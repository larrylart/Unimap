//============================================================================
//  plugin.cpp                                            j2k.ImageFile.Plugin
//============================================================================
//  *.j2k
//
//  www.openjpeg.org/
//  http://www.jpeg.org/jpeg2000guide/links/links.html
//
//  JPEG 2000 support provided by The OpenJPEG library.
//  Version 1.3 - December 21, 2007
//  Copyright (c) 2002-2009, Communications and Remote Sensing Laboratory, UCL.
//
//----------------------------------------------------------------------------
//  Copyright (C) 2009 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Library General Public License for more details.
//----------------------------------------------------------------------------
#include <stdio.h>

// eLynx.Core
#include <elx/core/CoreFile.h>
#include <elx/core/IPlugin.h>
#include <elx/core/IPluginPackage.h>

// eLynx.Image
#include <elx/image/ImageVariant.h>
#include <elx/image/IImageFilePlugin.h>

// boost
#include <boost/scoped_array.hpp>
#include <boost/shared_ptr.hpp>
using namespace boost;

#include "libopenjpeg/openjpeg.h"

// UUID of j2kPlugin {29A3B39F-2EE2-4bf1-8C51-23DC14932CD7}
elxDEFINE_UUID( UUID_j2kPlugin,
  0x29a3b39f, 0x2ee2, 0x4bf1, 0x8c, 0x51, 0x23, 0xdc, 0x14, 0x93, 0x2c, 0xd7);

namespace eLynx {
namespace Image {

#define J2K_CFMT 0
#define JP2_CFMT 1
#define JPT_CFMT 2

//----------------------------------------------------------------------------
int get_file_format(const char * filename)
//----------------------------------------------------------------------------
{
  unsigned int i;
  static const char * extension[] = {"j2k", "jp2", "jpt", "j2c" };
  static const int format[] = { J2K_CFMT, JP2_CFMT, JPT_CFMT, J2K_CFMT };
  const char * ext = ::strrchr(filename, '.');
  if (ext == NULL) return -1;

  ext++;
  if(ext) 
    for (i=0; i<sizeof(format)/sizeof(*format); i++) 
      if (strnicmp(ext, extension[i], 3) == 0)  
        return format[i];

  return -1;
}

//----------------------------------------------------------------------------
// sample error callback expecting a FILE* client object
//----------------------------------------------------------------------------
void error_callback(const char *msg, void *client_data) 
{
  FILE *stream = (FILE*)client_data;
  fprintf(stream, "[ERROR] %s", msg);
}

//----------------------------------------------------------------------------
// sample warning callback expecting a FILE* client object
//----------------------------------------------------------------------------
void warning_callback(const char *msg, void *client_data) 
{
  FILE *stream = (FILE*)client_data;
  fprintf(stream, "[WARNING] %s", msg);
}

//----------------------------------------------------------------------------
// sample debug callback expecting no client object
//----------------------------------------------------------------------------
void info_callback(const char *msg, void *client_data) 
{
  (void)client_data;
  fprintf(stdout, "[INFO] %s", msg);
}

//----------------------------------------------------------------------------
//  IsValidFile
//----------------------------------------------------------------------------
bool IsValidFile(const char * iprFilename)
{ 
  if (NULL == iprFilename)
    return false;

  FILE * paFile = ::fopen(iprFilename, "rb");
  const bool bExist = (NULL != paFile);
  ::fclose(paFile); paFile = NULL;

  return bExist ;

} // IsValidFile

/*
opj_image_t
  int x0,y0,x1,y1;
  int numcomps;               // number of components in the image
  OPJ_COLOR_SPACE color_space;// color space: sRGB, Greyscale or YCC
  opj_image_comp_t *comps;    // image components 

pj_image_comp _t
  int dx;   // horizontal separation of a sample of ith component with respect to the reference grid 
  int dy;   // YRsiz: vertical separation of a sample of ith component with respect to the reference grid 
  int w;    // data width
  int h;    // data height
  int x0;   // x component offset compared to the whole image
  int y0;   // y component offset compared to the whole image
  int prec; // precision
  int bpp;  // image depth in bits
  int sgnd; // signed (1) / unsigned (0)
  int resno_decoded; // number of decoded resolution
  int factor; // number of division by 2 of the out image compared to the original size of image
  int *data;  // image component data 
*/
#define _R_ 0
#define _G_ 1
#define _B_ 2
#define _A_ 3

//----------------------------------------------------------------------------
//  J2K_To_eLynx: convert image from j2k format to eLynx one
//----------------------------------------------------------------------------
shared_ptr<AbstractImage> J2K_To_eLynx(const opj_image_t& iImage)
{
  shared_ptr<AbstractImage> spAbstractImage;

  bool bSameSize = true;
  for (int i=0; i<iImage.numcomps-1; i++)
  {
    if ((iImage.comps[0].dx != iImage.comps[i+1].dx) ||
        (iImage.comps[0].dy != iImage.comps[i+1].dy) ||
        (iImage.comps[0].prec != iImage.comps[i+1].prec))
      bSameSize = false;
  }

  // Mono with alpha, or RGB with alpha.
//  bool bAlpha = (iImage.numcomps==2) || (iImage.numcomps==4); 

  // get image size
  const int w = iImage.comps[0].w;
  const int h = iImage.comps[0].h;
  const int32 size = w*h;

  
  switch (iImage.numcomps)
  {
    // @TODO Handle more than 8 bits image
    case 1: // grey
    {
      const int adjustL = (iImage.comps[0].prec > 8) ? iImage.comps[0].prec - 8 : 0;
      const int dl = iImage.comps[0].sgnd ? 1 << (iImage.comps[0].prec - 1) : 0;

      shared_ptr<ImageLub> spImage( new ImageLub(w,h) );
      if (NULL != spImage.get())
      {
        PixelLub * prDst = spImage->GetPixel();
        for (int i=0; i<size; i++, prDst++) 
        {
          int l = iImage.comps[0].data[i] + dl;
          prDst->_luminance = (unsigned char) ((l >> adjustL)+((l >> (adjustL-1))%2));
        }
        spAbstractImage = spImage;
      }
    }
    break;

    case 2: // grey + alpha
    {
      if (bSameSize)
      {
        const int adjustL = (iImage.comps[0].prec > 8) ? iImage.comps[0].prec - 8 : 0;
        const int adjustA = (iImage.comps[1].prec > 8) ? iImage.comps[1].prec - 8 : 0;
        const int dl = iImage.comps[0].sgnd ? 1 << (iImage.comps[0].prec - 1) : 0;
        const int da = iImage.comps[1].sgnd ? 1 << (iImage.comps[1].prec - 1) : 0;

        shared_ptr<ImageLAub> spImage( new ImageLAub(w,h) );
        if (NULL != spImage.get())
        {
          PixelLAub * prDst = spImage->GetPixel();
          for (int i=0; i<size; i++, prDst++) 
          {
            const int l = iImage.comps[0].data[i] + dl;
            const int a = iImage.comps[1].data[i] + da;
            prDst->_luminance = (unsigned char) ((l >> adjustL)+((l >> (adjustL-1))%2));
            prDst->_alpha     = (unsigned char) ((a >> adjustA)+((a >> (adjustA-1))%2));
          }
          spAbstractImage = spImage;
        }
      }
    }
    break;

    case 3: // color rgb or YCbCr
    {
      switch (iImage.color_space)
      {
        case CLRSPC_SYCC:
        {
          // YCbCr color space
          if (bSameSize)
          {
#define _Y_  0 //2
#define _Cb_ 1
#define _Cr_ 2 //0
            shared_ptr<ImageRGBub> spImage( new ImageRGBub(w,h) );
            if (NULL != spImage.get())
            {
              PixelRGBub * prDst = spImage->GetPixel();
              const int32 size = w*h;
              for (int i=0; i<size; i++, prDst++) 
              {
                int y  = iImage.comps[_Y_ ].data[i];
                int Cb = iImage.comps[_Cb_].data[i];
                int Cr = iImage.comps[_Cr_].data[i];

                float r = y                         + 1.402f  *(Cr - 128);
                float g = y - 0.34414f * (Cb - 128) - 0.71414f*(Cr - 128);
                float b = y + 1.77f    * (Cb - 128);

                prDst->_red   = ResolutionTypeTraits<uint8>::ClampF(r);
                prDst->_green = ResolutionTypeTraits<uint8>::ClampF(g);
                prDst->_blue  = ResolutionTypeTraits<uint8>::ClampF(b);
	      }
              spAbstractImage = spImage;
            }
#undef _Y_
#undef _Cb_
#undef _Cr_
          }
          else
          {
#define _Y_  0
#define _Cb_ 1
#define _Cr_ 2
            // @TODO here more than default 4:2:2
            const int w0 = iImage.comps[_Y_].w;
            const int h0 = iImage.comps[_Y_].h;
//          const int p0 = iImage.comps[_Y_].prec;

            const int w1 = iImage.comps[_Cb_].w;
//          const int h1 = iImage.comps[_Cb_].h;
//          const int p1 = iImage.comps[_Cb_].prec;

            const int w2 = iImage.comps[_Cr_].w;
//          const int h2 = iImage.comps[_Cr_].h;
//          const int p2 = iImage.comps[_Cr_].prec;

            shared_ptr<ImageRGBub> spImage( new ImageRGBub(w0,h0) );
            if (NULL != spImage.get())
            {
              PixelRGBub * prDst = spImage->GetPixel();
              int x,y,x2;
              int * idx0 = iImage.comps[_Y_ ].data;
              int * idx1 = iImage.comps[_Cb_].data;
              int * idx2 = iImage.comps[_Cr_].data;
              for (y=0; y<h; y++)
              {
                for (x=0; x<w; x++)
                {
                  x2 = x>>1;
                  int Y  = idx0[x];
                  int Cb = idx1[x2];
                  int Cr = idx2[x2];
	          
                  float r = Y                         + 1.402f  *(Cr - 128);
                  float g = Y - 0.34414f * (Cb - 128) - 0.71414f*(Cr - 128);
                  float b = Y + 1.77f    * (Cb - 128);

                  prDst->_red   = ResolutionTypeTraits<uint8>::ClampF(r);
                  prDst->_green = ResolutionTypeTraits<uint8>::ClampF(g);
                  prDst->_blue  = ResolutionTypeTraits<uint8>::ClampF(b);

                  prDst++;
                }
                idx0 += w;
                if (y%2 == 1)
                {
                  idx1 += w1;
                  idx2 += w2;
                }
              }
              spAbstractImage = spImage;
            }
#undef _Y_
#undef _Cb_
#undef _Cr_
          }
          break;
        }

        case CLRSPC_UNKNOWN:
        case CLRSPC_SRGB:
        default:
        {
          if (bSameSize)
          {
            // sRGB as defined by IEC 61966�2
            const int adjustR = (iImage.comps[_R_].prec > 8) ? iImage.comps[_R_].prec - 8 : 0;
            const int adjustG = (iImage.comps[_G_].prec > 8) ? iImage.comps[_G_].prec - 8 : 0;
            const int adjustB = (iImage.comps[_B_].prec > 8) ? iImage.comps[_B_].prec - 8 : 0;

            const int dr = iImage.comps[_R_].sgnd ? 1 << (iImage.comps[_R_].prec - 1) : 0;
            const int dg = iImage.comps[_G_].sgnd ? 1 << (iImage.comps[_G_].prec - 1) : 0;
            const int db = iImage.comps[_B_].sgnd ? 1 << (iImage.comps[_B_].prec - 1) : 0;

            shared_ptr<ImageRGBub> spImage( new ImageRGBub(w,h) );
            if (NULL != spImage.get())
            {
              PixelRGBub * prDst = spImage->GetPixel();
              const int32 size = w*h;
              for (int i=0; i<size; i++, prDst++) 
              {
                const int r = iImage.comps[_R_].data[i] + dr;
                const int g = iImage.comps[_G_].data[i] + dg;
                const int b = iImage.comps[_B_].data[i] + db;

                prDst->_red   = (unsigned char) ((r >> adjustR) + ((r >> (adjustR-1))%2));
                prDst->_green = (unsigned char) ((g >> adjustG) + ((g >> (adjustG-1))%2));
	        prDst->_blue  = (unsigned char) ((b >> adjustB) + ((b >> (adjustB-1))%2));
	      }
              spAbstractImage = spImage;
            }
          }
          break;
        }
      }
    }
    break;

    case 4: // rgb + alpha
    {
      if (!bSameSize) break;

      // sRGB as defined by IEC 61966�2
      const int adjustR = (iImage.comps[_R_].prec > 8) ? iImage.comps[_R_].prec - 8 : 0;
      const int adjustG = (iImage.comps[_G_].prec > 8) ? iImage.comps[_G_].prec - 8 : 0;
      const int adjustB = (iImage.comps[_B_].prec > 8) ? iImage.comps[_B_].prec - 8 : 0;
      const int adjustA = (iImage.comps[_A_].prec > 8) ? iImage.comps[_A_].prec - 8 : 0;

      const int dr = iImage.comps[_R_].sgnd ? 1 << (iImage.comps[_R_].prec - 1) : 0;
      const int dg = iImage.comps[_G_].sgnd ? 1 << (iImage.comps[_G_].prec - 1) : 0;
      const int db = iImage.comps[_B_].sgnd ? 1 << (iImage.comps[_B_].prec - 1) : 0;
      const int da = iImage.comps[_A_].sgnd ? 1 << (iImage.comps[_A_].prec - 1) : 0;

      shared_ptr<ImageRGBAub> spImage( new ImageRGBAub(w,h) );
      if (NULL != spImage.get())
      {
        PixelRGBAub * prDst = spImage->GetPixel();
        const int32 size = w*h;
        for (int i=0; i<size; i++, prDst++) 
        {
          const int r = iImage.comps[_R_].data[i] + dr;
          const int g = iImage.comps[_G_].data[i] + dg;
          const int b = iImage.comps[_B_].data[i] + db;
          const int a = iImage.comps[_A_].data[i] + da;

          prDst->_red   = (unsigned char) ((r >> adjustR) + ((r >> (adjustR-1))%2));
          prDst->_green = (unsigned char) ((g >> adjustG) + ((g >> (adjustG-1))%2));
          prDst->_blue  = (unsigned char) ((b >> adjustB) + ((b >> (adjustB-1))%2));
          prDst->_alpha = (unsigned char) ((a >> adjustA) + ((a >> (adjustA-1))%2));
        }
        spAbstractImage = spImage;
      }
    }
    break;

    default:
      break;
  }

  return spAbstractImage;

} // J2K_To_eLynx


//----------------------------------------------------------------------------
//  LoadFile
//----------------------------------------------------------------------------
shared_ptr<AbstractImage> LoadFile(
    const char * iprFilename,
    ImageFileInfo& oInfo,
    ProgressNotifier& iNotifier)
{ 
  // open the input file
  if (NULL == iprFilename)
    return shared_ptr<AbstractImage>();

  // configure the event callbacks (not required)
  opj_event_mgr_t event_mgr;
  ::memset(&event_mgr, 0, sizeof(opj_event_mgr_t));
  event_mgr.error_handler   = error_callback;
  event_mgr.warning_handler = warning_callback;
  event_mgr.info_handler    = info_callback;

  // set decoding parameters to default values
  opj_dparameters_t parameters;
  opj_set_default_decoder_parameters(&parameters);
  parameters.decod_format = get_file_format(iprFilename);

  // read the input file and put it in memory
  FILE * paFile = ::fopen(iprFilename, "rb");
  ::fseek(paFile, 0, SEEK_END);
  const int fileLength = ::ftell(paFile);
  ::fseek(paFile, 0, SEEK_SET);
  unsigned char * pmBuffer = (unsigned char*)::malloc(fileLength);
  ::fread(pmBuffer, 1, fileLength, paFile);
  ::fclose(paFile);

  // decode the code-stream
  opj_image_t * paImage = NULL;
  const bool bInfo = false;
  
  // get a decoder handle
  OPJ_CODEC_FORMAT codec = CODEC_J2K;
  if (J2K_CFMT == parameters.decod_format) codec = CODEC_J2K; // codestream
  if (JP2_CFMT == parameters.decod_format) codec = CODEC_JP2; // compressed image data
  if (JPT_CFMT == parameters.decod_format) codec = CODEC_JPT; // JPIP
  opj_dinfo_t * paDecoderInfo = opj_create_decompress(codec);

  // catch events using our callbacks and give a local context
  opj_set_event_mgr((opj_common_ptr)paDecoderInfo, &event_mgr, stderr);

  // setup the decoder decoding parameters using user parameters
  opj_setup_decoder(paDecoderInfo, &parameters);

  // open a byte stream
  opj_cio_t * cio = opj_cio_open((opj_common_ptr)paDecoderInfo, pmBuffer, fileLength);

  // decode the stream and fill the image structure
  opj_codestream_info_t cstr_info;  // Codestream information structure
  if (bInfo)
    // If need to extract codestream information
    paImage = opj_decode_with_info(paDecoderInfo, cio, &cstr_info);
  else
    paImage = opj_decode(paDecoderInfo, cio);

  // close the byte stream
  opj_cio_close(cio);

  // free the memory containing the code-stream
  ::free(pmBuffer); pmBuffer = NULL;

  // free remaining structures
  if (paDecoderInfo) { opj_destroy_decompress(paDecoderInfo); paDecoderInfo = NULL; }

  // free codestream information structure
  if (bInfo) opj_destroy_cstr_info(&cstr_info);

  if (!paImage) 
  {
    ::fprintf(stderr, "ERROR: failed to decode image!\n");
    return shared_ptr<AbstractImage>();
  }

  // convert opj_image to eLynx image format
  shared_ptr<AbstractImage> spAbstractImage = J2K_To_eLynx(*paImage);

  // free image data structure
  if (paImage) { opj_image_destroy(paImage); paImage=NULL; }

  return spAbstractImage;

} // LoadFile


//----------------------------------------------------------------------------
//  SaveImage
//----------------------------------------------------------------------------
bool SaveImage(
    const ImageVariant& iImage, 
    const char * iprFilename, 
    const void * iprOptions) 
{ 
  if (NULL == iprFilename)
    return false;

  if (!iImage.IsValid())
    return false;

  // check resolution
  if (!(iImage.IsUInt8() || iImage.IsUInt16()))
    return false;

  return false;

} // SaveImage

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                            ImageFilePluginImpl
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ExportedByPlugin ImageFilePluginImpl : public IImageFilePlugin
{
public:
  // IPlugin implementation

  // Does it a internal plugins
  virtual bool IsPublic() const { return true; }

  // Get plugin implementation ID
  virtual const UUID& GetID() const { return UUID_j2kPlugin; }

  // Get plugin family type
  virtual const UUID& GetFamilyType() const { return UUID_IImageFilePlugin; }

  // Get version of implementation
  virtual size_t GetVersion() const { return 1; }

  // Get string description of plugin
  virtual const char * GetDescription(size_t iIndex=0) const 
  { 
    switch(iIndex)
    {
    case 0: return "JPEG 2000";   // plugin name
    case 1: return "eLynx Team";  // plugin copyright
    case 2: return "Joint Photographic Experts Group 2000";   // long description
    case 3: return "OpenJPEG v1.3 of December 21, 2007";
    }
    return NULL;
  }

  // IImageFileFormat implementation
  virtual size_t GetInputExtCount() const { return 4; }

  virtual const char * GetInputExt(size_t iIndex) const 
  {
    if (0 == iIndex) return "j2k";
    if (1 == iIndex) return "j2c";
    if (2 == iIndex) return "jp2";
    if (3 == iIndex) return "jpt";
//  if (4 == iIndex) return "jpx";
//  if (5 == iIndex) return "jpc";
    return NULL;
  }

  virtual bool IsSupported(
    const char * iprFilename, 
    ImageFileInfo& oInfo, 
    bool ibPreview) const
  { 
    return IsValidFile(iprFilename);
  }

  virtual bool GeneratePreview(
    const char * iprFilenameIn, 
    const char * iprFilenameOut,
    ProgressNotifier& iNotifier) const
  {
    return false;
  }

  virtual bool Import(
    ImageVariant& oImage, 
    const char * iprFilename, 
    ImageFileInfo& oInfo,
    ProgressNotifier& iNotifier)
  { 
    if (NULL == iprFilename)
      return false;
    shared_ptr<AbstractImage> spAbstract = LoadFile(iprFilename, oInfo, iNotifier);
    oImage.Assign(spAbstract);
    return (NULL != spAbstract.get());
  }
#if 1
  virtual size_t GetOutputExtCount() const { return 0; }
  virtual const char * GetOutputExt(size_t iIndex) const { return NULL; }
  virtual size_t GetOutputImageFormatCount() const { return 0; }
  virtual EPixelFormat GetOutputPixelFormat(size_t iIndex) const { return PF_Undefined; }
#else
  virtual size_t GetOutputExtCount() const { return 1; }
  virtual const char * GetOutputExt(size_t iIndex) const { return "j2k"; }

  virtual size_t GetOutputImageFormatCount() const { return 8; }
  virtual EPixelFormat GetOutputPixelFormat(size_t iIndex) const 
  { 
    static EPixelFormat ms_PixelFormat[8] = { 
      PF_Lub, PF_LAub, PF_RGBub, PF_RGBAub,
      PF_Lus, PF_LAus, PF_RGBus, PF_RGBAus
    };
    if (iIndex < GetOutputImageFormatCount())
      return ms_PixelFormat[iIndex];
    return PF_Undefined;
  }
#endif
  virtual bool Export(
    const ImageVariant& iImage, 
    const char * iprFilename, 
    ProgressNotifier& iNotifier,
    const ImageFileOptions * iprOptions) 
  { 
    return SaveImage(iImage, iprFilename, iprOptions);
  }
};

static ImageFilePluginImpl s_ImageFilePluginImpl;


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                               PluginPackageImpl
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ExportedByPlugin ImageFilePluginPackageImpl : public IPluginPackage
{
public:
  // IPluginPackage implementation

  // Get the plugin family type.
  virtual const UUID& GetFamilyType() const { return UUID_IImageFilePlugin;}

  // Get the package ID.
  virtual const UUID& GetID() const { return UUID_j2kPlugin;}

  // Returns the number of plugin available in the package.
  virtual size_t GetPluginCount() const { return 1; }

  // Returns a reference pointer on the ith plugin of this package.
  virtual const IPlugin * GetPlugin(size_t iIndex=0) const { return &s_ImageFilePluginImpl; }
};


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                              plugin startup
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
IMPLEMENT_PLUGIN_PACKAGE( ImageFilePluginPackageImpl );

} // namespace Image
} // namespace eLynx
