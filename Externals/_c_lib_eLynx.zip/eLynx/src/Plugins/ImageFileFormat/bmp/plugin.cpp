//============================================================================
//  plugin.cpp                                            bmp.ImageFile.Plugin
//============================================================================
//  *.bmp by Mike
//
//  Datas:
//  http://sourceforge.net/projects/easybmp/
//  http://local.wasp.uwa.edu.au/~pbourke/dataformats/bmp/
//  http://www.fileformat.info/format/bmp/spec/e27073c25463436f8a64fa789c886d9c/view.htm
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Library General Public License for more details.
//----------------------------------------------------------------------------
#include "stdio.h"
#include "stdlib.h"
#include <set>

// eLynx.Core
#include <elx/core/CoreFile.h>
#include <elx/core/IPlugin.h>
#include <elx/core/IPluginPackage.h>

// eLynx.Image
#include <elx/image/ImageVariant.h>
#include <elx/image/IImageFilePlugin.h>
#include <elx/image/PixelIterator.h>

// boost
#include <boost/scoped_array.hpp>
#include <boost/shared_ptr.hpp>
using namespace boost;

#include "libBMP/EasyBMP.h"
#include "libBMP/EasyBMP_BMP.h"

// UUID of bmpPlugin {409D8E39-2C15-42a6-AAF0-C31F1FA70AAB}
elxDEFINE_UUID( UUID_bmpPlugin,
  0x409d8e39, 0x2c15, 0x42a6, 0xaa, 0xf0, 0xc3, 0x1f, 0x1f, 0xa7, 0xa, 0xab);

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  IsValidFile
//----------------------------------------------------------------------------
bool IsValidFile(const char * iprFilename)
{ 
  return true;

} // IsValidFile


//----------------------------------------------------------------------------
//  IsLubImage
//----------------------------------------------------------------------------
bool IsLubImage(BMP& iBmpImage)
{
  uint32 bits = iBmpImage.TellBitDepth();
  if (bits > 8)
    return false;

  // @TODO check only used colors into lookup table
  uint32 size = iBmpImage.TellNumberOfColors();
  for (uint32 i=0; i<size; ++i)
  {
    RGBApixel bmpPixel = iBmpImage.GetColor(i);
    if (!(bmpPixel.Red == bmpPixel.Blue && 
          bmpPixel.Blue == bmpPixel.Green))
      return false;
  }
  return true;

} //IsLubImage

//----------------------------------------------------------------------------
//  LoadFile
//----------------------------------------------------------------------------
shared_ptr<AbstractImage> LoadFile(
    const char * iprFilename,
    ImageFileInfo& oInfo,
    ProgressNotifier& iNotifier)
{ 
  // open the BMP input file
  if (!iprFilename)
    return shared_ptr<AbstractImage>();

  BMP bmpImage;
  if (!bmpImage.ReadFromFile(iprFilename))
    return shared_ptr<AbstractImage>();
    
  uint32 width = bmpImage.TellWidth();
  uint32 height = bmpImage.TellHeight();
  uint32 bits = bmpImage.TellBitDepth();
//  bool isLub = IsLubImage(bmpImage);
  
  float progress = 0.0f;
  float delta = 1.0f / float(height);
  uint32 x,y;
  

  switch (bits)
  {
    case 32:
    {
      // RGBAub
      shared_ptr<ImageRGBAub> spImage(new ImageRGBAub(width, height));
      if (NULL == spImage.get())
        return shared_ptr<AbstractImage>();
      PixelRGBAub * prDst = spImage->GetPixel();
      RGBApixel * prBMPPixel = NULL;
      for (y = 0; y < height; ++y)
      {
        for (x = 0; x < width; ++x, ++prDst)
        {
          prBMPPixel = bmpImage(x,y);
          prDst->_red   = prBMPPixel->Red;
          prDst->_green = prBMPPixel->Green;
          prDst->_blue  = prBMPPixel->Blue;
          prDst->_alpha = prBMPPixel->Alpha;
        }
        progress += delta;
        iNotifier.SetProgress(progress);
      }
      iNotifier.SetProgress(1.0f);
      return spImage;
    }

    case 24:
    {
      // RGBub
      shared_ptr<ImageRGBub> spImage(new ImageRGBub(width, height));
      if (NULL == spImage.get())
        return shared_ptr<AbstractImage>();
      PixelRGBub * prDst = spImage->GetPixel();
      RGBApixel * prBMPPixel = NULL;
      for (y = 0; y < height; ++y)
      {
        for (x = 0; x < width; ++x, ++prDst)
        {
          prBMPPixel = bmpImage(x,y);
          prDst->_red   = prBMPPixel->Red;
          prDst->_green = prBMPPixel->Green;
          prDst->_blue  = prBMPPixel->Blue;
        }
        progress += delta;
        iNotifier.SetProgress(progress);
      }
      iNotifier.SetProgress(1.0f);
      return spImage;
    }
    case 16: break;

    case 8:
    case 4:
    case 1:
    {
      if (IsLubImage(bmpImage))
      {
        // Lub
        shared_ptr<ImageLub> spImage(new ImageLub(width, height));
        if (NULL == spImage.get())
          return shared_ptr<AbstractImage>();
        PixelLub * prDst = spImage->GetPixel();
        for (y = 0; y < height; ++y)
        {
          for (x = 0; x < width; ++x, ++prDst)
          {
            prDst->_luminance = bmpImage(x,y)->Red;
          }
          progress += delta;
          iNotifier.SetProgress(progress);
        }
        iNotifier.SetProgress(1.0f);
        return spImage;
      }
      else
      {
        // RGBub
        shared_ptr<ImageRGBub> spImage(new ImageRGBub(width, height));
        if (NULL == spImage.get())
          return shared_ptr<AbstractImage>();
        PixelRGBub * prDst = spImage->GetPixel();
        RGBApixel * prBMPPixel = NULL;
        for (y = 0; y < height; ++y)
        {
          for (x = 0; x < width; ++x, ++prDst)
          {
            prBMPPixel = bmpImage(x,y);
            prDst->_red   = prBMPPixel->Red;
            prDst->_green = prBMPPixel->Green;
            prDst->_blue  = prBMPPixel->Blue;
          }
          progress += delta;
          iNotifier.SetProgress(progress);
        }
        iNotifier.SetProgress(1.0f);
        return spImage;
      }
    }
  }
  return shared_ptr<AbstractImage>();

} // LoadFile

//----------------------------------------------------------------------------
//  SetPixel
//----------------------------------------------------------------------------
void SetPixel(RGBApixel * oPixel, const PixelRGBub& iPixel)
{
  oPixel->Red   = iPixel._red;
  oPixel->Green = iPixel._green;
  oPixel->Blue  = iPixel._blue;
  oPixel->Alpha = 0;
}
void SetPixel(RGBApixel * oPixel, const PixelRGBAub& iPixel)
{
  oPixel->Red   = iPixel._red;
  oPixel->Green = iPixel._green;
  oPixel->Blue  = iPixel._blue;
  oPixel->Alpha = iPixel._alpha;
}
void SetPixel(RGBApixel * oPixel, const PixelLub& iPixel)
{
  oPixel->Red = oPixel->Green = oPixel->Blue = iPixel._luminance;
  oPixel->Alpha = 0;
}

struct PixelComparator
{
  bool operator()(const RGBApixel& p1, const RGBApixel& p2) const
  {
    return (p1.Red <p2.Red) ? true :
            (p1.Red >p2.Red) ? false:
              (p1.Green <p2.Green) ? true :
                (p1.Green >p2.Green) ? false :
                  (p1.Blue <p2.Blue) ? true : 
                    (p1.Alpha <p2.Alpha) ? true : false;
  }
};

//----------------------------------------------------------------------------
//  BuildColorMap
//----------------------------------------------------------------------------
template <class Pixel>
uint32 BuildColorMap(
    std::set<RGBApixel, 
    PixelComparator>& oColors,
    PixelIterator<Pixel> iBegin, 
    PixelIterator<Pixel> iEnd)
{
  RGBApixel pixel;

  if (iBegin->HasAlpha())
    return 32;

  for (PixelIterator<Pixel> current = iBegin; current != iEnd; ++current) 
  {
    SetPixel(&pixel, *current);
    oColors.insert(pixel);
    //if (oColors.size() >= 256)
    if (oColors.size() > 256)
      return 24;
  }
  size_t size = oColors.size();
  if (size <=2)
    return 1;
  else if (size <= 16)
    return 4;
  else if (size <= 256)
    return 8;

  return 8 * iBegin->GetChannelCount();

} //BuildColorMap

//----------------------------------------------------------------------------
//  SaveBMP
//----------------------------------------------------------------------------
template <class Pixel>
bool SaveBMP(const char * iprFilename,
  PixelIterator<Pixel> iBegin, PixelIterator<Pixel> iEnd, 
  uint32 iWidth, uint32 iHeight)
{
  // Create a color map
  std::set<RGBApixel, PixelComparator> colors;
  uint32 depth = BuildColorMap(colors, iBegin, iEnd);
  
  BMP bitmapImage;
  if (!bitmapImage.SetSize(iWidth, iHeight))
    return false;
  if (!bitmapImage.SetBitDepth(depth))
    return false;

  if (depth <= 8)
  {
    // Create Color palette
    if (!bitmapImage.CreateStandardColorTable())
      return false;
    std::set<RGBApixel, PixelComparator>::iterator c_begin = colors.begin();
    std::set<RGBApixel, PixelComparator>::iterator c_end = colors.end();
    uint32 pos = 0;
    while (c_begin != c_end)
    {
      if (!(bitmapImage.SetColor(pos++, *c_begin)))
        return false;
      ++c_begin;
    }   
  }

  // Set Pixels
  uint32 x,y;
  for (y=0; y < iHeight; y++) 
  {
    for (x=0; x < iWidth; x++, ++iBegin) 
      SetPixel(bitmapImage(x,y), *iBegin);
  }
  
  //Save file
  return bitmapImage.WriteToFile(iprFilename);

} // SaveBMP


//----------------------------------------------------------------------------
//  SaveImage
//----------------------------------------------------------------------------
bool SaveImage(
    const ImageVariant& iImage, 
    const char * iprFilename, 
    const void * iprOptions) 
{
  if (NULL == iprFilename)
    return false;

  if (!iImage.IsValid())
    return false;
    
  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();

  if (iImage.IsLub())
  {
    // Fill the colour map
    PixelIterator<PixelLub const> begin = elxConstDowncast<PixelLub>(iImage.Begin());
    PixelIterator<PixelLub const> end = elxConstDowncast<PixelLub>(iImage.End());  
    return SaveBMP(iprFilename, begin, end, w,h);
  }
  else if (iImage.IsRGBub())
  {
    // Fill the colour map
    PixelIterator<PixelRGBub const> begin = elxConstDowncast<PixelRGBub>(iImage.Begin());
    PixelIterator<PixelRGBub const> end = elxConstDowncast<PixelRGBub>(iImage.End());  
    return SaveBMP(iprFilename, begin, end, w,h);
  }
  else if (iImage.IsRGBAub())
  {
    // Fill the colour map
    PixelIterator<PixelRGBAub const> begin = elxConstDowncast<PixelRGBAub>(iImage.Begin());
    PixelIterator<PixelRGBAub const> end = elxConstDowncast<PixelRGBAub>(iImage.End());  
    return SaveBMP(iprFilename, begin, end, w,h);
  }
  return false;

} // SaveImage


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                            ImageFilePluginImpl
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ExportedByPlugin ImageFilePluginImpl : public IImageFilePlugin
{
public:
  // IPlugin implementation
  
  // Does it a internal plugins
  virtual bool IsPublic() const { return true; }

  // Get plugin implementation ID
  virtual const UUID& GetID() const { return UUID_bmpPlugin; }

  // Get plugin family type
  virtual const UUID& GetFamilyType() const { return UUID_IImageFilePlugin; }

  // Get version of implementation
  virtual size_t GetVersion() const { return 1; }

  // Get string description of plugin
  virtual const char * GetDescription(size_t iIndex=0) const 
  { 
    switch(iIndex)
    {
      case 0: return "bmp";                        // plugin name
      case 1: return "eLynx Team";                 // plugin copyright
      case 2: return "Windows or OS2 Bitmap";      // long description
      case 3: return "EasyBMP v1.01 of December 1, 2006";
    }
    return NULL;
  }

  // IImageFileFormat implementation
  virtual size_t GetInputExtCount() const { return 1; }

  virtual const char * GetInputExt(size_t iIndex) const 
  {
    static const char * ms_Ext[] = { "bmp" };
    if (iIndex < GetInputExtCount())
      return ms_Ext[iIndex];
    return NULL;
  }
  
  virtual bool IsSupported(
    const char * iprFilename, 
    ImageFileInfo& oInfo, 
    bool ibPreview) const
  { 
    return IsValidFile(iprFilename);
  }

  virtual bool GeneratePreview(
    const char * iprFilenameIn, 
    const char * iprFilenameOut,
    ProgressNotifier& iNotifier) const
  {
    return false;
  }

  virtual bool Import(
    ImageVariant& oImage, 
    const char * iprFilename, 
    ImageFileInfo& oInfo,
    ProgressNotifier& iNotifier)
  { 
    if (NULL == iprFilename)
      return false;
    shared_ptr<AbstractImage> spAbstract = LoadFile(iprFilename, oInfo, iNotifier);
    oImage.Assign(spAbstract);
    return (NULL != spAbstract.get());
  }

  virtual size_t GetOutputExtCount() const { return 1; }
  virtual const char * GetOutputExt(size_t iIndex) const { return "bmp"; }

  virtual size_t GetOutputImageFormatCount() const { return 3; }
  virtual EPixelFormat GetOutputPixelFormat(size_t iIndex) const 
  { 
    static EPixelFormat ms_PixelFormat[3] = { PF_RGBub, PF_RGBAub, PF_Lub };
    if (iIndex < GetOutputImageFormatCount())
      return ms_PixelFormat[iIndex];
    return PF_Undefined;
  }

  virtual bool Export(
      const ImageVariant& iImage, 
      const char * iprFilename, 
      ProgressNotifier& iNotifier,
      const ImageFileOptions * iprOptions) 
  { 
    return SaveImage(iImage, iprFilename, iprOptions);
  }
};

static ImageFilePluginImpl s_ImageFilePluginImpl;


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                               PluginPackageImpl
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ExportedByPlugin ImageFilePluginPackageImpl : public IPluginPackage
{
public:
  // IPluginPackage implementation

  // Get the plugin family type.
  virtual const UUID& GetFamilyType() const { return UUID_IImageFilePlugin;}

  // Get the package ID.
  virtual const UUID& GetID() const { return UUID_bmpPlugin;}

  // Returns the number of plugin available in the package.
  virtual size_t GetPluginCount() const { return 1; }

  // Returns a reference pointer on the ith plugin of this package.
  virtual const IPlugin * GetPlugin(size_t iIndex=0) const { return &s_ImageFilePluginImpl; }
};


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                              plugin startup
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
IMPLEMENT_PLUGIN_PACKAGE( ImageFilePluginPackageImpl );

} // namespace Image
} // namespace eLynx
