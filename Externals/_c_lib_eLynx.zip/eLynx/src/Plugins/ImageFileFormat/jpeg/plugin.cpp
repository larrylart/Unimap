//============================================================================
//  plugin.cpp                                           jpeg.ImageFile.Plugin
//============================================================================
//  *.jpg, *.jpeg 
//
//  http://www.ijg.org/
//  http://en.wikipedia.org/wiki/JPEG
//
//  JPEG support provided by the Independent JPEG Group's JPEG software.
//  Version 8b - May 16, 2010
//  This software is based in part on the work of the Independent JPEG Group.
//
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Library General Public License for more details.
//----------------------------------------------------------------------------
#include <stdio.h>
#include <setjmp.h> // For JPEG library error handling

// eLynx.Core
#include <elx/core/CoreFile.h>
#include <elx/core/IPlugin.h>
#include <elx/core/IPluginPackage.h>

// eLynx.Image
#include <elx/image/ImageVariant.h>
#include <elx/image/IImageFilePlugin.h>

// boost
#include <boost/scoped_array.hpp>
#include <boost/shared_ptr.hpp>
using namespace boost;

// lib JPEG
//#ifdef elxWINDOWS
//#define XMD_H
//#endif

extern "C" {
#include "../libjpeg/jpeglib.h"
}

// UUID of jpegPlugin {716221D3-56AD-44f3-9316-C74BF41B3754}
elxDEFINE_UUID( UUID_jpegPlugin,
  0x716221d3, 0x56ad, 0x44f3, 0x93, 0x16, 0xc7, 0x4b, 0xf4, 0x1b, 0x37, 0x54);

namespace eLynx {
namespace Image {

  // JPEG error manager
struct elx_error_mgr 
{
  struct jpeg_error_mgr pub;  // "public" fields
  jmp_buf setjmp_buffer;      // for return to caller
};

typedef struct elx_error_mgr * elx_error_ptr;

void elx_error_exit (j_common_ptr cinfo)
{
  // cinfo->err really points to a wx_error_mgr struct, so coerce pointer
  elx_error_ptr myerr = (elx_error_ptr) cinfo->err;

  // Always display the message. 
  // We could postpone this until after returning, if we chose.
  if (cinfo->err->output_message) (*cinfo->err->output_message) (cinfo);

  // Return control to the setjmp point
  longjmp(myerr->setjmp_buffer, 1);
}

//----------------------------------------------------------------------------
//  IsValidFile
//----------------------------------------------------------------------------
bool IsValidFile(const char * iprFilename)
{ 
/*
  TODO your code to check if image has a valid format
*/
  return true;

} // IsValidFile


//----------------------------------------------------------------------------
//  LoadFile
//----------------------------------------------------------------------------
shared_ptr<AbstractImage> LoadFile(
    const char * iprFilename,
    ImageFileInfo& oInfo,
    ProgressNotifier& iNotifier)
{ 
  // In this example we want to open the input file before doing anything else,
  // so that the setjmp() error recovery below can assume the file is open.
  // VERY IMPORTANT: use "b" option to fopen() if you are on a machine that
  // requires it in order to read binary files.
  FILE * paFile = fopen(iprFilename, "rb");
  if (NULL == paFile) 
    return shared_ptr<AbstractImage>();

  // Step 1: allocate and initialize JPEG decompression object

  // This struct contains the JPEG decompression parameters and pointers to
  // working space (which is allocated as needed by the JPEG library).
  struct jpeg_decompress_struct cinfo;

  // We use our private extension JPEG error handler.
  // Note that this struct must live as long as the main JPEG parameter
  // struct, to avoid dangling-pointer problems.
  struct elx_error_mgr jerr;

  // We set up the normal JPEG error routines, then override error_exit.
  cinfo.err = jpeg_std_error(&jerr.pub);
  //cinfo.err = jpeg_std_error(NULL);
  jerr.pub.error_exit = elx_error_exit;

  // Establish the setjmp return context for my_error_exit to use. 
  if (setjmp(jerr.setjmp_buffer)) 
  {
    // If we get here, the JPEG code has signaled an error.
    // We need to clean up the JPEG object, close the input file, and return.
    jpeg_destroy_decompress(&cinfo);
    fclose(paFile); paFile=NULL;
    return shared_ptr<AbstractImage>();
  }

  // Now we can initialize the JPEG decompression object.
  jpeg_create_decompress(&cinfo);


  // Step 2: specify data source (eg, a file)
  jpeg_stdio_src(&cinfo, paFile);


  // Step 3: read file parameters with jpeg_read_header()
  (void) jpeg_read_header(&cinfo, TRUE);
  // We can ignore the return value from jpeg_read_header since
  // (a) suspension is not possible with the stdio data source, and
  // (b) we passed TRUE to reject a tables-only JPEG file as an error.


  // Step 4: set parameters for decompression 

  // we don't need to change any of the defaults set by jpeg_read_header(), 
  // so we do nothing here.

  // Step 5: Start decompressor
  (void) jpeg_start_decompress(&cinfo);
  // We can ignore the return value since suspension is not possible
  // with the stdio data source.

  // We may need to do some setup of our own at this point before reading
  // the data.  After jpeg_start_decompress() we have the correct scaled
  // output image dimensions available, as well as the output colormap
  // if we asked for color quantization.
  // We need to make an output work buffer of the right size.

  // now we can allocate memory to store the image
  shared_ptr<AbstractImage> spAbstractImage;
  uint8 * prImageData = NULL;
  if (3 == cinfo.num_components)
  {
    // RGB (8 bits), can select Color Space
    shared_ptr<ImageRGBub> spImage( new ImageRGBub(cinfo.output_width, cinfo.output_height) );
    if (NULL != spImage.get()) prImageData = (uint8*)spImage->GetSamples();
    spAbstractImage = spImage;
  }
  else if (1 == cinfo.num_components)
  {
    // Grey (8 bits) 
    shared_ptr<ImageLub> spImage( new ImageLub(cinfo.output_width, cinfo.output_height) );
    if (NULL != spImage.get()) prImageData = (uint8*)spImage->GetSamples();
    spAbstractImage = spImage;
  }

  // JSAMPLEs per row in output buffer = physical row width in output buffer
  int row_stride = cinfo.output_width * cinfo.output_components;

  // Make a one-row-high sample array that will go away when done with image
  // Output row buffer
  JSAMPARRAY buffer = (*cinfo.mem->alloc_sarray)
		((j_common_ptr) &cinfo, JPOOL_IMAGE, row_stride, 1);


  // Step 6: while (scan lines remain to be read) 
  //           jpeg_read_scanlines(...);

  // Here we use the library's state variable cinfo.output_scanline as the
  // loop counter, so that we don't have to keep track ourselves.
  float progress = 0.0f;
  float delta = 1.0f / float(cinfo.output_height);

  while (cinfo.output_scanline < cinfo.output_height) 
  {
    // jpeg_read_scanlines expects an array of pointers to scanlines.
    // Here the array is only one element long, but you could ask for
    // more than one scanline at a time if that's more convenient.
    (void) jpeg_read_scanlines(&cinfo, buffer, 1);

    // Assume put_scanline_someplace wants a pointer and sample count.
    ::memcpy(prImageData, buffer[0], row_stride);
    prImageData += row_stride;
    progress += delta;
    iNotifier.SetProgress(progress);
  }

  // Step 7: Finish decompression 
  (void) jpeg_finish_decompress(&cinfo);
  // We can ignore the return value since suspension is not possible
  // with the stdio data source.


  // Step 8: Release JPEG decompression object

  // This is an important step since it will release a good deal of memory.
  jpeg_destroy_decompress(&cinfo);

  // After finish_decompress, we can close the input file.
  // Here we postpone it until after no more JPEG errors are possible,
  // so as to simplify the setjmp error logic above.  (Actually, I don't
  // think that jpeg_destroy can do an error exit, but why assume anything...)
  fclose(paFile); paFile = NULL;

  // At this point you may want to check to see whether any corrupt-data
  // warnings occurred (test whether jerr.pub.num_warnings is nonzero).

  return spAbstractImage;

} // LoadFile


//----------------------------------------------------------------------------
//  SaveImage
//----------------------------------------------------------------------------
bool SaveImage(
    const ImageVariant& iImage, 
    const char * iprFilename, 
    const ImageFileOptions * iprOptions) 
{ 
  if (NULL == iprFilename)
    return false;

  if (!iImage.IsValid())
    return false;

  // 'Quality' is a number between 0 (terrible) and 100 (very good).
  int quality = (NULL == iprOptions) ? 90 : iprOptions->GetQuality();

  // This struct contains the JPEG compression parameters and pointers to
  // working space (which is allocated as needed by the JPEG library).
  // It is possible to have several such structures, representing multiple
  // compression/decompression processes, in existence at once.  We refer
  // to any one struct (and its associated working data) as a "JPEG object".
  struct jpeg_compress_struct cinfo;

  // This struct represents a JPEG error handler.  It is declared separately
  // because applications often want to supply a specialized error handler
  // (see the second half of this file for an example).  But here we just
  // take the easy way out and use the standard error handler, which will
  // print a message on stderr and call exit() if compression fails.
  // Note that this struct must live as long as the main JPEG parameter
  // struct, to avoid dangling-pointer problems.
  struct jpeg_error_mgr jerr;

  // Step 1: allocate and initialize JPEG compression object

  // We have to set up the error handler first, in case the initialization
  // step fails.  (Unlikely, but it could happen if you are out of memory.)
  // This routine fills in the contents of struct jerr, and returns jerr's
  // address which we place into the link field in cinfo.
  cinfo.err = jpeg_std_error(&jerr);

  // Now we can initialize the JPEG compression object.
  jpeg_create_compress(&cinfo);

  // Step 2: specify data destination (eg, a file)
  // Note: steps 2 and 3 can be done in either order.

  // Here we use the library-supplied code to send compressed data to a
  // stdio stream.  You can also write your own code to do something else.
  // VERY IMPORTANT: use "b" option to fopen() if you are on a machine that
  // requires it in order to write binary files.
  FILE * paFile = ::fopen(iprFilename, "wb");
  if (NULL == paFile) 
  {
    fprintf(stderr, "can't open %s\n", iprFilename);
    return false;
  }
  jpeg_stdio_dest(&cinfo, paFile);

  // Step 3: set parameters for compression

  // First we supply a description of the input image.
  // Four fields of the cinfo struct must be filled in:
  const uint32 nChannel = iImage.GetChannelCount();
  cinfo.image_width = iImage.GetWidth();
  cinfo.image_height = iImage.GetHeight();
  cinfo.input_components = nChannel;
  if (3 == nChannel)
    cinfo.in_color_space = JCS_RGB;
  else
    cinfo.in_color_space = JCS_GRAYSCALE;

  // Now use the library's routine to set default compression parameters.
  // (You must set at least cinfo.in_color_space before calling this,
  // since the defaults depend on the source color space.)
  jpeg_set_defaults(&cinfo);

  // Now you can set any non-default parameters you wish to.
  // Here we just illustrate the use of quality (quantization table) scaling:
  jpeg_set_quality(&cinfo, quality, TRUE /* limit to baseline-JPEG values */);

  // Step 4: Start compressor 

  // TRUE ensures that we will write a complete interchange-JPEG file.
  // Pass TRUE unless you are very sure of what you're doing.
  jpeg_start_compress(&cinfo, TRUE);

  // Step 5: while (scan lines remain to be written)
  //           jpeg_write_scanlines(...);

  // Here we use the library's state variable cinfo.next_scanline as the
  // loop counter, so that we don't have to keep track ourselves.
  // To keep things simple, we pass one scanline per call; 
  // you can pass more if you wish, though.

  // JSAMPLEs per row in image_buffer
  int row_stride = iImage.GetWidth() * nChannel;	

  const JSAMPLE * image_buffer = NULL;
  switch (iImage.GetPixelFormat())
  {
    case PF_Lub:
    {
      PixelIterator<PixelLub const> begin = elxConstDowncast<PixelLub>(iImage.Begin());
      image_buffer = &begin->_channel[0];
      break;
    }
    case PF_RGBub:
    {
      PixelIterator<PixelRGBub const> begin = elxConstDowncast<PixelRGBub>(iImage.Begin());
      image_buffer = (uint8*)&begin->_channel[0];
      break;
    }
    default: break;
  }

  JSAMPROW row_pointer[1];	// pointer to JSAMPLE row[s]
  while (cinfo.next_scanline < cinfo.image_height) 
  {
    // jpeg_write_scanlines expects an array of pointers to scanlines.
    // Here the array is only one element long, but you could pass
    // more than one scanline at a time if that's more convenient.
    row_pointer[0] =  & ((JSAMPLE *)image_buffer)[cinfo.next_scanline * row_stride];
    (void) jpeg_write_scanlines(&cinfo, row_pointer, 1);
  }

  // Step 6: Finish compression
  jpeg_finish_compress(&cinfo);

  // After finish_compress, we can close the output file.
  ::fclose(paFile); 
  paFile = NULL;

  // Step 7: release JPEG compression object 

  // This is an important step since it will release a good deal of memory.
  jpeg_destroy_compress(&cinfo);
  return true;

} // SaveImage


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                            ImageFilePluginImpl
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ExportedByPlugin ImageFilePluginImpl : public IImageFilePlugin
{
public:
  // IPlugin implementation
  
  // Does it a internal plugins
  virtual bool IsPublic() const { return true; }

  // Get plugin implementation ID
  virtual const UUID& GetID() const { return UUID_jpegPlugin; }

  // Get plugin family type
  virtual const UUID& GetFamilyType() const { return UUID_IImageFilePlugin; }

  // Get version of implementation
  virtual size_t GetVersion() const { return 1; }

  // Get string description of plugin
  virtual const char * GetDescription(size_t iIndex=0) const
  {
    switch(iIndex)
    {
      case 0: return "jpeg";                                   // plugin name
      case 1: return "JPEG Group, eLynx Team";                 // plugin copyright
      case 2: return "JPEG Joint Photographic Experts Group";  // long description
      case 3: return "libJPEG v8b of May 16, 2010";
    }
    return NULL;
  }

  // IImageFileFormat implementation
  virtual size_t GetInputExtCount() const { return 5; }

  virtual const char * GetInputExt(size_t iIndex) const 
  {
    if (0 == iIndex) return "jpg";
    if (1 == iIndex) return "jpeg";
    if (2 == iIndex) return "jpe";
    if (3 == iIndex) return "jfif";
    if (4 == iIndex) return "jfi";
    return NULL;
  }
  
  virtual bool IsSupported(const char * iprFilename, ImageFileInfo& oInfo, bool ibThumbnail) const 
  { 
    return IsValidFile(iprFilename);
  }

  virtual bool GeneratePreview(
    const char * iprFilenameIn, 
    const char * iprFilenameOut,
    ProgressNotifier& iNotifier) const
  {
    return false;
  }

  virtual bool Import(
    ImageVariant& oImage, 
    const char * iprFilename, 
    ImageFileInfo& oInfo,
    ProgressNotifier& iNotifier)
  { 
    if (NULL == iprFilename)
      return false;
    shared_ptr<AbstractImage> spAbstract = LoadFile(iprFilename, oInfo, iNotifier);
    oImage.Assign(spAbstract);
    return (NULL != spAbstract.get());
  }

  virtual size_t GetOutputExtCount() const { return 1; }
  virtual const char * GetOutputExt(size_t iIndex) const 
  { 
    if (0 == iIndex) return "jpg";
    return NULL; 
  }  

  virtual size_t GetOutputImageFormatCount() const { return 2; }
  virtual EPixelFormat GetOutputPixelFormat(size_t iIndex) const 
  { 
    EPixelFormat list[2] = { PF_Lub, PF_RGBub };
    if (iIndex < GetOutputImageFormatCount())
      return list[iIndex];
    return PF_Undefined;
  }

  virtual bool Export(
      const ImageVariant& iImage, 
      const char * iprFilename, 
      ProgressNotifier& iNotifier,
      const ImageFileOptions * iprOptions) 
  { 
    return SaveImage(iImage, iprFilename, iprOptions);
  }
};

static ImageFilePluginImpl s_ImageFilePluginImpl;


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                               PluginPackageImpl
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ExportedByPlugin ImageFilePluginPackageImpl : public IPluginPackage
{
public:
  // IPluginPackage implementation

  // Get the plugin family type.
  virtual const UUID& GetFamilyType() const { return UUID_IImageFilePlugin;}

  // Get the package ID.
  virtual const UUID& GetID() const { return UUID_jpegPlugin;}

  // Returns the number of plugin available in the package.
  virtual size_t GetPluginCount() const { return 1; }

  // Returns a reference pointer on the ith plugin of this package.
  virtual const IPlugin * GetPlugin(size_t iIndex=0) const { return &s_ImageFilePluginImpl; }
};


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                              plugin startup
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
IMPLEMENT_PLUGIN_PACKAGE( ImageFilePluginPackageImpl );

} // namespace Image
} // namespace eLynx
