//============================================================================
//  plugin.cpp                                            gif.ImageFile.Plugin
//============================================================================
//
//  http://www.cs.usyd.edu.au/~graphapp/package/src/libgif/
//
//  GIF support provided by the libGIF library
//  Version 3.56 - August 9, 2005
//  Copyright (c) L. Patrick
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Library General Public License for more details.
//----------------------------------------------------------------------------
#include "stdio.h"
#include "stdlib.h"

#include <map>

// eLynx.Core
#include <elx/core/CoreFile.h>
#include <elx/core/IPlugin.h>
#include <elx/core/IPluginPackage.h>

// eLynx.Image
#include <elx/image/ImageVariant.h>
#include <elx/image/IImageFilePlugin.h>
#include <elx/image/PixelIterator.h>

// boost
#include <boost/scoped_array.hpp>
#include <boost/shared_ptr.hpp>
using namespace boost;

//----------------------------------------------------------------------------
// app minimal implementation for libGIF
//----------------------------------------------------------------------------
/* Inhibit C++ name-mangling . */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef unsigned char      byte;

typedef struct Colour      Color;
typedef struct Colour      Colour;
typedef struct Image       Image;

struct Colour {
byte  alpha;    /* transparency, 0=opaque, 255=transparent */
byte  red;      /* intensity, 0=black, 255=bright red */
byte  green;    /* intensity, 0=black, 255=bright green */
byte  blue;     /* intensity, 0=black, 255=bright blue */
};
  
#define rgb(r,g,b)             app_new_rgb((r),(g),(b))
#define argb(a,r,g,b)          app_new_argb((a),(r),(g),(b))
#define app_new_color(r,g,b)   app_new_rgb((r),(g),(b))
#define app_new_colour(r,g,b)  app_new_rgb((r),(g),(b))

Colour app_new_rgb(int32 r, int32 g, int32 b)
{
  Colour col;

  col.alpha = 0;
  col.red = r;
  col.green = g;
  col.blue = b;

  return col;
}

Colour app_new_argb(int32 a, int32 r, int32 g, int32 b)
{
  Colour col;

  col.alpha = a;
  col.red = r;
  col.green = g;
  col.blue = b;

  return col;
}

struct Palette {
int32    size;               /* list of colours */
Colour * element;
};

struct Image {
int32     depth;              /* 8 (indexed), 32 (direct) */
int32     width;              /* in pixels */
int32     height;             /* in pixels */
int32     cmap_size;          /* indexed list of colours */
Colour *  cmap;
byte **   data8;              /* indexed 8-bit data, or */
Colour ** data32;             /* direct 32-bit data */
};


/*
 *  Memory management:
 */

void *	app_alloc(long size)        { return ::malloc(size); }
void *	app_zero_alloc(long size)   { void * p = ::malloc(size); ::memset(p,0,size); return p; }
void *	app_realloc(void *ptr, long newsize) { return ::realloc(ptr, newsize); }
void	app_free(void *ptr)           { ::free(ptr); }

FILE *	app_open_file(const char *filepath, const char *mode){ return ::fopen(filepath,mode);}
int32 	app_close_file(FILE *f) { return ::fclose(f); }

/*
*  Create a new image:
*/
Image * app_new_image(int32 width, int32 height, int32 depth)
{
  Image *img;
  int32 i;

  if ((depth != 8) && (depth != 32))
    return NULL;

  img = (Image*)app_zero_alloc(sizeof(Image));

  if (! img)
    return img;

  img->width  = width;
  img->height = height;

  if (depth == 8) {
    img->depth  = 8;
    img->data8  = (byte**)app_alloc(height * sizeof(byte *));
    for (i=0; i < height; i++)
      img->data8[i] = (byte*)app_alloc(width);
  }
  else {
    img->depth  = 32;
    img->data32 = (Colour**)app_alloc(height * sizeof(Colour *));
    for (i=0; i < height; i++)
      img->data32[i] = (Colour*)app_alloc(width * sizeof(Colour));
  }

  return img;
}

/*
 *  Delete an image:
 */
void app_del_image(Image *img)
{
  int32 row;

  if (img->data8) {
    for (row=0; row < img->height; row++)
      app_free(img->data8[row]);
    app_free(img->data8);
  }

  if (img->data32) {
    for (row=0; row < img->height; row++)
      app_free(img->data32[row]);
    app_free(img->data32);
  }

  if (img->cmap)
    app_free(img->cmap);

  app_free(img);
}

/*
 *  Change an image's colour map:
 */
void app_set_image_cmap(Image *img, int32 cmap_size, Colour *cmap)
{
  int32 i;
  Colour *prev_cmap;

  prev_cmap = img->cmap;

  img->cmap_size = cmap_size;
  img->cmap = (Colour*)app_alloc(cmap_size * sizeof(Colour));

  for (i=0; i < cmap_size; i++)
    img->cmap[i] = cmap[i];

  app_free(prev_cmap);
}
#ifdef __cplusplus
}
#endif
//----------------------------------------------------------------------------


#include "libGIF/gif.h"

// UUID of gifPlugin {40767312-7CE7-49a7-9772-A6788CA64329}
elxDEFINE_UUID( UUID_gifPlugin,
  0x40767312, 0x7ce7, 0x49a7, 0x97, 0x72, 0xa6, 0x78, 0x8c, 0xa6, 0x43, 0x29);

namespace eLynx {
namespace Image {

typedef struct ::Image ImageStruct;

//----------------------------------------------------------------------------
//  IsValidFile
//----------------------------------------------------------------------------
bool IsValidFile(const char * iprFilename)
{ 
  FILE * paFile = ::fopen(iprFilename, "rb");
  if (NULL == paFile) return false;
  Gif * paGif = new_gif();
  if (NULL == paGif) 
  {
    ::fclose(paFile);
    return false;
  }

  ::read_gif(paFile, paGif);
  ::fclose(paFile);
  bool bValid = (::strncmp(paGif->header, "GIF", 3) != 0) ? false : true; 
  ::del_gif(paGif);
  return bValid;

} // IsValidFile

//----------------------------------------------------------------------------
//  GifToImage
//----------------------------------------------------------------------------
shared_ptr<AbstractImage> GifToImage(
    const GifPicture   * iprPicture, 
    const GifExtension * iprExtension, 
    const GifScreen    * iprScreen, 
    ProgressNotifier& iNotifier)
{
  if (NULL == iprPicture)
    return shared_ptr<ImageRGBub>();

  const int32 w = iprPicture->width;
  const int32 h = iprPicture->height;

  // Find a colour map
  const GifPalette * prMap = iprPicture->cmap;
  if ((NULL == prMap) || (prMap->length == 0))
    prMap = iprScreen->cmap;

  if (NULL == prMap)
    return shared_ptr<ImageRGBub>();
    
  // Check for a transparent colour
  bool bRGBA = false;

  // graphic control block
  if ((iprExtension) && (iprExtension->marker == 0xF9))
  {
    if ((iprExtension->data) && 
        (iprExtension->data[0]->byte_count == 4) && 
        (iprExtension->data[0]->bytes[0] & 0x01))
    {
      // transparent flag
      int32 trans_value = iprExtension->data[0]->bytes[3];
      if (prMap->length > trans_value)
      {
        prMap->colours[trans_value].alpha = 0xFF;
        bRGBA = true;
      }
    }
  }

  // Check for a grey map
  bool bGrey = true;
  int32 x,y,idx;

  // build table of used colors
  bool bUsed[256];
  for (int32 x=0; x<256; x++) bUsed[x] = false;
  for (y=0; y<h; ++y)
    for (x=0; x<w; ++x)
      bUsed[ iprPicture->data[y][x] ] = true;
  
  for (int32 i=0; i<prMap->length; i++)
    if (bUsed[i])
      if ((prMap->colours[i].red != prMap->colours[i].green) ||
          (prMap->colours[i].red != prMap->colours[i].blue))
      {
        bGrey = false;
        break;
      }

  // Create an image
  float progress = 0.0f;
  float delta = 1.0f / float(h);
  
  if (bGrey)
  {
    shared_ptr<ImageLub> spImage(new ImageLub(w,h));
    PixelLub * prDst = spImage->GetPixel();
    for (y=0; y<h; ++y)
    {
      for (x=0; x<w; ++x, ++prDst)
      {
        idx = iprPicture->data[y][x];
        prDst->_luminance = prMap->colours[idx].red;
      }
      progress += delta;
      iNotifier.SetProgress(progress);
    }
    iNotifier.SetProgress(1.0f);
    return spImage;
  }

  if (bRGBA)
  {
    shared_ptr<ImageRGBAub> spImage(new ImageRGBAub(w,h));
    PixelRGBAub * prDst = spImage->GetPixel();
    for (y=0; y<h; ++y)
    {
      for (x=0; x<w; ++x, ++prDst)
      {
        idx = iprPicture->data[y][x];
        prDst->_alpha = prMap->colours[idx].alpha;
        prDst->_red   = prMap->colours[idx].red;
        prDst->_green = prMap->colours[idx].green;
        prDst->_blue  = prMap->colours[idx].blue;
      }
      progress += delta;
      iNotifier.SetProgress(progress);
    }
    iNotifier.SetProgress(1.0f);
    return spImage;
  }

  shared_ptr<ImageRGBub> spImage(new ImageRGBub(w,h));
  PixelRGBub * prDst = spImage->GetPixel();
  for (y=0; y<h; ++y)
  {
    for (x=0; x<w; ++x, ++prDst)
    {
      idx = iprPicture->data[y][x];
      prDst->_red   = prMap->colours[idx].red;
      prDst->_green = prMap->colours[idx].green;
      prDst->_blue  = prMap->colours[idx].blue;
    }
    progress += delta;
    iNotifier.SetProgress(progress);
  }
  iNotifier.SetProgress(1.0f);
  return spImage;
} 

//----------------------------------------------------------------------------
//  LoadFile
//----------------------------------------------------------------------------
shared_ptr<AbstractImage> LoadFile(
    const char * iprFilename,
    ImageFileInfo& oInfo,
    ProgressNotifier& iNotifier)
{ 
  // open the GIF input file
  if (!iprFilename)
    return shared_ptr<AbstractImage>();

  GifPicture * prPicture = NULL;
  GifExtension * prExtension = NULL;

  // Read the Gif file into memory
  Gif * paGif = read_gif_file(iprFilename);
  if (NULL == paGif)
    return shared_ptr<AbstractImage>();
  
  shared_ptr<AbstractImage> image;
  
  // Find an image block and the extension just before it
  for (int32 i=0; i < paGif->block_count; i++) 
  {
    if (paGif->blocks[i]->ext) 
      prExtension = paGif->blocks[i]->ext;

    if (paGif->blocks[i]->pic) 
    {
      prPicture = paGif->blocks[i]->pic;
      image = GifToImage(prPicture, prExtension, paGif->screen, iNotifier);
      break;
    }
  }

  // Clean up and return the image
  del_gif(paGif);
  return image;  
  
} // LoadFile


//----------------------------------------------------------------------------
//  SetColor
//----------------------------------------------------------------------------
void SetColor(Colour& oCol, const PixelRGBub& iPixel)
{
  oCol.alpha = 0;
  oCol.red = iPixel._red;
  oCol.green = iPixel._green;
  oCol.blue = iPixel._blue;
}
void SetColor(Colour& oCol, const PixelRGBAub& iPixel)
{
  oCol.alpha = iPixel._alpha;
  oCol.red = iPixel._red;
  oCol.green = iPixel._green;
  oCol.blue = iPixel._blue;

} // SetColor

struct ColorComparator
{
  bool operator()(const Color& c1, const Color& c2) const
  {
    return (c1.red <c2.red) ? true :
            (c1.red >c2.red) ? false :
              (c1.green <c2.green) ? true :
                (c1.green >c2.green) ? false :
                  (c1.blue <c2.blue) ? true : 
                    (c1.alpha < c2.alpha) ? true : false;
  }
};
 
//----------------------------------------------------------------------------
//  FastFindCmap
//----------------------------------------------------------------------------
template <class Pixel>
ImageStruct * FastFindCmap(
    PixelIterator<Pixel> iBegin, PixelIterator<Pixel> iEnd, 
    uint32 iWidth, uint32 iHeight)
{
  ImageStruct * new_img;
  int32 idx = 0, cmap_size = 0;
  Colour col;
  Colour cmap[256];

  // create a sorted colour map for speed
  std::map<Color, int32, ColorComparator> color_map;

  for (PixelIterator<Pixel> current = iBegin; current != iEnd; ++current) 
  {
    SetColor(col, *current);
    // only allow one transparent colour in the cmap:
    if (col.alpha > 0x7F)
      col = argb(255,255,255,255); // transparent
    else
      col.alpha = 0; // opaque

    std::map<Color, int32, ColorComparator>::iterator it = color_map.find(col);
    if (it == color_map.end())
    {
      if (color_map.size() >= 256)
        return NULL;
      color_map.insert(std::make_pair(col, idx));
      ++idx;
    }
  } 
  cmap_size = (int32)color_map.size();
  std::map<Color, int32, ColorComparator>::iterator it = color_map.begin();
  std::map<Color, int32, ColorComparator>::iterator end = color_map.end();
  while (it != end)
  {
    cmap[it->second] = it->first;
    ++it;
  }

  // create the 8-bit indexed image
  new_img = app_new_image(iWidth, iHeight, 8);
  if (! new_img)
    return NULL;
  app_set_image_cmap(new_img, cmap_size, cmap);

  // convert each RGB(A) pixel into an 8-bit pixel
  PixelIterator<Pixel> current = iBegin; 
  for (uint32 y=0; y < iHeight; y++) 
  {
    for (uint32 x=0; x < iWidth; x++, ++current) 
    {
      SetColor(col, *current);
      // only allow one transparent colour in the cmap
      if (col.alpha > 0x7F)
        col = argb(255,255,255,255); // transparent
      else
        col.alpha = 0; // opaque

      std::map<Color, int32, ColorComparator>::iterator it = color_map.find(col);
      if (it == color_map.end())
      {
        // should not get there
        app_del_image(new_img);
        return NULL;
      }
      new_img->data8[y][x] = it->second;      
    }
  }

  return new_img;

} // FastFindCmap

//----------------------------------------------------------------------------
//  FastGenerateCmap
//----------------------------------------------------------------------------
template <class Pixel>
ImageStruct * FastGenerateCmap(
    PixelIterator<Pixel> iBegin, PixelIterator<Pixel> iEnd, 
    uint32 iWidth, uint32 iHeight)
{
  ImageStruct * new_img;
  uint32    i, x, y;
  int32     r, g, b, value;
  Colour  col;
  Colour  cmap[256];

  // Generate the colour map

  // 6x6x6 colour cube
  for (r=0; r<6; r++)
    for (g=0; g<6; g++)
      for (b=0; b<6; b++)
        cmap[r*36 + g*6 + b] = rgb(r,g,b);

  // greyscale ramp
  for (i=0; i<39; i++)
  {
    value = 255 * i / 38;
    cmap [216 + i] = rgb(value, value, value);
  }

  // transparent
  cmap[255] = argb(255,255,255,255);	

  // Generate the 8-bit indexed image
  new_img = app_new_image(iWidth, iHeight, 8);
  if (! new_img)
    return new_img;
  app_set_image_cmap(new_img, 256, cmap);

  // Translate the pixels from 32-bit to 8-bit
  PixelIterator<Pixel> current = iBegin; 
  for (y=0; y < iHeight; y++) 
  {
    for (x=0; x < iWidth; x++, ++current) 
    {
      SetColor(col, *current);
      r = col.red;
      g = col.green;
      b = col.blue;

      // transparent
      if (col.alpha > 0x7F) 
        value = 255;
      else if ((r == g) && (r == b))	
      {
        // grey
        g = g * 38 / 255;
        if (g == 0)
          value = 0; // black
        else
          value = 216 + g;
      }
      else
      {
        // map to 6x6x6 colour cube
        r = r * 5 / 255;
        g = g * 5 / 255;
        b = b * 5 / 255;
        value = r*36 + g*6 + b;
      }

      new_img->data8[y][x] = value;
    }
  }

  return new_img;

} // FastGenerateCmap

//----------------------------------------------------------------------------
//  SaveGif
//----------------------------------------------------------------------------
template <class Pixel>
bool SaveGif(
    const char * iprFilename,
    PixelIterator<Pixel> iBegin, PixelIterator<Pixel> iEnd, 
    uint32 iWidth, uint32 iHeight)
{
  // Create a blank Gif
  Gif * paGif = new_gif();
  if (NULL == paGif) return false;
    
  ImageStruct * img = FastFindCmap<Pixel>(iBegin, iEnd, iWidth, iHeight);
  if (NULL == img)
    img = FastGenerateCmap<Pixel>(iBegin, iEnd, iWidth, iHeight);
  if (NULL == img)
  {
    del_gif(paGif); paGif=NULL;
    return false;
  }
    
  int32 depth = 1;
  int32 cmap_length = (int32)img->cmap_size;
  for (; depth <= 8; depth++)
    if ((1 << depth) >= cmap_length)
      break;
      
  paGif->screen->width      = img->width;
  paGif->screen->height     = img->height;
  paGif->screen->has_cmap   = 1;
  paGif->screen->color_res  = 8;
  paGif->screen->cmap_depth = depth;

  // Fill the colour map
  GifExtension * ext = NULL;
  GifPalette * cmap = paGif->screen->cmap;
  cmap->length = 1 << depth;
  cmap->colours = (Color*) malloc(cmap->length * sizeof(Colour));
  if (cmap->colours == NULL)
  {
    del_gif(paGif); paGif=NULL;
    if (img) app_del_image(img);
    return false;
  }

  uint8 * data;
  GifBlock * block;
  int32 i, size;
  for (i=0; i < img->cmap_size; i++) 
  {
    // Append the colour
    cmap->colours[i] = img->cmap[i];

    if (img->cmap[i].alpha <= 0x7F)
      continue; // not transparent

    // Create transparent colour block
    if (ext)
      continue; // already made one 

    ext = new_gif_extension();
    ext->marker = 0xF9;
    ext->data = (GifData **) malloc(sizeof(GifData *));
    if (ext->data == NULL)
    {
      del_gif(paGif); paGif=NULL;
      if (img) app_del_image(img);
      return false;  
    }


    ext->data[0] = new_gif_data(4);
    data = ext->data[0]->bytes;
    data[0] = 0x05;	// was 0x01 (no disposal method)
    data[1] = 0x00;
    data[2] = 0x00;
    data[3] = i;
    ext->data_count++;

    // Link the transparency block to the Gif
    if ((block = new_gif_block()) == NULL)
    {
      del_gif(paGif); paGif=NULL;
      if (img) app_del_image(img);
      return false;  
    }

    block->intro = 0x21;
    block->ext = ext;
    // Append the block
    size = ++paGif->block_count;
    paGif->blocks = (GifBlock**) app_realloc(paGif->blocks, size * sizeof(GifBlock *));
    paGif->blocks[size-1] = block;
  }

  // Fill rest of colour map with zeros
  for ( ; i<cmap->length; i++)
    SetColor(cmap->colours[i], Pixel::Black());

  // Create a new GifPicture
  GifPicture * pic = new_gif_picture();
  if (pic == NULL)
  {
    del_gif(paGif); paGif=NULL;
    if (img) app_del_image(img);
    return false;  
  }

  pic->width      = img->width;
  pic->height     = img->height;
  pic->interlace  = 0; // 0=no interlace, 1=interlace
  pic->has_cmap   = 0;
  pic->cmap_depth = depth; // must be depth, despite not writing it

  // Link GifPicture data to supplied pixels
  pic->data = img->data8;

  // Link the GifPicture to the Gif
  if ((block = new_gif_block()) == NULL)
  {
    del_gif(paGif); paGif=NULL;
    del_gif_picture(pic);
    if (img) app_del_image(img);
    return false;  
  }
  block->intro = 0x2C;
  block->pic   = pic;

  // Append the block
  size = ++paGif->block_count;
  paGif->blocks = (GifBlock **) app_realloc(paGif->blocks, size * sizeof(GifBlock *));
  paGif->blocks[size-1] = block;

  // Write the Gif file
  write_gif_file(iprFilename, paGif);

  // Unlink the pixel data and clean up
  pic->data = NULL;
  del_gif(paGif); paGif=NULL;
  if (img) app_del_image(img);

  return true;

} // SaveGif

//----------------------------------------------------------------------------
//  SaveImage
//----------------------------------------------------------------------------
bool SaveImage(
    const ImageVariant& iImage, 
    const char * iprFilename, 
    const void * iprOptions) 
{
  if (NULL == iprFilename)
    return false;

  if (!iImage.IsValid())
    return false;

  // check resolution, supports only RGBub or RGBAub
  if (iImage.IsRGBub())
  {
    // Fill the colour map
    PixelIterator<PixelRGBub const> begin = elxConstDowncast<PixelRGBub>(iImage.Begin());
    PixelIterator<PixelRGBub const> end = elxConstDowncast<PixelRGBub>(iImage.End());  
    return 
      SaveGif(iprFilename, begin, end, iImage.GetWidth(), iImage.GetHeight());
  }
  else if (iImage.IsRGBAub())
  {
    // Fill the colour map
    PixelIterator<PixelRGBAub const> begin = elxConstDowncast<PixelRGBAub>(iImage.Begin());
    PixelIterator<PixelRGBAub const> end = elxConstDowncast<PixelRGBAub>(iImage.End());  
    return 
      SaveGif(iprFilename, begin, end, iImage.GetWidth(), iImage.GetHeight());
  }
  else
    return false;

} // SaveImage


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                            ImageFilePluginImpl
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ExportedByPlugin ImageFilePluginImpl : public IImageFilePlugin
{
public:
  // IPlugin implementation
  
  // Does it a internal plugins
  virtual bool IsPublic() const { return true; }

  // Get plugin implementation ID
  virtual const UUID& GetID() const { return UUID_gifPlugin; }

  // Get plugin family type
  virtual const UUID& GetFamilyType() const { return UUID_IImageFilePlugin; }

  // Get version of implementation
  virtual size_t GetVersion() const { return 1; }

  // Get string description of plugin
  virtual const char * GetDescription(size_t iIndex=0) const 
  { 
    switch(iIndex)
    {
      case 0: return "gif";                                     // plugin name
      case 1: return "L. Patrick, eLynx Team";                  // plugin copyright
      case 2: return "CompuServe Graphics Interchange Format";  // long description
      case 3: return "libGIF v3.56 of August 9, 2005";
    }
    return NULL;
  }

  // IImageFileFormat implementation
  virtual size_t GetInputExtCount() const { return 1; }

  virtual const char * GetInputExt(size_t iIndex) const 
  {
    if (0 == iIndex) return "gif";
    return NULL;
  }
  
  virtual bool IsSupported(
    const char * iprFilename, 
    ImageFileInfo& oInfo, 
    bool ibPreview) const
  { 
    return IsValidFile(iprFilename);
  }

  virtual bool GeneratePreview(
    const char * iprFilenameIn, 
    const char * iprFilenameOut,
    ProgressNotifier& iNotifier) const
  {
    return false;
  }

  virtual bool Import(
    ImageVariant& oImage, 
    const char * iprFilename, 
    ImageFileInfo& oInfo,
    ProgressNotifier& iNotifier)
  { 
    if (NULL == iprFilename)
      return false;
    shared_ptr<AbstractImage> spAbstract = LoadFile(iprFilename, oInfo, iNotifier);
    oImage.Assign(spAbstract);
    return (NULL != spAbstract.get());
  }
#if 0
  virtual size_t GetOutputExtCount() const { return 1; }
  virtual const char * GetOutputExt(size_t iIndex) const { return "gif"; }

  virtual size_t GetOutputImageFormatCount() const { return 2; }
  virtual EPixelFormat GetOutputPixelFormat(size_t iIndex) const 
  { 
    static EPixelFormat ms_PixelFormat[2] = { PF_RGBub, PF_RGBAub };
    if (iIndex < GetOutputImageFormatCount())
      return ms_PixelFormat[iIndex];
    return PF_Undefined;
  }

  virtual bool Export(
      const ImageVariant& iImage, 
      const char * iprFilename, 
      ProgressNotifier& iNotifier,
      const ImageFileOptions * iprOptions) 
  { 
    return SaveImage(iImage, iprFilename, iprOptions);
  }
#else
  virtual size_t GetOutputExtCount() const { return 0; }
  virtual const char * GetOutputExt(size_t iIndex) const { return NULL; }

  virtual size_t GetOutputImageFormatCount() const { return 0; }
  virtual EPixelFormat GetOutputPixelFormat(size_t iIndex) const { return PF_Undefined; }

  virtual bool Export(
      const ImageVariant& iImage, 
      const char * iprFilename, 
      ProgressNotifier& iNotifier,
      const ImageFileOptions * iprOptions) 
  { 
    return false;
  }
#endif
};

static ImageFilePluginImpl s_ImageFilePluginImpl;


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                               PluginPackageImpl
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ExportedByPlugin ImageFilePluginPackageImpl : public IPluginPackage
{
public:
  // IPluginPackage implementation

  // Get the plugin family type.
  virtual const UUID& GetFamilyType() const { return UUID_IImageFilePlugin;}

  // Get the package ID.
  virtual const UUID& GetID() const { return UUID_gifPlugin;}

  // Returns the number of plugin available in the package.
  virtual size_t GetPluginCount() const { return 1; }

  // Returns a reference pointer on the ith plugin of this package.
  virtual const IPlugin * GetPlugin(size_t iIndex=0) const { return &s_ImageFilePluginImpl; }
};


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                              plugin startup
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
IMPLEMENT_PLUGIN_PACKAGE( ImageFilePluginPackageImpl );

} // namespace Image
} // namespace eLynx
