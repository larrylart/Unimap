//============================================================================
//  AbstractImage.cpp                                  Image.Component package
//============================================================================
//  Usage : abstract image class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/AbstractImage.h>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  constructor : construct empty image of size iWidth by iHeight.
//----------------------------------------------------------------------------
//  protected
//----------------------------------------------------------------------------
//  In  : uint32 iWidth
//        uint32 iHeight
//----------------------------------------------------------------------------
AbstractImage::AbstractImage(uint32 iWidth, uint32 iHeight) :
  _width(iWidth),
  _height(iHeight)
{
} // constructor


//----------------------------------------------------------------------------
//  copy constructor : 
//----------------------------------------------------------------------------
//  protected
//----------------------------------------------------------------------------
//  In  : const AbstractImage& iImage
//----------------------------------------------------------------------------
AbstractImage::AbstractImage(const AbstractImage& iImage) :
  _width(iImage._width),
  _height(iImage._height)
{
} // copy constructor


//----------------------------------------------------------------------------
//  destructor
//----------------------------------------------------------------------------
//  public virtual
//----------------------------------------------------------------------------
AbstractImage::~AbstractImage()
{
} // destructor

} // namespace Image
} // namespace eLynx
