//============================================================================
//  EdgeProcessing/Roberts.hpp                         Image.Component package
//============================================================================
//
//  http://homepages.inf.ed.ac.uk/rbf/HIPR2/roberts.htm
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __EdgeProcessing_Roberts_hpp__
#define __EdgeProcessing_Roberts_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxApplyRoberts:
//----------------------------------------------------------------------------
//  Gx = |+1  0|   Gy = | 0 +1|   G = sqrt(Gx� + Gy�)
//       | 0 -1|        |-1  0|
//  
//  |P0 P1|   G = sqrt((P0-P1)� + (P1-P2)�)
//  |P2 P3|
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        uint32 iChannelMask
//        ProgressNotifier iNotifier :
//  Out : 
//----------------------------------------------------------------------------
template <class Pixel>
bool elxApplyRoberts(
    ImageImpl<Pixel>& ioImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  
  // we process convolution in Pixel_S::type resolution
  typedef typename Pixel::type T;
  typedef typename Pixel::F_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
  const IntegerToType< ResolutionTypeTraits<T>::_bInteger > doClamp =
    IntegerToType< ResolutionTypeTraits<T>::_bInteger >();
  const bool bNoMasking = Pixel::IsFullMask(iChannelMask);

  // optimizations
  // --- creates a cached window of 2 lines of width+1 (+ = pixels on the right border)
  const uint32 winLineSize = w+1;
  const uint32 byteWinLineSize = winLineSize * sizeof(Pixel_F);
  boost::scoped_array<Pixel_F> spWindow( new Pixel_F [2*winLineSize] );
  if (NULL == spWindow.get())
    return false;

  // --- inits progress ---
  const float ProgressStep = 1.f / (float)h;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);
  
  // --- declares variables ---
  uint32 x,y;
  Pixel * prSrc, * prDst;
  Pixel_F edge, Gx, Gy;
  Pixel_F * prLine0, * prLine1, * prPixel;
  
  // --- inits variables ---
  prLine0 = spWindow.get();
  prLine1 = prLine0 + winLineSize;

  prSrc = ioImage.GetPixel();
  prDst = prSrc;

  // -1- fill prLine0 line from image's first one ---
  prPixel = prLine0;
  for (x=0; x<w; x++)
    *prPixel++ = *prSrc++;
  *prPixel = prPixel[-1];

  // -2- process all lines ---
  for (y=0; y<h; y++)
  {
    // --- fill last line of window ---
    if (y == h-1)
    {
      ::memcpy(prLine1, prLine0, byteWinLineSize);
    }
    else
    {
      prPixel = prLine1;
      for (x=0; x<w; x++)
        *prPixel++ = *prSrc++;
      *prPixel = prPixel[-1];
    }

    // --- process a line ---
    for (x=0; x<w; ++x, ++prDst)
    {
      //  |P0 P1|   G = sqrt((P0-P1)� + (P1-P2)�)
      //  |P2 P3|
      Gx = prLine0[x+0] - prLine1[x+1];
      Gy = prLine0[x+1] - prLine1[x+0];
      edge = Gx*Gx + Gy*Gy;
      edge.PowSelf(0.5);
      if (bNoMasking)
        elxPixelClamp(edge, *prDst, doClamp);
      else
        elxPixelClamp(edge, *prDst, doClamp, iChannelMask);
    }

    // --- next line ---
    prPixel = prLine0;
    prLine0 = prLine1;
    prLine1 = prPixel;

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // --- progress end ---
  iNotifier.SetProgress(1.0f);

  return true;

} // elxApplyRoberts


//----------------------------------------------------------------------------
//  elxApplyRobertsFast:
//----------------------------------------------------------------------------
//  Gx = |+1  0|   Gy = | 0 +1|   G = |Gx|+|Gy|
//       | 0 -1|        |-1  0|
// 
//  |P0 P1|   G = |P0-P3| + |P1-P2|
//  |P2 P3|
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        uint32 iChannelMask
//        ProgressNotifier iNotifier :
//  Out : 
//----------------------------------------------------------------------------
template <class Pixel>
bool elxApplyRobertsFast(
    ImageImpl<Pixel>& ioImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  
  // we process convolution in Pixel_F::type resolution
  typedef typename Pixel::type T;
  typedef typename Pixel::F_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
  const IntegerToType< ResolutionTypeTraits<T>::_bInteger > doClamp =
    IntegerToType< ResolutionTypeTraits<T>::_bInteger >();
  const bool bNoMasking = Pixel::IsFullMask(iChannelMask);

  // optimizations
  // --- creates a cached window of 2 lines of width+1 (+ = pixels on the right border)
  const uint32 winLineSize = w+1;
  const uint32 byteWinLineSize = winLineSize * sizeof(Pixel_F);
  boost::scoped_array<Pixel_F> spWindow( new Pixel_F [2*winLineSize] );
  if (NULL == spWindow.get())
    return false;

  // --- inits progress ---
  const float ProgressStep = 1.f / (float)h;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);
  
  // --- declares variables ---
  uint32 x,y;
  Pixel * prSrc, * prDst;
  Pixel_F edge, Gx, Gy;
  Pixel_F * prLine0, * prLine1, * prPixel;
  
  // --- inits variables ---
  prLine0 = spWindow.get();
  prLine1 = prLine0 + winLineSize;

  prSrc = ioImage.GetPixel();
  prDst = prSrc;

  // -1- fill prLine0 line from image's first one ---
  prPixel = prLine0;
  for (x=0; x<w; x++)
    *prPixel++ = *prSrc++;
  *prPixel = prPixel[-1];

  // -2- process all lines ---
  for (y=0; y<h; y++)
  {
    // --- fill last line of window ---
    if (y == h-1)
    {
      ::memcpy(prLine1, prLine0, byteWinLineSize);
    }
    else
    {
      prPixel = prLine1;
      for (x=0; x<w; x++)
        *prPixel++ = *prSrc++;
      *prPixel = prPixel[-1];
    }

    // --- process a line ---
    for (x=0; x<w; ++x, ++prDst)
    {
      //  |P0 P1|   G = |P0-P3| + |P1-P2|
      //  |P2 P3|
      Gx = prLine0[x+0] - prLine1[x+1];
      Gy = prLine0[x+1] - prLine1[x+0];
      edge = elxPixelAbs(Gx) + elxPixelAbs(Gy);
      if (bNoMasking)
        elxPixelClamp(edge, *prDst, doClamp);
      else
        elxPixelClamp(edge, *prDst, doClamp, iChannelMask);
    }

    // --- next line ---
    prPixel = prLine0;
    prLine0 = prLine1;
    prLine1 = prPixel;

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // --- progress end ---
  iNotifier.SetProgress(1.0f);

  return true;

} // elxApplyRobertsFast


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageEdgeProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageEdgeProcessingImpl<Pixel>::ApplyRoberts(AbstractImage& ioImage, 
    bool ibFast,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ibFast ?
    elxApplyRobertsFast(image, iChannelMask, iNotifier) :
    elxApplyRoberts(image, iChannelMask, iNotifier);

} // ApplyRoberts

} // namespace Image
} // namespace eLynx


#endif // __EdgeProcessing_Roberts_hpp_
