//============================================================================
//  EdgeProcessing/ImageSegmentation.hpp               Image.Component package
//============================================================================
//
// 
//
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __EdgeProcessing_Segmentation_hpp__
#define __EdgeProcessing_Segmentation_hpp__

#include <vector>
#include <list>
#include <set>
#include <map>

#include <elx/math/Geometry.h>
#include <elx/image/ImageAnalyseImpl.h>
#include <elx/core/CoreTypes.h>

namespace eLynx {
namespace Image {

namespace {

const static int32 POINT_INTERNAL  = (1<<0);
const static int32 POINT_OLD       = (1<<1);
const static int32 POINT_USED      = (1<<2);
const static int32 POINT_NOT_USED  = ~POINT_USED;

//----------------------------------------------------------------------------
//  Iterates over the component and marks non-boundary points
//----------------------------------------------------------------------------
template <int32 Connectivity>
void elxSetFlags(std::map<int32, uint32>& ioQ, uint32 iW);

//----------------------------------------------------------------------------
//  Returns true if Pixel represented by iPointCoord is connected to iComponent
//----------------------------------------------------------------------------
template <int32 Connectivity>
inline
bool elxAreConnected(int32 iPointCoord, std::map<int32,uint32>& iComponent, uint32 iW);
  
//----------------------------------------------------------------------------
//  Returns true if Pixel belongs to the component
//----------------------------------------------------------------------------
inline
bool elxIsAvailable(const std::map<int32, uint32>& iC, int32 iPoint)
{
  std::map<int32, uint32>::const_iterator it = iC.find(iPoint);
  return it != iC.end() && !(it->second & POINT_USED);
}
inline
bool elxIsConstrained(const std::map<int32, uint32>& iC, int32 iPoint)
{
  return iC.find(iPoint) != iC.end();
}
inline
bool elxIsConstrained(const std::set<int32>& iC, int32 iPoint)
{
  return iC.find(iPoint) != iC.end();
}

//----------------------------------------------------------------------------
//  Dilates component ioC constrained by component ioQ
//  oC contains the newly added points which are removed from the ioQ
// component at the same time and placed into the oQ
// Structural element is 1 1 1
//                       1 1 1
//                       1 1 1
// The point is eligible for the dilation only if
//    -- it is boundary points
//    -- does not already belong to a dam
//----------------------------------------------------------------------------
bool elxDilateComponent(
    std::map<int32, uint32>& ioC, 
    std::map<int32, uint32>& ioQ, 
    const std::set<int32>& iDam, 
    int32 iW, 
    uint32 iConnectivity, 
    std::map<int32, uint32>& oC);

//----------------------------------------------------------------------------
//  Find intersection points between two components
//----------------------------------------------------------------------------
inline
void elxFindIntersection(
    const std::map<int32, uint32>& iC1, 
    const std::map<int32, uint32>& iC2, 
    std::set<int32>& oC)
{
  std::map<int32, uint32>::const_iterator it1 = iC1.begin();
  std::map<int32, uint32>::const_iterator it2 = iC2.begin();
  std::map<int32, uint32>::const_iterator itEnd1 = iC1.end();
  std::map<int32, uint32>::const_iterator itEnd2 = iC2.end();
  
  while (it1 != itEnd1 && it2 != itEnd2)
  {
    if (it1->first < it2->first) 
      ++it1;
    else if (it2->first < it1->first) 
      ++it2;
    else 
    { 
      oC.insert(it1->first);
      it1++; 
      it2++; 
    }
  }

} // elxFindIntersection


//----------------------------------------------------------------------------
//  Get Pixel's Luminance
//----------------------------------------------------------------------------
template <typename Pixel>
inline
typename Pixel::type elxGetLuminance(const Pixel& iPixel, uint32 iChannelMask)
{
  return iPixel.GetLuminance();
}

template <typename T>
inline
T elxGetLuminance(const PixelRGB<T>& iPixel, uint32 iChannelMask)
{
  if (iChannelMask == CM_All)
    return iPixel.GetLuminance();
  else if (iChannelMask == CM_Channel0)
    return iPixel._red;
  else if (iChannelMask == CM_Channel1)
    return iPixel._green;
  else if (iChannelMask == CM_Channel2)
    return iPixel._blue;
  else
    return iPixel.GetLuminance();
}
template <typename T>
inline
T elxGetLuminance(const PixelRGBA<T>& iPixel, uint32 iChannelMask)
{
  if (iChannelMask == CM_All)
    return iPixel.GetLuminance();
  else if (iChannelMask == CM_Channel0)
    return iPixel._red;
  else if (iChannelMask == CM_Channel1)
    return iPixel._green;
  else if (iChannelMask == CM_Channel2)
    return iPixel._blue;
  else
    return iPixel.GetLuminance();
}


//----------------------------------------------------------------------------
//  Build Dam between multiple components iC constrained by component ioQ
//  oQ contains the points which originally belong to ioQ and were added
//  to the one of the iC component during the dilation and removed from the 
//  ioQ to prevent them from being added to more then one component. 
//  They will be added back to the ioQ after Dam is built.
//----------------------------------------------------------------------------
void elxBuildDam(std::map<int32, uint32>** iC, size_t iSize, uint32 iConnectivity, 
  std::map<int32, uint32>& ioQ, uint32 iW, std::set<int32>& oDam);

//----------------------------------------------------------------------------
//  Updates set of connected components of pixels which luminance is less
//  then a given threshold
//----------------------------------------------------------------------------
//  In  : iprBegin, iprEnd - iterators to the first/last image pixel 
//        iThresholdNew  new threshold.
//        iThresholdOld  old threshold.
//        iW - image width
//        iChannelMask - channels
//        iConnectivity - pixel's connectivity - 4 or 8
//        ioSet - set of connected components for which luminance < threshold
//----------------------------------------------------------------------------
template <class Pixel, int32 Connectivity>
void elxFloodIncrement(
    const Pixel * iprPixelBegin, 
    const Pixel * iprPixelEnd, 
    uint32 iW, 
    uint32 iChannelMask, 
    typename ResolutionTypeTraits<typename Pixel::type>::SumOverflow_type iThresholdNew, 
    typename ResolutionTypeTraits<typename Pixel::type>::SumOverflow_type iThresholdOld, 
    std::vector<std::map<int32, uint32>* >& ioComponents,
    std::set<int32>& oDam)
{
  typedef typename Pixel::type T;
  typedef std::map<int32, uint32> Component;
  typedef Component::iterator ComponentIterator;
  typedef Component* ComponentPointer;
  typedef std::list<ComponentPointer> ComponentList;
  typedef ComponentList::iterator ComponentListIter;
  typedef std::multimap<ComponentPointer, int32> ComponentMultiMap;
  
  // Container to hold connected components flooded during the iteration
  ComponentList newComponents;
  
  // Map to keep association between new and old components. At the begining
  // it's one-to-one but as flooding progresses some components may connect. At the 
  // end it's one-to-many - one component from newComponents may correspond to 
  // many contain many from ioComponents
  // The key is the pointer to the new component.
  // The values - indexes to input components which are constrained by this
  // new component 
  ComponentMultiMap componentsMap; 
  const size_t componentsCount = ioComponents.size();
  for (size_t i=0; i< componentsCount; ++i)
  {
    Component * comp = new Component;
    ComponentIterator itBegin = ioComponents[i]->begin();
    ComponentIterator itEnd = ioComponents[i]->end();
    for (; itBegin != itEnd; ++itBegin)
      if (!(itBegin->second & POINT_INTERNAL))
        comp->insert(*itBegin);
    newComponents.push_back(comp);
    
    componentsMap.insert( std::make_pair(newComponents.back(), (int32)i)); 
  }
    
  std::vector<ComponentListIter> mergedComponents;    
  for (const Pixel * iprPixel = iprPixelBegin; iprPixel != iprPixelEnd; ++iprPixel)
  {
    T luminance = elxGetLuminance(*iprPixel, iChannelMask);
    if (luminance >= iThresholdNew || luminance < iThresholdOld)
      continue;
      
    mergedComponents.clear();
    size_t pointCoord = iprPixel - iprPixelBegin;

    // see whether pixel is connected to already existing components or not
    ComponentListIter itListEnd = newComponents.end();
    for (ComponentListIter itList = newComponents.begin();
         itList != itListEnd; ++itList)
    {
      // Is point connected to the component?
      if (elxAreConnected<Connectivity>((int32)pointCoord, *(*itList), iW))
      {
        (*itList)->insert( std::make_pair((int32)pointCoord, 0) );
        mergedComponents.push_back(itList);
      }
    } 
    
    size_t count = mergedComponents.size();
    if (count == 0)
    {
      // Add new components
      ComponentPointer component = new Component();
      component->insert( std::make_pair(pointCoord, 0) );
      newComponents.push_back(component);
      componentsMap.insert( std::make_pair(newComponents.back(), -1) ); 
    }
    else if (count > 1)
    {
      // merge connected components into the first one
      for (size_t i=1; i<count; ++i)
      {
        // merge corresponding old components
        std::pair<ComponentMultiMap::iterator, ComponentMultiMap::iterator> 
          itRange = componentsMap.equal_range(*mergedComponents[i]);
        
        while (itRange.first != itRange.second)
        {
          if (itRange.first->second != -1)
           componentsMap.insert(std::make_pair(*mergedComponents[0],
              itRange.first->second));
          ++itRange.first;
        }
        componentsMap.erase(*mergedComponents[i]);
        
        // merge new components
        (*mergedComponents[0])->insert( 
          (*mergedComponents[i])->begin(), (*mergedComponents[i])->end());

        // erase form newComponents
        newComponents.erase(mergedComponents[i]); 
      }   
    }
  }
  
  // for each comp in newComponents call elxBuildDam  
  ComponentListIter itListEnd = newComponents.end();
  std::vector<ComponentPointer> prevComponents;
  
  for (ComponentListIter itList = newComponents.begin();
       itList != itListEnd; ++itList)
  {
    prevComponents.clear();
    
    std::pair<ComponentMultiMap::iterator, ComponentMultiMap::iterator> 
      itRange = componentsMap.equal_range(*itList);
      
    for (ComponentMultiMap::iterator it = itRange.first; it != itRange.second; 
        ++it)
      if (it->second != -1)
        prevComponents.push_back(ioComponents[it->second]);

    if (!prevComponents.empty())
      elxBuildDam(&prevComponents[0], prevComponents.size(), Connectivity,
        *(*itList), iW, oDam);
 
    elxSetFlags<Connectivity>(*(*itList), iW);    
 }
  
  // need to populate ioComponents back 
  for (size_t i=0; i<ioComponents.size(); ++i)
  {
    ComponentPointer pc = ioComponents[i];
    ioComponents[i] = NULL;
    delete pc;
  }

  ioComponents.clear();
  ioComponents.insert(ioComponents.begin(),
    newComponents.begin(), newComponents.end());

} // elxFloodIncrement

} // namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Image Segmentation by morphological watersheds.
//----------------------------------------------------------------------------
//  public virtual from ImageEdgeProcessingImpl
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        iStep flood increment.
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageEdgeProcessingImpl<Pixel>::SegmentImage(
    ImageImpl<Pixel>& ioImage,
    double iStep, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::SumOverflow_type SumOverflow_type;
  const T increment = T(iStep);
  
  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  Pixel * prBegin = ioImage.GetPixel();
  Pixel * prEnd = ioImage.GetPixelEnd();
  
  // Get pixel's min max values
  T min, max;
  bool result = ImageAnalyseImpl<Pixel>::ComputeMinMax(ioImage, min, max);
  if (!result)
    return result;
  
  SumOverflow_type prevT = min, newT = min + increment;
  
  // --- inits progress ---
  const float ProgressStep = float(increment)/float(max - min);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);
  
  // Collection of the connected components
  std::vector<std::map<int32, uint32>* > components;

  // Collection of segmentation points 
  std::set<int32> dam;
  while (newT <= max + increment)
  {
    elxFloodIncrement<Pixel, 4>(
      prBegin, prEnd, w, iChannelMask, newT, prevT, components, dam); 
    prevT = newT;
    newT += increment;

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
  
  boost::shared_ptr<ImageImpl<Pixel> > segment(new ImageImpl<Pixel>(w, h));
  std::set<int32>::iterator pointIt = dam.begin();
  std::set<int32>::iterator endIt = dam.end();
  for(; pointIt != endIt; ++pointIt)
    *segment->GetPixel(*pointIt % w, *pointIt / w) = Pixel::White();
    
  // Done
  iNotifier.SetProgress(1.0f);
  
  ioImage.CopyAndForget(segment);
  
  return true;

} // SegmentImage

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageEdgeProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  SegmentImage
//----------------------------------------------------------------------------
//  public virtual from ImageEdgeProcessingImpl
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        iThresholdLo low threshold.
//        iThresholdHi high threshold.
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::SegmentImage(AbstractImage& ioImage,
    double iStep, uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ImageEdgeProcessingImpl<Pixel>::SegmentImage(
    image, iStep, iChannelMask, iNotifier);

} // SegmentImage


} // namespace Image
} // namespace eLynx

#endif // __EdgeProcessing_Segmentation_hpp__
