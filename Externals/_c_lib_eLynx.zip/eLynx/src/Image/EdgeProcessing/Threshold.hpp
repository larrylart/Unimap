//============================================================================
//  EdgeProcessing/Threshold.hpp                       Image.Component package
//============================================================================
//
//  http://homepages.inf.ed.ac.uk/rbf/HIPR2/threshld.htm#1
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __EdgeProcessing_Threshold_hpp__
#define __EdgeProcessing_Threshold_hpp__

#include <elx/image/ImageAnalyseImpl.h>

namespace eLynx {
namespace Image {


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>


//----------------------------------------------------------------------------
//  Edge enhancement by thresholding edges.
//----------------------------------------------------------------------------
//  public virtual from ImageEdgeProcessingImpl
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        iThresholdLo low threshold.
//        iThresholdHi  high threshold.
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::ApplyThreshold(
    ImageImpl<Pixel>& ioImage,
    double iThresholdLo, 
    double iThresholdHi,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;

  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  if (h<3 || w<3) return false;

  const bool bNoMasking = Pixel::IsFullMask(iChannelMask);
  
  double tmin = (iThresholdLo < iThresholdHi) ? iThresholdLo : iThresholdHi;
  if (tmin > 1.0) tmin = 1.0;

  double tmax = (iThresholdLo < iThresholdHi) ? iThresholdHi : iThresholdLo;
  if (tmax > 1.0) tmax = 1.0;
    
  // --- inits progress ---
  const float ProgressStep = 1.f / (float)h;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // --- declares variables ---
  uint32 x,y;
  Pixel * prPixel = ioImage.GetPixel();

  // process all lines forward---
  if (bNoMasking)
  {
    const Pixel pixelBlack = Pixel::Black();

    // Compute min/max Pixel. 
    double absMaxLuminance;
    if (!ImageAnalyseImpl<Pixel>::ComputeMaxLuminance(ioImage, absMaxLuminance, false))
      return false;

    F maxLuminance = F(double(absMaxLuminance)*tmin);
    F minLuminance = F(double(absMaxLuminance)*tmax);
    
    // speed up if no channel mask used
    for (y=0; y<h; y++)
    {
      // --- process a line ---
      for (x=0; x<w; ++x, ++prPixel)
      {
        F l = Pixel_F(*prPixel).GetLuminance();
        if (l < minLuminance)
          *prPixel = pixelBlack;
        else if (l < maxLuminance)
        {
          if (x>0 && y>0 && Pixel_F(*(prPixel-w-1)).GetLuminance() > maxLuminance)
            *prPixel = *(prPixel-w-1);
          else if (y>0 && Pixel_F(*(prPixel-w)).GetLuminance() > maxLuminance)
            *prPixel = *(prPixel-w);
          else if (x<w-1 && y>0 && 
                   Pixel_F(*(prPixel-w+1)).GetLuminance() > maxLuminance)
            *prPixel = *(prPixel-w+1);
          else if (x>0 && Pixel_F(*(prPixel-1)).GetLuminance() > maxLuminance)
            *prPixel = *(prPixel-1);
          else if (x<w-1 && Pixel_F(*(prPixel+1)).GetLuminance() > maxLuminance)
            *prPixel = *(prPixel+1);
          else if (x>0 && y<h-1 && 
                   Pixel_F(*(prPixel+w-1)).GetLuminance() > maxLuminance)
            *prPixel = *(prPixel+w-1);
          else if (y<h-1 && Pixel_F(*(prPixel+w)).GetLuminance() > maxLuminance)
            *prPixel = *(prPixel+w);
          else if (x<w-1 && y<h-1 && 
                   Pixel_F(*(prPixel+w+1)).GetLuminance() > maxLuminance)
            *prPixel = *(prPixel+w+1);
          else
            *prPixel = pixelBlack;
        }
      }
      // --- in progress ... ---
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }
  }
  else
  {
    double absMax[PC_MAX]; 
    if (!ImageAnalyseImpl<Pixel>::ComputeMax(ioImage, absMax, false))
      return false;

    T minLuminance[PC_MAX], maxLuminance[PC_MAX];
    const uint32 channelCount = Pixel::GetChannelCount();
    for (uint32 c = 0; c < channelCount; ++c)
    {
      minLuminance[c] = T(absMax[c]*tmin); 
      maxLuminance[c] = T(absMax[c]*tmax); 
    }

    for (y=0; y<h; y++)
    {
      for (x=0; x<w; ++x, ++prPixel)
      {
        for (uint32 c = 0; c < channelCount; ++c)
          if (elxUseChannel(c, iChannelMask))
          {
            if ( prPixel->_channel[c] < minLuminance[c])
              prPixel->_channel[c] = SampleTypeTraits<T>::_black;
            else
            {
              if (x>0 && y>0 && (prPixel-w-1)->_channel[c] > maxLuminance[c])
                prPixel->_channel[c] = (prPixel-w-1)->_channel[c];
              else if (y>0 && (prPixel-w)->_channel[c] > maxLuminance[c])
                prPixel->_channel[c] = (prPixel-w)->_channel[c];
              else if (x<w-1 && y>0 && (prPixel-w+1)->_channel[c] > maxLuminance[c])
                prPixel->_channel[c] = (prPixel-w+1)->_channel[c];
              else if (x>0 && (prPixel-1)->_channel[c] > maxLuminance[c])
                prPixel->_channel[c] = (prPixel-1)->_channel[c];
              else if (x<w-1 && (prPixel+1)->_channel[c] > maxLuminance[c])
                prPixel->_channel[c] = (prPixel+1)->_channel[c];
              else if (x>0 && y<h-1 && (prPixel+w-1)->_channel[c] > maxLuminance[c])
                prPixel->_channel[c] = (prPixel+w-1)->_channel[c];
              else if (y<h-1 && (prPixel+w)->_channel[c] > maxLuminance[c])
                prPixel->_channel[c] = (prPixel+w)->_channel[c];
              else if (x<w-1 && y<h-1 && (prPixel+w+1)->_channel[c] > maxLuminance[c])
                prPixel->_channel[c] = (prPixel+w+1)->_channel[c];
              else
                prPixel->_channel[c] = SampleTypeTraits<T>::_black;
            }
          }
      }

      // --- in progress ... ---
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }
  }

  // --- progress end ---
  iNotifier.SetProgress(1.0f);

  return true;

} // ApplyThreshold # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageEdgeProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplyThreshold # AbstractImage: Edge enhancement by thresholding edges.
//----------------------------------------------------------------------------
//  public virtual from ImageEdgeProcessingImpl
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        iThresholdLo low threshold.
//        iThresholdHi high threshold.
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::ApplyThreshold(
    AbstractImage& ioImage,
    double iThresholdLo, 
    double iThresholdHi,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ImageEdgeProcessingImpl<Pixel>::ApplyThreshold(
    image, iThresholdLo, iThresholdHi, iChannelMask, iNotifier);

} // ApplyThreshold # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __EdgeProcessing_Threshold_hpp__
