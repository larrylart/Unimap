//============================================================================
//  EdgeProcessing/ZeroCrossing.hpp                    Image.Component package
//============================================================================
//
//  http://homepages.inf.ed.ac.uk/rbf/HIPR2/zeros.htm#1
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __EdgeProcessing_ZeroCrossing_hpp__
#define __EdgeProcessing_ZeroCrossing_hpp__

#include <elx/image/ImageMorphologicalProcessingImpl.h>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Zero Crossing Edge detector
//----------------------------------------------------------------------------
//  public virtual from ImageEdgeProcessingImpl
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        double iRadius,
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::ApplyZeroCrossing(
    AbstractImage& ioImage,
    double iRadius,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  typedef  typename Pixel::type T;

  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  
  //--------------------------------------------------------------------------
  // Step 1: filter noise applying Gaussian filter
  //--------------------------------------------------------------------------

  // In order to implement the canny edge detector algorithm, a series of 
  // steps must be followed. The first step is to filter out any noise in the
  // original image before trying to locate and detect any edges. And because
  // the Gaussian filter can be computed using a simple mask, it is used
  // exclusively in the Canny algorithm. Once a suitable mask has been
  // calculated, the Gaussian smoothing can be performed using standard
  // convolution methods. The larger the width of the Gaussian mask, the lower
  // is the detector's sensitivity to noise. The localization error in the
  // detected edges also increases slightly as the Gaussian width is increased.

  // const double variance = Math::elxGetGaussianVariance(iRadius);
  if (!ImageLocalProcessingImpl<Pixel>::ApplyGaussian(
    image, iRadius, BF_Nearest, 1, iChannelMask, iNotifier))
    return false;

  //--------------------------------------------------------------------------
  // Step 2:  perform the laplacian on this blurred image.
  //--------------------------------------------------------------------------

  // Since the edge occurs at the peak of the image gradient, it can be 
  // localized by computing the laplacian (in one dimension, the second 
  // derivative) and finding the zero crossings. To remove false edges, 
  // an extra step is added. When a zero crossing of the laplacian is found, 
  // local variance is computed. Since a true edge corresponds to a significant
  // change in intensity of the original image. If this variance is low, 
  // then this zero crossing must have been caused by ripple and should be 
  // rejected
  const double variance = Math::elxGetGaussianVariance(iRadius);
  Math::ConvolutionKerneld LoG = Math::elxMakeLoG(iRadius, variance);
  
  
  //--------------------------------------------------------------------------
  // Step 3:  apply median filter.
  //--------------------------------------------------------------------------

  // Apply a median filter to removes the spot noise while preserving the edges.
  // This yields a very clean representation of the major edges of the original
  // image
  return ImageMorphologicalProcessingImpl<Pixel>::ApplyMedian3x3(
    image, 1, iChannelMask, iNotifier);
    
} // ApplyZeroCrossing

} // namespace Image
} // namespace eLynx

#endif // __EdgeProcessing_ZeroCrossing_hpp__
