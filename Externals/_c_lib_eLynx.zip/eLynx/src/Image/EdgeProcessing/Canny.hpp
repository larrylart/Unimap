//============================================================================
//  EdgeProcessing/Canny.hpp                           Image.Component package
//============================================================================
//
//  Canny Edge detector
//
//  http://homepages.inf.ed.ac.uk/rbf/HIPR2/canny.htm
//  http://www.pages.drexel.edu/~weg22/can_tut.html
//  http://www.roborealm.com/help/Canny.php
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __EdgeProcessing_Canny_hpp__
#define __EdgeProcessing_Canny_hpp__

namespace eLynx {
namespace Image {

#if 1
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
// ApplyCanny # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::ApplyCanny(
    ImageImpl<Pixel>& ioImage,
    EEdgeDetector iDetector,
    EEdgeGradient iGradient,
    double iRadius,
    double iThresholdLo, 
    double iThresholdHi,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  //--------------------------------------------------------------------------
  // Step 1: filter noise applying Gaussian filter
  //--------------------------------------------------------------------------

  // In order to implement the canny edge detector algorithm, a series of 
  // steps must be followed. The first step is to filter out any noise in the
  // original image before trying to locate and detect any edges. And because
  // the Gaussian filter can be computed using a simple mask, it is used
  // exclusively in the Canny algorithm. Once a suitable mask has been
  // calculated, the Gaussian smoothing can be performed using standard
  // convolution methods. The larger the width of the Gaussian mask, the lower
  // is the detector's sensitivity to noise. The localization error in the
  // detected edges also increases slightly as the Gaussian width is increased.

  // const double variance = Math::elxGetGaussianVariance(iRadius);
  if (!ImageLocalProcessingImpl<Pixel>::ApplyGaussian(
    ioImage, iRadius, BF_Nearest, 1, iChannelMask, iNotifier))
    return false;

  //--------------------------------------------------------------------------
  // Step 2: find the edge strength and direction
  //--------------------------------------------------------------------------

  // Find the edge strength by taking the gradient of the image. The Sobel
  // operator performs a 2-D spatial gradient measurement on an image. Then,
  // the approximate absolute gradient magnitude (edge strength) at each
  // point can be found. The Sobel operator uses a pair of 3x3 convolution
  // masks, one estimating the gradient in the x-direction (columns) and
  // the other estimating the gradient in the y-direction (rows).
  //
  // Finding the edge direction is trivial once the gradient in
  // the x and y directions are known. However, you will generate an error
  // whenever sumX is equal to zero. So in the code there has to be a
  // restriction set whenever this takes place. Whenever the gradient in the
  // x direction is equal to zero, the edge direction has to be  equal to 90
  // degrees or 0 degrees, depending on what the value of  the gradient in
  // the y-direction is equal to. If GY has a value of zero, the edge
  // direction will equal 0 degrees. Otherwise the edge direction will equal
  // 90 degrees. The formula for finding the edge direction is just:
  //
  //             theta = arctan (Gy / Gx) 

  boost::shared_array<float> spOrientation;
  if (!ImageEdgeProcessingImpl<Pixel>::ApplyGradientDirection(
    ioImage, spOrientation, iDetector, iGradient, iChannelMask, iNotifier))
    return false;

  //--------------------------------------------------------------------------
  // Step 3: Perform non-maximal suppression
  //--------------------------------------------------------------------------

  // Once the edge direction is known, the next step is to relate the edge 
  // direction to a direction that can be traced in an image. So if the pixels
  // of a 5x5 image are aligned as follows:
  //
  //      x     x     x     x     x
  //      x     x     x     x     x
  //      x     x     a     x     x
  //      x     x     x     x     x
  //      x     x     x     x     x
  //
  // Then, it can be seen by looking at pixel "a", there are only four 
  // possible directions when describing the surrounding pixels:
  // - 0 degrees (in the horizontal direction), 
  // - 45 degrees (along the positive diagonal), 
  // - 90 degrees (in the vertical direction), 
  // - 135 degrees (along the negative diagonal). 
  //
  // So now the edge orientation has to be resolved into one of these four 
  // directions depending on which direction it is closest to (e.g. if the 
  // orientation angle is found to be 3 degrees, make it zero degrees). 
  // Think of this as taking a semicircle and dividing it into 5 regions.
  // Therefore, any edge direction falling within the range:
  // - [  0.0 ..  22.5] is set to 0 degrees,
  // - [ 22.5 ..  67.5] is set to 45 degrees, 
  // - [ 67.5 .. 112.5] is set to 90 degrees,
  // - [112.5 .. 157.5] is set to 135 degrees, 
  // - [157.5 .. 180.0] is set to 0 degrees. 
  //
  // After the edge directions are known, nonmaximum suppression now has to be
  // applied. It's used to trace along/ the edge in the edge direction and 
  // suppress any pixel value (sets it equal to 0) that is not considered to 
  // be an edge. This will give a thin line in the output image.
  if (!ApplyNonMaxSuppression(ioImage, spOrientation.get(), iChannelMask, iNotifier))
    return false;
    
  // --4-- Threshold edges to eliminate `insignificant' edges.
  return ApplyThreshold(ioImage, iThresholdLo, iThresholdHi, iChannelMask, iNotifier);

} // ApplyCanny # ImageImpl<Pixel>

#else


#endif

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageEdgeProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplyCanny # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::ApplyCanny(
    AbstractImage& ioImage,
    EEdgeDetector iDetector,
    EEdgeGradient iGradient,
    double iRadius,
    double iThresholdLo, 
    double iThresholdHi,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ApplyCanny(image, iDetector, iGradient, 
    iRadius, iThresholdLo, iThresholdHi, iChannelMask, iNotifier);

} // ApplyCanny # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __EdgeProcessing_Canny_hpp__
