//============================================================================
//  EdgeProcessing/Gradient.hpp                        Image.Component package
//============================================================================
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __EdgeProcessing_Gradient_hpp__
#define __EdgeProcessing_Gradient_hpp__

#include "../LocalProcessing/ProcessorEngine3x3.hpp"

namespace eLynx {
namespace Image {

namespace {

enum EGradientDoSpecialization { 
  GDS_Fast,
  GDS_Accurate,
  GDS_Max2,
  GDS_Max4
};

//----------------------------------------------------------------------------
//  elxGetGradientDoSpecialization 
//----------------------------------------------------------------------------
template <typename Pixel>
EGradientDoSpecialization elxGetGradientDoSpecialization(EEdgeGradient iGradient)
{
  switch(iGradient)
  {
    case EG_Max4:             return GDS_Max4;
    case EG_Max2:
    case EG_Max2Diagonal:     return GDS_Max2;

    case EG_Accurate:
    case EG_AccurateDiagonal: return GDS_Accurate;

    case EG_Fast:
    case EG_FastDiagonal:     
    default:                  return GDS_Fast;
  }

} // elxGetGradientDoSpecialization


//----------------------------------------------------------------------------
//  elxCalculateEdgeOrientation full mask
//----------------------------------------------------------------------------
template <typename Pixel>
inline 
void elxCalculateEdgeOrientationNoMask(
    const Pixel& iGx, 
    const Pixel& iGy, 
    uint32 iChannelMask, 
    float * oprOrientation, 
    uint32& ioIdx)
{
  const float lx = float(iGx.GetLuminance());
  const float ly = float(iGy.GetLuminance());
  if (lx == SampleTypeTraits<float>::_black)
    oprOrientation[ioIdx] = (ly == SampleTypeTraits<float>::_black) ? 
      SampleTypeTraits<float>::_black : (float)M_PIo2;
  else
    oprOrientation[ioIdx] = Math::elxArctan(ly/lx);

  ++ioIdx;

} // elxCalculateEdgeOrientationNoMask
 

//----------------------------------------------------------------------------
//  elxCalculateEdgeOrientation mask
//----------------------------------------------------------------------------
template <typename Pixel>
inline 
void elxCalculateEdgeOrientationMask(
    const Pixel& iGx, 
    const Pixel& iGy, 
    uint32 iChannelMask, 
    float * oprOrientation, 
    uint32& ioIdx)
{
  typedef typename Pixel::type T;
  const uint32 channelCount = Pixel::GetChannelCount();
  for (uint32 c = 0; c < channelCount; ++c)
    if (elxUseChannel(c, iChannelMask))
    {
      if (iGx._channel[c] == SampleTypeTraits<T>::_black)
        oprOrientation[ioIdx + c] = 
          (iGy._channel[c] == SampleTypeTraits<T>::_black) ? 
            float(SampleTypeTraits<T>::_black) : (float)M_PIo2;
      else
        oprOrientation[ioIdx + c] = 
          Math::elxArctan(float(iGy._channel[c])/float(iGx._channel[c]));
    }

  ioIdx += channelCount; 

} // elxCalculateEdgeOrientationMask 


//----------------------------------------------------------------------------
//  GradientProcessor3x3: 
//----------------------------------------------------------------------------
template <typename Pixel, EGradientDoSpecialization Specialization>
class GradientProcessor3x3
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;

public:
  GradientProcessor3x3(
      EEdgeDetector iDetector,
      EEdgeGradient iGradient,
      uint32 iChannelMask=CM_All,
      uint32 iWidth = 0,
      float * oprOrientation = NULL) :
    _width(iWidth),
    _ChannelMask(iChannelMask),
    _IsFullMask(Pixel::IsFullMask(iChannelMask)),
    _doClamp(),
    _Specialization(),
    _prOrientation(oprOrientation),
    _OrientationIdx(0)
  {
    // init filters
    Math::ConvolutionKerneld kernel;
    uint32 i;
    switch(iGradient)
    {
      case EG_Fast:      // G = |Gx| + |Gy|
      case EG_Accurate:  // G = sqrt(Gx� + Gy�)
        kernel = elxGetKernel(iDetector, Math::CD_North);
        for (i=0; i<9; i++) _kH[i] = (F)kernel._spK[i];

        kernel = elxGetKernel(iDetector, Math::CD_East);
        for (i=0; i<9; i++) _kV[i] = (F)kernel._spK[i];
        break;

      case EG_FastDiagonal:     // G = |Gxy| + |Gyx|
      case EG_AccurateDiagonal: // G = sqrt(Gxy� + Gyx�)
        kernel = elxGetKernel(iDetector, Math::CD_NorthWest);
        for (i=0; i<9; i++) _kH[i] = (F)kernel._spK[i];

        kernel = elxGetKernel(iDetector, Math::CD_SouthWest);
        for (i=0; i<9; i++) _kV[i] = (F)kernel._spK[i];
        break;

      case EG_Max2:  // G = max(|Gx|, |Gy|)
        kernel = elxGetKernel(iDetector, Math::CD_North);
        for (i=0; i<9; i++) _kH[i] = (F)kernel._spK[i];

        kernel = elxGetKernel(iDetector, Math::CD_East);
        for (i=0; i<9; i++) _kV[i] = (F)kernel._spK[i];
        break;
        
      case EG_Max2Diagonal:  // G = max(|Gx|, |Gy|)
        kernel = elxGetKernel(iDetector, Math::CD_NorthWest);
        for (i=0; i<9; i++) _kH[i] = (F)kernel._spK[i];

        kernel = elxGetKernel(iDetector, Math::CD_SouthWest);
        for (i=0; i<9; i++) _kV[i] = (F)kernel._spK[i];
        break;
        
      case EG_Max4:  // G = max(|Gx|, |Gy|, |Gxy|, |Gyx|)
        kernel = elxGetKernel(iDetector, Math::CD_North);
        for (i=0; i<9; i++) _kH[i] = (F)kernel._spK[i];

        kernel = elxGetKernel(iDetector, Math::CD_East);
        for (i=0; i<9; i++) _kV[i] = (F)kernel._spK[i];

        kernel = elxGetKernel(iDetector, Math::CD_NorthWest);
        for (i=0; i<9; i++) _kD1[i] = (F)kernel._spK[i];

        kernel = elxGetKernel(iDetector, Math::CD_SouthWest);
        for (i=0; i<9; i++) _kD2[i] = (F)kernel._spK[i];

      default: break;
    }
  }
  
  // The oppotunity to adjust to the iteration range
  // this processor is going to operate on. 
  void SetRange(const IterationRange& iRange)
  {
    _OrientationIdx += (uint32)(_IsFullMask ?
      iRange.GetBegin()*_width : 
      iRange.GetBegin()*_width*Pixel::GetChannelCount());
  }

  // Do generic, inlined using optimization
  void Do(const Pixel_F * const * iprLines, uint32 iX, Pixel * oprDst) const
  { Do(iprLines, iX, oprDst, _Specialization); }

private:
  //--------------------------------------------------------------------------
  // Do # Fast
  //--------------------------------------------------------------------------
  void Do(const Pixel_F * const * iprL, uint32 iX, 
          Pixel * oprDst, const IntToType<GDS_Fast>&) const
  {
    Pixel_F Gx = 
      iprL[0][0+iX]*_kH[0] + iprL[0][1+iX]*_kH[1] + iprL[0][2+iX]*_kH[2] + 
      iprL[1][0+iX]*_kH[3] + iprL[1][1+iX]*_kH[4] + iprL[1][2+iX]*_kH[5] +
      iprL[2][0+iX]*_kH[6] + iprL[2][1+iX]*_kH[7] + iprL[2][2+iX]*_kH[8];
    Gx = elxPixelAbs(Gx);

    Pixel_F Gy = 
      iprL[0][0+iX]*_kV[0] + iprL[0][1+iX]*_kV[1] + iprL[0][2+iX]*_kV[2] + 
      iprL[1][0+iX]*_kV[3] + iprL[1][1+iX]*_kV[4] + iprL[1][2+iX]*_kV[5] +
      iprL[2][0+iX]*_kV[6] + iprL[2][1+iX]*_kV[7] + iprL[2][2+iX]*_kV[8];
    Gy = elxPixelAbs(Gy);

    Pixel_F g = Gx + Gy;
    elxPixelClamp(g, *oprDst, _doClamp);
    
    if (_prOrientation)
      (_IsFullMask) ?
        elxCalculateEdgeOrientationNoMask(
          Gx, Gy, _ChannelMask, _prOrientation, _OrientationIdx) :
        elxCalculateEdgeOrientationMask(
          Gx, Gy, _ChannelMask, _prOrientation, _OrientationIdx);
  }

  //--------------------------------------------------------------------------
  // Do # Accurate
  //--------------------------------------------------------------------------
  void Do(const Pixel_F * const * iprL, uint32 iX, 
          Pixel * oprDst, const IntToType<GDS_Accurate>&) const
  {
    Pixel_F Gx = 
      iprL[0][0+iX]*_kH[0] + iprL[0][1+iX]*_kH[1] + iprL[0][2+iX]*_kH[2] + 
      iprL[1][0+iX]*_kH[3] + iprL[1][1+iX]*_kH[4] + iprL[1][2+iX]*_kH[5] +
      iprL[2][0+iX]*_kH[6] + iprL[2][1+iX]*_kH[7] + iprL[2][2+iX]*_kH[8];

    Pixel_F Gy = 
      iprL[0][0+iX]*_kV[0] + iprL[0][1+iX]*_kV[1] + iprL[0][2+iX]*_kV[2] + 
      iprL[1][0+iX]*_kV[3] + iprL[1][1+iX]*_kV[4] + iprL[1][2+iX]*_kV[5] +
      iprL[2][0+iX]*_kV[6] + iprL[2][1+iX]*_kV[7] + iprL[2][2+iX]*_kV[8];

    Pixel_F g = Gx*Gx + Gy*Gy;
    g = elxPixelSqrt(g);
    elxPixelClamp(g, *oprDst, _doClamp);
    
    if (_prOrientation)
      (_IsFullMask) ?
        elxCalculateEdgeOrientationNoMask(
          Gx, Gy, _ChannelMask, _prOrientation, _OrientationIdx) :
        elxCalculateEdgeOrientationMask(
          Gx, Gy, _ChannelMask, _prOrientation, _OrientationIdx);
  }

  //--------------------------------------------------------------------------
  // Do # Max 2
  //--------------------------------------------------------------------------
  void Do(const Pixel_F * const * iprL, uint32 iX, 
          Pixel * oprDst, const IntToType<GDS_Max2>&) const
  {
    Pixel_F Gx = 
      iprL[0][0+iX]*_kH[0] + iprL[0][1+iX]*_kH[1] + iprL[0][2+iX]*_kH[2] + 
      iprL[1][0+iX]*_kH[3] + iprL[1][1+iX]*_kH[4] + iprL[1][2+iX]*_kH[5] +
      iprL[2][0+iX]*_kH[6] + iprL[2][1+iX]*_kH[7] + iprL[2][2+iX]*_kH[8];

    Pixel_F Gy = 
      iprL[0][0+iX]*_kV[0] + iprL[0][1+iX]*_kV[1] + iprL[0][2+iX]*_kV[2] + 
      iprL[1][0+iX]*_kV[3] + iprL[1][1+iX]*_kV[4] + iprL[1][2+iX]*_kV[5] +
      iprL[2][0+iX]*_kV[6] + iprL[2][1+iX]*_kV[7] + iprL[2][2+iX]*_kV[8];

    Pixel_F g = elxPixelMax(Gx,Gy);
    elxPixelClamp(g, *oprDst, _doClamp);
    
    if (_prOrientation)
      (_IsFullMask) ?
        elxCalculateEdgeOrientationNoMask(
          Gx, Gy, _ChannelMask, _prOrientation, _OrientationIdx) :
        elxCalculateEdgeOrientationMask(
          Gx, Gy, _ChannelMask, _prOrientation, _OrientationIdx);
  }

  //--------------------------------------------------------------------------
  // Do # Max 4
  //--------------------------------------------------------------------------
  void Do(const Pixel_F * const * iprL, uint32 iX, 
          Pixel * oprDst, const IntToType<GDS_Max4>&) const
  {
    Pixel_F Gx = 
      iprL[0][0+iX]*_kH[0] + iprL[0][1+iX]*_kH[1] + iprL[0][2+iX]*_kH[2] + 
      iprL[1][0+iX]*_kH[3] + iprL[1][1+iX]*_kH[4] + iprL[1][2+iX]*_kH[5] +
      iprL[2][0+iX]*_kH[6] + iprL[2][1+iX]*_kH[7] + iprL[2][2+iX]*_kH[8];

    Pixel_F Gy = 
      iprL[0][0+iX]*_kV[0] + iprL[0][1+iX]*_kV[1] + iprL[0][2+iX]*_kV[2] + 
      iprL[1][0+iX]*_kV[3] + iprL[1][1+iX]*_kV[4] + iprL[1][2+iX]*_kV[5] +
      iprL[2][0+iX]*_kV[6] + iprL[2][1+iX]*_kV[7] + iprL[2][2+iX]*_kV[8];

    Pixel_F Gxy = 
      iprL[0][0+iX]*_kD1[0] + iprL[0][1+iX]*_kD1[1] + iprL[0][2+iX]*_kD1[2] + 
      iprL[1][0+iX]*_kD1[3] + iprL[1][1+iX]*_kD1[4] + iprL[1][2+iX]*_kD1[5] +
      iprL[2][0+iX]*_kD1[6] + iprL[2][1+iX]*_kD1[7] + iprL[2][2+iX]*_kD1[8];

    Pixel_F Gyx = 
      iprL[0][0+iX]*_kD2[0] + iprL[0][1+iX]*_kD2[1] + iprL[0][2+iX]*_kD2[2] + 
      iprL[1][0+iX]*_kD2[3] + iprL[1][1+iX]*_kD2[4] + iprL[1][2+iX]*_kD2[5] +
      iprL[2][0+iX]*_kD2[6] + iprL[2][1+iX]*_kD2[7] + iprL[2][2+iX]*_kD2[8];

    Gx = elxPixelMax(Gx,Gy);
    Gy = elxPixelMax(Gxy,Gyx);
    Pixel_F g = elxPixelMax(Gx,Gy);

    elxPixelClamp(g, *oprDst, _doClamp);
    
    if (_prOrientation)
      (_IsFullMask) ?
        elxCalculateEdgeOrientationNoMask(
          Gx, Gy, _ChannelMask, _prOrientation, _OrientationIdx) :
        elxCalculateEdgeOrientationMask(
          Gx, Gy, _ChannelMask, _prOrientation, _OrientationIdx);
  }
    
private:
  const uint32 _width;
  const uint32 _ChannelMask;
  const bool _IsFullMask;
  const IntegerToType< ResolutionTypeTraits<T>::_bInteger > _doClamp;
  const IntToType<Specialization> _Specialization;
  mutable float * _prOrientation;
  mutable uint32 _OrientationIdx;
  F _kV[9],_kH[9],_kD1[9],_kD2[9];
};

} // anonymous-namespace


//----------------------------------------------------------------------------
//  ApplyGradient # ImageImpl<Pixel>
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        EEdgeDetector iDetector,
//        EEdgeGradient iGradient,
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::ApplyGradient(
    ImageImpl<Pixel>& ioImage,
    EEdgeDetector iDetector,
    EEdgeGradient iGradient,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;

  switch (iGradient)
  {
    case EG_North:      case EG_South:
    case EG_East:       case EG_West: 
    case EG_NorthEast:  case EG_NorthWest:
    case EG_SouthEast:  case EG_SouthWest:
    {
      // apply convolution filter
      Math::ConvolutionKerneld kernel = elxGetKernel(iDetector, iGradient);
      return ImageLocalProcessingImpl<Pixel>::Convolve(
        ioImage, kernel, 0.0, 1.0, false, BF_Nearest, 1, iChannelMask, iNotifier);
    }

    case EG_Vertical:     case EG_Horizontal:
    case EG_DiagonalNWSE: case EG_DiagonalSWNE:
    {
      // apply ABS convolution filter
      Math::ConvolutionKerneld kernel = elxGetKernel(iDetector, iGradient);
      return ImageLocalProcessingImpl<Pixel>::Convolve(
        ioImage, kernel, 0.0, 1.0, true /*absolute*/, BF_Nearest, 1, iChannelMask, iNotifier);
    }
    default: break;
  }

  // apply more complex gradients
  const EGradientDoSpecialization specialization = 
    elxGetGradientDoSpecialization<Pixel>(iGradient);

  bool isFullMask = Pixel::IsFullMask(iChannelMask);
  switch (specialization)
  {
    case GDS_Max4:
    {
      GradientProcessor3x3<Pixel, GDS_Max4> 
        processor(iDetector, iGradient, iChannelMask, isFullMask);
      return elxProcessLocalToPoint3x3<Pixel, typename Pixel::FloatingPixel>
        (ioImage, processor, BF_Nearest, 1, iNotifier);
    }
    case GDS_Max2:
    {
      GradientProcessor3x3<Pixel, GDS_Max2> 
        processor(iDetector, iGradient, iChannelMask, isFullMask);
      return elxProcessLocalToPoint3x3<Pixel, typename Pixel::FloatingPixel>
        (ioImage, processor, BF_Nearest, 1, iNotifier);
    }
    case GDS_Accurate: 
    {
      GradientProcessor3x3<Pixel, GDS_Accurate> 
        processor(iDetector, iGradient, iChannelMask, isFullMask);
      return elxProcessLocalToPoint3x3<Pixel, typename Pixel::FloatingPixel>
        (ioImage, processor, BF_Nearest, 1, iNotifier);
    }
    case GDS_Fast:
    {
      GradientProcessor3x3<Pixel, GDS_Fast> 
        processor(iDetector, iGradient, iChannelMask, isFullMask);
      return elxProcessLocalToPoint3x3<Pixel, typename Pixel::FloatingPixel>
        (ioImage, processor, BF_Nearest, 1, iNotifier);
    }
    default:
      return false;
  }

  return false;

} // ApplyGradient # ImageImpl<Pixel>


//----------------------------------------------------------------------------
//  ApplyGradientDirection:
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        EEdgeDetector iDetector,
//        EEdgeGradient iGradient,
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : shared_array<float>& ospOrientation Each array element 
//        represents the edge direction (in radian) per channel or per pixel 
//        (in case of full mask) for every pixel from the ioImage image 
//        bool status 
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::ApplyGradientDirection(
    ImageImpl<Pixel>& ioImage,
    boost::shared_array<float>& ospOrientation,
    EEdgeDetector iDetector,
    EEdgeGradient iGradient,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  bool isFullMask = Pixel::IsFullMask(iChannelMask);

  // adjust orientation array size
  if (isFullMask)
    ospOrientation.reset(new float[w*h]);
  else
    ospOrientation.reset(new float[w*h*Pixel::GetChannelCount()]);
  if (NULL == ospOrientation.get()) 
    return false;
      
  // apply complex gradients
  const EGradientDoSpecialization specialization = 
    elxGetGradientDoSpecialization<Pixel>(iGradient);

  switch (specialization)
  {
    case GDS_Max4:
    {
      GradientProcessor3x3<Pixel, GDS_Max4> processor(
        iDetector, iGradient, iChannelMask, w, ospOrientation.get());
      return elxProcessLocalToPoint3x3<Pixel, typename Pixel::FloatingPixel>
        (ioImage, processor, BF_Nearest, 1, iNotifier);
    }
    case GDS_Max2:
    {
      GradientProcessor3x3<Pixel, GDS_Max2> processor(
        iDetector, iGradient, iChannelMask, w, ospOrientation.get());
      return elxProcessLocalToPoint3x3<Pixel, typename Pixel::FloatingPixel>
        (ioImage, processor, BF_Nearest, 1, iNotifier);
    }
    case GDS_Accurate: 
    {
      GradientProcessor3x3<Pixel, GDS_Accurate> processor(
        iDetector, iGradient, iChannelMask, w, ospOrientation.get());
      return elxProcessLocalToPoint3x3<Pixel, typename Pixel::FloatingPixel>
        (ioImage, processor, BF_Nearest, 1, iNotifier);
    }
    case GDS_Fast:
    {
      GradientProcessor3x3<Pixel, GDS_Fast> processor(
        iDetector, iGradient, iChannelMask, w, ospOrientation.get());
      return elxProcessLocalToPoint3x3<Pixel, typename Pixel::FloatingPixel>
        (ioImage, processor, BF_Nearest, 1, iNotifier);
    }
    default:
      return false;
  }

  return false;

} // ApplyGradientDirection


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//              virtual from IImageEdgeProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplyGradient # AbstractImage : Edge detection using oriented compass filter
//----------------------------------------------------------------------------
//  public virtual from ImageEdgeProcessingImpl
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        EEdgeDetectorType iDetectorType,
//        EEdgeGradient iGradient
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::ApplyGradient(
    AbstractImage& ioImage,
    EEdgeDetector iDetector,
    EEdgeGradient iGradient,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ImageEdgeProcessingImpl<Pixel>::ApplyGradient(
    image, iDetector, iGradient, iChannelMask, iNotifier);

} // ApplyGradient # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __EdgeProcessing_Gradient_hpp__
