//============================================================================
//  EdgeProcessing/CompassDetector.hpp                 Image.Component package
//============================================================================
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __EdgeProcessing_CompassDetector_hpp__
#define __EdgeProcessing_CompassDetector_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Apply:
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        EEdgeDetectorType iDetectorType,
//        EEdgeDirection iDirection,
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::Apply(
    ImageImpl<Pixel>& ioImage,
    EEdgeDetector iDetector,
    EEdgeDirection iDirection,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  Math::ConvolutionKerneld kernel = elxGetKernel(iDetector, iDirection);
  return ImageLocalProcessingImpl<Pixel>::Convolve(
    ioImage, kernel, 0.0, 1.0, true, BF_Nearest, 1, iChannelMask, iNotifier);

} // Apply


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageEdgeProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Edge detection using oriented compass filter.
//----------------------------------------------------------------------------
//  public virtual from ImageEdgeProcessingImpl
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        EEdgeDetectorType iDetectorType,
//        EEdgeDirection iDirection,
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::Apply(
    AbstractImage& ioImage,
    EEdgeDetector iDetector,
    EEdgeDirection iDirection,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ImageEdgeProcessingImpl<Pixel>::Apply(
    image, iDetector, iDirection, iChannelMask, iNotifier);

} // Apply

} // namespace Image
} // namespace eLynx


#endif // __EdgeProcessing_CompassDetector_hpp__
