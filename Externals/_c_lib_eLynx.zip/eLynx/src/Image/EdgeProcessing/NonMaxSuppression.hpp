//============================================================================
//  EdgeProcessing/NonMaxSuppression.hpp               Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [N] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//
//  Edge enhancement by suppressing non-maxima edges.
//  http://homepages.inf.ed.ac.uk/rbf/HIPR2/canny.htm#5
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __EdgeProcessing_NonMaxSuppression_hpp__
#define __EdgeProcessing_NonMaxSuppression_hpp__

#include "../LocalProcessing/ProcessorEngine3x3.hpp"

namespace eLynx {
namespace Image {

namespace {

//----------------------------------------------------------------------------
//  NonMaximumProcessor3x3: 
//  Each pixel is compared with its two neighbours along the line of the 
//  gradient. If its value is not greater than both of the neighbour 
//  magnitudes along the gradient line then it is set to zero.
//----------------------------------------------------------------------------
template <bool IsFullMask>
struct NonMaximumProcessor3x3
{
public:
  NonMaximumProcessor3x3(
      const float * iprEdgeOrientation, 
      uint32 iWidth, 
      uint32 iChannelMask, 
      uint32 iChannelCount) : 
    _prEdgeOrientation(iprEdgeOrientation),
    _width(iWidth),
    _ChannelMask(iChannelMask),
    _ChannelCount(iChannelCount),
    _OrientationIdx(0),
    _Specialization()
  {}

  // The oppotunity to adjust to the iteration range
  // this processor is going to operate on. 
  void SetRange(const IterationRange& iRange)
  {
    _OrientationIdx += (IsFullMask) ?
      uint32(iRange.GetBegin()*_width) : 
      uint32(iRange.GetBegin()*_width*_ChannelCount);
  }
  
  // Do generic, inlined using optimisation
  template <typename Pixel>
  void Do(const typename Pixel::FloatingPixel * const * iprLines, uint32 iX, Pixel * oprDst) const
  {
    Do(iprLines, iX, oprDst, _Specialization);
  }
  
private:

  //--------------------------------------------------------------------------
  // Do mask
  //--------------------------------------------------------------------------
  template <typename Pixel>
  void Do(const typename Pixel::FloatingPixel * const * iprLines, uint32 iX, Pixel * oprDst,
    const IntToType<false>&) const
  {
    typedef typename Pixel::F_type F;
    typedef typename Pixel::type T;
  
    const uint32 channelMask = _ChannelMask;
    const uint32 channelCount = Pixel::GetChannelCount();
    const static F D_22_5 = F(M_PIo4 / 2);        //  pi/8 radians = 22.5�
    const static F D_67_5 = F(M_PIo2 - D_22_5);   // 3pi/8 radians = 67.5�
    
    for (uint32 c = 0; c < channelCount; ++c)
      if (elxUseChannel(c, channelMask))
      {
        const float orientation = _prEdgeOrientation[_OrientationIdx + c];

        // set pixel value to black if the centre is not greater than 
        // both of the neighbour magnitudes along the gradient line
        F l1 = iprLines[0][0+iX]._channel[c];
        F l2 = iprLines[0][1+iX]._channel[c];
        F l3 = iprLines[0][2+iX]._channel[c];

        F l4 = iprLines[1][0+iX]._channel[c];
        F l  = iprLines[1][1+iX]._channel[c] * 3;
        F l5 = iprLines[1][2+iX]._channel[c];

        F l6 = iprLines[2][0+iX]._channel[c];
        F l7 = iprLines[2][1+iX]._channel[c];
        F l8 = iprLines[2][2+iX]._channel[c];

        //  l1 l2 l3
        //  l4 l  l5
        //  l6 l7 l8
        if (-D_67_5 <= orientation && orientation < -D_22_5)
        {
          // diagonal l6-l3
          if (l <= l2 + l3 + l5 || 
              l <= l4 + l6 + l7)
           oprDst->_channel[c] = SampleTypeTraits<T>::_black; 
        }
        else if (-D_22_5 <= orientation && orientation < D_22_5)
        {
          // vertical
          if (l <= l1 + l4 + l6 || 
              l <= l3 + l5 + l8)
           oprDst->_channel[c] = SampleTypeTraits<T>::_black; 
        }
        else if (D_22_5 <= orientation && orientation < D_67_5)
        {
          // diagonal l1-l8
          if (l <= l4 + l1 + l2 || 
              l <= l7 + l8 + l5)
            oprDst->_channel[c] = SampleTypeTraits<T>::_black;
        }
        else
        {
          // horizontal
          if (l <= l1 + l2 + l3 || 
              l <= l6 + l7 + l8)
           oprDst->_channel[c] = SampleTypeTraits<T>::_black; 
        }
      }
    _OrientationIdx += Pixel::GetChannelCount();  
  }

  //--------------------------------------------------------------------------
  // Do full mask
  //--------------------------------------------------------------------------
  template <typename Pixel>
  void Do(const typename Pixel::FloatingPixel * const * iprLines, uint32 iX, Pixel * oprDst,
    const IntToType<true>&) const
  {
    typedef typename Pixel::type T;
    typedef typename Pixel::FloatingPixel Pixel_F;
    typedef typename ResolutionTypeTraits<T>::Floating_type F;
  
    const static float D_22_5 = float(M_PIo4/2.f);
    const static float D_67_5 = float(M_PIo2 - D_22_5);
    const static Pixel P_BLACK = Pixel::Black();
    
    const float orientation = _prEdgeOrientation[_OrientationIdx];
      
    // set pixel value to black if the centre is not greater than 
    // both of the neighbour magnitudes along the gradient line
    F l1 = iprLines[0][0+iX].GetLuminance();
    F l2 = iprLines[0][1+iX].GetLuminance();
    F l3 = iprLines[0][2+iX].GetLuminance();

    F l4 = iprLines[1][0+iX].GetLuminance();
    F l  = iprLines[1][1+iX].GetLuminance() * 3;
    F l5 = iprLines[1][2+iX].GetLuminance();

    F l6 = iprLines[2][0+iX].GetLuminance();
    F l7 = iprLines[2][1+iX].GetLuminance();
    F l8 = iprLines[2][2+iX].GetLuminance();

    //  l1 l2 l3
    //  l4 l  l5
    //  l6 l7 l8
    if (-D_67_5 <= orientation && orientation < -D_22_5)
    {
      // diagonal l6-l3
      if (l <= l2 + l3 + l5 || 
          l <= l4 + l6 + l7)
        *oprDst = P_BLACK;
    }
    else if (-D_22_5 <= orientation && orientation < D_22_5)
    {
      // vertical
      if (l <= l1 + l4 + l6 || 
          l <= l3 + l5 + l8)
        *oprDst = P_BLACK;
    }
    else if (D_22_5 <= orientation && orientation < D_67_5)
    {
      // diagonal l1-l8
      if (l <= l4 + l1 + l2 || 
          l <= l7 + l8 + l5)
        *oprDst = P_BLACK;
    }
    else
    {
      // horizontal
      if (l <= l1 + l2 + l3 || 
          l <= l6 + l7 + l8)
        *oprDst = P_BLACK;
    }
    ++_OrientationIdx;  
  }
  
private:
  const float * _prEdgeOrientation;
  const uint32 _width;
  const uint32 _ChannelMask, _ChannelCount;
  mutable uint32 _OrientationIdx;
  const IntToType<IsFullMask> _Specialization;
};

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::ApplyNonMaxSuppression(
    ImageImpl<Pixel>& ioImage,
    const float * iprEdgeOrientation,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;

  typedef typename Pixel::FloatingPixel Pixel_F;
  const uint32 nChannel = Pixel::GetChannelCount();
    
  if (Pixel::IsFullMask(iChannelMask))
  {
    NonMaximumProcessor3x3<true> processor(
      iprEdgeOrientation, ioImage.GetWidth(), iChannelMask, nChannel);
    return elxProcessLocalToPoint3x3<Pixel, Pixel_F>
      (ioImage, processor, BF_Black, 1, iNotifier);
  }
  else
  {
    NonMaximumProcessor3x3<false> processor(
      iprEdgeOrientation, ioImage.GetWidth(), iChannelMask, nChannel);
    return elxProcessLocalToPoint3x3<Pixel, Pixel_F>
      (ioImage, processor, BF_Black, 1, iNotifier);
  }

} // ApplyNonMaxSuppression


} // namespace Image
} // namespace eLynx

#endif // __EdgeProcessing_NonMaxSuppression_hpp__
