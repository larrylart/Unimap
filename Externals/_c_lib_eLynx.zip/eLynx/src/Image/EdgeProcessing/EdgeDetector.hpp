/*
//============================================================================
//  EdgeProcessing/EdgeDetector.hpp                    Image.Component package
//============================================================================
//
//  http://www.ph.tn.tudelft.nl/Courses/FIP/noframes/fip-Derivati.html
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __EdgeProcessing_EdgeDetector_hpp__
#define __EdgeProcessing_EdgeDetector_hpp__

#include <elx/math/ConvolutionKernel.h>
#include <elx/math/KernelCollection.h>
#include <elx/image/ImageOperatorsImpl.h>
#include <elx/image/ImageLocalProcessingImpl.h>

namespace eLynx {
namespace Image {


/// @name Pixel get Luminance by Channel (RGB alike only)
/// @{
template <class Pixel>
typename Pixel::type elxPixelLuminance(const Pixel& iPixel, const uint32 iChannelMask); 

template <typename T>
T elxPixelLuminance(const PixelRGB<T>& iPixel, const uint32 iChannelMask); 

template <typename T>
T elxPixelLuminance(const PixelRGBA<T>& iPixel, const uint32 iChannelMask); 
/// @}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                            luminance functions
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
inline
typename  Pixel::type elxPixelLuminance(const Pixel& iPixel, const uint32 iChannelMask)
{
  return iPixel.GetLuminance();
} 

template <typename T>
inline
T elxPixelLuminance(const PixelRGB<T>& iPixel, const uint32 iChannelMask)
{
  const uint32 nChannel = PixelRGB<T>::GetChannelCount();
  T luminance = T();
  uint32 count = 0;
  for (uint32 c=0; c<nChannel; c++)
    if (elxUseChannel(c, iChannelMask))
    {
       luminance += iPixel._channel[c];
       ++count;
    }
  return T(luminance/count);
} 

template <typename T>
inline
T elxPixelLuminance(const PixelRGBA<T>& iPixel, const uint32 iChannelMask)
{
  const uint32 nChannel = PixelRGBA<T>::GetChannelCount() -1;
  T luminance = T();
  uint32 count = 0;
  for (uint32 c=0; c<nChannel; c++)
    if (elxUseChannel(c, iChannelMask))
    {
       luminance += iPixel._channel[c];
       ++count;
    }
  return T(luminance/count);
} 


//----------------------------------------------------------------------------
//  Apply:
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        EEdgeDetectorType iDetectorType,
//        EEdgeDirection iDirection,
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::Apply(
    ImageImpl<Pixel>& ioImage,
    EEdgeDetector iDetector,
    EEdgeDirection iDirection,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  Math::ConvolutionKerneld kernel = elxGetKernel(iDetector, iDirection);
  return ImageLocalProcessingImpl<Pixel>::Convolve(
    ioImage, kernel, 0.0, 1.0, true, BF_Nearest, 1, iChannelMask, iNotifier);

} // Apply


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageEdgeProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Edge detection using oriented compass filter.
//----------------------------------------------------------------------------
//  public virtual from ImageEdgeProcessingImpl
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        EEdgeDetectorType iDetectorType,
//        ECompassDirection iDirection,
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::Apply(
    AbstractImage& ioImage,
    EEdgeDetector iDetector,
    EEdgeDirection iDirection,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ImageEdgeProcessingImpl<Pixel>::Apply(
    image, iDetector, iDirection, iChannelMask, iNotifier);

} // Apply


/*
namespace {

//----------------------------------------------------------------------------
//  EdgeProcessor: Applies kernel for each direction and compute the gradient.  
//----------------------------------------------------------------------------
template <typename Pixel, typename Pixel_F>
struct EdgeProcessor
{
  EdgeProcessor(
      const Math::ConvolutionKerneld& iKernelX,
      const Math::ConvolutionKerneld& iKernelY,
      OrientationtMap *  ipOrientationtMap) : 
   _pOrientationtMap(ipOrientationtMap), 
   _doClamp()
  {
    for (uint32 i = 0; i < 9; ++i)
    {
      _kx[i] = (typename Pixel_F::type)iKernelX._spK[i];
      _ky[i] = (typename Pixel_F::type)iKernelY._spK[i];  
    }
  }
  
  void Do(const Pixel_F * iprL0, const Pixel_F * iprL1, const Pixel_F * iprL2, 
          uint32 ix, Pixel * oprDst) const
  {
    _sumx = elxConvolvePixel3x3(_kx, iprL0,iprL1,iprL2, ix);
    _sumy = elxConvolvePixel3x3(_kx, iprL0,iprL1,iprL2, ix);

    // Could be done via policies to avoid extra IFs
    // Ignore iQuick for now
    _sum = elxPixelAbs(_sumx) + elxPixelAbs(_sumy);
    if (_pOrientationtMap != NULL)
    {
      _lum = iprL1[1+ix].GetLuminance();
      _grN  = Math::elxAbs(iprL0[1+ix].GetLuminance() - _lum);
      _grNE = Math::elxAbs(iprL0[2+ix].GetLuminance() - _lum);
      _grE  = Math::elxAbs(iprL1[2+ix].GetLuminance() - _lum);
      _grSE = Math::elxAbs(iprL2[2+ix].GetLuminance() - _lum);
      _grMax = Math::elxMax(_grN, _grNE, _grE, _grSE);
      Math::ECompassDirection direction =
        (_grMax == _grN) ? Math::CD_North :
          (_grMax == _grNE) ?  Math::CD_NorthEast :
            (_grMax == _grE) ?  Math::CD_East : Math::CD_SouthEast;
      _pOrientationtMap->push_back(direction);
    }
    elxPixelClamp(_sum, *oprDst, _doClamp);
  }
  
  void Do(const Pixel_F * iprL0, const Pixel_F * iprL1, const Pixel_F * iprL2, 
          uint32 ix, Pixel * oprDst, uint32 iChannelMask) const
  {
    _sumx = elxConvolvePixel3x3(_ky, iprL0,iprL1,iprL2, ix, iChannelMask);
    _sumy = elxConvolvePixel3x3(_ky, iprL0,iprL1,iprL2, ix, iChannelMask);
    _sum = elxPixelAdd(elxPixelAbs(_sumx), elxPixelAbs(_sumy), iChannelMask);
    if (_pOrientationtMap != NULL)
    {
      _lum = elxPixelLuminance(iprL1[1+ix], iChannelMask);
      _grN  = Math::elxAbs(elxPixelLuminance(iprL0[1+ix], iChannelMask) - _lum);
      _grNE = Math::elxAbs(elxPixelLuminance(iprL0[2+ix], iChannelMask) - _lum);
      _grE  = Math::elxAbs(elxPixelLuminance(iprL1[2+ix], iChannelMask) - _lum);
      _grSE = Math::elxAbs(elxPixelLuminance(iprL2[2+ix], iChannelMask) - _lum);
      _grMax = Math::elxMax(_grN, _grNE, _grE, _grSE);
      Math::ECompassDirection direction =
        (_grMax == _grN) ? Math::CD_North :
          (_grMax == _grNE) ?  Math::CD_NorthEast :
            (_grMax == _grE) ?  Math::CD_East : Math::CD_SouthEast;
      _pOrientationtMap->push_back(direction);
    }
    elxPixelClamp(_sum, *oprDst, _doClamp, iChannelMask);
  }
  
  OrientationtMap *  _pOrientationtMap;
  IntToType< ResolutionTypeTraits<typename Pixel::type>::_bLUT > _doClamp;
  typename Pixel_F::type _kx[9], _ky[9];
  mutable Pixel_F _sum, _sumx, _sumy, _mul;
  mutable typename Pixel_F::type _lum, _grN, _grNE, _grE, _grSE, _grMax;
};

//----------------------------------------------------------------------------
//  elxProcessPixels3x3: Generic method to iterate over the image line by line
//  process each Pixel. The iteration is a strip-down version of Convolution3x3.
//  PixelProcessor defines how to process a pixel.
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        const PixelProcessor& iProcessor - processor to be applied for each 
//                                           pixel 
//        uint32 iChannelMask
//        ProgressNotifier iNotifier :
//  Out : true/false
//----------------------------------------------------------------------------
template <typename Pixel, typename Pixel_F, class PixelProcessor>
bool elxProcessPixels3x3(
    ImageImpl<Pixel>& ioImage, 
    const PixelProcessor& iProcessor,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  const bool bNoMasking = Pixel::IsFullMask(iChannelMask);
  
  // optimizations
  // --- creates a cached window of 3 lines of width+2 (+2 = pixels on border, one left, one right)
  const uint32 winLineSize = w+2;
  const uint32 byteWinLineSize = winLineSize * sizeof(Pixel_F);
  boost::scoped_array<Pixel_F> spWindow( new Pixel_F [3*winLineSize] );
  if (NULL == spWindow.get())
    return false;
  
  // --- inits progress ---
  const float ProgressStep = 1.f / (float)h;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);
  
  // --- declares variables ---
  uint32 x,y;
  Pixel * prSrc, * prDst;
  Pixel_F * prLine0, * prLine1, * prLine2, * prPixel;
  
  // --- inits variables ---
  prLine0 = spWindow.get();
  prLine1 = prLine0 + winLineSize;
  prLine2 = prLine1 + winLineSize;

  prSrc = ioImage.GetPixel();
  prDst = prSrc;

  // -1- fill prLine1 line from image's first one ---
  prPixel = prLine1 + 1;          
  for (x=0; x<w; x++)                 
    *prPixel++ = *prSrc++;            

  prLine1[0] = prLine1[1];      
  *prPixel = prPixel[-1];           

  // -2- duplicates second line in first line ---
  ::memcpy(prLine0, prLine1, byteWinLineSize);

  // -3- process all lines ---
  for (y=0; y<h; y++)
  {
    // --- fill last line of window ---
    if (y == h-1)
    {
      ::memcpy(prLine2, prLine1, byteWinLineSize);
    }
    else
    {
      prPixel = prLine2 + 1;          
      for (x=0; x<w; x++)                 
        *prPixel++ = *prSrc++;            

      prLine2[0] = prLine2[1];      
      *prPixel = prPixel[-1];           
    }

    // --- process a line ---
    if (bNoMasking)
    {
      for (x=0; x<w; ++x, ++prDst)
        iProcessor.Do(prLine0, prLine1, prLine2, x, prDst);
    }
    else
    {
      for (x=0; x<w; ++x, ++prDst)
        iProcessor.Do(prLine0, prLine1, prLine2, x, prDst, iChannelMask);
    }

    // --- next line ---
    prPixel = prLine0;
    prLine0 = prLine1;
    prLine1 = prLine2;
    prLine2 = prPixel;

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // --- progress end ---
  iNotifier.SetProgress(1.0f);

  return true;

} // elxProcessPixels3x3


// Forward declarations
template <typename Pixel>
bool elxDetectEdges3x3(
    ImageImpl<Pixel>& ioImage,
    OrientationtMap*  opOrientationtMap,
    const Math::ConvolutionKerneld& iKernelX,
    const Math::ConvolutionKerneld& iKernelY,
    bool iQuick,
    uint32 iChannelMask, ProgressNotifier& iNotifier);

} //namespace

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  DetectEdges:
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        EEdgeDetectorType iDetectorType,
//        ECompassDirection iDirectionX,
//        ECompassDirection iDirectionY,
//        bool iQuick,
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//        OrientationtMap& oOrientationtMap,
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::DetectEdges(
    ImageImpl<Pixel>& ioImage,
    OrientationtMap * opOrientationtMap,
    EEdgeDetectorType iDetector,
    Math::ECompassDirection iDirectionX,
    Math::ECompassDirection iDirectionY,
    bool iQuick,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  Math::ConvolutionKerneld kernelX = elxGetEdgeDetector(iDetector, iDirectionX);
  Math::ConvolutionKerneld kernelY = elxGetEdgeDetector(iDetector, iDirectionY);

  return elxDetectEdges3x3(
    ioImage, opOrientationtMap, kernelX, kernelY, iQuick, iChannelMask, iNotifier);

  return false;

} // DetectEdges


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageEdgeProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Compass edge detection using pair of oriented kernels.
//----------------------------------------------------------------------------
//  public virtual from ImageEdgeProcessingImpl
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        EEdgeDetectorType iDetectorType,
//        ECompassDirection iDirectionX,
//        ECompassDirection iDirectionY,
//        bool iQuick,
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::DetectEdges(
    AbstractImage& ioImage,
    EEdgeDetectorType iDetectorType,
    Math::ECompassDirection iDirectionX,
    Math::ECompassDirection iDirectionY,
    bool iQuick,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ImageEdgeProcessingImpl<Pixel>::DetectEdges(
    image, NULL, iDetectorType, iDirectionX, iDirectionY,  
    iQuick, iChannelMask, iNotifier);

} // DetectEdges

//----------------------------------------------------------------------------
//  Compass edge detection using pair of oriented kernels.
//----------------------------------------------------------------------------
//  public virtual from ImageEdgeProcessingImpl
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        EEdgeDetectorType iDetectorType,
//        ECompassDirection iDirectionX,
//        ECompassDirection iDirectionY,
//        bool iQuick,
//        uint32 iChannelMask, 
//        ProgressNotifier& iNotifier
//  Out : bool
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageEdgeProcessingImpl<Pixel>::DetectEdges(
    AbstractImage& ioImage,
    OrientationtMap& oOrientationMap,
    EEdgeDetectorType iDetectorType,
    Math::ECompassDirection iDirectionX,
    Math::ECompassDirection iDirectionY,
    bool iQuick,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ImageEdgeProcessingImpl<Pixel>::DetectEdges(
    image, &oOrientationMap, iDetectorType, iDirectionX, iDirectionY,  
    iQuick, iChannelMask, iNotifier);

} // DetectEdges

} // namespace Image
} // namespace eLynx

#endif // __EdgeProcessing_EdgeDetector_hpp__
*/