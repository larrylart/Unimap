//============================================================================
//  ImageFileManager.cpp                               Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreCore.h>
#include <elx/core/CoreFile.h>
#include <elx/core/IPluginPackage.h>
#include <elx/image/ImageFilterManager.h>

#define IMAGE_FILTER_PLUGIN_EXT "elxFILTER"

/// UUID of IImageFilterPlugin {76E63867-C203-4910-9ED4-DDE52F3F9ECC}
const eLynx::UUID UUID_IImageFilterPlugin( 
  0x76e63867, 0xc203, 0x4910, 0x9e, 0xd4, 0xdd, 0xe5, 0x2f, 0x3f, 0x9e, 0xcc);

namespace eLynx {
namespace Image {

IImageFilterPlugin::~IImageFilterPlugin() {}

ImageFilterManager the_ImageFilterManager;

IImageFilter::~IImageFilter() {}

//----------------------------------------------------------------------------
//  constructor
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : -
//  Out : -
//----------------------------------------------------------------------------
ImageFilterManager::ImageFilterManager() :
  PluginManager(UUID_IImageFilterPlugin)
{
} // constructor


//----------------------------------------------------------------------------
//  destructor
//----------------------------------------------------------------------------
//  public virtual from ImageFilterManager
//----------------------------------------------------------------------------
//  In  : -
//  Out : -
//----------------------------------------------------------------------------
ImageFilterManager::~ImageFilterManager()
{
  Unregister();

} // destructor


//----------------------------------------------------------------------------
//  Register
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : iprPath :
//  Out : -
//----------------------------------------------------------------------------
void ImageFilterManager::Register(const char * iprPath)
{
  PluginManager::Register(iprPath, IMAGE_FILTER_PLUGIN_EXT);

} // Register


} // namespace Image
} // namespace eLynx

