//============================================================================
//  PointProcessing/HueSaturation.hpp                  Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [Y] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_HueSaturation_hpp__
#define __PointProcessing_HueSaturation_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>
#include <elx/image/ColorSpace.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template <typename Pixel>
struct AdjustHueSaturationTask : public IterationRangeTask
{
  // initial constructor
   AdjustHueSaturationTask(
      Pixel * iprSrc, 
      double iHue, 
      double iSaturation, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier), 
    _prSrc(iprSrc), 
    _hue(iHue), 
    _saturation(iSaturation) 
  {}
  
  // split constructor
  AdjustHueSaturationTask (
      const AdjustHueSaturationTask& iOther, 
      const IterationRange& iRange) : 
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc), 
    _hue(iOther._hue),
    _saturation(iOther._saturation) 
  {}
  
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
  uint32 operator ()()
  {
    const uint32 begin = (uint32)_begin;
    const uint32 end = (uint32)_end;
    const double hue = _hue;
    const double saturation = _saturation;

    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);

    Pixel * prPixel = _prSrc;
    for (uint32 i=begin; i!=end; i++)
      elxAdjustHueSaturation(prPixel[i], hue, saturation);

    notifier.SetProgress(1.0f);
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:  
  Pixel * _prSrc;
  double _hue, _saturation;
};

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustHueSaturation # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustHueSaturation(
    ImageImpl<Pixel>& ioImage,
    double iHue, 
    double iSaturation, 
    ProgressNotifier& iNotifier)
{
  // optimize processing for neutral values
  if ((0.0 == iHue) && (0.0 == iSaturation)) return true;
  if (!ioImage.IsValid()) return false;

  const uint32 size = ioImage.GetPixelCount();
  const IterationRange range(0, size);
  AdjustHueSaturationTask<Pixel> task(
    ioImage.GetPixel(), iHue, iSaturation, iNotifier); 

  return (elxOK == elxParallelFor(range, task));

} // AdjustHueSaturation # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustHueSaturation # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustHueSaturation(
    AbstractImage& ioImage, 
    double iHue, double iSaturation, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return AdjustHueSaturation(image, iHue, iSaturation, iNotifier);

} // AdjustHueSaturation # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_HueSaturation_hpp__
