//============================================================================
//  PointProcessing/Posterize.hpp                      Image.Component package
//============================================================================
//  [N] multicore optimization
//  [Y] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Posterize_hpp__
#define __PointProcessing_Posterize_hpp__

namespace eLynx {
namespace Image {

namespace {

//----------------------------------------------------------------------------
//  elxPosterize # NonLutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxPosterize(
    ImageImpl<Pixel>& ioImage,
    uint32 iLevels, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    NonLutType)
{
  // not supported
  return false;

} // elxPosterize # NonLutType


//----------------------------------------------------------------------------
//  elxPosterize # LutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxPosterize(
    ImageImpl<Pixel>& ioImage,
    uint32 iLevels,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    LutType)
{
  if (!ioImage.IsValid()) return false;
  iNotifier.SetProgress(0.0f);

  typedef typename Pixel::type T;
  Math::Ramp<T> ramp;
  ramp.Posterize(iLevels);
  iNotifier.SetProgress(0.3f);

  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = ioImage.GetChannelCount();
  const bool bSuccess = elxApplyRampFast(ramp, prSrc, size, nChannel, iChannelMask);
  
  iNotifier.SetProgress(1.0f);
  return bSuccess;

} // elxPosterize # LutType

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Posterize # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::Posterize(
    ImageImpl<Pixel>& ioImage,
    uint32 iLevels, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  return elxPosterize(ioImage, iLevels, iChannelMask, iNotifier, PIXEL_LUT_TYPE);

} // Posterize # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Posterize # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::Posterize(
    AbstractImage& ioImage,
    uint32 iLevels, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Posterize(image, iLevels, iChannelMask, iNotifier);

} // Posterize # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Posterize_hpp__
