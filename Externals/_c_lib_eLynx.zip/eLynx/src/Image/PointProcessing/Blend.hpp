//============================================================================
//  PointProcessing/Blend.hpp                          Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [N] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Blend_hpp__
#define __PointProcessing_Blend_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template <typename Pixel>
struct BlendTask : public IterationRangeTask
{
  BlendTask(
      const Pixel * iprSrc, 
      Pixel * iprDst,
      double iScalar, 
      uint32 iChannelMask,
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc),
    _prDst(iprDst),
    _Scalar(iScalar),
    _ChannelMask(iChannelMask)
  {}

  BlendTask(
      const BlendTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc),
    _prDst(iOther._prDst),
    _Scalar(iOther._Scalar),
    _ChannelMask(iOther._ChannelMask)
  {}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>  
  uint32 operator()()
  {
    const Pixel * prSrc = _prSrc + _begin;
    Pixel * prDst = _prDst + _begin;
    Pixel * prEnd = _prDst + _end;
    const uint32 channelMask = _ChannelMask;
    const double scalar = _Scalar;

    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);
    
    if (Pixel::IsFullMask(channelMask))
    {
      do 
      { 
        *prDst = elxPixelBlend(*prDst, *prSrc, scalar); 
      } 
      while (++prSrc, ++prDst != prEnd);
    }
    else
    {
      do 
      { 
        *prDst = elxPixelBlend(*prDst, *prSrc, scalar, channelMask); 
      } 
      while (++prSrc, ++prDst != prEnd);
    }

    notifier.SetProgress(1.0f);
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:  
  const Pixel * _prSrc;
  Pixel * _prDst;
  double _Scalar;
  uint32 _ChannelMask;

}; 

} // anonymous-namespace
 
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Blend # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <class Pixel>
bool ImagePointProcessingImpl<Pixel>::Blend(
    ImageImpl<Pixel>& ioImage, 
    const ImageImpl<Pixel>& iImage, 
    double iScalar,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid() || !iImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;

  // check images size
  if ((ioImage.GetWidth() != iImage.GetWidth()) ||
      (ioImage.GetHeight() != iImage.GetHeight()))
    return false;

  const Pixel * prSrc = iImage.GetPixel();
  Pixel * prDst = ioImage.GetPixel();
  Pixel * prEnd = ioImage.GetPixelEnd();
  
  const IterationRange range(0, prEnd - prDst);
  BlendTask<Pixel> task(
    prSrc, prDst, iScalar, iChannelMask, iNotifier);
    
  return (elxOK == elxParallelFor(range, task));

} // Blend # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImagePointProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Blend # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::Blend(
    AbstractImage& ioImage, 
    const AbstractImage& iImage,
    double iScalar,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  if (!ioImage.IsValid() || !iImage.IsValid()) return false;

  ImageImpl<Pixel>& image1 = elxDowncast<Pixel>(ioImage);
  const ImageImpl<Pixel>& image2 = elxDowncast<Pixel>(iImage);
  return Blend(image1, image2, iScalar, iChannelMask, iNotifier);

} // Blend # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Blend_hpp__
