//============================================================================
//  PointProcessing/Colorize.hpp                       Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [N] LUT type optimization
//  [N] channel mask
//  [N] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Colorize_hpp__
#define __PointProcessing_Colorize_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template <typename Pixel>
struct ColorizeTask : public IterationRangeTask
{
  typedef typename Pixel::type T;
  
  // initial constructor
  ColorizeTask(
      Pixel * iprSrc, 
      T iHue, 
      T iSaturation, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier), 
    _prSrc(iprSrc),
    _hue(iHue), 
    _saturation(iSaturation) 
  {}
  
  // split constructor
  ColorizeTask(
      const ColorizeTask& iOther, 
      const IterationRange& iRange) : 
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc), 
    _hue(iOther._hue),
    _saturation(iOther._saturation) 
  {}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
  uint32 operator ()()
  {
    Pixel * prDst = _prSrc + _begin;
    Pixel * prEnd = _prSrc + _end;
    const T hue = _hue;
    const T saturation = _saturation;

    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);

    do 
    { 
      elxColorize(*prDst, hue, saturation); 
    }
    while (++prDst != prEnd);

    notifier.SetProgress(1.0f);
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:  
  Pixel * _prSrc;
  T _hue, _saturation;

}; // ColorizeTask

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Colorize # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::Colorize(
    ImageImpl<Pixel>& ioImage,
    double iHue, 
    double iSaturation, 
    ProgressNotifier& iNotifier)
{
  typedef typename Pixel::type T;
  if (!ioImage.IsValid()) return false;

  Pixel * prDst = ioImage.GetPixel();
  Pixel * prEnd = ioImage.GetPixelEnd();
  T hue = elxGetHue<T>(iHue);
  T saturation = elxGetSaturation<T>(iSaturation);

  const IterationRange range(0, prEnd - prDst);
  ColorizeTask<Pixel> task(
    prDst, hue, saturation, iNotifier);

  return (elxOK == elxParallelFor(range, task));

} // Colorize # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Colorize # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::Colorize(
    AbstractImage& ioImage,
    double iHue, 
    double iSaturation, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Colorize(image, iHue, iSaturation, iNotifier);

} // Colorize # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Colorize_hpp__
