//============================================================================
//  PointProcessing/Solarize.hpp                       Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [Y] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Solarize_hpp__
#define __PointProcessing_Solarize_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template <typename T>
struct SolarizeTask : public IterationRangeTask
{
  SolarizeTask(
      T * iprSrc, 
      double iThreshold, 
      uint32 iChannelMask,
      uint32 iChannelCount, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc),
    _Threshold( T(iThreshold) ),
    _ChannelMask(iChannelMask),
    _nChannel(iChannelCount)
  {}

  SolarizeTask(
      const SolarizeTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc),
    _Threshold( T(iOther._Threshold) ),
    _ChannelMask(iOther._ChannelMask),
    _nChannel(iOther._nChannel)
  {}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>  
  uint32 operator()()
  {
    T * prDst = _prSrc + _begin;
    T * prEnd = _prSrc + _end;
    const T threshold = _Threshold;
    const uint32 nChannel = _nChannel;
    const uint32 channelMask = _ChannelMask;

    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);

    do 
    { 
      for (uint32 c=0; c<nChannel; c++, ++prDst)
        if (elxUseChannel(c, channelMask))
          if (*prDst >= threshold) 
            *prDst = T(1) - *prDst;
    } 
    while (prDst < prEnd);

    notifier.SetProgress(1.0f);
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:
  T * _prSrc;
  T _Threshold;
  uint32 _ChannelMask;
  uint32 _nChannel;

}; // SolarizeTask


//----------------------------------------------------------------------------
//  elxSolarize # NonLutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxSolarize(
    ImageImpl<Pixel>& ioImage,
    double iThreshold, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    NonLutType)
{
  if (!ioImage.IsValid()) return false;

  typedef typename Pixel::type T;
  T * prSrc = ioImage.GetSamples();
  uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = Pixel::GetChannelCount();

  const IterationRange range(0, size, nChannel);
  SolarizeTask<T> task(
    prSrc, iThreshold, iChannelMask, nChannel, iNotifier);

  return (elxOK == elxParallelFor(range, task));

} // elxSolarize # NonLutType


//----------------------------------------------------------------------------
//  elxSolarize # LutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxSolarize(
    ImageImpl<Pixel>& ioImage,
    double iThreshold,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    LutType)
{
  if (!ioImage.IsValid()) return false;
  iNotifier.SetProgress(0.0f);

  typedef typename Pixel::type T;
  Math::Ramp<T> ramp;
  ramp.SolarizeNorm(iThreshold);
  iNotifier.SetProgress(0.3f);

  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = ioImage.GetChannelCount();

  const bool bSuccess = elxApplyRampFast(ramp, prSrc, size, nChannel, iChannelMask);

  iNotifier.SetProgress(1.0f);
  return bSuccess;
  
} // elxSolarize # LutType

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Solarize # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::Solarize(
    ImageImpl<Pixel>& ioImage,
    double iThreshold, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  return elxSolarize(ioImage, iThreshold, iChannelMask, iNotifier, PIXEL_LUT_TYPE);

} // Solarize # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Solarize # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::Solarize(
    AbstractImage& ioImage,
    double iThreshold, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Solarize(image, iThreshold, iChannelMask, iNotifier);

} // Solarize # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Solarize_hpp__
