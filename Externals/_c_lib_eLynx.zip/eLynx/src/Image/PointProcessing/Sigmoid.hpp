//============================================================================
//  PointProcessing/Sigmoid.hpp                        Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Sigmoid_hpp__
#define __PointProcessing_Sigmoid_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template <typename T>
struct AdjustSigmoidTask : public IterationRangeTask
{
  AdjustSigmoidTask(
      T * iprSrc, 
      double iAlpha, 
      double iBeta,
      uint32 iChannelMask, 
      uint32 iChannelCount, 
      bool ibNoMasking, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc),
    _Alpha(iAlpha),
    _Beta(iBeta),
    _ChannelMask(iChannelMask),
    _nChannel(iChannelCount),
    _bNoMasking(ibNoMasking)
  {}

  AdjustSigmoidTask(
      const AdjustSigmoidTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc),
    _Alpha(iOther._Alpha),
    _Beta(iOther._Beta),
    _ChannelMask(iOther._ChannelMask),
    _nChannel(iOther._nChannel),
    _bNoMasking(iOther._bNoMasking)
  {}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
  uint32 operator()()
  {
    T * prDst = _prSrc + _begin;
    T * prEnd = _prSrc + _end;
    const double alpha = _Alpha;
    const double beta = _Beta;
    const uint32 nChannel = _nChannel;
    const uint32 channelMask = _ChannelMask;
    
    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);

    if (_bNoMasking)
    {
      // optimize when no mask used
      do 
      { 
        *prDst = (T)(1.0 / (1.0 + Math::elxExp(alpha * (beta - *prDst))));
      } 
      while (++prDst != prEnd);
    }
    else
    {
      do 
      { 
        for (uint32 c=0; c<nChannel; c++,prDst++)
          if (elxUseChannel(c, channelMask))
            *prDst = (T)(1.0 / (1.0 + Math::elxExp(alpha * (beta - *prDst))));
      } 
      while (prDst < prEnd);
    }

    notifier.SetProgress(1.0f);
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:
  T * _prSrc;
  double _Alpha, _Beta;
  uint32 _ChannelMask, _nChannel;
  bool _bNoMasking;

}; // AdjustSigmoidTask


//----------------------------------------------------------------------------
//  elxAdjustSigmoid # NonLutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustSigmoid(
    ImageImpl<Pixel>& ioImage,
    double iAlpha, 
    double iBeta, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    NonLutType)
{
  if (!ioImage.IsValid()) return false;

  typedef typename Pixel::type T;
  T * prSrc = ioImage.GetSamples();
  uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = Pixel::GetChannelCount();
  const bool bNoMasking = Pixel::IsFullMask(iChannelMask);

  const IterationRange range(0, size, nChannel);
  AdjustSigmoidTask<T> task(
      prSrc, iAlpha, iBeta, iChannelMask, nChannel, bNoMasking, iNotifier);

  return (elxOK == elxParallelFor(range, task));

} // elxAdjustSigmoid # NonLutType


//----------------------------------------------------------------------------
//  elxAdjustSigmoid # LutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustSigmoid(
    ImageImpl<Pixel>& ioImage,
    double iAlpha, 
    double iBeta,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    LutType)
{
  if (!ioImage.IsValid()) return false;
  iNotifier.SetProgress(0.0f);

  typedef typename Pixel::type T;
  Math::Ramp<T> ramp;
  ramp.Sigmoid(iAlpha, iBeta);

  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = ioImage.GetChannelCount();
  
  const bool bSuccess = elxApplyRampFast(ramp, prSrc, size, nChannel, iChannelMask);

  iNotifier.SetProgress(1.0f);
  return bSuccess;

} // elxAdjustSigmoid # LutType

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustSigmoid # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustSigmoid(
    ImageImpl<Pixel>& ioImage,
    double iAlpha, double iBeta, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  // optimize processing for neutral value
  if (0.0 == iAlpha) return true;
  return elxAdjustSigmoid(ioImage, iAlpha, iBeta, iChannelMask, iNotifier, PIXEL_LUT_TYPE);

} // AdjustSigmoid # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustSigmoid # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustSigmoid(
    AbstractImage& ioImage, 
    double iAlpha, double iBeta,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return AdjustSigmoid(image, iAlpha, iBeta, iChannelMask, iNotifier);

} // AdjustSigmoid # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Sigmoid_hpp__
