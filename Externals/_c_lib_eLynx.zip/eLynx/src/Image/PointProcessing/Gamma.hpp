//============================================================================
//  PointProcessing/Gamma.hpp                          Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [Y] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Gamma_hpp__
#define __PointProcessing_Gamma_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template <typename T>
struct GammaTask : public IterationRangeTask
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  
  GammaTask(
      T * iprSrc, 
      double iGamma, 
      uint32 iChannelMask,
      uint32 iChannelCount, 
      bool ibNoMasking, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc),
    _Gamma(iGamma),
    _ChannelMask(iChannelMask),
    _nChannel(iChannelCount),
    _bNoMasking(ibNoMasking)
  {}

  GammaTask(
      const GammaTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc),
    _Gamma(iOther._Gamma),
    _ChannelMask(iOther._ChannelMask),
    _nChannel(iOther._nChannel),
    _bNoMasking(iOther._bNoMasking)
  {}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>  
  uint32 operator()()
  {
    T * prDst = _prSrc + _begin;
    T * prEnd = _prSrc + _end;
    const F g = F(1.0/_Gamma);
    
    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);

    if (_bNoMasking)
    {
      // optimize when no mask used
      do 
      { 
        *prDst = (T)Math::elxPow(F(*prDst), g);
      } 
      while (++prDst != prEnd);
    }
    else
    {
      const uint32 nChannel = _nChannel;
      const uint32 channelMask = _ChannelMask;
      do 
      { 
        for (uint32 c=0; c<nChannel; c++,prDst++)
          if (elxUseChannel(c, channelMask))
            *prDst = (T)Math::elxPow(F(*prDst), g);
      } 
      while (prDst < prEnd);
    }

    notifier.SetProgress(1.0f);
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:  
  T * _prSrc;
  double _Gamma;
  uint32 _ChannelMask, _nChannel;
  bool _bNoMasking;
};

//----------------------------------------------------------------------------
//  elxAdjustGamma # NonLutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustGamma(
    ImageImpl<Pixel>& ioImage,
    double iGamma, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    NonLutType)
{
  typedef typename Pixel::type T;
  
  if (0.0 == iGamma) return false;
  if (!ioImage.IsValid()) return false;
  
  T * prSrc = ioImage.GetSamples();
  uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = Pixel::GetChannelCount();
  const bool bNoMasking = Pixel::IsFullMask(iChannelMask);

  const IterationRange range(0, size, nChannel);
  GammaTask<T> task(
    prSrc, iGamma, iChannelMask, nChannel, bNoMasking, iNotifier);

  return (elxOK == elxParallelFor(range, task));

} // elxAdjustGamma # NonLutType

//----------------------------------------------------------------------------
//  elxAdjustGamma # LutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustGamma(
    ImageImpl<Pixel>& ioImage,
    double iGamma,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    LutType)
{
  if (!ioImage.IsValid()) return false;

  typedef typename Pixel::type T;
  Math::Ramp<T> ramp;
  ramp.Gamma(iGamma);

  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = ioImage.GetChannelCount();
  return elxApplyRamp(ramp, prSrc, size, nChannel, iChannelMask);
  
} // elxAdjustGamma # LutType

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustGamma # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustGamma(
    ImageImpl< Pixel >& ioImage,
    double iGamma, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  // optimize processing for neutral value
  if (elxGammaDefault == iGamma) return true;
  return elxAdjustGamma(ioImage, iGamma, iChannelMask, iNotifier, PIXEL_LUT_TYPE);

} // AdjustGamma # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustGamma # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustGamma(
    AbstractImage& ioImage, 
    double iGamma, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return AdjustGamma(image, iGamma, iChannelMask, iNotifier);

} // AdjustGamma # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Gamma_hpp__
