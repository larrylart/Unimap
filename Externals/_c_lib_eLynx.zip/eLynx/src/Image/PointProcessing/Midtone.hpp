//============================================================================
//  PointProcessing/Midtone.hpp                        Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Midtone_hpp__
#define __PointProcessing_Midtone_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

namespace {

//----------------------------------------------------------------------------
//  elxAdjustMidtone # Pixel
//----------------------------------------------------------------------------
template <class Pixel>
inline
void elxAdjustMidtone(Pixel& ioPixel, double iMidtone)
{
  typedef typename Pixel::type T;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
  {
    const T D = (Pixel::_max[c] - Pixel::_min[c]);
    double v = ioPixel._channel[c];                   // [_min .. _max]
    v = (v - Pixel::_min[c]) / D;                     // [0 .. 1]
    v = Math::elxMidtone(v, iMidtone);                // [0 .. 1] 
    ioPixel._channel[c] = T(Pixel::_min[c] + v * D);  // [min .. _max]
  }

} // elxAdjustMidtone # Pixel

//----------------------------------------------------------------------------
//  elxAdjustMidtone # Pixel
//----------------------------------------------------------------------------
template <class Pixel>
inline
void elxAdjustMidtone(Pixel& ioPixel, double iMidtone, uint32 iChannelMask)
{
  typedef typename Pixel::type T;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
    if (elxUseChannel(c, iChannelMask))
  {
    const T D = (Pixel::_max[c] - Pixel::_min[c]);
    double v = ioPixel._channel[c];                  // [_min .. _max]
    v = (v - Pixel::_min[c]) / D;                    // [0 .. 1]
    v = Math::elxMidtone(v, iMidtone);               // [0 .. 1]
    ioPixel._channel[c] = T(Pixel::_min[c] + v * D); // [min .. _max]
  }

} // elxAdjustMidtone # Pixel

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
struct MidtoneTask : public IterationRangeTask
{
  MidtoneTask(
      Pixel * iprSrc, 
      double iMidtone, 
      uint32 iChannelMask,
      bool ibNoMasking, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc),
    _midtone(iMidtone),
    _channelMask(iChannelMask),
    _bNoMasking(ibNoMasking)
  {}

  MidtoneTask(
      const MidtoneTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc),
    _midtone(iOther._midtone),
    _channelMask(iOther._channelMask),
    _bNoMasking(iOther._bNoMasking)
  {}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
  uint32 operator()()
  {
    Pixel * prDst = _prSrc + _begin;
    Pixel * prEnd = _prSrc + _end;
    const double midtone = _midtone;
    
    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);

    if (_bNoMasking)
    {
      // optimize when no mask used
      do 
      { 
        elxAdjustMidtone(*prDst, midtone);
      } 
      while (++prDst < prEnd);
    }
    else
    {
      const uint32 channelMask = _channelMask;
      do 
      { 
        elxAdjustMidtone(*prDst, midtone, channelMask);
      } 
      while (++prDst < prEnd);
    }

    notifier.SetProgress(1.0f);
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:  
  Pixel * _prSrc;
  const double _midtone;
  const uint32 _channelMask;
  const bool _bNoMasking;
};

//----------------------------------------------------------------------------
//  elxAdjustMidtone # NonLutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustMidtone(
    ImageImpl<Pixel>& ioImage,
    double iMidtone, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    NonLutType)
{
  if (!ioImage.IsValid()) return false;

  Pixel * prSrc = ioImage.GetPixel();
  const uint32 size = ioImage.GetPixelCount();
  const bool bNoMasking = Pixel::IsFullMask(iChannelMask);

  const IterationRange range(0, size);
  MidtoneTask<Pixel> task(
    prSrc, iMidtone, iChannelMask, bNoMasking, iNotifier);
  return (elxOK == elxParallelFor(range, task));

} // elxAdjustMidtone # NonLutType


//----------------------------------------------------------------------------
//  elxAdjustMidtone # LutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustMidtone(
    ImageImpl<Pixel>& ioImage,
    double iMidtone,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    LutType)
{
  if (!ioImage.IsValid()) return false;

  typedef typename Pixel::type T;
  Math::Ramp<T> ramp;
  ramp.Midtone(iMidtone);

  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = ioImage.GetChannelCount();
  return elxApplyRampFast(ramp, prSrc, size, nChannel, iChannelMask);
  
} // elxAdjustMidtone # LutType

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustMidtone # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustMidtone(
    ImageImpl<Pixel>& ioImage,
    double iMidtone, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  // optimize processing for neutral value
  if (elxMidtoneDefault == iMidtone) return true;
  return elxAdjustMidtone(ioImage, iMidtone, iChannelMask, iNotifier, PIXEL_LUT_TYPE);

} // AdjustMidtone # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustMidtone # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustMidtone(
    AbstractImage& ioImage, 
    double iMidtone, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return AdjustMidtone(image, iMidtone, iChannelMask, iNotifier);

} // AdjustMidtone # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Midtone_hpp__
