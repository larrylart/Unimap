//============================================================================
//  PointProcessing/Desaturate.hpp                     Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [N] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Desaturate_hpp__
#define __PointProcessing_Desaturate_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template <typename Pixel>
struct DesaturateTask : public IterationRangeTask
{
  // initial constructor
  DesaturateTask(
      Pixel * iprSrc, 
      double iFactor, 
      uint32 iChannelMask,
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier), 
    _prSrc(iprSrc), 
    _factor(iFactor), 
    _channelMask(iChannelMask) 
  {}
  
  // split constructor
  DesaturateTask(
      const DesaturateTask& iOther, 
      const IterationRange& iRange) : 
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc), 
    _factor(iOther._factor),
    _channelMask(iOther._channelMask) 
  {}
  
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
  uint32 operator ()()
  {
    const uint32 begin = (uint32)_begin;
    const uint32 end = (uint32)_end;
    const double factor = _factor;
    const uint32 channelMask = _channelMask;
    Pixel * prPixel = _prSrc;

    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);

    for (uint32 i=begin; i!=end; ++i)
      elxDesaturate(prPixel[i], factor, channelMask);

    notifier.SetProgress(1.0f);
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:  
  Pixel * _prSrc;
  double _factor;
  uint32 _channelMask;
};

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Desaturate # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::Desaturate(
    ImageImpl<Pixel>& ioImage,
    double iFactor, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  // optimize processing for neutral value
  if (1.0 == iFactor) return true;
  if (!ioImage.IsValid()) return false;

  typedef typename Pixel::type T;
  if (!ioImage.IsValid()) return false;
  
  const uint32 size = ioImage.GetPixelCount();
  const IterationRange range(0, size);
  DesaturateTask<Pixel> task(
    ioImage.GetPixel(), iFactor, iChannelMask, iNotifier); 

  return (elxOK == elxParallelFor(range, task));

} // Desaturate # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Desaturate # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::Desaturate(
    AbstractImage& ioImage,
    double iFactor, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Desaturate(image, iFactor, iChannelMask, iNotifier);

} // Desaturate # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Desaturate_hpp__
