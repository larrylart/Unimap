//============================================================================
//  PointProcessing/Contrast.hpp                       Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [Y] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Contrast_hpp__
#define __PointProcessing_Contrast_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template <typename T>
struct ContrastTask : public IterationRangeTask
{
  // initial constructor
  ContrastTask(
      T * iprSrc, 
      double iContrast, 
      uint32 iChannelMask, 
      uint32 inChannel, 
      bool ibNoMasking, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier), 
    _prSrc(iprSrc), 
    _Contrast(iContrast),  
    _ChannelMask(iChannelMask),
    _nChannel(inChannel),
    _bNoMasking(ibNoMasking)
  {}
  
  // split constructor
  ContrastTask (
      const ContrastTask& iOther, 
      const IterationRange& iRange) : 
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc), 
    _Contrast(iOther._Contrast),  
    _ChannelMask(iOther._ChannelMask),
    _nChannel(iOther._nChannel), 
    _bNoMasking(iOther._bNoMasking)
  {}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>  
  uint32 operator ()()
  {
    T * prDst = _prSrc + _begin;
    T * prEnd = _prSrc + _end;
    const uint32 nChannel = _nChannel;
    const uint32 channelMask = _ChannelMask;
    double contrast = _Contrast;
    
    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);

    if (contrast < -1.0) contrast = -1.0; 
    else if (contrast > 1.0) contrast = 1.0;
  
    if (1.0 == contrast)
    {
      if (_bNoMasking)
        do { DoNoMask(prDst); } while (prDst != prEnd);
      else
        do { DoMask(prDst, nChannel, channelMask); } while (prDst != prEnd);
    }
    else
    {
      // compute affine transformation
      T a,b;
      if (contrast > 0)
      {
        a = T(1.0 / 1.0 - contrast);
        b = T(-0.5 * contrast * a);
      }
      else // (iContrast < 0)
      {
        a = T(1.0 + contrast);
        b = T(-contrast / 2.0);
      }
      if (_bNoMasking)
        do { DoNoMask(prDst, a , b); } while (prDst != prEnd);
      else
        do { DoMask(prDst, nChannel, channelMask, a, b); } while (prDst != prEnd);
    }
    
    notifier.SetProgress(1.0f);
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:  
  void DoNoMask(T *& ioprDst)
  {
    // optimize when no mask used
    *ioprDst = *ioprDst < 0.5 ? T(0) : T(1);
    ++ioprDst;
  }
  
  void DoMask(T *& ioprDst, const uint32 inChannel, const uint32 iChannelMask)
  {
    for (uint32 c=0; c<inChannel; c++,ioprDst++)
      if (elxUseChannel(c, iChannelMask))
        *ioprDst = *ioprDst < 0.5 ? T(0) : T(1);
  }
  
  void DoNoMask(T *& ioprDst, const T iA, const T iB)
  {
    // optimize when no mask used
    *ioprDst = iA * ioprDst[0] + iB;
    ++ioprDst;
  }
  
  void DoMask(T *& ioprDst, 
    const uint32 inChannel, const uint32 iChannelMask, const T iA, const T iB)
  {
    for (uint32 c=0; c<inChannel; c++,ioprDst++)
      if (elxUseChannel(c, iChannelMask))
        *ioprDst = iA * ioprDst[0] + iB;
  }

private:  
  T * _prSrc;
  double _Contrast;
  uint32 _ChannelMask;
  uint32 _nChannel;
  bool _bNoMasking;

}; // ContrastTask

//----------------------------------------------------------------------------
//  elxAdjustContrast # NonLutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustContrast(
    ImageImpl< Pixel >& ioImage,
    double iContrast, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    NonLutType)
{
  if (!ioImage.IsValid()) return false;

  typedef typename Pixel::type T;
  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = Pixel::GetChannelCount();
  const bool bNoMasking = Pixel::IsFullMask(iChannelMask);

  const IterationRange range(0, size, nChannel);
  ContrastTask<T> task(
    prSrc, iContrast, iChannelMask, nChannel, bNoMasking, iNotifier);

  return (elxOK == elxParallelFor(range, task));

} // elxAdjustContrast # NonLutType


//----------------------------------------------------------------------------
//  elxAdjustContrast # LutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustContrast(
    ImageImpl< Pixel >& ioImage,
    double iContrast,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    LutType)
{
  if (!ioImage.IsValid()) return false;

  typedef typename Pixel::type T;
  Math::Ramp<T> ramp;
  ramp.Contrast(iContrast);

  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = ioImage.GetChannelCount();
  return elxApplyRampFast(ramp, prSrc, size, nChannel, iChannelMask);
  
} // elxAdjustContrast # LutType

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustContrast # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustContrast(
    ImageImpl<Pixel>& ioImage,
    double iContrast, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  // optimize processing for neutral value
  if (elxContrastDefault == iContrast) return true;

  return elxAdjustContrast(ioImage, iContrast, iChannelMask, iNotifier, PIXEL_LUT_TYPE);

} // AdjustContrast # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustContrast # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustContrast(
    AbstractImage& ioImage, 
    double iContrast,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return AdjustContrast(image, iContrast, iChannelMask, iNotifier);

} // AdjustContrast # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Contrast_hpp__
