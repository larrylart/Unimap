//============================================================================
//  PointProcessing/ShadowHighlight.hpp                Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [Y] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2010 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_ShadowHighlight_hpp__
#define __PointProcessing_ShadowHighlight_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>
#include <elx/math/Ramp.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template <typename Pixel>
struct AdjustShadowHighlightTask : public IterationRangeTask
{
  typedef typename Pixel::type T;
  AdjustShadowHighlightTask(
      Pixel * iprSrc, 
      double iShadow, // normalized [0..1]
      double iHighlight, // normalized [0..1]
      uint32 iChannelMask,
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc),
    _channelMask(iChannelMask),
    _nChannel( Pixel::GetChannelCount() ),
    _bBadParameters(false),
    _bNegative(false)
  {
    T min = T(iShadow); 
    T max = T(iHighlight); 
    if (min == max)
    { 
      _bBadParameters = true; 
      return;
    }

    if (max < min) 
    {
      T tmp = min;
      min = max;
      max = tmp;
      _bNegative = true;
    }

    for (uint32 c=0; c<_nChannel; c++)
    {
      const T range = Pixel::_max[c] - Pixel::_min[c];
      _shadow[c]    = T(Pixel::_min[c] + range * min);
      _highlight[c] = T(Pixel::_min[c] + range * max);
      _scale[c]     = range / (_highlight[c] - _shadow[c]);
      if (_scale[c] <= 0.0) _bBadParameters = true;
    }
  }

  AdjustShadowHighlightTask(
      const AdjustShadowHighlightTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc),
    _channelMask(iOther._channelMask),
    _nChannel(iOther._nChannel),
    _bBadParameters(iOther._bBadParameters),
    _bNegative(iOther._bNegative)
  {
    for (uint32 c=0; c<_nChannel; c++)
    {
      _shadow[c]    = iOther._shadow[c];
      _highlight[c] = iOther._highlight[c];
      _scale[c]     = iOther._scale[c];
    }
  }

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>  
  uint32 operator()()
  {
    if (_bBadParameters) return elxErrDivisionByZero;

    const uint32 nChannel = _nChannel;
    const uint32 channelMask = _channelMask;

    Pixel * prDst = _prSrc + _begin;
    Pixel * prEnd = _prSrc + _end;

    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);
    uint32 c;

    if (_bNegative)
    {
      if (Pixel::IsFullMask(channelMask))
      {
        do 
        { 
          for (c=0; c<nChannel; c++)
          {
            T * p = &prDst->_channel[c];
            if      (*p <= _shadow[c])    *p = Pixel::_max[c];
            else if (*p >= _highlight[c]) *p = Pixel::_min[c];
            else                          *p = _highlight[c] - _scale[c] * (*p - _shadow[c]);
          }
        } 
        while (++prDst < prEnd);
      }
      else
      {
        do 
        { 
          for (c=0; c<nChannel; c++)
            if (elxUseChannel(c, channelMask))
            {
              T * p = &prDst->_channel[c];
              if      (*p <= _shadow[c])    *p = Pixel::_max[c];
              else if (*p >= _highlight[c]) *p = Pixel::_min[c];
              else                          *p = _highlight[c] - _scale[c] * (*p - _shadow[c]);
            }
        } 
        while (++prDst < prEnd);
      }
    }
    else
    {
      if (Pixel::IsFullMask(channelMask))
      {
        do 
        { 
          for (c=0; c<nChannel; c++)
          {
            T * p = &(prDst->_channel[c]);
            if      (*p <= _shadow[c])    *p = Pixel::_min[c];
            else if (*p >= _highlight[c]) *p = Pixel::_max[c];
            else                          *p = _shadow[c] + _scale[c] * (*p - _shadow[c]);
          }
        } 
        while (++prDst < prEnd);
      }
      else
      {
        do 
        { 
          for (c=0; c<nChannel; c++)
            if (elxUseChannel(c, channelMask))
            {
              T * p = &prDst->_channel[c];
              if      (*p <= _shadow[c])    *p = Pixel::_min[c];
              else if (*p >= _highlight[c]) *p = Pixel::_max[c];
              else                          *p = _shadow[c] + _scale[c] * (*p - _shadow[c]);
            }
        } 
        while (++prDst < prEnd);
      }
    }  

    notifier.SetProgress(1.0f);
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:
  Pixel * _prSrc;
  T _shadow[PC_MAX], _highlight[PC_MAX], _scale[PC_MAX];
  const uint32 _channelMask;
  const uint32 _nChannel;
  bool _bBadParameters, _bNegative;

}; // AdjustShadowHighlightTask

//----------------------------------------------------------------------------
//  elxAdjustShadowHighlight # NonLutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustShadowHighlight(
    ImageImpl< Pixel >& ioImage,
    double iShadow,
    double iHighlight, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    NonLutType)
{
  if (!ioImage.IsValid()) return false;

  const uint32 size = ioImage.GetPixelCount();
  const IterationRange range(0, size);
  AdjustShadowHighlightTask<Pixel> task(
    ioImage.GetPixel(), iShadow, iHighlight, iChannelMask, iNotifier); 

  return (elxOK == elxParallelFor(range, task));

} // elxAdjustShadowHighlight # NonLutType

//----------------------------------------------------------------------------
// none implemented
//----------------------------------------------------------------------------
template <>
bool elxAdjustShadowHighlight<PixelLi>(ImageImpl< PixelLi >& ioImage,
    double iShadow,double iHighlight, 
    uint32 iChannelMask, ProgressNotifier& iNotifier,
    NonLutType)
{ return false; }

template <>
bool elxAdjustShadowHighlight<PixelLAi>(ImageImpl< PixelLAi >& ioImage,
    double iShadow,double iHighlight, 
    uint32 iChannelMask, ProgressNotifier& iNotifier,
    NonLutType)
{ return false; }

template <>
bool elxAdjustShadowHighlight<PixelRGBi>(ImageImpl< PixelRGBi >& ioImage,
    double iShadow,double iHighlight, 
    uint32 iChannelMask, ProgressNotifier& iNotifier,
    NonLutType)
{ return false; }

template <>
bool elxAdjustShadowHighlight<PixelRGBAi>(ImageImpl< PixelRGBAi >& ioImage,
    double iShadow,double iHighlight, 
    uint32 iChannelMask, ProgressNotifier& iNotifier,
    NonLutType)
{ return false; }

template <>
bool elxAdjustShadowHighlight<PixelComplexi>(ImageImpl< PixelComplexi >& ioImage,
    double iShadow,double iHighlight, 
    uint32 iChannelMask, ProgressNotifier& iNotifier,
    NonLutType)
{ return false; }

//----------------------------------------------------------------------------
//  elxAdjustShadowHighlight # LutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustShadowHighlight(
    ImageImpl< Pixel >& ioImage,
    double iShadow,
    double iHighlight,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    LutType)
{
  if (!ioImage.IsValid()) return false;

  typedef typename Pixel::type T;
  Math::Ramp<T> ramp;

  ramp.StretchNorm(iShadow, iHighlight);

  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = ioImage.GetChannelCount();
  return elxApplyRampFast(ramp, prSrc, size, nChannel, iChannelMask);

  return false;

} // elxAdjustShadowHighlight # LutType

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustShadowHighlight # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustShadowHighlight(
    ImageImpl< Pixel >& ioImage,
    double iShadow,
    double iHighlight, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  // optimize processing for neutral value
  if ((elxShadowDefault == iShadow) && (elxHighlightDefault == iHighlight)) return true;
  return elxAdjustShadowHighlight(ioImage, iShadow, iHighlight, iChannelMask, iNotifier, PIXEL_LUT_TYPE);

} // AdjustShadowHighlight # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustShadowHighlight # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustShadowHighlight(
    AbstractImage& ioImage, 
    double iShadow,
    double iHighlight,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return AdjustShadowHighlight(image, iShadow, iHighlight, iChannelMask, iNotifier);

} // AdjustShadowHighlight # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_ShadowHighlight_hpp__
