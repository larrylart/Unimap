//============================================================================
//  PointProcessing/Brightness.hpp                     Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [Y] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Brightness_hpp__
#define __PointProcessing_Brightness_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>
#include <elx/math/Ramp.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

/*
template <typename T>
struct AdjustBrightnessTask : public IterationRangeTask
{
  AdjustBrightnessTask(
      T * iprSrc, 
      double iBrightness, 
      uint32 iChannelMask,
      uint32 inChannel, 
      bool ibNoMasking, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc),
    _Brightness( (T)iBrightness ),
    _ChannelMask(iChannelMask),
    _nChannel(inChannel),
    _bNoMasking(ibNoMasking)
  {}

  AdjustBrightnessTask(
      const AdjustBrightnessTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc),
    _Brightness(iOther._Brightness),
    _ChannelMask(iOther._ChannelMask),
    _nChannel(iOther._nChannel),
    _bNoMasking(iOther._bNoMasking)
  {}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>  
  uint32 operator()()
  {
    T * prDst = _prSrc + _begin;
    T * prEnd = _prSrc + _end;
    const T brightness = _Brightness; 
    const uint32 nChannel = _nChannel;
    const uint32 channelMask = _ChannelMask;

    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);
    
    if (_bNoMasking)
    {
      do 
      { 
        *prDst += brightness; 
      } 
      while (++prDst != prEnd);
    }
    else
    {
      do 
      { 
        for (uint32 c=0; c<nChannel; c++,prDst++)
          if (elxUseChannel(c, channelMask))
            *prDst += brightness;
      } 
      while (prDst < prEnd);
    }

    notifier.SetProgress(1.0f);
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:
  T * _prSrc;
  T _Brightness;
  uint32 _ChannelMask, _nChannel;
  bool _bNoMasking;

}; // AdjustBrightnessTask
*/

template <typename Pixel>
struct AdjustBrightnessTask : public IterationRangeTask
{
  typedef typename Pixel::type T;
  AdjustBrightnessTask(
      Pixel * iprSrc, 
      double iBrightness, // [-1..+1]
      uint32 iChannelMask,
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc),
    _channelMask(iChannelMask),
    _nChannel( Pixel::GetChannelCount() )
  {
    for (uint32 c=0; c<_nChannel; c++)
      _brightness[c] = T(iBrightness);
  }

  AdjustBrightnessTask(
      const AdjustBrightnessTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc),
    _channelMask(iOther._channelMask),
    _nChannel(iOther._nChannel)
  {
    for (uint32 c=0; c<_nChannel; c++)
      _brightness[c] = iOther._brightness[c];
  }

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>  
  uint32 operator()()
  {
#if 0
    Pixel * prDst = _prSrc + _begin;
    Pixel * prEnd = _prSrc + _end;

    //const T brightness = _brightness; 
    const uint32 nChannel = _nChannel;
    const uint32 channelMask = _channelMask;

    ProgressNotifier& notifier = _notifier;
    notifier.SetProgress(0.0f);
/*    
    if (_bNoMasking)
    {
      do 
      { 
        *prDst += brightness; 
      } 
      while (++prDst != prEnd);
    }
    else
    {
      do 
      { 
        for (uint32 c=0; c<nChannel; c++,prDst++)
          if (elxUseChannel(c, channelMask))
            *prDst += brightness;
      } 
      while (prDst < prEnd);
    }
*/
    notifier.SetProgress(1.0f);
#endif
    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

private:
  Pixel * _prSrc;
  T _brightness[PC_MAX];
  const uint32 _channelMask, _nChannel;

}; // AdjustBrightnessTask

//----------------------------------------------------------------------------
//  elxAdjustBrightness # NonLutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustBrightness(
    ImageImpl< Pixel >& ioImage,
    double iBrightness, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    NonLutType)
{
  if (!ioImage.IsValid()) return false;

  const uint32 size = ioImage.GetPixelCount();
  const IterationRange range(0, size);
  AdjustBrightnessTask<Pixel> task(
    ioImage.GetPixel(), iBrightness, iChannelMask, iNotifier); 

  return (elxOK == elxParallelFor(range, task));

} // elxAdjustBrightness # NonLutType

 
//----------------------------------------------------------------------------
//  elxAdjustBrightness # LutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustBrightness(
    ImageImpl< Pixel >& ioImage,
    double iBrightness,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    LutType)
{
  if (!ioImage.IsValid()) return false;

  typedef typename Pixel::type T;
  Math::Ramp<T> ramp;
  ramp.AddNorm(iBrightness);

  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = ioImage.GetChannelCount();
  return elxApplyRampFast(ramp, prSrc, size, nChannel, iChannelMask);

} // elxAdjustBrightness # LutType

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustBrightness # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustBrightness(
    ImageImpl< Pixel >& ioImage,
    double iBrightness, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  // optimize processing for neutral value
  if (elxBrightnessDefault == iBrightness) return true;
  return elxAdjustBrightness(ioImage, iBrightness, iChannelMask, iNotifier, PIXEL_LUT_TYPE);

} // AdjustBrightness # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustBrightness # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustBrightness(
    AbstractImage& ioImage, 
    double iBrightness,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return AdjustBrightness(image, iBrightness, iChannelMask, iNotifier);

} // AdjustBrightness # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Brightness_hpp__
