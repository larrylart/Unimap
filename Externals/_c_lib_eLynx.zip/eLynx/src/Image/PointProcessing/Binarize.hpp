//============================================================================
//  PointProcessing/Binarize.hpp                       Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Binarize_hpp__
#define __PointProcessing_Binarize_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateBinarized # ImageL<T>
//----------------------------------------------------------------------------
template <typename T>
inline
static boost::shared_ptr< ImageLub > 
  elxCreateBinarized(
    const ImageImpl< PixelL<T> >& iImage,  
    T iThreshold, 
    bool ibNegative,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageLub >();

  iNotifier.SetProgress(0.0f);

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();

  // create output image
  boost::shared_ptr< ImageLub > spImage( new ImageLub(w,h) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageLub >();

//  const T threshold = T(iThreshold);
  const uint8 One  = ibNegative ? 0 : 255;
  const uint8 Zero = ibNegative ? 255 : 0;

  const T * prSrc = iImage.GetSamples();
  const T * prEnd = iImage.GetSamplesEnd();
  uint8 * prDst = spImage->GetSamples();
  do 
  { 
    *prDst++ = (*prSrc >= iThreshold) ? One : Zero;
  } 
  while (++prSrc != prEnd);

  iNotifier.SetProgress(1.0f);
  return spImage;

} // elxCreateBinarized # ImageL<T>


//----------------------------------------------------------------------------
//  elxCreateBinarized # ImageLA<T>
//----------------------------------------------------------------------------
template <typename T>
inline
static boost::shared_ptr< ImageLAub > 
  elxCreateBinarized(
    const ImageImpl< PixelLA<T> >& iImage,
    T iThreshold, 
    bool ibNegative,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageLAub >();

  iNotifier.SetProgress(0.0f);

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();

  // create output image
  boost::shared_ptr< ImageLAub > spImage( new ImageLAub(w,h) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageLAub >();

  const uint8 One  = ibNegative ? 0 : 255;
  const uint8 Zero = ibNegative ? 255 : 0;

  const T * prSrc = iImage.GetSamples();
  const T * prEnd = iImage.GetSamplesEnd();
  uint8 * prDst = (uint8*)spImage->GetPixel();
  do 
  { 
    *prDst++ = (*prSrc >= iThreshold) ? One : Zero;
  } 
  while (++prSrc != prEnd);

  iNotifier.SetProgress(1.0f);
  return spImage;

} // elxCreateBinarized # ImageLA<T>


//----------------------------------------------------------------------------
//  elxCreateBinarized # ImageRGB<T>
//----------------------------------------------------------------------------
template <typename T>
inline
static boost::shared_ptr< ImageRGBub > 
  elxCreateBinarized(
    const ImageImpl< PixelRGB<T> >& iImage, 
    T iThreshold, 
    bool ibNegative,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageRGBub >();

  iNotifier.SetProgress(0.0f);

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();

  // create output image
  boost::shared_ptr< ImageRGBub > spImage( new ImageRGBub(w,h) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageRGBub >();

  const PixelRGBub One = ibNegative ? PixelRGBub::Black() : PixelRGBub::White();
  const PixelRGBub Zero = ibNegative ? PixelRGBub::White() : PixelRGBub::Black();

  const PixelRGB<T> * prSrc = iImage.GetPixel();
  const PixelRGB<T> * prEnd = iImage.GetPixelEnd();
  PixelRGBub * prDst = spImage->GetPixel();
  do 
  { 
    *prDst++ = (prSrc->GetLuminance() >= iThreshold) ? One : Zero;
  } 
  while (++prSrc != prEnd);

  iNotifier.SetProgress(1.0f);
  return spImage;

} // elxCreateBinarized # ImageRGB<T>


//----------------------------------------------------------------------------
//  elxCreateBinarized # ImageRGBA<T>
//----------------------------------------------------------------------------
template <typename T>
inline
static boost::shared_ptr< ImageRGBAub > 
  elxCreateBinarized(
    const ImageImpl< PixelRGBA<T> >& iImage, 
    T iThreshold, 
    bool ibNegative,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageRGBAub >();

  iNotifier.SetProgress(0.0f);

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();

  // create output image
  boost::shared_ptr< ImageRGBAub > spImage( new ImageRGBAub(w,h) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageRGBAub >();

  const PixelRGBAub One = 
    ibNegative ? PixelRGBAub::Black() : PixelRGBAub::White();
  const PixelRGBAub Zero = 
    ibNegative ? PixelRGBAub::White() : PixelRGBAub::Black();

  const PixelRGBA<T> * prSrc = iImage.GetPixel();
  const PixelRGBA<T> * prEnd = iImage.GetPixelEnd();
  PixelRGBAub * prDst = spImage->GetPixel();
  do 
  { 
    *prDst++ = (prSrc->GetLuminance() >= iThreshold) ? One : Zero;
  } 
  while (++prSrc != prEnd);

  iNotifier.SetProgress(1.0f);
  return spImage;

} // elxCreateBinarized # ImageRGBA<T>

//----------------------------------------------------------------------------
//  elxCreateBinarized # unsupported format
//----------------------------------------------------------------------------
template <typename T, template <typename> class Pixel>
inline
static boost::shared_ptr< ImageLub > 
  elxCreateBinarized(
    const ImageImpl< Pixel<T> >& iImage,  
    T iThreshold, 
    bool ibNegative,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  return boost::shared_ptr< ImageLub >();

} // elxCreateBinarized # unsupported format


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  CreateBinarized # AbstractImage
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr< AbstractImage > 
  ImagePointProcessingImpl<Pixel>::CreateBinarized(
    const AbstractImage& iImage,
    double iThreshold, 
    bool ibNegative,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  if (!iImage.IsL() && !iImage.IsRGB())
    return boost::shared_ptr< ImageLub >();

  typedef typename Pixel::type T;
  T threshold;
  elxFromDoubleNormalized(iThreshold, threshold);
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return elxCreateBinarized<T>(image, threshold, ibNegative, iChannelMask, iNotifier);

} // CreateBinarized # AbstractImage


} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Binarize_hpp__
