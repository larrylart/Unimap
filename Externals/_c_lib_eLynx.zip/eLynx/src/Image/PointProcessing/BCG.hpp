//============================================================================
//  PointProcessing/BGC.hpp                            Image.Component package
//============================================================================
//  [N] multicore optimization
//  [Y] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_BCG_hpp__
#define __PointProcessing_BCG_hpp__

namespace eLynx {
namespace Image {

namespace {

//----------------------------------------------------------------------------
//  AdjustBCG # NonLutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustBCG(
    ImageImpl<Pixel>& ioImage,
    double iBrightness, double iContrast, double iGamma, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    NonLutType)
{
  // optimize processing for neutral values
  const bool bBrightness = (elxBrightnessDefault != iBrightness);
  const bool bContrast   = (elxContrastDefault != iContrast);
  const bool bGamma      = (elxGammaDefault != iGamma);
  if ((!bBrightness) && (!bContrast) && (!bGamma)) return true;
  if (!ioImage.IsValid()) return false;

  iNotifier.SetProgress(0.0f);

  bool bSuccess = true;
  if (bBrightness)
    bSuccess |= elxAdjustBrightness(ioImage, iBrightness, iChannelMask, iNotifier, PIXEL_LUT_TYPE);

  if (bContrast)
    bSuccess |= elxAdjustContrast(ioImage, iContrast, iChannelMask, iNotifier, PIXEL_LUT_TYPE);

  if (bGamma)
    bSuccess |= elxAdjustGamma(ioImage, iGamma, iChannelMask, iNotifier, PIXEL_LUT_TYPE);

  iNotifier.SetProgress(1.0f);
  return bSuccess;

} // AdjustBCG # NonLutType


//----------------------------------------------------------------------------
//  AdjustBCG # LutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAdjustBCG(
    ImageImpl<Pixel>& ioImage,
    double iBrightness, double iContrast, double iGamma, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier,
    LutType)
{
  // optimize processing for neutral values
  const bool bBrightness = (elxBrightnessDefault != iBrightness);
  const bool bContrast   = (elxContrastDefault != iContrast);
  const bool bGamma      = (elxGammaDefault != iGamma);
  if ((!bBrightness) && (!bContrast) && (!bGamma))
    return true;

  if (!ioImage.IsValid()) return false;

  iNotifier.SetProgress(0.0f);

  typedef typename Pixel::type T;
  Math::Ramp<T> ramp;
  if (bBrightness)  ramp.AddNorm(iBrightness);
  if (bContrast)    ramp.Contrast(iContrast);
  if (bGamma)       ramp.Gamma(iGamma);

  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  const uint32 nChannel = ioImage.GetChannelCount();

  const bool bSuccess = elxApplyRampFast(ramp, prSrc, size, nChannel, iChannelMask);

  iNotifier.SetProgress(1.0f);
  return bSuccess;
  
} // elxAdjustBCG # LutType

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustBCG # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustBCG(
    ImageImpl<Pixel>& ioImage,
    double iBrightness, double iContrast, double iGamma,  
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  return elxAdjustBCG(ioImage, iBrightness,iContrast,iGamma, 
      iChannelMask, iNotifier, PIXEL_LUT_TYPE);

} // AdjustBCG # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AdjustBCG # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::AdjustBCG(
    AbstractImage& ioImage, 
    double iBrightness, double iContrast, double iGamma, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return AdjustBCG(image, iBrightness,iContrast,iGamma, iChannelMask, iNotifier);

} //  AdjustBCG # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_BCG_hpp__
