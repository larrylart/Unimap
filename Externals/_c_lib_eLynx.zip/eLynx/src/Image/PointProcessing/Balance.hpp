//============================================================================
//  PointProcessing/Balance.hpp                        Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [Y] LUT type optimization
//  [N] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __PointProcessing_Balance_hpp__
#define __PointProcessing_Balance_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>
#include <elx/math/Ramp.h>

namespace eLynx {
namespace Image {

namespace {

//----------------------------------------------------------------------------
//  elxBalanceBuffer # NonColorType
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxBalanceBuffer(Pixel * iprPixel, size_t iSize, 
    typename Pixel::type iR, typename Pixel::type iG, typename Pixel::type iB, 
    NonColorType)
{
  //  Do nothing

} // elxBalanceBuffer # NonColorType


//----------------------------------------------------------------------------
//  elxBalanceBuffer # ColorType
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxBalanceBuffer(Pixel * iprPixel, size_t iSize, 
    typename Pixel::type iR, typename Pixel::type iG, typename Pixel::type iB, 
    ColorType)
{
  typedef typename Pixel::type T;

  Pixel * prDst = iprPixel;
  Pixel * prEnd = prDst + iSize;

  do 
  { 
    // convert to RGB<T>
    PixelRGB<T> rgb(*prDst);

    // balance
    rgb._red   *= iR; 
    rgb._green *= iG; 
    rgb._blue  *= iB; 

    // back to original color space
    *prDst = Pixel(rgb);
  } 
  while (++prDst != prEnd);

} // elxBalanceBuffer # ColorType


//----------------------------------------------------------------------------
//  elxBalanceBufferRGB<T>
//----------------------------------------------------------------------------
template <typename T>
void elxBalanceBufferRGB(PixelRGB<T> * iprPixel, size_t iSize, T iR, T iG, T iB)
{
  PixelRGB<T> * prDst = iprPixel;
  PixelRGB<T> * prEnd = prDst + iSize;

  // optimize, convert only necessary data
  uint32 channelMask = 0;
  if (iR != T(1)) channelMask |= CM_Channel0;
  if (iG != T(1)) channelMask |= CM_Channel1;
  if (iB != T(1)) channelMask |= CM_Channel2;

  switch (channelMask)
  {
    case CM_Channel0:
      do { prDst->_red *= iR; } while (++prDst != prEnd);
      break;

    case CM_Channel1:
      do { prDst->_green *= iG; } while (++prDst != prEnd);
      break;

    case CM_Channel2:
      do { prDst->_blue *= iB; } while (++prDst != prEnd);
      break;

    case CM_Channel0+CM_Channel1:
      do { prDst->_red *= iR; prDst->_green *= iG; } while (++prDst != prEnd);
      break;

    case CM_Channel0+CM_Channel2:
      do { prDst->_red *= iR; prDst->_blue *= iB; } while (++prDst != prEnd);
      break;

    case CM_Channel1+CM_Channel2:
      do { prDst->_green *= iG; prDst->_blue *= iB; } while (++prDst != prEnd);
      break;

    case CM_Channel0+CM_Channel1+CM_Channel2:
      do { prDst->_red *= iR; prDst->_green *= iG; prDst->_blue *= iB; } while (++prDst != prEnd);
      break;

    default:
      break;
  }

} // elxBalanceBufferRGB<T>


//----------------------------------------------------------------------------
//  elxBalanceBufferRGBA<T>
//----------------------------------------------------------------------------
template <typename T>
void elxBalanceBufferRGBA(PixelRGBA<T> * iprPixel, size_t iSize, T iR, T iG, T iB)
{
  PixelRGBA<T> * prDst = iprPixel;
  PixelRGBA<T> * prEnd = prDst + iSize;

  // optimize, convert only necessary data
  uint32 channelMask = 0;
  if (iR != T(1)) channelMask |= CM_Channel0;
  if (iG != T(1)) channelMask |= CM_Channel1;
  if (iB != T(1)) channelMask |= CM_Channel2;

  switch (channelMask)
  {
    case CM_Channel0:
      do { prDst->_red *= iR; } while (++prDst != prEnd);
      break;

    case CM_Channel1:
      do { prDst->_green *= iG; } while (++prDst != prEnd);
      break;

    case CM_Channel2:
      do { prDst->_blue *= iB; } while (++prDst != prEnd);
      break;

    case CM_Channel0+CM_Channel1:
      do { prDst->_red *= iR; prDst->_green *= iG; } while (++prDst != prEnd);
      break;

    case CM_Channel0+CM_Channel2:
      do { prDst->_red *= iR; prDst->_blue *= iB; } while (++prDst != prEnd);
      break;

    case CM_Channel1+CM_Channel2:
      do { prDst->_green *= iG; prDst->_blue *= iB; } while (++prDst != prEnd);
      break;

    case CM_Channel0+CM_Channel1+CM_Channel2:
      do { prDst->_red *= iR; prDst->_green *= iG; prDst->_blue *= iB; } while (++prDst != prEnd);
      break;

    default:
      break;
  }

} // elxBalanceBufferRGBA<T>


template<class Pixel> 
struct BalanceHelper
{
  static void Do(Pixel * iprPixel, size_t iSize, 
    typename Pixel::type iR, typename Pixel::type iG, typename Pixel::type iB)
  { elxBalanceBuffer(iprPixel, iSize, iR,iG,iB, PIXEL_COLOR_TYPE(Pixel)); }
};

template<typename T> 
struct BalanceHelper< PixelRGB<T> >
{
  static void Do(PixelRGB<T> * iprPixel, size_t iSize, T iR, T iG, T iB)
  { elxBalanceBufferRGB(iprPixel, iSize, iR,iG,iB); }
};

template<typename T> 
struct BalanceHelper< PixelRGBA<T> >
{
  static void Do(PixelRGBA<T> * iprPixel, size_t iSize, T iR, T iG, T iB)
  { elxBalanceBufferRGBA(iprPixel, iSize, iR,iG,iB); }
};

//----------------------------------------------------------------------------
//  elxBalanceBuffer # generic
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxBalanceBuffer(Pixel * iprPixel, size_t iSize, 
    typename Pixel::type iR, typename Pixel::type iG, typename Pixel::type iB)
{
  BalanceHelper<Pixel>::Do(iprPixel, iSize, iR,iG,iB);

} // elxBalanceBuffer # generic



//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

template <typename Pixel>
struct BalanceTask : public IterationRangeTask
{
  typedef typename Pixel::type T;
  
  BalanceTask(
      Pixel * iprSrc, 
      T iRed, T iGreen, T iBlue,
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc),
    _red(iRed), _green(iGreen), _blue(iBlue)
    {}
    
  BalanceTask(
      const BalanceTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc),
    _red(iOther._red), _green(iOther._green), _blue(iOther._blue)
    {}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>    
  uint32 operator()()
  {
    Pixel * prDst = _prSrc + _begin;
    const size_t size = _end - _begin;

    const T r = _red;
    const T g = _green;
    const T b = _blue;

    elxBalanceBuffer(prDst, size, r,g,b);

    return elxOK;
  }
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
private:  
  Pixel * _prSrc;
  const T _red, _green, _blue;

}; // BalanceTask

//----------------------------------------------------------------------------
//  elxBalance # RGB NonLutType
//----------------------------------------------------------------------------
template <typename T>
inline
bool elxBalance(
    ImageImpl< PixelRGB<T> >& ioImage,
    double iRed, double iGreen, double iBlue,
    ProgressNotifier& iNotifier,
    NonLutType)
{
  if (!ioImage.IsValid())
    return false;

  const T r = T(iRed);
  const T g = T(iGreen);
  const T b = T(iBlue);
  
  PixelRGB<T> * prSrc = ioImage.GetPixel();
  PixelRGB<T> * prEnd = ioImage.GetPixelEnd();
  
  const IterationRange range(0, prEnd - prSrc);
  BalanceTask< PixelRGB<T> > task(
    prSrc, r,g,b, iNotifier);
    
  return (elxOK == elxParallelFor(range, task));

} // elxBalance # RGB NonLutType

//----------------------------------------------------------------------------
//  elxBalance # RGB LutType
//----------------------------------------------------------------------------
template <typename T>
inline
bool elxBalance(
    ImageImpl< PixelRGB<T> >& ioImage,
    double iRed, double iGreen, double iBlue,
    ProgressNotifier& iNotifier,
    LutType)
{
  if (!ioImage.IsValid())
    return false;

  Math::Ramp<T> Ramp0,Ramp1,Ramp2;

  // optimize, convert only necessary data
  uint32 channelMask = 0;
  if (iRed   != 1.) channelMask |= CM_Channel0;
  if (iGreen != 1.) channelMask |= CM_Channel1;
  if (iBlue  != 1.) channelMask |= CM_Channel2;

  if (channelMask & CM_Channel0) Ramp0.Mul(iRed);
  if (channelMask & CM_Channel1) Ramp1.Mul(iGreen);
  if (channelMask & CM_Channel2) Ramp2.Mul(iBlue);

  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  return elxApplyRampFast(Ramp0, Ramp1, Ramp2, prSrc, size, channelMask);

} // elxBalance # RGB LutType

//----------------------------------------------------------------------------
//  elxBalance # RGBA NonLutType
//----------------------------------------------------------------------------
template <typename T>
inline
bool elxBalance(
    ImageImpl< PixelRGBA<T> >& ioImage,
    double iRed, double iGreen, double iBlue,
    ProgressNotifier& iNotifier,
    NonLutType)
{
  if (!ioImage.IsValid())
    return false;

  const T r = T(iRed);
  const T g = T(iGreen);
  const T b = T(iBlue);

  PixelRGBA<T> * prDst = ioImage.GetPixel();
  PixelRGBA<T> * prEnd = ioImage.GetPixelEnd();
  
  const IterationRange range(0, prEnd - prDst);
  BalanceTask< PixelRGBA<T> > task(
    prDst, r,g,b, iNotifier);
    
  return (elxOK == elxParallelFor(range, task));

} // elxBalance # RGBA NonLutType

//----------------------------------------------------------------------------
//  elxBalance # RGBA LutType
//----------------------------------------------------------------------------
template <typename T>
inline
bool elxBalance(
    ImageImpl< PixelRGBA<T> >& ioImage,
    double iRed, double iGreen, double iBlue,
    ProgressNotifier& iNotifier,
    LutType)
{
  if (!ioImage.IsValid())
    return false;

  Math::Ramp<T> Ramp0,Ramp1,Ramp2,Ramp3; 

  // optimize, convert only necessary data
  uint32 channelMask = 0;
  if (iRed   != 1.) channelMask |= CM_Channel0;
  if (iGreen != 1.) channelMask |= CM_Channel1;
  if (iBlue  != 1.) channelMask |= CM_Channel2;

  if (channelMask & CM_Channel0) Ramp0.Mul(iRed);
  if (channelMask & CM_Channel1) Ramp1.Mul(iGreen);
  if (channelMask & CM_Channel2) Ramp2.Mul(iBlue);

  T * prSrc = ioImage.GetSamples();
  const uint32 size = ioImage.GetSampleCount();
  return elxApplyRampFast(Ramp0, Ramp1, Ramp2, Ramp3, prSrc, size, channelMask);
  
} // elxBalance # RGBA LutType

//----------------------------------------------------------------------------
//  elxBalance # none supported LutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxBalance(
    ImageImpl< Pixel >& ioImage,
    double iRed, double iGreen, double iBlue,
    ProgressNotifier& iNotifier, LutType)
{
  return false;

} // elxBalance # none supported LutType

//----------------------------------------------------------------------------
//  elxBalance # none supported NonLutType
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxBalance(
    ImageImpl< Pixel >& ioImage,
    double iRed, double iGreen, double iBlue,
    ProgressNotifier& iNotifier, NonLutType)
{
  typedef typename Pixel::type T;

  if (!ioImage.IsValid())
    return false;

  const T r = T(iRed);
  const T g = T(iGreen);
  const T b = T(iBlue);
  
  Pixel * prSrc = ioImage.GetPixel();
  Pixel * prEnd = ioImage.GetPixelEnd();
  
  const IterationRange range(0, prEnd - prSrc);
  BalanceTask< Pixel > task(
    prSrc, r,g,b, iNotifier);
    
  return (elxOK == elxParallelFor(range, task));

} // elxBalance # none supported NonLutType

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Balance # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::Balance(
    ImageImpl<Pixel>& ioImage,
    double iRed, double iGreen, double iBlue,
    ProgressNotifier& iNotifier)
{
  if (CS_Undefined == Pixel::GetColorSpace())
    return false; 

  return elxBalance(ioImage, iRed,iGreen,iBlue, iNotifier, PIXEL_LUT_TYPE);

} // Balance # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImagePointProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Balance # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImagePointProcessingImpl<Pixel>::Balance(
    AbstractImage& ioImage,
    double iRed, double iGreen, double iBlue,
    ProgressNotifier& iNotifier) const
{
  if (CS_Undefined == Pixel::GetColorSpace()) return false; 

  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Balance(image, iRed, iGreen, iBlue, iNotifier);

} // Balance # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __PointProcessing_Balance_hpp__
