//============================================================================
//  ImageHistogram.cpp                                 Image.Component package
//============================================================================
//  Usage : tool class for image histogram
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <memory.h>
#include <elx/image/ImageHistogram.h>
#include <elx/core/CoreMacros.h>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//                            ChannelHistogram
//----------------------------------------------------------------------------
ChannelHistogram::ChannelHistogram() :
  _min(0), _max(0)
{
  for (uint32 i=0; i<HistogramSamples; i++) _map[i] = 0;
}
//----------------------------------------------------------------------------
ChannelHistogram::ChannelHistogram(const ChannelHistogram& iHistogram) :
  _min(iHistogram._min),
  _max(iHistogram._max)
{
  ::memcpy(_map, iHistogram._map, HistogramSamples*sizeof(int32));
}
//----------------------------------------------------------------------------
const ChannelHistogram& ChannelHistogram::operator= (const ChannelHistogram& iHistogram)
{
  _min = iHistogram._min;
  _max = iHistogram._max;
  ::memcpy(_map, iHistogram._map, HistogramSamples*sizeof(int32));
  return *this;
}
//----------------------------------------------------------------------------
void ChannelHistogram::Reset()
{
  _min = _max = 0;
  for (uint32 i=0; i<HistogramSamples; i++) _map[i] = 0;
}
//----------------------------------------------------------------------------
void ChannelHistogram::UpdateMinMax()
{
  _min = _max = _map[0];

  for (uint32 i=1; i<HistogramSamples; i++)
  {
    if      (_map[i] > _max) _max = _map[i];
    else if (_map[i] < _min) _min = _map[i];
  }
}


//----------------------------------------------------------------------------
float ChannelHistogram::ComputeDominance() const
{
  // compute max index
  uint32 maxIdx = 0;
  uint32 max = _map[0];
  for (uint32 i=1; i<HistogramSamples; i++)
  {
    if (_map[i] > max) 
    {
      max = _map[i];
      maxIdx = i;
    }
  }

  uint32 first = 0;
  while ((first < HistogramSamples) && (0 == _map[first])) first++;
  uint32 last = HistogramSamples-1;
  while ((last != 0) && (0 == _map[last])) last--;

  uint32 d = last - first;
  if (0 == d)
    return -1.0;

  const float s = 1.0f / d;
  return s*(maxIdx-first);

} // ComputeDominance()

//----------------------------------------------------------------------------
uint32 * ChannelHistogram::GetMap()             { return _map;}
const uint32 * ChannelHistogram::GetMap() const { return _map;}
uint32 ChannelHistogram::GetMin() const         { return _min;}
uint32 ChannelHistogram::GetMax() const         { return _max;}
void ChannelHistogram::SetMin(uint32 iMin)      { _min = iMin; }
void ChannelHistogram::SetMax(uint32 iMax)      { _max = iMax; }


//----------------------------------------------------------------------------
//                            ImageHistogram
//----------------------------------------------------------------------------
ImageHistogram::ImageHistogram(uint32 iChannelCount) :
  _nChannel(iChannelCount), _min(0), _max(0)
{
  for (uint32 i=0; i<_nChannel; i++) _channel[i].Reset();
  _min = 0;_max = 0;
}
//----------------------------------------------------------------------------
ImageHistogram::ImageHistogram(const ImageHistogram& iHistogram) :
  _nChannel(iHistogram._nChannel),
  _min(iHistogram._min),
  _max(iHistogram._max)
{
  for (uint32 i=0; i<_nChannel; i++) 
    _channel[i] = iHistogram._channel[i];
} 
//----------------------------------------------------------------------------
void ImageHistogram::UpdateMinMax()
{ 
  for (uint32 i=0; i<_nChannel; i++)
    GetChannel(i).UpdateMinMax();

  _min = _channel[0].GetMin();
  _max = _channel[0].GetMax();

  for (uint32 i=1; i<_nChannel; i++)
  {
    if      (_channel[i].GetMin() < _min)  _min = _channel[i].GetMin();
    else if (_channel[i].GetMax() > _max)  _max = _channel[i].GetMax();
  }
}
//----------------------------------------------------------------------------
ChannelHistogram& ImageHistogram::GetChannel(uint32 iChannel)
{
  elxASSERT(iChannel<=5);
  return _channel[iChannel];
}
//----------------------------------------------------------------------------
const ChannelHistogram& ImageHistogram::GetChannel(uint32 iChannel) const
{
  elxASSERT(iChannel<=5);
  return _channel[iChannel];
}
//----------------------------------------------------------------------------
void ImageHistogram::Reset(uint32 iChannelCount)
{
  elxASSERT(iChannelCount<=5);
  _nChannel = iChannelCount;
  for (uint32 i=0; i<_nChannel; i++)
    _channel[i].Reset();
}
//----------------------------------------------------------------------------
uint32 ImageHistogram::GetChannelCount() const { return _nChannel;}
uint32 ImageHistogram::GetMin() const { return _min;}
uint32 ImageHistogram::GetMax() const { return _max;}
float ImageHistogram::ComputeDominance() const { return _channel[0].ComputeDominance(); }


} // namespace Image
} // namespace eLynx


