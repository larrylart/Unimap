//============================================================================
//  Morphological/MedianWxH.hpp                        Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Morphological_MedianWxH_hpp__
#define __Morphological_MedianWxH_hpp__

#include <elx/core/CoreSort.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplyMedianWxH: 
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        int32 W : width of the median window
//        int32 H : height of the median window
//        ProgressNotifier& iNotifier : default is 0
//  Out : bool 
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageMorphologicalProcessingImpl<Pixel>::ApplyMedianWxH(
    ImageImpl<Pixel>& ioImage,
    uint32 iW, uint32 iH, 
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask) || (0 == iIteration)) return true;

  // we must check H & W
  if (((iH & 1) == 0) || ((iW & 1) == 0))
    return false;

  const uint32 halfW = iW/2;
  const uint32 halfH = iH/2;
  const uint32 lastLine = iH-1;
  const uint32 total = iH*iW;
  const uint32 median = total/2;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
	
  // --- inits progress ---
  const float ProgressStep = (float)iIteration / (float)h;
  float Progress = 0.0f;
  iNotifier.SetProgress(Progress);

  // optimizations
  // --- creates a cached window of H lines of width+(W/2)*2 
  // (+(W/2)*2 = pixels on border, W/2 left, W/2 right)
  const uint32 lineSize = w + 2*halfW;
  const uint32 byteLineSize = lineSize*sizeof(LuminanceCell<Pixel>);

  boost::scoped_array< LuminanceCell<Pixel> > spWindow( new LuminanceCell<Pixel>[iH*lineSize] );
  if (NULL == spWindow.get())
    return false;

  // --- compute max increment to be used in shell sort
  uint32 sortIncrement = 1;
  for (; sortIncrement <= (iW*iH-2)/9; sortIncrement = 3*sortIncrement +1);
	
  // --- inits variables ---
  uint32 x,y,i,j;

  LuminanceCell<Pixel> * prCell;
  boost::scoped_array< LuminanceCell<Pixel> > spCellList( new LuminanceCell<Pixel>[total] );
  boost::scoped_array< LuminanceCell<Pixel>* > spPointerList( new LuminanceCell<Pixel>* [2*iH] );

  // loop over iterations
  do
  {
    // init line start of cache
    LuminanceCell<Pixel> ** prLine = &spPointerList[0];
    LuminanceCell<Pixel> ** prL = &spPointerList[iH];
    for (y=0; y<iH; y++)
      prLine[y] = spWindow.get() + y*lineSize;
    
    Pixel * prSrc = ioImage.GetPixel();
    Pixel * prDst = prSrc;	
    	
    // --- fill first cache line from image first line ---
    prCell = prLine[0] + halfW;
    for (x=0; x<w; x++, prSrc++, prCell++)
      elxLuminocity(*prSrc, *prCell);
    
    for (x=0; x<halfW; x++, prCell++)
    {
      prLine[0][x] = prLine[0][halfW];  // duplicate cell on the left
      *prCell = prCell[-1]; // duplicate cell on the right
    }

    // --- duplicate first cached line into halfH next lines ---
    for (y=1; y<1+halfH; y++)
      ::memcpy(prLine[y], prLine[0], byteLineSize);

    // --- fill next halfH-1 line into cache ---
    for (y=1+halfH; y<iH-1; y++)
    {
      prCell = prLine[y] + halfW;
      for (x=0; x<w; x++, prSrc++, prCell++)
        elxLuminocity(*prSrc, *prCell);
      
      for (x=0; x<halfW; x++, prCell++)
      {
        prLine[y][x] = prLine[y][halfW];  // duplicate cell on the left
        *prCell = prCell[-1]; // duplicate cell on the right
      }
    }

    // --- process all lines ---
    for (y=0; y<h; y++)
    {
      // --- fill last line of window cache ---
      if (y >= h-halfH)
      {
        // next line is duplicated of last converted
        ::memcpy(prLine[lastLine], prLine[lastLine-1], byteLineSize);
      }
      else
      {
        // converts from source
        prCell = prLine[lastLine] + halfW;
        for (x=0; x<w; x++, prSrc++, prCell++)
          elxLuminocity(*prSrc, *prCell);

        for (x=0; x<halfW; x++, prCell++)
        {
          prLine[lastLine][x] = prLine[lastLine][halfW];  // duplicate cell on the left
          *prCell = prCell[-1]; // duplicate cell on the right
        }
      }

      // --- process a line ---
      for (x=0; x<w; x++)
      {
        for (j=0; j<iH; j++)
          prL[j] = prLine[j] + x;

        // fill list of cells to sort
        for (j=0; j<iH; j++)
          for (i=0; i<iW; i++)
            spCellList[j*iW + i] = *(prL[j]+i);

        // --- Shell Sort algorithm with W*H items ---
        elxShellSort(spCellList.get(), total, sortIncrement);

        // --- saves median color ---
        *prDst++ = spCellList[median]._pixel;
      }

      // --- next line ---
      prCell = prLine[0];
      for (j=0; j<lastLine; j++)
        prLine[j] = prLine[j+1];
      prLine[lastLine] = prCell;

      // --- in progress ... ---
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }
  }
  while (--iIteration > 0);

  // --- progress end ---
  iNotifier.SetProgress(1.0f);
  return true;

} // ApplyMedianWxH


//----------------------------------------------------------------------------
// Specialization for pixel's types where Median does not make sense. 
//                            NOT_IMPLEMENTED 
//----------------------------------------------------------------------------
#ifdef elxUSE_ImageComplex
template <>
bool ImageMorphologicalProcessingImpl< PixelComplexi >::ApplyMedianWxH(
    ImageImpl< PixelComplexi >& ioImage, uint32 iW, uint32 iH, 
    uint32 iIteration, uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }

template <> 
bool ImageMorphologicalProcessingImpl< PixelComplexf >::ApplyMedianWxH(
    ImageImpl< PixelComplexf >& ioImage, uint32 iW, uint32 iH, 
    uint32 iIteration, uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }

template <>
bool ImageMorphologicalProcessingImpl< PixelComplexd >::ApplyMedianWxH(
    ImageImpl<PixelComplexd>& ioImage, uint32 iW, uint32 iH, 
    uint32 iIteration, uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }
#endif

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageMorphological implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ApplyMedian: 
//----------------------------------------------------------------------------
//  public virtual from IImageProcessing
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        ProgressNotifier& iNotifier : default is 0
//  Out : bool 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageMorphologicalProcessingImpl<Pixel>::ApplyMedian(
    AbstractImage& ioImage,
    uint32 iWidth, 
    uint32 iHeight, 
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);

  if ((iWidth == 3) && (iHeight == 3))
    return ApplyMedian3x3(image, iIteration, iChannelMask, iNotifier);

  return ApplyMedianWxH(image, iWidth, iHeight, iIteration, iChannelMask, iNotifier);

} // ApplyMedian


} // namespace Image
} // namespace eLynx

#endif // __Morphological_MedianWxH_hpp__
