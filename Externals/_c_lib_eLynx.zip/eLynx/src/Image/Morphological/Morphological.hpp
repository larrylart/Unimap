//============================================================================
//  Morphological/Morphological.hpp                    Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Morphological_Morphological_hpp__
#define __Morphological_Morphological_hpp__

#include <elx/core/CoreSort.h>
#include <elx/image/ImageOperatorsImpl.h>
#include "../Factory/Circle.hpp"

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Apply: 
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageMorphologicalProcessingImpl<Pixel>::Apply(
    ImageImpl<Pixel>& ioImage,
    EMorphologicalFilterType iType,
    const ImageLub& iKernelMask,
    bool ibLuminance,
    uint32 iIteration,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  // difference between the eroded and dilated image
  if (MFT_TopHat == iType)      
  {
    // create dilated image
    boost::shared_ptr< ImageImpl<Pixel> > spDilated( new ImageImpl<Pixel>(ioImage) );
    Apply(*spDilated, MFT_Dilate, iKernelMask, ibLuminance, 1, iChannelMask, iNotifier);

    // process erosion
    Apply(ioImage, MFT_Erode, iKernelMask, ibLuminance, 1, iChannelMask, iNotifier);

    // remove dilated from erosion
    return elxOperator(ioImage, IOP_SubAbsClamp, *spDilated, iChannelMask);
  }

  if (ibLuminance)
  {
    switch (iType)
    {
      case MFT_Min: case MFT_Max: case MFT_Median: // one pass
          return ApplyByLuminance(ioImage, iType, iKernelMask, iIteration, iChannelMask, iNotifier);

      // two passes
      case MFT_Open:  // dilation followed by erosion
      {
        do {
          ApplyByLuminance(ioImage, MFT_Dilate, iKernelMask, 1, iChannelMask, iNotifier);
          return ApplyByLuminance(ioImage, MFT_Erode, iKernelMask, 1, iChannelMask, iNotifier);
        } while (--iIteration > 0);
      }

      case MFT_Close: // erosion followed by dilation
      {
        do {
          ApplyByLuminance(ioImage, MFT_Erode, iKernelMask, 1, iChannelMask, iNotifier);
          return ApplyByLuminance(ioImage, MFT_Dilate, iKernelMask, 1, iChannelMask, iNotifier);
        } while (--iIteration > 0);
      }
      default: break;
    }
  }
  else // by channels
  {
    switch (iType)
    {
      case MFT_Min: case MFT_Max: case MFT_Median: // one pass
          return ApplyByChannel(ioImage, iType, iKernelMask, iIteration, iChannelMask, iNotifier);

      // two passes
      case MFT_Open:  // dilation followed by erosion
      {
        do {
          ApplyByChannel(ioImage, MFT_Dilate, iKernelMask, 1, iChannelMask, iNotifier);
          return ApplyByChannel(ioImage, MFT_Erode, iKernelMask, 1, iChannelMask, iNotifier);
        } while (--iIteration > 0);
      }

      case MFT_Close: // erosion followed by dilation
      {
        do {
          ApplyByChannel(ioImage, MFT_Erode, iKernelMask, 1, iChannelMask, iNotifier);
          return ApplyByChannel(ioImage, MFT_Dilate, iKernelMask, 1, iChannelMask, iNotifier);
        } while (--iIteration > 0);
      }
      default: break;
    }
  }
  return false;

} // Apply

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageMorphologicalProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Apply: 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageMorphologicalProcessingImpl<Pixel>::Apply(
    AbstractImage& ioImage,
    EMorphologicalFilterType iType,
    const ImageLub& iKernelMask,
    bool ibLuminance,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Apply(image, iType, iKernelMask, ibLuminance, iIteration, iChannelMask, iNotifier);

} // Apply


//----------------------------------------------------------------------------
//  Apply: 
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageMorphologicalProcessingImpl<Pixel>::Apply(
    AbstractImage& ioImage,
    EMorphologicalFilterType iType,
    uint32 iWidth, bool ibCircular, 
    bool ibLuminance, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  // build mask
  ImageLub FilterMask(iWidth,iWidth, PixelLub::White());
  if (ibCircular)
    FilterMask = *elxCreateCircle<uint8>(iWidth);

  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Apply(image, iType, FilterMask, ibLuminance, iIteration, iChannelMask, iNotifier);

} // Apply

} // namespace Image
} // namespace eLynx

#endif // __Morphological_Morphological_hpp__
