//============================================================================
//  Morphological/MedianByLuminance.hpp                Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __MedianByLuminance_hpp__
#define __MedianByLuminance_hpp__

#include <elx/core/CoreSort.h>
#include <elx/image/ImageImpl.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplyMedianByLuminance: 
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageMorphologicalProcessingImpl<Pixel>::ApplyMedianByLuminance(
    ImageImpl<Pixel>& ioImage,
    const ImageLub * iprMask,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid() || (NULL == iprMask)) return false;
  if (!iprMask->IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask) || (0 == iIteration)) return true;

  // we must check mask dimensions
  const uint32 mW = iprMask->GetWidth();
  const uint32 mH = iprMask->GetHeight();
  if (((mW & 1) == 0) || ((mH & 1) == 0)) return false;

  const bool bNoMasking = Pixel::IsFullMask(iChannelMask);
  const uint32 nChannel = Pixel_t::GetChannelCount();

  const uint32 halfW = mW/2;
  const uint32 halfH = mH/2;
  const uint32 lastLine = mH-1;
  const uint32 total = mW*mH;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
	
  // --- inits progress ---
  const float ProgressStep = (float)iIteration / (float)h;
  float Progress = 0.0f;
  iNotifier.SetProgress(Progress);

  // --- optimizations based on cache window to compute luminance once for each pixels
  const uint32 lineSize = w + 2*halfW;
  const uint32 byteLineSize = lineSize*sizeof(MedianCell<Pixel>);

  boost::scoped_array< MedianCell<Pixel> > spWindow( new MedianCell<Pixel>[mH*lineSize] );
  if (NULL == spWindow.get()) return false;

  // --- inits variables ---
  uint32 x,y,i,j,k,c;

  // count active pixels in mask
  uint32 count = total;
  const uint8 * prMaskBegin = iprMask->GetSamples();
  const uint8 * prMask = prMaskBegin;
  for (i=0; i<total; i++) if (*prMask++ == 0) count--;
  const uint32 median = count/2;

  // --- compute max increment to be used in shell sort
  uint32 sortIncrement = 1;
  for (; sortIncrement <= (count-2)/9; sortIncrement = 3*sortIncrement + 1);

  MedianCell<Pixel> * prCell;
  boost::scoped_array< MedianCell<Pixel> > spCellList( new MedianCell<Pixel>[count] );
  boost::scoped_array< MedianCell<Pixel>* > spPointerList( new MedianCell<Pixel>* [2*mH] );

  // loop over iterations
  do
  {
    // init line start of cache
    MedianCell<Pixel> ** prLine = &spPointerList[0];
    MedianCell<Pixel> ** prL = &spPointerList[mH];
    for (y=0; y<mH; y++)
      prLine[y] = spWindow.get() + y*lineSize;
    
    Pixel * prSrc = ioImage.GetPixel();
    Pixel * prDst = prSrc;	

    // --- fill first cache line from image first line ---
    prCell = prLine[0] + halfW;
    for (x=0; x<w; x++, prSrc++, prCell++)
      elxLuminocity(*prSrc, *prCell);
    
    for (x=0; x<halfW; x++, prCell++)
    {
      prLine[0][x] = prLine[0][halfW];  // duplicate cell on the left
      *prCell = prCell[-1]; // duplicate cell on the right
    }

    // --- duplicate first cached line into halfH next lines ---
    for (y=1; y<1+halfH; y++)
      ::memcpy(prLine[y], prLine[0], byteLineSize);

    // --- fill next halfH-1 line into cache ---
    for (y=1+halfH; y<lastLine; y++)
    {
      prCell = prLine[y] + halfW;
      for (x=0; x<w; x++, prSrc++, prCell++)
        elxLuminocity(*prSrc, *prCell);
      
      for (x=0; x<halfW; x++, prCell++)
      {
        prLine[y][x] = prLine[y][halfW];  // duplicate cell on the left
        *prCell = prCell[-1]; // duplicate cell on the right
      }
    }

    // --- process all lines ---
    for (y=0; y<h; y++)
    {
      // --- fill last line of window cache ---
      if (y >= h-halfH)
      {
        // next line is duplicated of last converted
        ::memcpy(prLine[lastLine], prLine[lastLine-1], byteLineSize);
      }
      else
      {
        // converts from source
        prCell = prLine[lastLine] + halfW;
        for (x=0; x<w; x++, prSrc++, prCell++)
          elxLuminocity(*prSrc, *prCell);

        for (x=0; x<halfW; x++, prCell++)
        {
          prLine[lastLine][x] = prLine[lastLine][halfW];  // duplicate cell on the left
          *prCell = prCell[-1]; // duplicate cell on the right
        }
      }

      // --- process a line ---
      for (x=0; x<w; x++)
      {
        for (j=0; j<mH; j++)
          prL[j] = prLine[j] + x;

        // fill list of cells to sort
        prMask = prMaskBegin;
        k = 0;
        for (j=0; j<mH; j++)
          for (i=0; i<mW; i++)
            if (0 != *prMask++)
              spCellList[k++] = *(prL[j]+i);

        // --- Shell Sort algorithm with count items ---
        elxShellSort(spCellList.get(), count, sortIncrement);

        // --- saves median according channel filter ---
        Pixel& Median = spCellList[median]._pixel;
        if (bNoMasking)
        {
          *prDst = Median;
        }
        else
        {
          for (c=0; c<nChannel; c++)
            if (elxUseChannel(c, iChannelMask))
              prDst->_channel[c] = Median._channel[c];
        }
        prDst++;
      }

      // --- next line ---
      prCell = prLine[0];
      for (j=0; j<lastLine; j++)
        prLine[j] = prLine[j+1];
      prLine[lastLine] = prCell;

      // --- in progress ... ---
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }
  }
  while (--iIteration > 0);

  // --- progress end ---
  iNotifier.SetProgress(1.0f);
  return true;

} // ApplyMedianByLuminance


//----------------------------------------------------------------------------
// Specialization for pixel's types where Median does not make sense. 
//                            NOT_IMPLEMENTED 
//----------------------------------------------------------------------------
#ifdef elxUSE_ImageComplex
template <>
bool ImageMorphologicalProcessingImpl< PixelComplexi >::ApplyMedianByLuminance(
    ImageImpl< PixelComplexi >&, const ImageLub*, uint32, uint32, ProgressNotifier&)
{ return false; }

template <>
bool ImageMorphologicalProcessingImpl< PixelComplexf >::ApplyMedianByLuminance(
    ImageImpl< PixelComplexf >&, const ImageLub*, uint32,uint32, ProgressNotifier&)
{ return false; }

template <>
bool ImageMorphologicalProcessingImpl< PixelComplexd >::ApplyMedianByLuminance(
    ImageImpl< PixelComplexd >&, const ImageLub*, uint32, uint32, ProgressNotifier&)
{ return false; }
#endif

} // namespace Image
} // namespace eLynx

#endif // __MedianSquaredByLuminance_hpp__
