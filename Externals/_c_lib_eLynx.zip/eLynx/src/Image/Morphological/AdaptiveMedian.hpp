//============================================================================
//  Morphological/AdaptiveMedian.hpp�           ���    Image.Component package
//============================================================================ 
//  Refers to "Salt-and-Pepper Noise Removal by Median-type Noise Detectors 
//             and Detail-preserving Regularization"
//  http://www.math.cuhk.edu.hk/~rchan/paper/impulse/impulse.pdf
//============================================================================ 
//� Copyright (C) 2006 by eLynx project
//
//� This library is free software; you can redistribute it and/or
//� modify it under the terms of the GNU Library General Public
//� License as published by the Free Software Foundation; either 
//� version 2 of the License, or (at your option) any later version.
//
//� This library is distributed in the hope that it will be useful,
//� but WITHOUT ANY WARRANTY; without even the implied warranty of
//� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//� See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Morphological_AdaptiveMedian_hpp__
#define __Morphological_AdaptiveMedian_hpp__

#include <elx/core/CoreSort.h>

namespace eLynx {
namespace Image { 

//#define DEBUG_CANDIDATE

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//������������������� static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//----------------------------------------------------------------------------
//�ApplyAdaptiveMedian: 
//----------------------------------------------------------------------------
//� optimizations :
//� -Transformation inplace ie without allocated another image of same size
//� -Type conversion for all image is done once (CPU).
//---------------------------------------------------------------------------- 
//� public static
//----------------------------------------------------------------------------
//� In� : ImageImpl<Pixel>& ioImage: image to process
//������� int32 iWMax: Max width of the squared median window 
//������� ProgressNotifier& iNotifier : default is 0
//� Out : bool 
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageMorphologicalProcessingImpl<Pixel>::ApplyAdaptiveMedian(
    ImageImpl<Pixel>& ioImage,
    uint32 iWMax, 
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) 
    return false; 

  // we must check W
  if ((iWMax & 1) == 0)
    return false;

  // We start with window size = 3
  const uint32 wMin = (iWMax > 3) ? 3 : iWMax;
  const uint32 halfW = iWMax/2;
  const uint32 lastLine = iWMax-1;
  const uint32 total = iWMax*iWMax;
  const uint32 wImage = ioImage.GetWidth();
  const uint32 hImage = ioImage.GetHeight();

  // --- inits progress ---
  const float ProgressStep = (float)iIteration / (float)hImage;
  float Progress = 0.0f;
  iNotifier.SetProgress(Progress);

  typedef Pixel Pixel_t;
  typedef typename Pixel_t::type T; 

  // optimizations
  // --- creates a cached window of H lines of width+(W/2)*2 
  // (+(W/2)*2 = pixels on border, W/2 left, W/2 right)
  const uint32 lineSize = wImage + 2*halfW;
  const uint32 byteLineSize = lineSize*sizeof(LuminanceCell<Pixel_t>);  

  boost::scoped_array< LuminanceCell<Pixel_t> > spWindow( new LuminanceCell<Pixel_t> [iWMax*lineSize] );
  if (NULL == spWindow.get())
    return false; 

  // --- compute max increment to be used in shell sort
  uint32 sortIncrement = 1;
  for (; sortIncrement <= (total-2)/9; sortIncrement = 3*sortIncrement +1);

  // --- inits variables ---
  uint32 x,y,i,j, w;
  uint32 square, minIdx,medIdx,maxIdx; 
  T Smin,Smed,Smax,Yij;

  LuminanceCell<Pixel_t> * prCell;
  boost::scoped_array< LuminanceCell<Pixel_t> > spCellList( new LuminanceCell<Pixel_t>[total] );
  boost::scoped_array< LuminanceCell<Pixel_t>* > spPointerList( new LuminanceCell<Pixel_t>* [2*iWMax] );  

  // init line start of cache
  LuminanceCell<Pixel_t> ** prStartLine = &spPointerList[0];
  LuminanceCell<Pixel_t> ** prL = &spPointerList[iWMax];
  for (y=0; y<iWMax; y++)
    prStartLine[y] = spWindow.get() + y*lineSize; 

  Pixel_t * prSrc = ioImage.GetPixel();
  Pixel_t * prDst = prSrc;

  // --- fill first cache line from image first line ---
  prCell = prStartLine[0] + halfW;
  for (x=0; x<wImage; x++, prSrc++, prCell++)
    elxLuminocity(*prSrc, *prCell);

  for (x=0; x<halfW; x++, prCell++)
  {
    prStartLine[0][x] = prStartLine[0][halfW]; // duplicate cell on the left
    *prCell = prCell[-1]; // duplicate cell on the right
  }

  // --- duplicate first cached line into halfW next lines ---
  for (y=1; y<1+halfW; y++)
    ::memcpy(prStartLine[y], prStartLine[0], byteLineSize);

  // --- fill next halfW-1 line into cache ---
  for (y=1+halfW; y<iWMax-1; y++)
  {
    prCell = prStartLine[y] + halfW;
    for (x=0; x<wImage; x++, prSrc++, prCell++)
      elxLuminocity(*prSrc, *prCell);

    for (x=0; x<halfW; x++, prCell++)
    {
      prStartLine[y][x] = prStartLine[y][halfW]; // duplicate cell on the left
      *prCell = prCell[-1]; // duplicate cell on the right
    }
  }

  // --- process all lines ---
  for (y=0; y<hImage; y++)
  {
    // --- fill last line of window cache ---
    if (y >= hImage-halfW)
    {
      // next line is duplicated of last converted
      ::memcpy(prStartLine[lastLine], prStartLine[lastLine-1], byteLineSize);
    }
    else
    {
      // converts from source
      prCell = prStartLine[lastLine] + halfW;
      for (x=0; x<wImage; x++, prSrc++, prCell++) 
        elxLuminocity(*prSrc, *prCell); 

      for (x=0; x<halfW; x++, prCell++)
      {
        prStartLine[lastLine][x] = prStartLine[lastLine][halfW]; // duplicate cell on the left
        *prCell = prCell[-1]; // duplicate cell on the right
      }
    } 

    // --- process a line ---
    for (x=0; x<wImage; x++)
    {
      //�1 - initial window's size to minimun = 3
      w = wMin;
      do
      {
        square = w*w;
        minIdx = 0;
        medIdx = square/2;
        maxIdx = square-1;

        for (j=0; j<w; j++) 
          prL[j] = prStartLine[j + (iWMax - w) / 2] + x;

        // 2 - compute Smin,w Smed,w and Smax,w

        // fill list of cells to sort
        for (j=0; j<w; j++)
          for (i=0; i<w; i++)
            spCellList[j*w + i] = *(prL[j]+i);

        // current pixel is unsorted median
        Yij = spCellList[medIdx]._luminance;

        // --- Shell sort algorithm with w*w items ---
        elxShellSort(spCellList.get(), square, sortIncrement);

        Smin = spCellList[minIdx]._luminance;
        Smed = spCellList[medIdx]._luminance;
        Smax = spCellList[maxIdx]._luminance;

        // 3 - Smin < Smed < Smax
        if ((Smin < Smed) && (Smed < Smax))
        {
          if ((Smin < Yij) && (Yij < Smax))
          {
            // not a noise candidate, keep value
            prDst++;
          }
          else 
          {
            // ### noise candidate ###
#ifdef DEBUG_CANDIDATE
            // just put it red to see noise candidate detection on image
            ((T*)prDst)[0]=255; ((T*)prDst)[1]=0; ((T*)prDst)[2]=0;
            prDst++;
#else
            *prDst++ = spCellList[medIdx]._pixel;
#endif
          }
          break;
        }
        else
        {
          // increase the window size
          w += 2; 
        }
        if (w > iWMax)
        {
          // ### noise candidate ###
#ifdef DEBUG_CANDIDATE
          // just put it green to see noise candidate detection on image
          ((T*)prDst)[0]=0; ((T*)prDst)[1]=255; ((T*)prDst)[2]=0;
          prDst++;
#else
          *prDst++ = spCellList[medIdx]._pixel; 
#endif
        }
      }
      while (w <= iWMax); 
    } 

    // --- next line ---
    prCell = prStartLine[0];
    for (j=0; j<lastLine; j++)
      prStartLine[j] = prStartLine[j+1];
    prStartLine[lastLine] = prCell; 

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // --- progress end ---
  iNotifier.SetProgress(Progress);
  return true;

} // ApplyAdaptiveMedian 

//----------------------------------------------------------------------------
// Specialization for pixel's types where Median does not make sense. 
//                            NOT_IMPLEMENTED 
//----------------------------------------------------------------------------
#ifdef elxUSE_ImageComplex
template <>
bool ImageMorphologicalProcessingImpl< PixelComplexi >::ApplyAdaptiveMedian(
    ImageImpl< PixelComplexi >& ioImage, uint32 iWMax, 
    uint32 iIteration, uint32 iChannelMask, ProgressNotifier& iNotifier) 
{ return false; }

template <> 
bool ImageMorphologicalProcessingImpl< PixelComplexf >::ApplyAdaptiveMedian(
    ImageImpl< PixelComplexf >& ioImage, uint32 iWMax, 
	uint32 iIteration, uint32 iChannelMask, ProgressNotifier& iNotifier) 
{ return false; }

template <> 
bool ImageMorphologicalProcessingImpl< PixelComplexd >::ApplyAdaptiveMedian(
    ImageImpl<PixelComplexd>& ioImage, uint32 iWMax, 
    uint32 iIteration, uint32 iChannelMask, ProgressNotifier& iNotifier) 
{ return false; }
#endif

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageMorphological implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ApplyAdaptiveMedian: 
//----------------------------------------------------------------------------
//  public virtual from IImageMorphologicalProcessing
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        ProgressNotifier& iNotifier : default is 0
//  Out : bool 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageMorphologicalProcessingImpl<Pixel>::ApplyAdaptiveMedian(
			AbstractImage& ioImage,
      uint32 iWMax, 
      uint32 iIteration, 
      uint32 iChannelMask,
      ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ApplyAdaptiveMedian(image, iWMax, iIteration, iChannelMask, iNotifier);

} // ApplyAdaptiveMedian

} // namespace Image
} // namespace eLynx

#endif // __Morphological_AdaptiveMedian_hpp__
