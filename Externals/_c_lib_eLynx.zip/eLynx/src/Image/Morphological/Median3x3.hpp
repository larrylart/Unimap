//============================================================================
//  Morphological/Median3x3.hpp                      Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Morphological_Median3x3_hpp__
#define __Morphological_Median3x3_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ApplyMedian3x3: 
//----------------------------------------------------------------------------
//  optimizations :
//  -Transformation inplace ie without allocated another image of same size (low memory cost)
//  -Luminosity computation for all image is done once (CPU). 
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        uint32 iIteration : default is 1
//        ProgressNotifier& iNotifier : default is 0
//  Out : bool 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageMorphologicalProcessingImpl<Pixel>::ApplyMedian3x3(
    ImageImpl<Pixel>& ioImage,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask) || (0 == iIteration)) return true;
	  
  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();

  // --- inits progress ---
  const float ProgressStep = (float)iIteration / (float)h;
  float Progress = 0.0f;
  iNotifier.SetProgress(Progress);

  // optimizations
  // --- creates a cached window of 3 lines of width+2 (+2 = pixels on border, one left, one right)
  const uint32 lineSize = w+2;
  const uint32 byteLineSize = lineSize*sizeof(LuminanceCell<Pixel>);
  LuminanceCell<Pixel> * plWindow = new LuminanceCell<Pixel_t> [3*lineSize];
  if (NULL == plWindow)
    return false;
			
  // --- inits variables ---
  uint32 x,y;
  LuminanceCell<Pixel> * prL0, * prL1, * prL2;
  LuminanceCell<Pixel> * prLine0 = plWindow;
  LuminanceCell<Pixel> * prLine1 = prLine0 + lineSize;
  LuminanceCell<Pixel> * prLine2 = prLine1 + lineSize;
  LuminanceCell<Pixel> * prCell, List[9];

  // loop over iterations
  do
  {
    Pixel_t * prSrc = ioImage.GetPixel();
    Pixel_t * prDst = prSrc;	
  	
    // --- fill first two lines duplicating image's first one ---
    prCell = prLine0 + 1;
    for (x=0; x<w; x++, prSrc++, prCell++)
      elxLuminocity(*prSrc, *prCell);
    
    *prCell = prCell[-1]; // duplicate pixel on the right
    prLine0[0] = prLine0[1]; // duplicate pixel on the left

    // --- duplicates first line in second line ---
    ::memcpy(prLine1, prLine0, byteLineSize);

    // --- process all lines ---
    for (y=0; y<h; y++)
    {
      // --- fill last line of window ---
      if (y == h-1)
      {
        // last line, just duplicates line1
        ::memcpy(prLine2, prLine1, lineSize);
      }
      else
      {
        // converts from source
        prCell = prLine2 + 1;
        for (x=0; x<w; x++, prSrc++, prCell++)
          elxLuminocity(*prSrc, *prCell);
       
        *prCell = prCell[-1]; // duplicate pixel on the right
        prLine2[0] = prLine2[1]; // duplicate pixel on the left
      }

      // --- process a line ---
      prL0 = prLine0;
      prL1 = prLine1;
      prL2 = prLine2;

      for (x=0; x<w; x++, prL0++, prL1++, prL2++)
      {
        List[0] = prL0[0];  List[1] = prL0[1]; List[2] = prL0[2];
        List[3] = prL1[0];  List[4] = prL1[1]; List[5] = prL1[2];
        List[6] = prL2[0];  List[7] = prL2[1]; List[8] = prL2[2];

        // Insertion Sort algorithm with 9 items
        elxInsertionSort(List);

        // saves median color
        *prDst++ = List[4]._pixel;
      }

      // --- next line ---
      prCell  = prLine0;
      prLine0 = prLine1;
      prLine1 = prLine2;
      prLine2 = prCell;

      // --- in progress ... ---
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }
  }
  while (--iIteration > 0);

  // --- progress end ---
  iNotifier.SetProgress(1.0f);

  // --- window no need anymore ---
  elxSAFE_DELETE_LIST(plWindow);
  return true;

} // ApplyMedian3x3


//----------------------------------------------------------------------------
// Specialization for pixel's types where Median does not make sense. 
//                            NOT_IMPLEMENTED 
//----------------------------------------------------------------------------
#ifdef elxUSE_ImageComplex
template <>
bool ImageMorphologicalProcessingImpl< PixelComplexi >::ApplyMedian3x3(
  ImageImpl< PixelComplexi >&, uint32, uint32, ProgressNotifier&)
{ return false; }

template <> 
bool ImageMorphologicalProcessingImpl< PixelComplexf >::ApplyMedian3x3(
  ImageImpl< PixelComplexf >&, uint32, uint32, ProgressNotifier&)
{ return false; }

template <>
bool ImageMorphologicalProcessingImpl< PixelComplexd >::ApplyMedian3x3(
  ImageImpl< PixelComplexd >&, uint32, uint32, ProgressNotifier&)
{ return false;}
#endif

//----------------------------------------------------------------------------
//  ApplyMedian3x3: 
//----------------------------------------------------------------------------
//  optimizations :
//  -Transformation inplace ie without allocated another image of same size (low memory cost)
//  -Luminosity computation for all image is done once (CPU). 
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        uint32 iIteration : default is 1
//        ProgressNotifier& iNotifier : default is 0
//  Out : bool 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageMorphologicalProcessingImpl<Pixel>::ApplyMedian3x3(
    ImageImpl<Pixel>& ioImage,
    const ImageLub& iImageMask,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask) || (0 == iIteration)) return true;
	  
  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  // check that mask has same dimension as image
  if ((w != iImageMask.GetWidth()) || (h != iImageMask.GetHeight()))
    return false;

  // --- inits progress ---
  const float ProgressStep = (float)iIteration / (float)h;
  float Progress = 0.0f;
  iNotifier.SetProgress(Progress);

  // optimizations
  // --- creates a cached window of 3 lines of width+2 (+2 = pixels on border, one left, one right)
  const uint32 lineSize = w+2;
  const uint32 byteLineSize = lineSize*sizeof(LuminanceCell<Pixel>);
  LuminanceCell<Pixel> * plWindow = new LuminanceCell<Pixel_t> [3*lineSize];
  if (NULL == plWindow)
    return false;
			
  // --- inits variables ---
  uint32 x,y;
  LuminanceCell<Pixel> * prL0, * prL1, * prL2;
  LuminanceCell<Pixel> * prLine0 = plWindow;
  LuminanceCell<Pixel> * prLine1 = prLine0 + lineSize;
  LuminanceCell<Pixel> * prLine2 = prLine1 + lineSize;
  LuminanceCell<Pixel> * prCell, List[9];

  // loop over iterations
  do
  {
    const uint8 * prMask = iImageMask.GetSamples();
    Pixel_t * prSrc = ioImage.GetPixel();
    Pixel_t * prDst = prSrc;	
  	
    // --- fill first two lines duplicating image's first one ---
    prCell = prLine0 + 1;
    for (x=0; x<w; x++, prSrc++, prCell++)
      elxLuminocity(*prSrc, *prCell);
    
    *prCell = prCell[-1]; // duplicate pixel on the right
    prLine0[0] = prLine0[1]; // duplicate pixel on the left

    // --- duplicates first line in second line ---
    ::memcpy(prLine1, prLine0, byteLineSize);

    // --- process all lines ---
    for (y=0; y<h; y++)
    {
      // --- fill last line of window ---
      if (y == h-1)
      {
        // last line, just duplicates line1
        ::memcpy(prLine2, prLine1, lineSize);
      }
      else
      {
        // converts from source
        prCell = prLine2 + 1;
        for (x=0; x<w; x++, prSrc++, prCell++)
          elxLuminocity(*prSrc, *prCell);
       
        *prCell = prCell[-1]; // duplicate pixel on the right
        prLine2[0] = prLine2[1]; // duplicate pixel on the left
      }

      // --- process a line ---
      prL0 = prLine0;
      prL1 = prLine1;
      prL2 = prLine2;

      for (x=0; x<w; x++, 
        prL0++, prL1++, prL2++, prDst++, prMask++)
      {
        if (*prMask)
        {
          List[0] = prL0[0];  List[1] = prL0[1]; List[2] = prL0[2];
          List[3] = prL1[0];  List[4] = prL1[1]; List[5] = prL1[2];
          List[6] = prL2[0];  List[7] = prL2[1]; List[8] = prL2[2];

          // Insertion Sort algorithm with 9 items
          elxInsertionSort(List);

          // saves median color
          *prDst = List[4]._pixel;
        }
      }

      // --- next line ---
      prCell  = prLine0;
      prLine0 = prLine1;
      prLine1 = prLine2;
      prLine2 = prCell;

      // --- in progress ... ---
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }
  }
  while (--iIteration > 0);

  // --- progress end ---
  iNotifier.SetProgress(1.0f);

  // --- window no need anymore ---
  elxSAFE_DELETE_LIST(plWindow);
  return true;

} // ApplyMedian3x3


//----------------------------------------------------------------------------
// Specialization for pixel's types where Median does not make sense. 
//                            NOT_IMPLEMENTED 
//----------------------------------------------------------------------------
#ifdef elxUSE_ImageComplex
template <>
bool ImageMorphologicalProcessingImpl< PixelComplexi >::ApplyMedian3x3(
  ImageImpl< PixelComplexi >&,const ImageLub&, uint32, uint32, ProgressNotifier&)
{ return false; }

template <> 
bool ImageMorphologicalProcessingImpl< PixelComplexf >::ApplyMedian3x3(
  ImageImpl< PixelComplexf >&,const ImageLub&, uint32, uint32, ProgressNotifier&)
{ return false; }

template <>
bool ImageMorphologicalProcessingImpl< PixelComplexd >::ApplyMedian3x3(
  ImageImpl< PixelComplexd >&,const ImageLub&, uint32, uint32, ProgressNotifier&)
{ return false;}
#endif

} // namespace Image
} // namespace eLynx

#endif // __Morphological_Median3x3_hpp__
