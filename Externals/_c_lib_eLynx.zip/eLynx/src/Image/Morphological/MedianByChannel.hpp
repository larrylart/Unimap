//============================================================================
//  Morphological/MedianByChannel.hpp                  Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __MedianByChannel_hpp__
#define __MedianByChannel_hpp__

#include <elx/core/CoreSort.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplyMedianByChannel: 
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageMorphologicalProcessingImpl<Pixel>::ApplyMedianByChannel(
    ImageImpl<Pixel>& ioImage,
    const ImageLub * iprMask,
    uint32 iIteration,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask) || (0 == iIteration)) return true;

  // we must check mask dimensions
  const uint32 mW = iprMask->GetWidth();
  const uint32 mH = iprMask->GetHeight();
  if (((mW & 1) == 0) || ((mH & 1) == 0)) return false;

  const uint32 nChannel = Pixel_t::GetChannelCount();

  typedef int32 (*fnComparator)(const void*, const void*);
  fnComparator PixelCmp[4] =
  {
    elxComparePixel<Pixel, 0>, // compare based on channel 0 sample value
    elxComparePixel<Pixel, 1>, // compare based on channel 1 sample value
    elxComparePixel<Pixel, 2>, // compare based on channel 2 sample value
    elxComparePixel<Pixel, 3>  // compare based on channel 3 sample value
  };

  const uint32 halfW = mW/2;
  const uint32 halfH = mH/2;
  const uint32 lastLine = mH-1;
  const uint32 total = mW*mH;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
	
  // --- inits progress ---
  const float ProgressStep = (float)iIteration / (float)h;
  float Progress = 0.0f;
  iNotifier.SetProgress(Progress);

  // --- optimizations based on cache window to compute luminance once for each pixels
  const uint32 lineSize = w + 2*halfW;
  const uint32 byteLineSize = lineSize*sizeof(Pixel);

  boost::scoped_array< Pixel > spWindow( new Pixel[mH*lineSize] );
  if (NULL == spWindow.get()) return false;

  // --- inits variables ---
  uint32 x,y,i,j,k,c;

  // count active pixels in mask
  uint32 count = total;
  const uint8 * prMaskBegin = iprMask->GetSamples();
  const uint8 * prMask = prMaskBegin;
  for (i=0; i<total; i++) if (*prMask++ == 0) count--;
  const uint32 median = count/2;

  Pixel * prCell;
  boost::scoped_array< Pixel > spCellList( new Pixel[count] );
  boost::scoped_array< Pixel* > spPointerList( new Pixel * [2*mH] );
  
  // loop over iterations
  do
  {
    // init line start of cache
    Pixel ** prLine = &spPointerList[0];
    Pixel ** prL = &spPointerList[mH];
    for (y=0; y<mH; y++)
      prLine[y] = spWindow.get() + y*lineSize;
    
    Pixel * prSrc = ioImage.GetPixel();
    Pixel * prDst = prSrc;	
    	
    // --- fill first cache line from image first line ---
    prCell = prLine[0] + halfW;
    for (x=0; x<w; x++, prSrc++, prCell++)
      *prCell = *prSrc;
    
    for (x=0; x<halfW; x++, prCell++)
    {
      prLine[0][x] = prLine[0][halfW];  // duplicate cell on the left
      *prCell = prCell[-1]; // duplicate cell on the right
    }

    // --- duplicate first cached line into half next lines ---
    for (y=1; y<1+halfH; y++)
      ::memcpy(prLine[y], prLine[0], byteLineSize);

    // --- fill next halfH-1 line into cache ---
    for (y=1+halfH; y<lastLine; y++)
    {
      prCell = prLine[y] + halfW;
      for (x=0; x<w; x++, prSrc++, prCell++)
        *prCell = *prSrc;
      
      for (x=0; x<halfW; x++, prCell++)
      {
        prLine[y][x] = prLine[y][halfW];  // duplicate cell on the left
        *prCell = prCell[-1]; // duplicate cell on the right
      }
    }

    // --- process all lines ---
    for (y=0; y<h; y++)
    {
      // --- fill last line of window cache ---
      if (y >= h-halfH)
      {
        // next line is duplicated of last converted
        ::memcpy(prLine[lastLine], prLine[lastLine-1], byteLineSize);
      }
      else
      {
        prCell = prLine[lastLine] + halfW;
        for (x=0; x<w; x++, prSrc++, prCell++)
          *prCell = *prSrc;

        for (x=0; x<halfW; x++, prCell++)
        {
          prLine[lastLine][x] = prLine[lastLine][halfW];  // duplicate cell on the left
          *prCell = prCell[-1]; // duplicate cell on the right
        }
      }

      // --- process a line ---
      for (x=0; x<w; x++)
      {
        for (j=0; j<mH; j++)
          prL[j] = prLine[j] + x;

        // fill list of cells to sort
        prMask = prMaskBegin;
        k = 0;
        for (j=0; j<mH; j++)
          for (i=0; i<mW; i++)
            if (0 != *prMask++)
              spCellList[k++] = *(prL[j]+i);

        // --- saves median according channel filter ---
        for (c=0; c<nChannel; c++)
        {
          if (elxUseChannel(c, iChannelMask))
          {
            ::qsort(spCellList.get(), count, sizeof(Pixel), *PixelCmp[c]);
            prDst->_channel[c] = spCellList[median]._channel[c];
          }
        }
        prDst++;
      }

      // --- next line ---
      prCell = prLine[0];
      for (j=0; j<lastLine; j++)
        prLine[j] = prLine[j+1];
      prLine[lastLine] = prCell;

      // --- in progress ... ---
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }
  }
  while (--iIteration > 0);

  // --- progress end ---
  iNotifier.SetProgress(1.0f);
  return true;

} // ApplyMedianByChannel


//----------------------------------------------------------------------------
// Specialization for pixel's types where Median does not make sense. 
//                            NOT_IMPLEMENTED 
//----------------------------------------------------------------------------
#ifdef elxUSE_ImageComplex
template <>
bool ImageMorphologicalProcessingImpl< PixelComplexi >::ApplyMedianByChannel(
    ImageImpl< PixelComplexi >&, const ImageLub*, uint32, uint32, ProgressNotifier&)
{ return false; }

template <>
bool ImageMorphologicalProcessingImpl< PixelComplexf >::ApplyMedianByChannel(
    ImageImpl< PixelComplexf >&, const ImageLub*, uint32, uint32, ProgressNotifier&)
{ return false; }

template <>
bool ImageMorphologicalProcessingImpl< PixelComplexd >::ApplyMedianByChannel(
    ImageImpl< PixelComplexd >&, const ImageLub*, uint32, uint32, ProgressNotifier&)
{ return false; }
#endif

} // namespace Image
} // namespace eLynx

#endif // __MedianByChannel_hpp__
