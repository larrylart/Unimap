//============================================================================
//  ImageRestorationImpl.cpp                           Image.Component package
//============================================================================
//  Usage : image misceallenous processing interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/ImageRestorationImpl.h>

#include "Restoration/FastInpainting.hpp"
#include "Restoration/MarchingInpainting.hpp"
#include "Restoration/ExemplarInpainting.hpp"

namespace eLynx {
namespace Image {

IImageRestoration::~IImageRestoration() {}

namespace {

//----------------------------------------------------------------------------
//  elxCreateInpaintMask
//----------------------------------------------------------------------------
boost::shared_ptr<ImageLub> elxCreateInpaintMask(const ImageLub& iBinaryMask)
{
  const uint32 w = iBinaryMask.GetWidth();
  const uint32 h = iBinaryMask.GetHeight();

  // create a inpainting image with same dimensions
  boost::shared_ptr<ImageLub> spImage( new ImageLub(w,h) );

  // fill inpainting image
  const uint8 * prSrc = iBinaryMask.GetSamples();
  uint8 * prDst = spImage->GetSamples();
  uint8 * prEnd = spImage->GetSamplesEnd();
  do 
  { 
    // 0=IPT_KNOWN, 255=IPT_UNKNOWN
    *prDst = (*prSrc++) ? IPT_UNKNOWN : IPT_KNOWN; 
  } 
  while (++prDst != prEnd);

  return spImage;

} // elxCreateInpaintMask

//----------------------------------------------------------------------------
//  elxScanInpaintRegions
//----------------------------------------------------------------------------
bool elxScanInpaintRegions(ImageLub& ioInpaintMask,
    std::vector<Math::AOBBox2i>& oRegions)
{
  const int32 w = ioInpaintMask.GetWidth();
  const int32 h = ioInpaintMask.GetHeight();

  // Get inpaint regions
  uint8 * prBitmap = ioInpaintMask.GetSamples();
  OperatorScanRegion scanRegion(prBitmap, w);

  int32 x,y;
  Math::AOBBox2i box;
  uint8 * prSrc = prBitmap;
  
  for (y=0; y<h; y++)
    for (x=0; x<w; x++, prSrc++)
    {
      if (elxIPT_IS_SEEN(*prSrc))
        continue;
      if (elxIPT_IS_KNOWN(*prSrc))
      {
        elxIPT_SET_SEEN(*prSrc);
      }
      else
      {
        // scan for region
        scanRegion.Init(x,y);
        elxProcessScan2i(w, h, prBitmap, x,y, scanRegion);

        // expand bounding box to 1 pixel in all directions when possible
        scanRegion.GetBBox(box);
        if (box._w < w) box._w++;
        if (box._h < h) box._h++;
        if (box._x > 0) box._x--;
        if (box._y > 0) box._y--;

        // add in region list
        oRegions.push_back(box);
      }
    }

  return (oRegions.size() > 0);

} // elxScanInpaintRegions

//----------------------------------------------------------------------------
//  elxFillBoundary
//----------------------------------------------------------------------------
bool elxFillBoundary(ImageLub& ioInpaintMask)
{
  const int32 w = (int32)ioInpaintMask.GetWidth();
  const int32 h = (int32)ioInpaintMask.GetHeight();
  const int32 w1 = w-1;
  const int32 h1 = h-1;

  uint8 * prBitmap = ioInpaintMask.GetSamples();
  uint8 * prSrc = prBitmap;
  int32 nBoundary = 0;  
  int32 x,y;
  for (y=0; y<h; y++)
    for (x=0; x<w; x++, prSrc++)
    {
      // criteria to be in boundaries
      if (elxIPT_IS_UNKNOWN(*prSrc))
      {
        if ( (x>0 && elxIPT_IS_KNOWN(prSrc[-1])) ||
             (x<w1 && elxIPT_IS_KNOWN(prSrc[+1])) ||
             (y>0 && elxIPT_IS_KNOWN(prSrc[-w])) ||
             (y<h1 && elxIPT_IS_KNOWN(prSrc[+w])) )
        {
          elxIPT_SET_BOUNDARY(*prSrc);
          nBoundary++;
        }
      }
    }

  return (nBoundary > 0);

} // elxFillBoundary

//----------------------------------------------------------------------------
// elxInitBoundary: Initialize initial boundary of the inpainting region
//----------------------------------------------------------------------------
void elxInitBoundary(uint8* ioBinaryMask, int32 iW, int32 iH, 
    std::deque<Math::Point2i>& oNarrowBand)
{
  for (int32 i = 0, idx = 0; i < iH; ++i)
    for (int32 j = 0; j < iW; ++j, ++idx)
      if (elxIPT_IS_KNOWN(ioBinaryMask[idx]))
        if (((j-1) >= 0 && elxIPT_IS_UNKNOWN(ioBinaryMask[idx-1])) || 
            ((j+1) < iW && elxIPT_IS_UNKNOWN(ioBinaryMask[idx+1])) ||
            ((i-1) >= 0 && elxIPT_IS_UNKNOWN(ioBinaryMask[idx-iW])) ||
            ((i+1) < iH && elxIPT_IS_UNKNOWN(ioBinaryMask[idx+iW])))
        {
          oNarrowBand.push_back(Math::Point2i(j, i));
          elxIPT_SET_BOUNDARY(ioBinaryMask[idx]);
        }
} //elxInitBoundary

} // namespace

//----------------------------------------------------------------------------
//  explicit instantiation of all image types
//----------------------------------------------------------------------------
elxINSTANTIATE_CLASS_FOR_ALL_IMAGE_TYPES( ImageRestorationImpl );

} // namespace Image
} // namespace eLynx
