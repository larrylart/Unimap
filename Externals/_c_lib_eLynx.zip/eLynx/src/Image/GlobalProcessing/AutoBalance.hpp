//============================================================================
//  GlobalProcessing/AutoBalance.hpp                   Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __GlobalProcessing_AutoBalance_hpp__
#define __GlobalProcessing_AutoBalance_hpp__

#include <elx/image/ImagePointProcessingImpl.h>

namespace eLynx {
namespace Image {

namespace {
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  elxComputeAutoBalance # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <class Pixel>
bool elxComputeAutoBalance(
    const ImageImpl<Pixel>& iImage,
    double& oR, double& oG, double& oB)
{
  oR = oG = oB = 1.0;
  return false;

} // elxComputeAutoBalance # ImageImpl<Pixel>


//----------------------------------------------------------------------------
//  elxComputeAutoBalance # ImageImpl< PixelRGB<T> >
//----------------------------------------------------------------------------
template <typename T>
bool elxComputeAutoBalance(
    const ImageImpl< PixelRGB<T> >& iImage,
    double& oR, double& oG, double& oB)
{
  if (!iImage.IsValid())
    return false;

  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  // search for highest luminance and concider it as pure white.
  const PixelRGB<T> * prSrc = iImage.GetPixel();
  const PixelRGB<T> * prEnd = iImage.GetPixelEnd();
  PixelRGB<T> PMax;
  M l, lMax = 0;
  do
  {
    // CGC_CCIR_709 luminance L = 0.2125*r + 0.7154*g + 0.0721*b
    l = 2125*prSrc->_red + 7154*prSrc->_green + 0721*prSrc->_blue;
    if (l > lMax)
    {
      lMax = l;
      PMax = *prSrc;
    }
  } 
  while (++prSrc != prEnd);
  
  // Get max channel
  const T r = PMax._red;
  const T g = PMax._green;
  const T b = PMax._blue;
  const T m = Math::elxMax(r,g,b);
  if (m == g)
  {
    // g is max
    oG = 1.0;
    oR = (r != T(0)) ? double(g) / double(r) : 1.0;
    oB = (b != T(0)) ? double(g) / double(b) : 1.0;
  }
  else if (m == r)
  {
    // r is max
    oR = 1.0;
    oG = (g != T(0)) ? double(r) / double(g) : 1.0;
    oB = (b != T(0)) ? double(r) / double(b) : 1.0;
  }
  else
  {
    // b is max
    oB = 1.0;
    oR = (r != T(0)) ? double(b) / double(r) : 1.0;
    oG = (g != T(0)) ? double(b) / double(g) : 1.0;
  }
  return true;

} // elxComputeAutoBalance # ImageImpl< PixelRGB<T> >


//----------------------------------------------------------------------------
//  elxComputeAutoBalance # ImageImpl< PixelRGBA<T> >
//----------------------------------------------------------------------------
template <typename T>
bool elxComputeAutoBalance(
    const ImageImpl< PixelRGBA<T> >& iImage,
    double& oR, double& oG, double& oB)
{
  if (!iImage.IsValid())
    return false;

  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  // search for highest luminance and concider it as pure white.
  const PixelRGBA<T> * prSrc = iImage.GetPixel();
  const PixelRGBA<T> * prEnd = iImage.GetPixelEnd();
  PixelRGBA<T> PMax;
  M l, lMax = 0;
  do
  {
    // CGC_CCIR_709 luminance L = 0.2125*r + 0.7154*g + 0.0721*b
    l = 2125*prSrc->_red + 7154*prSrc->_green + 0721*prSrc->_blue;
    if (l > lMax)
    {
      lMax = l;
      PMax = *prSrc;
    }
  } 
  while (++prSrc != prEnd);
  
  // Get max channel
  const T r = PMax._red;
  const T g = PMax._green;
  const T b = PMax._blue;
  const T m = Math::elxMax(r,g,b);
  if (m == g)
  {
    // g is max
    oG = 1.0;
    oR = (r != T(0)) ? double(g) / double(r) : 1.0;
    oB = (b != T(0)) ? double(g) / double(b) : 1.0;
  }
  else if (m == r)
  {
    // r is max
    oR = 1.0;
    oG = (g != T(0)) ? double(r) / double(g) : 1.0;
    oB = (b != T(0)) ? double(r) / double(b) : 1.0;
  }
  else
  {
    // b is max
    oB = 1.0;
    oR = (r != T(0)) ? double(b) / double(r) : 1.0;
    oG = (g != T(0)) ? double(b) / double(g) : 1.0;
  }
  return true;

} // elxComputeAutoBalance # ImageImpl< PixelRGBA<T> >

} // anonymous-namespace

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from IImageGlobalProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AutoBalance # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGlobalProcessingImpl<Pixel>::AutoBalance(
    AbstractImage& ioImage,
    ProgressNotifier& iNotifier) const
{
  if (CS_RGB != Pixel::GetColorSpace())
    return false; 

  double sR,sG,sB;
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  elxComputeAutoBalance(image, sR,sG,sB);
  return ImagePointProcessingImpl<Pixel>::Balance(
      image, sR,sG,sB, iNotifier);

} // AutoBalance # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __GlobalProcessing_AutoBalance_hpp__
