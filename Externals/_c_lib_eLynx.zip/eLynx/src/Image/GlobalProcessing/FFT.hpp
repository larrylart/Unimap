//============================================================================
//  GlobalProcessing/FFT.hpp                           Image.Component package
//============================================================================
//
//  Fast Fourier Transform for image implementation
//  
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __GlobalProcessing_FFT_hpp__
#define __GlobalProcessing_FFT_hpp__

#include <elx/image/Pixels.h>
#include "../Factory/Butterworth.hpp"

namespace eLynx {
namespace Image {

namespace {

#ifdef elxUSE_ImageComplex
//----------------------------------------------------------------------------
// elxMulInFrequencySpace : low level
// ImageComplex<T> = ImageComplex<T> * ImageL<T>
//----------------------------------------------------------------------------
template <typename T>
bool elxMulInFrequencySpace(
    ImageImpl< PixelComplex<T> >& ioImage,
    const ImageImpl< PixelL<T> >& iFilter)
{
  if (!ioImage.IsValid() || !iFilter.IsValid())
    return false;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();

  // image must have same dimensions
  if ((w != iFilter.GetWidth()) || (h != iFilter.GetHeight()))
    return false;

  const PixelL<T> * prSrc = iFilter.GetPixel();
  PixelComplex<T> * prDst = ioImage.GetPixel();
  PixelComplex<T> * prEnd = ioImage.GetPixelEnd();
  do
  {
    prDst->_re *= prSrc->_luminance;
    prDst->_im *= prSrc->_luminance;
  }
  while (++prSrc, ++prDst < prEnd);

  return true;

} // elxMulInFrequencySpace
#endif

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel> 
bool ImageGlobalProcessingImpl<Pixel>::ApplyFFT(
    ImageImpl<Pixel>& ioImage,
    const ImageImpl< PixelL<typename ResolutionTypeTraits<typename Pixel::type>::Floating_type> >& iFilter,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
#ifdef elxUSE_ImageComplex

  if (!ioImage.IsValid() || !iFilter.IsValid())
    return false;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  const uint32 w2 = Math::elxNextPow2(w);
  const uint32 h2 = Math::elxNextPow2(h);

  // filter must have image power of 2 dimensions
  if ((w2 != iFilter.GetWidth()) || (h2 != iFilter.GetHeight()))
    return false;

  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
  const EResolution resolutionT = ResolutionTypeTraits<T>::_resolution;
  const EResolution resolutionF = ResolutionTypeTraits<F>::_resolution;
  const uint32 nChannel = Pixel::GetChannelCount();

  // split image into grey planes
  ImageImpl< PixelL<T> > imageT[4];
  if (1 == nChannel)
    imageT[0] = *((ImageImpl< PixelL<T> >*)&ioImage);
  else if (2 == nChannel)
    elxSplit2(ioImage, imageT[0], imageT[1]);
  else if (3 == nChannel)
    elxSplit3(ioImage, imageT[0], imageT[1], imageT[2]);
  else if (4 == nChannel)
    elxSplit4(ioImage, imageT[0], imageT[1], imageT[2], imageT[3]);

  // process plane by plane
  for (uint32 c=0; c<nChannel; c++)
    if (elxUseChannel(c, iChannelMask))
    {
      // create image in floating point resolution (float or double)
      ImageImpl< PixelL<F> > imageF =
        *boost::dynamic_pointer_cast<ImageImpl< PixelL<F> >, AbstractImage>(
            elxCreateImage(imageT[c], resolutionF));

      // convert from time to frequency space (using FFT)
      ImageImpl< PixelComplex<F> > imageComplex =
        *boost::dynamic_pointer_cast<ImageImpl< PixelComplex<F> >, AbstractImage>(
          elxCreateComplexImage(imageF, GCC_FFT));

      // apply filter in frequency space
      // Multiplication in frequency space is convolution in time space
      elxMulInFrequencySpace(imageComplex, iFilter);

      // convert from frequency to time space (using IFFT)
      imageF = *boost::dynamic_pointer_cast< ImageImpl< PixelL<F> >, AbstractImage>(
        elxCreateGreyImage(imageComplex, CGC_IFFT));

      // remove border due size expansion to power of 2
      const uint32 x = (w2-w)/2;
      const uint32 y = (h2-h)/2;
      const bool bCrop = (x!=0) || (y!=0);
      if (bCrop) 
        ImageGeometryImpl< PixelL<F> >::Crop(imageF, x,y, w,h);

      // normalize
      ImageGlobalProcessingImpl< PixelL<F> >::Normalize(imageF);

      // get back to original resolution
      imageT[c] = *boost::dynamic_pointer_cast< ImageImpl< PixelL<T> >, AbstractImage>(
        elxCreateImage(imageF, resolutionT));
    }

  // recompose image merging planes
  if (1 == nChannel)
    ioImage = *((ImageImpl<Pixel>*)&imageT[0]);
  else if (2 == nChannel)
    elxMerge2(ioImage, imageT[0], imageT[1]);
  else if (3 == nChannel)
    elxMerge3(ioImage, imageT[0], imageT[1], imageT[2]);
  else if (4 == nChannel)
    elxMerge4(ioImage, imageT[0], imageT[1], imageT[2], imageT[3]);
  
  return true;

#else
  return false;
#endif

} // ApplyFFT


//----------------------------------------------------------------------------
//  ApplyFFTLowPass
//----------------------------------------------------------------------------
template <class Pixel> 
bool ImageGlobalProcessingImpl<Pixel>::ApplyFFTLowPass(
    ImageImpl<Pixel>& ioImage,
    double iCutoff, 
    uint32 iRank,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  const uint32 w2 = Math::elxNextPow2(w);
  const uint32 h2 = Math::elxNextPow2(h);

  // create Butterworth filter based on image size
  typedef typename ResolutionTypeTraits<typename Pixel::type>::Floating_type F;
  typedef ImageImpl< PixelL<F> > ImageLF;
  ImageLF * psFilter = elxCreateButterworth<F>(w2,h2, iCutoff, iRank);
  ImageLF& filter = elxDowncast< PixelL<F> >(*psFilter);

  // apply it
  bool bSuccess = ApplyFFT(ioImage, filter, iChannelMask, iNotifier);

  // free filter
  elxSAFE_DELETE(psFilter);
  return bSuccess;

} // ApplyFFTLowPass


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageGlobalProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel> 
bool ImageGlobalProcessingImpl<Pixel>::ApplyFFT(
    AbstractImage& ioImage,
    const AbstractImage& iFilter,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);

  // iFilter should have the floating type of the image to process
  typedef PixelL<typename ResolutionTypeTraits<typename Pixel::type>::Floating_type> Pixel_F;
  const ImageImpl<Pixel_F>& filter = elxDowncast<Pixel_F>(iFilter);

  return ApplyFFT(image, filter, iChannelMask, iNotifier);

} // ApplyFFT


//----------------------------------------------------------------------------
//  ApplyFFTLowPass
//----------------------------------------------------------------------------
template <class Pixel> 
bool ImageGlobalProcessingImpl<Pixel>::ApplyFFTLowPass(
    AbstractImage& ioImage,
    double iCutoff, 
    uint32 iRank,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ApplyFFTLowPass(image, iCutoff, iRank, iChannelMask, iNotifier);

} // ApplyFFTLowPass

} // namespace Image
} // namespace eLynx

#endif // __GlobalProcessing_FFT_hpp__
