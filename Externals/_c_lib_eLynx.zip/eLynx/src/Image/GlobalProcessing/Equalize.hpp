//============================================================================
//  GlobalProcessing/Equalize.inl                      Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __GlobalProcessing_Equalize_hpp__
#define __GlobalProcessing_Equalize_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel> 
bool ImageGlobalProcessingImpl<Pixel>::EqualizeHistogram(
    ImageImpl<Pixel>& ioImage,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  elxFIXME;
  return false;

} // EqualizeHistogram


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from IImageGlobalProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageGlobalProcessingImpl<Pixel>::EqualizeHistogram(
    AbstractImage& ioImage,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return EqualizeHistogram(image);

} // EqualizeHistogram


//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGlobalProcessingImpl<Pixel>::AutoContrast(
    AbstractImage& ioImage,
    ProgressNotifier& iNotifier) const
{ elxFIXME; return false; }

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGlobalProcessingImpl<Pixel>::AutoColor(
    AbstractImage& ioImage,
    ProgressNotifier& iNotifier) const
{ elxFIXME; return false; }

} // namespace Image
} // namespace eLynx

#endif // __GlobalProcessing_Equalize_hpp__
