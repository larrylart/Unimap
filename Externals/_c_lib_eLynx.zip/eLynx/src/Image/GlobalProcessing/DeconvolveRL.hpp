//============================================================================
//  GlobalProcessing/DeconvolveRL.hpp                  Image.Component package
//============================================================================
//  Richardson-Lucy deconvolution implementation
//  
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __GlobalProcessing_DeconvolveRL_hpp__
#define __GlobalProcessing_DeconvolveRL_hpp__

#include <boost/scoped_array.hpp>
#include <elx/image/KernelPSF.h>
#include <elx/image/ImageOperatorsImpl.h>
#include <elx/image/AbstractImageManager.h>

namespace eLynx {
namespace Image {

// should be in LocalToPoint / ConvolvePSF.inl
// should be rename as Convolve
// uint32 iTotalProgress should be removed
template <class Pixel> 
bool elxConvolveWithPSF(
    ImageImpl<Pixel> &ioImage, 
    const IImagePSF &iPSF, uint32 &ioProgress,
    uint32 iTotalProgress,
    EBorderFill iBorder, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  const KernelPSF *kpsf = dynamic_cast<const KernelPSF*>(&iPSF);
  if (kpsf != NULL) 
  {
    if (kpsf->IsSeparable()) 
    {
      elxGetLocalToPointHandler(ioImage).Convolve(ioImage, 
        kpsf->GetKernel(), kpsf->GetKernel2(), 
        BF_Nearest, 1, iChannelMask, iNotifier);
    }
    else 
    {
      elxGetLocalToPointHandler(ioImage).Convolve(ioImage, 
          kpsf->GetKernel(), false, iBorder, 1, iChannelMask, iNotifier);
    }
  }
  else 
  {
    ImageImpl<Pixel> result(ioImage.GetWidth(), ioImage.GetHeight());
    Pixel * prPixel = result.GetPixel();
    const uint32 w = ioImage.GetWidth();
    const uint32 h = ioImage.GetHeight();
    uint32 x,y;
    for (y=0; y<h; y++) 
    {
      for (x=0; x<w; x++, prPixel++) 
        elxConvolvePixelWithPSF(ioImage, iPSF, x, y, iChannelMask, *prPixel);
	
      ioProgress++;
      iNotifier.SetProgress((float)ioProgress/(float)iTotalProgress);
      if (iNotifier.IsCanceled()) return false;
    }
    ioImage = result;
  }
  return true;
}


//----------------------------------------------------------------------------
//
// should be in LocalToPoint / ConvolvePSF.inl
template <class Pixel> 
void elxConvolvePixelWithPSF(
    const ImageImpl<Pixel> &iImage, 
    const IImagePSF &iPSF, 
    uint32 iX, uint32 iY, 
    uint32 iChannelMask,
    Pixel & oResult)
{
  int32 psf_x = -(int32)iPSF.GetWidth()/2;
  int32 psf_y = -(int32)iPSF.GetHeight()/2;
	
  static boost::scoped_array<double> channels(
      new double[Pixel::GetChannelCount()]);

  for (uint32 c = 0; c < Pixel::GetChannelCount(); c++) 
    channels[c] = 0.0;
	
  for (uint32 i = 0; i < iPSF.GetHeight(); i++)
  {
    for (uint32 j = 0; j < iPSF.GetWidth(); j++) 
    {
      int32 img_x = (int32)iX+psf_x+(int32)j;
      int32 img_y = (int32)iY+psf_y+(int32)i;
			
      if (img_x >= 0 && img_y >= 0 &&
          img_x < (int32)iImage.GetWidth() && img_y < (int32)iImage.GetHeight()) 
      {
        const Pixel *value = iImage.GetPixel((uint32)img_x, (uint32)img_y);
        for (uint32 c = 0; c < Pixel::GetChannelCount(); c++)
        {
        	if (elxUseChannel(c, iChannelMask))
            channels[c] += iPSF.EvalPSF(iX, iY, psf_x, psf_y)*(double)value->_channel[c];
        }
      }
		
      for (uint32 c = 0; c < Pixel::GetChannelCount(); c++) 
        if (elxUseChannel(c, iChannelMask))
          oResult._channel[c] = (typename Pixel::type)channels[c];
    }
  }
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel> 
bool ImageGlobalProcessingImpl<Pixel>::DeconvolveRL(
    ImageImpl<Pixel>& ioImage, 
    const IImagePSF &iPSF, 
    uint32 iIterations, 
    EBorderFill iBorder, 
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  uint32 total_progress = ioImage.GetHeight()*iIterations*2;
  uint32 actual_progress = 0;
  
  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
 
  ImageImpl<Pixel> result(ioImage);
  ImageImpl<Pixel> temp(w,h);
  ImageImpl<Pixel> temp2(w,h);
	
  for (uint32 i = 0; i < iIterations; i++) 
  {
    temp = result;
		
    if (!elxConvolveWithPSF(temp, iPSF, actual_progress, total_progress, iBorder, iChannelMask, iNotifier))
      return false;
      
    temp2 = ioImage;
    if (!elxOperator(temp2, IOP_Div, temp, iChannelMask, iNotifier))
      return false;
    temp = temp2;

    if (!elxConvolveWithPSF(temp, iPSF, actual_progress, total_progress, iBorder, iChannelMask, iNotifier))
      return false;
		
    if (!elxOperator(result, IOP_Mul, temp, iChannelMask, iNotifier))
      return false;
  }
  
  ioImage = result;
  return true; 

} // DeconvolveRL


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageGlobalProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel> 
bool ImageGlobalProcessingImpl<Pixel>::DeconvolveRL(
    AbstractImage& ioImage, 
    const IImagePSF &iPSF, 
    uint32 iIterations,
    EBorderFill iBorder, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return DeconvolveRL(image, iPSF, iIterations, iBorder, iChannelMask, iNotifier);

} // DeconvolveRL
	
	
//----------------------------------------------------------------------------
	
} // namespace Image
} // namespace eLynx

#endif // __GlobalProcessing_DeconvolveRL_hpp__
