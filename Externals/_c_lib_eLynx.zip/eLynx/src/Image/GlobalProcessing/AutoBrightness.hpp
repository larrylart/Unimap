//============================================================================
//  GlobalProcessing/AutoBrightness.hpp                Image.Component package
//============================================================================
//  Copyright (C) 2009 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __GlobalProcessing_AutoBrightness_hpp__
#define __GlobalProcessing_AutoBrightness_hpp__

#include <elx/image/ImagePointProcessingImpl.h>
#include <elx/image/ImageAnalyseImpl.h>
#include <elx/image/ImageOperatorsImpl.h>

namespace eLynx {
namespace Image {

namespace {
//----------------------------------------------------------------------------
//  elxAutoBrightness # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool elxAutoBrightness(
    ImageImpl<Pixel>& ioImage,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  
  iNotifier.SetProgress(0.0f);
  const bool bSuccess = Math::elxNormalize(ioImage.GetSamples(), ioImage.GetSampleCount());
  iNotifier.SetProgress(1.0f);

  return bSuccess;

} // elxAutoBrightness # ImageImpl<Pixel>

#ifdef elxUSE_ImageHLS
//----------------------------------------------------------------------------
//  elxAutoBrightness # ImageImpl< PixelHLS<T> >
//----------------------------------------------------------------------------
template <typename T>
inline
bool elxAutoBrightness(
    ImageImpl< PixelHLS<T> >& ioImage,
    ProgressNotifier& iNotifier)
{ 
  return false; 

} // elxAutoBrightness # ImageImpl< PixelHLS<T> >
#endif // elxUSE_ImageHLS


#ifdef elxUSE_ImageLab
//----------------------------------------------------------------------------
//  elxAutoBrightness # ImageImpl< PixelLab<T> >
//----------------------------------------------------------------------------
template <typename T>
inline
bool elxAutoBrightness(
    ImageImpl< PixelLab<T> >& ioImage,
    ProgressNotifier& iNotifier)
{
  return false;

} // elxAutoBrightness # ImageImpl< PixelLab<T> >
#endif // elxUSE_ImageLab

#ifdef elxUSE_ImageComplex
//----------------------------------------------------------------------------
//  elxAutoBrightness # ImageImpl< PixelComplex<T> >
//----------------------------------------------------------------------------
template <typename T>
inline
bool elxAutoBrightness(
    ImageImpl< PixelComplex<T> >& ioImage,
    ProgressNotifier& iNotifier)
{
  return false;

} // elxAutoBrightness # ImageImpl< PixelLab<T> >
#endif // elxUSE_ImageComplex

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AutoBrightness # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <class Pixel> 
bool ImageGlobalProcessingImpl<Pixel>::AutoBrightness(
    ImageImpl<Pixel>& ioImage,
    ProgressNotifier& iNotifier)
{
  return elxAutoBrightness(ioImage, iNotifier);

} // AutoBrightness # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from IImageGlobalProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  AutoBrightness # AbstractImage
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGlobalProcessingImpl<Pixel>::AutoBrightness(
    AbstractImage& ioImage,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return AutoBrightness(image, iNotifier);

} // AutoBrightness # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __GlobalProcessing_AutoBrightness_hpp__
