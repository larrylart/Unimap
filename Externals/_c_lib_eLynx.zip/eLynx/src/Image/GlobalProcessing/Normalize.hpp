//============================================================================
//  GlobalProcessing/Normalize.hpp                     Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __GlobalProcessing_normalize_hpp__
#define __GlobalProcessing_normalize_hpp__

#include <elx/image/ImageAnalyseImpl.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

//----------------------------------------------------------------------------
//  elxNormalize # ImageImpl< PixelRGB<T> >
//----------------------------------------------------------------------------
template <typename T>
bool elxNormalize(
    ImageImpl< PixelRGB<T> >& ioImage,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  const T m = ResolutionTypeTraits<T>::_min;
  const T M = ResolutionTypeTraits<T>::_norm;

  //                             R     G     B     
  const T minRange[PC_MAX] = { T(m), T(m), T(m), T(0) };
  const T maxRange[PC_MAX] = { T(M), T(M), T(M), T(0) };

  iNotifier.SetProgress(0.0f);
  const bool bSuccess = Math::elxNormalize<T>(
    ioImage.GetSamples(), ioImage.GetSampleCount(), 
    (const T*)&minRange, (const T*)&maxRange, 
    iChannelMask, 3);
  iNotifier.SetProgress(1.0f);

  return bSuccess;

} // elxNormalize # ImageImpl< PixelRGB<T> >

//----------------------------------------------------------------------------
//  elxNormalize # ImageImpl< PixelRGBA<T> >
//----------------------------------------------------------------------------
template <typename T>
bool elxNormalize(
    ImageImpl< PixelRGBA<T> >& ioImage,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  //                             R     G     B     A
  const T minRange[PC_MAX] = { T(0), T(0), T(0), T(0) };
  const T maxRange[PC_MAX] = { T(1), T(1), T(1), T(1) };

  iNotifier.SetProgress(0.0f);
  const bool bSuccess = Math::elxNormalize<T>(
    ioImage.GetSamples(), ioImage.GetSampleCount(), 
    (const T*)&minRange, (const T*)&maxRange, 
    iChannelMask, 4);
  iNotifier.SetProgress(1.0f);

  return bSuccess;

} // elxNormalize # ImageImpl< PixelRGBA<T> >

#ifdef elxUSE_ImageHLS
//----------------------------------------------------------------------------
//  elxNormalize # ImageImpl< PixelHLS<T> >
//----------------------------------------------------------------------------
template <typename T>
bool elxNormalize(
    ImageImpl< PixelHLS<T> >& ioImage,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  //                             H     L      S
  const T minRange[PC_MAX] = { T(0), T(0), T(0.0), T(0) };
  const T maxRange[PC_MAX] = { T(1), T(1), T(0.5), T(0) };

  iNotifier.SetProgress(0.0f);
  const bool bSuccess = Math::elxNormalize<T>(
    ioImage.GetSamples(), ioImage.GetSampleCount(), 
    (const T*)&minRange, (const T*)&maxRange, 
    iChannelMask, 3);
  iNotifier.SetProgress(1.0f);

  return bSuccess;

} // ImageImpl< PixelHLS<T> >
#endif // elxUSE_ImageHLS

#ifdef elxUSE_ImageLab
//----------------------------------------------------------------------------
//  elxNormalize # ImageImpl< PixelLab<T> >
//----------------------------------------------------------------------------
template <typename T>
bool elxNormalize(
    ImageImpl< PixelLab<T> >& ioImage,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  //                              L        a        b
  const T minRange[PC_MAX] = { T(  0), T(-120), T(-120), T(0) };
  const T maxRange[PC_MAX] = { T(110), T(+120), T(+120), T(0) };

  iNotifier.SetProgress(0.0f);
  const bool bSuccess = Math::elxNormalize<T>(
    ioImage.GetSamples(), ioImage.GetSampleCount(), 
    (const T*)&minRange, (const T*)&maxRange, 
    iChannelMask, 3);
  iNotifier.SetProgress(1.0f);

  return bSuccess;

} // elxNormalize # ImageImpl< PixelLab<T> >
#endif // elxUSE_ImageLab

//----------------------------------------------------------------------------
//  elxNormalize # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <class Pixel>
bool elxNormalize(
    ImageImpl<Pixel>& ioImage,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;

  // @TODO care about iChannelMask
  return Math::elxNormalize(ioImage.GetSamples(), ioImage.GetSampleCount());

} // elxNormalize # ImageImpl<Pixel>

} // anonymous-namespace


//----------------------------------------------------------------------------
//  Normalize # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <class Pixel> 
bool ImageGlobalProcessingImpl<Pixel>::Normalize(
    ImageImpl<Pixel>& ioImage,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;

  return elxNormalize(ioImage, iChannelMask, iNotifier);

} // Normalize # ImageImpl<Pixel>

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from IImageGlobalProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Normalize # AbstractImage
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageGlobalProcessingImpl<Pixel>::Normalize(
    AbstractImage& ioImage,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Normalize(image, iChannelMask, iNotifier);

} // Normalize # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __GlobalProcessing_normalize_hpp__
