//============================================================================
//  ImageLocalProcessingImpl.cpp                       Image.Component package
//============================================================================
//  Usage : image local to point processing interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/ImageLocalProcessingImpl.h>
#include <boost/scoped_array.hpp>

// --- convolution filters
#include "LocalProcessing/Convolution.hpp"
#include "LocalProcessing/Convolution3x3.hpp"
#include "LocalProcessing/Convolution5x5.hpp"
#include "LocalProcessing/ConvolutionWxH.hpp"
#include "LocalProcessing/SeparableWxH.hpp"

// --- misc
#include "LocalProcessing/BoxBlur.hpp"
#include "LocalProcessing/SelectiveBlur.hpp"
#include "LocalProcessing/Bilateral.hpp"

namespace eLynx {
namespace Image {

IImageLocalProcessing::~IImageLocalProcessing() {}

#ifdef elxUSE_ImageComplex
//----------------------------------------------------------------------------
//                              NOT_IMPLEMENTED
// Specialization for pixel's types where convolution does not make sense. 
//----------------------------------------------------------------------------
template<>
bool ImageLocalProcessingImpl< PixelComplexi >::Convolve3x3(
    ImageImpl< PixelComplexi >& ioImage, 
    const Math::ConvolutionKerneld& iKernel, 
    double iThresholdMin, double iThresholdMax,
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }

template<>
bool ImageLocalProcessingImpl< PixelComplexf >::Convolve3x3(
    ImageImpl< PixelComplexf >& ioImage, 
    const Math::ConvolutionKerneld& iKernel, 
    double iThresholdMin, double iThresholdMax,
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }

template<> 
bool ImageLocalProcessingImpl< PixelComplexd >::Convolve3x3(
    ImageImpl< PixelComplexd >& ioImage, 
    const Math::ConvolutionKerneld& iKernel, 
    double iThresholdMin, double iThresholdMax,
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }

template<>
bool ImageLocalProcessingImpl< PixelComplexi >::Convolve5x5(
    ImageImpl< PixelComplexi >& ioImage, 
    const Math::ConvolutionKerneld& iKernel, 
    double iThresholdMin, double iThresholdMax,
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }

template<> 
bool ImageLocalProcessingImpl< PixelComplexf >::Convolve5x5(
    ImageImpl< PixelComplexf >& ioImage, 
    const Math::ConvolutionKerneld& iKernel, 
    double iThresholdMin, double iThresholdMax,
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }

template<> 
bool ImageLocalProcessingImpl< PixelComplexd >::Convolve5x5(
    ImageImpl< PixelComplexd >& ioImage, 
    const Math::ConvolutionKerneld& iKernel, 
    double iThresholdMin, double iThresholdMax,
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }

template<>
bool ImageLocalProcessingImpl< PixelComplexi >::Convolve(
    ImageImpl< PixelComplexi >& ioImage, 
    const Math::ConvolutionKerneld& iKernel, 
    double iThresholdMin, double iThresholdMax,
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }

template<>
bool ImageLocalProcessingImpl< PixelComplexf >::Convolve(
    ImageImpl< PixelComplexf >& ioImage, 
    const Math::ConvolutionKerneld& iKernel, 
    double iThresholdMin, double iThresholdMax,
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }

template<> 
bool ImageLocalProcessingImpl< PixelComplexd >::Convolve(
    ImageImpl< PixelComplexd >& ioImage, 
    const Math::ConvolutionKerneld& iKernel, 
    double iThresholdMin, double iThresholdMax,
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{ return false; }

#endif

//----------------------------------------------------------------------------
//  explicit instantiation of all image types
//----------------------------------------------------------------------------
elxINSTANTIATE_CLASS_FOR_ALL_IMAGE_TYPES( ImageLocalProcessingImpl );

} // namespace Image
} // namespace eLynx
