//============================================================================
//  Factory/Liquid.hpp                                 Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Liquid_hpp__
#define __Factory_Liquid_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a liquid simulation image
//----------------------------------------------------------------------------
template <typename T> 
inline
ImageImpl< PixelL<T> > * elxCreateLiquid(uint32 iWidth, uint32 iHeight, 
    uint32 iIterations, int32 iRandom, double iPower)
{
  ::srand(iRandom);

  // basic parameters
  const uint32 w = iWidth;
  const uint32 h = iHeight;

  // parameters to the fluid simulation equation
  const float d = 10.0f;
  const float c = 100.0f;
  const float mu = 100.0f;
  const float t = float(iPower); // 0.033f

  // pre-compute the coefficients in the fluid equation
  const float coefA = (4 - (8*c*c*t*t) / (d*d)) / (mu*t + 2);
  const float coefB = (mu*t - 2) / (mu*t + 2);
  const float coefC = ((2*c*c*t*t) / (d*d)) / (mu*t + 2);

  // surface at time k and k-1
  float * plSurface[2] = { NULL, NULL }; 

  // allocate memory for the surface at two timesteps
  plSurface[0] = new float [w*h];
  plSurface[1] = new float [w*h];

  // initialise the surfaces to random values, except the edges which are set to 0
  const float fMinInitH = -500.0f; 
  const float fMaxInitH =  500.0f;
  uint32 x,y;
  int32 index;
  for (y=0; y<h; y++) 
    for (x=0; x<w; x++) 
    {
      index = x + y*w;
      plSurface[0][index] = plSurface[1][index] = 
        (x == 0 || x == (w-1) || y == 0 || y == (h-1)) ? 
          0.0f :
          ((float)::rand() / RAND_MAX) * (fMaxInitH - fMinInitH) + fMinInitH;
    }

  // Iterate over the heightmap, applying the fluid simulation equation.
  // Although it requires knowledge of the two previous timesteps, it only
  // accesses one pixel of the k-1 timestep, so using a simple trick we only
  // need to store the heightmap twice, not three times, and we can avoid
  // a memcpy() every iteration.
  int32 currentBuffer = 0;
  float * prOld, * prNew;
  for (uint32 i=0; i<iIterations; i++) 
  {
    prOld = plSurface[1-currentBuffer];
    prNew = plSurface[currentBuffer];

    for (y=1; y<h-1; y++) 
      for (x=1; x<w-1; x++) 
      {
        index = x + y*w;
        prOld[index] = coefA * prNew[index] + 
                       coefB * prOld[index] +
                       coefC *(prNew[index+1] + prNew[index-1] + prNew[index+w] + prNew[index-w]);
      }
    currentBuffer = 1-currentBuffer;
  }

  // find the minimum and maximum heights
  float fMinH = plSurface[currentBuffer][0]; 
  float fMaxH = plSurface[currentBuffer][0];

  for (y=0; y<h; y++) 
    for (x=0; x<w; x++) 
      if (plSurface[currentBuffer][x+y*w] > fMaxH)
        fMaxH = plSurface[currentBuffer][x+y*w];
      else if (plSurface[currentBuffer][x+y*w] < fMinH)
        fMinH = plSurface[currentBuffer][x+y*w];

  // normalize the surface
  for (y=0; y<h; y++) 
    for (x=0; x<w; x++)
      plSurface[currentBuffer][x+y*w] = (plSurface[currentBuffer][x+y*w] - fMinH) / (fMaxH - fMinH);

  // create empty image
  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(iWidth,iHeight);

  // put the normalized heightmap into the greyscale image
  T * prDst = psImage->GetSamples();
  T * prEnd = psImage->GetSamplesEnd();
  float * p = plSurface[currentBuffer];

  do 
  { 
    *prDst = T(*p++);
  } 
  while (++prDst != prEnd);

  elxSAFE_DELETE_LIST( plSurface[0] );
  elxSAFE_DELETE_LIST( plSurface[1] );
  
  return psImage;

} // elxCreateLiquid


#ifdef USE_ImageFactoryHighLevel

//----------------------------------------------------------------------------
//  elxMakeLiquid
//----------------------------------------------------------------------------
bool elxMakeLiquid(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight, uint32 iIterations, int32 iRandom, double iPower)
{
  if (RT_Double == iResolution)
  {
    ioImage = *elxCreateLiquid<double>(iWidth, iHeight, iIterations, iRandom, iPower);
    return true;
  }
  ioImage = *elxCreateLiquid<float>(iWidth, iHeight, iIterations, iRandom, iPower);
  if (RT_Float == iResolution) return true;
  return ioImage.ChangeResolution(iResolution);

} // elxMakeLiquid


//----------------------------------------------------------------------------
//  Liquid image factory
//----------------------------------------------------------------------------
class LiquidFactory : public ImageFactoryBase
{
public:
  LiquidFactory() : ImageFactoryBase(IFT_Liquid),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter),
    _height(s_heightParameter),
    _iterations("Iterations", 100, 999, 200, 100, 3, "%3.0lf"),
    _random("Random", 0, 99, 50,  100, 2, "%2.0lf"),
    _power("Power", 0.01, 0.07, 0.06, 100, 4, "%1.3lf")
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_iterations);
    _parameters.push_back(&_random);
    _parameters.push_back(&_power);
  }

  virtual const char * GetName() const { return "Liquid"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const uint32 iterations = (uint32)_iterations.GetValue();
    int32 random = _random.GetValue();
    double power = _power.GetValue();
    return elxMakeLiquid(ioImage, resolution, w, h, iterations, random, power);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterInteger _iterations;
  ParameterInteger _random;
  ParameterDouble  _power;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Liquid_hpp__
