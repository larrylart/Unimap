//============================================================================
//  Factory/Plasma.hpp                                 Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Plasma_hpp__
#define __Factory_Plasma_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a Plasma image
//----------------------------------------------------------------------------
template <typename T>
inline
ImageImpl< PixelRGB<T> > * elxCreatePlasma(uint32 iWidth, uint32 iHeight,
  double iRange, double iAmplitude, int32 iSeed)
{
  Math::elxRandomReset(iSeed);
  const uint32 w = iWidth;
  const uint32 h = iHeight;

  // --- init cells ---
  const double amplitude = iAmplitude;
  const double c00 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
  const double c01 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
  const double c02 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
  const double c03 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
  const double c04 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
  const double c05 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
  const double c06 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
  const double c07 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
  const double c08 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
  const double c09 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
  const double c10 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
  const double c11 = amplitude * Math::elxCos( Math::elxRandom(M_2PI) );
 
  // --- fill image map ---

  // create empty image
  ImageImpl< PixelRGB<T> > * psImage = new ImageImpl< PixelRGB<T> >(w,h);
  T * prDst = psImage->GetSamples();

  // fill map
  const double range = iRange;
  const double sx = range / double(w - 1);
  const double sy = range / double(h - 1);
  const double o = 0.5f * range; 

  double x,y,xx,yy,xy;
  uint32 i,j;
  for (j=0; j<h; j++)
  {
    y = j*sy - o;
    for (i=0; i<w; i++)  
    {
      x = i*sx - o;

      xx = x*x;
      yy = y*y;
      xy = x*y;

      *prDst++ = 0.8f * (c00*x + c01*y + c02*xx + c03*(1.0f + xy)); // r
      *prDst++ = 0.8f * (c04*x + c05*y + c06*xy + c07*(1.0f - yy)); // g
      *prDst++ = 0.8f * (c08*x + c09*y + c10*yy + c11*(1.0f - xy)); // b
    }
  }

  return psImage;

} // elxCreatePlasma

#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  elxMakePlasma
//============================================================================
bool elxMakePlasma(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight,
    double iRange, double iAmplitude, int32 iSeed)
{
  ioImage = *elxCreatePlasma<double>(iWidth, iHeight, iRange, iAmplitude, iSeed);
  if (RT_Double == iResolution) return true;
  return ioImage.ChangeResolution(iResolution);

} // elxMakePlasma


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Plasma image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class PlasmaFactory : public ImageFactoryBase
{
public:
  PlasmaFactory() : ImageFactoryBase(IFT_Plasma),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _range("Range", 2.0, 20.0, 3.0, 100, 4, "%2.2lf"),
    _amplitude("Amplitude", 0.1, 4.0, 1.78, 80, 3, "%1.2lf"),
    _seed("Seed", 0, 9999, 5151, 100, 4, "%4.0lf")
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_range);
    _parameters.push_back(&_amplitude);
    _parameters.push_back(&_seed);
  }

  virtual const char * GetName() const { return "Plasma"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const double range = _range.GetValue();
    const double amplitude = _amplitude.GetValue();
    const int32 seed = _seed.GetValue();
    return elxMakePlasma(ioImage, resolution, w, h, range, amplitude, seed);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterDouble  _range;
  ParameterDouble  _amplitude;
  ParameterInteger _seed;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Plasma_hpp__
