//============================================================================
//  Factory/GradientWheel.hpp                          Image.Component package
//============================================================================
//  Copyright (C) 2009 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_GradientWheel_hpp__
#define __Factory_GradientWheel_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a GradientWheel image
//----------------------------------------------------------------------------
template <typename T>
inline
ImageImpl< PixelL<T> > * elxCreateGradientWheel(uint32 iWidth, uint32 iHeight,
    double iDegrees)
{
  const uint32 w = iWidth;
  const uint32 h = iHeight;

  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(w,h);
  T * prDst = psImage->GetSamples();

  const double xc = 0.5 * w;
  const double yc = 0.5 * h;
  const double radius = Math::elxMin(xc, yc);
  const double oneOverRadius = 1.0 / radius;
  const double radians = Math::elxDeg2Rad(iDegrees);
  const double cosA = Math::elxCos(radians);
  const double sinA = Math::elxSin(radians);

  double dx,dy, rx,ry, r,v;
  uint32 x;
  for (uint32 y=0; y<h; y++)
  {
    dy = (double(y) + 0.5) - yc;
    for (x=0; x<w; x++)
    {
      dx = (double(x) + 0.5) - xc;

      // apply rotation
      rx = dx*cosA - dy*sinA;
      ry = dy*cosA + dx*sinA;

      r = Math::elxSqrt(rx*rx + ry*ry) * oneOverRadius;
      v = 0.5*(1. + ::atan2(rx,ry)/M_PI);

      if (r > 1)
        *prDst++ = 0;
      else if (v < 0.5)
        *prDst++ = (1 - r) * (2 * v);
      else
        *prDst++ = (1 - r) * 2 * (1 - v);
    }
  }

  return psImage;

} // elxCreateGradientWheel


#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  Make a GradientWheel image
//============================================================================
bool elxMakeGradientWheel(ImageVariant& ioImage, EResolution iResolution, 
    uint32 iWidth, uint32 iHeight, double iRotation)
{
  ioImage = *elxCreateGradientWheel<double>(iWidth, iHeight, iRotation);
  return ioImage.ChangeResolution(iResolution);

} // elxMakeGradientWheel


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  GradientWheel image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class GradientWheelFactory : public ImageFactoryBase
{
public:
  GradientWheelFactory() : ImageFactoryBase(IFT_GradientWheel),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _rotation(s_RotationParameter)
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_rotation);
  }

  virtual const char * GetName() const { return "Gradient wheel"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const double rotation = _rotation.GetValue();
    return elxMakeGradientWheel(ioImage, resolution, w, h, rotation);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterDouble  _rotation;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_GradientWheel_hpp__
