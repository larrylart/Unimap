//============================================================================
//  Factory/Galaxy.hpp                                 Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Galaxy_hpp__
#define __Factory_Galaxy_hpp__

namespace eLynx {
namespace Image {

namespace {

float elxHatRandom(float iRange)
{
  const float area = 4 * ::atanf(6.0);
  const float angle = Math::elxRandom(area);
  return (::tanf(angle) * iRange / 6.0f);

} // elxHatRandom

}; // namespace

//----------------------------------------------------------------------------
//  Create a grey noicy image
//----------------------------------------------------------------------------
template <typename T> 
inline
ImageImpl< PixelL<T> > * elxCreateGalaxy(uint32 iWidth, uint32 iHeight,
    uint32 iArms, double iDensity)
{
  Math::elxRandomReset(0);

  const uint32 w = iWidth;
  const uint32 h = iHeight;
  const uint32 nStars = uint32(iDensity * w * h * 0.8);
  const uint32 nArms = iArms;
  const float scale = 1.f;

  const float xc = 0.5f * w;
  const float yc = 0.5f * h;
  const float radius = 0.5f * Math::elxMin(w, h);
  const float armAngle = float((360 / nArms)%360);
  const float angularSpread = 90.f/nArms;
  
  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(w,h);
  T * prDst = psImage->GetSamples();

  float r,q,x,y, degree,radian;
  uint32 index;
  for (uint32 i=0; i<nStars; i++)
  {
    r = Math::elxRandom(radius);
    q = elxHatRandom(angularSpread) * Math::elxRandomSign();
    degree = (::rand() % nArms) * armAngle;
    radian = Math::elxDeg2Rad( degree + r*scale + q );

    x = xc + r * Math::elxCos(radian);
    y = yc + r * Math::elxSin(radian);

    index = uint32(x) + w * uint32(y);
    prDst[index] = T(255);
  }

  return psImage;

} // elxCreateNoice


#ifdef USE_ImageFactoryHighLevel

//----------------------------------------------------------------------------
//  elxMakeGalaxy
//----------------------------------------------------------------------------
bool elxMakeGalaxy(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight, uint32 iArms, double iDensity)
{
  ioImage = *elxCreateGalaxy<uint8>(iWidth, iHeight, iArms, iDensity);
  if (RT_UINT8 == iResolution) return true;
  return ioImage.ChangeResolution(iResolution);

} // elxMakeGalaxy

//----------------------------------------------------------------------------
//  Galaxy image factory
//----------------------------------------------------------------------------
class GalaxyFactory : public ImageFactoryBase
{
public:
  GalaxyFactory() : ImageFactoryBase(IFT_Galaxy),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter),
    _height(s_heightParameter),
    _arms("Arms", 2, 10, 3, 8, 2, "%2.0lf"),
    _density("Density", 0.1, 1.0, 0.15, 100, 3, "%1.2lf")
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_arms);
    _parameters.push_back(&_density);
  }

  virtual const char * GetName() const { return "Galaxy"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const uint32 arms = (uint32)_arms.GetValue();
    const double density = _density.GetValue();
    return elxMakeGalaxy(ioImage, resolution, w, h, arms, density);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterInteger _arms;
  ParameterDouble  _density;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Galaxy_hpp__
