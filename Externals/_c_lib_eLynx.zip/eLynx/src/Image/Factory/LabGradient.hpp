//============================================================================
//  Factory/LabGradient.hpp                            Image.Component package
//============================================================================
//  Copyright (C) 2009 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
/*
#ifndef __Factory_LabGradient_hpp__
#define __Factory_LabGradient_hpp__

namespace eLynx {
namespace Image {

#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  Make a LabGradient image
//============================================================================
bool elxMakeLabGradient(ImageVariant& ioImage, EResolution iResolution, 
    uint32 iWidth, uint32 iHeight, double iLuminance, double iDegreesA, double iDegreesB)
{
  bool bSuccess = false;
  const uint32 w = iWidth;
  const uint32 h = iHeight;
#if 1
  ImageVariant L;

  // build L plane in float resolution
  bSuccess = elxMakeGradient(L, RT_Float, w,h);
  bSuccess = L.AdjustGamma(2.5);
  ImageVariant a = L;
  bSuccess = L.Mul(iLuminance);

  // build a* plane in float resolution
  bSuccess = a.Add(-0.5f);
  ImageVariant b = a;

  a.FlipHorizontal();
  bSuccess = a.Mul(2*iDegreesA);

  b.FlipVertical();
  bSuccess = b.Mul(2*iDegreesB);
#else
  ImageVariant L;

  // build L plane in float resolution
  bSuccess = elxMakeGradient(L, RT_Float, w,h);
  ImageVariant a = L;
  bSuccess = L.Mul(iLuminance);

  // build a* plane in float resolution
  bSuccess = a.Add(-0.5f);
  ImageVariant b = a;

  //a.FlipHorizontal();
  bSuccess = a.Mul(2*iLuminance);

  //b.FlipVertical();
  bSuccess = b.Mul(2*iLuminance);
#endif
  // Merge all planes in one image in CIE Lab color space with float resolution.
  ioImage = ImageVariant(L,a,b, CS_CIE_Lab);
  bSuccess = ioImage.ChangeColorSpace(CS_RGB);
  bSuccess = ioImage.ChangeResolution(iResolution);

  return bSuccess;

} // elxMakeLabGradient


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  LabGradient image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class LabGradientFactory : public ImageFactoryBase
{
public:
  LabGradientFactory() : ImageFactoryBase(IFT_LabGradient),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _luminance(s_LuminanceParameter),
    _rotationA(s_RotationAsParameter),
    _rotationB(s_RotationBsParameter)
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_luminance);
    _parameters.push_back(&_rotationA);
    _parameters.push_back(&_rotationB);
  }

  virtual const char * GetName() const { return "Lab gradient"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const double luminance = _luminance.GetValue();
    const double rotationA = _rotationA.GetValue();
    const double rotationB = _rotationB.GetValue();
    return elxMakeLabGradient(ioImage, resolution, w, h, luminance, rotationA, rotationB);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterDouble  _luminance;
  ParameterDouble  _rotationA;
  ParameterDouble  _rotationB;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_LabGradient_hpp__
*/