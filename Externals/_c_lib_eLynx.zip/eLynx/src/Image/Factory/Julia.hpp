//============================================================================
//  Factory/Julia.hpp                                  Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Julia_hpp__
#define __Factory_Julia_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a Julia image
//----------------------------------------------------------------------------
template <typename T>
inline
ImageImpl< PixelRGB<T> > * elxCreateJulia(uint32 iWidth, uint32 iHeight,
  uint32 iMaxIterations, double iZoom, double iRotation)
{
  const uint32 w = iWidth;
  const uint32 h = iHeight;

  // --- build iteration map ---

  // julia parameters
  const int32 maxIterations = int32(iMaxIterations);
  const float zoom = float(iZoom);
  const float rotation = float( Math::elxDeg2Rad(iRotation) );

#if 1
  const float Jx = -0.39054f;
  const float Jy = -0.5897f;
#else
 const float Jx = -0.156844471694257101941f;
 const float Jy = -0.649707745759247905171f;
#endif

  const float half =  0.5f*zoom;
  const float xc = 0.f;
  const float yc = 0.f;

  const float MinX = xc - half;
  const float MaxX = xc + half;
  const float MinY = yc - half;
  const float MaxY = yc + half;

  const float dx = (MaxX - MinX) / w;
  const float dy = (MaxY - MinY) / h;
  const float c = cosf(rotation);
  const float s = sinf(rotation);

  uint32 row, col, i;
  float Zx,Zy, xx,yy,xy, x,y, xl,yl, yls,ylc;

  uint32 * plIterationMap = new uint32 [w*h];
  uint32 * p = plIterationMap;
  y = MinY;
  for (row=0; row<h; row++, y+=dy)
  {
    yl = y - yc;
    yls = xc - yl*s;
    ylc = yc + yl*c;
    x = MinX;
    for (col=0; col<w; col++, x+=dx)
    {
      xl = x - xc;

      // rotation
      Zx = yls + xl*c;
      Zy = ylc + xl*s;

      // start julia iterations
      xx = Zx*Zx;
      yy = Zy*Zy;
      xy = 2.0f*Zx*Zy;
      for (i=maxIterations; i>0; i--)
      {
        // Julia formula : z(n+1) = z(n)*z(n) + c;
        Zx = Jx + xx - yy;
        Zy = Jy + xy;

        xy = 2.0f*Zx*Zy;
        xx = Zx*Zx;
        yy = Zy*Zy;

        // module limite
        if (xx + yy > 4.0f)
          break;
      }
      *p++ = maxIterations - i;
    }
  }

  // create palette
  PixelRGB<T> * plPalette = new PixelRGB<T>[maxIterations];
  const float scale = 1.0f / (maxIterations - 1.0f);
  for (uint32 i=0; i<iMaxIterations; i++)
  {
    float a = (float)i * scale;
    plPalette[i] = PixelHLS<T>(a, 0.5f, 1.0f);
    //plPalette[i] = PixelHLS<T>(1, 0.5f, a);
  }

  // --- fill image map ---

  // create empty image
  ImageImpl< PixelRGB<T> > * psImage = new ImageImpl< PixelRGB<T> >(w,h);
  PixelRGB<T> * prDst = psImage->GetPixel();
  p = plIterationMap;

  for (uint32 j=0; j<h; j++)
    for (i=0; i<w; i++)
      *prDst++ = plPalette[ *p++ ];
  
  elxSAFE_DELETE_LIST(plPalette);
  elxSAFE_DELETE_LIST(plIterationMap);

  return psImage;

} // elxCreateJulia

#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  elxMakeJulia
//============================================================================
bool elxMakeJulia(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight,
    uint32 iMaxIterations, double iZoom, double iRotation)
{
  ioImage = *elxCreateJulia<float>(iWidth, iHeight, iMaxIterations, iZoom, iRotation);
  if (RT_Float == iResolution) return true;
  return ioImage.ChangeResolution(iResolution);

} // elxMakeJulia


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Julia image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class JuliaFactory : public ImageFactoryBase
{
public:
  JuliaFactory() : ImageFactoryBase(IFT_Julia),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _maxIterations("Max iterations", 100, 1000, 200, 100, 4, "%4.0lf"),
    _zoom("Zoom", 0.1, 10.0, 1.0, 100, 4, "%2.2lf"),
    _rotation("Rotation", 0., 360., 0., 100, 4, "%3.1lf")
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_maxIterations);
    _parameters.push_back(&_zoom);
    _parameters.push_back(&_rotation);
  }

  virtual const char * GetName() const { return "Julia"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const uint32 maxIterations = (uint32)_maxIterations.GetValue();
    const double zoom = _zoom.GetValue();
    const double rotation = _rotation.GetValue();
    return elxMakeJulia(ioImage, resolution, w, h, maxIterations, zoom, rotation);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterInteger _maxIterations;
  ParameterDouble  _zoom;
  ParameterDouble  _rotation;
};

#endif // USE_ImageFactoryHighLevel


} // namespace Image
} // namespace eLynx

#endif // __Factory_Julia_hpp__
