//============================================================================
//  Factory/LensFlare.hpp                              Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_LensFlare_hpp__
#define __Factory_LensFlare_hpp__

namespace eLynx {
namespace Image {


double GetLuminance(double s, double a, double b, int32 type)
{
  double l;
  switch (type)
  { 
    case 1: // r^6
      l = s*s; 
      l = l*l;  
      l = l*l*l;
      break;

    case 2: // (1-r)^2
      l = 1.0 - s; 
      l = l*l;
      break;

    case 3: 
      l = 1.0 - 10 * Math::elxAbs(s - 0.9);
      if (l < 0.0) l = 0.0;
      l = l*l; 
      l = l*l;
      break;

    case 4: 
      l = (s > 1) ? 0.0 : 1.0;
      return l;

    default: // r
      l = s;
      break;
  }
  l *= 1.0 - Math::elxSmooth(a, b, s);
  return l;
}

//----------------------------------------------------------------------------
//  Create a grey plate image
//----------------------------------------------------------------------------
template <typename T> 
inline
ImageImpl< PixelL<T> > * elxCreateLensFlare(uint32 iWidth, uint32 iHeight, 
  uint32 iType, double iScale)
{
  const uint32 w = iWidth;
  const uint32 h = iHeight;
  const double a = 1. - iScale;
  const double b = 1. + iScale;

  ImageImpl< PixelL<T> > * psImageL = new ImageImpl< PixelL<T> >(w,h);
  T * prSrc = psImageL->GetSamples();

  const double xc = 0.5 * w;
  const double yc = 0.5 * h;
  const double radius = 0.5 * Math::elxMin(w, h) / b;
  const double oneOverRadius = 1.0 / radius;

  double dx, dy, dy2, s;
  uint32 x;
  for (uint32 y=0; y<h; y++)
  {
    dy = (double(y) + 0.5) - yc;
    dy2 = dy*dy;
    
    for (x=0; x<w; x++)
    {
      dx = (double(x) + 0.5) - xc;
      s = Math::elxSqrt(dx*dx + dy2) * oneOverRadius;

      *prSrc++ = T( GetLuminance(s, a, b, iType) );
    }
  }
  return psImageL;

} // elxCreateLensFlare

#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  Make a grey lens flare image
//============================================================================
bool elxMakeLensFlare(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight, uint32 iType, double iFocus)
{ 
  if (RT_Double == iResolution)
  {
    ioImage = *elxCreateLensFlare<double>(iWidth, iHeight, iType, iFocus);
    return true;
  }
  ioImage = *elxCreateLensFlare<float>(iWidth, iHeight, iType, iFocus);
  return ioImage.ChangeResolution(iResolution);

} // elxMakeLensFlare


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  LensFlare image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class LensFlareFactory : public ImageFactoryBase
{
public:
  LensFlareFactory() : ImageFactoryBase(IFT_LensFlare),
    _type(s_LensFlareTypeParameter),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _focus("Focus", 0.01, 0.50, 0.01, 100, 2, "%1.2lf")
  {
    _parameters.push_back(&_type);
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_focus);
  }

  virtual const char * GetName() const { return "Lens flare"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    uint32 type = (uint32)_type.GetValue();
    EResolution resolution = (EResolution)_resolution.GetValue();
    uint32 w = (uint32)_width.GetValue();
    uint32 h = (uint32)_height.GetValue();
    double focus = _focus.GetValue();
    return elxMakeLensFlare(ioImage, resolution, w, h, type, focus); 
  }

protected:
  ParameterEnum    _type;
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterDouble  _focus;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_LensFlare_hpp__
