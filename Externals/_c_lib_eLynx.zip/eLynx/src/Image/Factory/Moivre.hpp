//============================================================================
//  Factory/Moivre.hpp                                 Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Moivre_hpp__
#define __Factory_Moivre_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create an image with moivre artifact
//----------------------------------------------------------------------------
template <typename T> 
inline
ImageImpl< PixelL<T> > * elxCreateMoivre(uint32 iWidth, uint32 iHeight, uint32 iScale)
{
  const uint32 w = iWidth;
  const uint32 h = iHeight;
  const uint32 s = iScale;

  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(w,h);
  T * prDst = psImage->GetSamples();

  uint32 x;
  for (uint32 y=0; y<h; y++)
    for (x=0; x<w; x++)
      *prDst++ = T(x*y*s);

  return psImage;

} // elxCreateMoivre


#ifdef USE_ImageFactoryHighLevel

//----------------------------------------------------------------------------
//  elxMakeMoivre
//----------------------------------------------------------------------------
bool elxMakeMoivre(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight, uint32 iScale)
{
  ioImage = *elxCreateMoivre<uint8>(iWidth, iHeight, iScale);
  if (RT_UINT8 == iResolution) return true;
  return ioImage.ChangeResolution(iResolution);

} // elxMakeMoivre

//----------------------------------------------------------------------------
//  Moivre image factory
//----------------------------------------------------------------------------
class MoivreFactory : public ImageFactoryBase
{
public:
  MoivreFactory() : ImageFactoryBase(IFT_Moivre),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter),
    _height(s_heightParameter),
    _scale("Scale", 1, 100, 1, 99, 2, "%2.0lf")
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_scale);
  }

  virtual const char * GetName() const { return "Moivre"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const uint32 scale = (uint32)_scale.GetValue();
    return elxMakeMoivre(ioImage, resolution, w, h, scale);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterInteger _scale;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Moivre_hpp__
