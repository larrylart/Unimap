//============================================================================
//  Factory/Noise.hpp                                  Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Noise_hpp__
#define __Factory_Noise_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a grey noicy image
//----------------------------------------------------------------------------
template <typename T> 
inline
ImageImpl< PixelL<T> > * elxCreateNoise(uint32 iWidth, uint32 iHeight, int32 iSeed)
{
  //Math::elxRandomReset(iSeed);
  int32 seed = 1 + iSeed;
  int32 noise, carry;

  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(iWidth,iHeight);
  T * prDst = psImage->GetSamples();

  const uint32 size = psImage->GetSampleCount();
  for (uint32 i=size; i>0; i--)
  {
    noise = seed;
    noise >>= 5;
    noise ^= seed;
    carry = noise & 1;
    noise >>= 1;
    seed >>= 1;
    seed |= (carry << 30);
    noise &= 0xFF;
    *prDst++ = T(noise);
  }
  return psImage;

} // elxCreateNoise


#ifdef USE_ImageFactoryHighLevel

//----------------------------------------------------------------------------
//  elxMakeNoise
//----------------------------------------------------------------------------
bool elxMakeNoise(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight, int32 iSeed)
{
  ioImage = *elxCreateNoise<uint8>(iWidth, iHeight, iSeed);
  if (RT_UINT8 == iResolution) return true;
  return ioImage.ChangeResolution(iResolution);

} // elxMakeNoise

//----------------------------------------------------------------------------
//  Noise image factory
//----------------------------------------------------------------------------
class NoiseFactory : public ImageFactoryBase
{
public:
  NoiseFactory() : ImageFactoryBase(IFT_Noise),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter),
    _height(s_heightParameter),
    _seed(s_SeedParameter)
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_seed);
  }

  virtual const char * GetName() const { return "Noise"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const int32 seed = _seed.GetValue();
    return elxMakeNoise(ioImage, resolution, w, h, seed);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterInteger _seed;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Noise_hpp__
