//============================================================================
//  Factory/ColorWheel.hpp                             Image.Component package
//============================================================================
//  Copyright (C) 2009 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_ColorWheel_hpp__
#define __Factory_ColorWheel_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a ColorWheel image
//----------------------------------------------------------------------------
template <typename T>
inline
ImageImpl< PixelRGB<T> > * elxCreateColorWheel(uint32 iWidth, uint32 iHeight)
{
  const uint32 w = iWidth;
  const uint32 h = iHeight;

  ImageImpl< PixelRGB<T> > * psImage = new ImageImpl< PixelRGB<T> >(w,h);
  PixelRGB<T> * prDst = psImage->GetPixel();
  PixelHLSd hls;

  const double xc = 0.5 * w;
  const double yc = 0.5 * h;
  const double radius = 0.5 * Math::elxMin(w, h);
  const double oneOverRadius = 1.0 / radius;

  double dx, dy, dy2, r,v;
  uint32 x;
  for (uint32 y=0; y<h; y++)
  {
    dy = (double(y) + 0.5) - yc;
    dy2 = dy*dy;
    
    for (x=0; x<w; x++)
    {
      dx = (double(x) + 0.5) - xc;
      r = Math::elxSqrt(dx*dx + dy2) * oneOverRadius;
      v = 0.5*(1. + ::atan2(dx,dy)/M_PI);

      // color
      hls._hue = v;
      hls._luminance  = (r > 1) ? 1.5-r : 0.5;
      hls._saturation = (r > 1) ? 2.0-r : r;

      *prDst++ = hls;
    }
  }

  return psImage;

} // elxCreateColorWheel


#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  Make a ColorWheel image
//============================================================================
bool elxMakeColorWheel(ImageVariant& ioImage, EResolution iResolution, 
    uint32 iWidth, uint32 iHeight)
{
  ioImage = *elxCreateColorWheel<double>(iWidth, iHeight);
  return ioImage.ChangeResolution(iResolution);

} // elxMakeColorWheel


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  ColorWheel image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class ColorWheelFactory : public ImageFactoryBase
{
public:
  ColorWheelFactory() : ImageFactoryBase(IFT_ColorWheel),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter)
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
  }

  virtual const char * GetName() const { return "Color wheel"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    return elxMakeColorWheel(ioImage, resolution, w, h);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_ColorWheel_hpp__
