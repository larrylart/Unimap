//============================================================================
//  Factory/Hearts.hpp                                 Image.Component package
//============================================================================
//  Copyright (C) 2009 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Hearts_hpp__
#define __Factory_Hearts_hpp__

namespace eLynx {
namespace Image {

#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  Make a Hearts image
//============================================================================
bool elxMakeHearts(ImageVariant& ioImage, EResolution iResolution, 
    uint32 iWidth, uint32 iHeight, 
    double iDegreesR, double iDegreesG, double iDegreesB,
    double iPower)
{
  bool bSuccess = false;
  const uint32 w = iWidth;
  const uint32 h = iHeight;
  ImageVariant r,g,b;

  bSuccess = elxMakeGradientWheel(r, RT_Float, w,h, iDegreesR);
  bSuccess = elxMakeGradientWheel(g, RT_Float, w,h, iDegreesG);
  bSuccess = elxMakeGradientWheel(b, RT_Float, w,h, iDegreesB);

  // Merge all planes in one image in RGB color space with float resolution.
  ioImage = ImageVariant(r,g,b, CS_RGB);

  bSuccess = ioImage.ChangeResolution(iResolution);

  double contrast = 0.5*iPower;
  double gamma = 1.0 + 3*iPower;
  ioImage.AdjustBCG(0.0, contrast, gamma);

  return bSuccess;

} // elxMakeHearts


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Hearts image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class HeartsFactory : public ImageFactoryBase
{
public:
  HeartsFactory() : ImageFactoryBase(IFT_Hearts),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _rotationR(s_RotationRParameter),
    _rotationG(s_RotationGParameter),
    _rotationB(s_RotationBParameter),
    _power(s_PowerParameter)
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_rotationR);
    _parameters.push_back(&_rotationG);
    _parameters.push_back(&_rotationB);
    _parameters.push_back(&_power);
  }

  virtual const char * GetName() const { return "Color hearts"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const double rotationR = _rotationR.GetValue();
    const double rotationG = _rotationG.GetValue();
    const double rotationB = _rotationB.GetValue();
    const double power     = _power.GetValue();
    return elxMakeHearts(ioImage, resolution, w, h, 
        rotationR, rotationG, rotationB, power);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterDouble  _rotationR;
  ParameterDouble  _rotationG;
  ParameterDouble  _rotationB;
  ParameterDouble  _power;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Hearts_hpp__
