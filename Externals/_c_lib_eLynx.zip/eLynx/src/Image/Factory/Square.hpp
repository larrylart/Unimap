//============================================================================
//  Factory/Square.hpp                                 Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Square_hpp__
#define __Factory_Square_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a centered square
//----------------------------------------------------------------------------
template <typename T>
inline
ImageImpl< PixelL<T> > * elxCreateSquare(uint32 iWidth, uint32 iHeight, double iCutoff)
{
  const int32 w = iWidth;
  const int32 h = iHeight;
  const int32 xc = w / 2;
  const int32 yc = h / 2;
  const double v = iCutoff * Math::elxMax(xc,yc);
  const int32 r = int32(v + 0.5);

  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(w,h);
  T * prDst = psImage->GetSamples();

  int32 x,y;
  for (y=0; y<h; y++)
    for (x=0; x<w; x++)
      *prDst++ = ((Math::elxAbs(x - xc) < r) && (Math::elxAbs(y - yc) < r)) ? 
        ResolutionTypeTraits<T>::_max : 0;

  return psImage;

} // elxCreateSquare

#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  elxMakeSquare
//============================================================================
bool elxMakeSquare(ImageVariant& ioImage, EResolution iResolution, 
    uint32 iWidth, uint32 iHeight, double iCutoff)
{
  ioImage = *elxCreateSquare<uint8>(iWidth, iHeight, iCutoff);
  return ioImage.ChangeResolution(iResolution);

} // elxMakeSquare

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Square image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class SquareFactory : public ImageFactoryBase
{
public:
  SquareFactory() : ImageFactoryBase(IFT_Square),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _cutoff(s_CutoffParameter)
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_cutoff);
  }

  virtual const char * GetName() const { return "Square"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const double cutoff = _cutoff.GetValue();
    return elxMakeSquare(ioImage, resolution, w, h, cutoff);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterDouble  _cutoff;
};

#endif // USE_ImageFactoryHighLevel


} // namespace Image
} // namespace eLynx

#endif // __Factory_Square_hpp__
