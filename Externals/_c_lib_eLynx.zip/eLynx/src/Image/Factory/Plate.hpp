//============================================================================
//  Factory/Plate.hpp                                  Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Plate_hpp__
#define __Factory_Plate_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a grey plate image
//----------------------------------------------------------------------------
template <typename T> 
inline
ImageImpl< PixelL<T> > * elxCreatePlate(uint32 iWidth, uint32 iHeight, double iScale)
{
  const uint32 w = iWidth;
  const uint32 h = iHeight;

  ImageImpl< PixelL<T> > * psImageL = new ImageImpl< PixelL<T> >(w,h);
  T * prDst = psImageL->GetSamples();

  T d,dx,dy,dy2;
  T sx = 1 / T(iWidth);
  T sy = 1 / T(iHeight);
  T scale = T(2 * iScale * M_PI);
  int32 cX = iWidth / 2;
  int32 cY = iHeight / 2;

  T * p = prDst;
  for (int32 i=h, y=-cY; i--; y++) 
  {
    dy = sy*T(y); 
    dy2 = dy*dy;
    for (int32 j=w, x=-cX; j--; x++) 
    {
      dx = sx*T(x);
      d = (dx*dx + dy2) * scale;
      *p++ = T(0.5) + Math::elxSin(d) / T(2);
    }
  }
  return psImageL;

} // elxCreatePlate


#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  Make a grey plate image
//============================================================================
bool elxMakePlate(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight, double iScale)
{ 
  if (RT_Double == iResolution)
  {
    ioImage = *elxCreatePlate<double>(iWidth, iHeight, iScale);
    return true;
  }
  ioImage = *elxCreatePlate<float>(iWidth, iHeight, iScale);
  return ioImage.ChangeResolution(iResolution);

} // elxMakePlate


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Plate image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class PlateFactory : public ImageFactoryBase
{
public:
  PlateFactory() : ImageFactoryBase(IFT_Plate),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _wave("Wave", 1, 64, 16, 100, 2, "%2.0lf")
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_wave);
  }

  virtual const char * GetName() const { return "Plate"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const uint32 n = (uint32)_wave.GetValue();
    return elxMakePlate(ioImage, resolution, w, h, n); 
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterInteger _wave;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Plate_hpp__
