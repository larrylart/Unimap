//============================================================================
//  Factory/Gaussian.hpp                               Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Gaussian_hpp__
#define __Factory_Gaussian_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create an image as Low pass Gaussian filter
//----------------------------------------------------------------------------
//  Vertical and horizontal symmetry used to compute only 1/4 of image.
//----------------------------------------------------------------------------
//  H(u,v) = exp( - D(u,v) / 2v )
//  D(u,v) = (u - M/2)^2 + (v -N/2)^2 
//----------------------------------------------------------------------------
template <typename T> 
inline
ImageImpl< PixelL<T> > * elxCreateGaussian(
    uint32 iWidth, uint32 iHeight, double iVariance)
{
  const int32 halfW = iWidth/2;
  const int32 halfH = iHeight/2;
  const int32 shx = (iWidth  & 1) - 1; // odd 0, even -1
  const int32 shy = (iHeight & 1) - 1; // odd 0, even -1
  const T tx = (iWidth  & 1) ? T(0) : T(0.5);     // odd 1/2, even 0
  const T ty = (iHeight & 1) ? T(0) : T(0.5);     // odd 1/2, even 0
  const T xc = T(iWidth) / 2;
  const T yc = T(iHeight) / 2;
  const T scale = 1 / T(Math::elxMax(iWidth,iHeight));
  const T s = T( Math::elxMax(xc,yc) / (2*iVariance) );

  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(iWidth,iHeight);
  T * prDst = psImage->GetSamples();

  T u,v,v2;
  int32 x,y,top,bottom;
  for (y=0; y<halfH; y++)
  {
    top    = (halfH-y+shy)*iWidth + halfW;
    bottom = (halfH+y)*iWidth + halfW;
    v = (y + ty) * scale;
    v2 = v * v;
    for (x=0; x<halfW; x++)
    {
      u = (x + tx) * scale; 
      prDst[top-x+shx] = prDst[top+x] = prDst[bottom-x+shx] = prDst[bottom+x] = 
        Math::elxExp( -s * (u*u + v2) );
    }
  }

  return psImage;

} // elxCreateGaussian

#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  elxMakeGaussian
//============================================================================
bool elxMakeGaussian(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight, double iVariance)
{
  if (RT_Double == iResolution)
  {
    ioImage = *elxCreateGaussian<double>(iWidth, iHeight, iVariance);
    return true;
  }
  ioImage = *elxCreateGaussian<float>(iWidth, iHeight, iVariance);
  return ioImage.ChangeResolution(iResolution);

} // elxMakeGaussian

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Gaussian image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class GaussianFactory : public ImageFactoryBase
{
public:
  GaussianFactory() : ImageFactoryBase(IFT_Gaussian),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _variance(s_VarianceParameter)
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_variance);
  }

  virtual const char * GetName() const { return "Gaussian"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const double variance = _variance.GetValue();
    return elxMakeGaussian(ioImage, resolution, w, h, variance);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterDouble  _variance;
};

#endif // USE_ImageFactoryHighLevel


} // namespace Image
} // namespace eLynx

#endif // __Factory_Gaussian_hpp__
