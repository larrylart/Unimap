//============================================================================
//  Factory/Bands.hpp                                  Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Bands_hpp__
#define __Factory_Bands_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a Bands image
//----------------------------------------------------------------------------
template <typename T>
inline
ImageImpl< PixelRGB<T> > * elxCreateBands(uint32 iWidth, uint32 iBandHeight)
{
  const uint32 w = iWidth;
  const uint32 h = iBandHeight*8;

  ImageImpl< PixelRGB<T> > * psImage = new ImageImpl< PixelRGB<T> >(w,h);
  T * prDst = psImage->GetSamples();

  const uint32 size = iWidth*3*iBandHeight;
  uint32 i, j;
  T * prGrey  = prDst;
  T * prRed   = prDst + size;
  T * prGreen = prDst + size*2 + 1;
  T * prBlue  = prDst + size*3 + 2;

  T * prCyan    = prDst + size*4;
  T * prYellow  = prCyan + size;
  T * prMagenta = prYellow + size;
  T * prGrey2   = prMagenta + size;

  double dx = 1./double(iWidth);
  double v;
  for (j=0; j<iBandHeight; j++)
  {
    v = 0.;
    for (i=0; i<iWidth; i++, v+=dx)
    {
      const T t = T(v);
      *prGrey++ = t; *prGrey++ = t; *prGrey++ = t;
      *prRed    = t; prRed +=3;
      *prGreen  = t; prGreen +=3;
      *prBlue   = t; prBlue +=3;

      const T t2 = 1 - T(v);
      prYellow[0]  = prYellow[1]  = t2; prYellow+=3;
      prMagenta[0] = prMagenta[2] = t2; prMagenta+=3;
      prCyan[1]    = prCyan[2]    = t2; prCyan+=3;
      *prGrey2++ = t2; *prGrey2++ = t2; *prGrey2++ = t2;
    }
  }

  return psImage;

} // elxCreateBands

#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  elxMakeBands
//============================================================================
bool elxMakeBands(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iBandHeight)
{
  ioImage = *elxCreateBands<double>(iWidth, iBandHeight);
  if (RT_Double == iResolution) return true;
  return ioImage.ChangeResolution(iResolution);

} // elxMakeBands


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Bands image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class BandsFactory : public ImageFactoryBase
{
public:
  BandsFactory() : ImageFactoryBase(IFT_Bands),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _band("Band", 4, 256, 32, 100, 3, "%3.0lf")
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_band);
  }

  virtual const char * GetName() const { return "Bands"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 band = (uint32)_band.GetValue();
    return elxMakeBands(ioImage, resolution, w, band);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _band;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Bands_hpp__
