//============================================================================
//  Factory/Blend.hpp                                  Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Blend_hpp__
#define __Factory_Blend_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a Blend image
//----------------------------------------------------------------------------
template <typename T>
inline
ImageImpl< PixelRGB<T> > * elxCreateBlend(uint32 iWidth, uint32 iHeight, 
    double iBlend)
{
  const uint32 w = iWidth;
  const uint32 h = iHeight;

  ImageImpl< PixelRGB<T> > * psImage = new ImageImpl< PixelRGB<T> >(w,h);
  T * prSrc = psImage->GetSamples();

  int32 i, j;
  T r,g,b;
  T x,y,d;
	
  double dx = 2./w;
  double dy = 2./h;
  const double a = 0.4;
  double xR =  a*0.0;
  double yR = -a/2.0;
  double xG = a*cos(M_PI/6.0);
  double yG = a*sin(M_PI/6.0);
  double xB = -xG;
  double yB =  yG;
	
  T * p = prSrc;
  for (i = h, y = -1.0; i--; y += dy) 
  {
    for (j = w, x = -1.0; j--; x += dx) 
    {
      d = (x - xR)*(x - xR) + (y - yR)*(y - yR);
      if (d > 1.0) d = 0.0; else d = 1.0 - sqrt(d*iBlend);
      r = d;

      d = (x - xG)*(x - xG) + (y - yG)*(y - yG);
      if (d > 1.0) d = 0.0; else d = 1.0 - sqrt(d*iBlend);
      g = d;

      d = (x - xB)*(x - xB) + (y - yB)*(y - yB);
      if (d > 1.0) d = 0.0; else d = 1.0 - sqrt(d*iBlend);
      b = d;

      *p++ = r;
      *p++ = g;
      *p++ = b;
    }
  }
  return psImage;

} // elxCreateBlend

#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  elxMakeBlend
//============================================================================
bool elxMakeBlend(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight, double iRadius)
{
  ioImage = *elxCreateBlend<double>(iWidth, iHeight, iRadius);
  if (RT_Double == iResolution) return true;
  return ioImage.ChangeResolution(iResolution);

} // elxMakeBlend


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Blend image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class BlendFactory : public ImageFactoryBase
{
public:
  BlendFactory() : ImageFactoryBase(IFT_Blend),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _blend("Blend", 0.1, 4., 1.0, 100, 3, "%1.2lf")
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_blend);
  }

  virtual const char * GetName() const { return "Color blend"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const double blend = _blend.GetValue();
    return elxMakeBlend(ioImage, resolution, w, h, blend);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterDouble  _blend;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Blend_hpp__
