//============================================================================
//  Factory/Butterworth.hpp                            Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Butterworth_hpp__
#define __Factory_Butterworth_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create an image as Low pass Butterworth filter
//----------------------------------------------------------------------------
//  Vertical and horizontal symmetry used to compute only 1/4 of image.
//----------------------------------------------------------------------------
//  H(u,v) = 1/( 1 + (D(u,v)/D0)^2n )
//  D(u,v) = ( (u - M/2)^2 + (v - N/2)^2 )^1/2
//----------------------------------------------------------------------------
template <typename T> 
inline
ImageImpl< PixelL<T> > * elxCreateButterworth(
    uint32 iWidth, uint32 iHeight, 
    double iCutoff, uint32 iRank)
{
  const int32 halfW = iWidth/2;
  const int32 halfH = iHeight/2;
  const int32 sx = (iWidth  & 1) - 1; // odd 0, even -1
  const int32 sy = (iHeight & 1) - 1; // odd 0, even -1
  const T tx = (iWidth  & 1) ? T(0) : T(0.5);     // odd 1/2, even 0
  const T ty = (iHeight & 1) ? T(0) : T(0.5);     // odd 1/2, even 0
  const T n = T(iRank);
  T s = T(1) / ( T(iCutoff) * Math::elxMax(halfW,halfH) );
  s = s*s;

  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(iWidth,iHeight);
  T * prDst = psImage->GetSamples();

  T x2,y2;
  int32 x,y,top,bottom;
  for (y=0; y<halfH; y++)
  {
    top    = (halfH-y+sy)*iWidth + halfW;
    bottom = (halfH+y)*iWidth + halfW;
    y2 = y+ty; 
    y2 *= y2;
    for (x=0; x<halfW; x++)
    {
      x2 = x+tx; 
      x2 *= x2;
      prDst[top-x+sx] = prDst[top+x] = prDst[bottom-x+sx] = prDst[bottom+x] = 
        T(1) / (T(1) + Math::elxPow(s*(x2+y2), n));
    }
  }
  return psImage;

} // elxCreateButterworth


#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  elxMakeButterworth
//============================================================================
bool elxMakeButterworth(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight, double iCutoff, uint32 iRank)
{
  if (RT_Double == iResolution)
  {
    ioImage = *elxCreateButterworth<double>(iWidth, iHeight, iCutoff, iRank);
    return true;
  }
  ioImage = *elxCreateButterworth<float>(iWidth, iHeight, iCutoff, iRank);
  return ioImage.ChangeResolution(iResolution);

} // elxMakeButterworth


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Butterworth image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class ButterworthFactory : public ImageFactoryBase
{
public:
  ButterworthFactory() : ImageFactoryBase(IFT_Butterworth),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _cutoff(s_CutoffParameter),
    _rank("Rank", 1, 8, 1, 70, 1, "%1.0lf")
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_cutoff);
    _parameters.push_back(&_rank);
  }

  virtual const char * GetName() const { return "Butterworth"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const double cutoff = _cutoff.GetValue();
    const uint32 rank = (uint32)_rank.GetValue();
    return elxMakeButterworth(ioImage, resolution, w, h, cutoff, rank);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterDouble  _cutoff;
  ParameterInteger _rank;
};

#endif // USE_ImageFactoryHighLevel


} // namespace Image
} // namespace eLynx

#endif // __Factory_Butterworth_hpp__
