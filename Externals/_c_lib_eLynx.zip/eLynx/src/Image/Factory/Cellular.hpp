//============================================================================
//  Factory/Cellular.hpp                               Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Cellular_hpp__
#define __Factory_Cellular_hpp__

#include <elx/math/Geometry.h>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a Cellular image
//----------------------------------------------------------------------------
template <typename T>
inline
ImageImpl< PixelL<T> > * elxCreateCellular(uint32 iWidth, uint32 iHeight,
    uint32 iCells, double iGamma, int32 iSeed)
{
  const uint32 w = iWidth;
  const uint32 h = iHeight;
  const uint32 nCell = iCells;
  Math::elxRandomReset(iSeed);

  uint32 i;

  // --- init cells ---
  Math::Point2fList cells;
  for (i=0; i<nCell; i++)
  {
    float x = (float)Math::elxRandom();
    float y = (float)Math::elxRandom();
    cells.push_back( Math::Point2f(x,y) );
  }

  // --- compute distances ---
  float minDistance = floatMAX;
  float maxDistance = 0.0f;
  float * plDistances = new float [w*h];
  float * prDistance = plDistances;

  uint32 x,y;
  float fx,fy,dx,dy;
  float d, mini;

  const float sx = 1.0f / (w - 1);
  const float sy = 1.0f / (h - 1);

  for (y=0; y<h; y++)
  {
    fy = sy * y;
    for (x=0; x<w; x++)
    {
      fx = sx * x;
      mini = floatMAX;
      for (i=0; i<nCell; i++)
      {
        dx = cells[i]._x - fx;
        dy = cells[i]._y - fy;
        d = dx*dx + dy*dy;
        if (d < mini) mini = d;
      }
      d = mini;
      *prDistance++ = d;
      if (d < minDistance) minDistance = d;
      if (d > maxDistance) maxDistance = d;
    }
  }

  // --- build palette ---
  enum { nColors = 256 };
  float palette[nColors];

  const float g = 1.0f / float(iGamma);
  for (int32 i=0; i<nColors; i++)
  {
    // gamma correction
    float fc = float(i)/255.0f;
    palette[i] = fc = powf(fc, g);
  }

  // --- fill image map ---

  // create empty image
  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(w,h);
  PixelL<T> * prDst = psImage->GetPixel();
  PixelL<T> * prEnd = psImage->GetPixelEnd();

  // fill map
  uint32 s;
  float delta = 255.0f;
  if (maxDistance  != minDistance)
    delta /= (maxDistance - minDistance);
  prDistance = plDistances;
  do 
  { 
    s = (uint32)(delta * (*prDistance - minDistance));
    prDistance++;
    prDst->_luminance = palette[uint8(s)];
  } 
  while (++prDst != prEnd);

  // --- cleanup ---
  elxSAFE_DELETE_LIST(plDistances);

  return psImage;

} // elxCreateCellular

#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  elxMakeCellular
//============================================================================
bool elxMakeCellular(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight, uint32 iCells, double iGamma, int32 iSeed)
{
  ioImage = *elxCreateCellular<float>(iWidth, iHeight, iCells, iGamma, iSeed);
  if (RT_Float == iResolution) return true;
  return ioImage.ChangeResolution(iResolution);

} // elxMakeCellular


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Cellular image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class CellularFactory : public ImageFactoryBase
{
public:
  CellularFactory() : ImageFactoryBase(IFT_Cellular),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter),
    _cells("Cells", 2, 100, 30, 99, 3, "%3.0lf"),
    _gamma("Gamma", 1.3, 2.7, 1.8, 100, 3, "%1.2lf"),
    _seed(s_SeedParameter)
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_cells);
    _parameters.push_back(&_gamma);
    _parameters.push_back(&_seed);
  }

  virtual const char * GetName() const { return "Cellular"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const uint32 cells = (uint32)_cells.GetValue();
    const double gamma = _gamma.GetValue();
    const int32 seed = _seed.GetValue();
    return elxMakeCellular(ioImage, resolution, w, h, cells, gamma, seed);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterInteger _cells;
  ParameterDouble  _gamma;
  ParameterInteger _seed;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Cellular_hpp__
