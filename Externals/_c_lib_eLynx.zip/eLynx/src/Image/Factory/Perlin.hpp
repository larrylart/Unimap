//============================================================================
//  Factory/Perlin.hpp                                 Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Perlin_hpp__
#define __Factory_Perlin_hpp__

namespace eLynx {
namespace Image {

namespace {

double elxInterPolation(double a, double b, double c) 
{ 
  return (a + (b-a)*c*c*(3 - 2*c)); 
}

double elxPerlin(int32 x)
{
  x = (x<<13)^x;
  return (((x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 2147483648.0);
}

double elxPerlinNoise(double iX, double iY, int32 iWidth, int32 iOctaves, int32 iSeed, double iPeriod)
{
  const int32 amplitude = 120;
  const double frequency = 1./iPeriod;

  double a, b, value, xZone, yZone;
  int32 box, n, xStep, yStep, noisedata; 

  for (int32 s=0; s<iOctaves; s++)
  {
    n = int32(iWidth * frequency);
    xStep = int32(iX * frequency);
    yStep = int32(iY * frequency);

    xZone = iX * frequency - xStep;
    yZone = iY * frequency - yStep;

    box = xStep + yStep*n;
    noisedata = box + iSeed;

    a = elxInterPolation( elxPerlin(noisedata),     elxPerlin(noisedata + 1),     xZone);
    b = elxInterPolation( elxPerlin(noisedata + n), elxPerlin(noisedata + 1 + n), xZone);

    value = elxInterPolation(a, b, yZone) * amplitude;
  }
  return value;

} // elxPerlinNoise

}; // namespace

//----------------------------------------------------------------------------
//  Create an image with perlin noise
//----------------------------------------------------------------------------
template <typename T> 
inline
ImageImpl< PixelL<T> > * elxCreatePerlin(uint32 iWidth, uint32 iHeight,
    uint32 iSeed, uint32 iPeriod, double iScale)
{
  const uint32 w = iWidth;
  const uint32 h = iHeight;
  const uint32 seed = iSeed;
  const uint32 width = iPeriod;
  const double scale = iScale;

  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(w,h);
  T * prDst = psImage->GetSamples();

  double v1,v2,v3,v4,v5,v6, l;
  uint32 x,y;
  for (y=0; y<w; y++)
    for (x=0; x<h; x++)
    {
      v1 = elxPerlinNoise(x*scale, y*scale, width, 1, seed, 100);
      v2 = elxPerlinNoise(x*scale, y*scale, width, 1, seed, 25);
      v3 = elxPerlinNoise(x*scale, y*scale, width, 1, seed, 12.5);
      v4 = elxPerlinNoise(x*scale, y*scale, width, 1, seed, 6.25);
      v5 = elxPerlinNoise(x*scale, y*scale, width, 1, seed, 3.125);
      v6 = elxPerlinNoise(x*scale, y*scale, width, 1, seed, 1.56);
             
      l = v1 + v2*.25 + v3*.125 + v4*.0625 + v5*.03125 + v6*.0156;
      *prDst++ = T(l);
    }

  return psImage;

} // elxCreatePerlin


#ifdef USE_ImageFactoryHighLevel

//----------------------------------------------------------------------------
//  elxMakePerlin
//----------------------------------------------------------------------------
bool elxMakePerlin(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight, uint32 iSeek, uint32 iPeriod, double iScale)
{
  ioImage = *elxCreatePerlin<uint8>(iWidth, iHeight, iSeek, iPeriod, iScale);
  if (RT_UINT8 == iResolution) return true;
  return ioImage.ChangeResolution(iResolution);

} // elxMakePerlin

//----------------------------------------------------------------------------
//  Perlin image factory
//----------------------------------------------------------------------------
class PerlinFactory : public ImageFactoryBase
{
public:
  PerlinFactory() : ImageFactoryBase(IFT_Perlin),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter),
    _height(s_heightParameter),
    _seed("Seed", 1, 100, 63, 99, 2, "%2.0lf"),
    _period("Period", 10000, 30000, 12413, 100, 5, "%5.0lf"),
    _scale("Scale", 0.01, 10.0, 1.0, 100, 4, "%2.2lf")
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_seed);
    _parameters.push_back(&_period);
    _parameters.push_back(&_scale);
  }

  virtual const char * GetName() const { return "Perlin"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const uint32 seed = (uint32)_seed.GetValue();
    const uint32 period = (uint32)_period.GetValue();
    const double scale = _scale.GetValue();
    return elxMakePerlin(ioImage, resolution, w, h, seed, period, scale);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterInteger _seed;
  ParameterInteger _period;
  ParameterDouble  _scale;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Perlin_hpp__
