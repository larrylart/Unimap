//============================================================================
//  Factory/Gradient.hpp                               Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Gradient_hpp__
#define __Factory_Gradient_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a Gradient image using zigzag scan algorithm
//----------------------------------------------------------------------------
template <typename T>
inline
ImageImpl< PixelL<T> > * elxCreateGradient(uint32 iWidth, uint32 iHeight)
{
  const int32 w = (int32) iWidth;
  const int32 h = (int32) iHeight;

  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(iWidth,iHeight);
  T * prSrc = psImage->GetSamples();
  T * prDst = prSrc;
  T * prEnd = psImage->GetSamplesEnd();

  double v = 0.0;
  const double dv = 1./double(iWidth * iHeight);

  // Zigzag scan algorithm
  enum { go_down, go_up  } dir = go_up;
  int32 dx = +1, dy = -1;
  int32 x = 0, y = 0;

  do 
  { 
    prDst[y*w + x] = T(v);
    v += dv;

    // go next
    x += dx;
    y += dy;

    bool bChange = false;
    switch (dir)
    {
      case go_down: // by left
        if (y == h)     { bChange = true; x+=2; --y; }
        else if (x < 0) { bChange = true; ++x; }
        if (bChange)    { dir = go_up; dx = +1; dy = -1; }
        break;

      case go_up: // by right
        if (x == w)     { bChange = true; y+=2; --x; }
        else if (y < 0) { bChange = true; ++y; }
        if (bChange)    { dir = go_down; dx = -1; dy = +1; }
        break;

      default:
        break;
    }
  } 
  while (++prSrc != prEnd);

  return psImage;

} // elxCreateGradient

#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  elxMakeGradient
//============================================================================
bool elxMakeGradient(ImageVariant& ioImage, EResolution iResolution,
    uint32 iWidth, uint32 iHeight)
{
  ioImage = *elxCreateGradient<double>(iWidth, iHeight);
  if (RT_Double == iResolution) return true;
  return ioImage.ChangeResolution(iResolution);

} // elxMakeGradient

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Gradient image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class GradientFactory : public ImageFactoryBase
{
public:
  GradientFactory() : ImageFactoryBase(IFT_Gradient),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter), 
    _height(s_heightParameter)
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
  }

  virtual const char * GetName() const { return "Gradient"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    return elxMakeGradient(ioImage, resolution, w, h);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
};

#endif // USE_ImageFactoryHighLevel


} // namespace Image
} // namespace eLynx

#endif // __Factory_Gradient_hpp__
