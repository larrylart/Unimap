//============================================================================
//  Factory/Checker.hpp                                Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Factory_Checker_hpp__
#define __Factory_Checker_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Create a checker image
//----------------------------------------------------------------------------
template <typename T>
inline
ImageImpl< PixelL<T> > * elxCreateChecker(uint32 iWidth, uint32 iHeight, uint32 iN)
{
  const uint32 w = iWidth;
  const uint32 h = iHeight;

  ImageImpl< PixelL<T> > * psImage = new ImageImpl< PixelL<T> >(w,h);
  T * prDst = psImage->GetSamples();

  uint32 i, j;
  for (j=0; j<h; j++)
    for (i=0; i<w; i++)
      *prDst++ = ResolutionTypeTraits<T>::_max *( (i>>iN & 1) ^ (j>>iN & 1) ); 

  return psImage;

} // elxCreateChecker


#ifdef USE_ImageFactoryHighLevel

//============================================================================
//  Make a checker image
//============================================================================
bool elxMakeChecker(ImageVariant& ioImage, EResolution iResolution, 
    uint32 iWidth, uint32 iHeight, uint32 iN)
{
  ioImage = *elxCreateChecker<uint8>(iWidth, iHeight, iN);
  return ioImage.ChangeResolution(iResolution);

} // elxMakeChecker


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Checker image factory
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class CheckerFactory : public ImageFactoryBase
{
public:
  CheckerFactory() : ImageFactoryBase(IFT_Checker),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter),
    _height(s_heightParameter),
    _lenght("Lenght", 1, 16, 4, 100, 2, "%2.0lf")
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
    _parameters.push_back(&_lenght);
  }

  virtual const char * GetName() const { return "Checker"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    const EResolution resolution = (EResolution)_resolution.GetValue();
    const uint32 w = (uint32)_width.GetValue();
    const uint32 h = (uint32)_height.GetValue();
    const uint32 l = (uint32)_lenght.GetValue();
    return elxMakeChecker(ioImage, resolution, w,h, l);
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
  ParameterInteger _lenght;
};

#endif // USE_ImageFactoryHighLevel

} // namespace Image
} // namespace eLynx

#endif // __Factory_Checker_hpp__
