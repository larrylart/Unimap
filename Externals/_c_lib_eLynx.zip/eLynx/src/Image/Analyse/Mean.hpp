//============================================================================
//  Analyse/Mean.hpp                                   Image.Component package
//============================================================================
//  Usage : image analyse interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Analyse_Mean_hpp__
#define __Analyse_Mean_hpp__

namespace eLynx {
namespace Image {


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//                        mean = Sum N(sample) / N

//----------------------------------------------------------------------------
//  ComputeMean for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMean(
    const ImageImpl<Pixel>& iImage,
    double& oMean, 
    bool ibNormalized)
{
  if (!iImage.IsValid())
    return false;

  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::BigOverflow_type B;
  const T * prSrc = iImage.GetSamples();
  const T * prEnd = iImage.GetSamplesEnd();

  B sum = B(0);
  do
  {
    sum += *prSrc;
  }
  while (++prSrc != prEnd);
  
  const uint32 count = iImage.GetSampleCount(); 
  oMean = double(sum) / double(count);

  if (ibNormalized)
    oMean *= ResolutionTypeTraits<T>::_normScale;

  return true;

} // ComputeMean


//----------------------------------------------------------------------------
//  ComputeMean for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMean(
    const ImageImpl<Pixel>& iImage,
    double (&oMean)[PC_MAX], 
    bool ibNormalized)
{
  if (!iImage.IsValid())
    return false;

  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::BigOverflow_type B;
  
  const uint32 nChannel = Pixel::GetChannelCount();
  const Pixel * prSrc = iImage.GetPixel();
  const Pixel * prEnd = iImage.GetPixelEnd();

  uint32 c;
  B sum[PC_MAX];
  for (c=0; c<nChannel; c++) sum[c] = B(0);
  do
  {
    for (c=0; c<nChannel; c++)
      sum[c] += prSrc[0]._channel[c];
  }
  while (++prSrc != prEnd);
  
  double OneOvCount = 1.0 / double(iImage.GetPixelCount());
  if (ibNormalized)
    OneOvCount *= ResolutionTypeTraits<T>::_normScale;

  for (c=0; c<nChannel; ++c)
    oMean[c] = double(sum[c]) * OneOvCount;

  return true;

} // ComputeMean

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageAnalyseProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ComputeMean for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMean(
    const AbstractImage& iImage, 
    double& oMean, 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMean(image, oMean, ibNormalized);

} // ComputeMean


//----------------------------------------------------------------------------
//  ComputeMean for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMean(
    const AbstractImage& iImage, 
    double (&oMean)[PC_MAX], 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMean(image, oMean, ibNormalized);

} // ComputeMean


} // namespace Image
} // namespace eLynx

#endif // __Analyse_Mean_hpp__
