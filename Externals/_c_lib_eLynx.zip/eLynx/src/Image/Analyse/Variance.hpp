//============================================================================
//  Analyse/Variance.hpp                               Image.Component package
//============================================================================
//  Usage : image analyse interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Analyse_Variance_hpp__
#define __Analyse_Variance_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ComputeVariance for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeVariance(
    const ImageImpl<Pixel>& iImage,
    double& oVariance)
{
  if (!iImage.IsValid())
    return false;

  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  const T * prSrc = iImage.GetSamples();
  const T * prEnd = iImage.GetSamplesEnd();

  F s,sum,pwr;
  sum = pwr = F(0);
  do
  {
    s = F(*prSrc);
    sum += s;
    pwr += s*s;
  }
  while (++prSrc < prEnd);

  const double count = double( iImage.GetSampleCount() );
  const double mean = double(sum) / count;
  const double energy = double(pwr) / count;
  
  oVariance = energy - mean*mean;
  return true;

} // ComputeVariance


//----------------------------------------------------------------------------
//  ComputeVariance for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeVariance(
    const ImageImpl<Pixel>& iImage,
    double(&oVariance)[PC_MAX])
{
  if (!iImage.IsValid())
    return false;

  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

  const uint32 nChannel = Pixel::GetChannelCount();
  const Pixel * prSrc = iImage.GetPixel();
  const Pixel * prEnd = iImage.GetPixelEnd();
  
  F s, sum[PC_MAX], nrj[PC_MAX];
  uint32 c;
  for (c=0; c<nChannel; c++)
    sum[c] = nrj[c] = F(0);

  do
  {
    for (c=0; c<nChannel; c++)
    {
      s = F(prSrc[0]._channel[c]);
      sum[c] += s;
      nrj[c] += s*s;
    }
  }
  while (++prSrc != prEnd);

  const double count = double( iImage.GetSampleCount() );
  for (c=0; c<nChannel; c++)
  {
    const double mean   = double(sum[c]) / count;
    const double energy = double(nrj[c]) / count;
    oVariance[c] = energy - mean*mean;
  }
  return true;

} // ComputeVariance



//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageAnalyseProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ComputeVariance for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeVariance(
    const AbstractImage& iImage, 
    double& oVariance) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeVariance(image, oVariance);

} // ComputeVariance


//----------------------------------------------------------------------------
//  ComputeVariance for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeVariance(
    const AbstractImage& iImage, 
    double(&oVariance)[PC_MAX]) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeVariance(image, oVariance);

} // ComputeVariance

} // namespace Image
} // namespace eLynx

#endif // __Analyse_Variance_hpp__
