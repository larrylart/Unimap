//============================================================================
//  Analyse/Deviation.hpp                              Image.Component package
//============================================================================
//  Usage : Implement the standard deviation of an image
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Analyse_Deviation_hpp__
#define __Analyse_Deviation_hpp__

namespace eLynx {
namespace Image {

/*
Here some explanations about resolution to be used for computation:

Suppose we are using a picture from CANON 300D (3098 x 2056, 12-bits uint16)

* Computing sum of pixels:

  the bad case, for overflow, is when all pixels are white (maximum values).

  -with 12 bits:  L = 2^12 - 1 = 4095

   Sum of all pixels: 
	Sum = 3098 x 2056 x 4096 = 6,369,488 * 4096 = 26,083,053,360
	Sum = 6,12AB,CF30 in hexadecimal notation
	We need more that 32-bit resolution to prevent from overflow => 64-bit

  -with 16 bits:  L = 2^16 - 1 = 65535

   Sum of all pixels: 
	Sum = 3098 x 2056 x 65535 = 417,424,396,080
	Sum = 61,306E,CF30 in hexadecimal notation
	We need more that 32-bit resolution to prevent from overflow => 64-bit


  -with 8 bits:  L = 2^8 - 1 = 255

   Sum of all pixels: 
	Sum = 3098 x 2056 x 255= 1,624,219,440
	Sum = 60CF,9F30 in hexadecimal notation
	32-bit resolution is ok here to prevent from overflow => 32-bit

	if image size is scaled by 4:
	Sum = 3098 x 2056 x 255 x4x4 = 6,0CF9,F300 => 64-bit
*/

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ComputeStandardDeviation for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeStandardDeviation(
    const ImageImpl<Pixel>& iImage,
    double& oDeviation,
    double& oMean,
    bool ibNormalized)
{
  if (!iImage.IsValid())
    return false;

  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::BigOverflow_type B;
  const T * prSrc = iImage.GetSamples();
  const T * prEnd = iImage.GetSamplesEnd();

  B s = B(0);
  do
  {
    s += *prSrc;
  }
  while (++prSrc != prEnd);

  const double OneOvCount = 1.0 / double(iImage.GetSampleCount());
  oMean = double(s) * OneOvCount;
  
  double sum = 0.0;
  double delta;
  prSrc = iImage.GetSamples();
  do
  {
    delta = double(*prSrc) - oMean;
    sum += delta*delta;
  }
  while (++prSrc != prEnd);

  oDeviation = Math::elxSqrt( sum * OneOvCount );

  if (ibNormalized)
  {
    oMean *= ResolutionTypeTraits<T>::_normScale;
    oDeviation *= ResolutionTypeTraits<T>::_normScale;
  }
  return true;

} // ComputeStandardDeviation


//----------------------------------------------------------------------------
//  ComputeStandardDeviation for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeStandardDeviation(
    const ImageImpl<Pixel>& iImage,
    double(&oDeviation)[PC_MAX],
    double(&oMean)[PC_MAX], 
    bool ibNormalized)
{
  if (!iImage.IsValid())
    return false;

  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::BigOverflow_type B;
  const uint32 nChannel = Pixel::GetChannelCount();
  const Pixel * prSrc = iImage.GetPixel();
  const Pixel * prEnd = iImage.GetPixelEnd();

  uint32 c;
  B s[PC_MAX];
  for (c=0; c<nChannel; c++) s[c] = B(0);
  do
  {
    for (c=0; c<nChannel; c++)
      s[c] += prSrc[0]._channel[c];
  }
  while (++prSrc != prEnd);

  double sum[PC_MAX];
  const double OneOvCount = 1.0 / double(iImage.GetSampleCount());
  for (c=0; c<nChannel; c++)
  {
    oMean[c] = double(s[c]) * OneOvCount;
    sum[c] = 0.0;
  }
  
  double delta;
  prSrc = iImage.GetPixel();
  do
  {
    for (c=0; c<nChannel; c++)
    {
      delta = double(prSrc[0]._channel[c]) - oMean[c];
      sum[c] += delta*delta;
    }
  }
  while (++prSrc != prEnd);

  for (c=0; c<nChannel; c++)
    oDeviation[c] = Math::elxSqrt(sum[c] * OneOvCount);

  if (ibNormalized)
    for (c=0; c<nChannel; c++)
    {
      oMean[c] *= ResolutionTypeTraits<T>::_normScale;
      oDeviation[c] *= ResolutionTypeTraits<T>::_normScale;
    }

  return true;

} // ComputeStandardDeviation


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageAnalyseProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ComputeStandardDeviation for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeStandardDeviation(
    const AbstractImage& iImage, 
    double& oDeviation,
    double& oMean, 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeStandardDeviation(image, oDeviation, oMean, ibNormalized);

} // ComputeStandardDeviation

//----------------------------------------------------------------------------
//  ComputeStandardDeviation for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeStandardDeviation(
    const AbstractImage& iImage, 
    double& oDeviation, 
    bool ibNormalized) const
{
  double dummy;
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeStandardDeviation(image, oDeviation, dummy, ibNormalized);

} // ComputeStandardDeviation


//----------------------------------------------------------------------------
//  ComputeStandardDeviation for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeStandardDeviation(
    const AbstractImage& iImage, 
    double(&oDeviation)[PC_MAX], 
    bool ibNormalized) const
{
  double dummy[PC_MAX];
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeStandardDeviation(image, oDeviation, dummy, ibNormalized);

} // ComputeStandardDeviation

//----------------------------------------------------------------------------
//  ComputeStandardDeviation for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeStandardDeviation(
    const AbstractImage& iImage, 
    double(&oDeviation)[PC_MAX],
    double(&oMean)[PC_MAX], 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeStandardDeviation(image, oDeviation, oMean, ibNormalized);

} // ComputeStandardDeviation

} // namespace Image
} // namespace eLynx

#endif // __Analyse_Deviation_hpp__
