//============================================================================
//  Analyse/Histogram.hpp                              Image.Component package
//============================================================================
//  Usage : image analyse interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Analyse_Histogram_hpp__
#define __Analyse_Histogram_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ComputeHistogram :
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeHistogram(
    const ImageImpl<Pixel>& iImage, 
    ImageHistogram& oHistogram)
{
  return false;
}

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                             PixelL<T>
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

//----------------------------------------------------------------------------
//                             PixelLub
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelLub >::ComputeHistogram(
    const ImageImpl< PixelLub >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(1);
  uint32 * prMap = oHistogram.GetChannel(0).GetMap();

  const PixelLub * prSrc = iImage.GetPixel();
  const PixelLub * prEnd = iImage.GetPixelEnd();
  do 
  { 
    prMap[ prSrc->_luminance ]++; 
  }  
  while (++prSrc != prEnd);

  int32 k = 255;
  int32 j = 511;
  for (uint32 i=0; i<255; i++)
  {
    int32 v = prMap[k--];
    prMap[j--] = v;
    prMap[j--] = v;
  }
  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelLub

//----------------------------------------------------------------------------
//                             PixelLus
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelLus >::ComputeHistogram(
    const ImageImpl< PixelLus >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(1);
  uint32 * prMap = oHistogram.GetChannel(0).GetMap();
  const PixelLus * prSrc = iImage.GetPixel();
  const PixelLus * prEnd = iImage.GetPixelEnd();
  do 
  { 
    prMap[ prSrc->_luminance >> 7 ]++; 
  }  
  while (++prSrc != prEnd);

  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelLus

//----------------------------------------------------------------------------
//                             PixelLf
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelLf >::ComputeHistogram(
    const ImageImpl< PixelLf >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(1);
  uint32 * prMap = oHistogram.GetChannel(0).GetMap();
  const PixelLf * prSrc = iImage.GetPixel();
  const PixelLf * prEnd = iImage.GetPixelEnd();
  int32 idx;
  do 
  { 
    idx = int32(511.f * prSrc->_luminance + 0.5f);
    // clamp for un-Normalized float
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap[idx]++;
  } 
  while (++prSrc != prEnd);

  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelLf

//----------------------------------------------------------------------------
//                             PixelLd
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelLd >::ComputeHistogram(
    const ImageImpl< PixelLd >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(1);
  uint32 * prMap = oHistogram.GetChannel(0).GetMap();
  const PixelLd * prSrc = iImage.GetPixel();
  const PixelLd * prEnd = iImage.GetPixelEnd();
  int32 idx;
  do 
  { 
    idx = int32(511.0 * prSrc->_luminance + 0.5);
    // clamp for un-Normalized float
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap[idx]++;
  } 
  while (++prSrc != prEnd);

  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelLd


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                             PixelLA<T>
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

//----------------------------------------------------------------------------
//                             PixelLAub
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelLAub >::ComputeHistogram(
    const ImageImpl< PixelLAub >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(2);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();

  const PixelLAub * prSrc = iImage.GetPixel();
  const PixelLAub * prEnd = iImage.GetPixelEnd();
  do 
  { 
    prMap0[ prSrc->_luminance ]++; 
    prMap1[ prSrc->_alpha ]++; 
  }  
  while (++prSrc != prEnd);

  // map 256 into 512 values
  uint32 k = 255, j = 511, l,a;
  for (uint32 i=0; i<256; i++, j--, k--)
  {
    l = prMap0[k]; a = prMap1[k];
    prMap0[j] = l; prMap1[j] = a;
    j--;
    prMap0[j] = l; prMap1[j] = a;
  }
  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelLAub

//----------------------------------------------------------------------------
//                             PixelLAus
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelLAus >::ComputeHistogram(
    const ImageImpl< PixelLAus >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(2);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();

  const PixelLAus * prSrc = iImage.GetPixel();
  const PixelLAus * prEnd = iImage.GetPixelEnd();
  do 
  { 
    prMap0[ prSrc->_luminance >> 7 ]++; 
    prMap1[ prSrc->_alpha >> 7 ]++; 
  }  
  while (++prSrc != prEnd);

  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelLAus

//----------------------------------------------------------------------------
//                             PixelLAf
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelLAf >::ComputeHistogram(
    const ImageImpl< PixelLAf >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(2);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();

  const PixelLAf * prSrc = iImage.GetPixel();
  const PixelLAf * prEnd = iImage.GetPixelEnd();
  float l,a;  
  uint32 idx;
  do 
  { 
    // clamp un-normalized float
    l = prSrc->_luminance;
    idx = uint32(511.f * l + 0.5f);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap0[idx]++;

    a = prSrc->_alpha;
    idx = uint32(511.f * a + 0.5f);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap1[idx]++;
  } 
  while (++prSrc != prEnd);

  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelLAf

//----------------------------------------------------------------------------
//                             PixelLAd
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelLAd >::ComputeHistogram(
    const ImageImpl< PixelLAd >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(2);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();

  const PixelLAd * prSrc = iImage.GetPixel();
  const PixelLAd * prEnd = iImage.GetPixelEnd();
  double l,a;  
  uint32 idx;
  do 
  { 
    // clamp un-normalized float
    l = prSrc->_luminance;
    idx = uint32(511.0 * l + 0.5);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap0[idx]++;

    a = prSrc->_alpha;
    idx = uint32(511.0 * a + 0.5);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap1[idx]++;
  } 
  while (++prSrc != prEnd);

  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelLAd

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                             PixelRGB<T>
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

//----------------------------------------------------------------------------
//                             PixelRGBub
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelRGBub >::ComputeHistogram(
    const ImageImpl< PixelRGBub >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(4);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();
  uint32 * prMap2 = oHistogram.GetChannel(2).GetMap();
  uint32 * prMap3 = oHistogram.GetChannel(3).GetMap();

  const PixelRGBub * prSrc = iImage.GetPixel();
  const PixelRGBub * prEnd = iImage.GetPixelEnd();
  uint32 r,g,b,idx;
  do 
  { 
    r = (uint32)(prSrc->_red);
    g = (uint32)(prSrc->_green);
    b = (uint32)(prSrc->_blue);
    idx = (r*2989UL + g*5866UL + b*1145UL)/5000UL; 
    if (idx>=HistogramSamples) idx = HistogramSamples-1;
    prMap0[idx]++;
    prMap1[r]++;
    prMap2[g]++;
    prMap3[b]++;
  }
  while (++prSrc != prEnd);

  // map 256 into 512 values
  uint32 k = 255, j = 511;
  for (uint32 i=0; i<256; i++, j--, k--)
  {
    r = prMap1[k]; g = prMap2[k]; b = prMap3[k];
    prMap1[j] = r; prMap2[j] = g; prMap3[j] = b;
    j--;
    prMap1[j] = r; prMap2[j] = g; prMap3[j] = b;
  }

  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelRGBub

//----------------------------------------------------------------------------
//                             PixelRGBus
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelRGBus >::ComputeHistogram(
    const ImageImpl< PixelRGBus >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(4);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();
  uint32 * prMap2 = oHistogram.GetChannel(2).GetMap();
  uint32 * prMap3 = oHistogram.GetChannel(3).GetMap();

  const PixelRGBus * prSrc = iImage.GetPixel();
  const PixelRGBus * prEnd = iImage.GetPixelEnd();
  uint32 r,g,b,idx;
  do 
  { 
    r = (uint32)(prSrc->_red);
    g = (uint32)(prSrc->_green);
    b = (uint32)(prSrc->_blue);
    idx = (r*2989UL + g*5866UL + b*1145UL)/10000UL; 
    if (idx>=HistogramSamples) idx = HistogramSamples-1;
    prMap0[idx>>7]++;
    prMap1[r>>7]++;
    prMap2[g>>7]++;
    prMap3[b>>7]++;
  }
  while (++prSrc != prEnd);

  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelRGBus

//----------------------------------------------------------------------------
//                             PixelRGBf
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelRGBf >::ComputeHistogram(
    const ImageImpl< PixelRGBf >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(4);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();
  uint32 * prMap2 = oHistogram.GetChannel(2).GetMap();
  uint32 * prMap3 = oHistogram.GetChannel(3).GetMap();

  const PixelRGBf * prSrc = iImage.GetPixel();
  const PixelRGBf * prEnd = iImage.GetPixelEnd();
  float r,g,b,l;  
  uint32 idx;
  do 
  { 
    // clamp un-normalized float
    r = prSrc->_red;
    idx = uint32(511.f * r + 0.5f);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap1[idx]++;

    g = prSrc->_green;
    idx = uint32(511.f * g + 0.5f);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap2[idx]++;

    b = prSrc->_blue;
    idx = uint32(511.f * b + 0.5f);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap3[idx]++;

    l = r*0.2989f + g*0.5866f + b*0.1145f;  // range 0.f, 1.f
    idx = uint32(511.f * l + 0.5f);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap0[idx]++;
  } 
  while (++prSrc != prEnd);
  
  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelRGBf

//----------------------------------------------------------------------------
//                             PixelRGBd
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelRGBd >::ComputeHistogram(
    const ImageImpl< PixelRGBd >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(4);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();
  uint32 * prMap2 = oHistogram.GetChannel(2).GetMap();
  uint32 * prMap3 = oHistogram.GetChannel(3).GetMap();

  const PixelRGBd * prSrc = iImage.GetPixel();
  const PixelRGBd * prEnd = iImage.GetPixelEnd();
  double r,g,b,l;  
  uint32 idx;
  do 
  { 
    // clamp un-normalized float
    r = prSrc->_red;
    idx = uint32(511.0 * r + 0.5);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap1[idx]++;

    g = prSrc->_green;
    idx = uint32(511.0 * g + 0.5);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap2[idx]++;

    b = prSrc->_blue;
    idx = uint32(511.0 * b + 0.5);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap3[idx]++;

    l = r*0.2989 + g*0.5866 + b*0.1145;  // range 0.0, 1.0
    idx = uint32(511.0 * l + 0.5);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap0[idx]++;
  } 
  while (++prSrc != prEnd);
  
  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelRGBd

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                             PixelRGBA<T>
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

//----------------------------------------------------------------------------
//                             PixelRGBAub
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelRGBAub >::ComputeHistogram(
    const ImageImpl< PixelRGBAub >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(5);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();
  uint32 * prMap2 = oHistogram.GetChannel(2).GetMap();
  uint32 * prMap3 = oHistogram.GetChannel(3).GetMap();
  uint32 * prMap4 = oHistogram.GetChannel(4).GetMap();

  const PixelRGBAub * prSrc = iImage.GetPixel();
  const PixelRGBAub * prEnd = iImage.GetPixelEnd();
  uint32 r,g,b,a,idx;
  do 
  { 
    r = (uint32)(prSrc->_red);
    g = (uint32)(prSrc->_green);
    b = (uint32)(prSrc->_blue);
    a = (uint32)(prSrc->_alpha);
    idx = (r*2989UL + g*5866UL + b*1145UL)/5000UL; 
    if (idx>=HistogramSamples) idx = HistogramSamples-1;
    prMap0[idx]++;
    prMap1[r]++;
    prMap2[g]++;
    prMap3[b]++;
    prMap4[a]++;
  }
  while (++prSrc != prEnd);

  // map 256 into 512 values
  uint32 k = 255, j = 511;
  for (uint32 i=0; i<256; i++, j--, k--)
  {
    r = prMap1[k]; g = prMap2[k]; b = prMap3[k]; a = prMap4[k];
    prMap1[j] = r; prMap2[j] = g; prMap3[j] = b; prMap4[j] = a;
    j--;
    prMap1[j] = r; prMap2[j] = g; prMap3[j] = b; prMap4[j] = a;
  }

  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelRGBAub

//----------------------------------------------------------------------------
//                             PixelRGABus
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelRGBAus >::ComputeHistogram(
    const ImageImpl< PixelRGBAus >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(5);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();
  uint32 * prMap2 = oHistogram.GetChannel(2).GetMap();
  uint32 * prMap3 = oHistogram.GetChannel(3).GetMap();
  uint32 * prMap4 = oHistogram.GetChannel(4).GetMap();

  const PixelRGBAus * prSrc = iImage.GetPixel();
  const PixelRGBAus * prEnd = iImage.GetPixelEnd();
  uint32 r,g,b,a,idx;
  do 
  { 
    r = (uint32)(prSrc->_red);
    g = (uint32)(prSrc->_green);
    b = (uint32)(prSrc->_blue);
    a = (uint32)(prSrc->_alpha);
    idx = (r*2989UL + g*5866UL + b*1145UL)/10000UL; 
    if (idx>=HistogramSamples) idx = HistogramSamples-1;
    prMap0[idx>>7]++;
    prMap1[r>>7]++;
    prMap2[g>>7]++;
    prMap3[b>>7]++;
    prMap4[a>>7]++;
  }
  while (++prSrc != prEnd);

  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelRGBAus

//----------------------------------------------------------------------------
//                             PixelRGBAf
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelRGBAf >::ComputeHistogram(
    const ImageImpl< PixelRGBAf >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(5);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();
  uint32 * prMap2 = oHistogram.GetChannel(2).GetMap();
  uint32 * prMap3 = oHistogram.GetChannel(3).GetMap();
  uint32 * prMap4 = oHistogram.GetChannel(4).GetMap();

  const PixelRGBAf * prSrc = iImage.GetPixel();
  const PixelRGBAf * prEnd = iImage.GetPixelEnd();
  float r,g,b,a,l;  
  uint32 idx;
  do 
  { 
    // clamp un-normalized float
    r = prSrc->_red;
    idx = uint32(511.f * r + 0.5f);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap1[idx]++;

    g = prSrc->_green;
    idx = uint32(511.f * g + 0.5f);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap2[idx]++;

    b = prSrc->_blue;
    idx = uint32(511.f * b + 0.5f);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap3[idx]++;

    a = prSrc->_alpha;
    idx = uint32(511.f * a + 0.5f);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap4[idx]++;

    l = r*0.2989f + g*0.5866f + b*0.1145f;  // range 0.f, 1.f
    idx = uint32(511.f * l + 0.5f);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap0[idx]++;
  } 
  while (++prSrc != prEnd);
  
  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelRGBAf

//----------------------------------------------------------------------------
//                             PixelRGBAd
//----------------------------------------------------------------------------
template <>
bool ImageAnalyseImpl< PixelRGBAd >::ComputeHistogram(
    const ImageImpl< PixelRGBAd >& iImage, 
    ImageHistogram& oHistogram)
{
  if (!iImage.IsValid()) return false;

  oHistogram.Reset(4);
  uint32 * prMap0 = oHistogram.GetChannel(0).GetMap();
  uint32 * prMap1 = oHistogram.GetChannel(1).GetMap();
  uint32 * prMap2 = oHistogram.GetChannel(2).GetMap();
  uint32 * prMap3 = oHistogram.GetChannel(3).GetMap();
  uint32 * prMap4 = oHistogram.GetChannel(4).GetMap();

  const PixelRGBAd * prSrc = iImage.GetPixel();
  const PixelRGBAd * prEnd = iImage.GetPixelEnd();
  double r,g,b,a,l;  
  uint32 idx;
  do 
  { 
    // clamp un-normalized float
    r = prSrc->_red;
    idx = uint32(511.0 * r + 0.5);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap1[idx]++;

    g = prSrc->_green;
    idx = uint32(511.0 * g + 0.5);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap2[idx]++;

    b = prSrc->_blue;
    idx = uint32(511.0 * b + 0.5);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap3[idx]++;

    a = prSrc->_alpha;
    idx = uint32(511.0 * a + 0.5);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap4[idx]++;

    l = r*0.2989 + g*0.5866 + b*0.1145;  // range 0.0, 1.0
    idx = uint32(511.0 * l + 0.5);
    if      (idx < 0)   idx = 0;
    else if (idx > 511) idx = 511;
    prMap0[idx]++;
  } 
  while (++prSrc != prEnd);
  
  oHistogram.UpdateMinMax();
  return true;

} // ComputeHistogram # PixelRGBAd


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageAnalyseProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeHistogram(
    const AbstractImage& iImage, 
    ImageHistogram& oHistogram) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeHistogram(image, oHistogram);

} // ComputeHistogram

} // namespace Image
} // namespace eLynx

#endif // __Analyse_Histogram_hpp__
