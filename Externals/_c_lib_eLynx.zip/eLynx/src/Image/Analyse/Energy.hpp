//============================================================================
//  Analyse/Energy.hpp                                 Image.Component package
//============================================================================
//  Usage : image analyse interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Analyse_Energy_hpp__
#define __Analyse_Energy_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ComputeEnergy for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeEnergy(const ImageImpl<Pixel>& iImage,
    double& oEnergy)
{
  if (!iImage.IsValid())
    return false;

  typedef typename Pixel::type T;
  const T * prSrc = iImage.GetSamples();
  const T * prEnd = iImage.GetSamplesEnd();
  
  double v, sum = 0.0;
  do
  {
    v = double(*prSrc);
    sum += v*v;
  }
  while (++prSrc != prEnd);

  const uint32 size = iImage.GetSampleCount();
  oEnergy = sum / size;

  return true;

} // ComputeEnergy


//----------------------------------------------------------------------------
//  ComputeEnergy for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeEnergy(
    const ImageImpl<Pixel>& iImage,
    double(&oEnergy)[PC_MAX])
{
  if (!iImage.IsValid())
    return false;

  const uint32 nChannel = Pixel::GetChannelCount();
  const Pixel * prSrc = iImage.GetPixel();
  const Pixel * prEnd = iImage.GetPixelEnd();
  
  double v;
  double sum[PC_MAX];
  uint32 c;
  for (c=0; c<nChannel; c++) sum[c] = 0.0;
  
  do
  {
    for (c=0; c<nChannel; c++)
    {
      v = double(prSrc[0]._channel[c]);
      sum[c] += v*v;
    }
  }
  while (++prSrc != prEnd);

  const uint32 size = iImage.GetPixelCount();
  for (c=0; c<nChannel; c++)
    oEnergy[c] = sum[c] / size;

  return true;

} // ComputeEnergy

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageAnalyseProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ComputeEnergy for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeEnergy(
    const AbstractImage& iImage, 
    double& oEnergy) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeEnergy(image, oEnergy);

} // ComputeEnergy


//----------------------------------------------------------------------------
//  ComputeEnergy for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeEnergy(
    const AbstractImage& iImage, 
    double (&oEnergy)[PC_MAX]) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeEnergy(image, oEnergy);

} // ComputeEnergy

} // namespace Image
} // namespace eLynx

#endif // __Analyse_Energy_hpp__
