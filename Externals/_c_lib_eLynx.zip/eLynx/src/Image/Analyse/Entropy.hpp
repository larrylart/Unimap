//============================================================================
//  Analyse/Entropy.hpp                                Image.Component package
//============================================================================
//  Usage : image analyse interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Analyse_Entropy_hpp__
#define __Analyse_Entropy_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ComputeEntropy for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeEntropy(
    const ImageImpl<Pixel>& iImage,
    double& oEntropy)
{
  if (!iImage.IsValid())
    return false;
    
  oEntropy = -1.0;
  return false;

} // ComputeEntropy


//----------------------------------------------------------------------------
//  ComputeEntropy for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeEntropy(
    const ImageImpl<Pixel>& iImage,
    double(&oEntropy)[PC_MAX])
{
  if (!iImage.IsValid())
    return false;

  typedef typename Pixel::F_type F;
  
  const uint32 nChannel = Pixel::GetChannelCount();
  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const F OneOverLog2 = F(1.f) / Math::elxLog(F(2.f));
  const F OneOverwSize = F(1)/F(w*h);
  
  ImageHistogram histogram;
  if (!ImageAnalyseImpl<Pixel>::ComputeHistogram(iImage, histogram))
    return false;
  uint32* histMap; 

  F prob;
  uint32 c, i;
  for (c=0; c<nChannel; c++)
  {
    histMap = histogram.GetChannel(c).GetMap();
    oEntropy[c] = 0.f;
    for (i = 0; i < HistogramSamples; ++i)
    {
      if (histMap[i] == 0)
        continue;
      prob = OneOverwSize * histMap[i];
      oEntropy[c] -= OneOverLog2 * prob * Math::elxLog(prob);
    }        
  }
  return true;

} // ComputeEntropy


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageAnalyseProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ComputeEntropy for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeEntropy(
    const AbstractImage& iImage, 
    double& oEntropy) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeEntropy(image, oEntropy);

} // ComputeEntropy

//----------------------------------------------------------------------------
//  ComputeEntropy for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeEntropy(
    const AbstractImage& iImage, 
    double(&oEntropy)[PC_MAX]) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeEntropy(image, oEntropy);

} // ComputeEntropy

} // namespace Image
} // namespace eLynx

#endif //__Analyse_Entropy_hpp__
