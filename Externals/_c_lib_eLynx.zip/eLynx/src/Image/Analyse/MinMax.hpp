//============================================================================
//  Analyse/MinMax.hpp                                 Image.Component package
//============================================================================
//  Usage : image analyse interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Analyse_MinMax_hpp__
#define __Analyse_MinMax_hpp__

#include <elx/math/MathCore.h>
#include <elx/core/ParallelAlgorithms.h>

namespace eLynx {
namespace Image {

namespace {

template <typename Pixel>
struct ComputeMinMaxLuminanceTask
{
  typedef typename Pixel::type T;
  
  // initial constructor
  ComputeMinMaxLuminanceTask(const Pixel * iprSrc) :
    _prSrc(iprSrc), 
    _begin(0), 
    _end(0),
    _minLuminance(), 
    _maxLuminance() 
  {}
  
  // split constructor
  ComputeMinMaxLuminanceTask(
      const ComputeMinMaxLuminanceTask& iOther, 
      const IterationRange& iRange) :
    _prSrc(iOther._prSrc),
    _begin( uint32(iRange.GetBegin()) ), 
    _end( uint32(iRange.GetEnd()) ),
    _minLuminance(), 
    _maxLuminance() 
  {}
  
  uint32 operator ()()
  {
    const Pixel * prSrc = _prSrc + _begin;
    const Pixel * prEnd = _prSrc + _end;
    T minLuminance = ResolutionTypeTraits<T>::_max;
    T maxLuminance = ResolutionTypeTraits<T>::_min;
    
    do
    {
      T l= prSrc->GetLuminance();
      if (l< minLuminance) minLuminance = l;
      if (l> maxLuminance) maxLuminance = l;
    }
     while (++prSrc != prEnd);

    _minLuminance = minLuminance;
    _maxLuminance = maxLuminance;

    return elxOK;
  }
  
  // Compute global min/max.
  void Join(const ComputeMinMaxLuminanceTask& iOther)
  {
    if (_begin != iOther._begin)
    {
      if (iOther._minLuminance < _minLuminance) _minLuminance = iOther._minLuminance;
      if (iOther._maxLuminance > _maxLuminance) _maxLuminance = iOther._maxLuminance;
      _end = iOther._end;
    }
    else
      // This is the first range to merge.
      _minLuminance = iOther._minLuminance;
      _maxLuminance = iOther._maxLuminance;
      _end = iOther._end;
  }

private:  
  const Pixel * _prSrc;  // Source Image
  uint32 _begin, _end;     // Range to iterate

public:
  T _minLuminance, _maxLuminance;  // Pixel Min/Max luminance

}; // ComputeMinMaxLuminanceTask

} // namespace

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ComputeMin for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMin(
    const ImageImpl<Pixel>& iImage,
    T& oMin)
{
  if (!iImage.IsValid()) return false;
  return Math::elxMin(iImage.GetSamples(), iImage.GetSampleCount(), oMin);

} // ComputeMin

//----------------------------------------------------------------------------
//  ComputeMin for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMin(
    const ImageImpl<Pixel>& iImage,
    double& oMin, 
    bool ibNormalized)
{
  T m;
  bool bSuccess = ComputeMin(iImage, m);
  if (!bSuccess) return false;

  oMin = ibNormalized ? elxToDoubleNormalized(m) : double(m);
  return true;

} // ComputeMin

//----------------------------------------------------------------------------
//  ComputeMin :
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMin(
    const ImageImpl<Pixel>& iImage,
    double (&oMin)[PC_MAX], 
    bool ibNormalized)
{
  if (!iImage.IsValid()) return false;
  const uint32 nChannel = Pixel::GetChannelCount();
  T m[PC_MAX];
  Math::elxMin(iImage.GetSamples(), iImage.GetSampleCount(), nChannel, m);

  if (ibNormalized)
    elxToDoubleNormalized(m, nChannel, oMin);
  else
    for (uint32 c=0; c<nChannel; ++c)
      oMin[c] = double(m[c]);

  return true;

} // ComputeMin

//----------------------------------------------------------------------------
//  ComputeMinLuminance for all pixels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMinLuminance(
    const ImageImpl<Pixel>& iImage,
    double& oMinLuminance, 
    bool ibNormalized)
{
  if (!iImage.IsValid()) return false;
  
  const IterationRange range(0, iImage.GetPixelCount());
  ComputeMinMaxLuminanceTask<Pixel> task(iImage.GetPixel());
  if (elxOK != elxParallelReduce(range, task))
    return false;

  oMinLuminance = ibNormalized ? 
    elxToDoubleNormalized(task._minLuminance) :
    double(task._minLuminance);

  return true;

} // ComputeMinLuminance

//----------------------------------------------------------------------------
//  ComputeMax :
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMax(
    const ImageImpl<Pixel>& iImage,
    T& oMax)
{
  if (!iImage.IsValid()) return false;
  return Math::elxMax(iImage.GetSamples(), iImage.GetSampleCount(), oMax);

} // ComputeMax

//----------------------------------------------------------------------------
//  ComputeMax :
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMax(
    const ImageImpl<Pixel>& iImage,
    double& oMax, 
    bool ibNormalized)
{
  T M;
  bool bSuccess = ComputeMax(iImage, M);
  if (!bSuccess)
    return false;

  oMax = ibNormalized ? elxToDoubleNormalized(M) : double(M);
  return true;

} // ComputeMax

//----------------------------------------------------------------------------
//  ComputeMax :
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMax(
    const ImageImpl<Pixel>& iImage,
    double (&oMax)[PC_MAX], 
    bool ibNormalized)
{
  if (!iImage.IsValid()) return false;
  const uint32 nChannel = Pixel::GetChannelCount();
  T m[PC_MAX];
  Math::elxMax(iImage.GetSamples(), iImage.GetSampleCount(), nChannel, m);

  if (ibNormalized)
    elxToDoubleNormalized(m, nChannel, oMax);
  else
    for (uint32 c=0; c<nChannel; ++c)
      oMax[c] = double(m[c]);

  return true;

} // ComputeMax

//----------------------------------------------------------------------------
//  ComputeMaxLuminance for all pixels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMaxLuminance(
    const ImageImpl<Pixel>& iImage,
    double& oMaxLuminance, 
    bool ibNormalized)
{
  if (!iImage.IsValid()) return false;
  
  const IterationRange range(0, iImage.GetPixelCount());
  ComputeMinMaxLuminanceTask<Pixel> task(iImage.GetPixel());

  if (elxOK != elxParallelReduce(range, task))
    return false;

  oMaxLuminance = ibNormalized ? 
    elxToDoubleNormalized(task._maxLuminance) : 
    double(task._maxLuminance);

  return true;

} // ComputeMaxLuminance

//----------------------------------------------------------------------------
//  ComputeMinMax :
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMinMax(
    const ImageImpl<Pixel>& iImage,
    T& oMin, T& oMax)
{
  if (!iImage.IsValid()) return false;
  return Math::elxMinMax(iImage.GetSamples(), iImage.GetSampleCount(), oMin, oMax);

} // ComputeMinMax

//----------------------------------------------------------------------------
//  ComputeMinMax :
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMinMax(
    const ImageImpl<Pixel>& iImage,
    double& oMin, double& oMax, bool ibNormalized)
{
  T m,M;
  bool bSuccess = ComputeMinMax(iImage, m,M);
  if (!bSuccess)
    return false;

  oMin = ibNormalized ? elxToDoubleNormalized(m) : double(m);
  oMax = ibNormalized ? elxToDoubleNormalized(M) : double(M);
  return true;

} // ComputeMinMax

//----------------------------------------------------------------------------
//  ComputeMinMax :
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMinMax(
    const ImageImpl<Pixel>& iImage,
    double (&oMin)[PC_MAX], 
    double (&oMax)[PC_MAX], 
    bool ibNormalized)
{
  if (!iImage.IsValid()) return false;
  const uint32 nChannel = Pixel::GetChannelCount();
  T m[PC_MAX],M[PC_MAX];
  
  Math::elxMinMax(iImage.GetSamples(), iImage.GetSampleCount(), nChannel, m, M);
  
  if (ibNormalized)
  {
    elxToDoubleNormalized(m, nChannel, oMin);
    elxToDoubleNormalized(M, nChannel, oMax);
  }
  else for (uint32 c=0; c<nChannel; ++c)
  {
    oMin[c] = double(m[c]);
    oMax[c] = double(M[c]);
  }

  return true;

} // ComputeMinMax

//----------------------------------------------------------------------------
//  ComputeMinMaxLuminance for all pixels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMinMaxLuminance(
    const ImageImpl<Pixel>& iImage,
    double& oMinLuminance, 
    double& oMaxLuminance, 
    bool ibNormalized)
{
  if (!iImage.IsValid()) return false;
  
  const IterationRange range(0, iImage.GetPixelCount());
  ComputeMinMaxLuminanceTask<Pixel> task(iImage.GetPixel());

  if (elxOK != elxParallelReduce(range, task))
    return false;

  if (ibNormalized)
  {
    oMinLuminance = elxToDoubleNormalized(task._minLuminance);
    oMaxLuminance = elxToDoubleNormalized(task._maxLuminance);
  }
  else
  {
    oMinLuminance = double(task._minLuminance);;
    oMaxLuminance = double(task._maxLuminance);
  }
  return true;

} // ComputeMinMaxLuminance

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageAnalyseProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMin(
    const AbstractImage& iImage, 
    double& oMin, 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMin(image, oMin, ibNormalized);

} // ComputeMin

//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMin(
    const AbstractImage& iImage, 
    double (&oMin)[PC_MAX], 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMin(image, oMin, ibNormalized);

} // ComputeMin

//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMinLuminance(
    const AbstractImage& iImage, 
    double& oMinLuminance, 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMinLuminance(image, oMinLuminance, ibNormalized);

} // ComputeMinLuminance

//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMax(
    const AbstractImage& iImage, 
    double& oMax, 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMax(image, oMax, ibNormalized);

} // ComputeMax

//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMax(
    const AbstractImage& iImage, 
    double (&oMax)[PC_MAX], 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMax(image, oMax, ibNormalized);

} // ComputeMax

//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMaxLuminance(
    const AbstractImage& iImage, 
    double& oMaxLuminance, 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMaxLuminance(image, oMaxLuminance, ibNormalized);

} // ComputeMaxLuminance

//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMinMax(
    const AbstractImage& iImage, 
    double& oMin, 
    double& oMax, 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMinMax(image, oMin, oMax, ibNormalized);

} // ComputeMinMax

//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMinMax(
    const AbstractImage& iImage, 
    double (&oMin)[PC_MAX], 
    double (&oMax)[PC_MAX], 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMinMax(image, oMin, oMax, ibNormalized);

} // ComputeMinMax

//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMinMaxLuminance(
    const AbstractImage& iImage, 
    double& oMinLuminance, 
    double& oMaxLuminance, 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMinMaxLuminance(image, oMinLuminance, oMaxLuminance, ibNormalized);

} // ComputeMinMaxLuminance


} // namespace Image
} // namespace eLynx

#endif //__Analyse_MinMax_hpp__
