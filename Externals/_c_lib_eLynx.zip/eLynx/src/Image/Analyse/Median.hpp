//============================================================================
//  Analyse/Median.hpp                                 Image.Component package
//============================================================================
//  Usage : image analyse interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Analyse_Median_hpp__
#define __Analyse_Median_hpp__

#include <boost/scoped_array.hpp>

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreSort.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template<typename T>
int32 sortCompare(const T * v1, const T * v2) 
{
   if     (*v1 > *v2) return (1);
   else if(*v1 < *v2) return (-1);
   return (0);
}


template <typename T>
struct ParallelMedianChannelTask
{
  // initial constructor
  ParallelMedianChannelTask(
    const T * iprSrc, uint32 iTotalCount, uint32 inChannel, T * iprBuffer) :
    _prSrc(iprSrc), _prBuffer(iprBuffer), _totalCount(iTotalCount), 
    _nChannel(inChannel), _begin(0), _end(0)
  {}
  
  // split constructor
  ParallelMedianChannelTask(
      const ParallelMedianChannelTask& iOther, 
      const IterationRange& iRange) :
    _prSrc(iOther._prSrc + iRange.GetBegin()), 
    _prBuffer(iOther._prBuffer), _totalCount(iOther._totalCount), 
    _nChannel(iOther._nChannel), 
    _begin( uint32(iRange.GetBegin()/_nChannel) ), 
    _end( uint32(iRange.GetEnd()/_nChannel) )
  {}
  
  uint32 operator ()()
  {
    const T * prSrc = _prSrc;
    const uint32 nChannel = _nChannel;
    const uint32 rangeCount = uint32(_end - _begin);
    const uint32 nTotalCount = _totalCount/nChannel;
    const uint32 begin = _begin;
    T * prBuffer = _prBuffer;
    
    // copy image in buffer
    for (uint32 i=0; i<nTotalCount; ++i)
      for (uint32 c=0; c<nChannel; ++c, ++prSrc)
        prBuffer[c*nTotalCount + begin + i] = *prSrc;
        
    // sort with quick sort
    int32 (*cmp)(const T*, const T*) = (int32 (*)(const T*, const T*))sortCompare;
    for (uint32 c=0; c<nChannel; ++c)
      ::qsort(prBuffer + c*nTotalCount + begin, rangeCount, sizeof(T), 
        (int32 (*)(const void*, const void*))cmp);
    
    return elxOK;
  }
  
  // Merge sorted ranges into the original one.
  void Join(const ParallelMedianChannelTask& iOther)
  {
    if (_begin != iOther._begin)
    {
      // make sure that we are merging in the same order ranges were created.
      BOOST_ASSERT(_end == iOther._begin);
      const uint32 nTotalCount = _totalCount/_nChannel;
      for (uint32 c=0; c<_nChannel; ++c)
      {
        T * prBuffer = _prBuffer + c*nTotalCount;
        std::inplace_merge(
          prBuffer + _begin, prBuffer + _end, prBuffer + iOther._end);
      }
      _end = iOther._end;
    }
    else
      // This is the first range to merge. Don't need to actually merge them
      _end = iOther._end;
  }

private:  
  const T * _prSrc;     // Pointer to the source
  T * _prBuffer;        // Pointer to the whole buffer to sort
  uint32 _totalCount;   // Total count of the elements to sort
  uint32 _nChannel;     // Number of channels
  uint32 _begin, _end;  // Range to sort
};

} // anonymous-namespace

//----------------------------------------------------------------------------
//  ComputeMedian for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMedian(
    const ImageImpl<Pixel>& iImage,
    double& oMedian, 
    bool ibNormalized)
{
  if (!iImage.IsValid())
    return false;

  typedef typename Pixel::type T;
  const T * prSrc = iImage.GetSamples();
  const uint32 count = iImage.GetSampleCount();

  // create temp buffer for sort
  boost::scoped_array<T> splBuffer(new T [count]);
  if (NULL == splBuffer.get())
    return false;

  // copy image in buffer
  ::memcpy(splBuffer.get(), prSrc, count*sizeof(T));

  // Run qsort in parallel if possible
  int32 (*cmp)(const T*, const T*) = (int32 (*)(const T*, const T*))sortCompare;
  elxQuickSort(splBuffer.get(), count, cmp);
  
  T median;
  uint32 half = count/2;
  if (count % 2)
  {
    // odd number of samples
    median = splBuffer[half];
  }
  else
  {
    // even number of samples
    median = (splBuffer[half-1] + splBuffer[half])/2;
  }
   
  if (ibNormalized)
    oMedian = elxToDoubleNormalized(median);
  else
    oMedian = double(median);

  return true;

} // ComputeMedian


//----------------------------------------------------------------------------
//  ComputeMedian for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMedian(
    const ImageImpl<Pixel>& iImage,
    double (&oMedian)[PC_MAX], 
    bool ibNormalized)
{
  if (!iImage.IsValid())
    return false;

  typedef typename Pixel::type T;
  const T * prSrc = iImage.GetSamples();
  const uint32 nChannel = Pixel::GetChannelCount();
  const uint32 count = iImage.GetSampleCount();
  const uint32 pcount = count/nChannel;

  // create temp buffer for sort
  boost::scoped_array<T> spBuffer(new T [count]);
  if (NULL == spBuffer.get())
    return false;

  // Split the buffer and sort each part in a separate thread
  IterationRange range(0, count, nChannel);
  ParallelMedianChannelTask<T> task(prSrc, count, nChannel, spBuffer.get());
  if (elxOK != elxParallelReduce(range, task))
    return false;

  T median[PC_MAX];
  uint32 half = pcount/2;
  if (pcount % 2)
  {
    // odd number of samples
    for (uint32 c=0; c<nChannel; ++c)
      median[c] = spBuffer[c * pcount + half];
  }
  else
  {
    // even number of samples
    for (uint32 c=0; c<nChannel; ++c)
      median[c] = (spBuffer[c*pcount + half-1] + spBuffer[c*pcount + half])/2;
  }
   
  if (ibNormalized)
    elxToDoubleNormalized(median, nChannel, oMedian);
  else
    for (uint32 c=0; c<nChannel; ++c)
      oMedian[c] = double(median[c]);

  return true;

} // ComputeMedian

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageAnalyseProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ComputeMedian for all samples
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMedian(
    const AbstractImage& iImage, 
    double& oMedian, 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMedian(image, oMedian, ibNormalized);

} // ComputeMedian


//----------------------------------------------------------------------------
//  ComputeMedian for each channels
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageAnalyseImpl<Pixel>::ComputeMedian(
    const AbstractImage& iImage, 
    double (&oMedian)[PC_MAX], 
    bool ibNormalized) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return ComputeMedian(image, oMedian, ibNormalized);

} // ComputeMedian

} // namespace Image
} // namespace eLynx

#endif // __Analyse_Median_hpp__
