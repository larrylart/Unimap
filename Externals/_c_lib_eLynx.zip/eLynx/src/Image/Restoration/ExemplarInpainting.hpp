//============================================================================
//  Restoration/ExemplarInpainting.hpp                 Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Restoration_ExemplarInpainting_hpp__
#define __Restoration_ExemplarInpainting_hpp__

#include <set>
#include <iostream>

#include <boost/shared_ptr.hpp>

#include <elx/image/ImageRestorationImpl.h>
#include <elx/image/ImageGeometryImpl.h>
#include <elx/image/ImageCommon.h>
#include <elx/image/ImageConversion.h>

namespace eLynx {
namespace Image {

namespace {

//----------------------------------------------------------------------------
//                      elxIdentSkippedPixels
//optimization. 1. Keep track of the points which need to be skipped -
// patch centered at them would contain unknown pixels
//----------------------------------------------------------------------------
template <typename Pixel>
void elxIdentSkippedPixels(const ImageImpl<Pixel>& iImage, const uint8* iImageMask,
  uint32 iPatchSize, std::set<uint32>& oSkipPoints)
{
  const int32 w = (int32)iImage.GetWidth();
  const int32 h = (int32)iImage.GetHeight();
  const int32 half = iPatchSize /2;
  
  for (int32 i = half; i < h - half; ++i)
    for (int32 j = half; j < w - half; ++j)
    {
      bool good = true;
      // Iterate over the region of pathc size
      for (int32 y = -half; y < half+1 && good; ++y)
        for (int32 x = -half; x < half+1; ++x)
          if (!elxIPT_IS_ORIG_KNOWN(iImageMask[(i+y)*w + (j+x)]))
          {
            oSkipPoints.insert(i*w+j);
            // need to advance j
            good = false;
            break;
          }
    }
} //elxIdentSkippedPixels

//----------------------------------------------------------------------------
//                      elxFindBestMatch
// Finds the known image region which is most similar to the region to be filled
//----------------------------------------------------------------------------
template <typename Pixel>
Math::Point2i elxFindBestMatch(const Math::Point2i& iPoint,
  const ImageImpl<Pixel>& iImage, const uint8* iImageMask,
  const typename Pixel::type* iprImageLuminance,
  const ImageImpl<Pixel>& iRegion, const uint8* iRegionMask,
  uint32 iPatchSize, const std::set<uint32>& iSkipPoints)
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  const static M BIG = M(999999999);

  const int32 wi = (int32)iImage.GetWidth();
  const int32 hi = (int32)iImage.GetHeight();
  const int32 wr = (int32)iRegion.GetWidth();
  const int32 hr = (int32)iRegion.GetHeight();
  const int32 half = iPatchSize /2;
  const int32 ymin = (iPoint._y > half) ? -half : -iPoint._y;
  const int32 ymax = (iPoint._y + half < hr) ? half + 1 : hr - iPoint._y;
  const int32 xmin = (iPoint._x > half) ? -half : -iPoint._x ;
  const int32 xmax = (iPoint._x + half < wr) ? half + 1 : wr - iPoint._x;

  // optimization. 2. Pre-compute luminance for the region to be filled
  //               3. Pre-compute known pixels in the region to be filled
  std::vector<T> regionLuminance;
  regionLuminance.reserve(iPatchSize*iPatchSize);
  // point's coordinates are in region space
  std::vector<Math::Point2i> knownPoints;
  knownPoints.reserve(iPatchSize*iPatchSize);
  const Pixel* prRegionBegin = iRegion.GetPixel();
  for (int32 y = ymin; y < ymax; ++y)
    for (int32 x = xmin; x < xmax; ++x)
    {
      if (elxIPT_IS_KNOWN(iRegionMask[(iPoint._y+y)*wr + (iPoint._x+x)]))
      {
        regionLuminance.push_back(
		      (prRegionBegin + (iPoint._y+y)*wr+ iPoint._x+x)->GetLuminance());
        knownPoints.push_back(Math::Point2i(x, y));
      }
    }

  M minDistance = BIG;
  // center's coordinates are in image space
  Math::Point2i center;
  // number of known pixels in the region to be filled
  const size_t size = knownPoints.size();
   
  // Iterate over the known region
  for (int32 i = half; i < hi - half; ++i)
    for (int32 j = half; j < wi - half; ++j)
    {
      std::set<uint32>::const_iterator it = iSkipPoints.find(i*wi+j);
      if (it != iSkipPoints.end())
        continue;
      M distance = M();
      // Iterate over known pixels in the region to be filled
      for (size_t k = 0; k < size; ++k)
      {
        const int32 x = knownPoints[k]._x + j;
        const int32 y = knownPoints[k]._y + i;
        distance += Math::elxSqr(
          iprImageLuminance[y*wi+x] - regionLuminance[k]); 
      }

      if (distance < minDistance)
      {
        minDistance = distance;
        center._x = j;
        center._y = i;
      }
      else
        // speed-up iteration
        ++j;
    }

  BOOST_ASSERT(minDistance < BIG);

  return Math::Point2i(center);

} // elxFindBestMatch

//----------------------------------------------------------------------------
//                      elxPropagateTexture
// Propagates texture from the patch centerd at iPatchCenter to the iPoint
// Updates confidence
//----------------------------------------------------------------------------
template <typename Pixel>
void elxPropagateTexture(const Math::Point2i& iPoint, const Math::Point2i& iPatchCenter,
  const ImageImpl<Pixel>& iImage, uint32 iPatchSize,
  ImageImpl<Pixel>& ioRegion, uint8* ioRegionMask,
  std::vector<typename ResolutionTypeTraits<typename Pixel::type>::Floating_type>& ioConfidenceMap,
  std::deque<Math::Point2i>& ioNarrowBand)
{
  const int32 w = (int32)ioRegion.GetWidth();
  const int32 h = (int32) ioRegion.GetHeight();
  const int32 half = iPatchSize /2;
  const int32 ymin = (iPoint._y > half) ? -half : -iPoint._y;
  const int32 ymax = (iPoint._y + half < h) ? half + 1 : h - iPoint._y;
  const int32 xmin = (iPoint._x > half) ? -half : -iPoint._x;
  const int32 xmax = (iPoint._x + half < w) ? half + 1 : w - iPoint._x;

  const int32 pidx = iPoint._y*w +iPoint._x;

  for (int32 y = ymin; y < ymax; ++y)
    for (int32 x = xmin; x < xmax; ++x)
    {
      uint32 idx = (iPoint._y+y)*w +iPoint._x+x;
      if (elxIPT_IS_UNKNOWN(ioRegionMask[idx]))
      {
        *ioRegion.GetPixel(iPoint._x+x, iPoint._y+y) =
          *iImage.GetPixel(iPatchCenter._x+x, iPatchCenter._y+y);
        elxIPT_SET_INPAINTED(ioRegionMask[idx]);
        ioConfidenceMap[idx] = ioConfidenceMap[pidx];
      }
      if (elxIPT_IS_BOUNDARY(ioRegionMask[idx]))
      {
        // Erase part of the boundary which is inside of the patch
        elxIPT_UNSET_BOUNDARY(ioRegionMask[idx]);
        //performance - linear search
        std::deque<Math::Point2i>::iterator iter =
            std::find(ioNarrowBand.begin(), ioNarrowBand.end(),
              Math::Point2i(iPoint._x+x, iPoint._y+y));
        if (iter != ioNarrowBand.end())
          ioNarrowBand.erase(iter);
      }
    }
} // elxPropagateTexture

//----------------------------------------------------------------------------
//                      elxAdvanceBoundary
// Iterates over the patch boundary and pushes the front to the neighboring points
//----------------------------------------------------------------------------
template <typename Pixel>
void elxAdvanceBoundary(const Math::Point2i& iPoint,
  const ImageImpl<Pixel>& iRegion,
  uint32 iPatchSize, uint8* ioRegionMask,
  std::vector<typename ResolutionTypeTraits<typename Pixel::type>::Floating_type>& ioConfidenceMap,
  std::vector<typename ResolutionTypeTraits<typename Pixel::type>::Floating_type>& ioPriorityMap,
  std::deque<Math::Point2i>& ioNarrowBand)
{
  typedef typename Pixel::type T;
  typedef typename Pixel::FloatingPixel PixelF;
  typedef typename PixelF::type F;

  static std::vector<Math::Point2i> newBoundary;
  newBoundary.reserve(4*iPatchSize);
  newBoundary.clear();

  const int32 w = (int32)iRegion.GetWidth();
  const int32 h = (int32) iRegion.GetHeight();
  const int32 half = iPatchSize/2;
  const int32 ymin = Math::elxMax(iPoint._y - half, 0);
  const int32 ymax = Math::elxMin(iPoint._y + half + 1, h);
  const int32 xmin = Math::elxMax(iPoint._x - half, 0);
  const int32 xmax = Math::elxMin(iPoint._x + half + 1, w);

  // top
  if (iPoint._y - half > 0)
    for (int32 x = xmin; x < xmax; ++x)
    {
      BOOST_ASSERT(elxIPT_IS_KNOWN(ioRegionMask[ymin*w+x]));
      if (elxIPT_IS_UNKNOWN(ioRegionMask[(ymin-1)*w+x]))
      {
        elxIPT_SET_BOUNDARY(ioRegionMask[ymin*w+x]);
        newBoundary.push_back(Math::Point2i(x, ymin));
      }
    }
  // bottom
  if (iPoint._y + half < h-1)
    for (int32 x = xmin; x < xmax; ++x)
    {
      BOOST_ASSERT(elxIPT_IS_KNOWN(ioRegionMask[(ymax-1)*w+x]));
      if (elxIPT_IS_UNKNOWN(ioRegionMask[ymax*w+x]))
      {
        elxIPT_SET_BOUNDARY(ioRegionMask[(ymax-1)*w+x]);
        newBoundary.push_back(Math::Point2i(x, ymax-1));
      }
    }
  // left
  if (iPoint._x - half > 0)
    for (int32 y = ymin; y < ymax; ++y)
    {
      BOOST_ASSERT(elxIPT_IS_KNOWN(ioRegionMask[y*w+xmin]));
      if (elxIPT_IS_UNKNOWN(ioRegionMask[y*w+xmin-1]))
      {
        elxIPT_SET_BOUNDARY(ioRegionMask[y*w+xmin]);
        newBoundary.push_back(Math::Point2i(xmin, y));
      }
    }
  // right
  if (iPoint._x + half < w-1)
    for (int32 y = ymin; y < ymax; ++y)
    {
      BOOST_ASSERT(elxIPT_IS_KNOWN(ioRegionMask[y*w+(xmax-1)]));
      if (elxIPT_IS_UNKNOWN(ioRegionMask[y*w+xmax]))
      {
        elxIPT_SET_BOUNDARY(ioRegionMask[y*w+(xmax-1)]);
        newBoundary.push_back(Math::Point2i(xmax-1, y));
      }
    }

  size_t size = newBoundary.size();
  for (size_t i = 0; i < size; ++i)
  {
    const Math::Point2i& point = newBoundary[i];
    elxCalculatePatchPriority(
      point, iPatchSize, iRegion, ioRegionMask, ioConfidenceMap, ioPriorityMap);
    ioNarrowBand.push_back(point);
  }

  //  Sort initial boundary - smalest priority first
  if (size != 0)
  {
    PointCompare<F> compare(ioPriorityMap, w);
    std::sort(ioNarrowBand.begin(), ioNarrowBand.end(), compare);
  }

} // elxPropagateBoundary


//----------------------------------------------------------------------------
//                      elxPatchPriority
// Calculates confidence and data terms for a given patch centered at iPoint
//----------------------------------------------------------------------------
template <typename Pixel>
void elxCalculatePatchPriority(const Math::Point2i& iPoint, uint32 iPatchSize,
  const ImageImpl<Pixel>& iRegion, const uint8* iBinaryMask,
  std::vector<typename ResolutionTypeTraits<typename Pixel::type>::Floating_type>& ioConfidenceMap,
  std::vector<typename ResolutionTypeTraits<typename Pixel::type>::Floating_type>& oPriorityMap)
{
  typedef typename Pixel::type T;
  typedef typename Pixel::FloatingPixel PixelF;
  typedef typename PixelF::type F;

  const static F ZERO_VAL = F();
  const static F ONE_VAL = F(1);

  const int32 half = iPatchSize/2;
  const int32 w = iRegion.GetWidth();
  const int32 h = iRegion.GetHeight();
  const int32 ymin = Math::elxMax(iPoint._y - half, 0);
  const int32 ymax = Math::elxMin(iPoint._y + half + 1, h);
  const int32 xmin = Math::elxMax(iPoint._x - half, 0);
  const int32 xmax = Math::elxMin(iPoint._x + half + 1, w);

  // Image gradient at P
  PixelF gradIx,gradIy;
  elxComputeIGradient(iPoint, iRegion, iBinaryMask, gradIx,gradIy);

  // compute normal using least square method to fit a stight line
  // through the front
  F sy = ZERO_VAL, sx = ZERO_VAL, sx2 = ZERO_VAL, sxy = ZERO_VAL;
  uint32 n = 0;
  F confidence = ZERO_VAL;

  BOOST_ASSERT(ymin <= ymax && xmin <= xmax);

  for (int32 y = ymin; y < ymax; ++y)
    for (int32 x = xmin; x < xmax; ++x)
    {
      // Confidence term
      confidence += ioConfidenceMap[y*w+x];

      if (!elxIPT_IS_BOUNDARY(iBinaryMask[y*w+x]))
        continue;
      sy += F(y);
      sx += F(x);
      sx2 += F(x*x);
      sxy += F(x*y);
      ++n;
    }

  F divisor = n*sx2 - sx*sx;
//BOOST_ASSERT(divisor != ZERO_VAL);
  Math::Point2<F> normal;
  if (divisor != ZERO_VAL)
  {
    normal._x = -(sy*sx2 - sx*sxy)/divisor;
    normal._y = ONE_VAL;
  }
  else
    normal._x = normal._y = ZERO_VAL;
    
  F norm = Math::elxSqrt(Math::elxSqr(normal._y) + Math::elxSqr(normal._x));
  normal._x /=norm;
  normal._y /=norm;

  // Data term - orthogonal Image gradient x normal to the image front
  PixelF pixel = gradIx * normal._y -  gradIy * normal._x;
  F data = Math::elxAbs(pixel.GetLuminance());

  // Confidence
  ioConfidenceMap[iPoint._y*w+iPoint._x] = confidence/((xmax-xmin)*(ymax-ymin));

  // Priority
  oPriorityMap[iPoint._y*w+iPoint._x] =
    ioConfidenceMap[iPoint._y*w+iPoint._x]*data;
} // elxPatchPriority


//----------------------------------------------------------------------------
//                          elxExemplarRestoreRegion
//----------------------------------------------------------------------------
template <typename Pixel>
bool elxExemplarRestoreRegion(ImageImpl<Pixel>& ioRegion,
  uint8* ioRegionMask, const ImageImpl<Pixel>& iImage, const uint8* iImageMask,
	const typename Pixel::type* iprImageLuminace, 
  uint32 iPatchSize, uint32 iChannelMask)
{
  // The algorithm's sodu code:
  // 1. Identify initial boundary
  // 2. Init confidence map: 0 - inside pixels, 1 - known
  // 3. Init priority map
  // 4. Loop untill done
  //    a. Identify the fill front. Exit if empty
  //    b. Compute priorities for pixels in the boundary
  //    c. Find the pixel with max priority
  //    d. Find a best exemplar to fill the patch centered at that point
  //    e. Copy pixels from exemplar to patch
  //    f. Update Confidence for all points in a patch

  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

  typedef std::deque<Math::Point2i> NarrowBand;
  typedef std::vector<F> ConfidenceMap;
  typedef std::vector<F> PriorityMap;

  const static F ZERO_VAL = F();
  const static F ONE_VAL = F(1);

  const uint32 w = ioRegion.GetWidth();
  const uint32 h = ioRegion.GetHeight();

  // Step 1. Initial boundary
  NarrowBand narrowBand;
  elxInitBoundary(ioRegionMask, w, h, narrowBand);

  // Step 2. Init confidence map. 0 - inside pixels, 1 -known
  ConfidenceMap confidenceMap;
  confidenceMap.reserve(w*h);
  for (uint32 i = 0; i < w*h; ++i)
    (elxIPT_IS_UNKNOWN(ioRegionMask[i]))  ?
      confidenceMap.push_back(ZERO_VAL):confidenceMap.push_back(ONE_VAL);

  // Step 3. Init priority map.
  PriorityMap priorityMap(w*h, ZERO_VAL);

  // Calculate priorities for the initial boundary
  NarrowBand::iterator bandItEnd = narrowBand.end();
  for (NarrowBand::iterator it = narrowBand.begin(); it != bandItEnd; ++it)
    elxCalculatePatchPriority(
	    *it, iPatchSize, ioRegion, ioRegionMask, confidenceMap, priorityMap);

  //  Sort initial boundary - smalest priority first
  PointCompare<F> compare(priorityMap, w);
  std::sort(narrowBand.begin(), narrowBand.end(), compare);

  // Optimization. Keep track of the points which need to be skipped
  // during the elxFindBestMatch - patch centered at them would contain
  // unknown pixels
  std::set<uint32> skipPoints;
  elxIdentSkippedPixels(iImage, iImageMask, iPatchSize, skipPoints);

  // 4. Loop until done
  while (!narrowBand.empty())
  {
    // Find the pixel with max priority
    Math::Point2i point = narrowBand.back();
    narrowBand.pop_back();

    if (!elxIPT_IS_BOUNDARY(ioRegionMask[point._y*w+point._x]))
      continue;

    // Find a best exemplar to fill the patch centered at that point
    Math::Point2i exemplarPoint = elxFindBestMatch(point,
      iImage, iImageMask, iprImageLuminace,
      ioRegion, ioRegionMask, iPatchSize, skipPoints);

	  // Copy pixels from exemplar to patch and
	  // Update Confidence for all points in a patch
	  elxPropagateTexture(point, exemplarPoint, iImage, iPatchSize,
      ioRegion, ioRegionMask, confidenceMap, narrowBand);

	  // Advance boundary
    elxAdvanceBoundary(point, ioRegion, iPatchSize, ioRegionMask, confidenceMap,
      priorityMap, narrowBand);
  }

  return true;
} // elxExemplarRestoreRegion

} // namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageRestorationImpl<Pixel>::ExemplarBasedInpaint(
  ImageImpl<Pixel>& ioImage, const ImageLub& iBinaryMask,
  const Math::AOBBox2i& iSearchArea, uint32 iPatchSize, bool iUseRegion, 
  uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  typedef typename Pixel::type T;

  if (iPatchSize < 3)
    iPatchSize = 3;
  if (!(iPatchSize & 1))
    ++iPatchSize; 

  // Build inpaint mask based on known/unknown pixels
  boost::shared_ptr<ImageLub> spSourceMask = elxCreateInpaintMask(iBinaryMask);

  // extract search area
  const int32 width = 
    Math::elxMin(iSearchArea._w, int32(ioImage.GetWidth() - iSearchArea._x - 1));
  const int32 height = 
    Math::elxMin(iSearchArea._h, int32(ioImage.GetHeight() - iSearchArea._y - 1));
  const uint32 size = width * height;
  
  boost::shared_ptr< ImageImpl<Pixel> > spSubImage = 
    ImageGeometryImpl<Pixel>::CreateSubImage(
      ioImage, iSearchArea._x, iSearchArea._y, width, height);
  // extract search mask
  boost::shared_ptr<ImageLub> spSubMask =
    ImageGeometryImpl<PixelLub>::CreateSubImage(
      *spSourceMask, iSearchArea._x, iSearchArea._y, width, height);
        
  //precompute image luminance
  boost::scoped_array<T> spSubImageLuminance(new T[width*height]);
  if (NULL == spSubImageLuminance.get())
    return false;
  Pixel* prPixelBegin = spSubImage->GetPixel();
  for (uint32 i = 0; i < size; ++i, ++prPixelBegin)
    spSubImageLuminance[i] = prPixelBegin->GetLuminance();
  
  if (iUseRegion)
  {
    // optimizations: inpaint only localized regions

    // Get inpaint regions from mask
    std::vector<Math::AOBBox2i> regions;
    if (!elxScanInpaintRegions( *spSourceMask, regions))
      return false;
    const size_t nRegion = regions.size();

    // --- inits progress ---
    const float step = 1.0f / float(nRegion);
    float progress = 0.f;
    iNotifier.SetProgress(progress);
    
    // for each regions inpaint locally
    for (size_t r=0; r<nRegion; r++)
    {
      // get region expanded bounding box
      Math::AOBBox2i box = regions[r];

      // get region
      boost::shared_ptr< ImageImpl<Pixel> > spRegion =
        ImageGeometryImpl<Pixel>::CreateSubImage(
          ioImage, box._x, box._y, box._w, box._h);

      // get region mask
      boost::shared_ptr<ImageLub> spRegionMask =
        ImageGeometryImpl<PixelLub>::CreateSubImage(
          *spSourceMask, box._x, box._y, box._w, box._h);

      // Restore the region
      if (!elxExemplarRestoreRegion(*spRegion, spRegionMask->GetSamples(),
		    *spSubImage, spSubMask->GetSamples(), spSubImageLuminance.get(),
        iPatchSize, iChannelMask))
        return false;

      // inject inpainted tile in source image
      ImageGeometryImpl<Pixel>::Insert(ioImage, *spRegion, box._x, box._y);

      // --- update progress ---
      progress += step;
      iNotifier.SetProgress(progress);
    }
  }
  else
  {
    // Restore the region
    if (!elxExemplarRestoreRegion(ioImage, spSourceMask->GetSamples(),
		  *spSubImage, spSubMask->GetSamples(), spSubImageLuminance.get(),
      iPatchSize, iChannelMask))
      return false;
  }

  iNotifier.SetProgress(1.f);
  return true;

} // ExemplarBasedInpaint

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImageRestorationImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageRestorationImpl<Pixel>::ExemplarBasedInpaint(
  AbstractImage& ioImage, const ImageLub& iBinaryMask,
  const Math::AOBBox2i& iSearchArea, uint32 iPatchSize, bool iUseRegion,
  uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ExemplarBasedInpaint(image, iBinaryMask, iSearchArea, 
    iPatchSize, iUseRegion, iChannelMask, iNotifier);

} // ExemplarBasedInpaint

} // namespace Image
} // namespace eLynx

#endif // __Restoration_ExemplarInpainting_hpp__

