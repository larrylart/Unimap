//============================================================================
//  Restoration/FastInpainting.hpp                     Image.Component package
//============================================================================
//  Fast Marching Image Inpainting:
//
//  http://elynxsdk.free.fr/ext-docs/InpaintingFastMarching.pdf
//
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Restoration_FastInpainting_hpp__
#define __Restoration_FastInpainting_hpp__

#include <vector>
#include <boost/shared_ptr.hpp>
#include <elx/image/ImageGeometryImpl.h>
#include "../LocalProcessing/ProcessorEngine3x3.hpp"
#include "../Rasterization/Scan.hpp"

namespace eLynx {
namespace Image {

namespace {

//----------------------------------------------------------------------------
//  elxCreateInpaintMask
// Implementation is in ImageRrestorationImpl.cpp
//----------------------------------------------------------------------------
boost::shared_ptr<ImageLub> elxCreateInpaintMask(const ImageLub& iBinaryMask);

//----------------------------------------------------------------------------
//  elxScanInpaintRegions
// Implementation is in ImageRrestorationImpl.cpp
//----------------------------------------------------------------------------
bool elxScanInpaintRegions(ImageLub& ioInpaintMask,
    std::vector<Math::AOBBox2i>& oRegions);
    
//----------------------------------------------------------------------------
//  elxFillBoundary
// Implementation is in ImageRrestorationImpl.cpp
//----------------------------------------------------------------------------
bool elxFillBoundary(ImageLub& ioInpaintMask);

//----------------------------------------------------------------------------
//  OperatorScanRegion
//----------------------------------------------------------------------------
struct OperatorScanRegion
{
  OperatorScanRegion(uint8 * iprBitmap, int32 iWidth) :
    _prBitmap(iprBitmap),
    _width(iWidth)
  {}

  void Init(int32 iX, int32 iY)
  {
    _xs = _xe = iX; 
    _ys = _ye = iY;
  }

  void GetBBox(Math::AOBBox2i& oBBox)
  {
    oBBox = Math::AOBBox2i( _xs,_ys, _xe-_xs+1, _ye-_ys+1);
  }

  void operator()(int32 iX, int32 iY)
  {
    // set point as already seen
    elxIPT_SET_SEEN( _prBitmap[iY*_width + iX] );

    // update bounding box
    if (iX < _xs) _xs = iX; else if (iX > _xe) _xe = iX; 
    if (iY < _ys) _ys = iY; else if (iY > _ye) _ye = iY;
  }
  
  uint8 * _prBitmap;
  int32 _width, _xs,_ys, _xe,_ye;
};

//----------------------------------------------------------------------------
//                          FastInpaintConvolution3x3
//----------------------------------------------------------------------------
template <typename Pixel>
class FastInpaintConvolution3x3
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  typedef typename Pixel::FloatingPixel Atom;

public:
  FastInpaintConvolution3x3(ImageLub& ioInpaintMask, uint32 iChannelMask=CM_All) :
   _prBitmap(ioInpaintMask.GetSamples()),
   _width(ioInpaintMask.GetWidth()),
   _channelMask(iChannelMask),
   _doMask(iChannelMask!=CM_All),
   _doClamp(),
   _currentRow(0)
  {
    const int32 w = int32(_width);
    _neighbours[0] = -w-1;   _neighbours[1] = -w;    _neighbours[2] = -w+1;
    _neighbours[3] = -1;                             _neighbours[4] = +1;
    _neighbours[5] = +w-1;   _neighbours[6] = +w;    _neighbours[7] = +w+1;
  }

  //The oppotunity to adjust to the iteration range
  // this processor is going to operate on. 
  void SetRange(const IterationRange& iRange)
  {}
  
  // Do generic, inlined using optimization
  void Do(Atom ** iprLines, uint32 iX, Pixel * oprDst) const
  { 
    const uint32 w = _width;
    F k[8];
    int32 i, idx = _currentRow*w + iX; 
    if (elxIPT_IS_BOUNDARY(_prBitmap[idx]))
    {        
      // compute dynamic mean kernel based on known neighbour pixels
      F weight = 0;
      for (i=0; i<8; i++)
      {
        if (elxIPT_IS_KNOWN(_prBitmap[idx + _neighbours[i]]))
        {
          weight += 1;
          k[i] = 1;
        }
        else
          k[i] = 0;
      }
      
      // normalize kernel
      BOOST_ASSERT(weight > 0);
      for (i=0; i<8; i++) k[i] /= weight;
      
      // process convolution
      (_doMask) ? DoMask(iprLines, iX, k, oprDst) : 
                  DoNoMask(iprLines, iX, k, oprDst);

      // update inpaint mask
      elxIPT_UNSET_BOUNDARY(_prBitmap[idx]);
      elxIPT_SET_INPAINTED(_prBitmap[idx]);
    }
      
    if (iX == w - 1)
      ++_currentRow;      
  }
  
private:

  //--------------------------------------------------------------------------
  // Do # no mask fastest
  //--------------------------------------------------------------------------
  void DoNoMask(Atom ** iprL, uint32 iX, const F * iK, Pixel * oprDst) const
  {
    Atom p = 
       iprL[0][0+iX]*iK[0] + iprL[0][1+iX]*iK[1] + iprL[0][2+iX]*iK[2] + 
       iprL[1][0+iX]*iK[3] +                       iprL[1][2+iX]*iK[4] +
       iprL[2][0+iX]*iK[5] + iprL[2][1+iX]*iK[6] + iprL[2][2+iX]*iK[7];

    // update inpainted source in cached buffer
    iprL[1][1+iX] = p;

    // update processed image
    elxPixelClamp(p, *oprDst, _doClamp);
  }

  //--------------------------------------------------------------------------
  // Do # mask
  //--------------------------------------------------------------------------
  void DoMask(Atom ** iprL, uint32 iX,  const F * iK, Pixel * oprDst) const
  {
    Atom sum = elxPixelMul(iprL[0][0+iX], iK[0], _channelMask);
    Atom mul = elxPixelMul(iprL[0][1+iX], iK[1], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[0][2+iX], iK[2], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);

    mul = elxPixelMul(iprL[1][0+iX], iK[3], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[1][2+iX], iK[4], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);

    mul = elxPixelMul(iprL[2][0+iX], iK[5], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[2][1+iX], iK[6], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[2][2+iX], iK[7], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);

    // update inpainted source in cached buffer
    iprL[1][1+iX] = sum;

    elxPixelClamp(sum, *oprDst, _doClamp, _channelMask);
  }

private:
  uint8 * _prBitmap;
  const uint32 _width;
  const uint32 _channelMask;
  const bool _doMask;
  const IntegerToType< ResolutionTypeTraits<T>::_bInteger > _doClamp;
  int32 _neighbours[8];
  mutable uint32 _currentRow;
};

//----------------------------------------------------------------------------
//                          FastInpaintRegion task
//----------------------------------------------------------------------------
template <typename Pixel>
struct FastInpaintingRegionTask : public IterationRangeTask
{
  typedef typename Pixel::FloatingPixel PixelF; 
   
  // Constructor
  FastInpaintingRegionTask(ImageImpl<Pixel>& ioImage, 
      const ImageLub* iprInpaintMask, 
      const std::vector<Math::AOBBox2i>& iInpaintRegions,
      uint32 iChannelMask, ProgressNotifier& iNotifier) :
    IterationRangeTask( IterationRange(0, 1, iNotifier) ),
    _Image(ioImage),
    _prInpaintMask(iprInpaintMask),
    _InpaintRegions(iInpaintRegions),
    _ChannelMask(iChannelMask)
  {}
    
  // Split constructor
  FastInpaintingRegionTask(
      const FastInpaintingRegionTask& iOther, const IterationRange& iRange):
    IterationRangeTask(iRange, iOther._notifier),
    _Image(iOther._Image),
    _prInpaintMask(iOther._prInpaintMask),
    _InpaintRegions(iOther._InpaintRegions),
    _ChannelMask(iOther._ChannelMask)
  {}
    
  uint32 operator()()
  {
    const uint32 begin = _begin;
    const uint32 end = _end;
    const ImageLub* prInpaintMask = _prInpaintMask;
    ImageImpl<Pixel>& image = _Image;
    const std::vector<Math::AOBBox2i>& inpaintRegions = _InpaintRegions;
    ProgressNotifier& notifier = _notifier;
    const uint32 channelMask = _ChannelMask;
    
    // --- inits progress ---
    const float step = 1.0f / float(end-begin);
    float progress = 0.f;
    notifier.SetProgress(progress);
    
    // We need to disable multicore convolution because it would invalidate the 
    // order of the inpainting pixels.
    const bool bUseParallelImpl = false;

    // for each regions inpaint locally
    for (uint32 r=begin; r < end; r++)
    {
      // get region expanded bounding box
      Math::AOBBox2i box = inpaintRegions[r];

      // get sub source
      boost::shared_ptr< ImageImpl<Pixel> > spSubSource = 
        ImageGeometryImpl<Pixel>::CreateSubImage(
          image, box._x, box._y, box._w, box._h);

      // get sub inpaint mask
      boost::shared_ptr<ImageLub> spSubMask = 
        ImageGeometryImpl<PixelLub>::CreateSubImage(
          *prInpaintMask, box._x, box._y, box._w, box._h);
          
      // convolve region until all boundary pixels are inpainted
      while (elxFillBoundary(*spSubMask))
      {
        // initialize processor
        FastInpaintConvolution3x3<Pixel> processor(*spSubMask, channelMask);

        // apply dynamic convolution
        elxProcessLocalToPoint3x3<Pixel, PixelF>(*spSubSource, processor, 
          BF_Nearest, 1, ProgressNotifier_NULL, bUseParallelImpl);
      }
    
      // inject inpainted tile in source image
      ImageGeometryImpl<Pixel>::Insert(image, *spSubSource, box._x, box._y);

      // --- update progress ---
      progress += step;
      notifier.SetProgress(progress);
    }
    
    // --- progress end ---
    notifier.SetProgress(1.0f);
    return elxOK;
  }

private:  
  ImageImpl<Pixel>& _Image;         // Source Image
  const ImageLub * _prInpaintMask;  // Inpainting mask
  uint32 _ChannelMask;                // Channel mask
  // Regions to inpaint
  const std::vector<Math::AOBBox2i>& _InpaintRegions;
};

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel> 
bool ImageRestorationImpl<Pixel>::FastInpaint(
    ImageImpl<Pixel>& ioImage,
    const ImageLub& iBinaryMask, 
    bool ibUseRegion,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  typedef typename Pixel::FloatingPixel PixelF;  

  // Build inpaint mask based on known/unknown pixels
  boost::shared_ptr<ImageLub> spInpaintMask = elxCreateInpaintMask(iBinaryMask);

  // We need to disable multicore convolution because it would invalidate the 
  // order of the inpainting pixels.
  bool bUseParallelImpl = false;

  if (ibUseRegion)
  {
    // optimizations: inpaint only localized regions
    // Get inpaint regions from mask
    std::vector<Math::AOBBox2i> regions;
    if (!elxScanInpaintRegions( *spInpaintMask, regions))
      return false;
    const size_t nRegion = regions.size();

    // --- inits progress ---
    const float step = 1.0f / float(nRegion);
    float progress = 0.f;
    iNotifier.SetProgress(progress);

    // for each regions inpaint locally
    for (size_t r=0; r<nRegion; r++)
    {
      // get region expanded bounding box
      Math::AOBBox2i box = regions[r];

      // get sub source
      boost::shared_ptr< ImageImpl<Pixel> > spSubSource = 
        ImageGeometryImpl<Pixel>::CreateSubImage(
          ioImage, box._x, box._y, box._w, box._h);

      // get sub inpaint mask
      boost::shared_ptr<ImageLub> spSubMask = 
        ImageGeometryImpl<PixelLub>::CreateSubImage(
          *spInpaintMask, box._x, box._y, box._w, box._h);

      // process until no more boundaries are available
      while (elxFillBoundary(*spSubMask))
      {
        // initialize processor
        FastInpaintConvolution3x3<Pixel> processor(*spSubMask, iChannelMask);

        // apply dynamic convolution
        elxProcessLocalToPoint3x3<Pixel, PixelF>(*spSubSource, processor, 
          BF_Nearest, 1, ProgressNotifier_NULL, bUseParallelImpl);
      }

      // inject inpainted tile in source image
      ImageGeometryImpl<Pixel>::Insert(ioImage, *spSubSource, box._x, box._y);

      // --- update progress ---
      progress += step;
      iNotifier.SetProgress(progress);    
    }
  }
  else
  {
    // process until no more boundaries are available
    while (elxFillBoundary(*spInpaintMask))
    {
      // initialize processor
      FastInpaintConvolution3x3<Pixel> processor(*spInpaintMask, iChannelMask);

      // apply dynamic convolution
      elxProcessLocalToPoint3x3<Pixel, PixelF>(ioImage, processor, 
        BF_Nearest, 1, ProgressNotifier_NULL, bUseParallelImpl);
    }
  }
    
  iNotifier.SetProgress(1.f);
  return true;

} // FastInpaint # ImageImpl<Pixel>


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImageRestorationImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageRestorationImpl<Pixel>::FastInpaint(
    AbstractImage& ioImage,
    const ImageLub& iBinaryMask, 
    bool ibUseRegion,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return FastInpaint(image, iBinaryMask, ibUseRegion, iChannelMask, iNotifier);

} // FastInpaint # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __Restoration_FastInpainting_hpp__
