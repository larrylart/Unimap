//============================================================================
//  Restoration/MarchingInpainting.hpp                 Image.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Restoration_MarchingInpainting_hpp__
#define __Restoration_MarchingInpainting_hpp__

#include <deque>
#include <algorithm>

#include <boost/shared_ptr.hpp>

#include <elx/image/ImageGeometryImpl.h>
#include <elx/image/ImageCommon.h>
#include <elx/math/KernelCollection.h>

namespace eLynx {
namespace Image {

namespace {

//----------------------------------------------------------------------------
// Initialize initial boundary of the inpainting region    
// Implementation is in ImageRrestorationImpl.cpp
//----------------------------------------------------------------------------
void elxInitBoundary(uint8* ioBinaryMask, int32 iW, int32 iH, 
    std::deque<Math::Point2i>& oNarrowBand);

//----------------------------------------------------------------------------
// Inserts pixel into a queue according to its distance from the
// original region boundary
//----------------------------------------------------------------------------
template <typename T>
struct PointCompare
{
  PointCompare(const std::vector<T>& iSortMap, uint32 iW) :
    _sortMap(iSortMap), _w(iW)
    {}
    
  bool operator () (const Math::Point2i& iP1, const Math::Point2i& iP2) const
  {
    return _sortMap[iP1._y*_w + iP1._x] < _sortMap[iP2._y*_w + iP2._x];
  }
    
  const std::vector<T>& _sortMap;
  int32 _w;
};

//----------------------------------------------------------------------------
// elxUpdateBoundary
//----------------------------------------------------------------------------
template <typename T>
void elxUpdateBoundary(const Math::Point2i& iPoint, uint32 iW,
  const std::vector<T>& iDistanceMap, std::deque<Math::Point2i>& ioBand)
{
  const uint32 idx = iPoint._y*iW + iPoint._x;
  BOOST_ASSERT(idx < iDistanceMap.size());
  PointCompare<T> compare(iDistanceMap, iW);

  // Find a place to insert
  std::deque<Math::Point2i>::iterator iter = 
    std::lower_bound(ioBand.begin(), ioBand.end(), iPoint, compare);
  ioBand.insert(iter, iPoint);

} // elxUpdateBoundary 

//----------------------------------------------------------------------------
// Solves Eikonal equation     
//----------------------------------------------------------------------------
template <typename T>
T elxSolveEikonal(int32 iX1, int32 iY1, int32 iX2, int32 iY2, uint32 iW,
  const uint8* ioBinaryMask, const std::vector<T>& iDistanceMap)
{
  static const T BIG_VALUE = T(1000000.);
  static const T SQRT2 = Math::elxSqrt(T(2));
  
  T sol = BIG_VALUE;
  int32 idx1 = iY1 * iW + iX1;
  int32 idx2 = iY2 * iW + iX2;
  if (elxIPT_IS_KNOWN(ioBinaryMask[idx1]))
  {
    if (elxIPT_IS_KNOWN(ioBinaryMask[idx2]))
    {
      T r = SQRT2*Math::elxAbs(iDistanceMap[idx1] - iDistanceMap[idx2]);
      T s = (iDistanceMap[idx1] + iDistanceMap[idx2]*r) / 2;
      if (s >= iDistanceMap[idx1] && s >= iDistanceMap[idx2])
        sol = s;
      else
      {
        s += r;
        if (s >= iDistanceMap[idx1] && s >= iDistanceMap[idx2])
          sol = s; 
      }  
    }
    else
      sol = T(1. + iDistanceMap[idx1]);
  }
  else if (elxIPT_IS_KNOWN(ioBinaryMask[idx2]))
    sol = T(1. + iDistanceMap[idx2]);
  return sol;

} // elxSolve

//----------------------------------------------------------------------------
// Initialize distance map for the inpainting region    
//----------------------------------------------------------------------------
template <typename T>
void elxInitDistanceMap(
  const uint8* iBinaryMask, uint32 iSize, std::vector<T>& oDistanceMap)
{
  static const T BIG_VALUE = T(1000000.); 
  static const T ZERO_VALUE = T();
  static const T NEG_VALUE = T(-1.);
   
  oDistanceMap.reserve(iSize);
  for (uint32 i = 0; i < iSize; ++i)
    if (elxIPT_IS_UNKNOWN(iBinaryMask[i]))
      oDistanceMap.push_back(BIG_VALUE);
    else if (elxIPT_IS_BOUNDARY(iBinaryMask[i]))
      oDistanceMap.push_back(ZERO_VALUE);
    else
      oDistanceMap.push_back(NEG_VALUE);

} // elxInitDistanceMap 

//----------------------------------------------------------------------------
// Computes distance gradient   
//----------------------------------------------------------------------------
template <typename F>
Math::Point2<F> elxComputeTGradient(const Math::Point2i& iPoint, 
  int32 iW, int32 iH, const std::vector<F>& iDistanceMap)
{
  const static F ZERO_VALUE = F();
  const static int32 SIZE = 5;
  const static int32 HALF = SIZE/2; 
  const static Math::ConvolutionKerneld kernelX = Math::elxMakeSobelNxNd(SIZE);
  const static Math::ConvolutionKerneld kernelY = 
    Math::elxMakeSobelNxNd(SIZE).Rotated(Math::CD_East);
  
  static F neighbors[SIZE*SIZE];  
  memset(neighbors, 0, SIZE*SIZE*sizeof(F));
  const int32 ymin = Math::elxMax(iPoint._y - HALF, 0);
  const int32 ymax = Math::elxMin(iPoint._y + HALF + 1, iH);
  const int32 xmin = Math::elxMax(iPoint._x - HALF, 0);
  const int32 xmax = Math::elxMin(iPoint._x + HALF + 1, iW);
  
  for (int32 y = ymin; y < ymax; ++y)
    for (int32 x = xmin; x < xmax; ++x)
      neighbors[(y-ymin)*SIZE+(x-xmin)] = iDistanceMap[y*iW + x];
      
  F gradX = ZERO_VALUE;
  F gradY = ZERO_VALUE;
  for (int32 i = 0; i < SIZE*SIZE; ++i)
  {
    gradX += F(neighbors[i]*kernelX._spK[i]);
    gradY += F(neighbors[i]*kernelY._spK[i]);
  }
  F norm = Math::elxSqrt(Math::elxSqr(gradX) + Math::elxSqr(gradY));
  if (norm != ZERO_VALUE)
  {
    gradX /= norm;
    gradY /= norm;
  }
  return Math::Point2<F>(gradX, gradY);

} // elxComputeTGradient


//----------------------------------------------------------------------------
// Computes image gradient   
//----------------------------------------------------------------------------
template <typename Pixel>
void elxComputeIGradient(
  const Math::Point2i& iPoint, 
  const ImageImpl<Pixel>& iRegion, const uint8* iBinaryMask,
  typename Pixel::FloatingPixel& oGradIx, 
  typename Pixel::FloatingPixel& oGradIy)
{
  typedef typename Pixel::FloatingPixel PixelF;
  typedef typename PixelF::type F;
  
  oGradIx = oGradIy = PixelF::Black();
  const static int32 SIZE = 5;
  const static int32 HALF = SIZE/2; 
  const static F ZERO_VAL = F();
  const static F ONE_VAL = F(1.);
  const static Math::ConvolutionKerneld kernelX = Math::elxMakeSobelNxNd(SIZE);
  const static Math::ConvolutionKerneld kernelY = 
    Math::elxMakeSobelNxNd(SIZE).Rotated(Math::CD_East);

  static PixelF neighbors[SIZE*SIZE];
  static uint32 bitmap[SIZE*SIZE];
  memset(bitmap, 0, SIZE*SIZE*sizeof(uint32));
  
  int32 w = iRegion.GetWidth();
  int32 h = iRegion.GetHeight();

  const int32 ymin = Math::elxMax(iPoint._y - HALF, 0);
  const int32 ymax = Math::elxMin(iPoint._y + HALF + 1, h);
  const int32 xmin = Math::elxMax(iPoint._x - HALF, 0);
  const int32 xmax = Math::elxMin(iPoint._x + HALF + 1, w);
  
  for (int32 y = ymin; y < ymax; ++y)
    for (int32 x = xmin; x < xmax; ++x)
      if (elxIPT_IS_KNOWN(iBinaryMask[y*w+x]))
      {
        uint32 idx = (y-ymin)*SIZE+(x-xmin);
        bitmap[idx] = 1; 
        neighbors[idx] = *iRegion.GetPixel(x,y);
      }

  F sum = ZERO_VAL;
  for (int32 i = 0; i < SIZE*SIZE; ++i)
    if (bitmap[i])
    {
      F kernel = F(kernelX._spK[i]);
      oGradIx += neighbors[i] * kernel;
      oGradIy += neighbors[i] * kernel;
      sum += kernel;
    }
  
  sum = (sum == ZERO_VAL)? ONE_VAL : Math::elxAbs(sum);
  for (uint32 i=0; i<PixelF::_nChannel; ++i)
  {
    F norm = Math::elxSqrt(
      Math::elxSqr(oGradIx._channel[i]) + Math::elxSqr(oGradIy._channel[i])) * sum;
    if (norm > ZERO_VAL)
    {
      oGradIx._channel[i] /= norm;
      oGradIy._channel[i] /= norm;
    }
  } 

} // elxComputeIGradient

//----------------------------------------------------------------------------
// Inpaints a pixel   
//----------------------------------------------------------------------------
template <typename Pixel, typename F>
void elxInpaintPixel(const Math::Point2i& iPoint, uint32 iSize, 
  const uint8* iBinaryMask, const std::vector<F>& iDistanceMap,
  ImageImpl<Pixel>& ioRegion) 
{
  typedef typename Pixel::type T;
  typedef typename Pixel::FloatingPixel PixelF;
  
  static const IntegerToType< ResolutionTypeTraits<T>::_bInteger > DoClamp =
    IntegerToType< ResolutionTypeTraits<T>::_bInteger >();
  
  const int32 w = int32 (ioRegion.GetWidth());
  const int32 h = int32 (ioRegion.GetHeight());
  const int32 half = int32 (iSize/2);
  const int32 pidx = iPoint._y * w + iPoint._x;
  
  Math::Point2<F> gradT = elxComputeTGradient(iPoint, w, h, iDistanceMap);

  PixelF gradIx,gradIy;
  elxComputeIGradient(iPoint, ioRegion, iBinaryMask, gradIx,gradIy);

  PixelF pixelSum;
  F sum = F();
  const int32 ymin = Math::elxMax(iPoint._y - half, 0);
  const int32 ymax = Math::elxMin(iPoint._y + half + 1, h);
  const int32 xmin = Math::elxMax(iPoint._x - half, 0);
  const int32 xmax = Math::elxMin(iPoint._x + half + 1, w);
  
  for (int32 y = ymin; y < ymax; ++y)
    for (int32 x = xmin; x < xmax; ++x)
    {
      // Iterate only over the known pixels
      int32 idx = y*w + x;
      if (elxIPT_IS_UNKNOWN(iBinaryMask[idx]))
        continue; 
      BOOST_ASSERT(x != iPoint._x || y != iPoint._y);
      
      Math::Point2<F> r(x - iPoint._x, y - iPoint._y); // vector  
      F lengthR2 = Math::elxSqr(r._x) + Math::elxSqr(r._y);
      F lengthR = Math::elxSqrt(lengthR2);

      F dir = Math::elxAbs(Math::elxDotProduct(r, gradT) / lengthR);
      if (dir == F(0))
        dir = F(1);
      F dst = F(1) / lengthR2;
      F lev = F(1) / 
              (F(1) + Math::elxAbs(iDistanceMap[idx] - iDistanceMap[pidx]));
              
      F weight = dir*dst*lev;

      PixelF pixel = *ioRegion.GetPixel(x, y);
      pixelSum += (pixel + gradIx * r._x + gradIy * r._y) * weight;
      sum += weight;
    }
    
  BOOST_ASSERT(sum > 0);
  elxPixelClamp(pixelSum/sum, *ioRegion.GetPixel(iPoint._x, iPoint._y), DoClamp);

} // elxInpaintPixel
  
//----------------------------------------------------------------------------
//                          elxFMMRestoreRegion
//----------------------------------------------------------------------------
template <class Pixel> 
bool elxFMMRestoreRegion(ImageImpl<Pixel>& ioRegion, uint8* iBinaryMask, 
  uint32 iSize, uint32 iChannelMask)
{
  // Algorithm's pseudocode
  // 0. dQinit initial boundary of the region to restore
  // 1. dQ = dQinit
  // 2. while (dQ not empty) {
  // 3.   p = pixel from the dQ closest to dQinit
  // 4.   inpaint P and mark it as known
  // 5.   advance dQ by identifying new boundary
  // 6. }

  typedef typename Pixel::FloatingPixel PixelF;  
  typedef typename PixelF::type F;
  typedef std::deque<Math::Point2i> NarrowBand;
  typedef std::vector<F> DistanceMap;
      
  const int32 w = ioRegion.GetWidth();
  const int32 h = ioRegion.GetHeight();
  static const uint32 SIZE = 4; 
  static const Math::Point2i neighbors[SIZE] = 
    {Math::Point2i(-1, 0), Math::Point2i(0, -1), 
     Math::Point2i(1, 0), Math::Point2i(0, 1)};
  
  // Step 1. Initial boundary
  NarrowBand narrowBand;
  elxInitBoundary(iBinaryMask, w, h, narrowBand);
  
  DistanceMap distanceMap;
  elxInitDistanceMap(iBinaryMask, w*h, distanceMap);
   
  // Sort narrowBand
  PointCompare<F> compare(distanceMap, w);
  std::sort(narrowBand.begin(), narrowBand.end(), compare);
//  narrowBand.sort(compare);

  // Step 2. Iterate until NarrowBand is not empty
  while (!narrowBand.empty())
  {
    // Step 3. Extract closest Pixel to the initial boundary 
    Math::Point2i point = narrowBand.front();
    narrowBand.pop_front();
    
    // Step 4. Inpaint Pixel and mark it as inpainted
    elxIPT_UNSET_BOUNDARY(iBinaryMask[point._y*w+point._x]);
    elxIPT_SET_INPAINTED(iBinaryMask[point._y*w+point._x]);
    
    for (uint32 i = 0; i < SIZE; ++i) 
    {
      Math::Point2i 
        neighbor(point._x + neighbors[i]._x, point._y + neighbors[i]._y);
      if (neighbor._x < 1 || neighbor._x >= w-1 || 
          neighbor._y < 1 || neighbor._y >= h-1)
        continue;
      if (elxIPT_IS_UNKNOWN(iBinaryMask[neighbor._y*w+neighbor._x]) &&
          !elxIPT_IS_BOUNDARY(iBinaryMask[neighbor._y*w+neighbor._x]))
      {
        BOOST_ASSERT(neighbor._x - 1 >= 0 && neighbor._x + 1 < w &&
                     neighbor._y - 1 >= 0 && neighbor._y + 1 < h);
        F d1 = elxSolveEikonal(neighbor._x - 1, neighbor._y, neighbor._x, 
                               neighbor._y - 1, w, iBinaryMask, distanceMap);
        F d2 = elxSolveEikonal(neighbor._x + 1, neighbor._y, neighbor._x, 
                               neighbor._y - 1, w, iBinaryMask, distanceMap);
        F d3 = elxSolveEikonal(neighbor._x - 1, neighbor._y, neighbor._x, 
                               neighbor._y + 1, w, iBinaryMask, distanceMap);
        F d4 = elxSolveEikonal(neighbor._x + 1, neighbor._y, neighbor._x, 
                               neighbor._y + 1, w, iBinaryMask, distanceMap);
        distanceMap[neighbor._y*w + neighbor._x] = Math::elxMin(d1, d2, d3, d4);

        elxInpaintPixel(neighbor, iSize, iBinaryMask, distanceMap, ioRegion); 
        elxIPT_SET_BOUNDARY(iBinaryMask[neighbor._y*w+neighbor._x]);

        // Step 5. Advance the boundary
        elxUpdateBoundary(neighbor, w, distanceMap, narrowBand);
      }      
    }
  }
  return true;
  
} // elxFMMRestoreRegion
      
} // namespace

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel> 
bool ImageRestorationImpl<Pixel>::FastMarchingInpaint(
      ImageImpl<Pixel>& ioImage,
      const ImageLub& iBinaryMask, 
      uint32 iSize, 
      bool ibUseRegion,
      uint32 iChannelMask, 
      ProgressNotifier& iNotifier)
{
  if (iSize < 3)
    iSize = 3;
  if (!(iSize & 1))
    ++iSize;   

  // Build inpaint mask based on known/unknown pixels
  boost::shared_ptr<ImageLub> spInpaintMask = elxCreateInpaintMask(iBinaryMask);

  if (ibUseRegion)
  {
    // optimizations: inpaint only localized regions

    // Get inpaint regions from mask
    std::vector<Math::AOBBox2i> regions;
    if (!elxScanInpaintRegions( *spInpaintMask, regions))
      return false;
    const size_t nRegion = regions.size();

    // --- inits progress ---
    const float step = 1.0f / float(nRegion);
    float progress = 0.f;
    iNotifier.SetProgress(progress);

    // for each regions inpaint locally
    for (size_t r=0; r<nRegion; r++)
    {
      // get region expanded bounding box
      Math::AOBBox2i box = regions[r];

      // get sub source
      boost::shared_ptr< ImageImpl<Pixel> > spSubSource = 
        ImageGeometryImpl<Pixel>::CreateSubImage(
          ioImage, box._x, box._y, box._w, box._h);

      // get sub inpaint mask
      boost::shared_ptr<ImageLub> spSubMask = 
        ImageGeometryImpl<PixelLub>::CreateSubImage(
          *spInpaintMask, box._x, box._y, box._w, box._h);

      // Restore the region
      if (!elxFMMRestoreRegion(
            *spSubSource, spSubMask->GetSamples(), iSize, iChannelMask))
        return false;

      // inject inpainted tile in source image
      ImageGeometryImpl<Pixel>::Insert(ioImage, *spSubSource, box._x, box._y);

      // --- update progress ---
      progress += step;
      iNotifier.SetProgress(progress);    
    }
  }
  else
  {
    if (!elxFMMRestoreRegion(
          ioImage, spInpaintMask->GetSamples(), iSize, iChannelMask))
      return false;
  }
    
  iNotifier.SetProgress(1.f);
  return true;

} // FastMarchingInpaint

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from ImageRestorationImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageRestorationImpl<Pixel>::FastMarchingInpaint(
      AbstractImage& ioImage,
      const ImageLub& iBinaryMask, uint32 iSize, bool ibUseRegion,
      uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return FastMarchingInpaint(
    image, iBinaryMask, iSize, ibUseRegion, iChannelMask, iNotifier);

} // FastMarchingInpaint

} // namespace Image
} // namespace eLynx

#endif // __Restoration_MarchingInpainting_hpp__

