//============================================================================
//  ImageImpl.cpp                                      Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include "ImageImpl.hpp"

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxIsImageFormat
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
bool elxIsImageFormat(EPixelFormat iFormat)
{
  static bool ms_lut[PF_Undefined+1] =
  {
    true, true, true, true, true, // PF_Lub,    PF_Lus,   PF_Li,    PF_Lf,    PF_Ld
    true, true, true, true, true, // PF_LAub,   PF_LAus,  PF_LAi,   PF_LAf,   PF_LAd
    true, true, true, true, true, // PF_RGBub,  PF_RGBus, PF_RGBi,  PF_RGBf,  PF_RGBd
    true, true, true, true, true, // PF_RGBAub, PF_RGBAus,PF_RGBAi, PF_RGBAf, PF_RGBAd
#ifdef elxUSE_ImageComplex
    true, true, true,             //                      PF_CPLXi, PF_CPLXf, PF_CPLXd
#else
    false,false,false,
#endif
#ifdef elxUSE_ImageHLS
    true, true,                   //                                PF_HLSf,  PF_HLSd
#else
    false,false,
#endif
#ifdef elxUSE_ImageXYZ
    true, true,                   //                                PF_XYZf,  PF_XYZd
#else
    false,false,
#endif
#ifdef elxUSE_ImageLuv
    true, true,                   //                                PF_Luvf,  PF_Luvd,
#else
    false,false,
#endif
#ifdef elxUSE_ImageLab
    true, true,                   //                                PF_Labf,  PF_Labd
#else
    false,false,
#endif
#ifdef elxUSE_ImageLch
    true, true,                   //                                PF_Lchf,  PF_Lchbd
#else
    false,false,
#endif
#ifdef elxUSE_ImageHLab
    true, true,                   //                                PF_HLabf, PF_HLabd
#else
    false,false,
#endif
    true                          // PF_Undefined
  };
  return ms_lut[iFormat];

} // elxIsImageFormat


//----------------------------------------------------------------------------
//  elxIsImageFormat
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
bool elxIsImageColorSpace(EColorSpace iColorSpace)
{
  static bool ms_lut[CS_Undefined+1] =
  {
    true, // CS_RGB
#ifdef elxUSE_ImageHLS
    true, // CS_HLS
#else
    false,
#endif
#ifdef elxUSE_ImageXYZ
    true, // CS_CIE_XYZ
#else
    false,
#endif
#ifdef elxUSE_ImageLuv
    true, // CS_CIE_Luv
#else
    false,
#endif
#ifdef elxUSE_ImageLab
    true, // CS_CIE_Lab
#else
    false,
#endif
#ifdef elxUSE_ImageLch
    true, // CS_CIE_Lch
#else
    false,
#endif
#ifdef elxUSE_ImageHLab
    true, // CS_Hunter_Lab
#else
    false,
#endif
    true  // CS_Undefined
  };
  return ms_lut[iColorSpace];

} // elxIsImageColorSpace


//----------------------------------------------------------------------------
//  explicit instantiation of all image types
//----------------------------------------------------------------------------
elxINSTANTIATE_CLASS_FOR_ALL_IMAGE_TYPES(ImageImpl);

// for temporary access to int64 format
template class eLynx::Image::ImageImpl< PixelL<int64> >;
template class eLynx::Image::ImageImpl< PixelLA<int64> >;
template class eLynx::Image::ImageImpl< PixelRGB<int64> >;
template class eLynx::Image::ImageImpl< PixelRGBA<int64> >;

} // namespace Image
} // namespace eLynx
