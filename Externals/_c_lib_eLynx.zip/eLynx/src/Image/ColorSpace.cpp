//============================================================================
//  ColorSpace.cpp                                     Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/math/MathCore.h>
#include <elx/image/PixelMacros.h>
#include <elx/image/ColorSpace.h>

#include "ColorSpace/RGB.hpp"
#include "ColorSpace/HLS.hpp"
#include "ColorSpace/CIE.hpp"

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Indirect RGB <= CIE Luv, CIE Lab, CIE Lch, Hunter Lab
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//  RGB <= CIE Luv
template<typename T>
inline 
PixelRGB<T>::PixelRGB(const PixelLuv<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  RGB <= CIE Lab
template<typename T>
inline 
PixelRGB<T>::PixelRGB(const PixelLab<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  RGB <= CIE Lch
template<typename T>
inline 
PixelRGB<T>::PixelRGB(const PixelLch<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  RGB <= Hunter Lab
template<typename T>
inline 
PixelRGB<T>::PixelRGB(const PixelHLab<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Indirect HLS <= CIE XYZ, CIE Luv, CIE Lab, CIE Lch, Hunter Lab
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//  HLS <= CIE XYZ
template<typename T>
inline 
PixelHLS<T>::PixelHLS(const PixelXYZ<T>& iPixel)
{
  const PixelRGB<T> rgb = iPixel;
  *this = rgb;
}

//  HLS <= CIE Luv
template<typename T>
inline 
PixelHLS<T>::PixelHLS(const PixelLuv<T>& iPixel)
{
  const PixelRGB<T> rgb = iPixel;
  *this = rgb;
}

//  HLS <= CIE Lab
template<typename T>
inline 
PixelHLS<T>::PixelHLS(const PixelLab<T>& iPixel)
{
  const PixelRGB<T> rgb = iPixel;
  *this = rgb;
}

//  HLS <= CIE Lch
template<typename T>
inline 
PixelHLS<T>::PixelHLS(const PixelLch<T>& iPixel)
{
  const PixelRGB<T> rgb = iPixel;
  *this = rgb;
}

//  HLS <= Hunter Lab
template<typename T>
inline 
PixelHLS<T>::PixelHLS(const PixelHLab<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Indirect CIE XYZ <= HLS, CIE Lch
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//  CIE XYZ <= HLS
template<typename T>
inline 
PixelXYZ<T>::PixelXYZ(const PixelHLS<T>& iPixel)
{
  const PixelRGB<T> rgb = iPixel;
  *this = rgb;
}

//  CIE XYZ <= CIE Lch
template<typename T>
inline 
PixelXYZ<T>::PixelXYZ(const PixelLch<T>& iPixel)
{
  const PixelLab<T> Lab = iPixel;
  *this = Lab;
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Indirect CIE Luv <= RGB, HLS, CIE Lab, CIE Lch, Hunter Lab
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//  CIE Luv <= RGB
template<typename T>
inline 
PixelLuv<T>::PixelLuv(const PixelRGB<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  CIE Luv <= HLS
template<typename T>
inline 
PixelLuv<T>::PixelLuv(const PixelHLS<T>& iPixel)
{
  const PixelRGB<T> rgb = iPixel;
  *this = rgb;
}

//  CIE Luv <= CIE Lab
template<typename T>
inline 
PixelLuv<T>::PixelLuv(const PixelLab<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  CIE Luv <= CIE Lch
template<typename T>
inline 
PixelLuv<T>::PixelLuv(const PixelLch<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  CIE Luv <= Hunter Lab
template<typename T>
inline 
PixelLuv<T>::PixelLuv(const PixelHLab<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Indirect CIE Lab <= RGB, HLS, CIE Luv, Hunter Lab
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  CIE Lab <= L
template<typename T>
inline 
PixelLab<T>::PixelLab(const PixelL<T>& iPixel)
{
  const T l = iPixel._luminance;
  const PixelXYZ<T> XYZ = PixelRGB<T>(l,l,l);
  *this = XYZ;
}

//  CIE Lab <= LA
template<typename T>
inline 
PixelLab<T>::PixelLab(const PixelLA<T>& iPixel)
{
  const T l = iPixel._luminance;
  const PixelXYZ<T> XYZ = PixelRGB<T>(l,l,l);
  *this = XYZ;
}

//  CIE Lab <= RGB
template<typename T>
inline 
PixelLab<T>::PixelLab(const PixelRGB<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  CIE Lab <= RGBA
template<typename T>
inline 
PixelLab<T>::PixelLab(const PixelRGBA<T>& iPixel)
{
  const PixelRGB<T> RGB = iPixel;
  const PixelXYZ<T> XYZ = RGB;
  *this = XYZ;
}


//  CIE Lab <= HLS
template<typename T>
inline 
PixelLab<T>::PixelLab(const PixelHLS<T>& iPixel)
{
  const PixelRGB<T> rgb = iPixel;
  *this = rgb;
}

//  CIE Lab <= CIE Luv
template<typename T>
inline 
PixelLab<T>::PixelLab(const PixelLuv<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  CIE Lab <= Hunter Lab
template<typename T>
inline 
PixelLab<T>::PixelLab(const PixelHLab<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Indirect CIE Lch <= RGB, HLS, CIE XYZ, CIE Luv, Hunter Lab
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//  CIE Lch <= RGB
template<typename T>
inline 
PixelLch<T>::PixelLch(const PixelRGB<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  CIE Lch <= HLS
template<typename T>
inline 
PixelLch<T>::PixelLch(const PixelHLS<T>& iPixel)
{
  const PixelRGB<T> rgb = iPixel;
  *this = rgb;
}

//  CIE Lch <= CIE XYZ
template<typename T>
inline 
PixelLch<T>::PixelLch(const PixelXYZ<T>& iPixel)
{
  const PixelLab<T> Lab = iPixel;
  *this = Lab;
}

//  CIE Lch <= CIE Luv
template<typename T>
inline 
PixelLch<T>::PixelLch(const PixelLuv<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  CIE Lch <= Hunter Lab
template<typename T>
inline 
PixelLch<T>::PixelLch(const PixelHLab<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Indirect Hunter Lab <= RGB, HLS, CIE Lab, CIE Luv, CIE Lch
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//  Hunter Lab <= RGB
template<typename T>
inline 
PixelHLab<T>::PixelHLab(const PixelRGB<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  Hunter Lab <= HLS
template<typename T>
inline 
PixelHLab<T>::PixelHLab(const PixelHLS<T>& iPixel)
{
  const PixelRGB<T> rgb = iPixel;
  *this = rgb;
}

//  Hunter Lab <= CIE Lab
template<typename T>
inline 
PixelHLab<T>::PixelHLab(const PixelLab<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  Hunter Lab <= CIE Luv
template<typename T>
inline 
PixelHLab<T>::PixelHLab(const PixelLuv<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//  Hunter Lab <= CIE Lch
template<typename T>
inline 
PixelHLab<T>::PixelHLab(const PixelLch<T>& iPixel)
{
  const PixelXYZ<T> XYZ = iPixel;
  *this = XYZ;
}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                                 CIE luminance
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
/*
// from CIE Lab
//template <class Pixel> typename Pixel::type GetCIELuminance(const PixelLab& iPixel) { return iPixel._luminance; }

template<> typename PixelLabf::type GetCIELuminance(const PixelLabf& iPixel)
{ return iPixel._luminance; }

template<> double GetCIELuminance<double>(const PixelLab<double>&);


// from CIE Luv
template <typename T> inline
T GetCIELuminance(const PixelLuv<T>& iPixel) { return iPixel._luminance; }

template<> float GetCIELuminance<float>(const PixelLuv<float>&);
template<> double GetCIELuminance<double>(const PixelLuv<double>&);

// from CIE Lch
template <typename T> inline
T GetCIELuminance(const PixelLch<T>& iPixel) { return iPixel._luminance; }

template<> float GetCIELuminance<float>(const PixelLch<float>&);
template<> double GetCIELuminance<double>(const PixelLch<double>&);

// from CIE XYZ
template <typename T> inline
T GetCIELuminance(const PixelXYZ<T>& iPixel) { return iPixel._y; }

template<> float GetCIELuminance<float>(const PixelXYZ<float>&);
template<> double GetCIELuminance<double>(const PixelXYZ<double>&);

// from Hunter Lab 
template <typename T> inline
T GetCIELuminance(const PixelHLab<T>& iPixel) { return iPixel._luminance; }

template<> float GetCIELuminance<float>(const PixelHLab<float>&);
template<> double GetCIELuminance<double>(const PixelHLab<double>&);

// from L
template <typename T> inline
T GetCIELuminance(const PixelL<T>& iPixel) { return iPixel._luminance; }

template<> float GetCIELuminance<float>(const PixelL<float>&);
template<> double GetCIELuminance<double>(const PixelL<double>&);

// from LA
template <typename T>
T GetCIELuminance(const PixelLA<T>& iPixel) { return iPixel._luminance; }

template<> float GetCIELuminance<float>(const PixelLA<float>&);
template<> double GetCIELuminance<double>(const PixelLA<double>&);

// from RGB
template <typename T>
T GetCIELuminance(const PixelRGB<T>& iPixel) 
{ 
  const PixelLab<T> lab(iPixel);
  return lab._luminance; 
}

template<> float GetCIELuminance<float>(const PixelRGB<float>&);
template<> double GetCIELuminance<double>(const PixelRGB<double>&);

// from RGBA
template <typename T>
T GetCIELuminance(const PixelRGBA<T>& iPixel) 
{ 
  const PixelRGB<T> rgb(iPixel);
  const PixelLab<T> lab(rgb);
  return lab._luminance; 
}

template<> float GetCIELuminance<float>(const PixelRGBA<float>&);
template<> double GetCIELuminance<double>(const PixelRGBA<double>&);
*/

//----------------------------------------------------------------------------
//  GetLuminance : PixelRGB<uint8> specialization
//----------------------------------------------------------------------------
template<>
uint8 PixelRGB<uint8>::GetLuminance(EColorToGreyConversion iMethod) const
{
  switch(iMethod)
  {
    case CGC_Green: // L=G
      return _green;

    case CGC_Mean: // L = (r+g+b)/3
      return (uint8)( ((uint32)_red + (uint32)_green + (uint32)_blue)/3UL );

    case CGC_Desaturate: // L = (min(r,g,b) + max(r,g,b))/2
      {
        uint8 Min, Max;
        if (_red < _green) {	
          Min = _red; Max = _green;
        } else {	
          Min = _green; Max = _red;
        }
        if (_blue < Min) Min = _blue;
        if (_blue > Max) Max = _blue;

        return (uint8)(((uint16)Min + (uint16)Max)/2);
      }

    case CGC_CCIR_601: // L = 0.2989*r + 0.5866*g + 0.1145*b
      return (uint8)( ((uint32)_red*2989UL + (uint32)_green*5866UL + (uint32)_blue*1145UL)/10000UL );

    case CGC_CCIR_709: // L = 0.2125*r + 0.7154*g + 0.0721*b
      return (uint8)( ((uint32)_red*2125UL + (uint32)_green*7154UL + (uint32)_blue*0721UL)/10000UL );

    case CGC_ITU: // L = 0.222*r  + 0.707*g  + 0.071*b
      return (uint8)( ((uint32)_red*222UL + (uint32)_green*707UL + (uint32)_blue*071UL)/1000UL );
		
    default: 
      return _green;
  }
  return _green;

} // GetLuminance # PixelRGB<uint8>

//----------------------------------------------------------------------------
//  GetLuminance : PixelRGB<uint16> specialization
//----------------------------------------------------------------------------
template<>
uint16 PixelRGB<uint16>::GetLuminance(EColorToGreyConversion iMethod) const
{
  switch(iMethod)
  {
    case CGC_Green: // L=G
      return _green;

    case CGC_Mean: // L = (r+g+b)/3
      return (uint16)( ((uint32)_red + (uint32)_green + (uint32)_blue)/3UL );

    case CGC_Desaturate: // L = (min(r,g,b) + max(r,g,b))/2
      {
        uint16 Min, Max;
        if (_red < _green) {	
          Min = _red; Max = _green;
        } else {	
          Min = _green; Max = _red;
        }
        if (_blue < Min) Min = _blue;
        if (_blue > Max) Max = _blue;

        return (uint16)(((uint16)Min + (uint16)Max)/2);
      }

    case CGC_CCIR_601: // L = 0.2989*r + 0.5866*g + 0.1145*b
      return (uint16)( ((uint32)_red*2989UL + (uint32)_green*5866UL + (uint32)_blue*1145UL)/10000UL );

    case CGC_CCIR_709: // L = 0.2125*r + 0.7154*g + 0.0721*b
      return (uint16)( ((uint32)_red*2125UL + (uint32)_green*7154UL + (uint32)_blue*0721UL)/10000UL );

    case CGC_ITU: // L = 0.222*r  + 0.707*g  + 0.071*b
      return (uint16)( ((uint32)_red*222UL + (uint32)_green*707UL + (uint32)_blue*071UL)/1000UL );
		
    default: 
      return _green;
  }
  return _green;

} // GetLuminance # PixelRGB<uint16>

//----------------------------------------------------------------------------
//  GetLuminance : PixelRGB<int32> specialization
//----------------------------------------------------------------------------
template<>
int32 PixelRGB<int32>::GetLuminance(EColorToGreyConversion iMethod) const
{
  switch(iMethod)
  {
    case CGC_Green: // L=G
      return _green;

    case CGC_Mean: // L = (r+g+b)/3
      return (int32)( ((int64)_red + (int64)_green + (int64)_blue)/3UL );

    case CGC_Desaturate: // L = (min(r,g,b) + max(r,g,b))/2
      {
        int32 Min, Max;
        if (_red < _green) {	
          Min = _red; Max = _green;
        } else {	
          Min = _green; Max = _red;
        }
        if (_blue < Min) Min = _blue;
        if (_blue > Max) Max = _blue;

        return (int32)(((int64)Min + (int64)Max)/2);
      }

    case CGC_CCIR_601: // L = 0.2989*r + 0.5866*g + 0.1145*b
      return (int32)( ((int64)_red*2989UL + (int64)_green*5866UL + (int64)_blue*1145UL)/10000UL );

    case CGC_CCIR_709: // L = 0.2125*r + 0.7154*g + 0.0721*b
      return (int32)( ((int64)_red*2125UL + (int64)_green*7154UL + (int64)_blue*0721UL)/10000UL );

    case CGC_ITU: // L = 0.222*r  + 0.707*g  + 0.071*b
      return (int32)( ((int64)_red*222UL + (int64)_green*707UL + (int64)_blue*071UL)/1000UL );
		
    default: 
      return _green;
  }
  return _green;

} // GetLuminance # PixelRGB<int32>


//----------------------------------------------------------------------------
//  GetLuminance : PixelRGBA<uint8> specialization
//----------------------------------------------------------------------------
template<>
uint8 PixelRGBA<uint8>::GetLuminance(EColorToGreyConversion iMethod) const
{
  switch(iMethod)
  {
    case CGC_Green: // L=G
      return _green;

    case CGC_Mean: // L = (r+g+b)/3
      return (uint8)( ((uint32)_red + (uint32)_green + (uint32)_blue)/3UL );

    case CGC_Desaturate: // L = (min(r,g,b) + max(r,g,b))/2
      {
        uint8 Min, Max;
        if (_red < _green) {	
          Min = _red; Max = _green;
        } else {	
          Min = _green; Max = _red;
        }
        if (_blue < Min) Min = _blue;
        if (_blue > Max) Max = _blue;

        return (uint8)(((uint16)Min + (uint16)Max)/2);
      }

    case CGC_CCIR_601: // L = 0.2989*r + 0.5866*g + 0.1145*b
      return (uint8)( ((uint32)_red*2989UL + (uint32)_green*5866UL + (uint32)_blue*1145UL)/10000UL );

    case CGC_CCIR_709: // L = 0.2125*r + 0.7154*g + 0.0721*b
      return (uint8)( ((uint32)_red*2125UL + (uint32)_green*7154UL + (uint32)_blue*0721UL)/10000UL );

    case CGC_ITU: // L = 0.222*r  + 0.707*g  + 0.071*b
      return (uint8)( ((uint32)_red*222UL + (uint32)_green*707UL + (uint32)_blue*071UL)/1000UL );
		
    default: 
      return _green;
  }
  return _green;

} // GetLuminance # PixelRGBA<uint8>

//----------------------------------------------------------------------------
//  GetLuminance : PixelRGBA<uint16> specialization
//----------------------------------------------------------------------------
template<>
uint16 PixelRGBA<uint16>::GetLuminance(EColorToGreyConversion iMethod) const
{
  switch(iMethod)
  {
    case CGC_Green: // L=G
      return _green;

    case CGC_Mean: // L = (r+g+b)/3
      return (uint16)( ((uint32)_red + (uint32)_green + (uint32)_blue)/3UL );

    case CGC_Desaturate: // L = (min(r,g,b) + max(r,g,b))/2
      {
        uint16 Min, Max;
        if (_red < _green) {	
          Min = _red; Max = _green;
        } else {	
          Min = _green; Max = _red;
        }
        if (_blue < Min) Min = _blue;
        if (_blue > Max) Max = _blue;

        return (uint16)(((uint16)Min + (uint16)Max)/2);
      }

    case CGC_CCIR_601: // L = 0.2989*r + 0.5866*g + 0.1145*b
      return (uint16)( ((uint32)_red*2989UL + (uint32)_green*5866UL + (uint32)_blue*1145UL)/10000UL );

    case CGC_CCIR_709: // L = 0.2125*r + 0.7154*g + 0.0721*b
      return (uint16)( ((uint32)_red*2125UL + (uint32)_green*7154UL + (uint32)_blue*0721UL)/10000UL );

    case CGC_ITU: // L = 0.222*r  + 0.707*g  + 0.071*b
      return (uint16)( ((uint32)_red*222UL + (uint32)_green*707UL + (uint32)_blue*071UL)/1000UL );
		
    default: 
      return _green;
  }
  return _green;

} // GetLuminance # PixelRGBA<uint16>


//----------------------------------------------------------------------------
//  GetLuminance : PixelRGBA<int32> specialization
//----------------------------------------------------------------------------
template<>
int32 PixelRGBA<int32>::GetLuminance(EColorToGreyConversion iMethod) const
{
  switch(iMethod)
  {
    case CGC_Green: // L=G
      return _green;

    case CGC_Mean: // L = (r+g+b)/3
      return (int32)( ((int64)_red + (int64)_green + (int64)_blue)/3UL );

    case CGC_Desaturate: // L = (min(r,g,b) + max(r,g,b))/2
      {
        int32 Min, Max;
        if (_red < _green) {	
          Min = _red; Max = _green;
        } else {	
          Min = _green; Max = _red;
        }
        if (_blue < Min) Min = _blue;
        if (_blue > Max) Max = _blue;

        return (int32)(((int64)Min + (int64)Max)/2);
      }

    case CGC_CCIR_601: // L = 0.2989*r + 0.5866*g + 0.1145*b
      return (int32)( ((int64)_red*2989UL + (int64)_green*5866UL + (int64)_blue*1145UL)/10000UL );

    case CGC_CCIR_709: // L = 0.2125*r + 0.7154*g + 0.0721*b
      return (int32)( ((int64)_red*2125UL + (int64)_green*7154UL + (int64)_blue*0721UL)/10000UL );

    case CGC_ITU: // L = 0.222*r  + 0.707*g  + 0.071*b
      return (int32)( ((int64)_red*222UL + (int64)_green*707UL + (int64)_blue*071UL)/1000UL );
		
    default: 
      return _green;
  }
  return _green;

} // GetLuminance # PixelRGBA<int32>

//----------------------------------------------------------------------------
//  explicit instanciations
//----------------------------------------------------------------------------
//  All supported pixel formats
//  compilation error should be generated with unsupported resolution
//----------------------------------------------------------------------------
template<> PixelL<uint8 >::PixelL() {}
template<> PixelL<uint16>::PixelL() {}
template<> PixelL<int32 >::PixelL() {}
template<> PixelL<float >::PixelL() {}
template<> PixelL<double>::PixelL() {}

template<> PixelLA<uint8 >::PixelLA() {}
template<> PixelLA<uint16>::PixelLA() {}
template<> PixelLA<int32 >::PixelLA() {}
template<> PixelLA<float >::PixelLA() {}
template<> PixelLA<double>::PixelLA() {}

template<> PixelComplex<int32 >::PixelComplex() {}
template<> PixelComplex<float >::PixelComplex() {}
template<> PixelComplex<double>::PixelComplex() {}

} // namespace Image
} // namespace eLynx
