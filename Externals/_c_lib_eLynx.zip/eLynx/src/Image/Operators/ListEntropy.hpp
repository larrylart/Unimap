//============================================================================
//  Operators/ListEntropy.hpp                          Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Operators_ListEntropy_hpp__
#define __Operators_ListEntropy_hpp__

namespace eLynx {
namespace Image {

namespace {
//----------------------------------------------------------------------------
//  WeightedEntropyTask
//----------------------------------------------------------------------------
template <typename Pixel>
struct WeightedEntropyTask : public IterationRangeTask
{
  typedef typename Pixel::type T;
  typedef typename Pixel::F_type F;
  typedef uint32 HistogramType;

  // initial constructor
  WeightedEntropyTask(Pixel * oprDst,
      const std::vector< const ImageImpl<Pixel>* >& iImageList, 
      int32 iW, int32 iH, 
      int32 iScale, 
      const F * iprNormScale, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _prDst(oprDst),
    _ImageList(iImageList), 
    _W(iW), _H(iH),
    _Scale(iScale),
    _prNormScale(iprNormScale)
  {} 
  
  // split constructor
  WeightedEntropyTask(
      const WeightedEntropyTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prDst(iOther._prDst),
    _ImageList(iOther._ImageList), 
    _W(iOther._W), _H(iOther._H),
    _Scale(iOther._Scale),
    _prNormScale(iOther._prNormScale)
  {}  

  uint32 operator ()()
  {
    const std::vector< const ImageImpl<Pixel>* >& imageList = _ImageList;
    const int32 scale = _Scale;  
    const F * prNormScale = _prNormScale;
    
    const int32 begin = (int32)_begin;
    const int32 end = (int32)_end;
    const size_t size = imageList.size();
    const int32 w = (int32)imageList[0]->GetWidth();
    const int32 h = (int32)imageList[0]->GetHeight();
    const uint32 channels = Pixel::GetChannelCount();
    const int32 windowW = _W;
    const int32 halfW = (int32)windowW / 2;
    const int32 windowH = _H;
    const int32 halfH = (int32)windowH / 2;
    const uint32 histogramSize = uint32(size)*channels*scale*sizeof(HistogramType);
    const F constLog1 = F(1.f) / (Math::elxLog(F(2.f)) * windowW * windowH);
    const F constLog2 = Math::elxLog(F(1)/F(windowW * windowH)); 
         
    boost::scoped_array<const Pixel*> spInitialArray( new const Pixel* [size] );
    if (NULL == spInitialArray.get()) return elxErrOutOfMemory;

    boost::scoped_array<HistogramType> 
      spHistogram( new HistogramType [size * scale * channels] );
    if (NULL == spHistogram.get()) return elxErrOutOfMemory;

    boost::scoped_array<HistogramType> 
      spHistogramSave( new HistogramType [size * scale * channels] );
    if (NULL == spHistogramSave.get()) return elxErrOutOfMemory;
     
    // --- init sources and destination
    size_t i;
    for (i=0; i<size; i++)
       spInitialArray[i] = imageList[i]->GetPixel()+ begin*w;
    Pixel * prDst = _prDst + begin*w;
  
    // --- inits progress ---
    const float ProgressStep = 1 / (float)h;
    float Progress = 0.0f;
    ProgressNotifier& notifier = _notifier; 
    notifier.SetProgress(Progress);
  
    int32 j, k, x, y, histIdx, currentX, currentY;
    uint32 l;
    bool inImageY, inImageX;
    F weightSum[PC_MAX], entropySum[PC_MAX], entropy;
    
    for (y=begin; y<end; ++y)
    {
      if (y != begin)
      {
        // The histogam centered at (0,y) pixel = histogam centered at (0,y-1)
        // minus first row from the previous histogram (at y-1-halfH) 
        // plus last row (y+halsfH) of current
        currentY = y - 1 - halfH;
        inImageY = (y >= 1 + halfH);
        for (k = 0; k < windowW; ++k)
        {
          currentX = k - halfW;
          inImageX = !(currentX < 0 || currentX > w-1);

          inImageY = (inImageX) ? (y >= 1 + halfH) : false;        
          if (inImageY) 
          {
            for (i=0; i<size; i++)
            {
              for (l = 0; l < channels; ++l)
              {
                histIdx = (HistogramType)(
                  (spInitialArray[i]-(1+halfH)*w + currentX)->_channel[l]  *
                    prNormScale[i * channels + l]);
                --spHistogramSave[i*channels*scale + l*scale + histIdx];
              }
            }
          }
          else
            // out-of-image value is 0 (Black)
            for (i=0; i<size; i++)
              for (l = 0; l < channels; ++l)
                --spHistogramSave[i * channels * scale + l * scale];

          //add bottom window row for pixel (0,y) 
          inImageY = (inImageX) ? (y + halfH) < h : false;        
          if (inImageY) 
          {
            for (i=0; i<size; i++)
              for (l=0; l<channels; l++)
              {
                histIdx = (HistogramType)(
                  (spInitialArray[i]+halfH*w + currentX)->_channel[l]  *
                    prNormScale[i * channels + l]);
                ++spHistogramSave[i*channels*scale + l*scale + histIdx];
              }
          }
          else
            // out-of-image value is 0 (Black)
            for (i=0; i<size; i++)
              for (l=0; l<channels; l++)
                ++spHistogramSave[i * channels * scale + l * scale];
        }

        // copy it 
        ::memcpy(spHistogram.get(), spHistogramSave.get(), histogramSize);          
      }
      else
      {
        //First time compute the full histogram for entire window at (0,begin)
        ::memset(spHistogram.get(), 0, histogramSize);

        for (j = 0; j < windowH; ++j)
        {
          currentY = y + j - halfH;
          inImageY = !(currentY < 0 || currentY > h-1);
          for (k = 0; k < windowW; ++k)
          {
            if (inImageY)
            {
              currentX = k - halfW;
              inImageX = !(currentX < 0 || currentX > w-1);
            }
            else
              inImageX = false;

            if (inImageX) 
            {
              for (i=0; i<size; i++)
              {
                for (l = 0; l < channels; ++l)
                {
                  histIdx = (HistogramType)(
                    (spInitialArray[i]+(currentY-y)*w + currentX)->_channel[l] *
                      prNormScale[i * channels + l]);
                  ++spHistogram[i*channels*scale + l*scale + histIdx];
                }
              }
            }
            else
              // out-of-image value is 0 (Black)
              for (i=0; i<size; i++)
                for (l = 0; l < channels; ++l)
                  ++spHistogram[i*channels*scale + l*scale];
          }
        }
        // need to save it to calculate histogram for the next row
        ::memcpy(spHistogramSave.get(), spHistogram.get(), histogramSize);    
      }

      // process a horizontal row      
      for(x = 0; x < w; ++x, ++prDst)
      {  
        if( x != 0)
        {      
          // The histogam centered at (x,y) pixel = histogam centered at (x-1,y)
          // minus first column from the previous histogram (at x-1-halfW) 
          // plus last column (x+halsfW) of current
          for (j = 0; j < windowH; ++j)
          {
            currentY = y + (j - halfH);
            inImageY = !(currentY < 0 || currentY > h-1);

            //substract left column for (x-1, y) pixel
            inImageX = (inImageY) ? halfW + 1 <= x : false;
            if (inImageX) 
            {
              for (i=0; i<size; i++)
              {
                for (l = 0; l < channels; ++l)
                {
                  histIdx = (HistogramType)(
                    (spInitialArray[i]+(currentY -y)*w - halfW - 1)->_channel[l]*
                      prNormScale[i*channels + l]);

                  --spHistogram[i*channels*scale + l*scale + histIdx];
                }
              }
            }
            else
              // out-of-image value is 0 (Black)
              for (i=0; i<size; i++)
                for (l = 0; l < channels; ++l)
                  --spHistogram[i * channels * scale + l * scale];

            //add rigth column for (x1, y) pixel
            inImageX = (inImageY) ? x + halfW < w : false;
            if (inImageX) 
            {
              for (i=0; i<size; i++)
              {
                for (l = 0; l < channels; ++l)
                {
                  histIdx = (HistogramType)(
                    (spInitialArray[i]+(currentY -y)*w + halfW)->_channel[l]  *
                      prNormScale[i * channels + l]);

                  ++spHistogram[i*channels*scale + l*scale + histIdx];
                }
              }
            }
            else
              // out-of-image value is 0 (Black)
              for (i=0; i<size; i++)
                for (l = 0; l < channels; ++l)
                  ++spHistogram[i*channels*scale + l*scale];
          }
        }

        for (l = 0; l < channels; ++l)
        {
         weightSum[l] = entropySum[l] = 0;
         for (i=0; i<size; i++)
          { 
            entropy = 0.f;
            for (j=0; j<scale; ++j)
            {          
              histIdx =  int32(i) * channels * scale + l * scale + j;       
              if (spHistogram[histIdx] == 0)
                continue;

              entropy -= constLog1 * spHistogram[histIdx] *
                (Math::elxLog((F)spHistogram[histIdx]) + constLog2);
            } 
            entropySum[l] += entropy;
            weightSum[l] += entropy * (spInitialArray[i]->_channel[l]); 
          } 

          // calculate weighted average and save final mean pixel at (x,y)
          prDst->_channel[l] = (entropySum[l] != 0) ?
            ResolutionTypeTraits<T>::ClampF( weightSum[l]/entropySum[l] ) :
            ResolutionTypeTraits<T>::ClampF( weightSum[l] );
        }

        // move to the next pixel
        for (i=0; i<size; i++)
          ++spInitialArray[i];

        // --- in progress ... ---
        if (x == w-1)
        {
          Progress += ProgressStep;
          notifier.SetProgress(Progress);
        }
      }
    }

    notifier.SetProgress(1.0f);
    return elxOK;
  } 

private:  
  Pixel * _prDst;
  const std::vector< const ImageImpl<Pixel>* >& _ImageList; 
  int32 _W, _H, _Scale;
  const F * _prNormScale;
};

template<typename Pixel>
struct NormScaleTask
{
  typedef typename Pixel::type T;
  typedef typename Pixel::F_type F;
  
  // initial constructor
  NormScaleTask(const std::vector< const ImageImpl<Pixel>* >& iImageList, 
    int32 iScale, F * oprNormScale) :
    _ImageList(iImageList), 
    _begin(0), 
    _end(0),
    _Scale(iScale), 
    _prNormScale(oprNormScale)
  {}
    
  // split constructor
  NormScaleTask(const NormScaleTask& iOther, const IterationRange& iRange) :
    _ImageList(iOther._ImageList),
    _begin( (uint32)iRange.GetBegin() ), 
    _end( (uint32)iRange.GetEnd() ),
    _Scale(iOther._Scale), 
    _prNormScale(iOther._prNormScale)
  {}
    
  uint32 operator ()()
  {
    const uint32 begin = _begin;
    const uint32 end = _end;
    const uint32 channels = Pixel::GetChannelCount();
    const std::vector< const ImageImpl<Pixel>* >& imageList = _ImageList;
    const int32 scale = _Scale;  
    F * prNormScale = _prNormScale;
    T max[PC_MAX];
    
    for (uint32 i=begin; i<end; i++)
    {
      Math::elxMax(
        imageList[i]->GetSamples(), 
        imageList[i]->GetSampleCount(), 
        channels, max);

      for (uint32 l=0; l< channels; ++l)
        prNormScale[i*channels + l] = (max[l] > 0) ? 
          (F)(scale - 1) / (F)max[l] : F(1.f);
    }
    return elxOK;
  }

private:  
  const std::vector< const ImageImpl<Pixel>* >& _ImageList;
  uint32 _begin, _end;
  int32 _Scale;  
  F * _prNormScale; 
};

} // anonymous-namespace

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Create image from ImageImpl<Pixel> list using Entropy
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr< ImageImpl<Pixel> > 
  elxCreateWeightedEntropy(
    const std::vector< const ImageImpl<Pixel>* >& iImageList,
    uint32 iW, uint32 iH, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  typedef typename Pixel::type T;
  typedef typename Pixel::F_type F;
  typedef uint32 HistogramType;

  const size_t size = iImageList.size();
  elxASSERT(size != 0);
  const uint32 channels = Pixel::GetChannelCount();
  const int32 scale = 512;  
  const int32 w = (int32)iImageList[0]->GetWidth();
  const int32 h = (int32)iImageList[0]->GetHeight();
  iW = Math::elxMin(iW, (uint32)w);
  iH = Math::elxMin(iH, (uint32)h);
  const int32 windowW = (iW&1)? (int32)iW : (int32)(iW+1);
  const int32 windowH = (iH&1)? (int32)iH : (int32)(iH+1);
  
  // create output image
  boost::shared_ptr< ImageImpl<Pixel> > spImage( new ImageImpl<Pixel>(w,h) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();
    
  // Allocated temp arrays
  boost::scoped_array<F> spNormScale ( new F[size * channels]);
  if (NULL == spNormScale.get())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // --- initialize scale
  NormScaleTask<Pixel> scaleTask(iImageList, scale, spNormScale.get());

  if (elxOK != elxParallelFor(
      IterationRange(0, (size_t)size), scaleTask))
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // --- Create Weighted task
  WeightedEntropyTask<Pixel> task(spImage->GetPixel(), iImageList, 
    windowW, windowH, scale, spNormScale.get(), iNotifier);

  // --- Run process in parallel
  if (elxOK != elxParallelFor(
      IterationRange(0, (size_t)h), task))
    return boost::shared_ptr< ImageImpl<Pixel> >();
    
  return spImage;

} // elxCreateWeightedEntropy

} // namespace Image
} // namespace eLynx

#endif // __Operators_ListEntropy_hpp__
