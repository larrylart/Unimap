//============================================================================
//  Operators/Image.hpp                                Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Operator_Image_hpp__
#define __Operator_Image_hpp__

#include <elx/math/MathCore.h>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Operator with another image with same size
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageOperatorsImpl<Pixel>::Operator(
    ImageImpl<Pixel>& ioImage,
    EImageOperator iOperator, 
    const ImageImpl<Pixel>& iImage,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid() || !iImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;

  // check images size
  if ((ioImage.GetWidth() != iImage.GetWidth()) ||
      (ioImage.GetHeight() != iImage.GetHeight()))
    return false;

  const Pixel * prSrc = iImage.GetPixel();
  Pixel * prDst = ioImage.GetPixel();
  Pixel * prEnd = ioImage.GetPixelEnd();
  if (Pixel::IsFullMask(iChannelMask))
  {
    // speed up if no channel mask used
    switch (iOperator)
    {
      case IOP_Set: // copy iImage into ioImage
        // @TODO optimize with memcpy
        do { *prDst = *prSrc; } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Add:
        do { *prDst = elxPixelAdd(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Sub:
        do { *prDst = elxPixelSub(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mul:
        do { *prDst = elxPixelMul(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_AddClamp:
        do { *prDst = elxPixelAddClamp(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_SubClamp:
        do { *prDst = elxPixelSubClamp(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_MulClamp:
        do { *prDst = elxPixelMulClamp(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Div:
        do { *prDst = elxPixelDiv(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Dif:
        do { *prDst = elxPixelAbsDiff(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Min:
        do { *prDst = elxPixelMin(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Max:
        do { *prDst = elxPixelMax(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mean:
      case IOP_Median:
        do { *prDst = elxPixelMean(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;
        
      default:
        return false;
    }
  }
  else
  {
    // channel masking is slower
    switch (iOperator)
    {
      case IOP_Set: // copy iImage into ioImage
        elxFIXME;       
        return true;
    
      case IOP_Add:
        do { *prDst = elxPixelAdd(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Sub:
        do { *prDst = elxPixelSub(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mul:
        do { *prDst = elxPixelMul(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Div:
        do { *prDst = elxPixelDiv(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Dif:
        do { *prDst = elxPixelAbsDiff(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Min:
        do { *prDst = elxPixelMin(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Max:
        do { *prDst = elxPixelMax(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mean:
      case IOP_Median:
        do { *prDst = elxPixelMean(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      default:
        return false;
    }
  }
  return false;

} // Operator



//----------------------------------------------------------------------------
//  Operator with another image with same size
//----------------------------------------------------------------------------
template <class Pixel>
bool elxOperator(
    ImageImpl<Pixel>& ioImage,
    EImageOperator iOperator, 
    const ImageImpl<Pixel>& iImage,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid() || !iImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;

  // check images size
  if ((ioImage.GetWidth() != iImage.GetWidth()) ||
      (ioImage.GetHeight() != iImage.GetHeight()))
    return false;

  const Pixel * prSrc = iImage.GetPixel();
  Pixel * prDst = ioImage.GetPixel();
  Pixel * prEnd = ioImage.GetPixelEnd();

  if (Pixel::IsFullMask(iChannelMask))
  {
    // speed up if no channel mask used
    switch (iOperator)
    {
      case IOP_Set: // copy iImage into ioImage
        // @TODO optimize with memcpy
        do { *prDst = *prSrc; } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Add:
        do { *prDst = elxPixelAdd(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Sub:
        do { *prDst = elxPixelSub(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mul:
        do { *prDst = elxPixelMul(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_AddClamp:
        do { *prDst = elxPixelAddClamp(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_SubClamp:
        do { *prDst = elxPixelSubClamp(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_SubAbsClamp:
        do { *prDst = elxPixelSubAbsClamp(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_MulClamp:
        do { *prDst = elxPixelMulClamp(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Div:
        do { *prDst = elxPixelDiv(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Dif:
        do { *prDst = elxPixelAbsDiff(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Min:
        do { *prDst = elxPixelMin(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Max:
        do { *prDst = elxPixelMax(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mean:
      case IOP_Median:
        do { *prDst = elxPixelMean(*prDst, *prSrc); } while (++prSrc, ++prDst != prEnd);
        return true;
        
      default:
        return false;
    }
  }
  else
  {
    // channel masking is slower
    switch (iOperator)
    {
      case IOP_Set: // copy iImage into ioImage
        elxFIXME;       
        return true;
    
      case IOP_Add:
        do { *prDst = elxPixelAdd(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Sub:
        do { *prDst = elxPixelSub(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mul:
        do { *prDst = elxPixelMul(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Div:
        do { *prDst = elxPixelDiv(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Dif:
        do { *prDst = elxPixelAbsDiff(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Min:
        do { *prDst = elxPixelMin(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Max:
        do { *prDst = elxPixelMax(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mean:
      case IOP_Median:
        do { *prDst = elxPixelMean(*prDst, *prSrc, iChannelMask); } while (++prSrc, ++prDst != prEnd);
        return true;

      default:
        return false;
    }
  }
  return false;

} // elxOperator


//----------------------------------------------------------------------------
//  Operator with another image with same size, using a image mask
//----------------------------------------------------------------------------
template <class Pixel>
bool elxOperator(ImageImpl<Pixel>& ioImage,
    EImageOperator iOperator, 
    const ImageImpl<Pixel>& iImage,
    const ImageLub& iImageMask,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid() || !iImage.IsValid() || !iImageMask.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();

  // check images size
  if ((w != iImage.GetWidth()) || (h != iImage.GetHeight()) ||
      (w != iImageMask.GetWidth()) || (h != iImageMask.GetHeight()))
    return false;

  const Pixel * prSrc = iImage.GetPixel();
  Pixel * prDst = ioImage.GetPixel();
  Pixel * prEnd = ioImage.GetPixelEnd();

  const uint8 * prMask = iImageMask.GetSamples();
  if (Pixel::IsFullMask(iChannelMask))
  {
    // speed up if no channel mask used
    switch (iOperator)
    {
      case IOP_Set: // copy iImage into ioImage
        // @TODO optimize with memcpy
        do { if (*prMask) *prDst = *prSrc; } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Add:
        do 
        { 
          if (*prMask) 
            *prDst = elxPixelAdd(*prDst, *prSrc); 
          else
            *prDst = *prSrc;
        } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Sub:
        do 
        { 
          if (*prMask) 
            *prDst = elxPixelSub(*prDst, *prSrc); 
          else
            *prDst = *prSrc;
        } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mul:
        do 
        { 
          if (*prMask) 
            *prDst = elxPixelMul(*prDst, *prSrc); 
          else
            *prDst = *prSrc;
        } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_AddClamp:
        do 
        { 
          if (*prMask) 
            *prDst = elxPixelAddClamp(*prDst, *prSrc); 
          else
            *prDst = *prSrc;
        } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_SubClamp:
        do 
        { 
          if (*prMask) 
            *prDst = elxPixelSubClamp(*prDst, *prSrc);
          else
            *prDst = *prSrc;
        } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_MulClamp:
        do 
        { 
          if (*prMask) 
            *prDst = elxPixelMulClamp(*prDst, *prSrc);
          else
            *prDst = *prSrc;
        } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Div:
        do 
        { 
          if (*prMask) 
            *prDst = elxPixelDiv(*prDst, *prSrc);
          else
            *prDst = *prSrc;
        } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Dif:
        do 
        { 
          if (*prMask) 
            *prDst = elxPixelAbsDiff(*prDst, *prSrc);
          else
            *prDst = *prSrc;
        } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Min:
        do 
        { 
          if (*prMask) 
            *prDst = elxPixelMin(*prDst, *prSrc);
          else
            *prDst = *prSrc;
        } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Max:
        do 
        { 
          if (*prMask) 
            *prDst = elxPixelMax(*prDst, *prSrc);
          else
            *prDst = *prSrc;
        } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mean:
      case IOP_Median:
        do 
        { 
          if (*prMask) 
            *prDst = elxPixelMean(*prDst, *prSrc);
          else
            *prDst = *prSrc;
        } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;
        
      default:
        return false;
    }
  }
  else
  {
    // channel masking is slower
    switch (iOperator)
    {
      case IOP_Set: // copy iImage into ioImage
        elxFIXME;       
        return true;
    
      case IOP_Add:
        do { if (*prMask) *prDst = elxPixelAdd(*prDst, *prSrc, iChannelMask); } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Sub:
        do { if (*prMask) *prDst = elxPixelSub(*prDst, *prSrc, iChannelMask); } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mul:
        do { if (*prMask) *prDst = elxPixelMul(*prDst, *prSrc, iChannelMask); } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Div:
        do { if (*prMask) *prDst = elxPixelDiv(*prDst, *prSrc, iChannelMask); } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Dif:
        do { if (*prMask) *prDst = elxPixelAbsDiff(*prDst, *prSrc, iChannelMask); } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Min:
        do { if (*prMask) *prDst = elxPixelMin(*prDst, *prSrc, iChannelMask); } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Max:
        do { if (*prMask) *prDst = elxPixelMax(*prDst, *prSrc, iChannelMask); } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      case IOP_Mean:
      case IOP_Median:
        do { if (*prMask) *prDst = elxPixelMean(*prDst, *prSrc, iChannelMask); } 
        while (++prMask, ++prSrc, ++prDst != prEnd);
        return true;

      default:
        return false;
    }
  }
  return false;

} // elxOperator


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageOperators implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Operator with another image with same size & format
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageOperatorsImpl<Pixel>::Operator(
    AbstractImage& ioImage, 
    EImageOperator iOperator, 
    const AbstractImage& iImage,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  if (!ioImage.IsValid() || !iImage.IsValid())
    return false;

  ImageImpl<Pixel>& image1 = elxDowncast<Pixel>(ioImage);
  const ImageImpl<Pixel>& image2 = elxDowncast<Pixel>(iImage);
  return elxOperator(image1, iOperator, image2, iChannelMask, iNotifier);

} // Operator with image


//----------------------------------------------------------------------------
//  Operator with another image with same size & format using a image mask
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageOperatorsImpl<Pixel>::Operator(
    AbstractImage& ioImage, 
    EImageOperator iOperator, 
    const AbstractImage& iImage,
    const ImageLub& iImageMask,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  if (!ioImage.IsValid() || !iImage.IsValid() || !iImageMask.IsValid())
    return false;

  ImageImpl<Pixel>& image1 = elxDowncast<Pixel>(ioImage);
  const ImageImpl<Pixel>& image2 = elxDowncast<Pixel>(iImage);
  return elxOperator(image1, iOperator, image2, iImageMask, iChannelMask, iNotifier);

} // Operator with image and image mask


} // namespace Image
} // namespace eLynx

#endif // __Operator_Image_hpp__
