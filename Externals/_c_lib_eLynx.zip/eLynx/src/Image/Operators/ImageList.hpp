//============================================================================
// Operators/ImageList.hpp                             Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Operators_ImageList_hpp__
#define __Operators_ImageList_hpp__

namespace eLynx {
namespace Image {

namespace {

template <typename Pixel>
bool elxCheckImageList(
    const std::vector< const AbstractImage* >&iImageList,
    boost::shared_ptr< AbstractImage >& ispImage,
    std::vector< const ImageImpl<Pixel>* >& iSpecializedList)
{
  const size_t size = iImageList.size();
  if (0 == size)
  {
    ispImage.reset();
    return false;
  }

  if (1 == size)
  {
    // check format and return a copy of input image
    const ImageImpl<Pixel>& image = elxDowncast<Pixel>( *iImageList[0] );
    ispImage.reset(new ImageImpl<Pixel>(image));
    return false;
  }

  iSpecializedList.reserve(size);

  {
    const ImageImpl<Pixel>& image = elxDowncast<Pixel>( *iImageList[0] );
    iSpecializedList.push_back(&image);
  }

  // Check that all images are in Pixel format and have same dimensions
  // and build list of specialized images
  const uint32 w = iImageList[0]->GetWidth();
  const uint32 h = iImageList[0]->GetHeight();
  for(uint32 i=1; i<size; i++)
  {
    const ImageImpl<Pixel>& image = elxDowncast<Pixel>( *iImageList[i] );
    if (image.IsValid() && (image.GetWidth() == w) && (image.GetHeight() == h))
      iSpecializedList.push_back(&image);
    else
    {
      ispImage.reset();
      return false;
    }
  }
  return true;

} // elxCheckImageList

} // anonymous-namespace

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImagePointProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Operator with image list
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageOperatorsImpl<Pixel>::Operator(
    AbstractImage& ioImage, 
    EImageOperator iOperator, 
    const std::vector< const AbstractImage* >& iImageList,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  if (!ioImage.IsValid())
    return false;

    switch (iOperator)
    {
      case IOP_Set: break;
      case IOP_Neg: break;
      case IOP_Add: break;
      case IOP_Mul: break;
      case IOP_Min: break;
      case IOP_Max: break;
      case IOP_Mean:  
        return ImageOperatorsImpl<Pixel>::OperatorMean(
          ioImage, iImageList, iChannelMask, iNotifier);

      case IOP_Median:
        return ImageOperatorsImpl<Pixel>::OperatorMedian(
          ioImage, iImageList, iChannelMask, iNotifier);    

      default: 
        return false;
    }

  return false;
  
} // Operator

//----------------------------------------------------------------------------
//  Create image from operator and AbstractImage list
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr< AbstractImage > 
  ImageOperatorsImpl<Pixel>::CreateImage(
    EImageListOperator iOperator,
    const std::vector< const AbstractImage* >& iImageList,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  boost::shared_ptr< AbstractImage > spImage;
  std::vector< const ImageImpl<Pixel>* > SpecializedList;
  if (!elxCheckImageList<Pixel>(iImageList, spImage, SpecializedList))
    return spImage;
    
  switch (iOperator)
  {
    case ILO_Add:     return elxCreateSum(SpecializedList, iChannelMask, iNotifier);
    case ILO_Mul:     return elxCreateMul(SpecializedList, iChannelMask, iNotifier);
    case ILO_Min:     return elxCreateMin(SpecializedList, iChannelMask, iNotifier);
    case ILO_Max:     return elxCreateMax(SpecializedList, iChannelMask, iNotifier);
    case ILO_Mean:    return elxCreateMean(SpecializedList, iChannelMask, iNotifier);
    case ILO_Median:  return elxCreateMedian(SpecializedList, iChannelMask, iNotifier);
    default:
      break;
  }
  return boost::shared_ptr< AbstractImage >();

} // CreateImage


//----------------------------------------------------------------------------
//  Create mean image from the list
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageOperatorsImpl<Pixel>::OperatorMean(
    AbstractImage& oImage,
    const std::vector< const AbstractImage* >& iImageList,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  boost::shared_ptr< AbstractImage > spImage;
  std::vector< const ImageImpl<Pixel>* > SpecializedList;
  if (!elxCheckImageList<Pixel>(iImageList, spImage, SpecializedList))
    return false;

  boost::shared_ptr< ImageImpl<Pixel> > spMean = elxCreateMean(
    SpecializedList, iChannelMask, iNotifier);
    
  if (!spMean->IsValid())
    return false;

  ImageImpl<Pixel>& image = elxDowncast<Pixel>(oImage);
  image.CopyAndForget(spMean);
  
  return true;
}

//----------------------------------------------------------------------------
//  Median Operator with image list
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageOperatorsImpl<Pixel>::OperatorMedian(
    AbstractImage& oImage,
    const std::vector< const AbstractImage* >& iImageList,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  boost::shared_ptr< AbstractImage > spImage;
  std::vector< const ImageImpl<Pixel>* > SpecializedList;
  if (!elxCheckImageList<Pixel>(iImageList, spImage, SpecializedList))
    return false;

  boost::shared_ptr< ImageImpl<Pixel> > spMedian = elxCreateMedian(
    SpecializedList, iChannelMask, iNotifier);
    
  if (!spMedian->IsValid())
    return false;

  ImageImpl<Pixel>& image = elxDowncast<Pixel>(oImage);
  image.CopyAndForget(spMedian);
  
  return true;

} // OperatorMedian
 

//----------------------------------------------------------------------------
//  Create Clipped image from ImageImpl<Pixel> list
//----------------------------------------------------------------------------
template <template<class>  class ClipMethod, class Pixel>
boost::shared_ptr< ImageImpl<Pixel> > 
  elxCreateClipped(
    EImageListOperator iOperator,
    const std::vector< const ImageImpl<Pixel>* >& iImageList,
    uint32 iIteration, double iKappa, 
    uint32 iChannelMask, ProgressNotifier& iNotifier);


//----------------------------------------------------------------------------
//  Create clipped image from operator and AbstractImage list
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr< AbstractImage > 
  ImageOperatorsImpl<Pixel>::CreateClipped(
    EImageListOperator iOperator,
    const std::vector< const AbstractImage* >& iImageList,
    uint32 iIteration, double iKappa, 
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{  
  boost::shared_ptr< AbstractImage > spImage;
  std::vector< const ImageImpl<Pixel>* > SpecializedList;
  if (!elxCheckImageList<Pixel>(iImageList, spImage, SpecializedList))
    return spImage;

  return elxCreateClipped<Pixel>(iOperator,
    SpecializedList, iIteration, iKappa, iChannelMask, iNotifier);

} // CreateClipped


//----------------------------------------------------------------------------
//  Create image from ImageImpl<Pixel> list using Entropy
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr< ImageImpl<Pixel> > 
  elxCreateWeightedEntropy(
    const std::vector< const ImageImpl<Pixel>* >& iImageList,
    uint32 iW, uint32 iH, 
    uint32 iChannelMask, ProgressNotifier& iNotifier);


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageOperators implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Create clipped image from operator and AbstractImage list
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr< AbstractImage > 
ImageOperatorsImpl<Pixel>::CreateWeightedEntropy(
    const std::vector< const AbstractImage* >& iImageList,
    uint32 iW, uint32 iH, 
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{  
  boost::shared_ptr< AbstractImage > spImage;
  std::vector< const ImageImpl<Pixel>* > SpecializedList;
  if (!elxCheckImageList<Pixel>(iImageList, spImage, SpecializedList))
    return spImage;
    
  return elxCreateWeightedEntropy(SpecializedList, iW, iH, iChannelMask, iNotifier);
  
} // CreateWeightedEntropy
 
} // namespace Image
} // namespace eLynx

#endif // __Operators_ImageList_hpp__
