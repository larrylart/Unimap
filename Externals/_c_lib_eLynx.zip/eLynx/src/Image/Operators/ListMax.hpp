//============================================================================
//  Operators/ListMax.hpp                              Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Operators_ListMax_hpp__
#define __Operators_ListMax_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Create Min image from ImageImpl<Pixel> list
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr< ImageImpl<Pixel> > 
  elxCreateMax(
    const std::vector< const ImageImpl<Pixel>* >& iImageList,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  typedef typename Pixel::type T;

  size_t i;
  const size_t size = iImageList.size();
  if (0 == size)
    return boost::shared_ptr< ImageImpl<Pixel> >();

  if (1 == size)
  {
    // return a copy of input image
    return boost::shared_ptr< ImageImpl<Pixel> > (
      new ImageImpl<Pixel>( *iImageList[0] ) );
  }
 
  const uint32 w = iImageList[0]->GetWidth();
  const uint32 h = iImageList[0]->GetHeight();

  // check image size are all identical
  for (i=1; i<size; ++i)
  {
    if ((iImageList[i]->GetWidth() != w) || (iImageList[i]->GetHeight() != h))
      return boost::shared_ptr< ImageImpl<Pixel> >();
  }
  
  // create output image
  boost::shared_ptr< ImageImpl<Pixel> > spImage( new ImageImpl<Pixel>(w,h) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  std::vector< const T * > sampleList;
  sampleList.reserve(size);

  // --- initialize pixel start for all input images
  for (i=0; i<size; i++)
    sampleList.push_back( iImageList[i]->GetSamples() );

  // --- inits progress ---
  const uint32 ws = w * Pixel::GetChannelCount();
  const float ProgressStep = 1 / (float)h;
  float Progress = 0.0f;
  uint32 pixelProgress = ws;
  iNotifier.SetProgress(Progress);

  T * prDst = spImage->GetSamples();
  T * prEnd = spImage->GetSamplesEnd();
  T m;
  do
  {
    m = ResolutionTypeTraits<T>::_min;
    for (i=0; i<size; i++)
    {
      if (m < *sampleList[i])
        m = *sampleList[i];
      ++sampleList[i];
    }

    // save max
    *prDst = m;

    // --- in progress ... ---
    if (--pixelProgress == 0)
    {
      pixelProgress = ws;
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }
  }
  while (++prDst != prEnd);
  
  return spImage;

} // elxCreateMax

} // namespace Image
} // namespace eLynx

#endif // __Operators_ListMax_hpp__
