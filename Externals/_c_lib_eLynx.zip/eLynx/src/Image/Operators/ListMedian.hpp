//============================================================================
//  Operators/ListMedian.hpp                           Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Operators_ListMedian_hpp__
#define __Operators_ListMedian_hpp__

#include <elx/core/ParallelAlgorithms.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Create Median image from ImageImpl<Pixel> list
//----------------------------------------------------------------------------

namespace {
//----------------------------------------------------------------------------
//  MedianTask
//----------------------------------------------------------------------------
template <typename T>
struct MedianTask
{
  // initial constructor
  MedianTask(
      T * ipSample, 
      const T * const * iSampleList, 
      uint32 iSize, 
      uint32 iSortIncrement, 
      ProgressNotifier& iNotifier) :
    _prSample(ipSample), 
    _SampleList(iSampleList), 
    _Size(iSize),
    _SortIncrement(iSortIncrement), 
    _begin(0), 
    _end(0), 
    _notifier(iNotifier)
  {}
  
  // split constructor
  MedianTask(
      const MedianTask& iOther, 
      const IterationRange& iRange) :
    _prSample(iOther._prSample), 
    _SampleList(iOther._SampleList), 
    _Size(iOther._Size),
    _SortIncrement(iOther._SortIncrement), 
    _begin( (uint32)iRange.GetBegin() ),
    _end( (uint32)iRange.GetEnd() ),
    _notifier((iRange.IsLast() || iRange.IsAll()) ?
      iOther._notifier : ProgressNotifier_NULL)
  {}
  
  uint32 operator ()()
  {
    const uint32 size = _Size;
    const uint32 begin = _begin;
    const uint32 end = _end;
    const uint32 median = size / 2;
    const uint32 sortIncrement = _SortIncrement;
    const T * const* sampleList = _SampleList;
    T * prSample = _prSample;
    
    // --- inits progress ---
    const uint32 ProgressDisplayInterval = 1000;
    const float ProgressStep = 
      1.f / ((float)size/(float)ProgressDisplayInterval);
    float Progress = 0.0f;
    uint32 pixelProgress = ProgressDisplayInterval;
    ProgressNotifier& notifier = _notifier; 
    notifier.SetProgress(Progress);

    if (2 == size)
    {
      // no need to sort, just compute mean
      for (uint32 i = begin; i != end; ++i)
      {
        // save mean
        prSample[i] = (*(sampleList[0] + i) + *(sampleList[1] + i)) / 2;
      }
      return elxOK;
    }

    boost::scoped_array<T> spArray( new T[size] );
    uint32 j;
    if (Math::elxIsEven(size))
    {
      // median is even
      for (uint32 i = begin; i != end; ++i)
      {
        // fill temporary array
        for (j=0; j<size; ++j)
          spArray[j] = *(sampleList[j] + i);
        elxShellSort(spArray.get(), size, sortIncrement);

        // save median
        prSample[i] = spArray[median]; 
           
        // --- in progress ... ---
        if (--pixelProgress == 0)
        {
          pixelProgress = ProgressDisplayInterval;
          Progress += ProgressStep;
          notifier.SetProgress(Progress);
        }
      }
    }
    else
    {
      // median is odd, compute mean of median-1 and median
      for (uint32 i = begin; i != end; ++i)
      {
        // fill temporary array
        for (j=0; j<size; ++j)
          spArray[j] = *(sampleList[j] + i);
        elxShellSort(spArray.get(), uint32(size), uint32(sortIncrement));

        // save mean of median
        prSample[i] = (spArray[median-1] + spArray[median]) / 2;
        
        // --- in progress ... ---
        if (--pixelProgress == 0)
        {
          pixelProgress = ProgressDisplayInterval;
          Progress += ProgressStep;
          notifier.SetProgress(Progress);
        }
      }
    }

    notifier.SetProgress(1.0f);
    return elxOK;
  }

private:
  T * _prSample;
  const T * const * _SampleList;
  uint32 _Size, _SortIncrement;
  uint32 _begin, _end;
  ProgressNotifier& _notifier;

}; // MedianTask 

} // anonymous-namespace


template <class Pixel>
boost::shared_ptr< ImageImpl<Pixel> > 
  elxCreateMedian(
    const std::vector< const ImageImpl<Pixel>* >& iImageList,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  typedef typename Pixel::type T;
  typedef typename Pixel::S_type S;

  size_t i;
  const size_t size = iImageList.size();
  if (0 == size)
    return boost::shared_ptr< ImageImpl<Pixel> >();
    
  if (1 == size)
  {
    // return a copy of input image
    return boost::shared_ptr< ImageImpl<Pixel> > (
      new ImageImpl<Pixel>( *iImageList[0] ) );
  }
 
  const uint32 w = iImageList[0]->GetWidth();
  const uint32 h = iImageList[0]->GetHeight();

  // check image size are all identical
  for (i=1; i<size; ++i)
  {
    if ((iImageList[i]->GetWidth() != w) || (iImageList[i]->GetHeight() != h))
      return boost::shared_ptr< ImageImpl<Pixel> >();
  }
  
  // create output image
  boost::shared_ptr< ImageImpl<Pixel> > spImage( new ImageImpl<Pixel>(w,h) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // --- initialize pixel start for all input images
  std::vector< const T * > sampleList;
  sampleList.reserve(size);
  for (i=0; i<size; i++)
    sampleList.push_back( iImageList[i]->GetSamples() );

  // --- compute max increment to be used in shell sort
  size_t sortIncrement = 1;
  if (size > 2)
    for (; sortIncrement <= (size-2)/9; sortIncrement = 3*sortIncrement +1);

  MedianTask<T> task(
    spImage->GetSamples(), &sampleList[0], (uint32)size, (uint32)sortIncrement, iNotifier);

  const size_t sampleCount = (size_t)spImage->GetSampleCount(); 

  if (elxOK != elxParallelFor(
      IterationRange(0, sampleCount, Pixel::GetChannelCount()), task))
    return boost::shared_ptr< ImageImpl<Pixel> >();
  
  return spImage;

} // elxCreateMedian

} // namespace Image
} // namespace eLynx

#endif // __Operators_ListMedian_hpp__
