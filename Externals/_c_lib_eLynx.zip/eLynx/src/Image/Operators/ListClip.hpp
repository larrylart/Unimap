//============================================================================
//  Operators/ListClip.hpp                             Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Operators_ListClip_hpp__
#define __Operators_ListClip_hpp__

#include <boost/scoped_array.hpp>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

namespace {

template <typename T>
inline
T elxStdDeviation(
    const T * const * iSampleList, 
    uint32 iIdx, 
    const typename ResolutionTypeTraits<T>::Floating_type * iprWeight, 
    size_t iSize, 
    T iMean)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  
  if (iSize == 1)
    return (T)0;
    
  int32 count = 0; 
  F sum = F(0);
  for (size_t i=0; i<iSize; ++i)
  {
    if (iprWeight[i] == 0) 
      continue;
    sum += Math::elxSqr((F)(*(iSampleList[i] + iIdx) - iMean));
    ++count;
  }
  return (count < 2) ? 0 : (T) Math::elxSqrt(sum / (count - 1));

} // elxStdDeviation


//----------------------------------------------------------------------------
//  ClipMethodBase
//----------------------------------------------------------------------------
template <typename T, typename ClipMethod>
struct ClipMethodBase
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  
  ClipMethodBase(
      T * ipSample, 
      const T * const * iSampleList, 
      size_t iSize,
      uint32 iBegin, 
      uint32 iEnd, 
      uint32 iIterations, 
      double iKappa, 
      ProgressNotifier& iNotifier) :
    _prSample(ipSample), 
    _sampleList(iSampleList), 
    _size(iSize),
    _begin(iBegin), 
    _end(iEnd), 
    _iterations(iIterations), 
    _Kappa(iKappa), 
    _notifier(iNotifier)
  {}
  
  uint32 operator ()()
  {
    typedef typename ResolutionTypeTraits<T>::Floating_type F;
    
    const size_t size = _size;
    const uint32 begin = _begin;
    const uint32 end = _end;
    const T * const * sampleList = _sampleList;
    const uint32 iterations = _iterations;
    const double kappa = _Kappa;
    T * prSample = _prSample;
    
    ClipMethod& clipMethod = static_cast<ClipMethod&>(*this);
    
    boost::scoped_array<F> spWeightArrayInit( new F[size] );
    boost::scoped_array<F> spWeightArray( new F[size] );
    if (NULL == spWeightArray.get() || NULL == spWeightArrayInit.get())
      return elxErrOutOfMemory;
    uint32 k;
    size_t j;
    for (j=0; j<size; j++)
      spWeightArrayInit[j] = F(1.f);
      
    // --- inits progress ---
    const uint32 ProgressDisplayInterval = 1000;
    const float ProgressStep = 
      1.f / ((float)size/(float)ProgressDisplayInterval * (float)iterations);
    float Progress = 0.0f;
    uint32 pixelProgress = ProgressDisplayInterval;
    ProgressNotifier& notifier = _notifier; 
    notifier.SetProgress(Progress);
    
    clipMethod.Init();
      
    T mean, deviation;
    for (uint32 i = begin; i != end; ++i)
    {
      ::memcpy(spWeightArray.get(), spWeightArrayInit.get(), size*sizeof(F));

      for (uint32 it=0; it<iterations; it++)
      {
        // calculate temp pixel at (x,y)
        mean = clipMethod.CalculateValue(sampleList, i, spWeightArray.get());

        // calculate standard deviation
        deviation = (T)(kappa * elxStdDeviation(
          sampleList, i, spWeightArray.get(), size, mean));

        // reject pixels
        for (k = 0; k < size; ++k)
        {
          if (spWeightArray[k] == 0) 
            continue;
          clipMethod.CalculateWeight(
            *(sampleList[k] + i), spWeightArray[k], mean, deviation);
        } 
      }

      // --- in progress ... ---
      if (--pixelProgress == 0)
      {
        pixelProgress = ProgressDisplayInterval;
        Progress += ProgressStep;
        notifier.SetProgress(Progress);
      }
      
      // save final mean pixel at (x,y)
      prSample[i] = 
        clipMethod.CalculateValue(sampleList, i, spWeightArray.get());
    }
    
    notifier.SetProgress(1.0f);
    return elxOK;
  }

protected:
  T * _prSample;
  const T * const * _sampleList;
  size_t _size;
  uint32 _begin, _end;
  uint32 _iterations;
  double _Kappa;
  ProgressNotifier& _notifier;

}; // ClipMethodBase 


//----------------------------------------------------------------------------
//  Calculates Mean Kappa-sigma clipping
//----------------------------------------------------------------------------
template <typename T>
struct MeanClipMethod : public ClipMethodBase<T, MeanClipMethod<T> >
{
  typedef T type;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  
  // initial constructor
  MeanClipMethod(
      T * iprSample, 
      const T * const * iSampleList, 
      size_t iSize,
      uint32 iIterations, 
      double iKappa, 
      ProgressNotifier& iNotifier) :
    ClipMethodBase<T, MeanClipMethod>(
      iprSample, iSampleList, iSize, 0, 0, iIterations, iKappa, iNotifier)
  {}
  
  // split constructor
  MeanClipMethod(
      const MeanClipMethod& iOther, 
      const IterationRange& iRange) :
    ClipMethodBase<T, MeanClipMethod>(
      iOther._prSample, iOther._sampleList, iOther._size, 
      (uint32)iRange.GetBegin(), (uint32)iRange.GetEnd(), 
      iOther._iterations, iOther._Kappa, 
      (iRange.IsLast() || iRange.IsAll()) ?
        iOther._notifier : ProgressNotifier_NULL)
  {}
    
  void Init()
  {}
  
  T CalculateValue(const T * const * iSampleList, uint32 iIdx, const F * iWeight)
  {
    typedef typename ResolutionTypeTraits<T>::SumOverflow_type S;
    
    int32 count = 0; 
    S s = S(0);
    for (size_t i=0; i<this->_size; ++i)
    {
      if (iWeight[i] == 0)
        continue;
      s += *(iSampleList[i] + iIdx);
      ++count;
    }
    return (count > 0)? 
      ResolutionTypeTraits<T>::ClampS(s/count) :*(iSampleList[0] + iIdx);
  }
  
  void CalculateWeight(T iValue, F& oWeight, T iMean, T iDeviation)
  {
    if ( Math::elxAbs(iValue - iMean) >  iDeviation)
      oWeight = F(0.0f);
  }
};

//----------------------------------------------------------------------------
//  Calculates Median Kappa-sigma clipping
//----------------------------------------------------------------------------
template <typename T>
struct MedianClipMethod : public ClipMethodBase<T, MedianClipMethod<T> >
{
  typedef T type;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  
  // initial constructor
  MedianClipMethod(
      T * ipSample, 
      const T * const * iSampleList, 
      size_t iSize,
      uint32 iIterations, 
      double iKappa, 
      ProgressNotifier& iNotifier) :
    ClipMethodBase<T, MedianClipMethod>(
      ipSample, iSampleList, iSize, 0, 0, iIterations, iKappa, iNotifier),
   _sortIncrement(1),
   _spValues() 
  {}
  
  // split constructor
  MedianClipMethod(
      const MedianClipMethod& iOther, 
      const IterationRange& iRange) :
    ClipMethodBase<T, MedianClipMethod>(
      iOther._prSample, iOther._sampleList, iOther._size, 
      (uint32)iRange.GetBegin(), (uint32)iRange.GetEnd(), 
      iOther._iterations, iOther._Kappa, 
      (iRange.IsLast() || iRange.IsAll()) ?
        iOther._notifier : ProgressNotifier_NULL),
   _sortIncrement(1),
   _spValues() 
  {}
    

  // Copy Constructor
  MedianClipMethod(const MedianClipMethod& iOther) :
    ClipMethodBase<T, MedianClipMethod>(iOther),
   _sortIncrement(1),
   _spValues() 
  {}
  
  void Init()
  {
    _spValues.reset( new T[this->_size] );
    for (; _sortIncrement <= (this->_size-2)/9; _sortIncrement = 3*_sortIncrement+1);
  }
  
  T CalculateValue(const T * const * iSampleList, uint32 iIdx, const F * iprWeight)
  {
    // copy values with non-zero weight
    uint32 count = 0;
    for (size_t i=0; i<this->_size; ++i)
    {
      if (0 == iprWeight[i]) continue;
      _spValues[count] = *(iSampleList[i] + iIdx);
      ++count;
    }

    // calculate median
    elxShellSort(_spValues.get(), count, _sortIncrement);
    return _spValues[count/2];
  }
  
  void CalculateWeight(T iValue, F& oWeight, T iMean, T iDeviation)
  {
    if ( Math::elxAbs(iValue - iMean) >  iDeviation)
      oWeight = F(0.0f);
  }

protected:
  uint32 _sortIncrement;
  // we need a temp array to sort 
  boost::scoped_array<T> _spValues; 
};

//----------------------------------------------------------------------------
//  Calculates Weighted Average clipping
//----------------------------------------------------------------------------
template <typename T> 
struct WeightedClipMethod : public ClipMethodBase<T, WeightedClipMethod<T> >
{
  typedef T type;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  
  // initial constructor
  WeightedClipMethod(
      T * ipSample, 
      const T * const * iSampleList, 
      size_t iSize,
      uint32 iIterations, 
      double iKappa, 
      ProgressNotifier& iNotifier) :
    ClipMethodBase<T, WeightedClipMethod>(
      ipSample, iSampleList, iSize, 0, 0, iIterations, iKappa, iNotifier),
   _variance()
  {}
  
  // split constructor
  WeightedClipMethod(
      const WeightedClipMethod& iOther, 
      const IterationRange& iRange) :
    ClipMethodBase<T, WeightedClipMethod>(
      iOther._prSample, iOther._sampleList, iOther._size, 
      (uint32)iRange.GetBegin(), (uint32)iRange.GetEnd(), 
      iOther._iterations, iOther._Kappa, 
      (iRange.IsLast() || iRange.IsAll()) ?
        iOther._notifier : ProgressNotifier_NULL)
  {}
  
  void Init()
  {}
  
  T CalculateValue(const T * const * iSampleList, uint32 iIdx, const F * iWeight)
  {
    // calculate weighted average
    size_t i = 0;
    F s = *(iSampleList[i] + iIdx) * iWeight[i];
    F w = iWeight[i];
    for (i=1; i<this->_size; ++i)
    {
      s += *(iSampleList[i] + iIdx) * iWeight[i];
      w += iWeight[i];
    }

    T mean = ResolutionTypeTraits<T>::ClampF(s/w);
    
    // calculate variance
    _variance = Math::elxSqr( F(*(iSampleList[0] + iIdx)) - F(mean) );
    for (i=1; i<this->_size; ++i)
      _variance += Math::elxSqr( F(*(iSampleList[i] + iIdx)) - F(mean) );
      
    return mean;
  }
  
  void CalculateWeight(T iValue, F& oWeight, T iMean, T iDeviation)
  {
    // http://archive.eso.org/archive/hst/wfpc2_asn/3sites/WFPC2_Newsletter.pdf
    // w = 1 /G^2 * 1 / (1 + (iValue - Mean)^2 / G^2)
    oWeight =  1 / (_variance * (1 + Math::elxSqr(iValue - iMean)/_variance)); 
  }

protected:  
  F _variance;
};

} // anonymous-namespace

//----------------------------------------------------------------------------
//  Create clipped image from ImageImpl<Pixel> list
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr< ImageImpl<Pixel> > 
  elxCreateClipped(
    EImageListOperator iOperator,
    const std::vector< const ImageImpl<Pixel>* >& iImageList,
    uint32 iIterations, 
    double iKappa, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  typedef typename Pixel::type T;

  const size_t size = iImageList.size();
  const uint32 w = iImageList[0]->GetWidth();
  const uint32 h = iImageList[0]->GetHeight();

  // create output image
  boost::shared_ptr< ImageImpl<Pixel> > spImage( new ImageImpl<Pixel>(w,h) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  boost::scoped_array<const T*> spInitialArray( new const T*[size] );
  if (NULL == spInitialArray.get())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // --- initialize pixel start for all input images
  for (size_t i=0; i<size; i++)
    spInitialArray[i] = iImageList[i]->GetSamples();

  const uint32 sampleCount = spImage->GetSampleCount();
  uint32 status = elxErrInvalidParams;
  switch (iOperator)
  { 
    case ILO_MeanClip:
    {
      MeanClipMethod<T> meanClip(
        spImage->GetSamples(), spInitialArray.get(), size, 
        iIterations, iKappa, iNotifier);
      status = elxParallelFor(
        IterationRange(0, sampleCount, Pixel::GetChannelCount()), meanClip); 
      break;
    }
    case ILO_MedianClip:
    {
      MedianClipMethod<T> medianClip(
        spImage->GetSamples(), spInitialArray.get(), size, 
        iIterations, iKappa, iNotifier);
      status = elxParallelFor(
        IterationRange(0, sampleCount, Pixel::GetChannelCount()),
        medianClip);
      break;
    }
    case ILO_WeightedClip:
    {
      WeightedClipMethod<T> weightedClip(
        spImage->GetSamples(), spInitialArray.get(), size, 
        iIterations, iKappa, iNotifier);
      status = elxParallelFor(
        IterationRange(0, sampleCount, Pixel::GetChannelCount()),
        weightedClip);
      break;
    }
    default: break;
  }

  if (elxOK != status)
    return boost::shared_ptr< ImageImpl<Pixel> >();
  
  return spImage;

} // elxCreateClipped

} // namespace Image
} // namespace eLynx

#endif // __Operators_ListClip_hpp__
