//============================================================================
//  Operators/Constant.hpp                             Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Operators_Constant_hpp__
#define __Operators_Constant_hpp__

#include <elx/image/inl/Pixel/Neg.inl>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  Operator with constant
//----------------------------------------------------------------------------
template <class Pixel>
bool elxOperator(ImageImpl<Pixel>& ioImage,
    EImageOperator iOperator, 
    double iValue, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;

  typedef typename Pixel::type T;
  T value = T(iValue);
  
  if (Pixel::IsFullMask(iChannelMask))
  {
    // speed up if no channel mask used, works directly on samples
    T * prDst = ioImage.GetSamples();
    T * prEnd = ioImage.GetSamplesEnd();
    switch (iOperator)
    {
      case IOP_Set:
        do { *prDst = value; } while (++prDst != prEnd);
        return true;

      case IOP_Add:
        if (T(0) == value) return true;
        do { *prDst += value; } while (++prDst != prEnd);
        return true;

      case IOP_AddClamp:
// Todo
        if (T(0) == value) return true;
        do { *prDst = ResolutionTypeTraits<T>::Clamp(*prDst + value); } while (++prDst != prEnd);
        return true;

      case IOP_Sub:
        if (T(0) == value) return true;
        do { *prDst -= value; } while (++prDst != prEnd);
        return true;

      case IOP_SubClamp:
// Todo
        if (T(0) == value) return true;
        do { *prDst = ResolutionTypeTraits<T>::Clamp(*prDst - value); } while (++prDst != prEnd);
        return true;

      case IOP_Mul:
        if (1.0 == iValue) return true;
        do { *prDst = T(*prDst * iValue); } while (++prDst != prEnd);
        return true;

      case IOP_MulClamp:
        if (1.0 == iValue) return true;
        do { *prDst = ResolutionTypeTraits<T>::Clamp(*prDst * iValue); } while (++prDst != prEnd);
        return true;

      case IOP_Div:
      {
        if (1.0 == iValue) return true;
        if (0.0 == iValue) return false;
        value = T(1.0/iValue);
        do { *prDst *= value; } while (++prDst != prEnd);
        return true;
      }

      case IOP_Dif:
        do { *prDst = Math::elxAbsDiff(*prDst, value); } while (++prDst != prEnd);
        return true;

      case IOP_Min:
        do { *prDst = Math::elxMin(*prDst, value); } while (++prDst != prEnd);
        return true;

      case IOP_Max:
        do { *prDst = Math::elxMax(*prDst, value); } while (++prDst != prEnd);
        return true;

      case IOP_Thresh:
        do { *prDst = (*prDst > value)? *prDst : SampleTypeTraits<T>::_black; } while (++prDst != prEnd);
        return true;

      case IOP_Neg:
        {
          Pixel * prDst = ioImage.GetPixel();
          Pixel * prEnd = ioImage.GetPixelEnd();
          do { elxPixelNegative(*prDst); } while (++prDst != prEnd);
        }
        return true;
      
      default:
        return false;
    }
  } 
  else
  {
    // channel masking is slower, works on pixels
    Pixel * prDst = ioImage.GetPixel();
    Pixel * prEnd = ioImage.GetPixelEnd();
    switch (iOperator)
    {
      case IOP_Set:
        do { elxPixelSet(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;

      case IOP_Abs: 
        do { elxPixelAbs(*prDst, iChannelMask); } while (++prDst != prEnd);
        return true;
        
      case IOP_Add:
        if (T(0) == value) return true;
        do { *prDst = elxPixelAdd(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;

      case IOP_AddClamp:
        if (T(0) == value) return true;
        do { *prDst = elxPixelAddClamp(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;

      case IOP_Sub:
        if (T(0) == value) return true;
        do { *prDst = elxPixelSub(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;

      case IOP_SubClamp:
        if (T(0) == value) return true;
        do { *prDst = elxPixelSubClamp(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;

      case IOP_Mul:
        if (1.0 == iValue) return true;
        do { *prDst = elxPixelMul(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;

      case IOP_MulClamp:
        if (1.0 == iValue) return true;
        do { *prDst = elxPixelMulClamp(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;

      case IOP_Div:
        if (1.0 == iValue) return true;
        do { *prDst = elxPixelDiv(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;

      case IOP_Dif:
        do { *prDst = elxPixelAbsDiff(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;

      case IOP_Min:
        do { *prDst = elxPixelMin(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;

      case IOP_Max:
        do { *prDst = elxPixelMax(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;
        
      case IOP_Thresh:
        do { *prDst = elxPixelThreshold(*prDst, value, iChannelMask); } while (++prDst != prEnd);
        return true;

      case IOP_Neg:
        do { elxPixelNegative(*prDst, iChannelMask); } while (++prDst != prEnd);
        return true;

      default:
        return false;
    }
  }
  return false;

} // elxOperator

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageOperators implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Operator with constant
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageOperatorsImpl<Pixel>::Operator(
    AbstractImage& ioImage, 
    EImageOperator iOperator, 
    double iValue, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;

  if (RT_UINT8 == Pixel::GetResolution())
  {
    Math::Ramp<uint8> ramp;
    switch (iOperator)
    {
      case IOP_Set: ramp.SetNorm(iValue); break;
      case IOP_Abs: return true;
      case IOP_Neg: ramp.Complement(); break;
      case IOP_Add: ramp.AddNorm(iValue); break;
      case IOP_Sub: ramp.SubNorm(iValue); break;
      case IOP_Mul: ramp.Mul(iValue); break;
      case IOP_Div: ramp.Div(iValue); break;
      case IOP_Dif: ramp.DifNorm(iValue); break;
      case IOP_Min: ramp.MinNorm(iValue); break;
      case IOP_Max: ramp.MaxNorm(iValue); break;
      case IOP_AddClamp: ramp.AddNorm(iValue); break;
      case IOP_SubClamp: ramp.SubNorm(iValue); break;
      case IOP_MulClamp: ramp.Mul(iValue); break;
      default: return false;
    }
    PixelIterator<Pixel> begin = elxDowncast<Pixel>(ioImage.Begin());
    uint8 * prSrc = (uint8*)&begin->_channel[0];
    const uint32 size = ioImage.GetSampleCount();
    const uint32 nChannel = ioImage.GetChannelCount();
    return elxApplyRamp(ramp, prSrc, size, nChannel, iChannelMask);
  }
  else if (RT_UINT16 == Pixel::GetResolution())
  {
    Math::Ramp<uint16> ramp;
    switch (iOperator)
    {
      case IOP_Set: ramp.SetNorm(iValue); break;
      case IOP_Neg: ramp.Complement(); break;
      case IOP_Abs: return true;
      case IOP_Add: ramp.AddNorm(iValue); break;
      case IOP_Sub: ramp.SubNorm(iValue); break;
      case IOP_Mul: ramp.Mul(iValue); break;
      case IOP_Div: ramp.Div(iValue); break;
      case IOP_Dif: ramp.DifNorm(iValue); break;
      case IOP_Min: ramp.MinNorm(iValue); break;
      case IOP_Max: ramp.MaxNorm(iValue); break;
      case IOP_AddClamp: ramp.AddNorm(iValue); break;
      case IOP_SubClamp: ramp.SubNorm(iValue); break;
      case IOP_MulClamp: ramp.Mul(iValue); break;
      default: return false;
    }
    PixelIterator<Pixel> begin = elxDowncast<Pixel>(ioImage.Begin());
    uint16 * prSrc = (uint16*)&begin->_channel[0];
    const uint32 size = ioImage.GetSampleCount();
    const uint32 nChannel = ioImage.GetChannelCount();
    return elxApplyRamp(ramp, prSrc, size, nChannel, iChannelMask);
  }
  else if (RT_INT32 == Pixel::GetResolution())
  {
    //@TODO
    elxFIXME;
    return false;
  }

  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return elxOperator(image, iOperator, iValue, iChannelMask, iNotifier);

} // Operator

} // namespace Image
} // namespace eLynx

#endif // __Operators_Constant_hpp__
