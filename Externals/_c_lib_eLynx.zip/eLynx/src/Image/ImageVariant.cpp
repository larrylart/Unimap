//============================================================================
//  ImageVariant.cpp                                   Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/ImageVariant.h>
#include <elx/image/AbstractImageManager.h>

using namespace eLynx::Math;
using namespace boost;

// Blending macro
#define elxBLEND(iBlend, iChannelMask, _process_)         \
{                                                         \
  if (1.0 == iBlend) return (_process_);                  \
                                                          \
  ImageVariant original = *this;                          \
  const bool bSuccess = (_process_);                      \
  if (bSuccess)                                           \
    original.Blend(*this, 1.0-iBlend, iChannelMask);      \
  *this = original;                                       \
  return bSuccess;                                        \
}

#include "ImageVariant/Info.hpp"
#include "ImageVariant/File.hpp"
#include "ImageVariant/SplitMerge.hpp"
#include "ImageVariant/Mutation.hpp"
#include "ImageVariant/Bayer.hpp"
#include "ImageVariant/Analyse.hpp"
#include "ImageVariant/Geometry.hpp"
#include "ImageVariant/Operators_constant.hpp"
#include "ImageVariant/Operators_image.hpp"
#include "ImageVariant/Operators_list.hpp"
#include "ImageVariant/PointToPoint.hpp"
#include "ImageVariant/Convolution.hpp"
#include "ImageVariant/Morphological.hpp"
#include "ImageVariant/GlobalToPoint.hpp"
#include "ImageVariant/Edge.hpp"
#include "ImageVariant/Misc.hpp"
#include "ImageVariant/Rasterization.hpp"
#include "ImageVariant/Restoration.hpp"

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  default constructor : construct invalid image
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
ImageVariant::ImageVariant() :
  _spAbstractImpl(),
  _Bayer(BM_None)
{
}

//----------------------------------------------------------------------------
//  constructor : construct uninitialized image map of size iWidth by iHeight and type.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : EPixelFormat iPixelFormat
//        uint32 iWidth
//        uint32 iHeight
//----------------------------------------------------------------------------
ImageVariant::ImageVariant(EPixelFormat iPixelFormat, uint32 iWidth, uint32 iHeight) :
  _spAbstractImpl(),
  _Bayer(BM_None)
{
  // invalid  ?
  if ((0 == iWidth) || (0 == iHeight) || (PF_Undefined == iPixelFormat))
    return;

  _spAbstractImpl = elxGetImageHandler(iPixelFormat).CreateImage(iWidth, iHeight);
}

//----------------------------------------------------------------------------
//  copy constructor from ImageVariant
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const ImageVariant& iImage
//----------------------------------------------------------------------------
ImageVariant::ImageVariant(const ImageVariant& iImage) :
  _spAbstractImpl(),
  _Bayer(BM_None)
{
  if (!iImage.IsValid())
    return;

  _spAbstractImpl = elxGetImageHandler(*iImage._spAbstractImpl).
      CreateImage(*iImage._spAbstractImpl);
  _Bayer = iImage._Bayer;
  
} // copy constructor


//----------------------------------------------------------------------------
//  copy constructor from ImageVariant & resolution
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const ImageVariant& iImage
//----------------------------------------------------------------------------
ImageVariant::ImageVariant(const ImageVariant& iImage,
    EResolution iResolution, 
    bool ibScaled) :
  _spAbstractImpl(),
  _Bayer(BM_None)
{
  if (!iImage.IsValid())
    return;

  const EPixelFormat fromPF = iImage.GetPixelFormat();
  const EPixelFormat newPF = elxGetPixelFormat(fromPF, iResolution);
  if (PF_Undefined == newPF)
    return;

  _spAbstractImpl = elxGetImageHandler(*iImage._spAbstractImpl).
      CreateImage(*iImage._spAbstractImpl);
  
  ChangeResolution(iResolution, ibScaled);
  _Bayer = iImage._Bayer;

} // copy constructor

//----------------------------------------------------------------------------
//  copy constructor from AbstractImage
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const AbstractImage& iImage
//----------------------------------------------------------------------------
ImageVariant::ImageVariant(const AbstractImage& iImage) :
  _spAbstractImpl(),
  _Bayer(BM_None)
{
  if (!iImage.IsValid())
    return;

  _spAbstractImpl = elxGetImageHandler(iImage).CreateImage(iImage);
  
} // copy constructor

//----------------------------------------------------------------------------
//  operator =
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const ImageVariant& iImage: image to assign
//  Out : const ImageVariant&
//----------------------------------------------------------------------------
const ImageVariant& ImageVariant::operator = (const ImageVariant& iImage) 
{
  // guard against assigning to the "this" pointer
  if (this == &iImage)
    return *this;

  _spAbstractImpl.reset(); 
  if (!iImage.IsValid())
    return *this;

  _spAbstractImpl = elxGetImageHandler(*iImage._spAbstractImpl).
      CreateImage(*iImage._spAbstractImpl);
  _Bayer = iImage._Bayer;

  return *this;

} // operator =


//----------------------------------------------------------------------------
//  operator =
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const AbstractImage& iImage: image to assign
//  Out : const AbstractImage&
//----------------------------------------------------------------------------
const ImageVariant& ImageVariant::operator = (const AbstractImage& iImage) 
{
  if (!iImage.IsValid())
    return *this;

  _spAbstractImpl.reset(); 
  _spAbstractImpl = elxGetImageHandler(iImage).CreateImage(iImage);
  _Bayer = BM_None;
  return *this;

} // operator =


//----------------------------------------------------------------------------
//  operator ==
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const ImageVariant& iImage: image to assign
//  Out : bool true if iOther == this false otherwise
//----------------------------------------------------------------------------
bool ImageVariant::operator == (const ImageVariant& iOther) const
{
  if (_Bayer != iOther._Bayer) 
    return false;

  const AbstractImage * prImplThis = _spAbstractImpl.get();
  const AbstractImage * prImplOther = iOther._spAbstractImpl.get();
  
  // two invalid images ?
  if ((NULL == prImplThis) && (NULL == prImplOther))
    return true;

  // two valid images ?
  if ((NULL != prImplThis) && (NULL != prImplOther))
  {
    if (prImplThis->GetWidth() != prImplOther->GetWidth())
      return false;
    if (prImplThis->GetHeight() != prImplOther->GetHeight())
      return false;
    if (prImplThis->GetPixelFormat() != prImplOther->GetPixelFormat())
      return false;

    // compare image's maps bytes by bytes
    void * prImg1 = ((ImageLub*)prImplThis)->GetSamples();
    void * prImg2 = ((ImageLub*)prImplOther)->GetSamples();
    const size_t size = prImplThis->sizeofMap();
    return ( 0 == ::memcmp(prImg1, prImg2,size) );
  }
 
  // one valid / one invalid
  return false;

} // operator ==

//----------------------------------------------------------------------------
//  operator !=
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const ImageVariant& iImage: image to assign
//  Out : bool true if iOther != this false otherwise
//----------------------------------------------------------------------------
bool ImageVariant::operator != (const ImageVariant& iOther) const
{
  if (_Bayer != iOther._Bayer) 
    return true;

  const AbstractImage * prImplThis = _spAbstractImpl.get();
  const AbstractImage * prImplOther = iOther._spAbstractImpl.get();
  
  // two invalid images ?
  if ((NULL == prImplThis) && (NULL == prImplOther))
    return false;

  // two valid images ?
  if ((NULL != prImplThis) && (NULL != prImplOther))
  {
    if (prImplThis->GetWidth() != prImplOther->GetWidth())
      return true;
    if (prImplThis->GetHeight() != prImplOther->GetHeight())
      return true;
    if (prImplThis->GetPixelFormat() != prImplOther->GetPixelFormat())
      return true;

    // compare image's maps bytes by bytes
    void * prImg1 = ((ImageLub*)prImplThis)->GetSamples();
    void * prImg2 = ((ImageLub*)prImplOther)->GetSamples();
    const size_t size = prImplThis->sizeofMap();
    return ( 0 != ::memcmp(prImg1, prImg2,size) );
  }
 
  // one valid / one invalid
  return true;

} // operator !=


//----------------------------------------------------------------------------
//  destructor
//----------------------------------------------------------------------------
//  public virtual
//----------------------------------------------------------------------------
ImageVariant::~ImageVariant()
{
} // destructor


//----------------------------------------------------------------------------
//  Release
//----------------------------------------------------------------------------
void ImageVariant::Release() 
{ 
  delete this; 

} // Release


//----------------------------------------------------------------------------
//  Invalidate
//----------------------------------------------------------------------------
void ImageVariant::Invalidate(bool ibRelease)
{
  //@TODO something wrong here !
  if (ibRelease)  _spAbstractImpl.reset();
  else            _spAbstractImpl.reset();
  _Bayer = BM_None;

} // Invalidate


//----------------------------------------------------------------------------
//  Assign
//----------------------------------------------------------------------------
void ImageVariant::Assign(shared_ptr<AbstractImage>& ipnAbstractImpl)
{
  _spAbstractImpl = ipnAbstractImpl;

} // Assign


//----------------------------------------------------------------------------
//  Begin
//----------------------------------------------------------------------------
boost::shared_ptr<IPixelIterator> ImageVariant::Begin()
{
  if (NULL == _spAbstractImpl.get()) 
    return boost::shared_ptr<IPixelIterator>();

  return _spAbstractImpl->Begin();

} // Begin

//----------------------------------------------------------------------------  
boost::shared_ptr<IPixelIterator> ImageVariant::Begin() const
{
  if (NULL == _spAbstractImpl.get()) 
    return boost::shared_ptr<IPixelIterator>();

  const AbstractImage * prImpl = _spAbstractImpl.get();
  return prImpl->Begin();

} // Begin

//----------------------------------------------------------------------------
//  End
//----------------------------------------------------------------------------
boost::shared_ptr<IPixelIterator> ImageVariant::End()
{
  if (NULL == _spAbstractImpl.get()) 
    return boost::shared_ptr<IPixelIterator>();

  return _spAbstractImpl->End();

} // End

//----------------------------------------------------------------------------  
boost::shared_ptr<IPixelIterator> ImageVariant::End() const
{
  if (NULL == _spAbstractImpl.get()) 
    return boost::shared_ptr<IPixelIterator>();

  const AbstractImage * prImpl = _spAbstractImpl.get();
  return prImpl->End();

} // End

/*
bool ImageVariant::ApplyTransfertFunction(
  const Math::AbstractTransfertFunction& iTFn, 
  uint32 iChannelMask)
{
  if ((NULL == _spAbstractImpl.get()) || 
    !iImage.IsValid() || !isRGB()) return false;

  return true;
}
*/

} // namespace Image
} // namespace eLynx

