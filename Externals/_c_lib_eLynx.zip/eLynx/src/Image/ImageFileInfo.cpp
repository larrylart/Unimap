//============================================================================
//  ImageFileInfo.cpp                                  Image.Component package
//============================================================================
//  Usage : 
//----------------------------------------------------------------------------
//  Inheritance : 
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/ImageFileInfo.h>

#include <iostream>
using namespace std;

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
ImageFileInfo::ImageFileInfo() : 
  _flags(0),
  _wbRed(1.0), _wbGreen(1.0), _wbBlue(1.0),
  _shutter(0),
  _aperture(0),
  _focalLength(0),
  _timeStamp(0),
  _ISO(0),
  _width(0), _height(0),
  _bias(0),
  _Bayer(BM_None),
  _resolution(RT_Undefined),
  _pixelType(PT_Undefined),
  _content(IC_Unknown)
{
}

//----------------------------------------------------------------------------
ImageFileInfo::ImageFileInfo(const ImageFileInfo& iOther) :
  _flags(iOther._flags),
  _wbRed(iOther._wbRed), _wbGreen(iOther._wbRed), _wbBlue(iOther._wbRed),
  _shutter(iOther._shutter),
  _aperture(iOther._aperture),
  _focalLength(iOther._focalLength),
  _timeStamp(iOther._timeStamp),
  _ISO(iOther._ISO),
  _width(iOther._width), _height(iOther._height),
  _bias(iOther._bias),
  _Bayer(iOther._Bayer),
  _resolution(iOther._resolution),
  _pixelType(iOther._pixelType),
  _content(iOther._content)
{
  _Maker[0] = _Model[0] = '\0';
  strcpy(_Maker, iOther._Maker);
  strcpy(_Model, iOther._Model);

  if (0 != (_flags & II_Preview))
    _preview = iOther._preview;
}

//----------------------------------------------------------------------------
const ImageFileInfo& ImageFileInfo::operator = (const ImageFileInfo& iOther)
{
  // guard against assigning to the "this" pointer
  if (this == &iOther)
    return *this;

  _flags = iOther._flags;
  _ISO = iOther._ISO;
  _wbRed = iOther._wbRed; _wbGreen = iOther._wbRed; _wbBlue = iOther._wbRed;
  _shutter = iOther._shutter;
  _aperture = iOther._aperture;
  _focalLength = iOther._focalLength;
  _timeStamp = iOther._timeStamp;
  _width = iOther._width; _height = iOther._height;
  _bias = iOther._bias;
  _Bayer = iOther._Bayer;
  _resolution = iOther._resolution;
  _pixelType = iOther._pixelType;
  _content = iOther._content;
  
  _Maker[0] = _Model[0] = '\0';
  strcpy(_Maker, iOther._Maker);
  strcpy(_Model, iOther._Model);
  _preview = iOther._preview;

  return *this;
}


//----------------------------------------------------------------------------
void ImageFileInfo::SetMaker(const char * iprMaker)
{ 
  _flags |= II_Maker;
  strcpy(_Maker, iprMaker);
}
//----------------------------------------------------------------------------
const char * ImageFileInfo::GetMaker() const
{
  if (0 == (_flags & II_Maker)) return NULL;
  return &_Maker[0];
}

//----------------------------------------------------------------------------
void ImageFileInfo::SetModel(const char * iprModel)
{ 
  _flags |= II_Model;
  strcpy(_Model, iprModel);
}
//----------------------------------------------------------------------------
const char * ImageFileInfo::GetModel() const
{
  if (0 == (_flags & II_Model)) return NULL;
  return &_Model[0];
}

//----------------------------------------------------------------------------
void ImageFileInfo::SetISO(uint32 iISO)
{
  _flags |= II_ISO;
  _ISO = iISO;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetISO(uint32& oISO) const
{
  if (0 == (_flags & II_ISO)) return false;
  oISO = _ISO;
  return true;
}

//----------------------------------------------------------------------------
void ImageFileInfo::SetBias(uint32 iBias)
{
  _flags |= II_Bias;
  _bias = iBias;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetBias(uint32& oBias) const
{
  if (0 == (_flags & II_Bias)) return false;
  oBias = _bias;
  return true;
}

//----------------------------------------------------------------------------
void ImageFileInfo::SetWhiteBalance(float iRed, float iGreen, float iBlue)
{
  _flags |= II_WhiteBalance;
  _wbRed = iRed; 
  _wbGreen = iGreen;
  _wbBlue = iBlue;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetWhiteBalance(float& oRed, float& oGreen, float& oBlue) const
{
  if (0 == (_flags & II_WhiteBalance)) return false;
  oRed = _wbRed;
  oGreen = _wbGreen;
  oBlue = _wbBlue;
  return true;
}

//----------------------------------------------------------------------------
void ImageFileInfo::SetShutter(float iShutter)
{
  _flags |= II_Shutter;
  _shutter = iShutter;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetShutter(float& oShutter) const
{
  if (0 == (_flags & II_Shutter)) return false;
  oShutter = _shutter;
  return true;
}


//----------------------------------------------------------------------------
void ImageFileInfo::SetAperture(float iAperture)
{
  _flags |= II_Aperture;
  _aperture = iAperture;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetAperture(float& oAperture) const
{
  if (0 == (_flags & II_Aperture)) return false;
  oAperture = _aperture;
  return true;
}


//----------------------------------------------------------------------------
void ImageFileInfo::SetFocalLength(float iFocalLength)
{
  _flags |= II_FocalLength;
  _focalLength = iFocalLength;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetFocalLength(float& oFocalLength) const
{
  if (0 == (_flags & II_FocalLength)) return false;
  oFocalLength = _focalLength;
  return true;
}


//----------------------------------------------------------------------------
void ImageFileInfo::SetTimeStamp(time_t iTimeStamp)
{
  _flags |= II_TimeStamp;
  _timeStamp = iTimeStamp;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetTimeStamp(time_t& oTimeStamp) const
{
  if (0 == (_flags & II_TimeStamp)) return false;
  oTimeStamp = _timeStamp;
  return true;
}


//----------------------------------------------------------------------------
void ImageFileInfo::SetDimension(uint32 iWidth, uint32 iHeight)
{
  _flags |= II_Dimension;
  _width = iWidth;
  _height = iHeight;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetDimension(uint32& oWidth, uint32& oHeight) const
{
  if (0 == (_flags & II_Dimension)) return false;
  oWidth = _width;
  oHeight =_height;
  return true;
}


//----------------------------------------------------------------------------
void ImageFileInfo::SetBayer(EBayerMatrix iBayer)
{
  _flags |= II_Bayer;
  _Bayer = iBayer;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetBayer(EBayerMatrix& oBayer) const
{
  if (0 == (_flags & II_Bayer)) return false;
  oBayer = _Bayer;
  return true;
}


//----------------------------------------------------------------------------
void ImageFileInfo::SetResolution(EResolution iResolution)
{
  _flags |= II_resolution;
  _resolution = iResolution;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetResolution(EResolution& oResolution) const
{
  if (0 == (_flags & II_resolution)) return false;
  oResolution = _resolution;
  return true;
}


//----------------------------------------------------------------------------
void ImageFileInfo::SetPixelType(EPixelType iPixelType)
{
  _flags |= II_PixelType;
  _pixelType = iPixelType;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetPixelType(EPixelType& oPixelType) const
{
  if (0 == (_flags & II_PixelType)) return false;
  oPixelType = _pixelType;
  return true;
}


//----------------------------------------------------------------------------
void ImageFileInfo::SetPreview(const ImageVariant& iPreview)
{
  _flags |= II_Preview;
  _preview = iPreview;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetPreview(ImageVariant& oPreview) const
{
  if (0 == (_flags & II_Preview)) return false;
  oPreview = _preview;
  return true;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::UnloadPreview()
{
  _flags &= ~(II_Preview);
  _preview.Invalidate();
  return true;
}

//----------------------------------------------------------------------------
void ImageFileInfo::SetContent(EImageContent iContent)
{
  _flags |= II_Content;
  _content = iContent;
}
//----------------------------------------------------------------------------
bool ImageFileInfo::GetContent(EImageContent& oContent) const
{
  if (0 == (_flags & II_Content)) return false;
  oContent = _content;
  return true;
}

//----------------------------------------------------------------------------
void ImageFileInfo::Trace()
{
#if 0
  if (II_Maker || II_Model == (_flags & (II_Maker || II_Model)))
    cout << "Camera: " << _Maker << "-" << _Model << endl;

  if (_flags & II_ISO)          cout << "ISO=" << _ISO << endl;
  if (_flags & II_WhiteBalance) cout << "White balance Red=" << _wbRed << " Green=" << _wbGreen << "Blue=" << _wbBlue << endl;
  if (_flags & II_Shutter)      cout << "Shutter=" << _shutter << endl;
  if (_flags & II_Aperture)     cout << "Aperture=" << _aperture << endl;
  if (_flags & II_FocalLength)  cout << "Focal length=" << _focalLength << endl;
  if (_flags & II_TimeStamp)    cout << "Time=" << ctime(&_timeStamp);
  if (_flags & II_Dimension)    cout << "Width=" << _width << " Height=" << _height << " ";
  if (_flags & II_Bayer)        cout << "Bayer=" << elxToString(_Bayer) << " ";
  if (_flags & II_resolution)   cout << "Resolution=" << elxToString(_resolution) << " ";
  if (_flags & II_PixelType)    cout << "Pixel type=" << elxToString(_pixelType);
  cout << endl;
#else
  if (_flags & II_ISO)          cout << "ISO=" << _ISO << " ";
  if (_flags & II_Shutter)      cout << "Shutter=" << _shutter << " ";
  if (_flags & II_Aperture)     cout << "Aperture=" << _aperture << " ";
  if (_flags & II_FocalLength)  cout << "Focal length=" << _focalLength;
  cout << endl;
  if (_flags & II_TimeStamp)    cout << "Time=" << ctime(&_timeStamp);
#endif
}

} // namespace Image
} // namespace eLynx
