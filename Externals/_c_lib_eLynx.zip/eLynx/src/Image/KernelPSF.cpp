//============================================================================
//  KernelPSF.cpp                                      Image.Component package
//============================================================================
//  Usage : simple point spread function implementation, that uses convolution
// 					kernel elxKernel as PSF
//
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include "elx/core/CoreException.h"
#include "elx/image/KernelPSF.h"

namespace eLynx {
namespace Image {
	
//----------------------------------------------------------------------------
// constructor, creates new kernel-based PSF
//----------------------------------------------------------------------------
KernelPSF::KernelPSF(const Math::ConvolutionKerneld& iKernel) :
  _bSeparable(false)
{
  SetKernel(iKernel);
}


//----------------------------------------------------------------------------
// constructor, creates new separable kernel-based PSF
//----------------------------------------------------------------------------
KernelPSF::KernelPSF(
    const Math::ConvolutionKerneld& iKernel1,
    const Math::ConvolutionKerneld& iKernel2) :
  _bSeparable(true)
{
  SetKernel(iKernel1);
  SetKernel2(iKernel2);
}

//----------------------------------------------------------------------------
// copy constructor
//----------------------------------------------------------------------------
KernelPSF::KernelPSF(const KernelPSF& iOther)
{
  CopyData(iOther);
}


//----------------------------------------------------------------------------
// an assignement operator
//----------------------------------------------------------------------------	
KernelPSF& KernelPSF::operator = (const KernelPSF& iOther)
{
  if (&iOther != this) 
    CopyData(iOther);
  return *this;
}


//----------------------------------------------------------------------------
// returns convolution kernel (const version)
//----------------------------------------------------------------------------	
const Math::ConvolutionKerneld& KernelPSF::GetKernel() const
{
  return _kernel;
}


//----------------------------------------------------------------------------
// returns convolution kernel
//----------------------------------------------------------------------------	
Math::ConvolutionKerneld& KernelPSF::GetKernel()
{
  return _kernel;
}

//----------------------------------------------------------------------------
// returns second convolution kernel (const version)
//----------------------------------------------------------------------------		
const Math::ConvolutionKerneld& KernelPSF::GetKernel2() const
{
  return _kernel2;
}


//----------------------------------------------------------------------------
// returns second convolution kernel
//----------------------------------------------------------------------------
Math::ConvolutionKerneld& KernelPSF::GetKernel2()
{
  return _kernel2;
}


//----------------------------------------------------------------------------
// sets PSF convolution kernel
//----------------------------------------------------------------------------
void KernelPSF::SetKernel(const Math::ConvolutionKerneld& iKernel)
{
  _kernel = iKernel;
  _bSeparable = iKernel.IsHorizontal() ? true : false;
}


//----------------------------------------------------------------------------
// sets PSF convolution kernel
//----------------------------------------------------------------------------
void KernelPSF::SetKernel2(const Math::ConvolutionKerneld& iKernel)
{
  _kernel2 = iKernel;
  _bSeparable = true;
}

//----------------------------------------------------------------------------
// checks, whether PSF is implemented using separable kernel
//----------------------------------------------------------------------------
bool KernelPSF::IsSeparable() const
{
  return _bSeparable;
}

//----------------------------------------------------------------------------
// returns PSF width in pixels
//----------------------------------------------------------------------------	
uint32 KernelPSF::GetWidth() const
{
  return _kernel.GetWidth();
}


//----------------------------------------------------------------------------
// returns PSF height in pixels
//----------------------------------------------------------------------------
uint32 KernelPSF::GetHeight() const
{
  if (_bSeparable) 
    return _kernel2.GetHeight();
  return _kernel.GetHeight();
}


//----------------------------------------------------------------------------
// returns specified PSF value
//----------------------------------------------------------------------------
double KernelPSF::EvalPSF(uint32 iX, uint32 iY, int32 iDX, int32 iDY) const
{
  return 0.0;
  /*// compute kernel coodinates
  int32 x = (int32)_CenterX+iDX;
  int32 y = (int32)_CenterY+iDY;
	
  // if out of scope, return 0
  if (x < 0 || y < 0 || 
      x >= (int32)GetWidth() || y >= (int32)GetHeight()) return 0.0;
	
  // otherwise, return appropriate kernel value
  return _kernel._spK[y*GetWidth()+x];*/
  elxThrow(elxErrInvalidContext, "Not supported, use Convolve method.");
}


//----------------------------------------------------------------------------
// copies object data
//----------------------------------------------------------------------------
void KernelPSF::CopyData(const KernelPSF& iOther)
{
  _kernel = iOther._kernel;
  _kernel2 = iOther._kernel2;
  _bSeparable = iOther._bSeparable;
}

	
} // namespace Image
} // namespace eLynx
