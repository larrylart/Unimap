//============================================================================
//  AbstractImageManager.cpp                           Image.Component package
//============================================================================
//  Usage : services for abstract image management
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreConversion.h>
#include <elx/image/AbstractImageManager.h>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
// Instanciate all image type handlers
//----------------------------------------------------------------------------
static ImageHandlerImpl<PixelLub> s_HandlerLub;
static ImageHandlerImpl<PixelLus> s_HandlerLus;
static ImageHandlerImpl<PixelLi>  s_HandlerLi;
static ImageHandlerImpl<PixelLf>  s_HandlerLf;
static ImageHandlerImpl<PixelLd>  s_HandlerLd;

static ImageHandlerImpl<PixelLAub> s_HandlerLAub;
static ImageHandlerImpl<PixelLAus> s_HandlerLAus;
static ImageHandlerImpl<PixelLAi>  s_HandlerLAi;
static ImageHandlerImpl<PixelLAf>  s_HandlerLAf;
static ImageHandlerImpl<PixelLAd>  s_HandlerLAd;

static ImageHandlerImpl<PixelRGBub> s_HandlerRGBub;
static ImageHandlerImpl<PixelRGBus> s_HandlerRGBus;
static ImageHandlerImpl<PixelRGBi>  s_HandlerRGBi;
static ImageHandlerImpl<PixelRGBf>  s_HandlerRGBf;
static ImageHandlerImpl<PixelRGBd>  s_HandlerRGBd;

static ImageHandlerImpl<PixelRGBAub> s_HandlerRGBAub;
static ImageHandlerImpl<PixelRGBAus> s_HandlerRGBAus;
static ImageHandlerImpl<PixelRGBAi>  s_HandlerRGBAi;
static ImageHandlerImpl<PixelRGBAf>  s_HandlerRGBAf;
static ImageHandlerImpl<PixelRGBAd>  s_HandlerRGBAd;

#ifdef elxUSE_ImageComplex
static ImageHandlerImpl<PixelComplexi> s_HandlerCPLXi;
static ImageHandlerImpl<PixelComplexf> s_HandlerCPLXf;
static ImageHandlerImpl<PixelComplexd> s_HandlerCPLXd;
#endif

#ifdef elxUSE_ImageHLS
static ImageHandlerImpl<PixelHLSf> s_HandlerHLSf;
static ImageHandlerImpl<PixelHLSd> s_HandlerHLSd;
#endif

#ifdef elxUSE_ImageXYZ
static ImageHandlerImpl<PixelXYZf> s_HandlerXYZf;
static ImageHandlerImpl<PixelXYZd> s_HandlerXYZd;
#endif

#ifdef elxUSE_ImageLuv
static ImageHandlerImpl<PixelLuvf> s_HandlerLuvf;
static ImageHandlerImpl<PixelLuvd> s_HandlerLuvd;
#endif

#ifdef elxUSE_ImageLab
static ImageHandlerImpl<PixelLabf> s_HandlerLabf;
static ImageHandlerImpl<PixelLabd> s_HandlerLabd;
#endif

#ifdef elxUSE_ImageLch
static ImageHandlerImpl<PixelLchf> s_HandlerLchf;
static ImageHandlerImpl<PixelLchd> s_HandlerLchd;
#endif

#ifdef elxUSE_ImageHLab
static ImageHandlerImpl<PixelHLabf> s_HandlerHLabf;
static ImageHandlerImpl<PixelHLabd> s_HandlerHLabd;
#endif

//----------------------------------------------------------------------------
// Defined in same order as in EPixelFormat declaration
//----------------------------------------------------------------------------
static const IImageHandler * s_prImageTypeHandler_lut[PF_Undefined] =
{
//   uint8             uint16            integer           float            double
  &s_HandlerLub,    &s_HandlerLus,    &s_HandlerLi,     &s_HandlerLf,    &s_HandlerLd,
  &s_HandlerLAub,   &s_HandlerLAus,   &s_HandlerLAi,    &s_HandlerLAf,   &s_HandlerLAd,
  &s_HandlerRGBub,  &s_HandlerRGBus,  &s_HandlerRGBi,   &s_HandlerRGBf,  &s_HandlerRGBd,
  &s_HandlerRGBAub, &s_HandlerRGBAus, &s_HandlerRGBAi,  &s_HandlerRGBAf, &s_HandlerRGBAd,

#ifdef elxUSE_ImageComplex // ------------------------------------------------
                                      &s_HandlerCPLXi,  &s_HandlerCPLXf, &s_HandlerCPLXd,
#else
                                      NULL,             NULL,             NULL,
#endif
#ifdef elxUSE_ImageHLS // ----------------------------------------------------
                                                        &s_HandlerHLSf,  &s_HandlerHLSd,
#else
                                                        NULL,            NULL,
#endif
#ifdef elxUSE_ImageXYZ // ----------------------------------------------------
                                                        &s_HandlerXYZf,  &s_HandlerXYZd,
#else
                                                        NULL,            NULL,
#endif
#ifdef elxUSE_ImageLuv // ----------------------------------------------------
                                                        &s_HandlerLuvf,  &s_HandlerLuvd,
#else
                                                        NULL,            NULL,
#endif
#ifdef elxUSE_ImageLab // ----------------------------------------------------
                                                        &s_HandlerLabf,  &s_HandlerLabd,
#else
                                                        NULL,            NULL,
#endif
#ifdef elxUSE_ImageLch // ----------------------------------------------------
                                                        &s_HandlerLchf,  &s_HandlerLchd,
#else
                                                        NULL,            NULL,
#endif
#ifdef elxUSE_ImageHLab // ---------------------------------------------------
                                                        &s_HandlerHLabf, &s_HandlerHLabd
#else
                                                        NULL,            NULL
#endif
};

//----------------------------------------------------------------------------
//  elxGetImageHandler : return ImageManagerImpl for a given image type
//----------------------------------------------------------------------------
//  public global
//----------------------------------------------------------------------------
const IImageHandler& elxGetImageHandler(EPixelFormat iPixelFormat)
{
  elxASSERT(PF_Undefined != iPixelFormat);
  return *s_prImageTypeHandler_lut[iPixelFormat];
}
//----------------------------------------------------------------------------
const IImageHandler& elxGetImageHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() );
}
//============================================================================
const IImageGeometry& elxGetGeometryHandler(EPixelFormat iPixelFormat)
{
  return elxGetImageHandler(iPixelFormat).GetGeometryHandler();
}
//----------------------------------------------------------------------------
const IImageGeometry& elxGetGeometryHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() ).GetGeometryHandler();
}
//============================================================================
const IImageAnalyse& elxGetAnalyseHandler(EPixelFormat iPixelFormat)
{
  return elxGetImageHandler(iPixelFormat).GetAnalyseHandler();
}
//----------------------------------------------------------------------------
const IImageAnalyse& elxGetAnalyseHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() ).GetAnalyseHandler();
}
//============================================================================
const IImageOperators& elxGetOperatorsHandler(EPixelFormat iPixelFormat)
{
  return elxGetImageHandler(iPixelFormat).GetOperatorsHandler();
}
//----------------------------------------------------------------------------
const IImageOperators& elxGetOperatorsHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() ).GetOperatorsHandler();
}
//============================================================================
const IImagePointProcessing& elxGetPointToPointHandler(EPixelFormat iPixelFormat)
{
  return elxGetImageHandler(iPixelFormat).GetPointToPointHandler();
}
//----------------------------------------------------------------------------
const IImagePointProcessing& elxGetPointToPointHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() ).GetPointToPointHandler();
}
//============================================================================
const IImageLocalProcessing& elxGetLocalToPointHandler(EPixelFormat iPixelFormat)
{
  return elxGetImageHandler(iPixelFormat).GetLocalToPointHandler();
}
//----------------------------------------------------------------------------
const IImageLocalProcessing& elxGetLocalToPointHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() ).GetLocalToPointHandler();
}
//============================================================================
const IImageGlobalProcessing& elxGetGlobalToPointHandler(EPixelFormat iPixelFormat)
{
  return elxGetImageHandler(iPixelFormat).GetGlobalToPointHandler();
}
//----------------------------------------------------------------------------
const IImageGlobalProcessing& elxGetGlobalToPointHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() ).GetGlobalToPointHandler();
}
//============================================================================
const IImageEdgeProcessing& elxGetEdgeProcessingHandler(EPixelFormat iPixelFormat)
{
  return elxGetImageHandler(iPixelFormat).GetEdgeProcessingHandler();
}
//----------------------------------------------------------------------------
const IImageEdgeProcessing& elxGetEdgeProcessingHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() ).GetEdgeProcessingHandler();
}
//============================================================================
const IImageMorphologicalProcessing& elxGetMorphologicalHandler(EPixelFormat iPixelFormat)
{
  return elxGetImageHandler(iPixelFormat).GetMorphologicalHandler();
}
//----------------------------------------------------------------------------
const IImageMorphologicalProcessing& elxGetMorphologicalHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() ).GetMorphologicalHandler();
}

//============================================================================
const IImageMiscProcessing& elxGetMiscHandler(EPixelFormat iPixelFormat)
{
  return elxGetImageHandler(iPixelFormat).GetMiscHandler();
}
//----------------------------------------------------------------------------
const IImageMiscProcessing& elxGetMiscHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() ).GetMiscHandler();
}

//============================================================================
const IImageRasterization& elxGetRasterizationHandler(EPixelFormat iPixelFormat)
{
  return elxGetImageHandler(iPixelFormat).GetRasterizationHandler();
}
//----------------------------------------------------------------------------
const IImageRasterization& elxGetRasterizationHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() ).GetRasterizationHandler();
}

//============================================================================
const IImageRestoration& elxGetRestorationHandler(EPixelFormat iPixelFormat)
{
  return elxGetImageHandler(iPixelFormat).GetRestorationHandler();
}
//----------------------------------------------------------------------------
const IImageRestoration& elxGetRestorationHandler(const AbstractImage& iImage)
{
  return elxGetImageHandler( iImage.GetPixelFormat() ).GetRestorationHandler();
}

//----------------------------------------------------------------------------
//  elxCreateImage : construction by size
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
boost::shared_ptr<AbstractImage> 
  elxCreateImage(
    EPixelFormat iPixelFormat, 
    uint32 iWidth, 
    uint32 iHeight)
{
  return elxGetImageHandler(iPixelFormat).CreateImage(iWidth, iHeight);
}

//----------------------------------------------------------------------------
//  elxCreateImage : generic cloning
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
boost::shared_ptr<AbstractImage> 
  elxCreateImage(
    const AbstractImage& iImage)
{
  return elxGetImageHandler(iImage).CreateImage(iImage);
}

//----------------------------------------------------------------------------
//  elxCreateImage : Generic image resolution factory, keep pixel type.
//----------------------------------------------------------------------------
//  global public
//----------------------------------------------------------------------------
boost::shared_ptr<AbstractImage> 
  elxCreateImage(
    const AbstractImage& iImage, 
    EResolution iResolution,
    bool ibScaled)
{
  return elxGetImageHandler(iImage).CreateImage(iImage, iResolution, ibScaled);
}

//----------------------------------------------------------------------------
#ifdef elxUSE_ImageHLS
#define CREATE_HLS(image) case CS_HLS: return elxCreateImageHLS(image);
#else
#define CREATE_HLS(image)
#endif

#ifdef elxUSE_ImageXYZ
#define CREATE_XYZ(image) case CS_CIE_XYZ: return elxCreateImageXYZ(image);
#else
#define CREATE_XYZ(image)
#endif

#ifdef elxUSE_ImageLuv
#define CREATE_LUV(image) case CS_CIE_Luv: return elxCreateImageLuv(image);
#else
#define CREATE_LUV(image)
#endif

#ifdef elxUSE_ImageLab
#define CREATE_LAB(image) case CS_CIE_Lab: return elxCreateImageLab(image);
#else
#define CREATE_LAB(image)
#endif

#ifdef elxUSE_ImageLch
#define CREATE_LCH(image) case CS_CIE_Lch: return elxCreateImageLch(image);
#else
#define CREATE_LCH(image)
#endif

#ifdef elxUSE_ImageHLab
#define CREATE_HLAB(image) case CS_Hunter_Lab: return elxCreateImageHLab(image);
#else
#define CREATE_HLAB(image)
#endif

#define CREATE_COLOR_IMAGE(iColorSpace, image) \
  switch (iColorSpace) \
  {                    \
    case CS_RGB: return elxCreateImageRGB(image);  \
    CREATE_HLS(image)  \
    CREATE_XYZ(image)  \
    CREATE_LUV(image)  \
    CREATE_LAB(image)  \
    CREATE_LCH(image)  \
    CREATE_HLAB(image) \
default: return boost::shared_ptr<AbstractImage>();   \
  }

//----------------------------------------------------------------------------
//  elxCreateImage : Create an image with requested color space.
//  ISO resolution when possible.
//----------------------------------------------------------------------------
//  global public
//----------------------------------------------------------------------------
boost::shared_ptr<AbstractImage> 
  elxCreateImage(
    const AbstractImage& iImage,
    EColorSpace iColorSpace,
    bool ibBlendAlpha)
{
  switch (iImage.GetPixelFormat())
  {
    case PF_RGBub: case PF_RGBus: case PF_RGBi:
    {
      // RGBub,RGBub,PF_RGBi => RGBub,RGBub,PF_RGBi
      // RGBub,RGBub,PF_RGBi => RGBf -> HLSf,XYZf,Luvf,Labf,Lchf,HLabf

      if (CS_RGB == iColorSpace) // just a copy
        return elxCreateImage(iImage);

      const bool bScale = true;
      const bool bBlendAlpha = false;
      boost::shared_ptr<AbstractImage> spImageRGBf = elxCreateImage(iImage, RT_Float, bScale);
      return elxCreateImage(*spImageRGBf, iColorSpace, bBlendAlpha);
    }
    
    case PF_RGBf:
    {
      // RGBf -> HLSf,XYZf,Luvf,Labf,Lchf,HLabf
      const ImageRGBf& image = (const ImageRGBf&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }

    case PF_RGBd:
    {
      // RGBd -> HLSd,XYZd,Luvd,Labd,Lchd,HLabd
      const ImageRGBd& image = (const ImageRGBd&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
    //-------------------------------------------------------------
    case PF_HLSf:
    {
      const ImageHLSf& image = (const ImageHLSf&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
    case PF_HLSd:
    {
      const ImageHLSd& image = (const ImageHLSd&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
    //-------------------------------------------------------------
#ifdef elxUSE_ImageXYZ
    case PF_XYZf:
    {
      const ImageXYZf& image = (const ImageXYZf&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
    case PF_XYZd:
    {
      const ImageXYZd& image = (const ImageXYZd&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
#endif
    //-------------------------------------------------------------
#ifdef elxUSE_ImageLuv
    case PF_Luvf:
    {
      const ImageLuvf& image = (const ImageLuvf&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
    case PF_Luvd:
    {
      const ImageLuvd& image = (const ImageLuvd&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
#endif
    //-------------------------------------------------------------
#ifdef elxUSE_ImageLab
    case PF_Labf:
    {
      const ImageLabf& image = (const ImageLabf&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
    case PF_Labd:
    {
      const ImageLabd& image = (const ImageLabd&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
#endif
    //-------------------------------------------------------------
#ifdef elxUSE_ImageLch
    case PF_Lchf:
    {
      const ImageLchf& image = (const ImageLchf&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
    case PF_Lchd:
    {
      const ImageLchd& image = (const ImageLchd&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
#endif
    //-------------------------------------------------------------
#ifdef elxUSE_ImageHLab
    case PF_HLabf:
    {
      const ImageHLabf& image = (const ImageHLabf&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
    case PF_HLabd:
    {
      const ImageHLabd& image = (const ImageHLabd&)iImage;
      CREATE_COLOR_IMAGE(iColorSpace, image);
    }
#endif
    //-------------------------------------------------------------
    case PF_Lub: case PF_Lus: case PF_Li: case PF_Lf: case PF_Ld:
    {
      // Lub,Lus,Li,Lf,Ld => RGBub,RGBus,RGBi,RGBf,RGBd
      // Lub,Lus,Li => Lf => RGBf -> HLSf,XYZf,Luvf,Labf,Lchf,HLabf
      // Lf => RGBf -> HLSf,XYZf,Luvf,Labf,Lchf,HLabf
      // Ld => RGBd -> HLSd,XYZd,Luvd,Labd,Lchd,HLabd

      if (CS_RGB == iColorSpace)
        return elxCreateColorImage(iImage, CS_RGB, ibBlendAlpha);

      boost::shared_ptr<AbstractImage> spImageRGB;
      if (!iImage.IsFloat() && !iImage.IsDouble())
      {
        const bool bScale = true;
        boost::shared_ptr<AbstractImage> spImageLf = 
          elxCreateImage(iImage, RT_Float, bScale);

        spImageRGB = elxCreateColorImage(*spImageLf, CS_RGB, ibBlendAlpha);
      }
      else
        spImageRGB = elxCreateColorImage(iImage, CS_RGB, ibBlendAlpha);

      return elxCreateImage(*spImageRGB, iColorSpace, ibBlendAlpha);
    }
    //-------------------------------------------------------------
    case PF_LAub: case PF_LAus: case PF_LAi: case PF_LAf: case PF_LAd:
    {
      // LAub,LAus,LAi,LAf,LAd => RGBAub,RGBAus,RGBAi,RGBAf,RGBAd (ibBlendAlpha = false)
      // LAub,LAus,LAi,LAf,LAd => RGBub,RGBus,RGBi,RGBf,RGAd (ibBlendAlpha = true)
      // LAub,LAus,LAi => Lf => RGBf -> HLSf,XYZf,Luvf,Labf,Lchf,HLabf
      // LAf => RGBf -> HLSf,XYZf,Luvf,Labf,Lchf,HLabf
      // LAd => RGBd -> HLSd,XYZd,Luvd,Labd,Lchd,HLabd
      
      if (CS_RGB == iColorSpace)
      {
        if (ibBlendAlpha) // remove alpha, ISO resolution
          return elxCreateColorImage(iImage, CS_RGB, ibBlendAlpha);
        else // keep alpha, ISO resolution
          return elxCreateAlphaImage(iImage, true/*RGB*/);
      }

      boost::shared_ptr<AbstractImage> spImageRGB;
      if (!iImage.IsFloat() && !iImage.IsDouble())
      {
        const bool bScale = true;
        boost::shared_ptr<AbstractImage> spImageLf = 
          elxCreateImage(iImage, RT_Float, bScale);

        spImageRGB = elxCreateColorImage(*spImageLf, CS_RGB, ibBlendAlpha);
      }
      else
        spImageRGB = elxCreateColorImage(iImage, CS_RGB, ibBlendAlpha);

      return elxCreateImage(*spImageRGB, iColorSpace, ibBlendAlpha);
    }
    //-------------------------------------------------------------
    case PF_RGBAub: case PF_RGBAus: case PF_RGBAi: case PF_RGBAf: case PF_RGBAd:
    {
      // RGBAub,RGBAub,PF_RGBAi => RGBAub,RGBAub,PF_RGBAi (ibBlendAlpha = false)
      // RGBAub,RGBAub,PF_RGBAi => RGBub,RGBub,PF_RGBi (ibBlendAlpha = true)
      // RGBAub,RGBAub,PF_RGBAi => RGBub,RGBub,PF_RGBi -> RGBf -> HLSf,XYZf,Luvf,Labf,Lchf,HLabf
      // RGBAf,RGBAf,PF_RGBAf => PF_RGBf -> HLSf,XYZf,Luvf,Labf,Lchf,HLabf
      // RGBAd,RGBAd,PF_RGBAd => PF_RGBd -> HLSd,XYZd,Luvd,Labd,Lchd,HLabd

      if (CS_RGB == iColorSpace)
      {
        if (ibBlendAlpha) // remove alpha, ISO resolution
          switch(iImage.GetResolution())
          {
            case RT_UINT8:  return elxCreateImageRGB((const ImageRGBAub&)iImage, true);
            case RT_UINT16: return elxCreateImageRGB((const ImageRGBAus&)iImage, true);
            case RT_INT32:  return elxCreateImageRGB((const ImageRGBAi&) iImage, true);
            case RT_Float:  return elxCreateImageRGB((const ImageRGBAf&) iImage, true);
            case RT_Double: return elxCreateImageRGB((const ImageRGBAd&) iImage, true);
            default: return boost::shared_ptr<AbstractImage>();
          }
        else // keep alpha, ISO resolution
          return elxCreateAlphaImage(iImage, true/*RGB*/);
      }

      // remove alpha channel ISO resolution
      boost::shared_ptr<AbstractImage> spImageRGBiso =
        elxCreateImage(iImage, ibBlendAlpha);

      boost::shared_ptr<AbstractImage> spImageRGB;
      if (!iImage.IsFloat() && !iImage.IsDouble())
        spImageRGB = elxCreateImage(*spImageRGBiso, RT_Float, true /*bScale*/);
      else
        spImageRGB = spImageRGBiso;

      return elxCreateImage(*spImageRGB, iColorSpace, ibBlendAlpha);
    }
    //-------------------------------------------------------------
    default: 
      // not supported
      elxFIXME;
      return boost::shared_ptr<AbstractImage>();
  }

} // elxCreateImage # Color space


//----------------------------------------------------------------------------
//  elxCreateImage : Create an image with a requested pixel format
//  NO ISO resolution, NO iso type.
//----------------------------------------------------------------------------
//  global public
//----------------------------------------------------------------------------
boost::shared_ptr<AbstractImage> 
  elxCreateImage(
    const AbstractImage& iImage,
    EPixelFormat iPixelFormat, 
    bool ibScaled, 
    bool ibBlendAlpha)
{
  if (!iImage.IsValid() || (PF_Undefined == iPixelFormat))
    return boost::shared_ptr<AbstractImage>();

  // --- Here go optimizations ---

  // 1 - if AbstractImage pixel format is iPixelFormat just clone
  if (iPixelFormat == iImage.GetPixelFormat())
    return elxCreateImage(iImage);

  const EResolution newResolution = elxGetResolution(iPixelFormat);
  const EPixelType newType = elxGetPixelType(iPixelFormat);

  // 2 - if AbstractImage pixel type is pixel type of iPixelFormat just change resolution
  if (newType == iImage.GetPixelType())
    return elxCreateImage(iImage, newResolution, ibScaled);

  const bool bSameResolution = (newResolution == iImage.GetResolution());

  // 3 - same resolutions
  if (bSameResolution)
  {
    // just have to remove Alpha channel
    // RGBA<T> to RGB<T>, 
    // LA<T> to L<T> 
    if ((iImage.IsRGBA() && elxIsRGB(iPixelFormat)) ||
        (iImage.IsLA()   && elxIsL(iPixelFormat)))
      return elxCreateImage(iImage, ibBlendAlpha);

    // L<T>, RGB<T>, RGBA<T> to LA<T>
    if (elxIsLA(iPixelFormat) && 
       (iImage.IsL() || iImage.IsRGB() || iImage.IsRGBA()))
      return elxCreateAlphaImage(iImage, false/*RGB*/, CGC_Default);

    // L<T>, LA<T>, RGB<T> to RGBA<T>
    if (elxIsRGBA(iPixelFormat) && 
        (iImage.IsL() || iImage.IsLA() || iImage.IsRGB()))
      return elxCreateAlphaImage(iImage, true/*RGB*/);

    // LA<T> to RGB<T>
    if (elxIsRGB(iPixelFormat) && iImage.IsLA())
    {
      // LA<T> -> L<T> -> RGB<T>
      boost::shared_ptr<AbstractImage> spImage = 
        elxCreateImage(iImage, ibBlendAlpha);
      return elxCreateImage(*spImage, CS_RGB, false/*BlendAlpha*/);
    }
  }
  else
  {
    // just have to remove Alpha channel
    // RGBA<T> to RGB<U>, 
    // LA<T> to L<U> 
    if ((iImage.IsRGBA() && elxIsRGB(iPixelFormat)) ||
        (iImage.IsLA()   && elxIsL(iPixelFormat)))
    {
      boost::shared_ptr<AbstractImage> spImage = 
        elxCreateImage(iImage, ibBlendAlpha);
      return elxCreateImage(*spImage, newResolution, ibScaled);
    }

    // L<T>, RGB<T>, RGBA<T> to LA<U>
    if (elxIsLA(iPixelFormat) && 
       (iImage.IsL() || iImage.IsRGB() || iImage.IsRGBA()))
    {
      boost::shared_ptr<AbstractImage> spImage = 
        elxCreateAlphaImage(iImage, false/*RGB*/, CGC_Default);
      return elxCreateImage(*spImage, newResolution, ibScaled);
    }

    // L<T>, LA<T>, RGB<T> to RGBA<U>
    if (elxIsRGBA(iPixelFormat) && 
        (iImage.IsL() || iImage.IsLA() || iImage.IsRGB()))
    {
      boost::shared_ptr<AbstractImage> spImage = 
        elxCreateAlphaImage(iImage, true/*RGB*/);
      return elxCreateImage(*spImage, newResolution, ibScaled);
    }

    // LA<T> to RGB<U>
    if (elxIsRGB(iPixelFormat) && iImage.IsLA())
    {
      // LA<T> -> L<T> -> RGB<U>
      boost::shared_ptr<AbstractImage> spImageL = 
        elxCreateImage(iImage, ibBlendAlpha);
      boost::shared_ptr<AbstractImage> spImageLRes = 
        elxCreateImage(*spImageL, newResolution, ibScaled);
      return elxCreateImage(*spImageLRes, CS_RGB, false/*BlendAlpha*/);
    }
  }

  // 4 - Change pixel type
  // Change pixel mode?
  const EPixelMode newMode = elxGetPixelMode(iPixelFormat);
  if (newMode == iImage.GetPixelMode())
  {
    switch(newMode)
    {
    case PM_Grey:
      {
        if (bSameResolution)
        {
          // L<T> to LA<T>
          if (iImage.IsL() && elxIsLA(iPixelFormat))
            return elxCreateAlphaImage(iImage, false/*RGB*/);

          // LA<T> to L<T>
          if (iImage.IsLA() && elxIsL(iPixelFormat))
            return elxCreateImage(iImage, ibBlendAlpha);
        }
        else
        {
          boost::shared_ptr<AbstractImage> spImageRes = 
            elxCreateImage(iImage, newResolution, ibScaled);
        
          // L<T> to LA<T>
          if (iImage.IsL() && elxIsLA(iPixelFormat))
            return elxCreateAlphaImage(*spImageRes, false/*RGB*/);

          // LA<T> to L<T>
          if (iImage.IsLA() && elxIsL(iPixelFormat))
            return elxCreateImage(*spImageRes, ibBlendAlpha);
        }

        elxFIXME;
        return boost::shared_ptr<AbstractImage>();
      }

    case PM_Color: 
    {
      // Change color space ?
      boost::shared_ptr<AbstractImage> spImage;
      const AbstractImage * prSrc = &iImage;

      // first change resolution if necessary
      bool bResolutionFailed = false;
      boost::shared_ptr<AbstractImage> spImageRes;
      if (!bSameResolution)
      {
        spImageRes = elxCreateImage(iImage, newResolution, ibScaled);
        if (elxUseable(spImageRes.get()))
          prSrc = spImageRes.get();
        else // try again after color space conversion
          bResolutionFailed = true;
      }

      // change color space or clone
      const EColorSpace colorSpace = elxGetColorSpace(iPixelFormat);
      spImage = elxCreateImage(*prSrc, colorSpace, ibBlendAlpha);

      if (!bSameResolution && bResolutionFailed)
      {
        if (!elxUseable(spImage.get()))
          return boost::shared_ptr<AbstractImage>();

        spImageRes = elxCreateImage(*spImage, newResolution, ibScaled);
        spImage.swap(spImageRes);
      }

      if (elxIsRGBA(iPixelFormat))
      {
        boost::shared_ptr<AbstractImage> spImageAlpha = 
          elxCreateAlphaImage(*spImage, true/*RGB*/);
        spImage.swap(spImageAlpha);
      }
      return spImage;
    }

    default: return boost::shared_ptr<AbstractImage>();
    }
  }
  else // Change mode
  {
    switch(iImage.GetPixelMode())
    {
    case PM_Grey:
      // Grey => Color, Complex
      switch(newMode)
      {
        case PM_Color:
        {
          // L,LA => RGBA
          if (elxIsRGBA(iPixelFormat))
          {
            boost::shared_ptr<AbstractImage> spImage = 
              elxCreateAlphaImage(iImage, true/*RGB*/);

            if (bSameResolution) return spImage;

            // change resolution
            if (!elxUseable(spImage.get())) 
              return boost::shared_ptr<AbstractImage>();
            boost::shared_ptr<AbstractImage> spImageRes = 
              elxCreateImage(*spImage, newResolution, ibScaled);
            return spImageRes;
          }
          else
          {
            // L => RGB -> RGB,HLS,XYZ,Luv,Lab
            boost::shared_ptr<AbstractImage> spImageLRes = 
              elxCreateImage(iImage, newResolution, ibScaled);
            boost::shared_ptr<AbstractImage> spImageRGBRes = 
              elxCreateColorImage(*spImageLRes, CS_RGB, ibBlendAlpha);
            const EColorSpace cs = elxGetColorSpace(iPixelFormat);
            return elxCreateImage(*spImageRGBRes, cs, ibBlendAlpha);
          }
          elxFIXME; 
          return boost::shared_ptr<AbstractImage>();
        }
        case PM_Complex:
        {
          // L, LA => Complex
          elxFIXME; return boost::shared_ptr<AbstractImage>();
        }
        default: return boost::shared_ptr<AbstractImage>();
      }
      return boost::shared_ptr<AbstractImage>();

    case PM_Color:
      // Color => Grey (Color => Complex has no sense)
      switch(newMode)
      {
        // RGB,RGBA,HLS,XYZ,Luv,Lab => L,LA, @TODO Complex
        case PM_Grey:
        {
          // convert to grey
          boost::shared_ptr<AbstractImage> spImage;
          if (elxIsLA(iPixelFormat))
          {
            if (iImage.IsRGBA())
            {
              // keep alpha channel
              spImage = elxCreateAlphaImage(iImage, false/*RGB*/, CGC_Default);
            }
            else
            {
              // loose alpha channel
              boost::shared_ptr<AbstractImage> spGrey = elxCreateGreyImage(iImage);
              spImage = elxCreateAlphaImage(*spGrey, false/*RGB*/, CGC_Default);
            }
          }
          else
            spImage = elxCreateGreyImage(iImage, CGC_Default, true/*RemoveAlpha*/, ibBlendAlpha);

          // ISO resolution
          if (bSameResolution) return spImage;

          // change resolution
          return elxCreateImage(*spImage, newResolution, ibScaled);
        }     
        default: elxFIXME; return boost::shared_ptr<AbstractImage>();
      }

    case PM_Complex:
      // Complex => Grey (Complex => Color has no sense)
      elxFIXME;
      return boost::shared_ptr<AbstractImage>();

    default: return boost::shared_ptr<AbstractImage>();
    }
  }

  elxFIXME;
  return boost::shared_ptr<AbstractImage>();

} // elxCreateImage # Pixel format


//----------------------------------------------------------------------------
//  elxCreateImage:  RGBA<T> to RGB<T> and LA<T> to L<T>
//  ISO resolution 
//----------------------------------------------------------------------------
boost::shared_ptr< AbstractImage > 
  elxCreateImage(
    const AbstractImage& iImage,
    bool ibBlendAlpha)
{
  // check input image
  if (!iImage.IsValid() || !iImage.HasAlpha())
    return boost::shared_ptr<AbstractImage>();

  switch(iImage.GetPixelFormat())
  {
    case PF_RGBAub: {
      const ImageRGBAub& image = (const ImageRGBAub&)iImage;
      return elxCreateImageRGB(image, ibBlendAlpha);
    }
    case PF_RGBAus: {
      const ImageRGBAus& image = (const ImageRGBAus&)iImage;
      return elxCreateImageRGB(image, ibBlendAlpha);
    }
    case PF_RGBAi: {
      const ImageRGBAi& image = (const ImageRGBAi&)iImage;
      return elxCreateImageRGB(image, ibBlendAlpha);
    }
    case PF_RGBAf: {
      const ImageRGBAf& image = (const ImageRGBAf&)iImage;
      return elxCreateImageRGB(image, ibBlendAlpha);
    }
    case PF_RGBAd: {
      const ImageRGBAd& image = (const ImageRGBAd&)iImage;
      return elxCreateImageRGB(image, ibBlendAlpha);
    }
    case PF_LAub: {
      const ImageLAub& image = (const ImageLAub&)iImage;
      return elxCreateImageL(image, ibBlendAlpha);
    }
    case PF_LAus: {
      const ImageLAus& image = (const ImageLAus&)iImage;
      return elxCreateImageL(image, ibBlendAlpha);
    }
    case PF_LAi: {
      const ImageLAi& image = (const ImageLAi&)iImage;
      return elxCreateImageL(image, ibBlendAlpha);
    }
    case PF_LAf: {
      const ImageLAf& image = (const ImageLAf&)iImage;
      return elxCreateImageL(image, ibBlendAlpha);
    }
    case PF_LAd: {
      const ImageLAd& image = (const ImageLAd&)iImage;
      return elxCreateImageL(image, ibBlendAlpha);
    }
    default:
      return boost::shared_ptr<AbstractImage>();
  }
  return boost::shared_ptr<AbstractImage>();

} // elxCreateImage # Alpha


//----------------------------------------------------------------------------
boost::shared_ptr<ImageRGBub> 
  elxCreateImageRGB(
    const ImageLub& iImage, 
    EBayerToColorConversion iMethod)
{
  return boost::shared_ptr<ImageRGBub>();
}
//----------------------------------------------------------------------------
boost::shared_ptr<ImageRGBus> 
  elxCreateImageRGB(
    const ImageLus& iImage, 
    EBayerToColorConversion iMethod)
{
  return boost::shared_ptr<ImageRGBus>();
}

//----------------------------------------------------------------------------
//  elxCreateImageRGBGrey
//  ISO resolution
//----------------------------------------------------------------------------
ExportedByImage boost::shared_ptr<AbstractImage> 
  elxCreateImageRGBGrey(
    const AbstractImage& iImage, 
    uint32 iChannel)
{
  if (!iImage.IsValid())
    return boost::shared_ptr<AbstractImage>();
    
  switch(iImage.GetPixelFormat())
  {
    case PF_RGBub: {
      const ImageRGBub& image = (const ImageRGBub&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_RGBus: {
      const ImageRGBus& image = (const ImageRGBus&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_RGBi: {
      const ImageRGBi& image = (const ImageRGBi&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_RGBf: {
      const ImageRGBf& image = (const ImageRGBf&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_RGBd: {
      const ImageRGBd& image = (const ImageRGBd&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    //-------------------------------------------------------------
#ifdef elxUSE_ImageHLS
    case PF_HLSf: {
      const ImageHLSf& image = (const ImageHLSf&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_HLSd:{
      const ImageHLSd& image = (const ImageHLSd&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
#endif
    //-------------------------------------------------------------
#ifdef elxUSE_ImageXYZ
    case PF_XYZf: {
      const ImageXYZf& image = (const ImageXYZf&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_XYZd: {
      const ImageXYZd& image = (const ImageXYZd&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
#endif
    //-------------------------------------------------------------
#ifdef elxUSE_ImageLuv
    case PF_Luvf: {
      const ImageLuvf& image = (const ImageLuvf&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_Luvd: {
      const ImageLuvd& image = (const ImageLuvd&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
#endif
    //-------------------------------------------------------------
#ifdef elxUSE_ImageLab
    case PF_Labf: {
      const ImageLabf& image = (const ImageLabf&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_Labd: {
      const ImageLabd& image = (const ImageLabd&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
#endif
    //-------------------------------------------------------------
#ifdef elxUSE_ImageLch
    case PF_Lchf: {
      const ImageLchf& image = (const ImageLchf&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_Lchd: {
      const ImageLchd& image = (const ImageLchd&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
#endif
    //-------------------------------------------------------------
#ifdef elxUSE_ImageHLabf
    case PF_HLabf: {
      const ImageHLabf& image = (const ImageHLabf&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_HLabd: {
      const ImageHLabd& image = (const ImageHLabd&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
#endif
    //-------------------------------------------------------------
    case PF_RGBAub: {
      const ImageRGBAub& image = (const ImageRGBAub&)iImage;
      return elxCreateImageRGBGrey(image, iChannel&CM_Channel012);
    }
    case PF_RGBAus: {
      const ImageRGBus& image = (const ImageRGBus&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_RGBAi: {
      const ImageRGBi& image = (const ImageRGBi&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_RGBAf: {
      const ImageRGBf& image = (const ImageRGBf&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_RGBAd: {
      const ImageRGBd& image = (const ImageRGBd&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    //-------------------------------------------------------------
    case PF_LAub: {
      const ImageLAub& image = (const ImageLAub&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_LAus: {
      const ImageLAus& image = (const ImageLAus&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_LAi: {
      const ImageLAi& image = (const ImageLAi&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_LAf: {
      const ImageLAf& image = (const ImageLAf&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }
    case PF_LAd: {
      const ImageLAd& image = (const ImageLAd&)iImage;
      return elxCreateImageRGBGrey(image, iChannel);
    }

    default: 
      elxFIXME; // @TODO COMPLEX
  }
  return boost::shared_ptr<AbstractImage>();

} // elxCreateImageRGBGrey


//----------------------------------------------------------------------------
//  elxCreateColorImage : Create color image with requested color space, 
//  ISO resolution when possible.
//----------------------------------------------------------------------------
//  global public
//----------------------------------------------------------------------------
boost::shared_ptr<AbstractImage> 
  elxCreateColorImage(
    const AbstractImage& iImage, 
    EColorSpace iColorSpace,
    bool ibBlendAlpha,
    bool ibRemoveAlpha,
    EGreyToColorConversion iMethod)
{
  if (!iImage.IsValid())
    return boost::shared_ptr<AbstractImage>();

  if (iImage.IsL())
  {
    switch(iColorSpace)
    {
      case CS_RGB:
        switch(iImage.GetResolution())
        {
          case RT_UINT8:  return elxCreateImageRGBGrey( (const ImageLub&)iImage, iMethod );
          case RT_UINT16: return elxCreateImageRGBGrey( (const ImageLus&)iImage, iMethod );
          case RT_INT32:  return elxCreateImageRGBGrey( (const ImageLi&) iImage, iMethod );
          case RT_Float:  return elxCreateImageRGBGrey( (const ImageLf&) iImage, iMethod );
          case RT_Double: return elxCreateImageRGBGrey( (const ImageLd&) iImage, iMethod );
          default: return boost::shared_ptr<AbstractImage>();
        }
      default:
        return boost::shared_ptr<AbstractImage>();
      }
  }
  if (iImage.IsLA())
  {
    switch(iColorSpace)
    {
      case CS_RGB:
        if (ibRemoveAlpha)
          switch(iImage.GetResolution())
          {
            case RT_UINT8:  return elxCreateImageRGBGrey( (const ImageLAub&)iImage, iMethod, ibBlendAlpha );
            case RT_UINT16: return elxCreateImageRGBGrey( (const ImageLAus&)iImage, iMethod, ibBlendAlpha );
            case RT_INT32:  return elxCreateImageRGBGrey( (const ImageLAi&) iImage, iMethod, ibBlendAlpha );
            case RT_Float:  return elxCreateImageRGBGrey( (const ImageLAf&) iImage, iMethod, ibBlendAlpha );
            case RT_Double: return elxCreateImageRGBGrey( (const ImageLAd&) iImage, iMethod, ibBlendAlpha );
            default: return boost::shared_ptr<AbstractImage>();
          }
        else
          switch(iImage.GetResolution())
          {
            case RT_UINT8:  return elxCreateImageRGBAGrey( (const ImageLAub&)iImage, iMethod );
            case RT_UINT16: return elxCreateImageRGBAGrey( (const ImageLAus&)iImage, iMethod );
            case RT_INT32:  return elxCreateImageRGBAGrey( (const ImageLAi&) iImage, iMethod );
            case RT_Float:  return elxCreateImageRGBAGrey( (const ImageLAf&) iImage, iMethod );
            case RT_Double: return elxCreateImageRGBAGrey( (const ImageLAd&) iImage, iMethod );
            default: return boost::shared_ptr<AbstractImage>();
          }
      default:
        return boost::shared_ptr<AbstractImage>();
      }
  }
  elxFIXME;
  return boost::shared_ptr<AbstractImage>();

} // elxCreateColorImage


//----------------------------------------------------------------------------
// Abstract grey image factory from abstract (RGB or RGBA) color image. 
// ISO Resolution.
//----------------------------------------------------------------------------
boost::shared_ptr<AbstractImage> 
  elxCreateGreyImage(
    const AbstractImage& iImage, 
    EColorToGreyConversion iMethod,
    bool ibRemoveAlpha,
    bool ibBlendAlpha)
{
  if (iImage.IsL()) // copy L<T> to L<T>
    return elxCreateImage(iImage);

  if (iImage.IsLA())
  {
    if (ibRemoveAlpha) // LA<T> to L<T>
      return elxCreateImage(iImage, ibBlendAlpha);
    else // copy LA<T> to LA<T>
      return elxCreateImage(iImage);
  }

  if (iImage.IsComplex()) // NOT SUPPORTED
    return boost::shared_ptr<AbstractImage>();

  const EResolution res = iImage.GetResolution();
  if (iImage.IsRGBA())
  {
    if (ibRemoveAlpha)
      switch (res)
      {
        case RT_UINT8:  return elxCreateGreyImage( (const ImageRGBAub&)iImage, ibBlendAlpha, iMethod);
        case RT_UINT16: return elxCreateGreyImage( (const ImageRGBAus&)iImage, ibBlendAlpha, iMethod);
        case RT_INT32:  return elxCreateGreyImage( (const ImageRGBAi&)iImage,  ibBlendAlpha, iMethod);
        case RT_Float:  return elxCreateGreyImage( (const ImageRGBAf&)iImage,  ibBlendAlpha, iMethod);
        case RT_Double: return elxCreateGreyImage( (const ImageRGBAd&)iImage,  ibBlendAlpha, iMethod);
        default: return boost::shared_ptr<AbstractImage>();
      }
    else
      switch (res)
      {
        case RT_UINT8:  return elxCreateGreyImage( (const ImageRGBAub&)iImage, iMethod);
        case RT_UINT16: return elxCreateGreyImage( (const ImageRGBAus&)iImage, iMethod);
        case RT_INT32:  return elxCreateGreyImage( (const ImageRGBAi&)iImage,  iMethod);
        case RT_Float:  return elxCreateGreyImage( (const ImageRGBAf&)iImage,  iMethod);
        case RT_Double: return elxCreateGreyImage( (const ImageRGBAd&)iImage,  iMethod);
        default: return boost::shared_ptr<AbstractImage>();
      }
  }

  if (iImage.IsRGB())
  {
    switch (res)
    {
      case RT_UINT8:  return elxCreateGreyImage( (const ImageRGBub&)iImage, iMethod);
      case RT_UINT16: return elxCreateGreyImage( (const ImageRGBus&)iImage, iMethod);
      case RT_INT32:  return elxCreateGreyImage( (const ImageRGBi&)iImage,  iMethod);
      case RT_Float:  return elxCreateGreyImage( (const ImageRGBf&)iImage,  iMethod);
      case RT_Double: return elxCreateGreyImage( (const ImageRGBd&)iImage,  iMethod);  
      default: return boost::shared_ptr<AbstractImage>();
    }
  }

#ifdef elxUSE_ImageHLS
  if (iImage.IsHLS())
  {
    // Get the L plane
    if (RT_Float == res)  return elxCreateChannel((const ImageHLSf&)iImage, 1);
    if (RT_Double == res) return elxCreateChannel((const ImageHLSd&)iImage, 1);
    elxFIXME;
  }
#endif

#ifdef elxUSE_ImageXYZ
  if (iImage.IsXYZ())
  {
    // Get the L plane
    if (RT_Float == res)  return elxCreateChannel((const ImageXYZf&)iImage, 1);
    if (RT_Double == res) return elxCreateChannel((const ImageXYZd&)iImage, 1);
    elxFIXME;
  }
#endif

#ifdef elxUSE_ImageLuv
  if (iImage.IsLuv())
  {
    // Get the L plane
    if (RT_Float == res)  return elxCreateChannel((const ImageLuvf&)iImage, 0);
    if (RT_Double == res) return elxCreateChannel((const ImageLuvd&)iImage, 0);
    elxFIXME;
  }
#endif

#ifdef elxUSE_ImageLab
  if (iImage.IsLab())
  {
    // Get the L plane
    if (RT_Float == res)  return elxCreateChannel((const ImageLabf&)iImage, 0);
    if (RT_Double == res) return elxCreateChannel((const ImageLabd&)iImage, 0);
    elxFIXME;
  }
#endif

#ifdef elxUSE_ImageLch
  if (iImage.IsLch())
  {
    // Get the L plane
    if (RT_Float == res)  return elxCreateChannel((const ImageLchf&)iImage, 0);
    if (RT_Double == res) return elxCreateChannel((const ImageLchd&)iImage, 0);
    elxFIXME;
  }
#endif

#ifdef elxUSE_ImageHLab
  if (iImage.IsHLab())
  {
    // Get the L plane
    if (RT_Float == res)  return elxCreateChannel((const ImageHLabf&)iImage, 0);
    if (RT_Double == res) return elxCreateChannel((const ImageHLabd&)iImage, 0);
    elxFIXME;
  }
#endif

  elxFIXME;
  return boost::shared_ptr<AbstractImage>();

} // elxCreateGreyImage


//----------------------------------------------------------------------------
// elxCreateAlphaImage : Create image adding an alpha plane 
// ISO resolution when possible.
//----------------------------------------------------------------------------
//  global public
//----------------------------------------------------------------------------
boost::shared_ptr<AbstractImage> 
  elxCreateAlphaImage(
    const AbstractImage& iImage, 
    bool ibRGB,
    EColorToGreyConversion iMethod)
{
  if (!iImage.IsValid())
    return boost::shared_ptr<AbstractImage>();

  const EResolution res = iImage.GetResolution();

  if (ibRGB)
  {
    if (iImage.IsL())
    {
      // L<T> to RGBA<T>
      switch(res)
      {
        case RT_UINT8:  return elxCreateImageRGBA( (const ImageLub&)iImage);
        case RT_UINT16: return elxCreateImageRGBA( (const ImageLus&)iImage);
        case RT_INT32:  return elxCreateImageRGBA( (const ImageLi&) iImage);
        case RT_Float:  return elxCreateImageRGBA( (const ImageLf&) iImage);
        case RT_Double: return elxCreateImageRGBA( (const ImageLd&) iImage);
        default: return boost::shared_ptr<AbstractImage>();
      }
    }

    if (iImage.IsLA())
    {
      // LA<T> to RGBA<T>
      switch(res)
      {
        case RT_UINT8:  return elxCreateImageRGBA( (const ImageLAub&)iImage);
        case RT_UINT16: return elxCreateImageRGBA( (const ImageLAus&)iImage);
        case RT_INT32:  return elxCreateImageRGBA( (const ImageLAi&) iImage);
        case RT_Float:  return elxCreateImageRGBA( (const ImageLAf&) iImage);
        case RT_Double: return elxCreateImageRGBA( (const ImageLAd&) iImage);
        default: return boost::shared_ptr<AbstractImage>();
      }
    }

    if (iImage.IsRGB())
    {
      // RGB<T> to RGBA<T>
      switch(res)
      {
        case RT_UINT8:  return elxCreateImageRGBA((const ImageRGBub&)iImage);
        case RT_UINT16: return elxCreateImageRGBA((const ImageRGBus&)iImage);
        case RT_INT32:  return elxCreateImageRGBA((const ImageRGBi&) iImage);
        case RT_Float:  return elxCreateImageRGBA((const ImageRGBf&) iImage);
        case RT_Double: return elxCreateImageRGBA((const ImageRGBd&) iImage);
        default: return boost::shared_ptr<AbstractImage>();
      }
    }

    if (iImage.IsRGBA())
    {
      // RGBA<T> to RGBA<T>
      return elxCreateImage(iImage);
    }

    // could not be here
    elxFIXME;
  }
  else // not RGB
  {
    if (iImage.IsL())
    {
      // L<T> to LA<T>
      switch(res)
      {
        case RT_UINT8:  return elxCreateImageLA( (const ImageLub&)iImage);
        case RT_UINT16: return elxCreateImageLA( (const ImageLus&)iImage);
        case RT_INT32:  return elxCreateImageLA( (const ImageLi&) iImage);
        case RT_Float:  return elxCreateImageLA( (const ImageLf&) iImage);
        case RT_Double: return elxCreateImageLA( (const ImageLd&) iImage);
        default: return boost::shared_ptr<AbstractImage>();
      }
    }

    if (iImage.IsLA())
    {
      // LA<T> to LA<T>
      return elxCreateImage(iImage);
    }

    if (iImage.IsRGB())
    {
      // RGB<T> to LA<T>
      switch(res)
      {
        case RT_UINT8:  return elxCreateImageLA( (const ImageRGBub&)iImage, iMethod);
        case RT_UINT16: return elxCreateImageLA( (const ImageRGBus&)iImage, iMethod);
        case RT_INT32:  return elxCreateImageLA( (const ImageRGBi&) iImage, iMethod);
        case RT_Float:  return elxCreateImageLA( (const ImageRGBf&) iImage, iMethod);
        case RT_Double: return elxCreateImageLA( (const ImageRGBd&) iImage, iMethod);
        default: return boost::shared_ptr<AbstractImage>();
      }
    }
    if (iImage.IsRGBA())
    {
      // RGBA<T> to LA<T>
      switch(res)
      {
        case RT_UINT8:  return elxCreateImageLA( (const ImageRGBAub&)iImage, iMethod);
        case RT_UINT16: return elxCreateImageLA( (const ImageRGBAus&)iImage, iMethod);
        case RT_INT32:  return elxCreateImageLA( (const ImageRGBAi&) iImage, iMethod);
        case RT_Float:  return elxCreateImageLA( (const ImageRGBAf&) iImage, iMethod);
        case RT_Double: return elxCreateImageLA( (const ImageRGBAd&) iImage, iMethod);
        default: return boost::shared_ptr<AbstractImage>();
      }
    }
    // could not be here
    elxFIXME;
  }
  // could not be here
  elxFIXME;
  return boost::shared_ptr<AbstractImage>();

} // elxCreateAlphaImage

//----------------------------------------------------------------------------
//  elxCreateImageRGBub : create an ImageRGBub from an AbstractImage
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
boost::shared_ptr<ImageRGBub> 
  elxCreateImageRGBub(
    const AbstractImage& iImage,
    const Math::AbstractTransfertFunction * iprFunction,
    uint32 iChannelMask,
    bool ibBlendAlpha)
{
  boost::shared_ptr<ImageRGBub> spImage = 
    boost::dynamic_pointer_cast<ImageRGBub, AbstractImage>(
      elxCreateImage(iImage, PF_RGBub, true, ibBlendAlpha));
  if (NULL == spImage.get()) return boost::shared_ptr<ImageRGBub>();

  // Does transform must be apply?
  if ((NULL == iprFunction) || 
      ((NULL != iprFunction) && iprFunction->IsInvariant()))
    return spImage;

  uint8 * prDst = spImage->GetSamples();
  const uint8 * prSrc = (const uint8*)prDst;
  const uint32 size = spImage->sizeofMap();
  iprFunction->Transform(prDst, prSrc, size, RT_UINT8);

  elxFilterChannel(*spImage, iChannelMask);

  return spImage;

} // elxCreateImageRGBub


//----------------------------------------------------------------------------
//  elxCreateImageRGBub : create an ImageRGBub from an AbstractImage
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
boost::shared_ptr<ImageRGBub> 
  elxCreateImageRGBub(
    const AbstractImage& iImage,
    const Math::AbstractTransfertFunction * iprFunction,
    EBayerToColorConversion iMethod,
    EBayerMatrix iBayer,
    uint32 iChannelMask)
{
  if (!iImage.IsL())
    return boost::shared_ptr<ImageRGBub>();

  // get uint8 Grey image
  boost::shared_ptr<AbstractImage> spImageLub = elxCreateImage(iImage, RT_UINT8);
  if (NULL == spImageLub.get()) return boost::shared_ptr<ImageRGBub>();

  // transform to uint8 rgb according demosaicing method
  boost::shared_ptr<ImageRGBub> spImageRGBub = 
    boost::dynamic_pointer_cast<ImageRGBub, AbstractImage>(
      elxGetBayerHandler(*spImageLub).
        CreateRGB(*spImageLub, iBayer, iMethod));
  spImageLub.reset();

  // Does transform must be apply?
  if ((NULL == iprFunction) || 
      ((NULL != iprFunction) && iprFunction->IsInvariant()))
    return spImageRGBub;

  uint8 * prDst = spImageRGBub->GetSamples();
  const uint8* prSrc = (const uint8*)prDst;
  const uint32 size = spImageRGBub->sizeofMap();
  iprFunction->Transform(prDst, prSrc, size, RT_UINT8);

  elxFilterChannel(*spImageRGBub, iChannelMask);

  return spImageRGBub;

} // elxCreateImageRGBub


//----------------------------------------------------------------------------
//  elxCreateImageRGB : create an ImageRGB<T> from an AbstractImage
//  ISO resolution
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
ExportedByImage boost::shared_ptr<AbstractImage> 
  elxCreateImageRGB(
    const AbstractImage& iImage,
    EBayerToColorConversion iMethod,
    EBayerMatrix iBayer,
    uint32 iChannelMask)
{
  if (!iImage.IsL())
    return boost::shared_ptr<AbstractImage>();

  const EResolution res = iImage.GetResolution();

  // get Grey image
  boost::shared_ptr<AbstractImage> spImageL = elxCreateImage(iImage);
  if (NULL == spImageL.get()) 
    return boost::shared_ptr<AbstractImage>();

  switch(res)
  {
    case RT_UINT8:
    {
      spImageL = elxCreateImage(iImage, RT_UINT8);
      if (NULL == spImageL.get()) return boost::shared_ptr<AbstractImage>();

      // transform to uint8 rgb according demosaicing method
      boost::shared_ptr<ImageRGBub> spImageRGB = 
        boost::dynamic_pointer_cast<ImageRGBub, AbstractImage>(
          elxGetBayerHandler(*spImageL).
            CreateRGB(*spImageL, iBayer, iMethod));
      spImageL.reset();
      return spImageRGB;
    }

    case RT_UINT16:
    {
      // transform to uint16 rgb according demosaicing method
      boost::shared_ptr<ImageRGBus> spImageRGB = 
        boost::dynamic_pointer_cast<ImageRGBus, AbstractImage>(
          elxGetBayerHandler(*spImageL).
            CreateRGB(*spImageL, iBayer, iMethod));
      spImageL.reset();
      return spImageRGB;
    }

    case RT_INT32:
    {
      // transform to uint8 rgb according demosaicing method
      boost::shared_ptr<ImageRGBi> spImageRGB = 
        boost::dynamic_pointer_cast<ImageRGBi, AbstractImage>(
          elxGetBayerHandler(*spImageL).
            CreateRGB(*spImageL, iBayer, iMethod));
      spImageL.reset();
      return spImageRGB;
    }

    case RT_Float:
    {
      // transform to uint8 rgb according demosaicing method
      boost::shared_ptr<ImageRGBf> spImageRGB = 
        boost::dynamic_pointer_cast<ImageRGBf, AbstractImage>(
          elxGetBayerHandler(*spImageL).
            CreateRGB(*spImageL, iBayer, iMethod));
      spImageL.reset();
      return spImageRGB;
    }

    case RT_Double:
    {
      // transform to uint8 rgb according demosaicing method
      boost::shared_ptr<ImageRGBd> spImageRGB = 
        boost::dynamic_pointer_cast<ImageRGBd, AbstractImage>(
          elxGetBayerHandler(*spImageL).
            CreateRGB(*spImageL, iBayer, iMethod));
      spImageL.reset();
      return spImageRGB;
    }

    default: return boost::shared_ptr<AbstractImage>();
  }

  return boost::shared_ptr<AbstractImage>();

} // elxCreateImageRGB


//----------------------------------------------------------------------------
boost::shared_ptr<AbstractImage> 
  elxCreateZoomed(
    const AbstractImage& iImage, 
    uint32 iZoom, 
    ProgressNotifier& iNotifier)
{
  return elxGetGeometryHandler(iImage).
    CreateZoomed(iImage, iZoom, iNotifier);
}

//----------------------------------------------------------------------------
boost::shared_ptr<AbstractImage> 
  elxCreateResized(
    const AbstractImage& iImage, 
    uint32 iWidth, 
    uint32 iHeight, 
    ProgressNotifier& iNotifier)
{
  return elxGetGeometryHandler(iImage).
    CreateResized(iImage, iWidth, iHeight, iNotifier);
}

//----------------------------------------------------------------------------
//  elxCreateThumbnailImage
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const AbstractImage& iImage :
//  Out :-
//----------------------------------------------------------------------------
boost::shared_ptr<AbstractImage> 
  elxCreateThumbnailImage(
    const AbstractImage& iImage,
    uint32 iWidth,
    uint32 iHeight,
    bool ibConverveAspectRatio,
    ProgressNotifier& iNotifier)
{
  // --- checks valid image size ---
  if (!iImage.IsValid())
    return boost::shared_ptr<AbstractImage>();

  // --- check new dimension ---
  if ((iWidth <= 0) || (iHeight <= 0))
    return boost::shared_ptr<AbstractImage>();

  // --- creates image to fit in (iWidth, iHeight) ---
  uint32 imgWidth  = iImage.GetWidth();
  uint32 imgHeight = iImage.GetHeight();

  uint32 newWidth  = iWidth;
  uint32 newHeight = iHeight;

  if (ibConverveAspectRatio)
  {
    if (imgWidth > imgHeight)
    {
      newHeight = newWidth * imgHeight / imgWidth;
      if (newHeight > iHeight)
      {
        newHeight = iHeight;
        newWidth = newHeight * imgWidth / imgHeight;
      }
    }
    else
    {
      newWidth = newHeight * imgWidth / imgHeight;
      if (newWidth > iWidth)
      {
        newWidth = iWidth;
        newHeight = newWidth * imgHeight / imgWidth;
      }
    }
  }

  return elxGetGeometryHandler(iImage).
    CreateResized(iImage, newWidth, newHeight, iNotifier);

} // CreateThumbnailImage



//----------------------------------------------------------------------------
//  elxSplit
//----------------------------------------------------------------------------
// Valid input are :
// ImageLA<T> ouput is ImageL<T> L and ImageL<T> A
// ImageComplex<T> ouput is ImageL<T> Im and ImageL<T> Re
// ImageRGBA<T> ouput is ImageRGB<T> and ImageL<T> A
//----------------------------------------------------------------------------
bool elxSplit(
    const AbstractImage& iImage,
    AbstractImage*& opnChannel1,
    AbstractImage*& opnChannel2)
{
  switch(iImage.GetPixelFormat())
  {
    case PF_LAub:
    {
      ImageImpl<PixelLAub>& image = (ImageImpl<PixelLAub>&)iImage;
      ImageImpl< PixelLub > * pnL = new ImageImpl< PixelLub >();
      ImageImpl< PixelLub > * pnA = new ImageImpl< PixelLub >();
      elxSplit(image, *pnL,*pnA);
      opnChannel1 = pnL; opnChannel2 = pnA;
      return true;
    }
    case PF_LAus:
    {
      ImageImpl<PixelLAus>& image = (ImageImpl<PixelLAus>&)iImage;
      ImageImpl< PixelLus > * pnL = new ImageImpl< PixelLus >();
      ImageImpl< PixelLus > * pnA = new ImageImpl< PixelLus >();
      elxSplit(image, *pnL,*pnA);
      opnChannel1 = pnL; opnChannel2 = pnA;
      return true;
    }
    case PF_LAi:
    {
      ImageImpl<PixelLAi>& image = (ImageImpl<PixelLAi>&)iImage;
      ImageImpl< PixelLi > * pnL = new ImageImpl< PixelLi >();
      ImageImpl< PixelLi > * pnA = new ImageImpl< PixelLi >();
      elxSplit(image, *pnL,*pnA);
      opnChannel1 = pnL; opnChannel2 = pnA;
      return true;
    }
    case PF_LAf:
    {
      ImageImpl<PixelLAf>& image = (ImageImpl<PixelLAf>&)iImage;
      ImageImpl< PixelLf > * pnL = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnA = new ImageImpl< PixelLf >();
      elxSplit(image, *pnL,*pnA);
      opnChannel1 = pnL; opnChannel2 = pnA;
      return true;
    }
    case PF_LAd:
    {
      ImageImpl<PixelLAd>& image = (ImageImpl<PixelLAd>&)iImage;
      ImageImpl< PixelLd > * pnL = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnA = new ImageImpl< PixelLd >();
      elxSplit(image, *pnL,*pnA);
      opnChannel1 = pnL; opnChannel2 = pnA;
      return true;
    }
#ifdef elxUSE_ImageComplex
    case PF_CPLXi:
    {
      ImageImpl<PixelComplexi>& image = (ImageImpl<PixelComplexi>&)iImage;
      ImageImpl< PixelLi > * pnRe = new ImageImpl< PixelLi >();
      ImageImpl< PixelLi > * pnIm = new ImageImpl< PixelLi >();
      elxSplit(image, *pnRe,*pnIm);
      opnChannel1 = pnRe; opnChannel2 = pnIm;
      return true;
    }
    case PF_CPLXf:
    {
      ImageImpl<PixelComplexf>& image = (ImageImpl<PixelComplexf>&)iImage;
      ImageImpl< PixelLf > * pnRe = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnIm = new ImageImpl< PixelLf >();
      elxSplit(image, *pnRe,*pnIm);
      opnChannel1 = pnRe; opnChannel2 = pnIm;
      return true;
    }
    case PF_CPLXd:
    {
      ImageImpl<PixelComplexd>& image = (ImageImpl<PixelComplexd>&)iImage;
      ImageImpl< PixelLd > * pnRe = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnIm = new ImageImpl< PixelLd >();
      elxSplit(image, *pnRe,*pnIm);
      opnChannel1 = pnRe; opnChannel2 = pnIm;
      return true;
    }
#else
    case PF_CPLXi:
    case PF_CPLXf:
    case PF_CPLXd:
      return false;
#endif

    case PF_RGBAub:
    {
      ImageImpl<PixelRGBAub>& image = (ImageImpl<PixelRGBAub>&)iImage;
      ImageImpl< PixelRGBub > * pnRGB = new ImageImpl< PixelRGBub >();
      ImageImpl< PixelLub > * pnA = new ImageImpl< PixelLub >();
      elxSplit(image, *pnRGB,*pnA);
      opnChannel1 = pnRGB; opnChannel2 = pnA;
      return true;
    }
    case PF_RGBAus:
    {
      ImageImpl<PixelRGBAus>& image = (ImageImpl<PixelRGBAus>&)iImage;
      ImageImpl< PixelRGBus > * pnRGB = new ImageImpl< PixelRGBus >();
      ImageImpl< PixelLus > * pnA = new ImageImpl< PixelLus >();
      elxSplit(image, *pnRGB,*pnA);
      opnChannel1 = pnRGB; opnChannel2 = pnA;
      return true;
    }
    case PF_RGBAi:
    {
      ImageImpl<PixelRGBAi>& image = (ImageImpl<PixelRGBAi>&)iImage;
      ImageImpl< PixelRGBi > * pnRGB = new ImageImpl< PixelRGBi >();
      ImageImpl< PixelLi > * pnA = new ImageImpl< PixelLi >();
      elxSplit(image, *pnRGB,*pnA);
      opnChannel1 = pnRGB; opnChannel2 = pnA;
      return true;
    }
    case PF_RGBAf:
    {
      ImageImpl<PixelRGBAf>& image = (ImageImpl<PixelRGBAf>&)iImage;
      ImageImpl< PixelRGBf > * pnRGB = new ImageImpl< PixelRGBf >();
      ImageImpl< PixelLf > * pnA = new ImageImpl< PixelLf >();
      elxSplit(image, *pnRGB,*pnA);
      opnChannel1 = pnRGB; opnChannel2 = pnA;
      return true;
    }
    case PF_RGBAd:
    {
      ImageImpl<PixelRGBAd>& image = (ImageImpl<PixelRGBAd>&)iImage;
      ImageImpl< PixelRGBd > * pnRGB = new ImageImpl< PixelRGBd >();
      ImageImpl< PixelLd > * pnA = new ImageImpl< PixelLd >();
      elxSplit(image, *pnRGB,*pnA);
      opnChannel1 = pnRGB; opnChannel2 = pnA;
      return true;
    }
    default:
      return false;
  }

} // elxSplit


//----------------------------------------------------------------------------
//  elxSplit : Split iImage into 3 channels : oChannel1, oChannel2 and oChannel3
//----------------------------------------------------------------------------
// Valid input are :
// ImageRGB<T> ouput is ImageL<T> R, ImageL<T> G and ImageL<T> B
// ImageHLS<T> ouput is ImageL<T> H, ImageL<T> L and ImageL<T> S
// ImageXYZ<T> ouput is ImageL<T> X, ImageL<T> Y and ImageL<T> Z
// ImageLuv<T> ouput is ImageL<T> L, ImageL<T> u and ImageL<T> v
// ImageLab<T> ouput is ImageL<T> L, ImageL<T> a and ImageL<T> b
//----------------------------------------------------------------------------
bool elxSplit(
    const AbstractImage& iImage,
    AbstractImage*& opnChannel1,
    AbstractImage*& opnChannel2,
    AbstractImage*& opnChannel3)
{
  switch(iImage.GetPixelFormat())
  {
    case PF_RGBub:
    {
      ImageImpl<PixelRGBub>& image = (ImageImpl<PixelRGBub>&)iImage;
      ImageImpl< PixelLub > * pnR = new ImageImpl< PixelLub >();
      ImageImpl< PixelLub > * pnG = new ImageImpl< PixelLub >();
      ImageImpl< PixelLub > * pnB = new ImageImpl< PixelLub >();
      elxSplit(image, *pnR,*pnG,*pnB);
      opnChannel1 = pnR; opnChannel2 = pnG; opnChannel3 = pnB;
      return true;
    }
    case PF_RGBus:
    {
      ImageImpl<PixelRGBus>& image = (ImageImpl<PixelRGBus>&)iImage;
      ImageImpl< PixelLus > * pnR = new ImageImpl< PixelLus >();
      ImageImpl< PixelLus > * pnG = new ImageImpl< PixelLus >();
      ImageImpl< PixelLus > * pnB = new ImageImpl< PixelLus >();
      elxSplit(image, *pnR,*pnG,*pnB);
      opnChannel1 = pnR; opnChannel2 = pnG; opnChannel3 = pnB;
      return true;
    }
    case PF_RGBi:
    {
      ImageImpl<PixelRGBi>& image = (ImageImpl<PixelRGBi>&)iImage;
      ImageImpl< PixelLi > * pnR = new ImageImpl< PixelLi >();
      ImageImpl< PixelLi > * pnG = new ImageImpl< PixelLi >();
      ImageImpl< PixelLi > * pnB = new ImageImpl< PixelLi >();
      elxSplit(image, *pnR,*pnG,*pnB);
      opnChannel1 = pnR; opnChannel2 = pnG; opnChannel3 = pnB;
      return true;
    }
    case PF_RGBf:  
    {
      ImageImpl<PixelRGBf>& image = (ImageImpl<PixelRGBf>&)iImage;
      ImageImpl< PixelLf > * pnR = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnG = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnB = new ImageImpl< PixelLf >();
      elxSplit(image, *pnR,*pnG,*pnB);
      opnChannel1 = pnR; opnChannel2 = pnG; opnChannel3 = pnB;
      return true;
    }
    case PF_RGBd:  
    {
      ImageImpl<PixelRGBd>& image = (ImageImpl<PixelRGBd>&)iImage;
      ImageImpl< PixelLd > * pnR = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnG = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnB = new ImageImpl< PixelLd >();
      elxSplit(image, *pnR,*pnG,*pnB);
      opnChannel1 = pnR; opnChannel2 = pnG; opnChannel3 = pnB;
      return true;
    }
#ifdef elxUSE_ImageHLS
    case PF_HLSf:
    {
      ImageImpl<PixelHLSf>& image = (ImageImpl<PixelHLSf>&)iImage;
      ImageImpl< PixelLf > * pnH = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnL = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnS = new ImageImpl< PixelLf >();
      elxSplit(image, *pnH,*pnL,*pnS);
      opnChannel1 = pnH; opnChannel2 = pnL; opnChannel3 = pnS;
      return true;
    }
    case PF_HLSd:
    {
      ImageImpl<PixelHLSd>& image = (ImageImpl<PixelHLSd>&)iImage;
      ImageImpl< PixelLd > * pnH = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnL = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnS = new ImageImpl< PixelLd >();
      elxSplit(image, *pnH,*pnL,*pnS);
      opnChannel1 = pnH; opnChannel2 = pnL; opnChannel3 = pnS;
      return true;
    }
#else
    case PF_HLSf:
    case PF_HLSd:
      return false;
#endif

#ifdef elxUSE_ImageXYZ
    case PF_XYZf:
    {
      ImageImpl<PixelXYZf>& image = (ImageImpl<PixelXYZf>&)iImage;
      ImageImpl< PixelLf > * pnX = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnY = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnZ = new ImageImpl< PixelLf >();
      elxSplit(image, *pnX,*pnY,*pnZ);
      opnChannel1 = pnX; opnChannel2 = pnY; opnChannel3 = pnZ;
      return true;
    }
    case PF_XYZd:
    {
      ImageImpl<PixelXYZd>& image = (ImageImpl<PixelXYZd>&)iImage;
      ImageImpl< PixelLd > * pnX = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnY = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnZ = new ImageImpl< PixelLd >();
      elxSplit(image, *pnX,*pnY,*pnZ);
      opnChannel1 = pnX; opnChannel2 = pnY; opnChannel3 = pnZ;
      return true;
    }
#else
    case PF_XYZf:
    case PF_XYZd:
      return false;
#endif

#ifdef elxUSE_ImageLuv
    case PF_Luvf:
    {
      ImageImpl<PixelLuvf>& image = (ImageImpl<PixelLuvf>&)iImage;
      ImageImpl< PixelLf > * pnL = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnU = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnV = new ImageImpl< PixelLf >();
      elxSplit(image, *pnL,*pnU,*pnV);
      opnChannel1 = pnL; opnChannel2 = pnU; opnChannel3 = pnV;
      return true;
    }
    case PF_Luvd:
    {
      ImageImpl<PixelLuvd>& image = (ImageImpl<PixelLuvd>&)iImage;
      ImageImpl< PixelLd > * pnL = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnU = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnV = new ImageImpl< PixelLd >();
      elxSplit(image, *pnL,*pnU,*pnV);
      opnChannel1 = pnL; opnChannel2 = pnU; opnChannel3 = pnV;
      return true;
    }
#else
    case PF_Luvf:
    case PF_Luvd:
      return false;
#endif

#ifdef elxUSE_ImageLab
    case PF_Labf:
    {
      ImageImpl<PixelLabf>& image = (ImageImpl<PixelLabf>&)iImage;
      ImageImpl< PixelLf > * pnL = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnA = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnB = new ImageImpl< PixelLf >();
      elxSplit(image, *pnL,*pnA,*pnB);
      opnChannel1 = pnL; opnChannel2 = pnA; opnChannel3 = pnB;
      return true;
    }
    case PF_Labd:
    {
      ImageImpl<PixelLabd>& image = (ImageImpl<PixelLabd>&)iImage;
      ImageImpl< PixelLd > * pnL = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnA = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnB = new ImageImpl< PixelLd >();
      elxSplit(image, *pnL,*pnA,*pnB);
      opnChannel1 = pnL; opnChannel2 = pnA; opnChannel3 = pnB;
      return true;
    }
#else
    case PF_Labf:
    case PF_Labd:
      return false;
#endif

#ifdef elxUSE_ImageLch
    case PF_Lchf:
    {
      ImageImpl<PixelLchf>& image = (ImageImpl<PixelLchf>&)iImage;
      ImageImpl< PixelLf > * pnL = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnC = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnH = new ImageImpl< PixelLf >();
      elxSplit(image, *pnL,*pnC,*pnH);
      opnChannel1 = pnL; opnChannel2 = pnC; opnChannel3 = pnH;
      return true;
    }
    case PF_Lchd:
    {
      ImageLchd& image = (ImageLchd&)iImage;
      ImageLd * pnL = new ImageLd();
      ImageLd * pnC = new ImageLd();
      ImageLd * pnH = new ImageLd();
      elxSplit(image, *pnL,*pnC,*pnH);
      opnChannel1 = pnL; opnChannel2 = pnC; opnChannel3 = pnH;
      return true;
    }
#else
    case PF_Lchf:
    case PF_Lchd:
      return false;
#endif

#ifdef elxUSE_ImageHLab
    case PF_HLabf:
    {
      ImageImpl<PixelHLabf>& image = (ImageImpl<PixelHLabf>&)iImage;
      ImageImpl< PixelLf > * pnL = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnA = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnB = new ImageImpl< PixelLf >();
      elxSplit(image, *pnL,*pnA,*pnB);
      opnChannel1 = pnL; opnChannel2 = pnA; opnChannel3 = pnB;
      return true;
    }
    case PF_HLabd:
    {
      ImageImpl<PixelHLabd>& image = (ImageImpl<PixelHLabd>&)iImage;
      ImageImpl< PixelLd > * pnL = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnA = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnB = new ImageImpl< PixelLd >();
      elxSplit(image, *pnL,*pnA,*pnB);
      opnChannel1 = pnL; opnChannel2 = pnA; opnChannel3 = pnB;
      return true;
    }
#else
    case PF_HLabf:
    case PF_HLabd:
      return false;
#endif

    default:
      return false;
  }

} // elxSplit


//----------------------------------------------------------------------------
//  elxSplit
//----------------------------------------------------------------------------
/// Valid input are :
/// ImageRGBA<T> ouput is ImageL<T> R, ImageL<T> G, ImageL<T> B and ImageL<T> A
//----------------------------------------------------------------------------
bool elxSplit(
    const AbstractImage& iImage,
    AbstractImage*& opnChannel1,
    AbstractImage*& opnChannel2,
    AbstractImage*& opnChannel3,
    AbstractImage*& opnChannel4)
{
  switch(iImage.GetPixelFormat())
  {
    case PF_RGBAub:
    {
      ImageImpl<PixelRGBAub>& image = (ImageImpl<PixelRGBAub>&)iImage;
      ImageImpl< PixelLub > * pnR = new ImageImpl< PixelLub >();
      ImageImpl< PixelLub > * pnG = new ImageImpl< PixelLub >();
      ImageImpl< PixelLub > * pnB = new ImageImpl< PixelLub >();
      ImageImpl< PixelLub > * pnA = new ImageImpl< PixelLub >();
      elxSplit(image, *pnR,*pnG,*pnB,*pnA);
      opnChannel1 = pnR; opnChannel2 = pnG; opnChannel3 = pnB; opnChannel4 = pnA;
      return true;
    }
    case PF_RGBAus:
    {
      ImageImpl<PixelRGBAus>& image = (ImageImpl<PixelRGBAus>&)iImage;
      ImageImpl< PixelLus > * pnR = new ImageImpl< PixelLus >();
      ImageImpl< PixelLus > * pnG = new ImageImpl< PixelLus >();
      ImageImpl< PixelLus > * pnB = new ImageImpl< PixelLus >();
      ImageImpl< PixelLus > * pnA = new ImageImpl< PixelLus >();
      elxSplit(image, *pnR,*pnG,*pnB,*pnA);
      opnChannel1 = pnR; opnChannel2 = pnG; opnChannel3 = pnB; opnChannel4 = pnA;
      return true;
    }
    case PF_RGBAi:
    {
      ImageImpl<PixelRGBAi>& image = (ImageImpl<PixelRGBAi>&)iImage;
      ImageImpl< PixelLi > * pnR = new ImageImpl< PixelLi >();
      ImageImpl< PixelLi > * pnG = new ImageImpl< PixelLi >();
      ImageImpl< PixelLi > * pnB = new ImageImpl< PixelLi >();
      ImageImpl< PixelLi > * pnA = new ImageImpl< PixelLi >();
      elxSplit(image, *pnR,*pnG,*pnB,*pnA);
      opnChannel1 = pnR; opnChannel2 = pnG; opnChannel3 = pnB; opnChannel4 = pnA;
      return true;
    }
    case PF_RGBAf:
    {
      ImageImpl<PixelRGBAf>& image = (ImageImpl<PixelRGBAf>&)iImage;
      ImageImpl< PixelLf > * pnR = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnG = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnB = new ImageImpl< PixelLf >();
      ImageImpl< PixelLf > * pnA = new ImageImpl< PixelLf >();
      elxSplit(image, *pnR,*pnG,*pnB,*pnA);
      opnChannel1 = pnR; opnChannel2 = pnG; opnChannel3 = pnB; opnChannel4 = pnA;
      return true;
    }
    case PF_RGBAd:
    {
      ImageImpl<PixelRGBAd>& image = (ImageImpl<PixelRGBAd>&)iImage;
      ImageImpl< PixelLd > * pnR = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnG = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnB = new ImageImpl< PixelLd >();
      ImageImpl< PixelLd > * pnA = new ImageImpl< PixelLd >();
      elxSplit(image, *pnR,*pnG,*pnB,*pnA);
      opnChannel1 = pnR; opnChannel2 = pnG; opnChannel3 = pnB; opnChannel4 = pnA;
      return true;
    }
    default:
      return false;
  }

} // elxSplit


//----------------------------------------------------------------------------
//  elxFilterChannel
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
bool elxFilterChannel(
    AbstractImage& ioImage, 
    uint32 iChannelMask)
{
  if (PF_RGBub != ioImage.GetPixelFormat())
    return false;

  const uint32 nChannels = ioImage.GetChannelCount();
  uint32 mask = (1 << nChannels) - 1;

  iChannelMask &= CM_Channel012;

  // all possible channels are activate, no need to filter
  if (iChannelMask == mask)
    return true;

  if (!ioImage.IsValid())
    return false;

  ImageRGBub& image = elxDowncast<PixelRGBub>(ioImage);
  PixelRGBub * prDst = image.GetPixel();
  PixelRGBub * prEnd = image.GetPixelEnd();

  switch (iChannelMask)
  {
    case CM_Channel0:
      // keep channel0, remove channel1 & channel2
      do { prDst->_channel[1] = prDst->_channel[2] = 0; } while (++prDst != prEnd);
      break;

    case CM_Channel1:
      // keep channel1, remove channel0 & channel2
      do { prDst->_channel[0] = 0; prDst->_channel[2] = 0; } while (++prDst != prEnd);
      break;

    case CM_Channel2:
      // keep channel2, remove channel0 & channel1
      do { prDst->_channel[0] = 0; prDst->_channel[1] = 0; } while (++prDst != prEnd);
      break;

    case CM_Channel01:
      // keep channel0, channel1 remove channel2
      do { prDst->_channel[2] = 0; } while (++prDst != prEnd);
      break;

    case CM_Channel02:
      // keep channel0, channel2 remove channel1
      do { prDst->_channel[1] = 0; } while (++prDst != prEnd);
      break;

    case CM_Channel12:
      // keep channel1, channel2 remove channel0
      do { prDst->_channel[0] = 0; } while (++prDst != prEnd);
      break;
    default:
      return false;
  }
  return true;

} // elxFilterChannel


//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EBorderFill iBorder)
{
  static const char * ms_lut[4] =
  {
    "Black", "White", "Nearest", "Cycle"
  };
  return ms_lut[iBorder];

} // elxToString


} // namespace Image
} // namespace eLynx
