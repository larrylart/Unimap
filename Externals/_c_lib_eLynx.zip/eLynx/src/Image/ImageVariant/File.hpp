//============================================================================
//  ImageVariant/File.hpp                              Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/ImageFileManager.h>

namespace eLynx {
namespace Image {

//============================================================================
//                             Image file access
//============================================================================
//----------------------------------------------------------------------------
//  constructor with filename
//----------------------------------------------------------------------------
ImageVariant::ImageVariant(
    const char * iprFilename,
    ImageFileInfo * oprInfo,
    ProgressNotifier& iNotifier) :
  _spAbstractImpl(),
  _Bayer(BM_None)
{
  Load(iprFilename, oprInfo, iNotifier);
}

//----------------------------------------------------------------------------
//  CanLoad
//----------------------------------------------------------------------------
bool ImageVariant::CanLoad(
    const char * iprFilename,
    ImageFileInfo * oprInfo,
    bool ibPreview) const
{
  if (NULL == iprFilename) return false;
  return the_ImageFileManager.CanImport(iprFilename, oprInfo, ibPreview);

} // CanLoad


//----------------------------------------------------------------------------
//  Load
//----------------------------------------------------------------------------
bool ImageVariant::Load(
    const char * iprFilename,
    ImageFileInfo * oprInfo,
    ProgressNotifier& iNotifier)
{
  Invalidate();
  if (NULL == iprFilename) return false;
  return the_ImageFileManager.Import(*this, iprFilename, oprInfo, iNotifier);

} // Load


//----------------------------------------------------------------------------
//  CanSave
//----------------------------------------------------------------------------
bool ImageVariant::CanSave(const char * iprFilename) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (NULL == iprFilename) return false;
  return the_ImageFileManager.CanExport( *this, iprFilename);

} // CanSave


//----------------------------------------------------------------------------
//  Save
//----------------------------------------------------------------------------
bool ImageVariant::Save(
    const char * iprFilename, 
    ProgressNotifier& iNotifier,
    const ImageFileOptions *iprOptions) const
{
  if (NULL == iprFilename)
    return false;

  if (!elxUseable(_spAbstractImpl.get()))
    return false;

  if (!the_ImageFileManager.CanExport(*this, iprFilename))
    return false;

  return the_ImageFileManager.Export(*this, iprFilename, iNotifier, iprOptions);
    
} // Save

} // namespace Image
} // namespace eLynx
