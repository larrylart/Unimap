//============================================================================
//  ImageVariant/SplitMerge.hpp                        Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                          Split & Merge planes
//============================================================================

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                                   Split
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Split # 2 planes
//----------------------------------------------------------------------------
bool ImageVariant::Split(
    ImageVariant& oPlane1, 
    ImageVariant& oPlane2)
{
  if (!elxUseable(_spAbstractImpl.get()))
    return false;

  AbstractImage * pnPlane1 = NULL;
  AbstractImage * pnPlane2 = NULL;

  bool bSuccess = elxSplit(*_spAbstractImpl, pnPlane1, pnPlane2);
  if (!bSuccess)
  {
    elxSAFE_DELETE(pnPlane1); 
    elxSAFE_DELETE(pnPlane2); 
    return false;
  }
  oPlane1 = *pnPlane1;  elxSAFE_DELETE(pnPlane1);
  oPlane2 = *pnPlane2;  elxSAFE_DELETE(pnPlane2);

  return true;

} // Split


//----------------------------------------------------------------------------
//  Split # 3 planes
//----------------------------------------------------------------------------
bool ImageVariant::Split(
    ImageVariant& oPlane1, 
    ImageVariant& oPlane2, 
    ImageVariant& oPlane3)
{
  if (!elxUseable(_spAbstractImpl.get()))
    return false;

  AbstractImage * pnPlane1 = NULL;
  AbstractImage * pnPlane2 = NULL;
  AbstractImage * pnPlane3 = NULL;

  bool bSuccess = elxSplit(*_spAbstractImpl, pnPlane1, pnPlane2, pnPlane3);
  if (!bSuccess)
  {
    elxSAFE_DELETE(pnPlane1); 
    elxSAFE_DELETE(pnPlane2); 
    elxSAFE_DELETE(pnPlane3); 
    return false;
  }
  oPlane1 = *pnPlane1;  elxSAFE_DELETE(pnPlane1);
  oPlane2 = *pnPlane2;  elxSAFE_DELETE(pnPlane2);
  oPlane3 = *pnPlane3;  elxSAFE_DELETE(pnPlane3);

  return true;

} // Split


//----------------------------------------------------------------------------
//  Split # 4 planes
//----------------------------------------------------------------------------
bool ImageVariant::Split(
    ImageVariant& oPlane1, 
    ImageVariant& oPlane2, 
    ImageVariant& oPlane3, 
    ImageVariant& oPlane4)
{
  if (!elxUseable(_spAbstractImpl.get()))
    return false;

  AbstractImage * pnPlane1 = NULL;
  AbstractImage * pnPlane2 = NULL;
  AbstractImage * pnPlane3 = NULL;
  AbstractImage * pnPlane4 = NULL;

  bool bSuccess = elxSplit(*_spAbstractImpl, pnPlane1, pnPlane2, pnPlane3, pnPlane4);
  if (!bSuccess)
  {
    elxSAFE_DELETE(pnPlane1);
    elxSAFE_DELETE(pnPlane2);
    elxSAFE_DELETE(pnPlane3);
    elxSAFE_DELETE(pnPlane4);
    return false;
  }
  oPlane1 = *pnPlane1;  elxSAFE_DELETE(pnPlane1);
  oPlane2 = *pnPlane2;  elxSAFE_DELETE(pnPlane2);
  oPlane3 = *pnPlane3;  elxSAFE_DELETE(pnPlane3);
  oPlane3 = *pnPlane4;  elxSAFE_DELETE(pnPlane4);

  return true;

} // Split


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                                   Merge
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  contructor # merge 2 planes 
//  L<T> + L<T> = LA<T>
//  L<T> + L<T> = CPLX<T>
//  RGB<T> + L<T> = RGBA<T>
//----------------------------------------------------------------------------
ImageVariant::ImageVariant(
    const ImageVariant& iImage1, 
    const ImageVariant& iImage2,
    bool ibComplex) :
  _spAbstractImpl(),
  _Bayer(BM_None)
{
  // check input image validity
  if (!iImage1.IsValid() || !iImage2.IsValid())
    return;

  // check resolution
  const EResolution resolution = iImage1.GetResolution();
  if (resolution != iImage2.GetResolution()) return;

  // check input images have same dimensions
  const uint32 w = iImage1.GetWidth();
  const uint32 h = iImage1.GetHeight();
  if (w != iImage2.GetWidth()) return;
  if (h != iImage2.GetHeight()) return;

  if (iImage1.IsL() && iImage2.IsL())
  {
    // L<T> + L<T> = LA<T>
    switch (resolution)
    {
      case RT_UINT8:
      {
        const ImageLub& L1 = (const ImageLub&)(*iImage1.GetImpl());
        const ImageLub& L2 = (const ImageLub&)(*iImage2.GetImpl());
        _spAbstractImpl.reset(new ImageLAub(w,h));
        elxMerge((ImageLAub&)(*_spAbstractImpl), L1, L2);
        elxASSERT(false == ibComplex);
        return;
      }
      case RT_UINT16:
      {
        const ImageLus& L1 = (const ImageLus&)(*iImage1.GetImpl());
        const ImageLus& L2 = (const ImageLus&)(*iImage2.GetImpl());
        _spAbstractImpl.reset(new ImageLAus(w,h));
        elxMerge((ImageLAus&)(*_spAbstractImpl), L1, L2);
        elxASSERT(false == ibComplex);
        return;
      }
      case RT_INT32:
      {
        const ImageLi& L1 = (const ImageLi&)(*iImage1.GetImpl());
        const ImageLi& L2 = (const ImageLi&)(*iImage2.GetImpl());
        if (ibComplex)
        {
#ifdef elxUSE_ImageComplex
          _spAbstractImpl.reset(new ImageComplexi(w,h));
          elxMerge((ImageComplexi&)(*_spAbstractImpl), L1, L2);
#endif
        }
        else
        {
          _spAbstractImpl.reset(new ImageLAi(w,h));
          elxMerge((ImageLAi&)(*_spAbstractImpl), L1, L2);
        }
        return;
      }
      case RT_Float:
      {
        const ImageLf& L1 = (const ImageLf&)(*iImage1.GetImpl());
        const ImageLf& L2 = (const ImageLf&)(*iImage2.GetImpl());
        if (ibComplex)
        {
#ifdef elxUSE_ImageComplex
          _spAbstractImpl.reset(new ImageComplexf(w,h));
          elxMerge((ImageComplexf&)(*_spAbstractImpl), L1, L2);
#endif
        }
        else
        {
          _spAbstractImpl.reset(new ImageLAf(w,h));
          elxMerge((ImageLAf&)(*_spAbstractImpl), L1, L2);
        }
        return;
      }
      case RT_Double:
      {
        const ImageLd& L1 = (const ImageLd&)(*iImage1.GetImpl());
        const ImageLd& L2 = (const ImageLd&)(*iImage2.GetImpl());
        if (ibComplex)
        {
#ifdef elxUSE_ImageComplex
          _spAbstractImpl.reset(new ImageComplexd(w,h));
          elxMerge((ImageComplexd&)(*_spAbstractImpl), L1, L2);
#endif
        }
        else
        {
          _spAbstractImpl.reset(new ImageLAd(w,h));
          elxMerge((ImageLAd&)(*_spAbstractImpl), L1, L2);
        }
        return;
      }
      default: // No sence
        elxFIXME; break;
    }
  }

  const bool bOneL = (iImage1.IsL() || iImage2.IsL());
  const bool bOneRGB = (iImage1.IsRGB() || iImage2.IsRGB());
  if (bOneL && bOneRGB)
  {
    //  RGB<T> + L<T> = RGBA<T>
    const ImageVariant& imageL   = iImage1.IsL() ? iImage1 : iImage2;
    const ImageVariant& imageRGB = iImage1.IsL() ? iImage2 : iImage1;

    switch (resolution)
    {
      case RT_UINT8:
      {
        const ImageRGBub& RGB = (const ImageRGBub&)(*imageRGB.GetImpl());
        const ImageLub& L = (const ImageLub&)(*imageL.GetImpl());
        _spAbstractImpl.reset(new ImageRGBAub(w,h));
        elxMerge((ImageRGBAub&)(*_spAbstractImpl), RGB, L);
        return;
      }
      case RT_UINT16:
      {
        const ImageRGBus& RGB = (const ImageRGBus&)(*imageRGB.GetImpl());
        const ImageLus& L = (const ImageLus&)(*imageL.GetImpl());
        _spAbstractImpl.reset(new ImageRGBAus(w,h));
        elxMerge((ImageRGBAus&)(*_spAbstractImpl), RGB, L);
        return;
      }
      case RT_INT32:
      {
        const ImageRGBi& RGB = (const ImageRGBi&)(*imageRGB.GetImpl());
        const ImageLi& L = (const ImageLi&)(*imageL.GetImpl());
        _spAbstractImpl.reset(new ImageRGBAi(w,h));
        elxMerge((ImageRGBAi&)(*_spAbstractImpl), RGB, L);
        return;
      }
      case RT_Float:
      {
        const ImageRGBf& RGB = (const ImageRGBf&)(*imageRGB.GetImpl());
        const ImageLf& L = (const ImageLf&)(*imageL.GetImpl());
        _spAbstractImpl.reset(new ImageRGBAf(w,h));
        elxMerge((ImageRGBAf&)(*_spAbstractImpl), RGB, L);
        return;
      }
      case RT_Double:
      {
        const ImageRGBf& RGB = (const ImageRGBf&)(*imageRGB.GetImpl());
        const ImageLf& L = (const ImageLf&)(*imageL.GetImpl());
        _spAbstractImpl.reset(new ImageRGBAf(w,h));
        elxMerge((ImageRGBAf&)(*_spAbstractImpl), RGB, L);
        return;
      }
      default: // No sence
        elxFIXME; break;
    }
  }
  elxFIXME;
}

//----------------------------------------------------------------------------
//  contructor # merge 3 planes
//----------------------------------------------------------------------------
ImageVariant::ImageVariant(
    const ImageVariant& iImage1, 
    const ImageVariant& iImage2, 
    const ImageVariant& iImage3,
    EColorSpace iColorSpace) :
  _spAbstractImpl(),
  _Bayer(BM_None)
{
  // check input image validity
  if (!iImage1.IsValid() || !iImage2.IsValid() || !iImage3.IsValid())
    return;

  // check input images have same format
  const EPixelFormat format = iImage1.GetPixelFormat();
  if (format != iImage2.GetPixelFormat()) return;
  if (format != iImage3.GetPixelFormat()) return;

  // check input images have same dimensions
  const uint32 w = iImage1.GetWidth();
  const uint32 h = iImage1.GetHeight();
  if (w != iImage2.GetWidth()) return;
  if (w != iImage3.GetWidth()) return;
  if (h != iImage2.GetHeight()) return;
  if (h != iImage3.GetHeight()) return;

    // format must be luminance
  if ((format != PF_Lub) && (format != PF_Lus) && (format != PF_Li) && (format != PF_Lf) && (format != PF_Ld))
    return;

  switch (format)
  {
    case PF_Lub:
      if (CS_RGB == iColorSpace)
      {
        const ImageLub& L1 = (const ImageLub&)(*iImage1.GetImpl());
        const ImageLub& L2 = (const ImageLub&)(*iImage2.GetImpl());
        const ImageLub& L3 = (const ImageLub&)(*iImage3.GetImpl());
        _spAbstractImpl.reset(new ImageRGBub(w,h));
        elxMerge((ImageRGBub&)(*_spAbstractImpl), L1, L2, L3);
      }
      break;

    case PF_Lus:
      if (CS_RGB == iColorSpace)
      {
        const ImageLus& L1 = (const ImageLus&)(*iImage1.GetImpl());
        const ImageLus& L2 = (const ImageLus&)(*iImage2.GetImpl());
        const ImageLus& L3 = (const ImageLus&)(*iImage3.GetImpl());
        _spAbstractImpl.reset(new ImageRGBus(w,h));
        elxMerge((ImageRGBus&)(*_spAbstractImpl), L1, L2, L3);
      }
      break;

    case PF_Li:
      if (CS_RGB == iColorSpace)
      {
        const ImageLi& L1 = (const ImageLi&)(*iImage1.GetImpl());
        const ImageLi& L2 = (const ImageLi&)(*iImage2.GetImpl());
        const ImageLi& L3 = (const ImageLi&)(*iImage3.GetImpl());
        _spAbstractImpl.reset(new ImageRGBi(w,h));
        elxMerge((ImageRGBi&)(*_spAbstractImpl), L1, L2, L3);
      }
      break;

    case PF_Lf:
    {
      const ImageLf& L1 = (const ImageLf&)(*iImage1.GetImpl());
      const ImageLf& L2 = (const ImageLf&)(*iImage2.GetImpl());
      const ImageLf& L3 = (const ImageLf&)(*iImage3.GetImpl());

      switch(iColorSpace)
      {
        case CS_RGB:
          _spAbstractImpl.reset(new ImageRGBf(w,h));
          elxMerge((ImageRGBf&)(*_spAbstractImpl), L1, L2, L3);
          break;
        case CS_HLS:
          _spAbstractImpl.reset(new ImageHLSf(w,h));
          elxMerge((ImageHLSf&)(*_spAbstractImpl), L1, L2, L3);
          break;
#ifdef elxUSE_ImageXYZ
        case CS_CIE_XYZ:
          _spAbstractImpl.reset(new ImageXYZf(w,h));
          elxMerge((ImageXYZf&)(*_spAbstractImpl), L1, L2, L3);
          break;
#endif
#ifdef elxUSE_ImageLuv
        case CS_CIE_Luv:
          _spAbstractImpl.reset(new ImageLuvf(w,h));
          elxMerge((ImageLuvf&)(*_spAbstractImpl), L1, L2, L3);
          break;
#endif
        case CS_CIE_Lab:  
          _spAbstractImpl.reset(new ImageLabf(w,h));
          elxMerge((ImageLabf&)(*_spAbstractImpl), L1, L2, L3);
          break;

        default: elxFIXME;     
          break;
      }
      break;
    }

    case PF_Ld:
    {
      const ImageLd& L1 = (const ImageLd&)(*iImage1.GetImpl());
      const ImageLd& L2 = (const ImageLd&)(*iImage2.GetImpl());
      const ImageLd& L3 = (const ImageLd&)(*iImage3.GetImpl());

      switch(iColorSpace)
      {
        case CS_RGB:
          _spAbstractImpl.reset(new ImageRGBd(w,h));
          elxMerge((ImageRGBd&)(*_spAbstractImpl), L1, L2, L3);
          break;
        case CS_HLS:
          _spAbstractImpl.reset(new ImageHLSd(w,h));
          elxMerge((ImageHLSd&)(*_spAbstractImpl), L1, L2, L3);
          break;
#ifdef elxUSE_ImageXYZ
        case CS_CIE_XYZ:
          _spAbstractImpl.reset(new ImageXYZd(w,h));
          elxMerge((ImageXYZd&)(*_spAbstractImpl), L1, L2, L3);
          break;
#endif
#ifdef elxUSE_ImageLuv
        case CS_CIE_Luv:
          _spAbstractImpl.reset(new ImageLuvd(w,h));
          elxMerge((ImageLuvd&)(*_spAbstractImpl), L1, L2, L3);
          break;
#endif
        case CS_CIE_Lab:  
          _spAbstractImpl.reset(new ImageLabd(w,h));
          elxMerge((ImageLabd&)(*_spAbstractImpl), L1, L2, L3);
          break;
        default: elxFIXME;
          break;
      }
      break;
    }
    default:
      // No sence
      break;
  }
}


//----------------------------------------------------------------------------
//  contructor # merge 4 planes
//----------------------------------------------------------------------------
ImageVariant::ImageVariant(
    const ImageVariant& iImage1, 
    const ImageVariant& iImage2, 
    const ImageVariant& iImage3, 
    const ImageVariant& iImage4) :
  _spAbstractImpl(),
  _Bayer(BM_None)
{
  // check input image validity
  if (!iImage1.IsValid() || !iImage2.IsValid() || 
      !iImage3.IsValid() || !iImage3.IsValid())
    return;

  // check input images have same format
  const EPixelFormat format = iImage1.GetPixelFormat();
  if (format != iImage2.GetPixelFormat()) return;
  if (format != iImage3.GetPixelFormat()) return;
  if (format != iImage4.GetPixelFormat()) return;

  // check input images have same dimensions
  const uint32 w = iImage1.GetWidth();
  const uint32 h = iImage1.GetHeight();
  if (w != iImage2.GetWidth()) return;
  if (w != iImage3.GetWidth()) return;
  if (w != iImage4.GetWidth()) return;
  if (h != iImage2.GetHeight()) return;
  if (h != iImage3.GetHeight()) return;
  if (h != iImage4.GetHeight()) return;

  // format must be luminance
  if ((format != PF_Lub) && (format != PF_Lus) && (format != PF_Li) && (format != PF_Lf) && (format != PF_Ld))
    return;

  switch (format)
  {
    case PF_Lub:
    {
      const ImageLub& L1 = (const ImageLub&)(*iImage1.GetImpl());
      const ImageLub& L2 = (const ImageLub&)(*iImage2.GetImpl());
      const ImageLub& L3 = (const ImageLub&)(*iImage3.GetImpl());
      const ImageLub& L4 = (const ImageLub&)(*iImage4.GetImpl());
      _spAbstractImpl.reset(new ImageRGBAub(w,h));
      elxMerge((ImageRGBAub&)(*_spAbstractImpl), L1, L2, L3, L4);
      break;
    }

    case PF_Lus:
    {
      const ImageLus& L1 = (const ImageLus&)(*iImage1.GetImpl());
      const ImageLus& L2 = (const ImageLus&)(*iImage2.GetImpl());
      const ImageLus& L3 = (const ImageLus&)(*iImage3.GetImpl());
      const ImageLus& L4 = (const ImageLus&)(*iImage4.GetImpl());
      _spAbstractImpl.reset(new ImageRGBAus(w,h));
      elxMerge((ImageRGBAus&)(*_spAbstractImpl), L1, L2, L3, L4);
      break;
    }

    case PF_Li:
    {
      const ImageLi& L1 = (const ImageLi&)(*iImage1.GetImpl());
      const ImageLi& L2 = (const ImageLi&)(*iImage2.GetImpl());
      const ImageLi& L3 = (const ImageLi&)(*iImage3.GetImpl());
      const ImageLi& L4 = (const ImageLi&)(*iImage4.GetImpl());
      _spAbstractImpl.reset(new ImageRGBAi(w,h));
      elxMerge((ImageRGBAi&)(*_spAbstractImpl), L1, L2, L3, L4);
      break;
    }

    case PF_Lf:
    {
      const ImageLf& L1 = (const ImageLf&)(*iImage1.GetImpl());
      const ImageLf& L2 = (const ImageLf&)(*iImage2.GetImpl());
      const ImageLf& L3 = (const ImageLf&)(*iImage3.GetImpl());
      const ImageLf& L4 = (const ImageLf&)(*iImage4.GetImpl());
      _spAbstractImpl.reset(new ImageRGBAf(w,h));
      elxMerge((ImageRGBAf&)(*_spAbstractImpl), L1, L2, L3, L4);
      break;
    }

    case PF_Ld:
    {
      const ImageLd& L1 = (const ImageLd&)(*iImage1.GetImpl());
      const ImageLd& L2 = (const ImageLd&)(*iImage2.GetImpl());
      const ImageLd& L3 = (const ImageLd&)(*iImage3.GetImpl());
      const ImageLd& L4 = (const ImageLd&)(*iImage4.GetImpl());
      _spAbstractImpl.reset(new ImageRGBAd(w,h));
      elxMerge((ImageRGBAd&)(*_spAbstractImpl), L1, L2, L3, L4);
      break;
    }
    default:
      // No sence
      elxFIXME;
      break;
  }
}

//----------------------------------------------------------------------------
//  contructor # from a channel plane
//----------------------------------------------------------------------------
ImageVariant::ImageVariant(
    const ImageVariant& iImage,
    uint32 iPlane, 
    bool ibScaled)
{
  if (!iImage.IsValid() || iImage.IsBayer()) return;
  if (iPlane >= iImage.GetChannelCount()) return;

  _spAbstractImpl.reset(); 
  _spAbstractImpl = elxGetImageHandler(*iImage._spAbstractImpl).
    CreateChannel(*iImage._spAbstractImpl.get(), iPlane, ibScaled);
  _Bayer = BM_None;
}

//----------------------------------------------------------------------------
//  GetPlane
//----------------------------------------------------------------------------
bool ImageVariant::GetPlane(
    const ImageVariant& iImage, 
    uint32 iPlane, 
    bool ibScaled)
{
  if (!iImage.IsValid() || iImage.IsBayer()) return false;
  if (iPlane >= iImage.GetChannelCount()) return false;

  _spAbstractImpl.reset(); 
  _spAbstractImpl = elxGetImageHandler(*iImage._spAbstractImpl).
    CreateChannel(*iImage._spAbstractImpl.get(), iPlane, ibScaled);
  _Bayer = BM_None;
  return true;

} // GetPlane


//----------------------------------------------------------------------------
//  GetPlane
//----------------------------------------------------------------------------
bool ImageVariant::GetPlane(uint32 iPlane, ImageVariant& oPlane, bool ibScaled) const
{
  if (!IsValid() || IsBayer()) return false;
  if (iPlane >= GetChannelCount()) return false;

  oPlane._spAbstractImpl.reset(); 
  oPlane._spAbstractImpl = elxGetImageHandler(*_spAbstractImpl).
    CreateChannel(*_spAbstractImpl.get(), iPlane, ibScaled);
  oPlane._Bayer = BM_None;
  return true;

} // GetPlane


//----------------------------------------------------------------------------
//  SetPlane
//----------------------------------------------------------------------------
bool ImageVariant::SetPlane(
    uint32 iPlane, 
    const ImageVariant& iImage, 
    bool ibResized, 
    bool ibScaled)
{
  if (!IsValid() || IsBayer()) return false;
  if (!iImage.IsValid() || iImage.IsBayer()) return false;

  const uint32 nPlane = GetChannelCount();
  if (iPlane >= nPlane) return false;

  bool bSuccess = false;

  // ckeck resolution
  ImageVariant plane = iImage;
  const EResolution resolution = GetResolution();
  if (resolution != plane.GetResolution())
    bSuccess = plane.ChangeResolution(resolution, ibScaled);

  // check dimensions
  const uint32 w = GetWidth();
  const uint32 h = GetHeight();
  const uint32 w2 = plane.GetWidth();
  const uint32 h2 = plane.GetHeight();
  const bool bSameSize = (w == w2) && (h == h2);

  // inject plane into image
  if (bSameSize)
  {
    bSuccess = elxGetImageHandler(*_spAbstractImpl).
      SetChannel(
        *_spAbstractImpl.get(), *plane._spAbstractImpl.get(), iPlane);
  }
  else
  {
    //@TODO
    return false;
  }

  return true;
  
} // SetPlane


//----------------------------------------------------------------------------
//  SwapPlanes
//----------------------------------------------------------------------------
bool ImageVariant::SwapPlanes(uint32 iPlane1, uint32 iPlane2)
{
  if (!IsValid() || IsBayer()) return false;

  const uint32 nPlane = GetChannelCount();
  if (nPlane < 2) return false;
  if ((iPlane1 >= nPlane) || (iPlane2 >= nPlane)) return false;
  if (iPlane1 == iPlane2) return true;

  bool bSuccess = false;

  // split planes
  ImageVariant plane1, plane2;
  bSuccess = GetPlane(iPlane1, plane1, false);
  bSuccess = GetPlane(iPlane2, plane2, false);

  // reinject planes
  bSuccess = SetPlane(iPlane1, plane2, false, false);
  bSuccess = SetPlane(iPlane2, plane1, false, false);

  return true;

} // SwapPlanes


} // namespace Image
} // namespace eLynx
