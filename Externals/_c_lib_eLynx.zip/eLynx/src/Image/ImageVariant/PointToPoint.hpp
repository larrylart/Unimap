//============================================================================
//  ImageVariant/PointToPoint.hpp                      Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                     Point to point processing
//============================================================================
//----------------------------------------------------------------------------
//  AdjustBrightness
//----------------------------------------------------------------------------
bool ImageVariant::AdjustBrightness(double iBrightness,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // support Bayer image
  if (IsBayer()) iChannelMask = CM_All;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    AdjustBrightness(*_spAbstractImpl, iBrightness, iChannelMask, iNotifier);

} // AdjustBrightness


//----------------------------------------------------------------------------
//  AdjustContrast
//----------------------------------------------------------------------------
bool ImageVariant::AdjustContrast(double iContrast,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // support Bayer image
  if (IsBayer()) iChannelMask = CM_All;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    AdjustContrast(*_spAbstractImpl, iContrast, iChannelMask, iNotifier);

} // AdjustContrast


//----------------------------------------------------------------------------
//  AdjustGamma
//----------------------------------------------------------------------------
bool ImageVariant::AdjustGamma(double iGamma, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // support Bayer image
  if (IsBayer()) iChannelMask = CM_All;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    AdjustGamma(*_spAbstractImpl, iGamma, iChannelMask, iNotifier);

} // AdjustGamma


//----------------------------------------------------------------------------
//  AdjustBCG
//----------------------------------------------------------------------------
bool ImageVariant::AdjustBCG(
    double iBrightness, double iContrast, double iGamma, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // support Bayer image
  if (IsBayer()) iChannelMask = CM_All;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    AdjustBCG(*_spAbstractImpl, iBrightness, iContrast, iGamma, iChannelMask, iNotifier);

} // AdjustBCG


//----------------------------------------------------------------------------
//  AdjustShadowHighlight
//----------------------------------------------------------------------------
bool ImageVariant::AdjustShadowHighlight(
    double iShadow, double iHighlight, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // support Bayer image
  if (IsBayer()) iChannelMask = CM_All;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    AdjustShadowHighlight(*_spAbstractImpl, iShadow, iHighlight, iChannelMask, iNotifier);

} // AdjustShadowHighlight


//----------------------------------------------------------------------------
//  AdjustMidtone
//----------------------------------------------------------------------------
bool ImageVariant::AdjustMidtone(
    double iMidtone, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // support Bayer image
  if (IsBayer()) iChannelMask = CM_All;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    AdjustMidtone(*_spAbstractImpl, iMidtone, iChannelMask, iNotifier);

} // AdjustMidtone


//----------------------------------------------------------------------------
//  AdjustSigmoid
//----------------------------------------------------------------------------
bool ImageVariant::AdjustSigmoid(
    double iAlpha, double iBeta, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // support Bayer image
  if (IsBayer()) iChannelMask = CM_All;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    AdjustSigmoid(*_spAbstractImpl, iAlpha, iBeta, iChannelMask, iNotifier);

} // AdjustSigmoid


//----------------------------------------------------------------------------
//  Balance
//----------------------------------------------------------------------------
bool ImageVariant::Balance(
    double iRed, double iGreen, double iBlue,
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // support Bayer image
  if (IsBayer())
    return elxGetBayerHandler(*_spAbstractImpl).
      Balance(*_spAbstractImpl, _Bayer, iRed, iGreen, iBlue);

  return elxGetPointToPointHandler(*_spAbstractImpl).
    Balance(*_spAbstractImpl, iRed, iGreen, iBlue, iNotifier);

} // Balance


//----------------------------------------------------------------------------
//  Posterize
//----------------------------------------------------------------------------
bool ImageVariant::Posterize(uint32 iLevels, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // support Bayer image
  if (IsBayer()) iChannelMask = CM_All;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    Posterize(*_spAbstractImpl, iLevels, iChannelMask, iNotifier);

} // Posterize


//----------------------------------------------------------------------------
//  Solarize
//----------------------------------------------------------------------------
bool ImageVariant::Solarize(double iValue, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // support Bayer image
  if (IsBayer()) iChannelMask = CM_All;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    Solarize(*_spAbstractImpl, iValue, iChannelMask, iNotifier);

} // Solarize


//----------------------------------------------------------------------------
//  Colorize
//----------------------------------------------------------------------------
bool ImageVariant::Colorize(double iHue, double iSaturation, 
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // do not support Bayer image
  if (IsBayer()) return false;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    Colorize(*_spAbstractImpl, iHue, iSaturation, iNotifier);

} // Colorize


//----------------------------------------------------------------------------
//  Desaturate
//----------------------------------------------------------------------------
bool ImageVariant::Desaturate(double iFactor,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // do not support Bayer image
  if (IsBayer()) return false;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    Desaturate(*_spAbstractImpl, iFactor, iChannelMask, iNotifier);

} // Desaturate


//----------------------------------------------------------------------------
//  AdjustHueSaturation
//----------------------------------------------------------------------------
bool ImageVariant::AdjustHueSaturation(double iHue, double iSaturation, 
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // do not support Bayer image
  if (IsBayer()) return false;

  return elxGetPointToPointHandler(*_spAbstractImpl).
    AdjustHueSaturation(*_spAbstractImpl, iHue, iSaturation, iNotifier);

} // AdjustHueSaturation


//----------------------------------------------------------------------------
//  Binarize
//----------------------------------------------------------------------------
bool ImageVariant::Binarize(double iThreshold, bool ibNegative,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // support Bayer image
  if (IsBayer()) iChannelMask = CM_All;

  shared_ptr<AbstractImage> spImage = 
    elxGetPointToPointHandler(*_spAbstractImpl).
      CreateBinarized(*_spAbstractImpl, iThreshold, ibNegative, iChannelMask, iNotifier);

  if (!elxUseable(spImage.get())) return false;

  // new aggregation
  _spAbstractImpl.swap(spImage);
  return true;

} // Binarize


//----------------------------------------------------------------------------
//  Blend
//----------------------------------------------------------------------------
bool ImageVariant::Blend(const ImageVariant& iImage, double iScalar,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if ((NULL == _spAbstractImpl.get()) || (!iImage.IsValid()))
    return false;

  // check ISO format
  const EPixelFormat format = GetPixelFormat();
  if (format != iImage.GetPixelFormat())
    return false;

  // check ISO Bayer matrix
  if (_Bayer != iImage._Bayer)
    return false;

  // support Bayer image
  if (IsBayer()) iChannelMask = CM_All;

  const AbstractImage& image = *iImage.GetImpl();
  return elxGetPointToPointHandler(format).
    Blend( *_spAbstractImpl.get(), image, iScalar, iChannelMask, iNotifier);

} // Blend

} // namespace Image
} // namespace eLynx
