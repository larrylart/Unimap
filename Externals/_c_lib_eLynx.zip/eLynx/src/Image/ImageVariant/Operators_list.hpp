//============================================================================
//  ImageVariant/Operators_list.cpp                    Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                      Operators with an image list
//============================================================================
bool elxCheckAndBuildAbstractList(
    const std::vector< const ImageVariant* >& iImageList,
    std::vector< const AbstractImage* >& oImageList)
{
  const size_t size = iImageList.size();
    
 // check that all images have same format and same bayer pattern
  if (!iImageList[0]->IsValid())
    return false;
 
  EBayerMatrix Bayer = iImageList[0]->GetBayerMatrix();
  const uint32 w = iImageList[0]->GetWidth();
  const uint32 h = iImageList[0]->GetHeight();
  
  oImageList.reserve(size);
  oImageList.push_back( iImageList[0]->GetImpl().get() );
  for (size_t i=1; i<size; ++i)
  {
    if (!iImageList[i]->IsValid() || 
        (Bayer != iImageList[i]->GetBayerMatrix()) ||
        (w != iImageList[i]->GetWidth()) || 
        (h != iImageList[i]->GetHeight()))
      return false;
    oImageList.push_back( iImageList[i]->GetImpl().get() );
  }
  return true;

} // elxCheckAndBuildAbstractList


//----------------------------------------------------------------------------
//  Build: build an image from an image list and an operator
//----------------------------------------------------------------------------
bool ImageVariant::Build(
    EImageListOperator iOperator,
    const std::vector< const ImageVariant* >& iImageList,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  _spAbstractImpl.reset();

  const size_t size = iImageList.size();
  if (0 == size)
    return true;
    
  if (1 == size)
  {
    // only one image in list
    _spAbstractImpl = elxGetImageHandler( *(iImageList[0]->_spAbstractImpl) ).
        CreateImage( *(iImageList[0]->_spAbstractImpl) );
    return true;
  }
  
  std::vector< const AbstractImage * > abstractList;
  const bool bValid = elxCheckAndBuildAbstractList(iImageList, abstractList);
  if (!bValid)
    return bValid;

  _spAbstractImpl = elxGetOperatorsHandler(iImageList[0]->GetPixelFormat()).
      CreateImage(iOperator, abstractList, iChannelMask, iNotifier);

  return IsValid();

} // Build


//----------------------------------------------------------------------------
//  Build: build an clipped image from an image list and an operator
//----------------------------------------------------------------------------
bool ImageVariant::BuildClipped(
    EImageListOperator iOperator,
    const std::vector< const ImageVariant* >& iImageList,
    uint32 iIteration, double iKappa,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  _spAbstractImpl.reset();

  const size_t size = iImageList.size();
  if (0 == size)
    return true;
    
  if (1 == size)
  {
    // only one image in list
    _spAbstractImpl = elxGetImageHandler( *(iImageList[0]->_spAbstractImpl) ).
        CreateImage( *(iImageList[0]->_spAbstractImpl) );
    return true;
  }
  
  std::vector< const AbstractImage * > abstractList;
  const bool bValid = elxCheckAndBuildAbstractList(iImageList, abstractList);
  if (!bValid)
    return bValid;

  _spAbstractImpl = elxGetOperatorsHandler(iImageList[0]->GetPixelFormat()).
      CreateClipped(iOperator, abstractList, iIteration, iKappa, iChannelMask, iNotifier);

  return IsValid();

} // BuildClipped

//----------------------------------------------------------------------------
//  Build: build an clipped image from an image list and an operator
//----------------------------------------------------------------------------
bool ImageVariant::BuildWeightedEntropy(
    const std::vector< const ImageVariant* >& iImageList,
    uint32 iW, uint32 iH,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  _spAbstractImpl.reset();

  const size_t size = iImageList.size();
  if (0 == size)
    return true;
    
  if (1 == size)
  {
    // only one image in list
    _spAbstractImpl = elxGetImageHandler( *(iImageList[0]->_spAbstractImpl) ).
        CreateImage( *(iImageList[0]->_spAbstractImpl) );
    return true;
  }
  
  std::vector< const AbstractImage * > abstractList;
  const bool bValid = elxCheckAndBuildAbstractList(iImageList, abstractList);
  if (!bValid)
    return bValid;

  _spAbstractImpl = elxGetOperatorsHandler(iImageList[0]->GetPixelFormat()).
      CreateWeightedEntropy(abstractList, iW, iH, iChannelMask, iNotifier);

  return IsValid();

} // BuildWeightedEntropy


} // namespace Image
} // namespace eLynx
