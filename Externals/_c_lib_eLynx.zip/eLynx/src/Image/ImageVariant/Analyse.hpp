//============================================================================
//  ImageVariant/Analyse.hpp                           Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                                Analyse
//============================================================================
//----------------------------------------------------------------------------
//  ComputeMin
//----------------------------------------------------------------------------
bool ImageVariant::ComputeMin(double& oMin, bool ibNormalized) const
{
  oMin = 0.0;
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeMin(*_spAbstractImpl, oMin, ibNormalized);
}
bool ImageVariant::ComputeMin(double (&oMin)[PC_MAX], bool ibNormalized) const
{
  for (uint32 i = 0; i < PC_MAX; ++i) oMin[i] = 0.0;
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeMin(*_spAbstractImpl, oMin, ibNormalized);
}

//----------------------------------------------------------------------------
//  ComputeMax
//----------------------------------------------------------------------------
bool ImageVariant::ComputeMax(double& oMax, bool ibNormalized) const
{
  oMax = 1.0;
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeMax(*_spAbstractImpl, oMax, ibNormalized);
}
bool ImageVariant::ComputeMax(double (&oMax)[PC_MAX], bool ibNormalized) const
{
  for (uint32 i = 0; i < PC_MAX; ++i) oMax[i] = 0.0;
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeMax(*_spAbstractImpl, oMax, ibNormalized);
}

//----------------------------------------------------------------------------
//  ComputeMinMax
//----------------------------------------------------------------------------
bool ImageVariant::ComputeMinMax(double& oMin, double& oMax, bool ibNormalized) const
{
  oMin = 0.0; oMax = 1.0;
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeMinMax(*_spAbstractImpl, oMin, oMax, ibNormalized);
}
bool ImageVariant::ComputeMinMax(
    double (&oMin)[PC_MAX], 
    double (&oMax)[PC_MAX], 
    bool ibNormalized) const
{
  for (uint32 i = 0; i < PC_MAX; ++i) 
  {
    oMin[i] = 0.0; oMax[i] = 0.0;
  }
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeMinMax(*_spAbstractImpl, oMin, oMax, ibNormalized);
}

//----------------------------------------------------------------------------
//  ComputeMean
//----------------------------------------------------------------------------
bool ImageVariant::ComputeMean(double& oMean, bool ibNormalized) const
{
  oMean = 0.0;
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeMean(*_spAbstractImpl, oMean, ibNormalized);
}
bool ImageVariant::ComputeMean(double (&oMean)[PC_MAX], bool ibNormalized) const
{
  for (uint32 i = 0; i < PC_MAX; ++i) oMean[i] = 0.0;
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeMean(*_spAbstractImpl, oMean, ibNormalized);
}

//----------------------------------------------------------------------------
//  ComputeMedian
//----------------------------------------------------------------------------
bool ImageVariant::ComputeMedian(double& oMedian, bool ibNormalized) const
{
  oMedian = 0.0;
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeMedian(*_spAbstractImpl, oMedian, ibNormalized);
}
bool ImageVariant::ComputeMedian(double (&oMedian)[PC_MAX], bool ibNormalized) const
{
  for (uint32 i = 0; i < PC_MAX; ++i) oMedian[i] = 0.0;;
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeMedian(*_spAbstractImpl, oMedian, ibNormalized);
}

//----------------------------------------------------------------------------
//  ComputeStandardDeviation
//----------------------------------------------------------------------------
bool ImageVariant::ComputeStandardDeviation(
    double& oDeviation,
    bool ibNormalized) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeStandardDeviation(*_spAbstractImpl, oDeviation, ibNormalized);
}
bool ImageVariant::ComputeStandardDeviation(
    double (&oDeviation)[PC_MAX],
    bool ibNormalized) const
{
  for (uint32 i = 0; i < PC_MAX; ++i) oDeviation[i] = 0.0;
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeStandardDeviation(*_spAbstractImpl, oDeviation, ibNormalized);
}

bool ImageVariant::ComputeStandardDeviation(
    double& oDeviation, 
    double& oMean,
    bool ibNormalized) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeStandardDeviation(*_spAbstractImpl, oDeviation, oMean, ibNormalized);
}
bool ImageVariant::ComputeStandardDeviation(
    double (&oDeviation)[PC_MAX],
    double (&oMean)[PC_MAX],
    bool ibNormalized) const
{
  for (uint32 i = 0; i < PC_MAX; ++i) oDeviation[i] = 0.0;
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeStandardDeviation(*_spAbstractImpl, oDeviation, oMean, ibNormalized);
}


//----------------------------------------------------------------------------
//  ComputeVariance
//----------------------------------------------------------------------------
bool ImageVariant::ComputeVariance(double& oVariance) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeVariance(*_spAbstractImpl, oVariance);
}
bool ImageVariant::ComputeVariance(double (&oVariance)[PC_MAX]) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeVariance(*_spAbstractImpl, oVariance);
}

//----------------------------------------------------------------------------
// ComputeEnergy
//----------------------------------------------------------------------------
bool ImageVariant::ComputeEnergy(double& oEnergy) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeEnergy(*_spAbstractImpl, oEnergy);
}
bool ImageVariant::ComputeEnergy(double (&oEnergy)[PC_MAX]) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeEnergy(*_spAbstractImpl, oEnergy);
}

//----------------------------------------------------------------------------
//  ComputeEntropy
//----------------------------------------------------------------------------
bool ImageVariant::ComputeEntropy(double& oEntropy) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeEntropy(*_spAbstractImpl, oEntropy);
}
bool ImageVariant::ComputeEntropy(double (&oEntropy)[PC_MAX]) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeEntropy(*_spAbstractImpl, oEntropy);
}

//----------------------------------------------------------------------------
//  ComputeHistogram
//----------------------------------------------------------------------------
bool ImageVariant::ComputeHistogram(ImageHistogram& oHistogram) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeHistogram(*_spAbstractImpl, oHistogram);
}

} // namespace Image
} // namespace eLynx
