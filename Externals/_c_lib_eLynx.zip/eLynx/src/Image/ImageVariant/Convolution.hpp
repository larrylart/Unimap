//============================================================================
//  ImageVariant/Convolution.hpp                       Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/math/KernelCollection.h>

namespace eLynx {
namespace Image {


//============================================================================
//                          Convolution filters
//============================================================================

//----------------------------------------------------------------------------
//  Convolve # classical
//----------------------------------------------------------------------------
bool ImageVariant::Convolve(const ConvolutionKerneld& iKernel, 
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetLocalToPointHandler(*_spAbstractImpl).
    Convolve(*_spAbstractImpl, iKernel, 
      ibAbsolute, iBorder, iIteration, iChannelMask, iNotifier);

} // Convolve

//----------------------------------------------------------------------------
//  Convolve # with thresholds
//----------------------------------------------------------------------------
bool ImageVariant::Convolve(const Math::ConvolutionKerneld& iKernel,
    double iThresholdMin, double iThresholdMax, 
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetLocalToPointHandler(*_spAbstractImpl).
    Convolve(*_spAbstractImpl, iKernel, iThresholdMin, iThresholdMax,
      ibAbsolute, iBorder, iIteration, iChannelMask, iNotifier);

} // Convolve

//----------------------------------------------------------------------------
//  Convolve # with thresholds & blend
//----------------------------------------------------------------------------
bool ImageVariant::Convolve(const Math::ConvolutionKerneld& iKernel,
    double iThresholdMin, double iThresholdMax, double iBlend,
    bool ibAbsolute, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  elxBLEND(iBlend, iChannelMask,
    elxGetLocalToPointHandler(*_spAbstractImpl).
      Convolve(*_spAbstractImpl, iKernel, iThresholdMin, iThresholdMax,
        ibAbsolute, iBorder, iIteration, iChannelMask, iNotifier)
  );

} // Convolve

//----------------------------------------------------------------------------
//  Convolve # with separable kernels
//----------------------------------------------------------------------------
bool ImageVariant::Convolve(
    const ConvolutionKerneld& iKernel1, 
    const ConvolutionKerneld& iKernel2, 
    EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetLocalToPointHandler(*_spAbstractImpl).
    Convolve(*_spAbstractImpl, iKernel1,iKernel2, iBorder, iIteration, iChannelMask, iNotifier);

} // Convolve

//----------------------------------------------------------------------------
//  ApplySharpen3x3
//----------------------------------------------------------------------------
bool ImageVariant::ApplySharpen3x3(
    double iAmount,
    double iThresholdMin, double iThresholdMax, double iBlend,
    EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakeSharpen3x3d(iAmount);
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);

} // ApplySharpen3x3

//----------------------------------------------------------------------------
//  ApplySharpen
//----------------------------------------------------------------------------
bool ImageVariant::ApplySharpen(
    double iRadius,
    double iThresholdMin, double iThresholdMax, double iBlend,
    EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakeSharpen(iRadius);
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);

} // ApplySharpen

//----------------------------------------------------------------------------
//  ApplySharpenMore
//----------------------------------------------------------------------------
bool ImageVariant::ApplySharpenMore(
    double iAlpha,
    double iThresholdMin, double iThresholdMax, double iBlend,
    EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakeSharpenMore3x3d(iAlpha);
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);

} // ApplySharpenMore

//----------------------------------------------------------------------------
//  ApplySharpenSmooth
//----------------------------------------------------------------------------
bool ImageVariant::ApplySharpenSmooth(
    double iAlpha, 
    double iThresholdMin, double iThresholdMax, 
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakeSharpenSmooth3x3d(iAlpha);
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);
              
} // ApplySharpenSmooth

//----------------------------------------------------------------------------
//  ApplySharpenSoft
//----------------------------------------------------------------------------
bool ImageVariant::ApplySharpenSoft(
    double iThresholdMin, double iThresholdMax, 
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakeSharpenSoft3x3d();
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);
              
} // ApplySharpenSoft

//----------------------------------------------------------------------------
//  ApplySmooth
//----------------------------------------------------------------------------
bool ImageVariant::ApplySmooth(
    double iThresholdMin, double iThresholdMax, double iBlend,
    EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakeSmooth3x3d();
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);
              
} // ApplySmooth


//----------------------------------------------------------------------------
//  ApplyCone
//----------------------------------------------------------------------------
bool ImageVariant::ApplyCone(
    double iThresholdMin, double iThresholdMax, 
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakeCone5x5d();
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);
             
} // ApplyCone


//----------------------------------------------------------------------------
//  ApplyPyramidal
//----------------------------------------------------------------------------
bool ImageVariant::ApplyPyramidal(
    double iThresholdMin, double iThresholdMax, 
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakePyramidal5x5d();
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);
              
} // ApplyPyramidal


//----------------------------------------------------------------------------
//  ApplyLowpass
//----------------------------------------------------------------------------
bool ImageVariant::ApplyLowpass(
    double iAlpha,
    double iThresholdMin, double iThresholdMax, 
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakeLowpass3x3d(iAlpha);
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);
              
} // ApplyLowpass


//----------------------------------------------------------------------------
//  ApplyEmboss
//----------------------------------------------------------------------------
bool ImageVariant::ApplyEmboss(
    double iDegree,
    double iThresholdMin, double iThresholdMax, 
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakeEmboss3x3d(iDegree);
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);

} // ApplyEmboss


//----------------------------------------------------------------------------
//  ApplyLaplacian3x3
//----------------------------------------------------------------------------
bool ImageVariant::ApplyLaplacian3x3(
    double iAlpha, 
    double iThresholdMin, double iThresholdMax, 
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakeLaplacian3x3d(iAlpha);
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);

} // ApplyLaplacian3x3


//----------------------------------------------------------------------------
//  ApplyLaplacian
//----------------------------------------------------------------------------
bool ImageVariant::ApplyLaplacian(
    double iRadius, 
    double iThresholdMin, double iThresholdMax, 
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const Math::ConvolutionKerneld kernel = elxMakeLaplacian(iRadius);
  const bool bAbsolute = false;

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);
              
} // ApplyLaplacian


//----------------------------------------------------------------------------
//  ApplyMean
//----------------------------------------------------------------------------
bool ImageVariant::ApplyMean(
    double iRadius, bool ibCircular,
    double iThresholdMin, double iThresholdMax, 
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const bool bAbsolute = false;
  const Math::ConvolutionKerneld kernel = elxMakeMeanRadiusKernel(iRadius, ibCircular);

  return Convolve(kernel, iThresholdMin, iThresholdMax, iBlend, 
    bAbsolute, iBorder, iIteration, iChannelMask, iNotifier);

} // ApplyMean


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                       specialized filters
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

//----------------------------------------------------------------------------
//  ApplyMarrHildreth
//----------------------------------------------------------------------------
bool ImageVariant::ApplyMarrHildreth(EBorderFill iBorder,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetLocalToPointHandler(*_spAbstractImpl).
    Convolve(*_spAbstractImpl, elxMakeMarrHildreth3x3d(), 
      true, iBorder, 1, iChannelMask, iNotifier);
    
} // ApplyMarrHildreth


//----------------------------------------------------------------------------
//  ApplyBoxBlur
//----------------------------------------------------------------------------
bool ImageVariant::ApplyBoxBlur(uint32 iWidth, uint32 iHeight, 
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  elxBLEND(iBlend, iChannelMask, 
    elxGetLocalToPointHandler(*_spAbstractImpl).
      ApplyBoxBlur(*_spAbstractImpl, iWidth,iHeight, iBorder, iIteration, iChannelMask, iNotifier)
  );
      
} // ApplyBoxBlur


//----------------------------------------------------------------------------
//  ApplySelectiveBlur
//----------------------------------------------------------------------------
bool ImageVariant::ApplySelectiveBlur(
    double iBlend, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  elxBLEND(iBlend, iChannelMask, 
    elxGetLocalToPointHandler(*_spAbstractImpl).
      ApplySelectiveBlur(*_spAbstractImpl, iBorder, iIteration, iChannelMask, iNotifier)
  );

} // ApplySelectiveBlur


//----------------------------------------------------------------------------
//  ApplyFastGaussianBlur
//----------------------------------------------------------------------------
bool ImageVariant::ApplyFastGaussianBlur(double iRadius, EBorderFill iBorder, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;  

  uint32 d = uint32(2.0*iRadius + 0.5);
  d = Math::elxMax(uint32(3), d);
  if (Math::elxIsEven(d)) d++;

  // gaussian approximation using 3 times box blur
  return elxGetLocalToPointHandler(*_spAbstractImpl).
    ApplyBoxBlur(*_spAbstractImpl, d,d, iBorder, 3, iChannelMask, iNotifier);
      
} // ApplyFastGaussianBlur


//----------------------------------------------------------------------------
//  ApplyGaussian
//----------------------------------------------------------------------------
bool ImageVariant::ApplyGaussian(
    uint32 iWidth, uint32 iHeight, double iVariance,
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  elxBLEND(iBlend, iChannelMask, 
    elxGetLocalToPointHandler(*_spAbstractImpl).
      ApplyGaussian(*_spAbstractImpl, iWidth, iHeight, iVariance, 
        iBorder, iIteration, iChannelMask, iNotifier)
  );

} // ApplyGaussian


//----------------------------------------------------------------------------
//  ApplyGaussian
//----------------------------------------------------------------------------
bool ImageVariant::ApplyGaussian(
    double iRadius, double iVariance,
    double iBlend, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  elxBLEND(iBlend, iChannelMask, 
    elxGetLocalToPointHandler(*_spAbstractImpl).
      ApplyGaussian(*_spAbstractImpl, iRadius, iVariance, 
        iBorder, iIteration, iChannelMask, iNotifier)
  );
    
} // ApplyGaussian


//----------------------------------------------------------------------------
//  ApplyGaussian
//----------------------------------------------------------------------------
bool ImageVariant::ApplyGaussian(
    double iRadius,
    double iBlend, EBorderFill iBorder, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  const double variance = Math::elxGetGaussianVariance(iRadius);
  elxBLEND(iBlend, iChannelMask, 
    elxGetLocalToPointHandler(*_spAbstractImpl).
      ApplyGaussian(*_spAbstractImpl, iRadius, variance,
        iBorder, iIteration, iChannelMask, iNotifier)
  );
    
} // ApplyGaussian


//----------------------------------------------------------------------------
//  ApplyLoG
//----------------------------------------------------------------------------
bool ImageVariant::ApplyLoG(
    double iRadius, double iVariance,
    EBorderFill iBorder,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetLocalToPointHandler(*_spAbstractImpl).
    Convolve(*_spAbstractImpl, elxMakeLoG(iRadius, iVariance), 
      false, iBorder, 1, iChannelMask, iNotifier);
    
} // ApplyLoG

#if 1
//----------------------------------------------------------------------------
//  ApplyUnsharpMask
//----------------------------------------------------------------------------
//  Unsharp masking produces an edge image g(x,y) from an input image f(x,y):
//  g(x,y) = f(x,y) - a1 * fsmooth(x,y)
//  fsharp(x,y) = f(x,y) - a2 * g(x,y)
//----------------------------------------------------------------------------
bool ImageVariant::ApplyUnsharpMask(
    double iRadius, double iAmount1, double iAmount2,
    EBorderFill iBorder,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  // process in float to disable clamping on signed result
  EResolution res = GetResolution();
  ChangeResolution(RT_Float);
  
  // Apply gaussian to image copy
  ImageVariant blurred = *this;
  
//  double variance = iRadius/2.0;
//  bool bSuccess = blurred.ApplyGaussianBlur(iRadius, variance, iBorder, iChannelMask, iNotifier);
  bool bSuccess = blurred.ApplyFastGaussianBlur(iRadius, iBorder, iChannelMask);
  if (bSuccess)
  {
    ImageVariant detailled = *this;
    blurred.Mul(iAmount1, iChannelMask);
    detailled.Sub(blurred, iChannelMask);
    
    detailled.Mul(iAmount2, iChannelMask);
    Add(detailled, iChannelMask, iNotifier);
    ChangeResolution(res);
  }
  return bSuccess;
 
} //  ApplyUnsharpMask

#else

//----------------------------------------------------------------------------
//  ApplyUnsharpMask
//----------------------------------------------------------------------------
//  Unsharp masking produces an edge image g(x,y) from an input image f(x,y):
//  g(x,y) = f(x,y) - a1 * fsmooth(x,y)
//  fsharp(x,y) = f(x,y) - a2 * g(x,y)
//----------------------------------------------------------------------------
bool ImageVariant::ApplyUnsharpMask(
    double iRadius, double iAmount1, double iAmount2,
    EBorderFill iBorder,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  // process in float to disable clamping on signed result
  EResolution res = GetResolution();
  ChangeResolution(RT_Float);
  
  // Apply gaussian to image copy
  const uint32 iteration = 1;
  const double variance = Math::elxGetGaussianVariance(iRadius);
  ImageVariant blurred = *this;
  bool bSuccess = blurred.ApplyGaussian(iRadius, variance,  
        iBorder, iteration, iChannelMask);
  if (bSuccess)
  {
    double k = iAmount1;
    ImageVariant detailled = *this;
    bSuccess = blurred.Mul(1. - k, iChannelMask);
    bSuccess = detailled.Mul(k, iChannelMask);
    bSuccess = detailled.Sub(blurred, iChannelMask);
    bSuccess = detailled.ChangeResolution(res);
    *this = detailled;
  }
  return bSuccess;
 
} //  ApplyUnsharpMask

#endif

//----------------------------------------------------------------------------
//  ApplyBilateral
//----------------------------------------------------------------------------
bool ImageVariant::ApplyBilateral(
    double iRadius, double iSigmaSpatial, double iSigmaRange,
    double iBlend, EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  elxBLEND(iBlend, iChannelMask, 
    elxGetLocalToPointHandler(*_spAbstractImpl).
      ApplyBilateral(*_spAbstractImpl, iRadius, iSigmaSpatial, iSigmaRange,
        iBorder, iIteration, iChannelMask, iNotifier)
  );

} // ApplyBilateral

} // namespace Image
} // namespace eLynx
