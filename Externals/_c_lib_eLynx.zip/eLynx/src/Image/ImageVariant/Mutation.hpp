//============================================================================
//  ImageVariant/Mutation.hpp                          Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>

namespace eLynx {
namespace Image {

//============================================================================
//                                mutations
//============================================================================
//----------------------------------------------------------------------------
//  ChangeResolution
//----------------------------------------------------------------------------
bool ImageVariant::ChangeResolution(EResolution iResolution, bool ibScaled)
{
  // for undefined or invalid image it has no sense, so not an error
  const bool bToUndefined = (RT_Undefined == iResolution);
  if (NULL == _spAbstractImpl.get())
    return bToUndefined;

  shared_ptr<AbstractImage> spImage;
  if (IsBayer() && bToUndefined)
  {
    spImage = boost::shared_ptr<AbstractImage>();
    // no more Bayer
    _Bayer = BM_None;
  }
  else
    spImage = elxGetImageHandler(*_spAbstractImpl).
      CreateImage(*_spAbstractImpl, iResolution, ibScaled);

  if (!elxUseable(spImage.get()) && !bToUndefined)
    return false;

  // new aggregation
  _spAbstractImpl.swap(spImage);

  // check that resolution conversion is successfull
  elxASSERT(GetResolution() == iResolution);
  return true;

} // ChangeResolution


//----------------------------------------------------------------------------
//  ChangeColorSpace
//----------------------------------------------------------------------------
bool ImageVariant::ChangeColorSpace(EColorSpace iColorSpace, bool ibBlendAlpha)
{
  // check if Color Space is supported for an image implementation
  if (!elxIsImageColorSpace(iColorSpace)) return false;

  // for undefined or invalid image it has no sense, so not an error
  const bool bToUndefined = (CS_Undefined == iColorSpace);

  if (NULL == _spAbstractImpl.get()) 
    return bToUndefined;
  
  if (IsComplex() && !bToUndefined)
    return false;

  shared_ptr<AbstractImage> spImage;
  if (IsBayer())
  {
    // variant image deals with Bayer but AbstractImage DOES NOT
    if (bToUndefined)
      spImage = boost::shared_ptr<AbstractImage>();
    else if (CS_RGB == iColorSpace)
      spImage = elxCreateImageRGB(*_spAbstractImpl, BCC_Adaptive, _Bayer);
    else
    {
      shared_ptr<AbstractImage> spImageRGB = 
        elxCreateImageRGB(*_spAbstractImpl, BCC_Adaptive, _Bayer);
      spImage = elxCreateImage(*spImageRGB, iColorSpace, ibBlendAlpha);
    }

    // no more Bayer
    _Bayer = BM_None;
  }
  else if (bToUndefined)
    spImage = boost::shared_ptr<AbstractImage>();
  else
    spImage = elxCreateImage(*_spAbstractImpl, iColorSpace, ibBlendAlpha);

  if (!elxUseable(spImage.get()) && !bToUndefined)
    return false;

  // new aggregation
  _spAbstractImpl.swap(spImage);

  // check that color space conversion is successfull
  elxASSERT(GetColorSpace() == iColorSpace);
  return true;

} // ChangeColorSpace


//----------------------------------------------------------------------------
//  ChangePixelFormat
//----------------------------------------------------------------------------
bool ImageVariant::ChangePixelFormat(EPixelFormat iPixelFormat, 
    bool ibScaled, bool ibBlendAlpha)
{
  // for undefined or invalid image it has no sense, so not an error
  if (NULL == _spAbstractImpl.get())
    return (PF_Undefined == iPixelFormat);

  shared_ptr<AbstractImage> spImage;

  const bool bFromComplex = IsComplex();
  const bool bToComplex = elxIsComplex(iPixelFormat);
  if (bFromComplex && bToComplex)
  {
    // CPLX<T> to CPLX<U>
    if (iPixelFormat == GetPixelFormat())
      return true;

    // just change resolution
    const EResolution res = elxGetResolution(iPixelFormat);
    spImage = elxCreateImage(*_spAbstractImpl, res, ibScaled);
  }
  else if (bFromComplex || bToComplex)
  {
    // !CPLX<T> to CPLX<U> is not supported
    // CPLX<T> to !CPLX<U> is not supported
    if ((PF_Undefined != iPixelFormat))
      return false;

    // CPLX<T> to Undefined
    spImage = boost::shared_ptr<AbstractImage>();
  }
  else if (IsBayer())
  {
    // variant image deals with Bayer but AbstractImage DOES NOT

    // change to RGB
    shared_ptr<AbstractImage> spImageRGB = 
      elxCreateImageRGB(*_spAbstractImpl, BCC_Adaptive, _Bayer);
    elxASSERT( elxUseable(spImageRGB.get()) );

    // change RGB to requested pixel format
    spImage = elxCreateImage(*spImageRGB, iPixelFormat, ibScaled, ibBlendAlpha);
    if (!elxUseable(spImage.get()) && (PF_Undefined != iPixelFormat)) 
      return false;

    // no more Bayer
    _Bayer = BM_None;
  }
  else
  {
    spImage = elxCreateImage(*_spAbstractImpl, iPixelFormat, ibScaled, ibBlendAlpha);
    if (!elxUseable(spImage.get()) && (PF_Undefined != iPixelFormat)) 
      return false;
  }

  // new aggregation
  _spAbstractImpl.swap(spImage);

  // check that format conversion is successfull
  elxASSERT(GetPixelFormat() == iPixelFormat);
  return true;

} // ChangePixelFormat


//----------------------------------------------------------------------------
//  ChangeToGrey
//----------------------------------------------------------------------------
bool ImageVariant::ChangeToGrey(EColorToGreyConversion iMethod,
    bool ibRemoveAlpha,
    bool ibBlendAlpha)
{
  if (NULL == _spAbstractImpl.get() || IsComplex())
    return false;

  // keep actual image because it's already grey
  if ( (IsL() && !IsBayer()) ||
       (IsLA() && (false == ibRemoveAlpha)) )
    return true;

  shared_ptr<AbstractImage> spImage;

  // variant image deals with Bayer but AbstractImage DOES NOT
  if (IsBayer())
  {
    // change to RGB
    shared_ptr<AbstractImage> spImageRGB = 
      elxCreateImageRGB(*_spAbstractImpl, BCC_Adaptive, _Bayer);

    if (!elxUseable(spImageRGB.get()))
      return false;

    // back to grey
    spImage = elxCreateGreyImage(*spImageRGB, iMethod, ibRemoveAlpha, ibBlendAlpha);

    // no more Bayer
    _Bayer = BM_None;
  }
  else
    spImage = elxCreateGreyImage(*_spAbstractImpl, iMethod, ibRemoveAlpha, ibBlendAlpha);

  // new aggregation
  elxASSERT( elxUseable(spImage.get()) );
  _spAbstractImpl.swap(spImage);

  // check that grey conversion is successfull
  elxASSERT( IsGrey() );
  return true;

} // ChangeToGrey


//----------------------------------------------------------------------------
//  ChangeToColor
//----------------------------------------------------------------------------
bool ImageVariant::ChangeToColor(EGreyToColorConversion iMethod,
    bool ibRemoveAlpha, 
    bool ibBlendAlpha)
{
  if (NULL == _spAbstractImpl.get())
    return false;

  if (IsColor())
  {
    // RGBA<T> to RGB<T>, just remove alpha
    if (HasAlpha() && ibRemoveAlpha)
      return RemoveAlpha(ibBlendAlpha);

    // already a color space
    return true;
  }
  else if (IsBayer()) // already a color space
    return true;
  else if (IsComplex()) // NOT SUPPORTED
    return false;

  shared_ptr<AbstractImage> spImage = 
    elxCreateColorImage(*_spAbstractImpl, CS_RGB, ibBlendAlpha, ibRemoveAlpha, iMethod);
   
  // new aggregation
  elxASSERT( elxUseable(spImage.get()) );
  _spAbstractImpl.swap(spImage);

  // check that color conversion is successfull
  elxASSERT( IsColor() );
  return true;

} // ChangeToColor


//----------------------------------------------------------------------------
//  RemoveAlpha
//----------------------------------------------------------------------------
bool ImageVariant::RemoveAlpha(bool ibBlendAlpha)
{
  if (NULL == _spAbstractImpl.get() || !HasAlpha())
    return false;

  shared_ptr<AbstractImage> spImage = 
    elxCreateImage(*_spAbstractImpl, ibBlendAlpha);

  if (!elxUseable(spImage.get()))
    return false;

  // new aggregation
  _spAbstractImpl.swap(spImage);
  return true;

} // RemoveAlpha

//----------------------------------------------------------------------------
//  AddAlpha
//----------------------------------------------------------------------------
bool ImageVariant::AddAlpha(const ImageVariant& iAlpha)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (!(IsL() || IsRGB())) return false;
  if (!iAlpha.IsL()) return false;

  ImageVariant alpha = iAlpha;

  // check resolution
  const EResolution resolution = GetResolution();
  if (resolution != alpha.GetResolution())
    alpha.ChangeResolution(resolution);

  // check size
  const uint32 w = GetWidth();
  const uint32 h = GetHeight();
  if ((alpha.GetWidth() != w) || (alpha.GetHeight() != h))
    alpha.Resample(w,h);

  // merge two images
  *this = ImageVariant(*this, alpha, false);
  return true;

} // AddAlpha

//----------------------------------------------------------------------------
//  GetChannelAsRGBGrey
//----------------------------------------------------------------------------
bool ImageVariant::GetChannelAsRGBGrey(const ImageVariant& iImage, uint32 iChannel)
{
  if (!iImage.IsValid())
    return false;

  shared_ptr<AbstractImage> spImage = 
    elxCreateImageRGBGrey(*iImage.GetImpl(), iChannel);
  if (!elxUseable(spImage.get()))
    return false;

  // new aggregation
  _spAbstractImpl.swap(spImage);
  return true;

} // GetChannelAsRGBGrey

//----------------------------------------------------------------------------
//  ChangeToUByteFullDynamic
//----------------------------------------------------------------------------
bool ImageVariant::ChangeToUByteFullDynamic()
{
  if (NULL == _spAbstractImpl.get())
    return true;

  shared_ptr<AbstractImage> spImage = 
    elxGetImageHandler(*_spAbstractImpl).
      CreateImageUByteFullDynamic(*_spAbstractImpl);

  if (!elxUseable(spImage.get()))
    return false;

  // new aggregation
  _spAbstractImpl.swap(spImage);
  return true;
    
} // ChangeToUByteFullDynamic

} // namespace Image
} // namespace eLynx
