//============================================================================
//  ImageVariant/Operators_constant.hpp                Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                          Operators with a constant
//============================================================================
//----------------------------------------------------------------------------
//  Operator # generic operator with a constant
//----------------------------------------------------------------------------
bool ImageVariant::Operator(
    EImageOperator iOperator, 
    double iValue, 
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) iChannelMask = CM_All;

  return elxGetOperatorsHandler(*_spAbstractImpl).
    Operator(*_spAbstractImpl, iOperator, iValue, iChannelMask, iNotifier);

} // Operator

//----------------------------------------------------------------------------
//  Neg: transform image to invert value of each pixels
//----------------------------------------------------------------------------
bool ImageVariant::Neg(uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Neg, 0, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Abs: transform image to absolute value of each pixels
//----------------------------------------------------------------------------
bool ImageVariant::Abs(uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Abs, 0, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Add: add a const to image
//----------------------------------------------------------------------------
bool ImageVariant::Add(double iScalar, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Add, iScalar, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Sub: substract a const to image
//----------------------------------------------------------------------------
bool ImageVariant::Sub(double iScalar, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Sub, iScalar, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Mul: mul image with a constant
//----------------------------------------------------------------------------
bool ImageVariant::Mul(double iScalar, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Mul, iScalar, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Div: divide an image by a constant
//----------------------------------------------------------------------------
bool ImageVariant::Div(double iScalar, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Div, iScalar, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Dif: absolute difference with a constant
//----------------------------------------------------------------------------
bool ImageVariant::Dif(double iScalar, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Dif, iScalar, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Min: min of sample and a constant
//----------------------------------------------------------------------------
bool ImageVariant::Min(double iScalar, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Min, iScalar, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Max: max of sample and a constant
//----------------------------------------------------------------------------
bool ImageVariant::Max(double iScalar, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Max, iScalar, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Mean: mean of sample and a constant
//----------------------------------------------------------------------------
bool ImageVariant::Mean(double iScalar, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Mean, iScalar, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  AddClamp: add a const to image
//----------------------------------------------------------------------------
bool ImageVariant::AddClamp(double iScalar, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_AddClamp, iScalar, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  SubClamp: substract a const to image
//----------------------------------------------------------------------------
bool ImageVariant::SubClamp(double iScalar, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_SubClamp, iScalar, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  MulClamp: mul image with a const scaling factor
//----------------------------------------------------------------------------
bool ImageVariant::MulClamp(double iScalar, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_MulClamp, iScalar, iChannelMask, iNotifier);
}

} // namespace Image
} // namespace eLynx
