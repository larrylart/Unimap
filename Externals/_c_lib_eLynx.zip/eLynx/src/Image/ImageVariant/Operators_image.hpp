//============================================================================
//  ImageVariant/Operators_image.hpp                   Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                      Operators with another image
//                  ISO format, ISO dimension, ISO Bayer
//============================================================================
bool ImageVariant::Operator(
    EImageOperator iOperator, 
    const ImageVariant& iImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if ((NULL == _spAbstractImpl.get()) || (!iImage.IsValid()))
    return false;

  // check ISO format
  const EPixelFormat format = GetPixelFormat();
  if (format != iImage.GetPixelFormat())
    return false;

  // check ISO Bayer matrix
  if (_Bayer != iImage._Bayer)
    return false;

  const AbstractImage& image = *iImage.GetImpl();
  return elxGetOperatorsHandler(format).
    Operator( *_spAbstractImpl.get(), iOperator, image, iChannelMask, iNotifier);

} // Operator


//----------------------------------------------------------------------------
//  Add: add another ISO size & format image
//----------------------------------------------------------------------------
bool ImageVariant::Add(const ImageVariant& iImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Add, iImage, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Sub: sub another ISO size & format image
//----------------------------------------------------------------------------
bool ImageVariant::Sub(const ImageVariant& iImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Sub, iImage, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Mul: mul another ISO size & format image
//----------------------------------------------------------------------------
bool ImageVariant::Mul(const ImageVariant& iImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Mul, iImage, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Div: division of image by another ISO size & format image
//----------------------------------------------------------------------------
bool ImageVariant::Div(const ImageVariant& iImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Div, iImage, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Min: mininum between this and another image (ISO size & format image)
//----------------------------------------------------------------------------
bool ImageVariant::Min(const ImageVariant& iImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Min, iImage, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Max: maximum between this and another image (ISO size & format image)
//----------------------------------------------------------------------------
bool ImageVariant::Max(const ImageVariant& iImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Max, iImage, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Mean: mean of this with another image (ISO size & format image)
//----------------------------------------------------------------------------
bool ImageVariant::Mean(const ImageVariant& iImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Mean, iImage, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  AddClamp: 
//----------------------------------------------------------------------------
bool ImageVariant::AddClamp(const ImageVariant& iImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_AddClamp, iImage, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  SubClamp: 
//----------------------------------------------------------------------------
bool ImageVariant::SubClamp(const ImageVariant& iImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_SubClamp, iImage, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  MulClamp: 
//----------------------------------------------------------------------------
bool ImageVariant::MulClamp(const ImageVariant& iImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_MulClamp, iImage, iChannelMask, iNotifier);
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                 operators with another image and an image mask
//                     ISO format, ISO dimension, ISO Bayer
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
bool ImageVariant::Operator(
    EImageOperator iOperator, 
    const ImageVariant& iImage,
    const ImageLub& iImageMask,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if ((NULL == _spAbstractImpl.get()) || 
    !iImage.IsValid() || !iImageMask.IsValid()) return false;

  // check ISO format
  const EPixelFormat format = GetPixelFormat();
  if (format != iImage.GetPixelFormat())
    return false;

  // check ISO Bayer matrix
  if (_Bayer != iImage._Bayer)
    return false;

  const AbstractImage& image = *iImage.GetImpl();
  return elxGetOperatorsHandler(format).
    Operator( *_spAbstractImpl.get(), iOperator, image, iImageMask, iChannelMask, iNotifier);

} // Operator


//----------------------------------------------------------------------------
//  Add: add another ISO size & format image
//----------------------------------------------------------------------------
bool ImageVariant::Add(const ImageVariant& iImage, const ImageLub& iImageMask,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Add, iImage, iImageMask, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Sub: sub another ISO size & format image
//----------------------------------------------------------------------------
bool ImageVariant::Sub(const ImageVariant& iImage, const ImageLub& iImageMask,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Sub, iImage, iImageMask, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Mul: mul another ISO size & format image
//----------------------------------------------------------------------------
bool ImageVariant::Mul(const ImageVariant& iImage, const ImageLub& iImageMask,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Mul, iImage, iImageMask, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Div: division of image by another ISO size & format image
//----------------------------------------------------------------------------
bool ImageVariant::Div(const ImageVariant& iImage, const ImageLub& iImageMask,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Div, iImage, iImageMask, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Min: mininum between this and another image (ISO size & format image)
//----------------------------------------------------------------------------
bool ImageVariant::Min(const ImageVariant& iImage, const ImageLub& iImageMask,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Min, iImage, iImageMask, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Max: maximum between this and another image (ISO size & format image)
//----------------------------------------------------------------------------
bool ImageVariant::Max(const ImageVariant& iImage, const ImageLub& iImageMask,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Max, iImage, iImageMask, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Mean: mean of this with another image (ISO size & format image)
//----------------------------------------------------------------------------
bool ImageVariant::Mean(const ImageVariant& iImage, const ImageLub& iImageMask,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_Mean, iImage, iImageMask, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  AddClamp: 
//----------------------------------------------------------------------------
bool ImageVariant::AddClamp(const ImageVariant& iImage, const ImageLub& iImageMask,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_AddClamp, iImage, iImageMask, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  SubClamp: 
//----------------------------------------------------------------------------
bool ImageVariant::SubClamp(const ImageVariant& iImage, const ImageLub& iImageMask,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_SubClamp, iImage, iImageMask, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  MulClamp: 
//----------------------------------------------------------------------------
bool ImageVariant::MulClamp(const ImageVariant& iImage, const ImageLub& iImageMask,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  return Operator(IOP_MulClamp, iImage, iImageMask, iChannelMask, iNotifier);
}


} // namespace Image
} // namespace eLynx
