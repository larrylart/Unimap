//============================================================================
//  ImageVariant/Edge.hpp                              Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                          Edge detection filters
//============================================================================

//----------------------------------------------------------------------------
//  ApplyGradient
//----------------------------------------------------------------------------
bool ImageVariant::ApplyGradient(
    EEdgeDetector iDetector,
    EEdgeGradient iGradient,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetEdgeProcessingHandler(*_spAbstractImpl).
    ApplyGradient(*_spAbstractImpl, iDetector, iGradient, iChannelMask, iNotifier);

} // ApplyGradient


//----------------------------------------------------------------------------
//  ApplyZeroCrossing
//----------------------------------------------------------------------------
bool ImageVariant::ApplyZeroCrossing(
    double iRadius, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetEdgeProcessingHandler(*_spAbstractImpl).
    ApplyZeroCrossing(*_spAbstractImpl, iRadius, iChannelMask, iNotifier);

} // ApplyZeroCrossing


//----------------------------------------------------------------------------
//  ApplyRoberts
//----------------------------------------------------------------------------
bool ImageVariant::ApplyRoberts(
    bool ibFast, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetEdgeProcessingHandler(*_spAbstractImpl).ApplyRoberts(
    *_spAbstractImpl, ibFast, iChannelMask, iNotifier);

} // ApplyRoberts


//----------------------------------------------------------------------------
//  ApplyCanny
//----------------------------------------------------------------------------
bool ImageVariant::ApplyCanny(
    EEdgeDetector iDetector, EEdgeGradient iGradient,
    double iRadius, double iThresholdLo, double iThresholdHi,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetEdgeProcessingHandler(*_spAbstractImpl).
    ApplyCanny(*_spAbstractImpl, iDetector, iGradient, 
      iRadius, iThresholdLo, iThresholdHi, iChannelMask, iNotifier);

} // ApplyCanny


//----------------------------------------------------------------------------
//  ApplySegmentation
//----------------------------------------------------------------------------
bool ImageVariant::ApplySegmentation(
    double iStep,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetEdgeProcessingHandler(*_spAbstractImpl).
    SegmentImage(*_spAbstractImpl, iStep, iChannelMask, iNotifier);

} // ApplySegmentation

} // namespace Image
} // namespace eLynx
