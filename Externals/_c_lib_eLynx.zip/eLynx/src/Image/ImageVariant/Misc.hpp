//============================================================================
//  ImageVariant/Misc.hpp                              Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                           misceallenous processing
//============================================================================

//----------------------------------------------------------------------------
//  ApplyRotationalGradient
//----------------------------------------------------------------------------
bool ImageVariant::ApplyRotationalGradient(double iXc, double iYc,
    double iRadialShift, double iRotationalShift, bool ibInterpolation,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  const uint32 xc = uint32( iXc * (GetWidth() -1) );
  const uint32 yc = uint32( iYc * (GetHeight()-1) );

  return elxGetMiscHandler(*_spAbstractImpl).
    ApplyRotationalGradient(*_spAbstractImpl, xc, yc, iRadialShift, 
      iRotationalShift, ibInterpolation, iChannelMask, iNotifier);

} // ApplyRotationalGradient

//----------------------------------------------------------------------------
//  RemoveGradient
//----------------------------------------------------------------------------
bool ImageVariant::RemoveGradient(ImageVariant& oBackground,
    const Math::Point2iList& iPoints, EGradientMethod iMethod,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetMiscHandler(*_spAbstractImpl).
    RemoveGradient(*_spAbstractImpl, *oBackground.GetImpl(), iPoints, iMethod, iChannelMask, iNotifier);

} // RemoveGradient

//----------------------------------------------------------------------------
//  Debloom
//----------------------------------------------------------------------------
bool ImageVariant::Debloom(uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetMiscHandler(*_spAbstractImpl).
    Debloom(*_spAbstractImpl, iChannelMask, iNotifier);

} // Debloom

//----------------------------------------------------------------------------
//  ApplyDigitalDevelopment
//----------------------------------------------------------------------------
bool ImageVariant::ApplyDigitalDevelopment(
    double iBackground, double iCrossOver, double iScale,
    double iVariance, EColorEmphasis iEmphasis,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetMiscHandler(*_spAbstractImpl).
    ApplyDigitalDevelopment(*_spAbstractImpl, iBackground, iCrossOver, iScale,
      iVariance, iEmphasis,iChannelMask, iNotifier);

} // ApplyDigitalDevelopment

/*
//----------------------------------------------------------------------------
//  ApplyChannelSubstitution
//----------------------------------------------------------------------------
bool ImageVariant::ApplyChannelSubstitution(
    const ImageVariant& iHighResGrayImage, 
    EChannelSubstitution iSubstitution, double iBlendScalar,
    ProgressNotifier& iNotifier)
{
  // Must be implemented at ImageVariant level not AbstractImage
  // one image must be colored the other grayed

//  gray != color
//  const ImageImpl<Pixel>& grayImage = elxDowncast<Pixel>(iHighResGrayImage);
//  const ImageImpl<Pixel>& colorImage = elxDowncast<Pixel>(iLowResColorImage);

  const AbstractImage& grayImage = *iHighResGrayImage.GetImpl();
  const AbstractImage& colorImage = *this->GetImpl();
  boost::shared_ptr<AbstractImage> spEnhanced = elxGetMiscHandler(*_spAbstractImpl).
    ApplyChannelSubstitution(grayImage, colorImage, iSubstitution, 
      iBlendScalar, iNotifier);
  if (NULL == spEnhanced.get())
    return false;
  this->Assign(spEnhanced);
  return true;

} // ApplyChannelSubstitution
*/

} // namespace Image
} // namespace eLynx
