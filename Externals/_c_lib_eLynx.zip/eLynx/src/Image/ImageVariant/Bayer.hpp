//============================================================================
//  ImageVariant/Bayer.hpp                             Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/Bayer.h>

namespace eLynx {
namespace Image {

//============================================================================
//                             Bayer matrix methods
//============================================================================

//----------------------------------------------------------------------------
//  GetBayerMatrix
//----------------------------------------------------------------------------
EBayerMatrix ImageVariant::GetBayerMatrix() const   
{ 
  return _Bayer; 

} // GetBayerMatrix


//----------------------------------------------------------------------------
//  SetBayerMatrix
//----------------------------------------------------------------------------
bool ImageVariant::SetBayerMatrix(EBayerMatrix iBayer) 
{ 
  if (BM_None == iBayer)
  {
    _Bayer = BM_None;
    return true;
  }
  
  // Bayer matrix is available only for ImageL<T> familly
  if (!IsL())
  {
    _Bayer = BM_None;
    return false;
  }

  _Bayer = iBayer; 
  return true;

} // SetBayerMatrix


//----------------------------------------------------------------------------
//  IsBayer
//----------------------------------------------------------------------------
bool ImageVariant::IsBayer() const 
{ 
  // Bayer matrix is available only for ImageL<T> familly
  return (IsL() && (BM_None != _Bayer)); 

} // IsBayer


//----------------------------------------------------------------------------
//  ComputeMean
//----------------------------------------------------------------------------
bool ImageVariant::ComputeMean(
    double& oMeanR, double& oMeanG, double& oMeanB, 
    bool ibNormalized) const
{
  if (NULL == _spAbstractImpl.get() || !IsBayer()) return false;

  return elxGetBayerHandler(*_spAbstractImpl).
    ComputeMean(*_spAbstractImpl, _Bayer, oMeanR, oMeanG, oMeanB, ibNormalized);

} // ComputeMean


//----------------------------------------------------------------------------
//  ComputeStandardDeviation
//----------------------------------------------------------------------------
bool ImageVariant::ComputeStandardDeviation(
    double& oStdDevR, double& oStdDevG, double& oStdDevB, 
    bool ibNormalized) const
{
  if (NULL == _spAbstractImpl.get() || !IsBayer()) return false;
  
  double dummy;
  return elxGetBayerHandler(*_spAbstractImpl).
    ComputeStandardDeviation(*_spAbstractImpl, _Bayer, dummy,dummy,dummy, oStdDevR, oStdDevG, oStdDevB, ibNormalized);

} // ComputeStandardDeviation


//----------------------------------------------------------------------------
//  ComputeStandardDeviation
//----------------------------------------------------------------------------
bool ImageVariant::ComputeStandardDeviation(double& oMeanR, double& oMeanG, double& oMeanB, 
  double& oStdDevR, double& oStdDevG, double& oStdDevB, bool ibNormalized) const
{
  if (NULL == _spAbstractImpl.get() || !IsBayer()) return false;

  return elxGetBayerHandler(*_spAbstractImpl).
    ComputeStandardDeviation(*_spAbstractImpl, _Bayer, oMeanR,oMeanG,oMeanB, oStdDevR,oStdDevG,oStdDevB, ibNormalized);

} // ComputeStandardDeviation

/*
bool ImageVariant::ComputeStandardDeviation(
    double& oDeviation, 
    double& oMean,
    bool ibNormalized) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetAnalyseHandler(*_spAbstractImpl).
    ComputeStandardDeviation(*_spAbstractImpl, oDeviation, oMean, ibNormalized);
}
bool ImageVariant::ComputeStandardDeviation(
    double (&oDeviation)[PC_MAX],
    double (&oMean)[PC_MAX],
    bool ibNormalized) const
*/

//----------------------------------------------------------------------------
//  Affine
//----------------------------------------------------------------------------
bool ImageVariant::Affine(
    double iScaleR, double iOffsetR, 
    double iScaleG, double iOffsetG, 
    double iScaleB, double iOffsetB)
{
  if (NULL == _spAbstractImpl.get() || !IsBayer()) return false;

  return elxGetBayerHandler(*_spAbstractImpl).
    Affine(*_spAbstractImpl, _Bayer, iScaleR,iOffsetR, iScaleG,iOffsetG, iScaleB,iOffsetB);

} // Affine


//----------------------------------------------------------------------------
//  ChangeToColor
//----------------------------------------------------------------------------
bool ImageVariant::ChangeToColor(
    EBayerToColorConversion iMethod,
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get() || !IsBayer()) return false;

  shared_ptr<AbstractImage> spImage = elxGetBayerHandler(*_spAbstractImpl).
      CreateRGB(*_spAbstractImpl, _Bayer, iMethod, iNotifier);

  if (!elxUseable(spImage.get())) return false;

  _Bayer = BM_None;
  _spAbstractImpl.swap(spImage);
  return true;

} // ChangeToColor


//----------------------------------------------------------------------------
//  ChangeToBayer: convert image to L<T>+Bayer 
//----------------------------------------------------------------------------
bool ImageVariant::ChangeToBayer(
    EBayerMatrix iBayer, 
    bool ibBlendAlpha,
    ProgressNotifier& iNotifier)
{
  if ((NULL == _spAbstractImpl.get()) || IsComplex())
    return false;

  if (BM_None == iBayer)
  {
    if (!IsBayer()) // keep image unchanged
      return true;
    // change bayer to grey
    return ChangeToGrey(CGC_Default, true/*ibRemoveAlpha*/, ibBlendAlpha);
  }

  // already a bayer image with requested bayer matrix
  if (_Bayer == iBayer)
    return true;

  // change to RGB
  ChangeToColor();

  // remove alpha channel
  if (HasAlpha())
    RemoveAlpha(ibBlendAlpha);

  // change format to RGB ISO resolution
  if (!IsRGB())
    ChangeColorSpace(CS_RGB, false/*BlendAlpha*/);

  shared_ptr<AbstractImage> spImage = 
    elxGetBayerHandler(*_spAbstractImpl).
      CreateBayer(*_spAbstractImpl, iBayer, iNotifier);

  // new aggregation
  elxASSERT( elxUseable(spImage.get()) );
  _spAbstractImpl.swap(spImage);

  _Bayer = iBayer;

  // check that bayer conversion is successfull
  elxASSERT(IsBayer());
  elxASSERT(_Bayer == iBayer);
  return true;

} // ChangeToBayer

} // namespace Image
} // namespace eLynx
