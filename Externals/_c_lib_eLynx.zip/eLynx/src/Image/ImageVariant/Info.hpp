//============================================================================
//  ImageVariant/Info.hpp                                   Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxUseable
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
bool elxUseable(const ImageVariant * iprImage)
{
  if (NULL == iprImage) return false;
  return iprImage->IsValid();

} // elxUseable

//----------------------------------------------------------------------------
bool ImageVariant::IsValid() const 
{
  if (NULL == _spAbstractImpl.get()) return false;

  // Bayer matrix is supported only with L images
  if (!IsL() && (_Bayer != BM_None)) return false;

  return _spAbstractImpl->IsValid();

} // IsValid

//----------------------------------------------------------------------------
bool ImageVariant::IsMasking(uint32 iChannelMask) const
{
  return elxIsMasking(GetPixelFormat(), iChannelMask);
} 

//----------------------------------------------------------------------------
shared_ptr<AbstractImage> ImageVariant::GetImpl() 
{ 
  return _spAbstractImpl; 
}
//----------------------------------------------------------------------------
shared_ptr<const AbstractImage> ImageVariant::GetImpl() const 
{ 
  return _spAbstractImpl; 
}

//----------------------------------------------------------------------------
uint32 ImageVariant::GetWidth() const 
{ 
  if (NULL == _spAbstractImpl.get()) return 0;
  return _spAbstractImpl->GetWidth(); 
}  

//----------------------------------------------------------------------------
uint32 ImageVariant::GetHeight() const 
{ 
  if (NULL == _spAbstractImpl.get()) return 0;
  return _spAbstractImpl->GetHeight(); 
}

//----------------------------------------------------------------------------
uint32 ImageVariant::GetPixelCount() const 
{ 
  if (NULL == _spAbstractImpl.get()) return 0;
  return _spAbstractImpl->GetPixelCount(); 
}
//----------------------------------------------------------------------------
uint32 ImageVariant::GetBitsPerPixel() const 
{ 
  if (NULL == _spAbstractImpl.get()) return 0;
  return _spAbstractImpl->GetBitsPerPixel(); 
}
//----------------------------------------------------------------------------
uint32 ImageVariant::sizeofPixel() const
{
  if (NULL == _spAbstractImpl.get()) return 0;
  return _spAbstractImpl->sizeofPixel(); 
}
//----------------------------------------------------------------------------
/* uint32 ImageVariant::sizeofWidth() const
{
  if (NULL == _spAbstractImpl.get()) return 0;
  return _spAbstractImpl->sizeofWidth(); 
}*/
//----------------------------------------------------------------------------
uint32 ImageVariant::sizeofMap() const
{
  if (NULL == _spAbstractImpl.get()) return 0;
  return _spAbstractImpl->sizeofMap(); 
}
//----------------------------------------------------------------------------
uint32 ImageVariant::GetChannelCount() const
{
  if (NULL == _spAbstractImpl.get()) return 0;
  return _spAbstractImpl->GetChannelCount(); 
}
//----------------------------------------------------------------------------
/* uint32 ImageVariant::GetSampleCount() const 
{ 
  if (NULL == _spAbstractImpl.get()) return 0;
  return _spAbstractImpl->GetSampleCount(); 
}*/

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                              Pixel Resolution
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
EResolution ImageVariant::GetResolution() const
{
  if (NULL == _spAbstractImpl.get()) return RT_Undefined;
  return _spAbstractImpl->GetResolution(); 
} 
//----------------------------------------------------------------------------
bool ImageVariant::IsUInt8() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsUInt8(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsUInt16() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsUInt16(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsInt32() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsInt32(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsFloat() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsFloat(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsDouble() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsDouble(); 
}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                              Color Space
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
EColorSpace ImageVariant::GetColorSpace() const
{
  if (NULL == _spAbstractImpl.get()) return CS_Undefined;
  // L + Bayer Matrix => RGB
  if (IsBayer()) return CS_RGB;
  return _spAbstractImpl->GetColorSpace(); 
}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                              Pixel Mode
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
EPixelMode ImageVariant::GetPixelMode() const
{
  if (NULL == _spAbstractImpl.get()) return PM_Undefined;

  // bayer mode means color
  if (BM_None != _Bayer) return PM_Color;  

  return _spAbstractImpl->GetPixelMode(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsColor() const
{
  if (NULL == _spAbstractImpl.get()) return false;

   // bayer mode means color
  if (BM_None != _Bayer) return true; 

  return _spAbstractImpl->IsColor(); 
} 
//----------------------------------------------------------------------------
bool ImageVariant::IsGrey() const
{
  if (NULL == _spAbstractImpl.get()) return false;

  // bayer mode means color
  if (BM_None != _Bayer) return false;  

  return _spAbstractImpl->IsGrey(); 
} 
//----------------------------------------------------------------------------
bool ImageVariant::IsComplex() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsComplex(); 
} 
//----------------------------------------------------------------------------
bool ImageVariant::HasAlpha() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->HasAlpha(); 
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                              Pixel Type
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
EPixelType ImageVariant::GetPixelType() const
{
  if (NULL == _spAbstractImpl.get()) return PT_Undefined;
  return _spAbstractImpl->GetPixelType(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsL() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsL(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLA() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLA(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGB() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGB(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGBA() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGBA(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsHLS() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsHLS(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsXYZ() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsXYZ(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLuv() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLuv(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLab() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLab(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLch() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLch(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsHLab() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsHLab(); 
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                              Pixel Format
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
EPixelFormat ImageVariant::GetPixelFormat() const
{
  if (NULL == _spAbstractImpl.get()) return PF_Undefined;
  return _spAbstractImpl->GetPixelFormat(); 
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLub() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLub();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLus() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLus();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLi() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLi();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLf() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLf();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLd() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLd();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLAub() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLAub();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLAus()  const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLAus();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLAi()  const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLAi();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLAf()  const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLAf();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLAd()  const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLAd();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsComplexi() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsComplexi();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsComplexf()  const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsComplexf();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsComplexd() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsComplexd();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGBub() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGBub();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGBus() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGBus();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGBi() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGBi();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGBf() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGBf();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGBd() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGBd();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGBAub() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGBAub();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGBAus() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGBAus();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGBAi() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGBAi();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGBAf() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGBAf();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsRGBAd() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsRGBAd();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsHLSf() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsHLSf();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsHLSd() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsHLSd();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsXYZf() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsXYZf();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsXYZd() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsXYZd();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLuvf() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLuvf();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLuvd() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLuvd();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLabf() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLabf();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLabd() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLabd();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLchf() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLchf();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsLchd() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsLchd();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsHLabf() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsHLabf();
}
//----------------------------------------------------------------------------
bool ImageVariant::IsHLabd() const
{
  if (NULL == _spAbstractImpl.get()) return false;
  return _spAbstractImpl->IsHLabd();
}

} // namespace Image
} // namespace eLynx
