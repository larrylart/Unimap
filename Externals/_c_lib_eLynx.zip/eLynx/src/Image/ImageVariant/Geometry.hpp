//============================================================================
//  ImageVariant/Geometry.hpp                          Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                                Geometry
//============================================================================

//----------------------------------------------------------------------------
//  Flip
//----------------------------------------------------------------------------
bool ImageVariant::Flip(EFlipPlane iFlipPlane, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  const bool bSuccess = elxGetGeometryHandler(*_spAbstractImpl).
    Flip(*_spAbstractImpl, iFlipPlane, iNotifier);

  _Bayer = elxFlip(_Bayer, iFlipPlane, GetWidth(), GetHeight());
  return bSuccess;

} // Flip


//----------------------------------------------------------------------------
//  FlipVertical
//----------------------------------------------------------------------------
bool ImageVariant::FlipVertical(ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  const bool bSuccess = elxGetGeometryHandler(*_spAbstractImpl).
    Flip(*_spAbstractImpl, FP_Vertical, iNotifier);

  _Bayer = elxFlipVertical(_Bayer, GetHeight());
  return bSuccess;

} // FlipVertical


//----------------------------------------------------------------------------
//  FlipHorizontal
//----------------------------------------------------------------------------
bool ImageVariant::FlipHorizontal(ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  const bool bSuccess = elxGetGeometryHandler(*_spAbstractImpl).
    Flip(*_spAbstractImpl, FP_Horizontal, iNotifier);

  _Bayer = elxFlipHorizontal(_Bayer, GetWidth());
  return bSuccess;

} // FlipHorizontal


//----------------------------------------------------------------------------
//  Rotate
//----------------------------------------------------------------------------
bool ImageVariant::Rotate(
    ERightRotation iRotation, 
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  const bool bSuccess = elxGetGeometryHandler(*_spAbstractImpl).
    Rotate(*_spAbstractImpl, iRotation, iNotifier);

  _Bayer = elxRotate(_Bayer, iRotation, GetWidth(), GetHeight());
  return bSuccess;

} // Rotate


//----------------------------------------------------------------------------
//  Rotate180
//----------------------------------------------------------------------------
bool ImageVariant::Rotate180(ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  const bool bSuccess = elxGetGeometryHandler(*_spAbstractImpl).
    Rotate(*_spAbstractImpl, RR_180, iNotifier);

  _Bayer = elxRotate180(_Bayer, GetWidth(), GetHeight());
  return bSuccess;

} // Rotate180


//----------------------------------------------------------------------------
//  Rotate90Left
//----------------------------------------------------------------------------
bool ImageVariant::Rotate90Left(ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  const bool bSuccess = elxGetGeometryHandler(*_spAbstractImpl).
    Rotate(*_spAbstractImpl, RR_90Left, iNotifier);

  _Bayer = elxRotate(_Bayer, RR_90Left, GetWidth(), GetHeight());
  return bSuccess;

} // Rotate90Left


//----------------------------------------------------------------------------
//  Rotate90Right
//----------------------------------------------------------------------------
bool ImageVariant::Rotate90Right(ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  const bool bSuccess = elxGetGeometryHandler(*_spAbstractImpl).
    Rotate(*_spAbstractImpl, RR_90Right, iNotifier);

  _Bayer = elxRotate(_Bayer, RR_90Right, GetWidth(), GetHeight());
  return bSuccess;

} // Rotate90Right


//----------------------------------------------------------------------------
//  Rotate by double angle / not allowed for Bayer image
//----------------------------------------------------------------------------
bool ImageVariant::Rotate(
    double iDegrees, 
    int32 iFlags, 
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  const bool bSuccess = elxGetGeometryHandler(*_spAbstractImpl).
    Rotate(*_spAbstractImpl, iDegrees, iFlags, iNotifier);
  return bSuccess;

} // Rotate


//----------------------------------------------------------------------------
//  Crop
//----------------------------------------------------------------------------
bool ImageVariant::Crop(
    uint32 iX, uint32 iY, 
    uint32 iWidth, uint32 iHeight,
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  const bool bSuccess = elxGetGeometryHandler(*_spAbstractImpl).
    Crop(*_spAbstractImpl, iX,iY,iWidth,iHeight, iNotifier);

  _Bayer = elxGetBayerAt(_Bayer, iX, iY);
  return bSuccess;

} // Crop


//----------------------------------------------------------------------------
//  AutoCrop
//----------------------------------------------------------------------------
bool ImageVariant::AutoCrop()
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  const bool bSuccess = elxGetGeometryHandler(*_spAbstractImpl).
    AutoCrop(*_spAbstractImpl);

  return bSuccess;

} // AutoCrop


//----------------------------------------------------------------------------
//  AddBorder
//----------------------------------------------------------------------------
bool ImageVariant::AddBorder(
    uint32 iLeft, uint32 iRight, 
    uint32 iTop, uint32 iBottom, 
    bool ibBlack, 
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  const bool bSuccess = elxGetGeometryHandler(*_spAbstractImpl).
    AddBorder(*_spAbstractImpl, iLeft,iRight,iTop,iBottom, ibBlack, iNotifier);

  _Bayer = elxGetBayerAt(_Bayer, iLeft%2, iTop%2);
  return bSuccess;

} // AddBorder


//----------------------------------------------------------------------------
//  Resize
//----------------------------------------------------------------------------
bool ImageVariant::Resize(
    uint32 iWidth, 
    uint32 iHeight, 
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetGeometryHandler(*_spAbstractImpl).
    Resize(*_spAbstractImpl, iWidth,iHeight, iNotifier);

} // Resize


//----------------------------------------------------------------------------
//  Resample
//----------------------------------------------------------------------------
bool ImageVariant::Resample(
    uint32 iWidth, 
    uint32 iHeight, 
    EResampleFilter iFilter,
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetGeometryHandler(*_spAbstractImpl).
    Resample(*_spAbstractImpl, iWidth,iHeight, iFilter, iNotifier);

} // Resample


//----------------------------------------------------------------------------
//  Zoom
//----------------------------------------------------------------------------
bool ImageVariant::Zoom(uint32 iZoom, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetGeometryHandler(*_spAbstractImpl).
    Zoom(*_spAbstractImpl, iZoom, iNotifier);

} // Zoom


//----------------------------------------------------------------------------
//  Bin2x2
//----------------------------------------------------------------------------
bool ImageVariant::Bin2x2(EBinningMethod iMethod, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetGeometryHandler(*_spAbstractImpl).
    Bin(*_spAbstractImpl, 2, iMethod, iNotifier);

} // Bin2x2


//----------------------------------------------------------------------------
//  Bin3x3
//----------------------------------------------------------------------------
bool ImageVariant::Bin3x3(EBinningMethod iMethod, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetGeometryHandler(*_spAbstractImpl).
    Bin(*_spAbstractImpl, 3, iMethod, iNotifier);

} // Bin3x3


//----------------------------------------------------------------------------
//  Shift
//----------------------------------------------------------------------------
bool ImageVariant::Shift(
    int32 iHorizontal, 
    int32 iVertical, 
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) 
  {
    // works only with odd shift
    if ((iHorizontal % 2 == 1) || (iVertical % 2 == 1))
    return false; 
  }

  return elxGetGeometryHandler(*_spAbstractImpl).
    Shift(*_spAbstractImpl, iHorizontal, iVertical, iNotifier);

} // Shift


//----------------------------------------------------------------------------
//  Shift
//----------------------------------------------------------------------------
bool ImageVariant::Shift(
    double iHorizontal, 
    double iVertical, 
    ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false; 

  return elxGetGeometryHandler(*_spAbstractImpl).
    Shift(*_spAbstractImpl, iHorizontal, iVertical, iNotifier);

} // Shift


//----------------------------------------------------------------------------
//  GetSubImage
//----------------------------------------------------------------------------
bool ImageVariant::GetSubImage(
    const ImageVariant& iImage, 
    uint32 iX, uint32 iY, uint32 iWidth, uint32 iHeight,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return false;

  shared_ptr<AbstractImage> pnAbstract = 
    elxGetGeometryHandler(*iImage.GetImpl()).
      CreateSubImage(*iImage.GetImpl(), iX, iY, iWidth, iHeight, iNotifier);
  if (!elxUseable(pnAbstract.get()))
    return false;

  // new aggregation
  _spAbstractImpl.swap(pnAbstract);
  _Bayer = elxGetBayerAt(iImage.GetBayerMatrix(), iX,iY);
  return true;

} // GetSubImage


//----------------------------------------------------------------------------
//  Insert
//----------------------------------------------------------------------------
bool ImageVariant::Insert(
    const ImageVariant& iImage, 
    int32 iX, 
    int32 iY,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid()) return false;
  
  const EPixelFormat pf = GetPixelFormat();
  if (pf != iImage.GetPixelFormat())
  {
    // convert image to insert to the current pixel format
    ImageVariant image(iImage);
    if (image.ChangePixelFormat(pf))
    {
      if (image.GetBayerMatrix() != elxGetBayerAt(_Bayer, iX, iY))
        return false;

      return elxGetGeometryHandler(*_spAbstractImpl).
        Insert(*_spAbstractImpl, *image.GetImpl(), iX,iY, iNotifier);
    }
    else
      return false;
  }

  if (iImage.GetBayerMatrix() != elxGetBayerAt(_Bayer, iX, iY))
    return false;

  return elxGetGeometryHandler(*_spAbstractImpl).
    Insert(*_spAbstractImpl, *iImage.GetImpl(), iX,iY, iNotifier);

} // Insert

//----------------------------------------------------------------------------
//  CreateThumbnailImage
//----------------------------------------------------------------------------
shared_ptr<ImageVariant> 
  ImageVariant::CreateThumbnailImage(
    uint32 iWidth, 
    uint32 iHeight, 
    bool ibConverveAspectRatio,
    ProgressNotifier& iNotifier) const
{
  if (NULL == _spAbstractImpl.get()) return shared_ptr<ImageVariant>();
  if (IsBayer())
  {
    ImageVariant copy = *this;
    copy.ChangeToColor(BCC_Adaptive);
    shared_ptr<AbstractImage> psAbstract = 
      elxCreateThumbnailImage(*copy.GetImpl(), iWidth, iHeight, ibConverveAspectRatio);
    return shared_ptr<ImageVariant>( new ImageVariant(*psAbstract) );
  }
  shared_ptr<AbstractImage> psAbstract = 
    elxCreateThumbnailImage(*_spAbstractImpl, iWidth, iHeight, ibConverveAspectRatio);
  
  return shared_ptr<ImageVariant>( new ImageVariant(*psAbstract) );

} // CreateThumbnailImage


//----------------------------------------------------------------------------
//  GetThumbnail
//----------------------------------------------------------------------------
bool ImageVariant::GetThumbnail(
    const ImageVariant& iImage, 
    uint32 iWidth, 
    uint32 iHeight, 
    bool ibConverveAspectRatio,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid() || (0==iWidth) || (0==iHeight))
    return false;

  if (iImage.IsBayer())
  {
    // first convert to color
    shared_ptr<ImageRGBub> spImageRGBub = 
      elxCreateImageRGBub(*iImage.GetImpl(), NULL, BCC_Adaptive, iImage.GetBayerMatrix());

    _spAbstractImpl = elxCreateThumbnailImage(*spImageRGBub, iWidth, iHeight, ibConverveAspectRatio);
  }
  else
  {
    _spAbstractImpl = elxCreateThumbnailImage(*iImage.GetImpl(), iWidth, iHeight, ibConverveAspectRatio);
  }
  return (NULL != _spAbstractImpl.get());

} // GetThumbnail

} // namespace Image
} // namespace eLynx
