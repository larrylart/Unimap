//============================================================================
//  ImageVariant/Restoration.hpp                       Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                           Rasterization
//============================================================================
//----------------------------------------------------------------------------
//  FastInpaint
//----------------------------------------------------------------------------
bool ImageVariant::FastInpaint(const ImageVariant& iBinaryMask, bool iUseRegion,
  uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  // Mask must be binary Lub format
  if (!iBinaryMask.IsLub()) return false;
  const ImageImpl<PixelLub>& mask = 
    elxDowncast<PixelLub>( *iBinaryMask.GetImpl() );

  return elxGetRestorationHandler(*_spAbstractImpl).
    FastInpaint(*_spAbstractImpl, mask, iUseRegion, iChannelMask, iNotifier);

} // FastInpaint

//----------------------------------------------------------------------------
//  FastMarchingInpaint
//----------------------------------------------------------------------------
bool ImageVariant::FastMarchingInpaint(const ImageVariant& iBinaryMask,
      uint32 iSize, bool iUseRegion, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  
  // Mask must be binary Lub format
  if (!iBinaryMask.IsLub()) return false;
  const ImageImpl<PixelLub>& mask = 
    elxDowncast<PixelLub>( *iBinaryMask.GetImpl() );

  return elxGetRestorationHandler(*_spAbstractImpl).
      FastMarchingInpaint(*_spAbstractImpl, mask, iSize, iUseRegion, iChannelMask, iNotifier);
} // FastMarchingInpaint


//----------------------------------------------------------------------------
//  ExemplarInpaint
//----------------------------------------------------------------------------
bool ImageVariant::ExemplarBasedInpaint(const ImageVariant& iBinaryMask,
      const Math::AOBBox2i& iSearchArea, uint32 iPatchSize, bool iUseRegion,
      uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  
  // Mask must be binary Lub format
  if (!iBinaryMask.IsLub()) return false;
  const ImageImpl<PixelLub>& mask = 
    elxDowncast<PixelLub>( *iBinaryMask.GetImpl() );

  return elxGetRestorationHandler(*_spAbstractImpl).
      ExemplarBasedInpaint(*_spAbstractImpl, mask, iSearchArea, iPatchSize, iUseRegion, 
        iChannelMask, iNotifier);
} // ExemplarInpaint


} // namespace Image
} // namespace eLynx
