//============================================================================
//  ImageVariant/GlobalToPoint.hpp                     Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/KernelPSF.h>

namespace eLynx {
namespace Image {

//============================================================================
//                     Global to point processing
//============================================================================

//----------------------------------------------------------------------------
//  Normalize
//----------------------------------------------------------------------------
bool ImageVariant::Normalize(uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetGlobalToPointHandler(*_spAbstractImpl).
    Normalize(*_spAbstractImpl, iChannelMask, iNotifier);

} // Normalize


//----------------------------------------------------------------------------
//  AutoBrightness
//----------------------------------------------------------------------------
bool ImageVariant::AutoBrightness(ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;

  if (IsL() || IsLA() || IsRGB() || IsRGBA())
    return elxGetGlobalToPointHandler(*_spAbstractImpl).
      AutoBrightness(*_spAbstractImpl, iNotifier);

  bool bSuccess = false;
  if (IsColor())
  {
    const EColorSpace cs = GetColorSpace();
    bSuccess = ChangeColorSpace(CS_RGB);
    bSuccess = bSuccess && elxGetGlobalToPointHandler(*_spAbstractImpl).
      AutoBrightness(*_spAbstractImpl, iNotifier);
    bSuccess = bSuccess && ChangeColorSpace(cs);
  }
  return bSuccess;

} // AutoBrightness


//----------------------------------------------------------------------------
//  AutoBalance
//----------------------------------------------------------------------------
bool ImageVariant::AutoBalance(ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer() || IsGrey() || IsComplex()) return false;

  if (IsRGB() || IsRGBA())
    return elxGetGlobalToPointHandler(*_spAbstractImpl).
      AutoBalance(*_spAbstractImpl, iNotifier);

  bool bSuccess = false;
  if (IsColor())
  {
    const EColorSpace cs = GetColorSpace();
    bSuccess = ChangeColorSpace(CS_RGB);
    bSuccess = bSuccess && elxGetGlobalToPointHandler(*_spAbstractImpl).
      AutoBalance(*_spAbstractImpl, iNotifier);
    bSuccess = bSuccess && ChangeColorSpace(cs);
  }
  return bSuccess;

} // AutoBalance


//----------------------------------------------------------------------------
//  DeconvolveRL
//----------------------------------------------------------------------------
bool ImageVariant::DeconvolveRL(const IImagePSF& iPSF, uint32 iIteration,
    EBorderFill iBorder, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  
  EResolution resolution = GetResolution();
  if (IsFloat() || IsDouble())
  {
    return elxGetGlobalToPointHandler(*_spAbstractImpl).
      DeconvolveRL(*_spAbstractImpl, iPSF, iIteration, iBorder, iChannelMask, iNotifier);
  }
  else
  {
    // it's better to process in float resolution without scaling
    if (IsUInt8() || IsUInt16())
      ChangeResolution(RT_Float, false);
    else
      ChangeResolution(RT_Double, false);
      
    bool bSuccess = elxGetGlobalToPointHandler(*_spAbstractImpl).
      DeconvolveRL(*_spAbstractImpl, iPSF, iIteration, iBorder, iChannelMask, iNotifier);
    
    // back to original resolution
    ChangeResolution(resolution, false);
    
    return bSuccess;
  }

} // DeconvolveRL


//----------------------------------------------------------------------------
//  DeconvolveRL
//----------------------------------------------------------------------------
bool ImageVariant::DeconvolveRL(double iRadius, double iSigma, uint32 iIteration,
    EBorderFill iBorder, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;
  
  uint32 r = uint32(2.0*iRadius + 0.5);
  if (0 == (r&1)) r++;
  ConvolutionKerneld Gw = elxMakeGaussianSeparableKernel(r, iSigma, true);
  ConvolutionKerneld Gh = elxMakeGaussianSeparableKernel(r, iSigma, false);
  KernelPSF psf(Gw, Gh);
  return elxGetGlobalToPointHandler(*_spAbstractImpl).
    DeconvolveRL(*_spAbstractImpl, psf, iIteration, iBorder, iChannelMask, iNotifier);

} // DeconvolveRL


//----------------------------------------------------------------------------
//  ApplyFFT
//----------------------------------------------------------------------------
bool ImageVariant::ApplyFFT(
    const ImageVariant& iFilter,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetGlobalToPointHandler(*_spAbstractImpl).
    ApplyFFT(*_spAbstractImpl, *iFilter.GetImpl(), iChannelMask, iNotifier);

} // ApplyFFT


//----------------------------------------------------------------------------
//  ApplyFFTLowPass
//----------------------------------------------------------------------------
bool ImageVariant::ApplyFFTLowPass(
    double iCutoff, uint32 iRank,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (NULL == _spAbstractImpl.get()) return false;
  return elxGetGlobalToPointHandler(*_spAbstractImpl).
    ApplyFFTLowPass(*_spAbstractImpl, iCutoff, iRank, iChannelMask, iNotifier);

} // ApplyFFTLowPass

} // namespace Image
} // namespace eLynx
