//============================================================================
//  ImageVariant/Morphological.hpp                     Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                          Morphological filters
//============================================================================
//----------------------------------------------------------------------------
//  ApplyMorphological # generic with blending
//----------------------------------------------------------------------------
bool ImageVariant::ApplyMorphological(EMorphologicalFilterType iType, 
    uint32 iWidth, bool ibCircular, 
    bool ibLuminance, uint32 iIteration, double iBlend,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  // enable for Bayer matrix
  if (NULL == _spAbstractImpl.get()) return false;
  if (!IsMasking(iChannelMask)) return true;

  if (1.0 == iBlend)
    return elxGetMorphologicalHandler(*_spAbstractImpl).
      Apply(*_spAbstractImpl, iType, iWidth, ibCircular, ibLuminance, iIteration, iChannelMask, iNotifier);
  
  ImageVariant original = *this;
  bool bSuccess = elxGetMorphologicalHandler(*_spAbstractImpl).
    Apply(*_spAbstractImpl, iType, iWidth, ibCircular, ibLuminance, iIteration, iChannelMask, iNotifier);

  if (bSuccess)
  {
    // we keep original where channel mask is not used
    original.Blend(*this, 1.0-iBlend, iChannelMask);
    *this = original;
    return true;
  }

  // restore original image
  *this = original;
  return false;

} // ApplyMorphological


//----------------------------------------------------------------------------
//  Despeckle
//----------------------------------------------------------------------------
bool ImageVariant::Despeckle(uint32 iWidth, bool ibCircular, bool ibLuminance, 
    uint32 iIteration, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  // enable for Bayer matrix
  if (NULL == _spAbstractImpl.get()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetMorphologicalHandler(*_spAbstractImpl).
      Apply(*_spAbstractImpl, MFT_Median, iWidth, 
        ibCircular, ibLuminance, iIteration, iChannelMask, iNotifier);

} // Despeckle


//----------------------------------------------------------------------------
//  Erode
//----------------------------------------------------------------------------
bool ImageVariant::Erode(uint32 iWidth, bool ibCircular, bool ibLuminance, 
    uint32 iIteration, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  // enable for Bayer matrix
  if (NULL == _spAbstractImpl.get()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetMorphologicalHandler(*_spAbstractImpl).
      Apply(*_spAbstractImpl, MFT_Erode, iWidth, 
        ibCircular, ibLuminance, iIteration, iChannelMask, iNotifier);

} // Erode


//----------------------------------------------------------------------------
//  Dilate
//----------------------------------------------------------------------------
bool ImageVariant::Dilate(uint32 iWidth, bool ibCircular, bool ibLuminance, 
    uint32 iIteration, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  // enable for Bayer matrix
  if (NULL == _spAbstractImpl.get()) return false;
  if (!IsMasking(iChannelMask)) return true;

  return elxGetMorphologicalHandler(*_spAbstractImpl).
      Apply(*_spAbstractImpl, MFT_Dilate, iWidth, 
        ibCircular, ibLuminance, iIteration, iChannelMask, iNotifier);

} // Dilate


//----------------------------------------------------------------------------
//  Open = Erode followed by Dilate filters
//----------------------------------------------------------------------------
bool ImageVariant::Open(uint32 iWidth, bool ibCircular, bool ibLuminance, 
    uint32 iIteration, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  // enable for Bayer matrix
  if (NULL == _spAbstractImpl.get()) return false;
  if (!IsMasking(iChannelMask)) return true;

  elxGetMorphologicalHandler(*_spAbstractImpl).
      Apply(*_spAbstractImpl, MFT_Erode, iWidth, 
        ibCircular, ibLuminance, iIteration, iChannelMask, iNotifier);

  return  elxGetMorphologicalHandler(*_spAbstractImpl).
      Apply(*_spAbstractImpl, MFT_Dilate, iWidth, 
        ibCircular, ibLuminance, iIteration, iChannelMask, iNotifier);

} // Open


//----------------------------------------------------------------------------
//  Close = Dilate followed by Erode filters
//----------------------------------------------------------------------------
bool ImageVariant::Close(uint32 iWidth, bool ibCircular, bool ibLuminance, 
    uint32 iIteration, uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  // enable for Bayer matrix
  if (NULL == _spAbstractImpl.get()) return false;
  if (!IsMasking(iChannelMask)) return true;

  elxGetMorphologicalHandler(*_spAbstractImpl).
      Apply(*_spAbstractImpl, MFT_Dilate, iWidth, 
        ibCircular, ibLuminance, iIteration, iChannelMask, iNotifier);

  return elxGetMorphologicalHandler(*_spAbstractImpl).
      Apply(*_spAbstractImpl, MFT_Erode, iWidth, 
        ibCircular, ibLuminance, iIteration, iChannelMask, iNotifier);

} // Close


//----------------------------------------------------------------------------
//  TopHat = difference between the eroded and dilated image
//----------------------------------------------------------------------------
bool ImageVariant::TopHat(uint32 iWidth, bool ibCircular, bool ibLuminance, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  // enable for Bayer matrix
  if (NULL == _spAbstractImpl.get()) return false;
  if (!IsMasking(iChannelMask)) return true;

  Erode(iWidth, ibCircular, ibLuminance, 1, iChannelMask, iNotifier);

  // copy of original
  ImageVariant Dilated(*this);
  Dilated.Dilate(iWidth, ibCircular, ibLuminance, 1, iChannelMask, iNotifier);

  // TopHat = Eroded - Dilated
  Sub(Dilated);

  return true;

} // TopHat

//----------------------------------------------------------------------------
//  ApplyMedian
//----------------------------------------------------------------------------
bool ImageVariant::ApplyMedian(uint32 iW, uint32 iIteration, 
    bool ibCircular, bool ibLuminance, double iBlend,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  // enable for Bayer matrix
  if (NULL == _spAbstractImpl.get()) return false;
  if (!IsMasking(iChannelMask)) return true;

  if (1.0 == iBlend)
    return elxGetMorphologicalHandler(*_spAbstractImpl).
      Apply(*_spAbstractImpl, MFT_Median,
          iW, ibCircular, ibLuminance, iIteration, iChannelMask, iNotifier);
  
  ImageVariant original = *this;
  bool bSuccess = elxGetMorphologicalHandler(*_spAbstractImpl).
    Apply(*_spAbstractImpl, MFT_Median,
        iW, ibCircular, ibLuminance, iIteration, iChannelMask, iNotifier);

  if (bSuccess)
  {
    // we keep original where channel mask is not used
    original.Blend(*this, 1.0-iBlend, iChannelMask);
    *this = original;
    return true;
  }

  // restore original image
  *this = original;
  return false;

} // ApplyMedian


//----------------------------------------------------------------------------
//  ApplyAdaptiveMedian
//----------------------------------------------------------------------------
bool ImageVariant::ApplyAdaptiveMedian(uint32 iWMax, uint32 iIteration, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  // enable for Bayer matrix  
  if (NULL == _spAbstractImpl.get()) return false;

  return elxGetMorphologicalHandler(*_spAbstractImpl).
    ApplyAdaptiveMedian(*_spAbstractImpl, iWMax, iIteration, iChannelMask, iNotifier);

} // ApplyAdaptiveMedian

} // namespace Image
} // namespace eLynx
