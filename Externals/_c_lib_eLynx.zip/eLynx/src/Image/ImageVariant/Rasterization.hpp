//============================================================================
//  ImageVariant/Rasterization.hpp                     Image.Component package
//============================================================================
//  Usage : image variant class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
namespace eLynx {
namespace Image {

//============================================================================
//                           Rasterization
//============================================================================

//----------------------------------------------------------------------------
//  Clear
//----------------------------------------------------------------------------
bool ImageVariant::Clear(uint32 iChannelMask)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetRasterizationHandler(*_spAbstractImpl).
    Clear(*_spAbstractImpl, iChannelMask);

} // Clear

//----------------------------------------------------------------------------
//  Plot
//----------------------------------------------------------------------------
bool ImageVariant::Plot(int32 iX, int32 iY, uint32 iChannelMask)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetRasterizationHandler(*_spAbstractImpl).
    Plot(*_spAbstractImpl, iX,iY, iChannelMask);

} // Plot

//----------------------------------------------------------------------------
//  DrawHLine
//----------------------------------------------------------------------------
bool ImageVariant::DrawHLine(int32 iY, int32 iX1, int32 iX2, uint32 iChannelMask)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetRasterizationHandler(*_spAbstractImpl).
    DrawHLine(*_spAbstractImpl, iY, iX1, iX2, iChannelMask);

} // DrawHLine

//----------------------------------------------------------------------------
//  DrawLine
//----------------------------------------------------------------------------
bool ImageVariant::DrawLine(int32 iX1, int32 iY1, int32 iX2, int32 iY2, 
    bool ibAntialiasing, uint32 iChannelMask)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetRasterizationHandler(*_spAbstractImpl).
    DrawLine(*_spAbstractImpl, iX1, iY1, iX2, iY2, ibAntialiasing, iChannelMask);

} // DrawLine

//----------------------------------------------------------------------------
//  DrawRectangle
//----------------------------------------------------------------------------
bool ImageVariant::DrawRectangle(int32 iX1, int32 iY1, int32 iX2, int32 iY2, 
    bool ibSolid, uint32 iChannelMask)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetRasterizationHandler(*_spAbstractImpl).
    DrawRectangle(*_spAbstractImpl, iX1, iY1, iX2, iY2, ibSolid, iChannelMask);

} // DrawRectangle

//----------------------------------------------------------------------------
//  DrawEllipse
//----------------------------------------------------------------------------
bool ImageVariant::DrawEllipse(int32 iX, int32 iY, uint32 iRadiusX, uint32 iRadiusY,
    bool ibSolid, uint32 iChannelMask)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetRasterizationHandler(*_spAbstractImpl).
    DrawEllipse(*_spAbstractImpl, iX, iY, iRadiusX, iRadiusY, ibSolid, iChannelMask);

} // DrawEllipse


//----------------------------------------------------------------------------
//  DrawCircle
//----------------------------------------------------------------------------
bool ImageVariant::DrawCircle(int32 iX, int32 iY, uint32 iRadius,
    bool ibSolid, uint32 iChannelMask)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetRasterizationHandler(*_spAbstractImpl).
    DrawCircle(*_spAbstractImpl, iX, iY, iRadius, ibSolid, iChannelMask);

} // DrawCircle

//----------------------------------------------------------------------------
//  DrawTriangle
//----------------------------------------------------------------------------
bool ImageVariant::DrawTriangle(int32 iX0, int32 iY0, int32 iX1, int32 iY1, int32 iX2, int32 iY2,
    bool ibSolid, uint32 iChannelMask)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetRasterizationHandler(*_spAbstractImpl).
    DrawTriangle(*_spAbstractImpl, iX0,iY0, iX1,iY1, iX2,iY2, ibSolid, iChannelMask);

} // DrawTriangle

//----------------------------------------------------------------------------
//  Fill
//----------------------------------------------------------------------------
bool ImageVariant::Fill(int32 iX, int32 iY, uint32 iChannelMask)
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetRasterizationHandler(*_spAbstractImpl).
    Fill(*_spAbstractImpl, iX,iY, iChannelMask);

} // Fill

//----------------------------------------------------------------------------
//  GetFilledBBox
//----------------------------------------------------------------------------
bool ImageVariant::GetFilledBBox(int32 iX, int32 iY, Math::AOBBox2i& oBBox) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (IsBayer()) return false;

  return elxGetRasterizationHandler(*_spAbstractImpl).
    GetFilledBBox(*_spAbstractImpl, iX,iY, oBBox);

} // GetFilledBBox

} // namespace Image
} // namespace eLynx
