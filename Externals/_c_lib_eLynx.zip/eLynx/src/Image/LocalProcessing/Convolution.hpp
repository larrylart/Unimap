//============================================================================
//  LocalProcessing/Convolution.hpp                    Image.Component package
//============================================================================
//
//  http://www.ph.tn.tudelft.nl/Courses/FIP/noframes/fip-Convolut-2.html
//
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __LocalProcessing_Convolution_hpp__
#define __LocalProcessing_Convolution_hpp__

#include <elx/math/KernelCollection.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Convolve, optimized generic
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        const Math::ConvolutionKerneld& iKernel
//        uint32 iIteration : default is 1
//        ProgressNotifier iNotifier : 
//  Out : bool 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::Convolve(
    ImageImpl<Pixel>& ioImage,
    const Math::ConvolutionKerneld& iKernel,
    double iThresholdMin, 
    double iThresholdMax,
    bool ibAbsolute,
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (iKernel.Is3x3())
    return Convolve3x3(ioImage, iKernel, iThresholdMin, iThresholdMax, 
      ibAbsolute, iBorder, iIteration, iChannelMask, iNotifier);
  else if (iKernel.Is5x5())
    return Convolve5x5(ioImage, iKernel, iThresholdMin, iThresholdMax, 
      ibAbsolute, iBorder, iIteration, iChannelMask, iNotifier);

  return ConvolveWxH(ioImage, iKernel, iThresholdMin, iThresholdMax, 
    ibAbsolute, iBorder, iIteration, iChannelMask, iNotifier);

} // Convolve


//----------------------------------------------------------------------------
//  ApplyGaussian
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplyGaussian(
    ImageImpl<Pixel>& ioImage,
    uint32 iWidth, uint32 iHeight, double iVariance,
    EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  Math::ConvolutionKerneld Gx = Math::elxMakeGaussianSeparableKernel(iWidth, iVariance, true);
  Math::ConvolutionKerneld Gy = Math::elxMakeGaussianSeparableKernel(iHeight, iVariance, false);
  return Convolve(ioImage, Gx, Gy, iBorder, 1, iChannelMask, iNotifier);

} // ApplyGaussian


//----------------------------------------------------------------------------
//  ApplyGaussian
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplyGaussian(
    ImageImpl<Pixel>& ioImage,
    double iRadius, double iVariance,
    EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const uint32 size = Math::elxGetKernelSize(iRadius);
  Math::ConvolutionKerneld Gx = Math::elxMakeGaussianSeparableKernel(size, iVariance, true);
  Math::ConvolutionKerneld Gy = Math::elxMakeGaussianSeparableKernel(size, iVariance, false);
  return Convolve(ioImage, Gx, Gy, iBorder, 1, iChannelMask, iNotifier);

} // ApplyGaussian


//----------------------------------------------------------------------------
//  ApplyGaussian
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplyGaussian(
    ImageImpl<Pixel>& ioImage,
    double iRadius,
    EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  const uint32 size = Math::elxGetKernelSize(iRadius);
  const double variance = Math::elxGetGaussianVariance(iRadius);
  Math::ConvolutionKerneld Gx = Math::elxMakeGaussianSeparableKernel(size, variance, true);
  Math::ConvolutionKerneld Gy = Math::elxMakeGaussianSeparableKernel(size, variance, false);
  return Convolve(ioImage, Gx, Gy, iBorder, 1, iChannelMask, iNotifier);

} // ApplyGaussian

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from IImageLocalProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Convolve, optimized generic
//----------------------------------------------------------------------------
//  public virtual from ImageLocalProcessingImpl
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::Convolve(
    AbstractImage& ioImage,
    const Math::ConvolutionKerneld& iKernel,
    bool ibAbsolute,
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Convolve(image, iKernel, 0.0, 1.0,
    ibAbsolute, iBorder, iIteration, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Convolve, optimized generic using thresholds
//----------------------------------------------------------------------------
//  public virtual from ImageLocalProcessingImpl
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::Convolve(
    AbstractImage& ioImage,
    const Math::ConvolutionKerneld& iKernel,
    double iThresholdMin, 
    double iThresholdMax,
    bool ibAbsolute,
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Convolve(image, iKernel, iThresholdMin, iThresholdMax,
    ibAbsolute, iBorder, iIteration, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  Convolve with separable Wx1 and 1xH kernels
//----------------------------------------------------------------------------
//  public virtual from ImageLocalProcessingImpl
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        uint32 iIteration : default is 1
//        bool ibClamp : true to clamp result after transformation
//        ProgressNotifier& iNotifier : default is 0
//  Out : bool 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::Convolve(
    AbstractImage& ioImage,
    const Math::ConvolutionKerneld& iKernel1,
    const Math::ConvolutionKerneld& iKernel2,
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Convolve(image, iKernel1, iKernel2, iBorder, iIteration, iChannelMask, iNotifier);
}

//----------------------------------------------------------------------------
//  ApplyGaussian
//----------------------------------------------------------------------------
//  public virtual from ImageLocalProcessingImpl
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplyGaussian(
    AbstractImage& ioImage,
    uint32 iWidth, uint32 iHeight, double iVariance,
    EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ApplyGaussian(image, iWidth, iHeight, iVariance,
    iBorder, iIteration, iChannelMask, iNotifier);

} // ApplyGaussian


//----------------------------------------------------------------------------
//  ApplyGaussian
//----------------------------------------------------------------------------
//  public virtual from ImageLocalProcessingImpl
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplyGaussian(
    AbstractImage& ioImage,
    double iRadius, double iVariance,
    EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ApplyGaussian(image, iRadius, iVariance,
    iBorder, iIteration, iChannelMask, iNotifier);

} // ApplyGaussian


//----------------------------------------------------------------------------
//  ApplyGaussian
//----------------------------------------------------------------------------
//  public virtual from ImageLocalProcessingImpl
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplyGaussian(
    AbstractImage& ioImage,
    double iRadius,
    EBorderFill iBorder, uint32 iIteration,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ApplyGaussian(image, iRadius, 
    iBorder, iIteration, iChannelMask, iNotifier);

} // ApplyGaussian

} // namespace Image
} // namespace eLynx

#endif // __LocalProcessing_Convolution_hpp__
