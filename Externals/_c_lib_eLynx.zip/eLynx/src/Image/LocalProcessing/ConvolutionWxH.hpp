//============================================================================
//  LocalProcessing/ConvolutionWxH.hpp                 Image.Component package
//============================================================================
//
//  http://www.ph.tn.tudelft.nl/Courses/FIP/noframes/fip-Convolut-2.html
//
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __LocalProcessing_ConvolutionWxH_hpp__
#define __LocalProcessing_ConvolutionWxH_hpp__

#include "ProcessorEngineWxH.hpp"

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

namespace {

enum EConvolutionDoSpecialization { 
  CDS_NoMask,
  CDS_NoMaskAbsolute,
  CDS_MaskNoThreshold,
  CDS_MaskThreshold
};

//----------------------------------------------------------------------------
//  elxGetConvolutionDoSpecialization
//----------------------------------------------------------------------------
template <typename Pixel>
EConvolutionDoSpecialization elxGetConvolutionDoSpecialization(
    double iThresholdMin, 
    double iThresholdMax, 
    bool ibAbsolute, 
    uint32 iChannelMask)
{
  const bool bUseThreshold = (iThresholdMin != 0.0) || (iThresholdMax != 1.0);
  const bool bUseMask = !Pixel::IsFullMask(iChannelMask);

  return bUseThreshold ? CDS_MaskThreshold :
         bUseMask      ? CDS_MaskNoThreshold : 
         ibAbsolute    ? CDS_NoMaskAbsolute : 
                         CDS_NoMask;

} // elxGetConvolutionDoSpecialization


//----------------------------------------------------------------------------
//                          ConvolutionProcessor
//----------------------------------------------------------------------------
template <typename Pixel, EConvolutionDoSpecialization Specialization>
class ConvolutionProcessor
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  typedef typename Pixel::FloatingPixel Atom;

public:
  ConvolutionProcessor(
      const Math::ConvolutionKerneld& iKernel,
      double iThresholdMin=0.0, 
      double iThresholdMax=1.0,
      bool ibAbsolute=false,
      uint32 iChannelMask=CM_All) :
   _kernel(iKernel),
   _bUseAbsolute(ibAbsolute),
   _bInRange(iThresholdMin <= iThresholdMax),
   _Wk(iKernel.GetWidth()),
   _Hk(iKernel.GetHeight()),   
   _channelMask(iChannelMask),
   _nChannel(Pixel::GetChannelCount()),
   _thresholdMin( F(iThresholdMin * ResolutionTypeTraits<T>::_max) ),
   _thresholdMax( F(iThresholdMax * ResolutionTypeTraits<T>::_max) ),
   _prK(_kernel._spK.get()),
   _doClamp(),
   _specialization()
  {}

  // The oportunity to adjust to the iteration range this processor is going to operate on. 
  // This particular one does not need to. :)
  void SetRange(const IterationRange& iRange)
  {}
  
  uint32 GetWidth()  const { return _Wk; }
  uint32 GetHeight() const { return _Hk; }

  // Do generic, inlined using optimization
  void Do(boost::scoped_array<Atom*>& ispLine, uint32 iX, Pixel * oprDst) const
  { Do(ispLine, iX, oprDst, _specialization); }

private:

  //--------------------------------------------------------------------------
  // Do # no mask, no Threshold = fatest
  //--------------------------------------------------------------------------
  void Do(boost::scoped_array<Atom*>& ispLine, uint32 iX, Pixel * oprDst,
          const IntToType<CDS_NoMask>&) const
  {
    uint32 x,y;
    Atom sum = Atom::Null();
    for (y=0; y<_Hk; y++)
      for (x=0; x<_Wk; x++)
        sum += ispLine[y][iX+x] * _prK[y*_Wk + x];
         
    elxPixelClamp(sum, *oprDst, _doClamp);
  }

  //--------------------------------------------------------------------------
  // Do # no mask, absolute value
  //--------------------------------------------------------------------------
  void Do(boost::scoped_array<Atom*>& ispLine, uint32 iX, Pixel * oprDst,
          const IntToType<CDS_NoMaskAbsolute>&) const
  {
    uint32 x,y;
    Atom sum = Atom::Null();
    for (y=0; y<_Hk; y++)
      for (x=0; x<_Wk; x++)
        sum += ispLine[y][iX+x] * _prK[y*_Wk + x];

    sum = elxPixelAbs(sum);
    elxPixelClamp(sum, *oprDst, _doClamp);
  }

  //--------------------------------------------------------------------------
  // Do # mask, no Threshold
  //--------------------------------------------------------------------------
  void Do(boost::scoped_array<Atom*>& ispLine, uint32 iX, Pixel * oprDst,
          const IntToType<CDS_MaskNoThreshold>&) const
  {
    uint32 x,y;
    Atom mul, sum = Atom::Null();
    for (y=0; y<_Hk; y++)
      for (x=0; x<_Wk; x++)
      {
        mul = elxPixelMul(ispLine[y][iX+x], _prK[y*_Wk + x], _channelMask);
        sum = elxPixelAdd(sum, mul, _channelMask);
      }

    if (_bUseAbsolute)
      sum = elxPixelAbs(sum,_channelMask);
          
    elxPixelClamp(sum, *oprDst, _doClamp, _channelMask);
  }


  //--------------------------------------------------------------------------
  // Do # mask & Threshold, slowest
  //--------------------------------------------------------------------------
  void Do(boost::scoped_array<Atom*>& ispLine, uint32 iX, Pixel * oprDst, 
          const IntToType<CDS_MaskThreshold>&) const  
  {
    uint32 x,y,c;

    // compute channel mask using tMin, tMax
    uint32 channelMask = 0;

    // get current pixel
    Atom p = ispLine[_Hk/2][iX + _Wk/2];
    for (c=0; c<_nChannel; c++)
    {
      if (elxUseChannel(c, _channelMask))
      {
        // the channel is requested, does it fit thresholds?
        if (_bInRange)
        {
          // tMin <= tMax, check Pixel inside range
          if ((p._channel[c] >= _thresholdMin) && (p._channel[c] <= _thresholdMax))
            channelMask |= 1 << c;
        }
        else
        {
          // tMin > tMax, check Pixel outside range
          if ((p._channel[c] >= _thresholdMin) || (p._channel[c] <= _thresholdMax))
            channelMask |= 1 << c;
        }
      }
    }

    // filter user mask selection
    channelMask &= _channelMask;

    // skip pixel if out of thresholds
    if (0 == channelMask) return;

    for (c=0; c<_nChannel; c++)
    {
      if (elxUseChannel(c, _channelMask))
      {
        p._channel[c] = F(0);
        for (y=0; y<_Hk; y++)
          for (x=0; x<_Wk; x++)
            p._channel[c] += ispLine[y][iX+x]._channel[c] * _prK[y*_Wk + x];
      }
    }
    if (_bUseAbsolute)
      p = elxPixelAbs(p, channelMask);

    elxPixelClamp(p, *oprDst, _doClamp, channelMask);
  }

private:
  const Math::ConvolutionKernel<F> _kernel;
  const bool _bUseAbsolute, _bInRange;
  const uint32 _Wk, _Hk, _channelMask, _nChannel;
  const F _thresholdMin, _thresholdMax, * _prK;
  const IntegerToType< ResolutionTypeTraits<typename Pixel::type>::_bInteger > _doClamp;
  const IntToType<Specialization> _specialization;
};

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ConvolveWxH:
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        const Math::ConvolutionKerneld& iKernel
//        uint32 iIteration : default is 1
//        ProgressNotifier iNotifier : 
//  Out : bool 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ConvolveWxH(
    ImageImpl<Pixel>& ioImage,
    const Math::ConvolutionKerneld& iKernel,
    double iThresholdMin, 
    double iThresholdMax,
    bool ibAbsolute,
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;
  typedef typename Pixel::FloatingPixel Atom;

  const EConvolutionDoSpecialization specialization = 
    elxGetConvolutionDoSpecialization<Pixel>(
      iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);

  switch (specialization)
  {
    case CDS_MaskNoThreshold:
    {
      ConvolutionProcessor<Pixel, CDS_MaskNoThreshold> processor(
        iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    case CDS_MaskThreshold:
    {
      ConvolutionProcessor<Pixel, CDS_MaskThreshold> processor(
        iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    case CDS_NoMaskAbsolute: 
    {
      ConvolutionProcessor<Pixel, CDS_NoMaskAbsolute> processor(
        iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    case CDS_NoMask:
    {
      ConvolutionProcessor<Pixel, CDS_NoMask> processor(
        iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    default:
      return false;
  }

} // ConvolveWxH


} // namespace Image
} // namespace eLynx

#endif // __LocalProcessing_ConvolutionWxH_hpp__
