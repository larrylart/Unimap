//============================================================================
//  LocalProcessing/ProcessorEngineWxH.hpp             Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [N] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//
//  http://www.ph.tn.tudelft.nl/Courses/FIP/noframes/fip-Convolut-2.html
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __LocalProcessing_processorEngineWxH_hpp__
#define __LocalProcessing_processorEngineWxH_hpp__

namespace eLynx {
namespace Image {

// convert line from image (Pixel) into window line _Y_ (Atom)
// fill left and right borders according iBorder
#define CONVERT_LINE(Y)                 \
{                                       \
  prAtom = spLine[Y] + halfW;           \
  for (x=0; x<w; x++)                   \
    *prAtom++ = *prSrc++;               \
                                        \
  if (borderF == BF_Cycle)              \
  {                                     \
    for (x=0; x<halfW; x++, prAtom++)   \
    {                                   \
      spLine[Y][x] = spLine[Y][x+w];    \
      *prAtom = spLine[Y][halfW+x];     \
    }                                   \
  }                                     \
  else                                  \
  {                                     \
    if (borderF == BF_Nearest)          \
    {                                   \
      leftBorder = spLine[Y][halfW];    \
      rightBorder = prAtom[-1];         \
    }                                   \
    for (x=0; x<halfW; x++, prAtom++)   \
    {                                   \
      spLine[Y][x] = leftBorder;        \
      *prAtom = rightBorder;            \
    }                                   \
  }                                     \
}                                       \

namespace {

//----------------------------------------------------------------------------
//  EngineLocalToPointWxHTask: process SubImage in Atom space
//  Generic method to iterate over the SubImage line by line process each Pixel. 
//  ProcessorWxH defines how to process a pixel from Atom cache.
//----------------------------------------------------------------------------
//  optimizations :
//  -Transformation inplace ie without allocated another image of same size (low memory cost)
//  -Type conversion for all image is done once (CPU).
//----------------------------------------------------------------------------
//  In  : iSubImage - SubImage to process
//        iProcessor - processor to be applied for each pixel 
//        iBorder - type of border fill
//        ipBorder - pointers to the first and last rows of the whole image
//                   to be used for cycle border
//        iIteration - number of iteration to perform
//        iNotifier  - progress notifier
//  Out : true/false
//----------------------------------------------------------------------------
template <typename Pixel, class Atom, class ProcessorWxH>
struct EngineLocalToPointWxHTask : public IterationRangeTask
{
  EngineLocalToPointWxHTask(
      ImageImpl<Pixel>& ioImage,
      const ProcessorWxH& iProcessor,
      EBorderFill iBorder, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask( IterationRange(0, size_t(ioImage.GetHeight())), iNotifier ),
    _image(ioImage),
    _processor(iProcessor),
    _border(iBorder),
    _spBorder()
  {}
  
  // Split constructor
  EngineLocalToPointWxHTask(
      const EngineLocalToPointWxHTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _image(iOther._image),
    _processor(iOther._processor),
    _border(iOther._border),
    _spBorder( new Pixel[(_processor.GetHeight() - 1)*_image.GetWidth()] )
  {
    // We need to save lines before and after the current fragment to make 
    // smooth transition between ranges 
    const uint32 w = _image.GetWidth();
    const uint32 h = _image.GetHeight();
    const uint32 byteLineSize = w*sizeof(Pixel);
    const uint32 kh = _processor.GetHeight();
    const uint32 halfH = kh/2;
    Pixel * prSrc =  _image.GetPixel();
    Pixel * prBorder = _spBorder.get();
    
    uint32 begin = (uint32)iRange.GetBegin();
    uint32 end = (uint32)iRange.GetEnd();
    uint32 i;

    if (_border == BF_Cycle)
    {
      // For cycle border need to preserve last two image rows for the first 
      // fragment and vise versa. For the fragments in the middle need to 
      // preserve two neighboring lines
      if (iRange.IsFirst())
      {
        elxASSERT(end+kh-2 < h);
        for (i=0; i<halfH; ++i) 
        {
          ::memcpy(prBorder + w*i,         prSrc + w*(i+h-halfH), byteLineSize); 
          ::memcpy(prBorder + w*(i+halfH), prSrc + w*(i+end),     byteLineSize);
        }
      }
      else if (iRange.IsMiddle())
      {
        elxASSERT((end+kh-2 < h) && (begin >= halfH)); 
        for (i=0; i<halfH; ++i)
        { 
          ::memcpy(prBorder + w*i,         prSrc + w*(i+begin-halfH), byteLineSize); 
          ::memcpy(prBorder + w*(i+halfH), prSrc + w*(i+end),         byteLineSize);
        }
      }
      else if (iRange.IsLast())
      {
        elxASSERT(begin >= halfH); 
        for (i=0; i<halfH; ++i)
          ::memcpy(prBorder + w*i, prSrc + w*(i+begin-halfH), byteLineSize);

        for (i=halfH; i<kh-1; ++i)
          ::memcpy(prBorder + w*i, prSrc + w*(i-halfH), byteLineSize);    
      }
      else // SRP_ALL
      {
        for (i=0; i<halfH; ++i) 
          ::memcpy(prBorder + w*i, prSrc + w*(i+h-halfH), byteLineSize); 

        for (i=halfH; i<kh-1; ++i)  
          ::memcpy(prBorder + w*i, prSrc + w*(i-halfH), byteLineSize);    
      }
    }
    else
    {
      // For all other types of border just need to preserve 
      // only neighboring lines for inner fragments
      if (iRange.IsFirst())
      {
        elxASSERT(end+kh-2 < h);
        for (i=halfH; i<kh-1; ++i)  
          ::memcpy(prBorder + w*i, prSrc + w*(i+end-halfH), byteLineSize);
      }    
      else if (iRange.IsMiddle())
      {
        elxASSERT((end+kh-2 < h) && (begin >= halfH));  
        for (i=0; i<halfH; ++i)
        { 
          ::memcpy(prBorder + w*i,         prSrc + w*(i+begin-halfH), byteLineSize); 
          ::memcpy(prBorder + w*(i+halfH), prSrc + w*(i+end),         byteLineSize);
        }
      }
      else if (iRange.IsLast())
      {
        elxASSERT(begin >= halfH);
        for (i=0; i<halfH; ++i) 
          ::memcpy(prBorder + w*i, prSrc + w*(i+begin-halfH), byteLineSize); 
      }   
    }
    
    // Give Processor an oppotunity to adjust range if needed.
    _processor.SetRange(iRange);
  }
 
  uint32 operator()()
  {
    // Copy all member variables to give compiler a hint to keep them in registers
    ProcessorWxH processor(_processor);
    const uint32 w = _image.GetWidth();
    const uint32 h = _image.GetHeight();
    const uint32 begin = (uint32)_begin;
    const uint32 end = (uint32)_end;
    const uint32 Wk = processor.GetWidth();
    const uint32 Hk = processor.GetHeight();   
    const uint32 halfW = Wk/2;
    const uint32 halfH = Hk/2;
    const uint32 lastH = Hk-1;
    const uint32 winLineSize = w + 2*halfW;
    const uint32 byteWinLineSize = winLineSize*sizeof(Atom);
    const uint32 byteCycleLineSize  = w*sizeof(Atom);
    
    Pixel * prBorder = _spBorder.get();
    ESubRangePosition position = _position;
    EBorderFill borderF = _border;
    ProgressNotifier& notifier = _notifier;
    
    if (w == 0 || h == 0) 
      return elxErrInvalidParams;
      
    // caches optimizations
    // --- creates a cached window of Hk lines of width+(W/2)*2
    // (+(W/2)*2 = atom on border, W/2 left, W/2 right)  
    boost::scoped_array<Atom> spWindow( new Atom [Hk * winLineSize] );
    boost::scoped_array<Atom*> spLine( new Atom*[Hk] );
    boost::scoped_array<Atom> spCycle( new Atom [w * lastH] );
    if (NULL == spWindow.get() || NULL == spLine.get() || NULL == spCycle.get())
      return elxErrOutOfMemory;
    Atom * prCycle = spCycle.get();
    
    // --- inits progress ---
    const float ProgressStep = 1 / (float)(end-begin);
    float Progress = 0.0f;
    notifier.SetProgress(0.0f);

    // --- declares variables ---
    uint32 x,y;
    Pixel * prSrc, * prDst;
    const Pixel borderT = (borderF == BF_Black) ? Pixel::Black() : Pixel::White();
    const Atom border(borderT);
    Atom leftBorder(border), rightBorder(border), * prAtom;

    // --- inits variables ---
   for (y=0; y<Hk; ++y)
     spLine[y] = spWindow.get() + y*winLineSize;

    // for cycle border we must save first & last image lines
    if (BF_Cycle == borderF)
    {
      // process first halfH lines
      for (y=0; y<halfH; ++y)
      {
        prSrc = prBorder + (lastH-1-y)*w;
        CONVERT_LINE(y);
      }
      // process last halfW lines
      for (y=halfH; y<2*halfH; ++y)
      {
        prSrc = prBorder + (lastH-1-y)*w;
        CONVERT_LINE(y);
      }

      // save temp border
      for (y=0; y<lastH; y++)
        ::memcpy(prCycle + w*y, spLine[lastH-1-y] + halfW, byteCycleLineSize);
    }

    // reset image source pointer
    prSrc = _image.GetPixel() + w*begin;
    prDst = prSrc;
    
    // -1- converts first line into window line # halfH
    //     needed for BF_Nearest border
    CONVERT_LINE(halfH);

    // -2- first halfH line in window are vertical top border
    if (position == SRP_FIRST || position == SRP_ALL)
    {
      for (y=0; y<halfH; y++)
      {
        switch (borderF)
        {
          case BF_Black:
          case BF_White:
            prAtom = spLine[y];
            for (x=0; x<winLineSize; x++)
              *prAtom++ = border;
            break;

          case BF_Nearest:
            ::memcpy(spLine[y], spLine[halfH], byteWinLineSize);
            break;

          case BF_Cycle:
            ::memcpy(spLine[y] + halfW, prCycle + w*y, byteCycleLineSize);
            break;

          default:
            break;
        }
      }
    }
    else
    {
      Pixel * prSrcSave = prSrc;
      for (y=0; y<halfH; y++)
      {
        prSrc = prBorder + y*w;
        CONVERT_LINE(y);
      } 
      prSrc = prSrcSave; 
    }

    // -3- fill & process next halfH-1 line into window
    for (y=halfH+1; y<lastH; y++)
      CONVERT_LINE(y);

    // -4- process all lines ---
    for (y=begin; y<end; y++)
    {
      // --- fill last line of window ---
      if (y >= end-halfH)
      {
        if (position == SRP_LAST || position == SRP_ALL)
        {
          switch (borderF)
          {
            case BF_Black:
            case BF_White:
              prAtom = spLine[lastH];
              for (x=0; x<winLineSize; x++)
                *prAtom++ = border;
              break;

            case BF_Nearest:
              ::memcpy(spLine[lastH], spLine[lastH-1], byteWinLineSize);
              break;

            case BF_Cycle:
              ::memcpy(spLine[lastH] + halfW, prCycle + w*(y-end+lastH), byteCycleLineSize);
              break;

            default:
              break;
          }
        }
        else
        {
          Pixel * prSrcSave = prSrc;
          prSrc = prBorder + (y-end+lastH)*w;
          CONVERT_LINE(lastH);
          prSrc = prSrcSave;  
        }
      }
      else
      {
        CONVERT_LINE(lastH);
      }

      // -5- apply processor to whole line
      for (x=0; x<w; ++x, ++prDst)
        processor.Do(spLine, x, prDst);

      // -6- Move window lines from bottom to top
      // we just move line pointers to optimize memory management
      prAtom = spLine[0];
      for (x=0; x<lastH; ++x) 
        spLine[x] = spLine[x+1];
      spLine[lastH] = prAtom;

      // --- in progress ... ---
      Progress += ProgressStep;
      notifier.SetProgress(Progress);
    }

    // --- progress end ---
    notifier.SetProgress(1.0f);
    return elxOK;
  }
  
private:  
  ImageImpl<Pixel>&          _image;     // Source Image
  ProcessorWxH               _processor; // Convolution Processor
  EBorderFill                _border;    // Border Type
  boost::shared_array<Pixel> _spBorder;  // For cycle type border
  
}; // EngineLocalToPointWxHTask

} // anonymous-namespace

#undef CONVERT_LINE

template <typename Pixel, class Atom, class ProcessorWxH>
bool elxProcessLocalToPoint(
    ImageImpl<Pixel>& ioImage,
    const ProcessorWxH& iProcessor,
    EBorderFill iBorder=BF_Nearest, 
    uint32 iIteration=1,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL,
    bool ibUseParallelImpl=true)
{
  if (!ioImage.IsValid()) return false;
  if (0 == iIteration) return true;

  const uint32 h = ioImage.GetHeight();
  const uint32 w = ioImage.GetWidth();

  // If multicore optimization is used then each core needs to 
  // operate on at least ~10000 pixels. Otherwise overhead of 
  // splitting the original image, creating threads, etc. would 
  // be bigger then the gain from the parallel implementation.
  // If parallel implementation is not required (iUseParallelImpl = false) then
  // range size is set to the original image size + 1 to prevent multicore split
  uint32 minRangeSize = h + 1; 
  if (ibUseParallelImpl)
    minRangeSize = (w > 10000)? 1 : 10000/w;
  IterationRange range(0, size_t(h), 1, minRangeSize);
  do
  {
    EngineLocalToPointWxHTask<Pixel, Atom, ProcessorWxH> task(
      ioImage, iProcessor, iBorder, iNotifier);

    if (elxOK != elxParallelFor(range, task))
      return false;
  }
  while (--iIteration > 0);
   
  return true;

} // elxProcessLocalToPointWxH


} // namespace Image
} // namespace eLynx

#endif // __LocalProcessing_processorEngineWxH_hpp__
