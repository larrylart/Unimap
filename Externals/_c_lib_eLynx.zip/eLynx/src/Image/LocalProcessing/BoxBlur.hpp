//============================================================================
//  LocalProcessing/BoxBlur.hpp                        Image.Component package
//============================================================================
//  [N] multicore optimization
//  [N] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Burring overview:
//  http://www.jhlabs.com/ip/blurring.html
//
//  For Fast Gaussian blur filter techniques refer:
//
//  Wojciech Jarosz, "Fast Image Convolutions," ACM SIGGRAPH@UIUC. 
//  http://www.acm.uiuc.edu/siggraph/workshops/wjarosz_convolution_2001.pdf
//
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __LocalProcessing_BoxBlur_hpp__
#define __LocalProcessing_BoxBlur_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplyBoxBlur # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplyBoxBlur(
    ImageImpl<Pixel>& ioImage,
    uint32 iWidth, uint32 iHeight, 
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask) || (0 == iIteration)) return true;
  if (Math::elxIsEven(iWidth) || Math::elxIsEven(iHeight)) return false;

  iNotifier.SetProgress(0.0f);

  typedef typename Pixel_t::type T;
  typedef typename Pixel_t::M_type M;
  typedef typename Pixel_t::MulOverflowPixel Pixel_M;
  typedef typename Pixel_M::F_type F;
  const bool bNoMasking = Pixel::IsFullMask(iChannelMask);
  const IntegerToType< ResolutionTypeTraits<T>::_bInteger > doClamp =
    IntegerToType< ResolutionTypeTraits<T>::_bInteger >();

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  const uint32 Wk = iWidth;
  const uint32 Hk = iHeight;
  const uint32 halfW = Wk/2;
  const uint32 halfH = Hk/2;
  const uint32 sizeW = w + 2*halfW;
  const uint32 sizeH = h + 2*halfH;
  const int32 firstW = -int32(Wk);
  const int32 firstH = -int32(Hk);
  F scale = 1/F(Wk * Hk);

  // --- inits progress ---
  const float ProgressStep = 1.0f/float(iIteration*(w+h));
  float Progress = 0.0f;
  iNotifier.SetProgress(Progress);

  // --- declares variables ---
  uint32 x,y,xk;
  const Pixel_t borderT = (iBorder == BF_Black) ? Pixel_t::Black() : Pixel_t::White();
  const Pixel_M border = borderT;
  Pixel_M * prSrcM;
  Pixel_M sum, tmp, leftBorder(border), rightBorder(border);
  
  // create 2 images in M resolution width expanded size
  ImageImpl<Pixel_M> imageW(sizeW, h);
  ImageImpl<Pixel_M> imageH(sizeH, w);
  
  // Fill imageH with original image
  Pixel_t * prSrcT = ioImage.GetPixel();
  Pixel_M * prDstM = imageW.GetPixel() + halfW;
  for (y=0; y<h; y++, prDstM += 2*halfW)
    for (x=0; x<w; x++)
      *prDstM++ = *prSrcT++;

  // loop over iterations
  do
  {
    // Horizontal pass
    prSrcM = imageW.GetPixel();
    for (y=0; y<h; y++)
    {
      // fill left & right borders before processing line
      if (iBorder == BF_Cycle)
      {
        for (x=0; x<halfW; x++)
        {
          prSrcM[x] = prSrcM[x+w];
          prSrcM[x+halfW+w] = prSrcM[x+halfW];
        }
      }
      else
      {             
        if (iBorder == BF_Nearest)
        {
          leftBorder  = prSrcM[halfW];
          rightBorder = prSrcM[halfW+w-1];
        }
        for (x=0; x<halfW; x++)
        {
          prSrcM[x] = leftBorder;
          prSrcM[x+halfW+w] = rightBorder;
        }
      }
      
      prDstM = imageH.GetPixel() + halfH + y;
      
      // process first pixel of line
      sum = *prSrcM++;
      for (xk=1; xk<Wk; xk++) 
        sum += *prSrcM++;
      *prDstM = sum;
      prDstM += sizeH;

      for (x=1; x<w; x++, prSrcM++, prDstM += sizeH)
      {
        sum -= prSrcM[firstW];
        sum += *prSrcM;
        *prDstM = sum;
      }
      
      // --- in progress ... ---
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }

    // Vertical pass (transposed version)
    prSrcM = imageH.GetPixel();
    for (y=0; y<w; y++)
    {
      // fill left & right borders before processing line
      if (iBorder == BF_Cycle)
      {
        for (x=0; x<halfH; x++)
        {
          prSrcM[x] = prSrcM[x+h];
          prSrcM[x+halfH+h] = prSrcM[x+halfH];
        }
      }
      else
      {             
        if (iBorder == BF_Nearest)
        {
          leftBorder  = prSrcM[halfH];
          rightBorder = prSrcM[halfH+h-1];
        }
        for (x=0; x<halfH; x++)
        {
          prSrcM[x] = leftBorder;
          prSrcM[x+halfH+h] = rightBorder;
        }
      }
      
      prDstM = imageW.GetPixel() + halfW + y;
      
      // process first pixel
      sum = *prSrcM++;
      for (xk=1; xk<Hk; xk++) sum += *prSrcM++;
      *prDstM = elxPixelMul(sum, scale);
      prDstM += sizeW;

      for (x=1; x<h; x++, prSrcM++, prDstM += sizeW)
      {
        sum -= prSrcM[firstH];
        sum += *prSrcM;
        *prDstM = elxPixelMul(sum, scale);
      }

      // --- in progress ... ---
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }
  }
  while (--iIteration > 0);

  // convert back to original resolution apply scaling
  prSrcM = imageW.GetPixel() + halfW;
  Pixel_t * prDstT = ioImage.GetPixel();

  if (bNoMasking)
  {
    for (y=0; y<h; y++, prSrcM += 2*halfW)
      for (x=0; x<w; x++, prDstT++, prSrcM++)
        elxPixelClamp(*prSrcM, *prDstT, doClamp);
  }
  else
  {
    for (y=0; y<h; y++, prSrcM += 2*halfW)
      for (x=0; x<w; x++, prDstT++, prSrcM++)
        elxPixelClamp(*prSrcM, *prDstT, doClamp, iChannelMask);
  }

  // --- progress end ---
  iNotifier.SetProgress(1.0f);
  return true;

} // ApplyBoxBlur # ImageImpl<Pixel>


//----------------------------------------------------------------------------
//                              NOT_IMPLEMENTED
// Specialization for pixel's types where convolution does not make sense. 
//----------------------------------------------------------------------------
#ifdef elxUSE_ImageComplex
template <>
bool ImageLocalProcessingImpl<PixelComplexi>::ApplyBoxBlur(ImageImpl<PixelComplexi>&, 
    uint32, uint32, EBorderFill, uint32, uint32, ProgressNotifier&)
{ return false; }

template <>
bool ImageLocalProcessingImpl<PixelComplexf>::ApplyBoxBlur(ImageImpl<PixelComplexf>&, 
    uint32, uint32, EBorderFill, uint32, uint32, ProgressNotifier&)
{ return false; }

template <>
bool ImageLocalProcessingImpl<PixelComplexd>::ApplyBoxBlur(ImageImpl<PixelComplexd>&, 
    uint32, uint32, EBorderFill, uint32, uint32, ProgressNotifier&)
{ return false; }
#endif

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//              virtual from IImageLocalProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplyBoxBlur # AbstractImage
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplyBoxBlur(
    AbstractImage& ioImage,
    uint32 iWidth, uint32 iHeight, 
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ApplyBoxBlur(image, iWidth, iHeight, iBorder, iIteration, 
      iChannelMask, iNotifier);
  
} // ApplyBoxBlur # AbstractImage


} // namespace Image
} // namespace eLynx

#endif // __LocalProcessing_BoxBlur_hpp__
