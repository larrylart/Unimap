//============================================================================
//  LocalProcessing/ProcessorEngine5x5.hpp             Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [N] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//
//  http://www.ph.tn.tudelft.nl/Courses/FIP/noframes/fip-Convolut-2.html
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __LocalProcessing_processorEngine5x5_hpp__
#define __LocalProcessing_processorEngine5x5_hpp__

#include <boost/shared_array.hpp>

#include <elx/math/MathCore.h>
#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>
#include <elx/image/ImageCommon.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

// convert line from image (Pixel) into window line _Y_ (Atom)
// fill left and right borders according iBorder
#define CONVERT_LINE5(_Y_)                    \
{                                             \
  prAtom = prLine##_Y_ + 2;                   \
  for (x=0; x<w; x++)                         \
    *prAtom++ = *prSrc++;                     \
                                              \
  if (borderF == BF_Cycle)                    \
  {                                           \
    prLine##_Y_[0] = prLine##_Y_[w];          \
    prLine##_Y_[1] = prLine##_Y_[w+1];        \
    prAtom[0] = prLine##_Y_[2];               \
    prAtom[1] = prLine##_Y_[3];               \
  }                                           \
  else                                        \
  {                                           \
    if (borderF == BF_Nearest)                \
    {                                         \
      leftBorder = prLine##_Y_[2];            \
      rightBorder = prAtom[-1];               \
    }                                         \
    prLine##_Y_[0]=prLine##_Y_[1]=leftBorder; \
    prAtom[0] = prAtom[1] = rightBorder;      \
  }                                           \
}                                             \

namespace {

//----------------------------------------------------------------------------
//  EngineLocalToPoint5x5Task: process SubImage in Atom space
//  Generic method to iterate over the SubImage line by line process each Pixel. 
//  Processor5x5 defines how to process a pixel from Atom cache.
//----------------------------------------------------------------------------
//  optimizations :
//  -Transformation inplace ie without allocated another image of same size (low memory cost)
//  -Type conversion for all image is done once (CPU).
//----------------------------------------------------------------------------
//  In  : iSubImage - SubImage to process
//        iProcessor - processor to be applied for each pixel 
//        iBorder - type of border fill
//        ipBorder - pointers to the first and last rows of the whole image
//                   to be used for cycle border
//        iIteration - number of iteration to perform
//        iNotifier  - progress notifier
//  Out : true/false
//----------------------------------------------------------------------------
template <typename Pixel, class Atom, class Processor5x5>
struct EngineLocalToPoint5x5Task : public IterationRangeTask
{
  EngineLocalToPoint5x5Task(ImageImpl<Pixel>& ioImage,
      const Processor5x5& iProcessor,
      EBorderFill iBorder, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask( IterationRange(0, size_t(ioImage.GetHeight())), iNotifier ),
    _image(ioImage),
    _processor(iProcessor),
    _border(iBorder),
    _spBorder()
  {}
  
  // Split constructor
  EngineLocalToPoint5x5Task(
      const EngineLocalToPoint5x5Task& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _image(iOther._image),
    _processor(iOther._processor),
    _border(iOther._border),
    _spBorder( new Pixel[4*_image.GetWidth()] )
  {
    // We need to save lines before and after the current 
    // fragment to make smooth transition between ranges
    const uint32 w = _image.GetWidth();
    const uint32 h = _image.GetHeight();
    const uint32 byteLineSize = w*sizeof(Pixel);
    Pixel * prSrc = _image.GetPixel();
    Pixel * prBorder[4] = {
        _spBorder.get() + w*0,  //0
        _spBorder.get() + w*1,  //1
        _spBorder.get() + w*2,  //2
        _spBorder.get() + w*3   //3
    };

    const uint32 begin = (uint32)iRange.GetBegin();
    const uint32 end = (uint32)iRange.GetEnd();
    
    if (_border == BF_Cycle)
    {
      // For cycle border need to preserve last image row for 
      // the first fragment and vise versa. For the fragments 
      // in the middle need to preserve neighboring line
      if (iRange.IsFirst())
      {
        elxASSERT(end+1 < h);
        ::memcpy(prBorder[0], prSrc + w*(h-2),   byteLineSize);
        ::memcpy(prBorder[1], prSrc + w*(h-1),   byteLineSize);
        ::memcpy(prBorder[2], prSrc + w*(end+0), byteLineSize);
        ::memcpy(prBorder[3], prSrc + w*(end+1), byteLineSize);
      }
      else if (iRange.IsMiddle())
      {
        elxASSERT((begin > 1) && (end+1 < h));
        ::memcpy(prBorder[0], prSrc + w*(begin-2), byteLineSize);
        ::memcpy(prBorder[1], prSrc + w*(begin-1), byteLineSize);
        ::memcpy(prBorder[2], prSrc + w*(end+0),   byteLineSize);
        ::memcpy(prBorder[3], prSrc + w*(end+1),   byteLineSize);
      }
      else if (iRange.IsLast())
      {
        elxASSERT(begin > 1);
        ::memcpy(prBorder[0], prSrc + w*(begin-2), byteLineSize);    
        ::memcpy(prBorder[1], prSrc + w*(begin-1), byteLineSize);    
        ::memcpy(prBorder[2], prSrc + w*0,         byteLineSize);
        ::memcpy(prBorder[3], prSrc + w*1,         byteLineSize);
      }
      else // SRP_ALL
      {
        ::memcpy(prBorder[0], prSrc + w*(h-2), byteLineSize);
        ::memcpy(prBorder[1], prSrc + w*(h-1), byteLineSize);
        ::memcpy(prBorder[2], prSrc + w*0,     byteLineSize);
        ::memcpy(prBorder[3], prSrc + w*1,     byteLineSize);
      }
    }
    else
    {
      // For all other types of border just need to preserve 
      // only neighboring line for inner fragments
      if (iRange.IsFirst())
      {
        elxASSERT(end+1 < h);  
        ::memcpy(prBorder[2], prSrc + w*(end+0), byteLineSize);
        ::memcpy(prBorder[3], prSrc + w*(end+1), byteLineSize);
      }    
      else if (iRange.IsMiddle())
      {
        elxASSERT((end+1 < h) && (begin > 1));  
        ::memcpy(prBorder[0], prSrc + w*(begin-2), byteLineSize);
        ::memcpy(prBorder[1], prSrc + w*(begin-1), byteLineSize);
        ::memcpy(prBorder[2], prSrc + w*(end+0),   byteLineSize);
        ::memcpy(prBorder[3], prSrc + w*(end+1),   byteLineSize);
      }
      else if (iRange.IsLast())
      {
        elxASSERT(begin > 1);  
        ::memcpy(prBorder[0], prSrc + w*(begin-2), byteLineSize);
        ::memcpy(prBorder[1], prSrc + w*(begin-1), byteLineSize);
      }   
    }
    
    // Give Processor an oppotunity to adjust range if needed.
    _processor.SetRange(iRange);
  }
  
  uint32 operator()()
  {
    // Copy all member variables to give compiler a hint to keep them in registers
    const uint32 w = _image.GetWidth();
    const uint32 h = _image.GetHeight();
    const uint32 begin = (uint32)_begin;
    const uint32 end = (uint32)_end;
    ESubRangePosition position = _position;
    Processor5x5 processor(_processor);
    EBorderFill borderF = _border;
    ProgressNotifier& notifier = _notifier;
    Pixel * prBorder[4] = {
        _spBorder.get() + w*0,  //0
        _spBorder.get() + w*1,  //1
        _spBorder.get() + w*2,  //2
        _spBorder.get() + w*3   //3
    };

    if (w == 0 || h == 0) 
      return elxErrInvalidParams;
      
    // optimizations
    // --- creates a cached window of 5 lines of width+4 
    const uint32 winLineSize = w+4;
    const uint32 byteWinLineSize = winLineSize * sizeof(Atom);
    const uint32 byteCycleLineSize = w*sizeof(Atom);
    boost::scoped_array<Atom> spWindow( new Atom [5*winLineSize] );
    boost::scoped_array<Atom> spCycle( new Atom [4*w] );
    if (NULL == spWindow.get() || NULL == spCycle.get())
      return elxErrOutOfMemory;

    Atom * prCycle[4] = {
        spCycle.get() + w*0,  //0
        spCycle.get() + w*1,  //1
        spCycle.get() + w*2,  //2
        spCycle.get() + w*3   //3
    };

    // --- inits progress ---
    const float ProgressStep = 1 / (float)(end-begin);
    float Progress = 0.0f;
    notifier.SetProgress(0.0f);

    // --- declares variables ---
    uint32 x,y;
    Pixel * prSrc, * prDst;
    const Pixel borderT = (borderF == BF_Black) ? Pixel::Black() : Pixel::White();
    const Atom border(borderT);
    Atom leftBorder(border), rightBorder(border), * prAtom;
    Atom * prLine0, * prLine1, * prLine2, * prLine3, * prLine4, * LineList[5];

    // --- inits variables ---
    prLine0 = spWindow.get();
    prLine1 = prLine0 + winLineSize;
    prLine2 = prLine1 + winLineSize;
    prLine3 = prLine2 + winLineSize;
    prLine4 = prLine3 + winLineSize;

    // for cycle border we must save first & last image lines
    if (BF_Cycle == borderF)
    {
      prSrc = prBorder[3];
      CONVERT_LINE5(0);
      prSrc = prBorder[2];
      CONVERT_LINE5(1);
      prSrc = prBorder[1];
      CONVERT_LINE5(2);
      prSrc = prBorder[0];
      CONVERT_LINE5(3);

      // save temp border
      ::memcpy(prCycle[0], prLine3 + 2, byteCycleLineSize);
      ::memcpy(prCycle[1], prLine2 + 2, byteCycleLineSize);
      ::memcpy(prCycle[2], prLine1 + 2, byteCycleLineSize);
      ::memcpy(prCycle[3], prLine0 + 2, byteCycleLineSize);
    }

    // reset image source pointer
    prSrc = _image.GetPixel() + begin*w;
    prDst = prSrc;

    // -1- fill prLine2 line from image's first one ---
    CONVERT_LINE5(2);

    // -2- duplicates 3rd line in first two lines ---
    if (position == SRP_FIRST || position == SRP_ALL)
    {
      switch (borderF)
      {
        case BF_Black:
        case BF_White:
          prAtom = prLine0;
          for (x=0; x<winLineSize; x++)
            *prAtom++ = border;

          prAtom = prLine1;
          for (x=0; x<winLineSize; x++)
            *prAtom++ = border;
          break;

        case BF_Nearest:
          ::memcpy(prLine0, prLine2, byteWinLineSize);
          ::memcpy(prLine1, prLine2, byteWinLineSize);
          break;

        case BF_Cycle:
          ::memcpy(prLine0 + 2, prCycle[0], byteCycleLineSize);
          ::memcpy(prLine1 + 2, prCycle[1], byteCycleLineSize);
          break;

        default:
          break;
      }
    }
    else
    {
      Pixel * prSrcSave = prSrc;
      prSrc = prBorder[0];
      CONVERT_LINE5(0);
      prSrc = prBorder[1];
      CONVERT_LINE5(1);
      prSrc = prSrcSave;  
    }

    // -3- fill & process 4th line into window
    CONVERT_LINE5(3);

    // -4- process all lines ---
    for (y=begin; y<end; y++)
    {
      // --- fill last line of window ---
      if (y >= end-2)
      {
        if (position == SRP_LAST || position == SRP_ALL)
        {
          switch (borderF)
          {
            case BF_Black:
            case BF_White:
              prAtom = prLine4;
              for (x=0; x<winLineSize; x++)
                *prAtom++ = border;
              break;

            case BF_Nearest:
              ::memcpy(prLine4, prLine3, byteWinLineSize);
              break;

            case BF_Cycle:
              ::memcpy(prLine4 + 2, prCycle[y-end+4], byteCycleLineSize);
              break;

            default:
              break;
          }
        }
        else
        {
          Pixel * prSrcSave = prSrc;
          prSrc = prBorder[y-end+4];
          CONVERT_LINE5(4);
          prSrc = prSrcSave;  
        }
      }
      else
      {
        CONVERT_LINE5(4);
      }

      // --- process a line ---
      LineList[0] = prLine0;
      LineList[1] = prLine1;
      LineList[2] = prLine2;
      LineList[3] = prLine3;
      LineList[4] = prLine4;

      for (x=0; x<w; ++x, ++prDst)
        processor.Do(LineList, x, prDst);

      // --- next line ---
      prAtom = prLine0;
      prLine0 = prLine1;
      prLine1 = prLine2;
      prLine2 = prLine3;
      prLine3 = prLine4;
      prLine4 = prAtom;

      // --- in progress ... ---
      Progress += ProgressStep;
      notifier.SetProgress(Progress);
    }

    // --- progress end ---
    notifier.SetProgress(1.0f);
    return elxOK;
  }

private:
  ImageImpl<Pixel>&          _image;     // Source Image
  Processor5x5               _processor; // Convolution Processor
  EBorderFill                _border;    // Border Type
  boost::shared_array<Pixel> _spBorder;  // For cycle type border 
                                         // prBorder[0] points to the first row of the image
                                         // prBorder[3] points to the last row of the image
}; // EngineLocalToPoint5x5Task

} // anonymous-namespace

#undef CONVERT_LINE5

template <typename Pixel, class Atom, class Processor5x5>
bool elxProcessLocalToPoint5x5(
    ImageImpl<Pixel>& ioImage,
    const Processor5x5& iProcessor,
    EBorderFill iBorder=BF_Nearest, 
    uint32 iIteration=1,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL,
    bool ibUseParallelImpl=true)
{
  if (!ioImage.IsValid()) return false;
  if (0 == iIteration) return true;

  const uint32 h = ioImage.GetHeight();
  const uint32 w = ioImage.GetWidth();

  // If multicore optimization is used then each core needs to 
  // operate on at least ~10000 pixels. Otherwise overhead of 
  // splitting the original image, creating threads, etc. would 
  // be bigger then the gain from the parallel implementation.
  // If parallel implementation is not required (iUseParallelImpl = false) then
  // range size is set to the original image size + 1 to prevent multicore split
  uint32 minRangeSize = h + 1; 
  if (ibUseParallelImpl)
    minRangeSize = (w > 10000)? 1 : 10000/w;
  IterationRange range(0, h, 1, minRangeSize);
  do
  {
    EngineLocalToPoint5x5Task<Pixel, Atom, Processor5x5> task(
      ioImage, iProcessor, iBorder, iNotifier);

    if (elxOK != elxParallelFor(range, task))
      return false;
  }
  while (--iIteration > 0);
   
  return true;

} // elxProcessLocalToPoint5x5

} // namespace Image
} // namespace eLynx

#endif // __LocalProcessing_processorEngine5x5_hpp__
