//============================================================================
//  LocalProcessing/SelectiveBlur.hpp                  Image.Component package
//============================================================================
//  [N] multicore optimization
//  [N] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  SelectiveBlur filter is an edge-preserving filtering technique
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __LocalProcessing_SelectiveBlur_hpp__
#define __LocalProcessing_SelectiveBlur_hpp__

#include "ProcessorEngine3x3.hpp"

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

//----------------------------------------------------------------------------
//  SelectiveBlurProcessor3x3: 
//----------------------------------------------------------------------------
template <typename Pixel>
class SelectiveBlurProcessor3x3
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  typedef typename Pixel::FloatingPixel Atom;

public:
  SelectiveBlurProcessor3x3(uint32 iChannelMask=CM_All) :
    _channelMask(iChannelMask),
    _nChannel( Pixel::GetChannelCount() )
  {}
  
  // The oppotunity to adjust to the iteration range
  // this processor is going to operate on. 
  // This particular one does not need to. :)
  void SetRange(const IterationRange& iRange)
  {}

  // Do generic
  void Do(const Atom * const * iprL, uint32 iX, Pixel * oprDst) const
  {
    T l;
    F sum[4]= {F(0),F(0),F(0),F(0)}, v;
    Atom p2, p = iprL[1][1+iX];
    uint32 c,i,j,k;

    // Compute convolution kernel for each pixel's channels
    for (j=0; j<3; j++)
      for (i=0; i<3; i++)
      {
        k = j*3 + i;
        if ((1 == j) && (1 == i))
        {
          for (c=0; c<_nChannel; c++)
          {
            _k[c][4] = F(0.5);
            sum[c] += F(0.5);
          }
        }
        else
        {
          p2 = elxPixelAbs(p - iprL[j][i+iX]);
          for (c=0; c<_nChannel; c++)
          {
            v = p2._channel[c];
            v = (v == F(0)) ? F(1) : F(1.0/v);
            _k[c][k] = v;
            sum[c] += v;
          }
        }
      }

    // Apply kernels for each channels
    for (c=0; c<_nChannel; c++)
      if (elxUseChannel(c, _channelMask))
      {
        // convolution
        v = 
iprL[0][0+iX]._channel[c]*_k[c][0] + iprL[0][1+iX]._channel[c]*_k[c][1] + iprL[0][2+iX]._channel[c]*_k[c][2] + 
iprL[1][0+iX]._channel[c]*_k[c][3] + iprL[1][1+iX]._channel[c]*_k[c][4] + iprL[1][2+iX]._channel[c]*_k[c][5] +
iprL[2][0+iX]._channel[c]*_k[c][6] + iprL[2][1+iX]._channel[c]*_k[c][7] + iprL[2][2+iX]._channel[c]*_k[c][8];
        
        // normalize
        v /= sum[c];

        // back to Pixel type
        Math::elxClamp(v, l);

        // save
        oprDst->_channel[c] = l;
      }
  }

private:
  const uint32 _channelMask, _nChannel;
  mutable F _k[4][3*3];
};

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplySelectiveBlur # ImageImpl<Pixel>
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplySelectiveBlur(
    ImageImpl<Pixel>& ioImage,
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;
  typedef typename Pixel::FloatingPixel Atom;

  SelectiveBlurProcessor3x3<Pixel> processor(iChannelMask);

  return elxProcessLocalToPoint3x3<Pixel, Atom>(
    ioImage, processor, iBorder, iIteration, iNotifier);

} // ApplySelectiveBlur # ImageImpl<Pixel>


//----------------------------------------------------------------------------
//                              NOT_IMPLEMENTED
// Specialization for pixel's types where convolution does not make sense. 
//----------------------------------------------------------------------------
#ifdef elxUSE_ImageComplex
template <>
bool ImageLocalProcessingImpl<PixelComplexi>::ApplySelectiveBlur(
    ImageImpl<PixelComplexi>&, 
    EBorderFill, uint32, uint32, ProgressNotifier&)
{ return false; }

template <>
bool ImageLocalProcessingImpl<PixelComplexf>::ApplySelectiveBlur(
    ImageImpl<PixelComplexf>&, 
    EBorderFill, uint32, uint32, ProgressNotifier&)
{ return false; }

template <>
bool ImageLocalProcessingImpl<PixelComplexd>::ApplySelectiveBlur(
    ImageImpl<PixelComplexd>&, 
    EBorderFill, uint32, uint32, ProgressNotifier&)
{ return false; }
#endif

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageLocalProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplySelectiveBlur # AbstractImage
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplySelectiveBlur(
    AbstractImage& ioImage,
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ApplySelectiveBlur(image, iBorder, iIteration, iChannelMask, iNotifier);
  
} // ApplySelectiveBlur # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __LocalProcessing_SelectiveBlur_hpp__
