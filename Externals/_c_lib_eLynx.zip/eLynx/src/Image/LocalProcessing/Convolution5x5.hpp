//============================================================================
//  LocalProcessing/Convolution5x5.hpp                 Image.Component package
//============================================================================
//
//  http://www.ph.tn.tudelft.nl/Courses/FIP/noframes/fip-Convolut-2.html
//
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __LocalProcessing_CDS5x5_hpp__
#define __LocalProcessing_CDS5x5_hpp__

#include "ProcessorEngine5x5.hpp"

namespace eLynx {
namespace Image {

namespace {

enum EConvolutionDoSpecialization5x5 { 
  CDS5x5_NoMask,
  CDS5x5_NoMaskAbsolute,
  CDS5x5_MaskNoThreshold,
  CDS5x5_MaskThreshold
};

//----------------------------------------------------------------------------
//                elxGetConvolutionDoSpecialization5x5: 
//----------------------------------------------------------------------------
template <typename Pixel>
EConvolutionDoSpecialization5x5 elxGetConvolutionDoSpecialization5x5(
    double iThresholdMin, 
    double iThresholdMax, 
    bool ibAbsolute, 
    uint32 iChannelMask)
{
  const bool bUseThreshold = (iThresholdMin != 0.0) || (iThresholdMax != 1.0);
  const bool bUseMask = !Pixel::IsFullMask(iChannelMask);

  return bUseThreshold ? CDS5x5_MaskThreshold :
         bUseMask      ? CDS5x5_MaskNoThreshold : 
         ibAbsolute    ? CDS5x5_NoMaskAbsolute : 
                         CDS5x5_NoMask;

} // elxGetConvolutionDoSpecialization5x5


//----------------------------------------------------------------------------
//  ConvolutionProcessor5x5
//----------------------------------------------------------------------------
template <typename Pixel, EConvolutionDoSpecialization5x5 Specialization>
class ConvolutionProcessor5x5
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  typedef typename Pixel::FloatingPixel Atom;

public:
  ConvolutionProcessor5x5(
      const Math::ConvolutionKerneld& iKernel,
      double iThresholdMin=0.0, 
      double iThresholdMax=1.0,
      bool ibAbsolute=false,
      uint32 iChannelMask=CM_All) :
   _bUseAbsolute(ibAbsolute),
   _bInRange( iThresholdMin <= iThresholdMax ),
   _channelMask(iChannelMask),
   _nChannel( Pixel::GetChannelCount() ),
   _thresholdMin( F(iThresholdMin * ResolutionTypeTraits<T>::_max) ),
   _thresholdMax( F(iThresholdMax * ResolutionTypeTraits<T>::_max) ),
   _doClamp(),
   _specialization()
  {
    for (uint32 i=0; i<25; i++)
      _k[i] = (F)iKernel._spK[i];
  }

  // The oportunity to adjust to the iteration range this processor is going to operate on. 
  // This particular one does not need to. :)
  void SetRange(const IterationRange& iRange)
  {}
  
  // Do generic, inlined using optimization
  void Do(const Atom * const * iprLines, uint32 iX, Pixel * oprDst) const
  { Do(iprLines, iX, oprDst, _specialization); }

private:

  //--------------------------------------------------------------------------
  // Do # no mask, no Threshold = fatest
  //--------------------------------------------------------------------------
  void Do(const Atom * const * iprL, uint32 iX, Pixel * oprDst,
          const IntToType<CDS5x5_NoMask>&) const
  {
    Atom p = 
iprL[0][0+iX]*_k[00] + iprL[0][1+iX]*_k[01] + iprL[0][2+iX]*_k[02] + iprL[0][3+iX]*_k[03] + iprL[0][4+iX]*_k[04] +
iprL[1][0+iX]*_k[05] + iprL[1][1+iX]*_k[06] + iprL[1][2+iX]*_k[07] + iprL[1][3+iX]*_k[ 8] + iprL[1][4+iX]*_k[ 9] +
iprL[2][0+iX]*_k[10] + iprL[2][1+iX]*_k[11] + iprL[2][2+iX]*_k[12] + iprL[2][3+iX]*_k[13] + iprL[2][4+iX]*_k[14] +
iprL[3][0+iX]*_k[15] + iprL[3][1+iX]*_k[16] + iprL[3][2+iX]*_k[17] + iprL[3][3+iX]*_k[18] + iprL[3][4+iX]*_k[19] +
iprL[4][0+iX]*_k[20] + iprL[4][1+iX]*_k[21] + iprL[4][2+iX]*_k[22] + iprL[4][3+iX]*_k[23] + iprL[4][4+iX]*_k[24];
    elxPixelClamp(p, *oprDst, _doClamp);
  }

  //--------------------------------------------------------------------------
  // Do # no mask, absolute value
  //--------------------------------------------------------------------------
  void Do(const Atom * const * iprL, uint32 iX, Pixel * oprDst,
          const IntToType<CDS5x5_NoMaskAbsolute>&) const
  {
    Atom p = 
iprL[0][0+iX]*_k[00] + iprL[0][1+iX]*_k[01] + iprL[0][2+iX]*_k[02] + iprL[0][3+iX]*_k[03] + iprL[0][4+iX]*_k[04] +
iprL[1][0+iX]*_k[05] + iprL[1][1+iX]*_k[06] + iprL[1][2+iX]*_k[07] + iprL[1][3+iX]*_k[ 8] + iprL[1][4+iX]*_k[ 9] +
iprL[2][0+iX]*_k[10] + iprL[2][1+iX]*_k[11] + iprL[2][2+iX]*_k[12] + iprL[2][3+iX]*_k[13] + iprL[2][4+iX]*_k[14] +
iprL[3][0+iX]*_k[15] + iprL[3][1+iX]*_k[16] + iprL[3][2+iX]*_k[17] + iprL[3][3+iX]*_k[18] + iprL[3][4+iX]*_k[19] +
iprL[4][0+iX]*_k[20] + iprL[4][1+iX]*_k[21] + iprL[4][2+iX]*_k[22] + iprL[4][3+iX]*_k[23] + iprL[4][4+iX]*_k[24];
    p = elxPixelAbs(p);
    elxPixelClamp(p, *oprDst, _doClamp);
  }

  //--------------------------------------------------------------------------
  // Do # mask, no Threshold
  //--------------------------------------------------------------------------
  void Do(const Atom * const * iprL, uint32 iX, Pixel * oprDst,
          const IntToType<CDS5x5_MaskNoThreshold>&) const
  {
    Atom sum = elxPixelMul(iprL[0][0+iX], _k[0], _channelMask);
    Atom mul = elxPixelMul(iprL[0][1+iX], _k[1], _channelMask);

    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[0][2+iX], _k[2], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[0][3+iX], _k[3], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[0][4+iX], _k[4], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
            
    mul = elxPixelMul(iprL[1][0+iX], _k[5], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[1][1+iX], _k[6], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[1][2+iX], _k[7], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[1][3+iX], _k[8], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[1][4+iX], _k[9], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);

    mul = elxPixelMul(iprL[2][0+iX], _k[10], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[2][1+iX], _k[11], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[2][2+iX], _k[12], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[2][3+iX], _k[13], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[2][4+iX], _k[14], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);

    mul = elxPixelMul(iprL[3][0+iX], _k[15], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[3][1+iX], _k[16], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[3][2+iX], _k[17], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[3][3+iX], _k[18], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[3][4+iX], _k[19], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);

    mul = elxPixelMul(iprL[4][0+iX], _k[20], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[4][1+iX], _k[21], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[4][2+iX], _k[22], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[4][3+iX], _k[23], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[4][4+iX], _k[24], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);

    if (_bUseAbsolute)
      sum = elxPixelAbs(sum, _channelMask);

    elxPixelClamp(sum, *oprDst, _doClamp, _channelMask);
  }

  //--------------------------------------------------------------------------
  // Do # mask & Threshold, slowest
  //--------------------------------------------------------------------------
  void Do(const Atom * const * iprL, uint32 iX, Pixel * oprDst, 
          const IntToType<CDS5x5_MaskThreshold>&) const  
  {
    // compute channel mask using tMin, tMax
    uint32 c, channelMask = 0;

    // get current pixel
    Atom p = iprL[2][iX+2];
    for (c=0; c<_nChannel; c++)
    {
      if (elxUseChannel(c, _channelMask))
      {
        // the channel is requested, does it fit thresholds?
        if (_bInRange)
        {
          // tMin <= tMax, check Pixel inside range
          if ((p._channel[c] >= _thresholdMin) && (p._channel[c] <= _thresholdMax))
            channelMask |= 1 << c;
        }
        else
        {
          // tMin > tMax, check Pixel outside range
          if ((p._channel[c] >= _thresholdMin) || (p._channel[c] <= _thresholdMax))
            channelMask |= 1 << c;
        }
      }
    }

    // filter user mask selection
    channelMask &= _channelMask;

    // skip pixel if out of thresholds
    if (0 == channelMask) return;

    for (c=0; c<_nChannel; c++)
      if (elxUseChannel(c, _channelMask))
      {
        p._channel[c]  = iprL[0][iX+0]._channel[c] * _k[0];
        p._channel[c] += iprL[0][iX+1]._channel[c] * _k[1];
        p._channel[c] += iprL[0][iX+2]._channel[c] * _k[2];
        p._channel[c] += iprL[0][iX+3]._channel[c] * _k[3];
        p._channel[c] += iprL[0][iX+4]._channel[c] * _k[4];

        p._channel[c] += iprL[1][iX+0]._channel[c] * _k[5];
        p._channel[c] += iprL[1][iX+1]._channel[c] * _k[6];
        p._channel[c] += iprL[1][iX+2]._channel[c] * _k[7];
        p._channel[c] += iprL[1][iX+3]._channel[c] * _k[8];
        p._channel[c] += iprL[1][iX+4]._channel[c] * _k[9];

        p._channel[c] += iprL[2][iX+0]._channel[c] * _k[10];
        p._channel[c] += iprL[2][iX+1]._channel[c] * _k[11];
        p._channel[c] += iprL[2][iX+2]._channel[c] * _k[12];
        p._channel[c] += iprL[2][iX+3]._channel[c] * _k[13];
        p._channel[c] += iprL[2][iX+4]._channel[c] * _k[14];

        p._channel[c] += iprL[3][iX+0]._channel[c] * _k[15];
        p._channel[c] += iprL[3][iX+1]._channel[c] * _k[16];
        p._channel[c] += iprL[3][iX+2]._channel[c] * _k[17];
        p._channel[c] += iprL[3][iX+3]._channel[c] * _k[18];
        p._channel[c] += iprL[3][iX+4]._channel[c] * _k[19];

        p._channel[c] += iprL[4][iX+0]._channel[c] * _k[20];
        p._channel[c] += iprL[4][iX+1]._channel[c] * _k[21];
        p._channel[c] += iprL[4][iX+2]._channel[c] * _k[22];
        p._channel[c] += iprL[4][iX+3]._channel[c] * _k[23];
        p._channel[c] += iprL[4][iX+4]._channel[c] * _k[24];
      }

    if (_bUseAbsolute)
      p = elxPixelAbs(p, channelMask);

    elxPixelClamp(p, *oprDst, _doClamp, channelMask);
  }

private:
  const bool _bUseAbsolute, _bInRange;
  const uint32 _channelMask, _nChannel;
  const F _thresholdMin, _thresholdMax;
  const IntegerToType< ResolutionTypeTraits<T>::_bInteger > _doClamp;
  const IntToType<Specialization> _specialization;
  F _k[5*5];
};

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Convolve5x5:
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        const Math::ConvolutionKerneld& iKernel
//  Out : bool 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::Convolve5x5(
    ImageImpl<Pixel>& ioImage,
    const Math::ConvolutionKerneld& iKernel,
    double iThresholdMin, 
    double iThresholdMax,
    bool ibAbsolute,
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;
  typedef typename Pixel::FloatingPixel Atom;

  const EConvolutionDoSpecialization5x5 specialization = 
    elxGetConvolutionDoSpecialization5x5<Pixel>(
      iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);

  switch (specialization)
  {
    case CDS5x5_MaskNoThreshold:
    {
      ConvolutionProcessor5x5<Pixel, CDS5x5_MaskNoThreshold> processor
        (iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint5x5<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    case CDS5x5_MaskThreshold:
    {
      ConvolutionProcessor5x5<Pixel, CDS5x5_MaskThreshold> processor
        (iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint5x5<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    case CDS5x5_NoMask:
    {
      ConvolutionProcessor5x5<Pixel, CDS5x5_NoMask> processor
        (iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint5x5<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    case CDS5x5_NoMaskAbsolute:
    {
      ConvolutionProcessor5x5<Pixel, CDS5x5_NoMaskAbsolute> processor
        (iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint5x5<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    
    default:
      return false;
  }

} // Convolve5x5


} // namespace Image
} // namespace eLynx

#endif // __LocalProcessing_CDS5x5_hpp__
