//============================================================================
//  LocalProcessing/Bilateral.hpp                      Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [N] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  Bilateral filter is an edge-preserving filtering technique
//
//  [1] Bilateral Filtering for Gray and Color Images
//      by C. Tomasi and R. Manduchi
//      http://www.cse.ucsc.edu/~manduchi/Papers/ICCV98.pdf
//      http://elynxsdk.free.fr/ext-docs/Bilateral/ICCV98.pdf
//  
//  [2] Fast Bilateral Filtering for the Display of High-Dynamic-Range Images
//      by Fr�do Durand and Julie Dorsey
//      Laboratory for Computer Science, Massachusetts Institute of Technology
//      http://people.csail.mit.edu/fredo/PUBLI/Siggraph2002/DurandBilateral.pdf
//      http://elynxsdk.free.fr/ext-docs/Bilateral/DurandBilateral.pdf
//
//  [3] SEPARABLE BILATERAL FILTERING FOR FAST VIDEO PREPROCESSING
//      Tuan Q. Pham Lucas J. van Vliet
//      Quantitative Imaging Group, Department of Imaging Science and Technology
//      Delft University of Technology
//      http://www.ph.tn.tudelft.nl/~lucas/publications/2005/ICME2005_TPLV.pdf
//      http://elynxsdk.free.fr/ext-docs/Bilateral/ICME2005_TPLV.pdf
//
//  [4] Medical Image Processing: Bilateral Filtering in Matlab
//      http://www.oneder.de/2006/12/06/programmierung/medical-image-processing-bilateral-filtering-in-matlab/
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __LocalProcessing_Bilateral_hpp__
#define __LocalProcessing_Bilateral_hpp__

#include <elx/math/KernelCollection.h>
#include <elx/image/ColorSpace.h>
#include "ProcessorEngineWxH.hpp"

namespace eLynx {
namespace Image {

namespace {

template <typename Pixel>
struct PixelF_n_CIELabF
{
  typedef typename Pixel::F_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;

  PixelF_n_CIELabF() {}
  PixelF_n_CIELabF(const Pixel& iPixel) : _PixelF(iPixel), _Lab(_PixelF) {}

  Pixel_F     _PixelF;
  PixelLab<F> _Lab;
};

enum EBilateralDoSpecialization { 
  BDS_NoMask,
  BDS_Mask,
};

//----------------------------------------------------------------------------
//  elxGetConvolutionDoSpecialization
//----------------------------------------------------------------------------
template <typename Pixel>
EBilateralDoSpecialization elxGetBilateralDoSpecialization(uint32 iChannelMask)
{
  const bool bUseMask = !Pixel::IsFullMask(iChannelMask);
  return bUseMask ? BDS_Mask : BDS_NoMask;

} // elxGetBilateralDoSpecialization


//----------------------------------------------------------------------------
//                          BilateralProcessor
//----------------------------------------------------------------------------
template <typename Pixel, EBilateralDoSpecialization Specialization>
class BilateralProcessor
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
  typedef          PixelF_n_CIELabF<Pixel> Atom;

public:
  BilateralProcessor(
      double iRadius=2.5, 
      double iSigmaSpatial=1.0, 
      double iSigmaRange=1.0,
      uint32 iChannelMask=CM_All) :
    _sigmaRange( F(iSigmaRange) ),
    _Wk( Math::elxGetKernelSize(iRadius) ),
    _Hk(_Wk),
    _channelMask(iChannelMask),
    _nChannel( Pixel::GetChannelCount() ),
    _spatial( Math::elxMakeGaussianKernel(_Wk,_Hk, iSigmaSpatial) ),
    _kernel( Math::elxMakeGaussianKernel(_Wk,_Hk, iSigmaRange) ),
    _doClamp(),
    _specialization()
  {}
  
  uint32 GetWidth()  const { return _Wk; }
  uint32 GetHeight() const { return _Hk; }

  // The oportunity to adjust to the iteration range this processor is going to operate on. 
  // This particular one does not need to. :)
  void SetRange(const IterationRange& iRange)
  {
    // Clone the kernel. 
    Math::ConvolutionKernel<F> kernel(
      _kernel.GetWidth(), _kernel.GetHeight(), _kernel._spK.get()); 
    _kernel = kernel;

    Math::ConvolutionKernel<F> spatial(
      _spatial.GetWidth(), _spatial.GetHeight(), _spatial._spK.get()); 
    _spatial = spatial;
  }
  
  // Do generic, inlined using optimization
  void Do(boost::scoped_array<Atom*>& ispLine, uint32 iX, Pixel * oprDst) const
  { Do(ispLine, iX, oprDst, _specialization); }

private:

  //--------------------------------------------------------------------------
  // Do # no mask, no Threshold = fatest
  //--------------------------------------------------------------------------
  void Do(boost::scoped_array<Atom*>& ispLine, uint32 iX, Pixel * oprDst,
          const IntToType<BDS_NoMask>&) const
  {
    uint32 x,y;
    F * prK = _kernel._spK.get();
    const F * prKs = _spatial._spK.get();

    // Build kernel based on composition of spatial and range filters
    const PixelLab<F> Lab = ispLine[_Hk/2][iX+_Wk/2]._Lab;
    PixelLab<F> current;
    for (y=0; y<_Hk; y++)
      for (x=0; x<_Wk; x++)
      {
        const uint32 idx = y*_Wk + x;

        // range filter
        current = ispLine[y][iX+x]._Lab;
        const F dL = Math::elxAbs(Lab._luminance - current._luminance);
        const F da = Lab._a - current._a;
        const F db = Lab._b - current._b;
        const F d = dL + Math::elxSqrt(da*da + db*db);
        const F kr = Math::elxGaussian(d, _sigmaRange);

        // saved kernel = spatial filter * range filter
        prK[idx] = prKs[idx] * kr;
      }

    _kernel.Normalize();

    // apply convolution kernel
    Pixel_F sum = Pixel_F::Null();
    for (y=0; y<_Hk; y++)
      for (x=0; x<_Wk; x++)
        sum += ispLine[y][iX+x]._PixelF * prK[y*_Wk + x];
         
    elxPixelClamp(sum, *oprDst, _doClamp);
  }

  //--------------------------------------------------------------------------
  // Do # mask
  //--------------------------------------------------------------------------
  void Do(boost::scoped_array<Atom*>& ispLine, uint32 iX, Pixel * oprDst, 
          const IntToType<BDS_Mask>&) const  
  {
    uint32 x,y;
    F * prK = _kernel._spK.get();
    const F * prKs = _spatial._spK.get();

    // Build kernel based on composition of spatial and range filters
    const PixelLab<F> Lab = ispLine[_Hk/2][iX+_Wk/2]._Lab;
    PixelLab<F> current;
    for (y=0; y<_Hk; y++)
      for (x=0; x<_Wk; x++)
      {
        const uint32 idx = y*_Wk + x;

        // range filter
        current = ispLine[y][iX+x]._Lab;
        const F dL = Math::elxAbs(Lab._luminance - current._luminance);
        const F da = Lab._a - current._a;
        const F db = Lab._b - current._b;
        const F d = dL + Math::elxSqrt(da*da + db*db);
        const F kr = Math::elxGaussian(d, _sigmaRange);

        // saved kernel = spatial filter * range filter
        prK[idx] = prKs[idx] * kr;
      }

    _kernel.Normalize();

    // apply convolution kernel using mask
    Pixel_F mul, sum = Pixel_F::Null();
    for (y=0; y<_Hk; y++)
      for (x=0; x<_Wk; x++)
      {
        mul = elxPixelMul(ispLine[y][iX+x]._PixelF, prK[y*_Wk + x], _channelMask);
        sum = elxPixelAdd(sum, mul, _channelMask);
      }
    
    elxPixelClamp(sum, *oprDst, _doClamp, _channelMask);
  }

private:
  const F _sigmaRange;
  const uint32 _Wk, _Hk, _channelMask, _nChannel;
  Math::ConvolutionKernel<F> _spatial;
  mutable Math::ConvolutionKernel<F> _kernel; 
  const IntegerToType< ResolutionTypeTraits<typename Pixel::type>::_bInteger > _doClamp;
  const IntToType<Specialization> _specialization;
};

} // anonymous-namespace

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplyBilateral # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplyBilateral(
    ImageImpl<Pixel>& ioImage,
    double iRadius, 
    double iSigmaSpatial,
    double iSigmaRange,
    EBorderFill iBorder, 
    uint32 iIteration,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;
  typedef PixelF_n_CIELabF<Pixel> Atom;

  const EBilateralDoSpecialization specialization = 
    elxGetBilateralDoSpecialization<Pixel>(iChannelMask);

  switch (specialization)
  {
    case BDS_Mask:
    {
      BilateralProcessor<Pixel, BDS_Mask> processor
        (iRadius, iSigmaSpatial, iSigmaRange, iChannelMask);
      return elxProcessLocalToPoint<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    case BDS_NoMask: 
    {
      BilateralProcessor<Pixel, BDS_NoMask> processor
        (iRadius, iSigmaSpatial, iSigmaRange, iChannelMask);
      return elxProcessLocalToPoint<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    default:
      return false;
  }

} // ApplyBilateral # ImageImpl<Pixel>


//----------------------------------------------------------------------------
//                              NOT_IMPLEMENTED
// Specialization for pixel's types where convolution does not make sense.
//----------------------------------------------------------------------------
#ifdef elxUSE_ImageComplex
template<> inline
bool ImageLocalProcessingImpl< PixelComplexi >::ApplyBilateral(
    ImageImpl< PixelComplexi >&, 
    double,double,double, EBorderFill, uint32, uint32, ProgressNotifier&)
{ return false; }

template<> inline
bool ImageLocalProcessingImpl< PixelComplexf >::ApplyBilateral(
    ImageImpl< PixelComplexf >&,
    double,double,double, EBorderFill, uint32, uint32, ProgressNotifier&)
{ return false; }

template<> inline
bool ImageLocalProcessingImpl< PixelComplexd >::ApplyBilateral(
    ImageImpl< PixelComplexd >&,
    double,double,double, EBorderFill, uint32, uint32, ProgressNotifier&)
{ return false; }
#endif

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageLocalProcessing implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  ApplyBilateral # AbstractImage
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::ApplyBilateral(
    AbstractImage& ioImage,
    double iRadius, 
    double iSigmaSpatial,
    double iSigmaRange,
    EBorderFill iBorder, 
    uint32 iIteration,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ApplyBilateral(
    image, iRadius, iSigmaSpatial, iSigmaRange, iBorder, iIteration, iChannelMask, iNotifier);

} // ApplyBilateral # AbstractImage

} // namespace Image
} // namespace eLynx

#endif // __LocalProcessing_Bilateral_hpp__
