//============================================================================
//  LocalProcessing/SeparableWxH.hpp                   Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [N] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//
//  http://www.ph.tn.tudelft.nl/Courses/FIP/noframes/fip-Convolut-2.html
//
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __SeparableWxH_hpp__
#define __SeparableWxH_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

// PLEASE DO NOT USE CODE MACROS ELSEWHERE

// convert line from image (Pixel_t) into window line Y (Pixel_T)
// fill left and right borders according iBorder
#define CONVERT_LINE(Y)                \
{                                      \
  prPixel = spLine[Y] + halfW;         \
  for (x=0; x<w; x++)                  \
    *prPixel++ = *prSrc++;             \
                                       \
  if (borderF == BF_Cycle)             \
  {                                    \
    for (x=0; x<halfW; x++, prPixel++) \
    {                                  \
      spLine[Y][x] = spLine[Y][x+w];   \
      *prPixel = spLine[Y][halfW+x];   \
    }                                  \
  }                                    \
  else                                 \
  {                                    \
    if (borderF == BF_Nearest)         \
    {                                  \
      leftBorder = spLine[Y][halfW];   \
      rightBorder = prPixel[-1];       \
    }                                  \
    for (x=0; x<halfW; x++, prPixel++) \
    {                                  \
      spLine[Y][x] = leftBorder;       \
      *prPixel = rightBorder;          \
    }                                  \
  }                                    \
}

#define APPLY_HORIZONTAL_KERNEL(Y)                                    \
{                                                                     \
  if (bNoMasking)                                                     \
  {                                                                   \
    for (x=0; x<w; ++x)                                               \
    {                                                                 \
      sum = spLine[Y][x] * prKw[0];                                   \
      for (xk=1; xk<Wk; ++xk)                                         \
        sum += spLine[Y][x + xk] * prKw[xk];                          \
      spLineBuffer[x] = sum;                                          \
    }                                                                 \
  }                                                                   \
  else                                                                \
  {                                                                   \
    for (x=0; x<w; ++x)                                               \
    {                                                                 \
      sum = elxPixelMul(spLine[Y][x], prKw[0], channelMask);          \
      for (xk=1; xk<Wk; ++xk)                                         \
      {                                                               \
        mul = elxPixelMul( spLine[Y][x + xk], prKw[xk], channelMask); \
        sum = elxPixelAdd(sum, mul, channelMask);                     \
      }                                                               \
      spLineBuffer[x] = sum;                                          \
    }                                                                 \
  }                                                                   \
  /* copy line buffer back to window */                               \
  ::memcpy(spLine[Y] + halfW, spLineBuffer.get(), byteLineSize);      \
}                                                                     \

namespace {

//----------------------------------------------------------------------------
//  SeparableConvolutionTask: process SubImage in Atom space
//  Generic method to iterate over the SubImage line by line process each Pixel. 
//  ProcessorWxH defines how to process a pixel from Atom cache.
//----------------------------------------------------------------------------
//  optimizations :
//  -Transformation inplace ie without allocated another image of same size (low memory cost)
//  -Type conversion for all image is done once (CPU).
//----------------------------------------------------------------------------
//  In  : iSubImage - SubImage to process
//        iProcessor - processor to be applied for each pixel 
//        iBorder - type of border fill
//        ipBorder - pointers to the first and last rows of the whole image
//                   to be used for cycle border
//        iIteration - number of iteration to perform
//        iNotifier  - progress notifier
//  Out : true/false
//----------------------------------------------------------------------------
template <typename Pixel>
struct SeparableConvolutionTask : public IterationRangeTask
{
  typedef typename Pixel::type T;
  typedef typename Pixel::F_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
    
  SeparableConvolutionTask(
      ImageImpl<Pixel>& ioImage,
      const Math::ConvolutionKerneld& iKernel1,
      const Math::ConvolutionKerneld& iKernel2,
      EBorderFill iBorder,
      uint32 iChannelMask, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask(
      IterationRange(0, size_t(ioImage.GetHeight())), iNotifier),
    _image(ioImage),
    _kernelW(iKernel1),
    _kernelH(iKernel2),
    _border(iBorder),
    _channelMask(iChannelMask),
    _spBorder()
  {}
  
  // Split constructor
  SeparableConvolutionTask(
      const SeparableConvolutionTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _image(iOther._image),
    _kernelW(iOther._kernelW),
    _kernelH(iOther._kernelH),
    _border(iOther._border),
    _channelMask(iOther._channelMask),
    _spBorder( new Pixel[(_kernelH.GetHeight() - 1)*_image.GetWidth()] )
  {
    // We need to save lines before and after the current 
    // fragment to make smooth transition between ranges 
    const uint32 w = _image.GetWidth();
    const uint32 h = _image.GetHeight();
    const uint32 byteLineSize = w*sizeof(Pixel);
    const uint32 kh = _kernelH.GetHeight();
    const uint32 halfH = kh/2;
    Pixel * prSrc = _image.GetPixel();
    Pixel * prBorder = _spBorder.get();
    
    const uint32 begin = (uint32)iRange.GetBegin();
    const uint32 end = (uint32)iRange.GetEnd();
    uint32 i;

    if (_border == BF_Cycle)
    {
      // For cycle border need to preserve last two image rows for the first 
      // fragment and vise versa. For the fragments in the middle need to 
      // preserve two neighboring lines
      if (iRange.IsFirst())
      {
        elxASSERT(end+kh-2 < h);
        for (i=0; i<halfH; ++i) 
        {
          ::memcpy(prBorder + w*i,         prSrc + w*(i+h-halfH), byteLineSize); 
          ::memcpy(prBorder + w*(i+halfH), prSrc + w*(i+end),     byteLineSize);
        }
      }
      else if (iRange.IsMiddle())
      {
        elxASSERT((end+kh-2 < h) && (begin >= halfH)); 
        for (i=0; i<halfH; ++i)
        { 
          ::memcpy(prBorder + w*i,         prSrc + w*(i+begin-halfH), byteLineSize); 
          ::memcpy(prBorder + w*(i+halfH), prSrc + w*(i+end),         byteLineSize);
        }
      }
      else if (iRange.IsLast())
      {
        elxASSERT(begin >= halfH); 
        for (i=0; i<halfH; ++i) 
          ::memcpy(prBorder + w*i, prSrc + w*(i+begin-halfH), byteLineSize); 

        for (i=halfH; i<kh-1; ++i)  
          ::memcpy(prBorder + w*i, prSrc + w*(i-halfH), byteLineSize);    
      }
      else // SRP_ALL
      {
        for (i=0; i<halfH; ++i) 
          ::memcpy(prBorder + w*i, prSrc + w*(i+h-halfH), byteLineSize); 

        for (i=halfH; i<kh-1; ++i)  
          ::memcpy(prBorder + w*i, prSrc + w*(i-halfH), byteLineSize);    
      }
    }
    else
    {
      // For all other types of border just need to preserve 
      // only neighboring lines for inner fragments
      if (iRange.IsFirst())
      {
        elxASSERT(end+kh-2 < h);
        for (i=halfH; i<kh-1; ++i)  
          ::memcpy(prBorder + w*i, prSrc + w*(i+end-halfH), byteLineSize);
      }    
      else if (iRange.IsMiddle())
      {
        elxASSERT((end+kh-2 < h) && (begin >= halfH)); 
        for (i=0; i<halfH; ++i)
        { 
          ::memcpy(prBorder + w*i,         prSrc + w*(i+begin-halfH), byteLineSize); 
          ::memcpy(prBorder + w*(i+halfH), prSrc + w*(i+end),         byteLineSize);
        }
      }
      else if (iRange.IsLast())
      {
        elxASSERT(begin >= halfH);
        for (i=0; i<halfH; ++i) 
          ::memcpy(prBorder + w*i, prSrc + w*(i+begin-halfH), byteLineSize); 
      }   
    }
    
    // Need to clone kernels
    _kernelW = Math::ConvolutionKernel<F> (
      _kernelW.GetWidth(), _kernelW.GetHeight(), _kernelW._spK.get()); 

    _kernelH = Math::ConvolutionKernel<F> (
      _kernelH.GetWidth(), _kernelH.GetHeight(), _kernelH._spK.get()); 
  }
   
  
  uint32 operator()()
  {
    // Copy all member variables to give compiler a hint to keep them in registers
    const uint32 w = _image.GetWidth();
    const uint32 h = _image.GetHeight();
    const uint32 begin = (uint32)_begin;
    const uint32 end = (uint32)_end;
    const uint32 Wk = _kernelW.GetWidth();
    const uint32 Hk = _kernelH.GetHeight();   
    const uint32 halfW = Wk/2;
    const uint32 halfH = Hk/2;
    const uint32 lastH = Hk-1;
    const uint32 winLineSize = w + 2*halfW;
    const uint32 byteWinLineSize = winLineSize*sizeof(Pixel_F);
    const uint32 byteCycleLineSize = w*sizeof(Pixel_F);
    const uint32 channelMask = _channelMask;
    const uint32 byteLineSize = w*sizeof(Pixel_F);
    const bool bNoMasking = Pixel::IsFullMask(channelMask);
    const IntegerToType< ResolutionTypeTraits<T>::_bInteger > doClamp =
      IntegerToType< ResolutionTypeTraits<T>::_bInteger >();
    
    Pixel * prBorder = _spBorder.get();
    F * prKw = _kernelW._spK.get();
    F * prKh = _kernelH._spK.get();
    ESubRangePosition position = _position;
    EBorderFill borderF = _border;
    ProgressNotifier& notifier = _notifier;
    
    if (w == 0 || h == 0) 
      return elxErrInvalidParams;
      
    // caches optimizations
    boost::scoped_array<Pixel_F> spLineBuffer( new Pixel_F [w] );
    boost::scoped_array<Pixel_F> spWindow( new Pixel_F[Hk * winLineSize] );
    boost::scoped_array<Pixel_F*> spLine( new Pixel_F*[Hk] );
    boost::scoped_array<Pixel_F> spCycle( new Pixel_F [w * lastH] );
    if (NULL == spWindow.get() || NULL == spLine.get() || 
        NULL == spCycle.get() || NULL == spLineBuffer.get())
      return elxErrOutOfMemory;
    Pixel_F * prCycle = spCycle.get();
    
    // --- inits progress ---
    const float ProgressStep = 1 / (float)(end-begin);
    float Progress = 0.0f;
    notifier.SetProgress(0.0f);

    // --- declares variables ---
    uint32 x,y,xk,yk;
    Pixel * prSrc, * prDst;
    const Pixel borderT = (borderF == BF_Black) ? Pixel::Black() : Pixel::White();
    const Pixel_F border = borderT;
    Pixel_F sum,mul, leftBorder(border), rightBorder(border);
    Pixel_F * prPixel;

    // --- inits variables ---
   for (y=0; y<Hk; ++y)
     spLine[y] = spWindow.get() + y*winLineSize;

    // for cycle border we must save first & last image lines
    if (BF_Cycle == borderF)
    {
      // process first halfH lines
      for (y=0; y<halfH; ++y)
      {
        prSrc = prBorder + w*(lastH-1-y);
        CONVERT_LINE(y);
        APPLY_HORIZONTAL_KERNEL(y);
      }
      // process last halfW lines
      for (y=halfH; y<2*halfH; ++y)
      {
        prSrc = prBorder + w*(lastH-1-y);
        CONVERT_LINE(y);
        APPLY_HORIZONTAL_KERNEL(y);
      }

      // save temp border
      for (y=0; y<lastH; y++)
        ::memcpy(prCycle + w*y, spLine[lastH-1-y] + halfW, byteCycleLineSize);
    }


    // reset image source pointer
    prSrc = _image.GetPixel() + w*begin;
    prDst = prSrc;
    
    // -1- converts first line into window line # halfH
    //     needed for BF_Nearest border
    CONVERT_LINE(halfH);
    APPLY_HORIZONTAL_KERNEL(halfH);

     // -2- first halfH line in window are vertical top border
    if (position == SRP_FIRST || position == SRP_ALL)
    {
      for (y=0; y<halfH; y++)
      {
        switch (borderF)
        {
          case BF_Black:
          case BF_White:
            prPixel = spLine[y];
            for (x=0; x<winLineSize; x++)
              *prPixel++ = border;
            APPLY_HORIZONTAL_KERNEL(y);
            break;

          case BF_Nearest:
            ::memcpy(spLine[y], spLine[halfH], byteWinLineSize);
            // do not apply horizontal kernel again
            break;

          case BF_Cycle:
            ::memcpy(spLine[y] + halfW, prCycle + w*y, byteCycleLineSize);
            // do not apply horizontal kernel again
            break;

          default:
            break;
        }
      }
    }
    else
    {
      Pixel * prSrcSave = prSrc;
      for (y=0; y<halfH; y++)
      {
        prSrc = prBorder + w*y;
        CONVERT_LINE(y);
        APPLY_HORIZONTAL_KERNEL(y);
      } 
      prSrc = prSrcSave; 
    }

    // -3- fill & process next halfH-1 line into window
    for (y=halfH+1; y<lastH; y++)
    {
      CONVERT_LINE(y);
      APPLY_HORIZONTAL_KERNEL(y);
    }

    // -4- process all lines ---
    for (y=begin; y<end; y++)
    {
      // --- fill last line of window ---
      if (y >= end-halfH)
      {
        if (position == SRP_LAST || position == SRP_ALL)
        {
          switch (borderF)
          {
            case BF_Black:
            case BF_White:
              prPixel = spLine[lastH];
              for (x=0; x<winLineSize; x++)
                *prPixel++ = border;
              APPLY_HORIZONTAL_KERNEL(lastH);
              break;

            case BF_Nearest:
              ::memcpy(spLine[lastH], spLine[lastH-1], byteWinLineSize);
              // do not process, this is already done
              break;

            case BF_Cycle:
              ::memcpy(spLine[lastH] + halfW, prCycle + w*(y-end+lastH), byteCycleLineSize);
              // do not process, this is already done
              break;

            default:
              break;
          }
        }
        else
        {
          Pixel * prSrcSave = prSrc;
          prSrc = prBorder + w*(y-end+lastH);
          CONVERT_LINE(lastH);
          APPLY_HORIZONTAL_KERNEL(lastH);
          prSrc = prSrcSave;  
        }
      }
      else
      {
        // fill from image source, and progress last windows line
        CONVERT_LINE(lastH);
        APPLY_HORIZONTAL_KERNEL(lastH);
      }

      // -5- apply vertical kernel to whole window buffer
      if (bNoMasking)
      {
        // speed up if no channel mask used
        for (x=0; x<w; ++x, ++prDst)
        {
          sum = spLine[0][halfW+x] * prKh[0];
          for (yk=1; yk<Hk; ++yk)
            sum += spLine[yk][halfW+x] * prKh[yk];
            
          // re-inject temporary result into original image
          elxPixelClamp(sum, *prDst, doClamp);
        }
      }
      else
      {
        for (x=0; x<w; ++x, ++prDst)
        {
          sum = elxPixelMul(spLine[0][halfW+x], prKh[0], channelMask);
          for (yk=1; yk<Hk; ++yk)
          {
            mul = elxPixelMul(spLine[yk][halfW+x], prKh[yk], channelMask);
            sum = elxPixelAdd(sum, mul, channelMask);
          }

          // re-inject temporary result into original image
          elxPixelClamp(sum, *prDst, doClamp, channelMask);
        }
      }

      // -6- Move window lines from bottom to top
      // we just move line pointers to optimize memory management
      prPixel = spLine[0];
      for (x=0; x<lastH; ++x) 
        spLine[x] = spLine[x+1];
      spLine[lastH] = prPixel;

      // --- in progress ... ---
      Progress += ProgressStep;
      notifier.SetProgress(Progress);
    }

    // --- progress end ---
    notifier.SetProgress(1.0f);
    return elxOK;
  }

private:  
  ImageImpl<Pixel>&          _image;       // Source Image
  Math::ConvolutionKernel<F> _kernelW;     // Horizontal kernel
  Math::ConvolutionKernel<F> _kernelH;     // Vertical kernel
  EBorderFill                _border;      // Border Type
  uint32                     _channelMask; // Channel Mask
  boost::shared_array<Pixel> _spBorder;    // For cycle type border
  
}; // SeparableConvolutionTask

} // anonymous-namespace


//----------------------------------------------------------------------------
//  Convolve # ImageImpl<Pixel>
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::Convolve(
    ImageImpl<Pixel>& ioImage,
    const Math::ConvolutionKerneld& iKernel1,
    const Math::ConvolutionKerneld& iKernel2,
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask) || (0 == iIteration)) return true;

  Math::ConvolutionKerneld KernelW, KernelH;
  if (iKernel1.IsHorizontal())
  {
    if (!iKernel2.IsVertical()) return false;
    KernelW = iKernel1;
    KernelH = iKernel2;
  }
  else if (iKernel2.IsHorizontal())
  {
    if (!iKernel1.IsVertical()) return false;
    KernelW = iKernel2;
    KernelH = iKernel1;
  }
  else
    return false;
    
  const uint32 h = ioImage.GetHeight();
  const uint32 w = ioImage.GetWidth();

  // If multicore optimization is used then each core needs to 
  // operate on at least ~10000 pixels. Otherwise overhead of 
  // splitting the original image, creating threads, etc. would 
  // be bigger then the gain from the parallel implementation.
  // If parallel implementation is not required (iUseParallelImpl = false) then
  // range size is set to the original image size + 1 to prevent multicore split
  const uint32 minRangeSize = (w > 10000)? 1 : 10000/w;
  const IterationRange range(0, size_t(h), 1, minRangeSize);
  do
  {
    SeparableConvolutionTask<Pixel> task(
      ioImage, KernelW, KernelH, iBorder, iChannelMask, iNotifier);

    if (elxOK != elxParallelFor(range, task))
      return false;
  }
  while (--iIteration > 0);
  
  return true;

} // Convolve # ImageImpl<Pixel>

#undef CONVERT_LINE
#undef APPLY_HORIZONTAL_KERNEL

//----------------------------------------------------------------------------
//                              NOT_IMPLEMENTED
// Specialization for pixel's types where convolution does not make sense. 
//----------------------------------------------------------------------------
#ifdef elxUSE_ImageComplex
template<> 
bool ImageLocalProcessingImpl< PixelComplexi >::Convolve(
    ImageImpl< PixelComplexi >&, 
    const Math::ConvolutionKerneld&, const Math::ConvolutionKerneld&,
    EBorderFill, uint32, uint32 iChannelMask, ProgressNotifier&)
{ return false; }

template<> 
bool ImageLocalProcessingImpl< PixelComplexf >::Convolve(
    ImageImpl< PixelComplexf >&, 
    const Math::ConvolutionKerneld&, const Math::ConvolutionKerneld&,
    EBorderFill, uint32, uint32 iChannelMask, ProgressNotifier&)
{ return false; }

template<>
bool ImageLocalProcessingImpl< PixelComplexd >::Convolve(
    ImageImpl< PixelComplexd >&, 
    const Math::ConvolutionKerneld&, const Math::ConvolutionKerneld&,
    EBorderFill, uint32, uint32 iChannelMask, ProgressNotifier&)
{ return false; }
#endif

} // namespace Image
} // namespace eLynx
 
#endif // __SeparableWxH_hpp__
