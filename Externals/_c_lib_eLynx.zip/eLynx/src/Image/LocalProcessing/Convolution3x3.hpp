//============================================================================
//  LocalProcessing/Convolution3x3.hpp                 Image.Component package
//============================================================================
//
//  http://www.ph.tn.tudelft.nl/Courses/FIP/noframes/fip-Convolut-2.html
//
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __LocalProcessing_Convolution3x3_hpp__
#define __LocalProcessing_Convolution3x3_hpp__

#include <boost/shared_array.hpp>
#include <elx/core/CoreTypes.h>
#include "ProcessorEngine3x3.hpp"

namespace eLynx {
namespace Image {

namespace {

enum EConvolutionDoSpecialization3x3 { 
  CDS3x3_NoMask,
  CDS3x3_NoMaskAbsolute,
  CDS3x3_MaskNoThreshold,
  CDS3x3_MaskThreshold
};

//----------------------------------------------------------------------------
//  elxGetConvolutionDoSpecialization3x3: 
//----------------------------------------------------------------------------
template <typename Pixel>
EConvolutionDoSpecialization3x3 elxGetConvolutionDoSpecialization3x3(
    double iThresholdMin, 
    double iThresholdMax, 
    bool ibAbsolute, 
    uint32 iChannelMask)
{
  const bool bUseThreshold = (iThresholdMin != 0.0) || (iThresholdMax != 1.0);
  const bool bUseMask = !Pixel::IsFullMask(iChannelMask);

  return bUseThreshold ? CDS3x3_MaskThreshold :
         bUseMask      ? CDS3x3_MaskNoThreshold : 
         ibAbsolute    ? CDS3x3_NoMaskAbsolute : 
                         CDS3x3_NoMask;

} // elxGetConvolutionDoSpecialization3x3


//----------------------------------------------------------------------------
//                          ConvolutionProcessor3x3
//----------------------------------------------------------------------------
template <typename Pixel, EConvolutionDoSpecialization3x3 Specialization>
class ConvolutionProcessor3x3
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  typedef typename Pixel::FloatingPixel Atom;

public:
  ConvolutionProcessor3x3(
      const Math::ConvolutionKerneld& iKernel,
      double iThresholdMin=0.0, 
      double iThresholdMax=1.0,
      bool ibAbsolute=false,
      uint32 iChannelMask=CM_All) :
   _bUseAbsolute(ibAbsolute),
   _bInRange(iThresholdMin <= iThresholdMax),
   _channelMask(iChannelMask),
   _nChannel(Pixel::GetChannelCount()),
   _thresholdMin( F(iThresholdMin * ResolutionTypeTraits<T>::_max) ),
   _thresholdMax( F(iThresholdMax * ResolutionTypeTraits<T>::_max) ),
   _doClamp(),
   _specialization()
  {
    for (uint32 i=0; i<9; i++)
      _k[i] = (F)iKernel._spK[i];
  }
  
  // The oportunity to adjust to the iteration range this processor is going to operate on. 
  // This particular one does not need to. :)
  void SetRange(const IterationRange& iRange)
  {}

  // Do generic, inlined using optimization
  void Do(const Atom * const * iprLines, uint32 iX, Pixel * oprDst) const
  { Do(iprLines, iX, oprDst, _specialization); }
  
private:

  //--------------------------------------------------------------------------
  // Do # no mask fatest
  //--------------------------------------------------------------------------
  void Do(const Atom * const * iprL, uint32 iX, Pixel * oprDst, 
          const IntToType<CDS3x3_NoMask>&) const
  {
    Atom p = 
      iprL[0][0+iX]*_k[0] + iprL[0][1+iX]*_k[1] + iprL[0][2+iX]*_k[2] + 
      iprL[1][0+iX]*_k[3] + iprL[1][1+iX]*_k[4] + iprL[1][2+iX]*_k[5] +
      iprL[2][0+iX]*_k[6] + iprL[2][1+iX]*_k[7] + iprL[2][2+iX]*_k[8];
    elxPixelClamp(p, *oprDst, _doClamp);
  }

  //--------------------------------------------------------------------------
  // Do # no mask, absolute value
  //--------------------------------------------------------------------------
  void Do(const Atom * const * iprL, uint32 iX, Pixel * oprDst, 
          const IntToType<CDS3x3_NoMaskAbsolute>&) const
  {
    Atom p = 
      iprL[0][0+iX]*_k[0] + iprL[0][1+iX]*_k[1] + iprL[0][2+iX]*_k[2] + 
      iprL[1][0+iX]*_k[3] + iprL[1][1+iX]*_k[4] + iprL[1][2+iX]*_k[5] +
      iprL[2][0+iX]*_k[6] + iprL[2][1+iX]*_k[7] + iprL[2][2+iX]*_k[8];
    p = elxPixelAbs(p);
    elxPixelClamp(p, *oprDst, _doClamp);
  }

  //--------------------------------------------------------------------------
  // Do # mask, no Threshold
  //--------------------------------------------------------------------------
  void Do(const Atom * const * iprL, uint32 iX, Pixel * oprDst, 
          const IntToType<CDS3x3_MaskNoThreshold>&) const
  {
    Atom sum = elxPixelMul(iprL[0][0+iX], _k[0], _channelMask);
    Atom mul = elxPixelMul(iprL[0][1+iX], _k[1], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[0][2+iX], _k[2], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);

    mul = elxPixelMul(iprL[1][0+iX], _k[3], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[1][1+iX], _k[4], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[1][2+iX], _k[5], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);

    mul = elxPixelMul(iprL[2][0+iX], _k[6], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[2][1+iX], _k[7], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);
    mul = elxPixelMul(iprL[2][2+iX], _k[8], _channelMask);
    sum = elxPixelAdd(sum, mul, _channelMask);

    if (_bUseAbsolute)
      sum = elxPixelAbs(sum, _channelMask);

    elxPixelClamp(sum, *oprDst, _doClamp, _channelMask);
  }

  //--------------------------------------------------------------------------
  // Do # mask & Threshold, slowest
  //--------------------------------------------------------------------------
  void Do(const Atom * const * iprL, uint32 iX, Pixel * oprDst, 
          const IntToType<CDS3x3_MaskThreshold>&) const  
  {
    // compute channel mask using tMin, tMax
    uint32 c, channelMask = 0;

    // get current pixel
    Atom p = iprL[1][iX+1];
    for (c=0; c<_nChannel; c++)
    {
      if (elxUseChannel(c, _channelMask))
      {
        // the channel is requested, does it fit thresholds?
        if (_bInRange)
        {
          // tMin <= tMax, check Pixel inside range
          if ((p._channel[c] >= _thresholdMin) && (p._channel[c] <= _thresholdMax))
            channelMask |= 1 << c;
        }
        else
        {
          // tMin > tMax, check Pixel outside range
          if ((p._channel[c] >= _thresholdMin) || (p._channel[c] <= _thresholdMax))
            channelMask |= 1 << c;
        }
      }
    }

    // filter user mask selection
    channelMask &= _channelMask;

    // skip pixel if out of thresholds
    if (0 == channelMask) return;

    for (c=0; c<_nChannel; c++)
      if (elxUseChannel(c, _channelMask))
      {
        p._channel[c]  = iprL[0][iX+0]._channel[c] * _k[0];
        p._channel[c] += iprL[0][iX+1]._channel[c] * _k[1];
        p._channel[c] += iprL[0][iX+2]._channel[c] * _k[2];
        p._channel[c] += iprL[1][iX+0]._channel[c] * _k[3];
        p._channel[c] += iprL[1][iX+1]._channel[c] * _k[4];
        p._channel[c] += iprL[1][iX+2]._channel[c] * _k[5];
        p._channel[c] += iprL[2][iX+0]._channel[c] * _k[6];
        p._channel[c] += iprL[2][iX+1]._channel[c] * _k[7];
        p._channel[c] += iprL[2][iX+2]._channel[c] * _k[8];
      }

    if (_bUseAbsolute)
      p = elxPixelAbs(p, channelMask);

    elxPixelClamp(p, *oprDst, _doClamp, channelMask);
  }

private:
  const bool _bUseAbsolute, _bInRange;
  const uint32 _channelMask, _nChannel;
  const F _thresholdMin, _thresholdMax;
  const IntegerToType< ResolutionTypeTraits<T>::_bInteger > _doClamp;
  const IntToType<Specialization> _specialization;
  F _k[3*3];
};

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Convolve3x3:
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage: image to process
//        const Math::ConvolutionKerneld& iKernel
//        uint32 iIteration : default is 1
//        bool ibClamp : true to clamp result after transformation
//        ProgressNotifier iNotifier : 
//  Out : bool 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageLocalProcessingImpl<Pixel>::Convolve3x3(
    ImageImpl<Pixel>& ioImage,
    const Math::ConvolutionKerneld& iKernel,
    double iThresholdMin, double iThresholdMax,
    bool ibAbsolute,
    EBorderFill iBorder,
    uint32 iIteration,
    uint32 iChannelMask,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  if (!Pixel::IsMasking(iChannelMask)) return true;
  typedef typename Pixel::FloatingPixel Atom;

  const EConvolutionDoSpecialization3x3 specialization = 
    elxGetConvolutionDoSpecialization3x3<Pixel>(
      iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);

  switch (specialization)
  {
    case CDS3x3_MaskNoThreshold:
    {
      ConvolutionProcessor3x3<Pixel, CDS3x3_MaskNoThreshold> processor
        (iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint3x3<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    case CDS3x3_MaskThreshold:
    {
      ConvolutionProcessor3x3<Pixel, CDS3x3_MaskThreshold> processor
        (iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint3x3<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    case CDS3x3_NoMaskAbsolute: 
    {
      ConvolutionProcessor3x3<Pixel, CDS3x3_NoMaskAbsolute> processor
        (iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint3x3<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    case CDS3x3_NoMask:
    {
      ConvolutionProcessor3x3<Pixel, CDS3x3_NoMask> processor
        (iKernel, iThresholdMin, iThresholdMax, ibAbsolute, iChannelMask);
      return elxProcessLocalToPoint3x3<Pixel, Atom>
        (ioImage, processor, iBorder, iIteration, iNotifier);
    }
    default:
      return false;
  }

} // Convolve3x3


} // namespace Image
} // namespace eLynx

#endif // __LocalProcessing_Convolution3x3_hpp__
