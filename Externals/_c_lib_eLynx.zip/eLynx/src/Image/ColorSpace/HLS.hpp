//============================================================================
//  ColorSpace_HLS.hpp                                 Image.Component package
//============================================================================
//  http://en.wikipedia.org/wiki/HSL_color_space
//  http://support.microsoft.com/kb/29240
//
//  HSL color values (hue-saturation-lightness)
//  It has been observed that RGB colors have the following limitations: 
//  - RGB is hardware-oriented: it reflects the use of CRTs. 
//  - RGB is non-intuitive. People can learn how to use RGB, 
//    but actually by internalizing how to translate hue, saturation and 
//    lightness, or something similar, to RGB. 
//  There are several other color schemes possible. Advantages of HSL are that
//  it is symmetrical to lightness and darkness (which is not the case with 
//  HSV for example), and it is trivial to convert HSL to RGB. 
//
//  HSL colors are encoding as a triple (hue, saturation, lightness). 
//  * Hue is represented as an angle of the color circle (i.e. the rainbow 
//    represented in a circle). This angle is so typically measured in degrees 
//    that the unit is implicit in CSS; syntactically, only a <number> is given. 
//    By definition red=0=360, and the other colors are spread around the circle, 
//    so green=120, blue=240, etc. As an angle, it implicitly wraps around such 
//    that -120=240 and 480=120. One way an implementation could normalize such 
//    an angle x to the range [0,360) is to compute ((x mod 360) + 360) mod 360). 
//  * Saturation and lightness are represented as percentages. 
//    100% is full saturation, and 0% is a shade of grey. 
//    0% lightness is black, 100% lightness is white, 
//    and 50% lightness is 'normal'. 
//
//  In eLynx SDK, PixelHLS<T> is only supported for floating type resolutions:
//  float and double. All values are normalized, this means:
//  HLS: H,L,S in range [0, 1]
//  
//  PixelHLS<T> if not defined for uint8/uint16/integer resolutions because
//  it leads to range problem and library size growing.
//  with uint8 we can't store hue angle in range [0, 360[ as we are limited
//  to range [0, 256]. We must use a range where the max value is a multiple of 6.
//  Conversion from PixelHLS<T> to PixelHLS<U> should be too complex.
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __ColorSpace_HLS_hpp__
#define __ColorSpace_HLS_hpp__

namespace eLynx {
namespace Image {

namespace {

// hue max is a multiple of 6 for integer types
template<typename T> inline T elxGetHueMax();
template<> inline uint8 elxGetHueMax<uint8>()   { return 252; }
template<> inline uint16 elxGetHueMax<uint16>() { return 65532; }
template<> inline int32 elxGetHueMax<int32>()   { return 600000; }

//----------------------------------------------------------------------------
//  elxGetHue
//----------------------------------------------------------------------------
template<typename T> inline
T elxGetHue(double iHue, FloatType)   { return T(iHue); }

template<typename T> inline
T elxGetHue(double iHue, IntegerType) { return T(elxGetHueMax<T>() * iHue + 0.5); }

//----------------------------------------------------------------------------
//  elxGetSaturation
//----------------------------------------------------------------------------
template<typename T> inline
T elxGetSaturation(double iSaturation, FloatType) { return T(iSaturation); }

template<typename T> inline
T elxGetSaturation(double iSaturation, IntegerType)
{ return T(iSaturation * ResolutionTypeTraits<T>::_max + 0.5); }

//----------------------------------------------------------------------------
//  elxHueToRGB # FloatType
//  iHue in range [0, 1]
//----------------------------------------------------------------------------
template<typename T>
inline 
T elxHueToRGB(T p1, T p2, T iHue, FloatType)
{
  if (iHue > T(6)) iHue -= T(6); else if (iHue < T(0)) iHue += T(6);
  if (iHue < T(1)) return (p1 + (p2-p1)*iHue);
  if (iHue < T(3)) return p2;
  if (iHue < T(4)) return (p1 + (p2-p1)*(T(4)-iHue));
  return p1;

} // elxHueToRGB # FloatType

//----------------------------------------------------------------------------
//  elxHueToRGB # IntegerType
//  iHue in range [0, hue max]
//----------------------------------------------------------------------------
template<typename T>
inline 
T elxHueToRGB(T p1, T p2, T iHue, IntegerType)
{
  const T HueMax = elxGetHueMax<T>();
  // return r,g, or b value from this tridrant 
  if (iHue < HueMax/6)     return (p1 + ((p2-p1)*6*iHue + HueMax/2)/HueMax);
  if (iHue < HueMax/2)     return p2;
  if (iHue < (2*HueMax)/3) return (p1 + ((p2-p1)*6*((2*HueMax)/3 - iHue) + HueMax/2)/HueMax);
  return p1;

} // elxHueToRGB # IntegerType


//----------------------------------------------------------------------------
//  elxRGBToHLS # FloatType
//----------------------------------------------------------------------------
template<typename T>
inline
void elxRGBToHLS(const PixelRGB<T>& iPixel, 
    T& oHue, T& oLuminance, T& oSaturation,
    FloatType)
{
  const T r = iPixel._red;
  const T g = iPixel._green;
  const T b = iPixel._blue;

  const T Max = Math::elxMax(r,g,b);
  const T Min = Math::elxMin(r,g,b);
  if (Max == Min)
  {
    // achromatic case
    oHue = T(0); oLuminance = Max; oSaturation = T(0);
    return;
  }

  oLuminance = (Max + Min)/2;
  oSaturation = (oLuminance < T(0.5)) ? (Max - Min)/(Max + Min) : (Max - Min)/(2 - Max - Min);

  const T a = T(1)/(6*(Max - Min));
  if (r == Max) 
  { 
    oHue = a*(g - b); 
    if (oHue < T(0)) oHue += T(1); 
  }
  else if (g == Max)
  {
    oHue = a*(b - r) + T(1)/T(3);
  }
  else
  {
    oHue = a*(r - g) + T(2)/T(3);
    if (oHue > T(1)) oHue -= T(1);
  }

} // elxRGBToHLS # FloatType

//----------------------------------------------------------------------------
//  elxHLSToRGB # FloatType
//----------------------------------------------------------------------------
template<typename T>
inline
void elxHLSToRGB(T iHue, T iLuminance, T iSaturation, 
    PixelRGB<T>& oPixel, FloatType)
{
  if (T(0) == iSaturation)
  {
    // achromatic case
    oPixel._red = oPixel._green = oPixel._blue = iLuminance;
    return;
  }

  const T p2 = (iLuminance <= T(0.5)) ? 
    iLuminance*(T(1) + iSaturation) : 
    iLuminance*(T(1) - iSaturation) + iSaturation;
  const T p1 = T(2)*iLuminance - p2;
  iHue *= 6;

  oPixel._red   = elxHueToRGB(p1, p2, iHue + 2, INTEGER_TYPE(T));
  oPixel._green = elxHueToRGB(p1, p2, iHue,     INTEGER_TYPE(T));
  oPixel._blue  = elxHueToRGB(p1, p2, iHue - 2, INTEGER_TYPE(T));

} // elxHLSToRGB # FloatType

//----------------------------------------------------------------------------
//  elxRGBToHLS # IntegerType
//----------------------------------------------------------------------------
template<typename T>
inline
void elxRGBToHLS(const PixelRGB<T>& iPixel, 
    T& oHue, T& oLuminance, T& oSaturation,
    IntegerType)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  PixelRGB<F> rgbF(
    F(iPixel._red   * ResolutionTypeTraits<T>::_normScale),
    F(iPixel._green * ResolutionTypeTraits<T>::_normScale),
    F(iPixel._blue  * ResolutionTypeTraits<T>::_normScale));

  PixelHLS<F> hls(rgbF);

  oHue        = T(hls._hue * elxGetHueMax<T>());
  oLuminance  = T(hls._luminance * ResolutionTypeTraits<T>::_max);
  oSaturation = T(hls._saturation * ResolutionTypeTraits<T>::_max);

} // elxRGBToHLS # IntegerType

//----------------------------------------------------------------------------
//  elxHLSToRGB # IntegerType
//----------------------------------------------------------------------------
//  H in range [0, elxGetHueMax<T>]
//  L,S in range [0, ResolutionTypeTraits<T>::_max]
//----------------------------------------------------------------------------
template<typename T>
inline
void elxHLSToRGB(T iHue, T iLuminance, T iSaturation, 
    PixelRGB<T>& oPixel, IntegerType)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  PixelHLS<F> hls(
    F(iHue / F(elxGetHueMax<T>())),
    F(iLuminance * ResolutionTypeTraits<T>::_normScale),
    F(iSaturation * ResolutionTypeTraits<T>::_normScale));

  PixelRGB<F> rgbF(hls);

  oPixel._red   = T(rgbF._red   * ResolutionTypeTraits<T>::_max);
  oPixel._green = T(rgbF._green * ResolutionTypeTraits<T>::_max);
  oPixel._blue  = T(rgbF._blue  * ResolutionTypeTraits<T>::_max);

} // elxHLSToRGB # IntegerType

} // namespace

//----------------------------------------------------------------------------
//  elxRGBToHLS # Generic
//----------------------------------------------------------------------------
template<typename T>
inline
void elxRGBToHLS(const PixelRGB<T>& iPixel, T& oHue, T& oLuminance, T& oSaturation)
{
  elxRGBToHLS(iPixel, oHue, oLuminance, oSaturation, INTEGER_TYPE(T));

} // elxRGBToHLS # Generic

//----------------------------------------------------------------------------
//  elxHLSToRGB # Generic
//----------------------------------------------------------------------------
template<typename T>
inline
void elxHLSToRGB(T iHue, T iLuminance, T iSaturation, PixelRGB<T>& oPixel)
{
  elxHLSToRGB(iHue, iLuminance, iSaturation, oPixel, INTEGER_TYPE(T));

} // elxHLSToRGB # Generic


//----------------------------------------------------------------------------
//  Transform from RGB to HLS # generic
//----------------------------------------------------------------------------
template<typename T>
inline
PixelHLS<T>::PixelHLS(const PixelRGB<T>& iPixel)
{
  elxRGBToHLS(iPixel, _hue, _luminance, _saturation, INTEGER_TYPE(T));
}

//----------------------------------------------------------------------------
//  Transform from HLS to RGB # generic
//----------------------------------------------------------------------------
template<typename T>
inline
PixelRGB<T>::PixelRGB(const PixelHLS<T>& iPixel)
{
  elxHLSToRGB(iPixel._hue, iPixel._luminance, iPixel._saturation,
    *this, INTEGER_TYPE(T));
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                                elxColorize
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {
//----------------------------------------------------------------------------
//  elxColorize # NonColorType
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxColorize(Pixel& ioPixel, 
    typename Pixel::type iHue, 
    typename Pixel::type iSaturation,
    NonColorType)
{
  //  Do nothing

} // elxColorize # NonColorType

//----------------------------------------------------------------------------
//  elxColorizeHLS
//----------------------------------------------------------------------------
template<typename T>
inline
void elxColorizeHLS(PixelHLS<T>& ioPixel, T iHue, T iSaturation)
{
  ioPixel._hue = iHue;
  ioPixel._saturation = iSaturation;

} // elxColorizeHLS

//----------------------------------------------------------------------------
//  elxColorizeRGB # IntegerType
//----------------------------------------------------------------------------
//  iHue in range [0, elxGetHueMax<T>()]
//  iSaturation in range [0, ResolutionTypeTraits<T>::_max]
//----------------------------------------------------------------------------
template<typename T>
inline
void elxColorizeRGB(PixelRGB<T>& ioPixel, T iHue, T iSaturation, IntegerType)
{
  const T M = ResolutionTypeTraits<T>::_max;
  const T HueMax = elxGetHueMax<T>();

  T r = ioPixel._red;
  T g = ioPixel._green;
  T b = ioPixel._blue;

  // compute lightness
  const T Max = Math::elxMax(r,g,b);
  const T Min = Math::elxMin(r,g,b);
  const T l = (Max + Min)/2;
  if (0 == iSaturation)
  {
    // achromatic case
    ioPixel._red = ioPixel._green = ioPixel._blue = l;
    return;
  }
  
  const T s = iSaturation;
  const T p2 = (l <= M/2) ? (l*(M + s) + M/2)/M : l + s - (l*s + M/2)/M;
  const T p1 = 2*l - p2;

  // get RGB, change units from hue max to M
  r = elxHueToRGB(p1, p2, T(iHue + HueMax/3), INTEGER_TYPE(T));
  g = elxHueToRGB(p1, p2, iHue,               INTEGER_TYPE(T));
  b = elxHueToRGB(p1, p2, T(iHue - HueMax/3), INTEGER_TYPE(T));

  ioPixel._red   = (M*r + M/2)/M;
  ioPixel._green = (M*g + M/2)/M;
  ioPixel._blue  = (M*b + M/2)/M;

} // elxColorizeRGB # IntegerType

//----------------------------------------------------------------------------
//  elxColorizeRGB # FloatType
//----------------------------------------------------------------------------
//  iHue in range [0, 1]
//  iSaturation in range [0, 1]
//----------------------------------------------------------------------------
template<typename T>
inline
void elxColorizeRGB(PixelRGB<T>& ioPixel, T iHue, T iSaturation, FloatType)
{
  const T r = ioPixel._red;
  const T g = ioPixel._green;
  const T b = ioPixel._blue;

  // compute lightness
  const T Max = Math::elxMax(r,g,b);
  const T Min = Math::elxMin(r,g,b);
  const T l = (Max + Min)/2;
  if (T(0) == iSaturation)
  {
    // achromatic case
    ioPixel._red = ioPixel._green = ioPixel._blue = l;
    return;
  }

  const T s = iSaturation;
  const T p2 = (l <= T(0.5)) ? l*(T(1) + s) : l*(T(1) - s) + s;
  const T p1 = T(2)*l - p2;
  const T h = 6*iHue;
  
  ioPixel._red   = elxHueToRGB(p1, p2, h+2, INTEGER_TYPE(T));
  ioPixel._green = elxHueToRGB(p1, p2, h,   INTEGER_TYPE(T));
  ioPixel._blue  = elxHueToRGB(p1, p2, h-2, INTEGER_TYPE(T));

} // elxColorizeRGB # FloatType 

//----------------------------------------------------------------------------
//  elxColorize # ColorType
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxColorize(Pixel& ioPixel, 
    typename Pixel::type iHue, 
    typename Pixel::type iSaturation,
    ColorType)
{
  typedef typename Pixel::type T;

  // convert to RGB<T>, Colorize, back to original color space
  PixelRGB<T> rgb(ioPixel);
  elxColorizeRGB(rgb, iHue, iSaturation, INTEGER_TYPE(T));
  ioPixel = Pixel(rgb);

} // elxColorize # ColorType


template<class Pixel> 
struct ColorizeHelper
{
  static void Do(Pixel& ioPixel, typename Pixel::type iHue, typename Pixel::type iSaturation)
  { elxColorize(ioPixel, iHue, iSaturation, PIXEL_COLOR_TYPE(Pixel)); }
};

template<typename T> 
struct ColorizeHelper< PixelRGB<T> >
{
  static void Do(PixelRGB<T>& ioPixel, T iHue, T iSaturation)
  { elxColorizeRGB(ioPixel, iHue, iSaturation, INTEGER_TYPE(T)); }
};

template<typename T> 
struct ColorizeHelper< PixelHLS<T> >
{
  static void Do(PixelHLS<T>& ioPixel, T iHue, T iSaturation)
  { elxColorizeHLS(ioPixel, iHue, iSaturation); }
};

} // namespace


//----------------------------------------------------------------------------
//  elxColorize # generic
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxColorize(Pixel& ioPixel, 
    typename Pixel::type iHue, 
    typename Pixel::type iSaturation)
{
  ColorizeHelper<Pixel>::Do(ioPixel, iHue, iSaturation);

} // elxColorize # generic

template<typename T> inline
T elxGetHue(double iHue) { return elxGetHue<T>(iHue, INTEGER_TYPE(T)); }

template<typename T> inline
T elxGetSaturation(double iSaturation) 
{ return elxGetSaturation<T>(iSaturation, INTEGER_TYPE(T));}



//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                                elxDesaturate
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {
//----------------------------------------------------------------------------
//  elxDesaturate
//----------------------------------------------------------------------------
template<typename T> inline
T elxDesaturate(T iSaturation, double iFactor, FloatType)
{ 
  // keep gray value
  if (iSaturation == T(0)) return T(0);

  iSaturation *= (T)iFactor;

  // saturation is clamped in range[0, 1]
  if      (iSaturation < T(0)) return T(0);
  else if (iSaturation > T(1)) return T(1);

  return iSaturation; 
}

template<typename T> inline
T elxDesaturate(T iSaturation, double iFactor, IntegerType)
{ return ResolutionTypeTraits<T>::Clamp( double(iSaturation)*iFactor ); }

template<typename T> inline
T elxDesaturate(T iSaturation, double iFactor)
{ return elxDesaturate(iSaturation, iFactor, INTEGER_TYPE(T)); }

//----------------------------------------------------------------------------
//  elxDesaturate # NonColorType
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxDesaturate(Pixel& ioPixel, double iFactor, uint32 iChannelMask, NonColorType)
{
  //  Do nothing

} // elxDesaturate # NonColorType

//----------------------------------------------------------------------------
//  elxDesaturateHLS
//----------------------------------------------------------------------------
template<typename T>
inline
void elxDesaturateHLS(PixelHLS<T>& ioPixel, double iFactor, uint32 iChannelMask)
{
  if (iChannelMask & CM_Channel2)
  {
    ioPixel._saturation = elxDesaturate(ioPixel._saturation, iFactor, INTEGER_TYPE(T));
  }

} // elxDesaturateHLS

//----------------------------------------------------------------------------
//  elxDesaturateRGB # IntegerType
//----------------------------------------------------------------------------
template<typename T>
inline
void elxDesaturateRGB(PixelRGB<T>& ioPixel, 
    double iFactor, uint32 iChannelMask,
    IntegerType)
{
  // convert to HLS normalized space h,l,s in range [0,1]
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  PixelRGB<F> rgbF(
    F(ResolutionTypeTraits<T>::_normScale * ioPixel._red),
    F(ResolutionTypeTraits<T>::_normScale * ioPixel._green),
    F(ResolutionTypeTraits<T>::_normScale * ioPixel._blue));
  PixelHLS<F> hls(rgbF);

  // change saturation
  elxDesaturateHLS(hls, iFactor, CM_All);

  // back to original space & resolution
  rgbF = hls;
  if (iChannelMask & CM_Channel0) 
    ioPixel._red = T(rgbF._red * ResolutionTypeTraits<T>::_max);
  if (iChannelMask & CM_Channel1)
    ioPixel._green = T(rgbF._green * ResolutionTypeTraits<T>::_max);
  if (iChannelMask & CM_Channel2) 
    ioPixel._blue = T(rgbF._blue * ResolutionTypeTraits<T>::_max);

} // elxDesaturateRGB # IntegerType

//----------------------------------------------------------------------------
//  elxDesaturateRGB # FloatType
//----------------------------------------------------------------------------
template<typename T>
inline
void elxDesaturateRGB(PixelRGB<T>& ioPixel, 
    double iFactor, uint32 iChannelMask,
    FloatType)
{
  PixelHLS<T> hls(ioPixel);

  elxDesaturateHLS(hls, iFactor, CM_All);

  PixelRGB<T> rgb(hls);
  if (iChannelMask & CM_Channel0) ioPixel._red   = rgb._red;
  if (iChannelMask & CM_Channel1) ioPixel._green = rgb._green;
  if (iChannelMask & CM_Channel2) ioPixel._blue  = rgb._blue;

} // elxDesaturateRGB # FloatType

//----------------------------------------------------------------------------
//  elxDesaturateRGBA
//----------------------------------------------------------------------------
template<typename T>
inline
void elxDesaturateRGBA(PixelRGBA<T>& ioPixel, double iFactor, uint32 iChannelMask)
{
  // convert to RGB<T>, Desaturate, back to original color space
  PixelRGB<T> rgb(ioPixel);
  elxDesaturateRGB(rgb, iFactor, iChannelMask, INTEGER_TYPE(T));
  ioPixel._red   = rgb._red;
  ioPixel._green = rgb._green;
  ioPixel._blue  = rgb._blue;
  // unchange alpha channel

} // elxDesaturateRGBA

//----------------------------------------------------------------------------
//  elxDesaturate # ColorType
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxDesaturate(Pixel& ioPixel, double iFactor, uint32 iChannelMask, ColorType)
{
  typedef typename Pixel::type T;

  // convert to RGB<T>, Desaturate, back to original color space
  PixelRGB<T> rgb(ioPixel);
  elxDesaturateRGB(rgb, iFactor, CM_All, INTEGER_TYPE(T));
  const Pixel pixel = Pixel(rgb);

  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
    if (elxUseChannel(c, iChannelMask))
      ioPixel._channel[c] = pixel._channel[c];

} // elxDesaturate # ColorType


template<class Pixel> 
struct DesaturateHelper
{
  static void Do(Pixel& ioPixel, double iFactor, uint32 iChannelMask)
  { elxDesaturate(ioPixel, iFactor, iChannelMask, PIXEL_COLOR_TYPE(Pixel)); }
};

template<typename T> 
struct DesaturateHelper< PixelHLS<T> >
{
  static void Do(PixelHLS<T>& ioPixel, double iFactor, uint32 iChannelMask)
  { elxDesaturateHLS(ioPixel, iFactor, iChannelMask); }
};

template<typename T> 
struct DesaturateHelper< PixelRGB<T> >
{
  static void Do(PixelRGB<T>& ioPixel, double iFactor, uint32 iChannelMask)
  { elxDesaturateRGB(ioPixel, iFactor, iChannelMask, INTEGER_TYPE(T)); }
};

template<typename T> 
struct DesaturateHelper< PixelRGBA<T> >
{
  static void Do(PixelRGBA<T>& ioPixel, double iFactor, uint32 iChannelMask)
  { elxDesaturateRGBA(ioPixel, iFactor, iChannelMask); }
};

} // anonymous-namespace

//----------------------------------------------------------------------------
//  elxDesaturate # generic
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxDesaturate(Pixel& ioPixel, double iFactor, uint32 iChannelMask)
{
  DesaturateHelper<Pixel>::Do(ioPixel, iFactor, iChannelMask);

} // elxDesaturate # generic


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                          elxAdjustHueSaturation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

//----------------------------------------------------------------------------
//  elxAdjustHue # FloatType
//----------------------------------------------------------------------------
template<typename T>
inline
void elxAdjustHue(T& ioHue, double iAdjustment, FloatType)
{
  // hue cycle in [0, 1[
  ioHue += T(iAdjustment);
  if      (ioHue <  T(0)) ioHue += T(1);
  else if (ioHue >= T(1)) ioHue -= T(1);

} // elxAdjustHue # FloatType

//----------------------------------------------------------------------------
//  elxAdjustHue # IntegerType
//----------------------------------------------------------------------------
template<typename T>
inline
void elxAdjustHue(T& ioHue, double iAdjustment, IntegerType)
{
  // hue cycle in [0, elxGetMaxHue<T>]
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;
  const T HueMax = elxGetHueMax<T>();

  M h = M(ioHue)+ M(iAdjustment*HueMax);
  if (h < 0) h += HueMax; else if (h > HueMax) h -= HueMax;
  ioHue = T(h);

} // elxAdjustHue # IntegerType

//----------------------------------------------------------------------------
//  elxAdjustSaturation # FloatType
//----------------------------------------------------------------------------
template<typename T>
inline
void elxAdjustSaturation(T& ioSaturation, double iAdjustment, FloatType)
{
  // keep gray value
  if (ioSaturation == T(0)) return;

  if (iAdjustment == 1.)
  {
    // handles div by 0
    ioSaturation = T(1);
    return;
  }

  ioSaturation *= (iAdjustment > 0) ?
    // Apply non-linear curve for maximum saturation at 1
    T(1. / (1. - iAdjustment)) :
    // Linear adjustment
    T(1. + iAdjustment);

  // saturation is clamped in normalized range
  if      (ioSaturation < T(0)) ioSaturation = T(0);
  else if (ioSaturation > T(1)) ioSaturation = T(1);

} // elxAdjustSaturation # FloatType

//----------------------------------------------------------------------------
//  elxAdjustSaturation # IntegerType
//----------------------------------------------------------------------------
template<typename T>
inline
void elxAdjustSaturation(T& ioSaturation, double iAdjustment, IntegerType)
{
  // keep gray value
  if (ioSaturation == T(0)) return;

  if (iAdjustment == 1.)
  {
    // handles div by 0
    ioSaturation = ResolutionTypeTraits<T>::_max;
    return;
  }

  const double factor = (iAdjustment > 0) ?
    // Apply non-linear curve for maximum saturation at 1
    1.0 / (1.0 - iAdjustment) :
    // Linear adjustment
    1.0 + iAdjustment;

  // saturation is clamped in range[0, <T>::_max]
  ioSaturation = ResolutionTypeTraits<T>::Clamp( ioSaturation * factor );

} // elxAdjustSaturation # IntegerType

//----------------------------------------------------------------------------
//  elxAdjustHueSaturation # NonColorType
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxAdjustHueSaturation(Pixel& ioPixel, 
    double iHue, double iSaturation, NonColorType)
{
  // Do nothing

} // elxAdjustHueSaturation # NonColorType

//----------------------------------------------------------------------------
//  elxAdjustHueSaturationHLS
//----------------------------------------------------------------------------
template<typename T>
inline
void elxAdjustHueSaturationHLS(PixelHLS<T>& ioPixel, double iHue, double iSaturation)
{
  elxAdjustHue(ioPixel._hue, iHue, INTEGER_TYPE(T));
  elxAdjustSaturation(ioPixel._saturation, iSaturation, INTEGER_TYPE(T));

} // elxAdjustHueSaturationHLS

//----------------------------------------------------------------------------
//  elxAdjustHueSaturationRGB # IntegerType
//----------------------------------------------------------------------------
//  iHue in range [-1, +1]
//  iSaturation in range [-1, +1]
//----------------------------------------------------------------------------
template<typename T>
inline
void elxAdjustHueSaturationRGB(PixelRGB<T>& ioPixel, 
    double iHue, double iSaturation, IntegerType)
{
  T h,l,s;
  elxRGBToHLS(ioPixel, h,l,s, INTEGER_TYPE(T));
  elxAdjustHue(h, iHue, INTEGER_TYPE(T));
  elxAdjustSaturation(s, iSaturation, INTEGER_TYPE(T));
  elxHLSToRGB(h,l,s, ioPixel, INTEGER_TYPE(T));

} // elxAdjustHueSaturationRGB # IntegerType

//----------------------------------------------------------------------------
//  elxAdjustHueSaturationRGB # FloatType
//----------------------------------------------------------------------------
//  iHue in range [0, 1]
//  iSaturation in range [0, 1]
//----------------------------------------------------------------------------
template<typename T>
inline
void elxAdjustHueSaturationRGB(PixelRGB<T>& ioPixel, 
    double iHue, double iSaturation, FloatType)
{
  PixelHLS<T> hls(ioPixel);
  elxAdjustHue(hls._hue, iHue, INTEGER_TYPE(T));
  elxAdjustSaturation(hls._saturation, iSaturation, INTEGER_TYPE(T));
  ioPixel = hls;

} // elxAdjustHueSaturationRGB # FloatType

//----------------------------------------------------------------------------
//  elxAdjustHueSaturation # ColorType
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxAdjustHueSaturation(Pixel& ioPixel, 
    double iHue, double iSaturation, ColorType)
{
  typedef typename Pixel::type T;

  // convert to RGB<T>, Adjust Hue,Saturation, back to original color space 
  PixelRGB<T> rgb(ioPixel);
  elxAdjustHueSaturationRGB(rgb, iHue, iSaturation, INTEGER_TYPE(T));
  ioPixel = Pixel(rgb);

} // elxAdjustHueSaturation # ColorType


template<class Pixel> 
struct AdjustHueSaturationHelper
{
  static void Do(Pixel& ioPixel, double iHue, double iSaturation)
  { elxAdjustHueSaturation(ioPixel, iHue, iSaturation, PIXEL_COLOR_TYPE(Pixel)); }
};

template<typename T> 
struct AdjustHueSaturationHelper< PixelRGB<T> >
{
  static void Do(PixelRGB<T>& ioPixel, double iHue, double iSaturation)
  { elxAdjustHueSaturationRGB(ioPixel, iHue, iSaturation, INTEGER_TYPE(T)); }
};

template<typename T> 
struct AdjustHueSaturationHelper< PixelHLS<T> >
{
  static void Do(PixelHLS<T>& ioPixel, double iHue, double iSaturation)
  { elxAdjustHueSaturationHLS(ioPixel, iHue, iSaturation); }
};

} // namespace

//----------------------------------------------------------------------------
//  elxAdjustHueSaturation # generic
//----------------------------------------------------------------------------
template<class Pixel> 
inline
void elxAdjustHueSaturation(Pixel& ioPixel, double iHue, double iSaturation)
{
  AdjustHueSaturationHelper<Pixel>::Do(ioPixel, iHue, iSaturation);

} // elxAdjustHueSaturation # generic


//----------------------------------------------------------------------------
//  explicit instanciations
//----------------------------------------------------------------------------

//--- PixelHLS contructors ---------------------------------------------------
template<> PixelHLS<float>::PixelHLS() {}
template<> PixelHLS<double>::PixelHLS() {}

template<> PixelHLS<float>::PixelHLS(float iH, float iL, float iS)     { _hue = iH; _luminance = iL; _saturation = iS; }
template<> PixelHLS<double>::PixelHLS(double iH, double iL, double iS) { _hue = iH; _luminance = iL; _saturation = iS; }

template<> PixelHLS<float>::PixelHLS(const PixelL<float>& iPixel)      { _hue = 0.0f; _luminance = iPixel._luminance; _saturation = 0.0f; }
template<> PixelHLS<double>::PixelHLS(const PixelL<double>& iPixel)    { _hue = 0.0;  _luminance = iPixel._luminance; _saturation = 0.0; }

template<> PixelHLS<float>::PixelHLS(const PixelLA<float>& iPixel)     { _hue = 0.0f; _luminance = iPixel._luminance; _saturation = 0.0f; }
template<> PixelHLS<double>::PixelHLS(const PixelLA<double>& iPixel)   { _hue = 0.0;  _luminance = iPixel._luminance; _saturation = 0.0; }

template PixelHLS<float>::PixelHLS(const PixelRGB<float>&);
template PixelHLS<float>::PixelHLS(const PixelXYZ<float>&);
template PixelHLS<float>::PixelHLS(const PixelLuv<float>&);
template PixelHLS<float>::PixelHLS(const PixelLab<float>&);
template PixelHLS<float>::PixelHLS(const PixelLch<float>&);
template PixelHLS<float>::PixelHLS(const PixelHLab<float>&);

template PixelHLS<double>::PixelHLS(const PixelRGB<double>&);
template PixelHLS<double>::PixelHLS(const PixelXYZ<double>&);
template PixelHLS<double>::PixelHLS(const PixelLuv<double>&);
template PixelHLS<double>::PixelHLS(const PixelLab<double>&);
template PixelHLS<double>::PixelHLS(const PixelLch<double>&);
template PixelHLS<double>::PixelHLS(const PixelHLab<double>&);

//--- elxGetHue --------------------------------------------------------------
template uint8  elxGetHue<uint8> (double);
template uint16 elxGetHue<uint16>(double);
template int32    elxGetHue<int32>   (double);
template float  elxGetHue<float> (double);
template double elxGetHue<double>(double);

//--- elxGetSaturation -------------------------------------------------------
template uint8  elxGetSaturation<uint8> (double);
template uint16 elxGetSaturation<uint16>(double);
template int32    elxGetSaturation<int32>   (double);
template float  elxGetSaturation<float> (double);
template double elxGetSaturation<double>(double);

//--- elxHLSToRGB ------------------------------------------------------------
template void elxHLSToRGB<uint8>(uint8, uint8, uint8, PixelRGB<uint8>&);
template void elxHLSToRGB<uint16>(uint16, uint16, uint16, PixelRGB<uint16>&);
template void elxHLSToRGB<int32>(int32, int32, int32, PixelRGB<int32>&);
template void elxHLSToRGB<float>(float, float, float, PixelRGB<float>&);
template void elxHLSToRGB<double>(double, double, double, PixelRGB<double>&);

//--- elxRGBToHLS ------------------------------------------------------------
template void elxRGBToHLS<uint8>(const PixelRGB<uint8>&, uint8&, uint8&, uint8&);
template void elxRGBToHLS<uint16>(const PixelRGB<uint16>&, uint16&, uint16&, uint16&);
template void elxRGBToHLS<int32>(const PixelRGB<int32>&, int32&, int32&, int32&);
template void elxRGBToHLS<float>(const PixelRGB<float>&, float&, float&, float&);
template void elxRGBToHLS<double>(const PixelRGB<double>&, double&, double&, double&);

//--- elxColorize ------------------------------------------------------------
#define MACRO_COLORIZE(Pixel, T) \
  template void elxColorize< Pixel<T> >(Pixel<T>&, T, T);

elxINSTANTIATE_METHOD_FOR_ALL_PIXEL_TYPES2( MACRO_COLORIZE );

//--- elxAdjustHueSaturation -------------------------------------------------
#define MACRO_ADJUST_HUE_SATURATION(Pixel) \
  template void elxAdjustHueSaturation<Pixel>(Pixel&, double, double);

elxINSTANTIATE_METHOD_FOR_ALL_PIXEL_TYPES( MACRO_ADJUST_HUE_SATURATION );

//--- elxDesaturate ----------------------------------------------------------
#define MACRO_DESATURATE(Pixel, T) \
  template void elxDesaturate< Pixel<T> >(Pixel<T>&, double, uint32);

elxINSTANTIATE_METHOD_FOR_ALL_PIXEL_TYPES2( MACRO_DESATURATE );

/*
  PixelRGB<T> pixel;
  PixelRGB<T> white(255,255,255);
  elxRGBToHLS(white, h,l,s, INTEGER_TYPE(T));
  elxHLSToRGB(h,l,s, pixel, INTEGER_TYPE(T));

  PixelRGB<T> caca(255,255,254);
  elxRGBToHLS(caca, h,l,s, INTEGER_TYPE(T));
  elxHLSToRGB(h,l,s, pixel, INTEGER_TYPE(T));

  PixelRGB<T> yellow(255,255,0);
  elxRGBToHLS(yellow, h,l,s, INTEGER_TYPE(T));
  elxHLSToRGB(h,l,s, pixel, INTEGER_TYPE(T));

  PixelRGB<T> red(255,0,0);
  elxRGBToHLS(red, h,l,s, INTEGER_TYPE(T));
  elxHLSToRGB(h,l,s, pixel, INTEGER_TYPE(T));

  PixelRGB<T> green(0,255,0);
  elxRGBToHLS(green, h,l,s, INTEGER_TYPE(T));
  elxHLSToRGB(h,l,s, pixel, INTEGER_TYPE(T));

  PixelRGB<T> blue(0,0,255);
  elxRGBToHLS(blue, h,l,s, INTEGER_TYPE(T));
  elxHLSToRGB(h,l,s, pixel, INTEGER_TYPE(T));
*/
} // namespace Image
} // namespace eLynx

#endif // __ColorSpace_HLS_hpp__
