//============================================================================
//  ColorSpace_CIE.hpp                                 Image.Component package
//============================================================================
//  Ranges:
//  RGB: normalized R,G,B in range [0, 1]
//  CIE XYZ: Y [0, 100], X,Z [-120, +120]
//  CIE Luv: L [0, 100], u [-134, +220], v [-140, +122]
//  CIE Lab: L [0, 100], a,b [-120, +120]
//  CIE Lch: L [0, 100], c [0, 170], h [0, 360]
//  Hunter Lab: L, a,b
//
//  Direct color space conversions:
//  RGB      <=> CIE XYZ
//  CIE XYZ  <=> CIE Luv
//  CIE XYZ  <=> CIE Lab
//  CIE XYZ  <=> Hunter Lab
//  CIE Lab  <=> CIE Lch
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __ColorSpace_CIE_hpp__
#define __ColorSpace_CIE_hpp__

namespace eLynx {
namespace Image {

// Tristimulus reference values
const double g_TristimulusLut[TV_F11_10+1][3] = 
{
  // 2 degrees                  // Illuminant
  {109.850, 100.000, 35.585},   // A
  {98.074,  100.000, 118.232},  // C
  {96.422,  100.000, 82.521},   // D50
  {95.682,  100.000, 92.149},   // D55  
  {95.047,  100.000, 108.883},  // D65 
  {94.972,  100.000, 122.638},  // D75
  {99.187,  100.000, 67.395},   // F2
  {95.044,  100.000, 108.755},  // F7
  {100.966, 100.000, 64.370},   // F11

  // 10 degrees
  {111.144, 100.000, 35.200},   // A
  {97.285,  100.000, 116.145},  // C
  {96.720,  100.000, 81.427},   // D50
  {95.799,  100.000, 90.926},   // D55 
  {94.811,  100.000, 107.304},  // D65 (default tristimulus)
  {94.416,  100.000, 120.641},  // D75
  {103.280, 100.000, 69.026},   // F2
  {95.792,  100.000, 107.687},  // F7
  {103.866, 100.000, 65.627}    // F11
};

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                             RGB <=> CIE XYZ
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Transform from RGB to CIE XYZ
//  To be used with mormalized float and double type only (in range [0..1]).
//----------------------------------------------------------------------------
template<typename T>
inline 
PixelXYZ<T>::PixelXYZ(const PixelRGB<T>& iPixel)
{
  // scale to white reference
  T r = T(g_TristimulusLut[TV_Default][0]) * iPixel._red;
  T g = T(g_TristimulusLut[TV_Default][1]) * iPixel._green;
  T b = T(g_TristimulusLut[TV_Default][2]) * iPixel._blue;

  // apply transformation matrix
  _X = T(0.4124)*r + T(0.3576)*g + T(0.1805)*b;
  _Y = T(0.2126)*r + T(0.7152)*g + T(0.0722)*b;
  _Z = T(0.0193)*r + T(0.1192)*g + T(0.9505)*b;
}

//----------------------------------------------------------------------------
template<typename T> 
inline 
T ft_XYZ2RGB(T t)
{
  if (t <= T(0.0031308)) return T(12.92) * t;
  return T(1.055) * Math::elxPow(t, T(1./2.4)) - T(0.055);
}

//----------------------------------------------------------------------------
//  Transform from CIE XYZ to normalized RGB
//  To be used with float and double type only.
//----------------------------------------------------------------------------
template<typename T>
inline 
PixelRGB<T>::PixelRGB(const PixelXYZ<T>& iPixel)
{
  const T x = iPixel._X;
  const T y = iPixel._Y;
  const T z = iPixel._Z;

  // apply transformation matrix
  _red   =  T(3.2406)*x - T(1.5372)*y - T(0.4986)*z;
  _green = -T(0.9689)*x + T(1.8758)*y + T(0.0415)*z;
  _blue  =  T(0.0557)*x - T(0.2040)*y + T(1.0570)*z;
/*
  ft_XYZ2RGB(_red);
  ft_XYZ2RGB(_green);
  ft_XYZ2RGB(_blue);
*/
  // normalize from white reference
  _red   /= T(g_TristimulusLut[TV_Default][0]); 
  _green /= T(g_TristimulusLut[TV_Default][1]); 
  _blue  /= T(g_TristimulusLut[TV_Default][2]); 

  elxClampNorm(*this);
}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                            CIE XYZ <=> CIE Luv
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Transform from CIE Luv to CIE XYZ
//  To be used with float and double type only.
//----------------------------------------------------------------------------
template<typename T>
inline 
PixelXYZ<T>::PixelXYZ(const PixelLuv<T>& iPixel)
{
  const T L = iPixel._luminance; 
  const T u = iPixel._u; 
  const T v = iPixel._v;

  // white reference
  const T Xr = T(g_TristimulusLut[TV_Default][0]);
  const T Yr = T(g_TristimulusLut[TV_Default][1]);
  const T Zr = T(g_TristimulusLut[TV_Default][2]);

  const T Ur = 4*Xr / (Xr + 15*Yr + 3*Zr);
  const T Vr = 9*Yr / (Xr + 15*Yr + 3*Zr);

  const T U = Ur + u/(13*L);
  const T V = Vr + v/(13*L);
  T Y = (L + 16)/T(116);

  const T Y3 = Y*Y*Y;
  if (Y3 > T(0.008856)) Y = Y3;
  else                  Y = (Y - T(16./116.))/T(7.787);

  _Y = Y * 100;
  _X = -9*_Y*U / ((U - 4)*V - U*V );
  _Z = (9*_Y - 15*V*_Y - V*_X) / (3*V);
}

//----------------------------------------------------------------------------
//  Transform from CIE XYZ to CIE Luv
//  To be used with float and double type only.
//----------------------------------------------------------------------------
template<typename T>
inline 
PixelLuv<T>::PixelLuv(const PixelXYZ<T>& iPixel)
{
  const T x = iPixel._X; 
  const T y = iPixel._Y; 
  const T z = iPixel._Z;

  // white reference
  const T Xr = T(g_TristimulusLut[TV_Default][0]);
  const T Yr = T(g_TristimulusLut[TV_Default][1]);
  const T Zr = T(g_TristimulusLut[TV_Default][2]);

  const T Ur = 4*Xr / (Xr + 15*Yr + 3*Zr);
  const T Vr = 9*Yr / (Xr + 15*Yr + 3*Zr);

  T Y = T(0.01) * y;
  const T U = 4*x / (x + 15*y + 3*z);
  const T V = 9*y / (x + 15*y + 3*z);

  if ( Y > 0.008856 ) Y = Math::elxPow(Y, T(1./3.));
  else                Y = T(7.787)*Y + T(16./116.);

  _luminance = 116*Y - 16;
  _u = 13*_luminance*(U - Ur);
  _v = 13*_luminance*(V - Vr);
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                            CIE XYZ <=> CIE Lab
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template<typename T> 
inline 
T ft_xz(T t)
{
  if (t <= T(0.207)) return ((t - T(16)/T(116)) / T(7.787));
  return t*t*t;
}

//----------------------------------------------------------------------------
template<typename T> 
inline 
T ft_ab(T t)
{
  if (t <= T(0.008856)) return (T(7.7787)*t + T(16)/T(116));
  return Math::elxPow(t, T(T(1)/T(3)));
}
  
//----------------------------------------------------------------------------
//  Transform from CIE L*ab to CIE XYZ
//  To be used with float and double type only.
//----------------------------------------------------------------------------
template<typename T>
inline 
PixelXYZ<T>::PixelXYZ(const PixelLab<T>& iPixel)
{
  const T L = iPixel._luminance;
  const T a = iPixel._a;
  const T b = iPixel._b;

  _Y = (L + T(16) ) / T(116);
  _X = _Y + a/T(500);
  _Z = _Y - b/T(200);

  _X = ft_xz(_X) * T(g_TristimulusLut[TV_Default][0]);
  _Y = ft_xz(_Y) * T(g_TristimulusLut[TV_Default][1]);
  _Z = ft_xz(_Z) * T(g_TristimulusLut[TV_Default][2]);

} // CIE Lab => CIE XYZ

//----------------------------------------------------------------------------
//  Transform from CIE XYZ to CIE L*ab
//  To be used with float and double type only.
//----------------------------------------------------------------------------
template<typename T>
inline 
PixelLab<T>::PixelLab(const PixelXYZ<T>& iPixel)
{
  // normalize from white reference
  T x = iPixel._X / T(g_TristimulusLut[TV_Default][0]); 
  T y = iPixel._Y / T(g_TristimulusLut[TV_Default][1]); 
  T z = iPixel._Z / T(g_TristimulusLut[TV_Default][2]); 

  x = ft_ab(x);
  y = ft_ab(y);
  z = ft_ab(z);

  _luminance = T(116)*y - T(16);
  _a = T(500)*(x - y);
  _b = T(200)*(y - z);

} // CIE XYZ => CIE Lab

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                         CIE XYZ <=> Hunter Lab
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Transform from Hunter Lab to CIE XYZ
//  To be used with float and double type only.
//----------------------------------------------------------------------------
template<typename T>
inline
PixelXYZ<T>::PixelXYZ(const PixelHLab<T>& iPixel)
{
  const T L = iPixel._luminance;
  const T a = iPixel._a;
  const T b = iPixel._b;

  const T y = L * T(0.1);
  const T x = y * a / T(17.5);
  const T z = y * b / T(7);

  _Y = y*y;
  _X = (_Y + x) * T(1./1.02);
  _Z = (_Y - z) * T(1./0.847);
}

//----------------------------------------------------------------------------
//  Transform from CIE XYZ to Hunter Lab
//  To be used with float and double type only.
//----------------------------------------------------------------------------
template<typename T>
inline
PixelHLab<T>::PixelHLab(const PixelXYZ<T>& iPixel)
{
  const T x = iPixel._X;
  const T y = iPixel._Y;
  const T z = iPixel._Z;

  const T sqrtY = Math::elxSqrt(y);
  _luminance = T(10) * sqrtY;
  _a = T(17.5) * (T(1.02)*x - y) / sqrtY;
  _b = T(7) * (y - T(0.847)*z) / sqrtY;
}


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                         CIE Lab <=> CIE Lch
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Transform from CIE Lch to CIE Lab
//  To be used with float and double type only.
//----------------------------------------------------------------------------
template<typename T>
inline
PixelLab<T>::PixelLab(const PixelLch<T>& iPixel)
{
  const T radian = iPixel._h * T(M_PI / 180);
  _luminance = iPixel._luminance;
  _a = iPixel._c * Math::elxCos(radian);
  _b = iPixel._c * Math::elxSin(radian);
}

//----------------------------------------------------------------------------
//  Transform from CIE Lab to CIE Lch
//  To be used with float and double type only.
//----------------------------------------------------------------------------
template<typename T>
inline
PixelLch<T>::PixelLch(const PixelLab<T>& iPixel)
{
  const T a = iPixel._a;
  const T b = iPixel._b;

  _luminance = iPixel._luminance;
  _c = Math::elxSqrt(a*a + b*b);

  // Quadrant by signs
  _h = ::atan2(b, a);
  if (_h > 0) _h *= T(180 / M_PI);
  else        _h = T(360 - 180*(int32(_h)) / M_PI);
}




//----------------------------------------------------------------------------
//  XYZ To Lab
//----------------------------------------------------------------------------
template <typename T>
inline
float CIELut::GetXYZ2Lab(T iValue) 
{ 
  float f = float(iValue);
  return ( (f > 0.008856f) ? Math::elxPow(f, 1/3.0f) : 7.787f*f + 16/116.0f );
}

template <>
inline
float CIELut::GetXYZ2Lab<uint8>(uint8 iValue)
{
  return CIELut::_slutXYZ2Lab_ub[ iValue ];
}

template <>
inline
float CIELut::GetXYZ2Lab<uint16>(uint16 iValue)
{
  return CIELut::_slutXYZ2Lab_us[ iValue ];
}

//----------------------------------------------------------------------------
//  RGB to XYZ
//----------------------------------------------------------------------------
bool CIELut::_sbInit = false;

float CIELut::_slutXYZ2Lab_ub[0x100];
float CIELut::_slutXYZ2Lab_us[0x10000];

uint8  CIELut::_slutRGB2XYZ_ub[0x100][9];
uint16 CIELut::_slutRGB2XYZ_us[0x10000][9];

const float MatRGB2XYZ[9] = { 
  0.433953f, 0.376219f, 0.189828f,
  0.212671f, 0.715160f, 0.072169f,
  0.017758f, 0.109477f, 0.872766f 
};

void CIELut::Init()
{
  // compute tables once
  if (CIELut::_sbInit == true) return;
  _sbInit = true;

  float r;
  int32 i,j;
  for (i=0; i<0x100; i++)
  {
    r = float(i) / 255.0f;
    _slutXYZ2Lab_ub[i] = r > 0.008856f ? 
      Math::elxPow(r, 1/3.0f) : 7.787f*r + 16/116.0f;
    for (j=0; j<9; j++)
      _slutRGB2XYZ_ub[i][j] = uint8(i*MatRGB2XYZ[j]);
  }
  for (i=0; i<0x10000; i++)
  {
    r = float(i) / 65535.0f;
    _slutXYZ2Lab_us[i] = r > 0.008856f ? 
      Math::elxPow(r, 1/3.0f) : 7.787f*r + 16/116.0f;
    for (j=0; j<9; j++)
      _slutRGB2XYZ_us[i][j] = uint16(i*MatRGB2XYZ[j]);
  }
}

//----------------------------------------------------------------------------
//  elxRGBToLab # uint8
//----------------------------------------------------------------------------
template <>
void elxRGBToLab<uint8>(
    const PixelRGB<uint8>& iPixelRGB, 
    PixelLab<ResolutionTypeTraits<uint8>::Floating_type>& oPixelLab)
{
  typedef ResolutionTypeTraits<uint8>::Floating_type F;

  const uint8 r = iPixelRGB._red;
  const uint8 g = iPixelRGB._green;
  const uint8 b = iPixelRGB._blue;

  // rgb to CIE XYZ, applying transformation matrix with D65 white
  uint8 x = CIELut::_slutRGB2XYZ_ub[r][0] + CIELut::_slutRGB2XYZ_ub[g][1] + CIELut::_slutRGB2XYZ_ub[b][2];
  uint8 y = CIELut::_slutRGB2XYZ_ub[r][3] + CIELut::_slutRGB2XYZ_ub[g][4] + CIELut::_slutRGB2XYZ_ub[b][5];
  uint8 z = CIELut::_slutRGB2XYZ_ub[r][6] + CIELut::_slutRGB2XYZ_ub[g][7] + CIELut::_slutRGB2XYZ_ub[b][8];

  // CIE XYZ to CIE Lab
  F X = CIELut::GetXYZ2Lab<uint8>( x );
  F Y = CIELut::GetXYZ2Lab<uint8>( y );
  F Z = CIELut::GetXYZ2Lab<uint8>( z );

  oPixelLab._luminance  = 116*Y - 16;
  oPixelLab._a          = 500*(X - Y);
  oPixelLab._b          = 200*(Y - Z);

} //  elxRGBToLab # uint8

//----------------------------------------------------------------------------
//  elxRGBToLab # uint16
//----------------------------------------------------------------------------
template <>
void elxRGBToLab<uint16>(
    const PixelRGB<uint16>& iPixelRGB, 
    PixelLab<ResolutionTypeTraits<uint16>::Floating_type>& oPixelLab)
{
  typedef ResolutionTypeTraits<uint16>::Floating_type F;

  const uint16 r = iPixelRGB._red;
  const uint16 g = iPixelRGB._green;
  const uint16 b = iPixelRGB._blue;

  // rgb to CIE XYZ, applying transformation matrix with D65 white
  uint16 x = CIELut::_slutRGB2XYZ_us[r][0] + CIELut::_slutRGB2XYZ_us[g][1] + CIELut::_slutRGB2XYZ_us[b][2];
  uint16 y = CIELut::_slutRGB2XYZ_us[r][3] + CIELut::_slutRGB2XYZ_us[g][4] + CIELut::_slutRGB2XYZ_us[b][5];
  uint16 z = CIELut::_slutRGB2XYZ_us[r][6] + CIELut::_slutRGB2XYZ_us[g][7] + CIELut::_slutRGB2XYZ_us[b][8];

  // CIE XYZ to CIE Lab
  F X = CIELut::GetXYZ2Lab<uint16>( x );
  F Y = CIELut::GetXYZ2Lab<uint16>( y );
  F Z = CIELut::GetXYZ2Lab<uint16>( z );

  oPixelLab._luminance  = 116*Y - 16;
  oPixelLab._a          = 500*(X - Y);
  oPixelLab._b          = 200*(Y - Z);

} // elxRGBToLab # uint16

//----------------------------------------------------------------------------
//  elxRGBToLab # int32
//----------------------------------------------------------------------------
template <>
void elxRGBToLab<int32>(
    const PixelRGB<int32>& iPixelRGB, 
    PixelLab<ResolutionTypeTraits<int32>::Floating_type>& oPixelLab)
{
  typedef ResolutionTypeTraits<int32>::Floating_type F;
  PixelRGB<F> rgbf(iPixelRGB);
  PixelXYZ<F> xyz(rgbf);
  oPixelLab = xyz;

} // elxRGBToLab # int32

//----------------------------------------------------------------------------
//  elxRGBToLab # float
//----------------------------------------------------------------------------
template <>
void elxRGBToLab<float>(
    const PixelRGB<float>& iPixelRGB, 
    PixelLab<ResolutionTypeTraits<float>::Floating_type>& oPixelLab)
{
  typedef ResolutionTypeTraits<int32>::Floating_type F;
  PixelXYZ<F> xyz(iPixelRGB);
  oPixelLab = xyz;

} // elxRGBToLab # float

//----------------------------------------------------------------------------
//  elxRGBToLab # double
//----------------------------------------------------------------------------
template <>
void elxRGBToLab<double>(
    const PixelRGB<double>& iPixelRGB, 
    PixelLab<ResolutionTypeTraits<double>::Floating_type>& oPixelLab)
{
  PixelXYZ<double> xyz(iPixelRGB);
  oPixelLab = xyz;

} // elxRGBToLab # double



//----------------------------------------------------------------------------
//  explicit instanciations
//----------------------------------------------------------------------------

//--- CIE Pixel contructors --------------------------------------------------
template<> PixelXYZ<float >::PixelXYZ() {}
template<> PixelXYZ<double>::PixelXYZ() {}
template<> PixelLuv<float >::PixelLuv() {}
template<> PixelLuv<double>::PixelLuv() {}
template<> PixelLab<float >::PixelLab() {}
template<> PixelLab<double>::PixelLab() {}
template<> PixelLch<float >::PixelLch() {}
template<> PixelLch<double>::PixelLch() {}
template<> PixelHLab<float >::PixelHLab() {}
template<> PixelHLab<double>::PixelHLab() {}

//--- PixelXYZ ---------------------------------------------------------------
template PixelXYZ<float>::PixelXYZ(const PixelRGB<float>&);
template PixelXYZ<float>::PixelXYZ(const PixelHLS<float>&);
template PixelXYZ<float>::PixelXYZ(const PixelLuv<float>&);
template PixelXYZ<float>::PixelXYZ(const PixelLab<float>&);
template PixelXYZ<float>::PixelXYZ(const PixelLch<float>&);
template PixelXYZ<float>::PixelXYZ(const PixelHLab<float>&);

template PixelXYZ<double>::PixelXYZ(const PixelRGB<double>&);
template PixelXYZ<double>::PixelXYZ(const PixelHLS<double>&);
template PixelXYZ<double>::PixelXYZ(const PixelLuv<double>&);
template PixelXYZ<double>::PixelXYZ(const PixelLab<double>&);
template PixelXYZ<double>::PixelXYZ(const PixelLch<double>&);
template PixelXYZ<double>::PixelXYZ(const PixelHLab<double>&);

//--- PixelLuv ---------------------------------------------------------------
template PixelLuv<float>::PixelLuv(const PixelRGB<float>&);
template PixelLuv<float>::PixelLuv(const PixelHLS<float>&);
template PixelLuv<float>::PixelLuv(const PixelXYZ<float>&);
template PixelLuv<float>::PixelLuv(const PixelLab<float>&);
template PixelLuv<float>::PixelLuv(const PixelLch<float>&);
template PixelLuv<float>::PixelLuv(const PixelHLab<float>&);

template PixelLuv<double>::PixelLuv(const PixelRGB<double>&);
template PixelLuv<double>::PixelLuv(const PixelHLS<double>&);
template PixelLuv<double>::PixelLuv(const PixelXYZ<double>&);
template PixelLuv<double>::PixelLuv(const PixelLab<double>&);
template PixelLuv<double>::PixelLuv(const PixelLch<double>&);
template PixelLuv<double>::PixelLuv(const PixelHLab<double>&);

//--- PixelLab ---------------------------------------------------------------
template PixelLab<float>::PixelLab(const PixelL<float>&);
template PixelLab<float>::PixelLab(const PixelLA<float>&);
template PixelLab<float>::PixelLab(const PixelRGB<float>&);
template PixelLab<float>::PixelLab(const PixelRGBA<float>&);
template PixelLab<float>::PixelLab(const PixelHLS<float>&);
template PixelLab<float>::PixelLab(const PixelXYZ<float>&);
template PixelLab<float>::PixelLab(const PixelLuv<float>&);
template PixelLab<float>::PixelLab(const PixelLch<float>&);
template PixelLab<float>::PixelLab(const PixelHLab<float>&);

template PixelLab<double>::PixelLab(const PixelL<double>&);
template PixelLab<double>::PixelLab(const PixelLA<double>&);
template PixelLab<double>::PixelLab(const PixelRGB<double>&);
template PixelLab<double>::PixelLab(const PixelRGBA<double>&);
template PixelLab<double>::PixelLab(const PixelHLS<double>&);
template PixelLab<double>::PixelLab(const PixelXYZ<double>&);
template PixelLab<double>::PixelLab(const PixelLuv<double>&);
template PixelLab<double>::PixelLab(const PixelLch<double>&);
template PixelLab<double>::PixelLab(const PixelHLab<double>&);

//--- PixelLch ---------------------------------------------------------------
template PixelLch<float>::PixelLch(const PixelRGB<float>&);
template PixelLch<float>::PixelLch(const PixelHLS<float>&);
template PixelLch<float>::PixelLch(const PixelXYZ<float>&);
template PixelLch<float>::PixelLch(const PixelLuv<float>&);
template PixelLch<float>::PixelLch(const PixelLab<float>&);
template PixelLch<float>::PixelLch(const PixelHLab<float>&);

template PixelLch<double>::PixelLch(const PixelRGB<double>&);
template PixelLch<double>::PixelLch(const PixelHLS<double>&);
template PixelLch<double>::PixelLch(const PixelXYZ<double>&);
template PixelLch<double>::PixelLch(const PixelLuv<double>&);
template PixelLch<double>::PixelLch(const PixelLab<double>&);
template PixelLch<double>::PixelLch(const PixelHLab<double>&);

//--- PixelHLab ---------------------------------------------------------------
template PixelHLab<float>::PixelHLab(const PixelRGB<float>&);
template PixelHLab<float>::PixelHLab(const PixelHLS<float>&);
template PixelHLab<float>::PixelHLab(const PixelXYZ<float>&);
template PixelHLab<float>::PixelHLab(const PixelLuv<float>&);
template PixelHLab<float>::PixelHLab(const PixelLab<float>&);
template PixelHLab<float>::PixelHLab(const PixelLch<float>&);

template PixelHLab<double>::PixelHLab(const PixelRGB<double>&);
template PixelHLab<double>::PixelHLab(const PixelHLS<double>&);
template PixelHLab<double>::PixelHLab(const PixelXYZ<double>&);
template PixelHLab<double>::PixelHLab(const PixelLuv<double>&);
template PixelHLab<double>::PixelHLab(const PixelLab<double>&);
template PixelHLab<double>::PixelHLab(const PixelLch<double>&);

} // namespace Image
} // namespace eLynx

#endif // __ColorSpace_CIE_hpp__
