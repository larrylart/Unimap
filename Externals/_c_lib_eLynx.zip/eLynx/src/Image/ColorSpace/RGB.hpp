//============================================================================
//  ColorSpace_RGB.hpp                                 Image.Component package
//============================================================================
//
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __ColorSpace_RGB_hpp__
#define __ColorSpace_RGB_hpp__

#include <elx/math/MathCore.h>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
template<typename T>
inline 
PixelL<T>::PixelL(const PixelLA<T>& iPixel, bool ibBlendAlpha)
{
  if (ibBlendAlpha)
  {
    const double s = iPixel._alpha * ResolutionTypeTraits<T>::_normScale;
    const double w = (1.0 - s) * ResolutionTypeTraits<T>::_norm;
    _luminance = ResolutionTypeTraits<T>::Clamp(w + s * iPixel._luminance);
  }
  else
    _luminance = iPixel._luminance;
}

//----------------------------------------------------------------------------
template<typename T>
inline 
PixelRGB<T>::PixelRGB(const PixelRGBA<T>& iPixel, bool ibBlendAlpha)
{ 
  if (ibBlendAlpha)
  {
    const double s = iPixel._alpha * ResolutionTypeTraits<T>::_normScale;
    const double w = (1.0 - s) * ResolutionTypeTraits<T>::_norm;
    _red   = ResolutionTypeTraits<T>::Clamp(w + s * iPixel._red);
    _green = ResolutionTypeTraits<T>::Clamp(w + s * iPixel._green);
    _blue  = ResolutionTypeTraits<T>::Clamp(w + s * iPixel._blue);
  }
  else
  {
    _red   = iPixel._red; 
    _green = iPixel._green; 
    _blue  = iPixel._blue; 
  }
}

//----------------------------------------------------------------------------
//  GetLuminance : PixelRGB<T> generalization
//----------------------------------------------------------------------------
template<typename T>
T PixelRGB<T>::GetLuminance(EColorToGreyConversion iMethod) const
{
  switch(iMethod)
  {
    case CGC_Green: // L=G
      return _green;

    case CGC_Mean: // L = (r+g+b)/3
      return (_red + _green + _blue)/T(3);

    case CGC_Desaturate: // L = (min(r,g,b) + max(r,g,b))/2
      {
        T Min, Max;
        if (_red < _green) {	
          Min = _red; Max = _green;
        } else {	
          Min = _green; Max = _red;
        }
        if (_blue < Min) Min = _blue;
        if (_blue > Max) Max = _blue;

        return (Min + Max)/T(2);
      }

    case CGC_CCIR_601: // L = 0.2989*r + 0.5866*g + 0.1145*b
      return _red*T(0.2989) + _green*T(0.5866) + _blue*T(0.1145);

    case CGC_CCIR_709: // L = 0.2125*r + 0.7154*g + 0.0721*b
      return _red*T(0.2125) + _green*T(0.7154) + _blue*T(0.0721);

    case CGC_ITU: // L = 0.222*r  + 0.707*g  + 0.071*b
      return _red*T(0.222) + _green*T(0.707) + _blue*T(0.071);
		
    default: 
      return _green;
  }
  return _green;

} // GetLuminance # PixelRGB<T>


//----------------------------------------------------------------------------
//  GetLuminance : PixelRGBA<T> generalization
//----------------------------------------------------------------------------
template<typename T>
T PixelRGBA<T>::GetLuminance(EColorToGreyConversion iMethod) const
{
  switch(iMethod)
  {
    case CGC_Green: // L=G
      return _green;

    case CGC_Mean: // L = (r+g+b)/3
      return (_red + _green + _blue)/T(3);

    case CGC_Desaturate: // L = (min(r,g,b) + max(r,g,b))/2
      {
        T Min, Max;
        if (_red < _green) {	
          Min = _red; Max = _green;
        } else {	
          Min = _green; Max = _red;
        }
        if (_blue < Min) Min = _blue;
        if (_blue > Max) Max = _blue;

        return (Min + Max)/T(2);
      }

    case CGC_CCIR_601: // L = 0.2989*r + 0.5866*g + 0.1145*b
      return _red*T(0.2989) + _green*T(0.5866) + _blue*T(0.1145);

    case CGC_CCIR_709: // L = 0.2125*r + 0.7154*g + 0.0721*b
      return _red*T(0.2125) + _green*T(0.7154) + _blue*T(0.0721);

    case CGC_ITU: // L = 0.222*r  + 0.707*g  + 0.071*b
      return _red*T(0.222) + _green*T(0.707) + _blue*T(0.071);
		
    default: 
      return _green;
  }
  return _green;

} // GetLuminance # PixelRGBA<T>

//----------------------------------------------------------------------------
template<typename T>
inline 
void elxClampNorm(PixelRGB<T>& ioRGB)
{
  // clamp in range [0..1]
  Math::elxClamp(T(0),T(1), ioRGB._red);
  Math::elxClamp(T(0),T(1), ioRGB._green);
  Math::elxClamp(T(0),T(1), ioRGB._blue);
}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                                RGB <=> sRGB
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  RGB to sRGB gamma correction thanks to Rec. ITU-R BT.709
//----------------------------------------------------------------------------
template<typename T>
inline 
T elxRGBTosRGB(T iSample)
{
  if (iSample <= T(0.04045)) return (iSample / T(12.92));
  return Math::elxPow( T((iSample+T(0.055))/T(1.055)), T(2.4));
}

//----------------------------------------------------------------------------
//  sRGB to RGB gamma correction thanks to Rec. ITU-R BT.709
//----------------------------------------------------------------------------
template<typename T>
inline 
T elxsRGBToRGB(T iSample)
{
  if (iSample <= T(0.0031308)) return (iSample * T(12.92));
  return (T(1.055) * Math::elxPow(iSample, T(1.0/2.4)) - T(0.055));
}

//----------------------------------------------------------------------------
//  explicit instanciations
//----------------------------------------------------------------------------

template<> PixelRGB<uint8 >::PixelRGB() {}
template<> PixelRGB<uint16>::PixelRGB() {}
template<> PixelRGB<int32   >::PixelRGB() {}
template<> PixelRGB<float >::PixelRGB() {}
template<> PixelRGB<double>::PixelRGB() {}

template<> PixelRGBA<uint8 >::PixelRGBA() {}
template<> PixelRGBA<uint16>::PixelRGBA() {}
template<> PixelRGBA<int32   >::PixelRGBA() {}
template<> PixelRGBA<float >::PixelRGBA() {}
template<> PixelRGBA<double>::PixelRGBA() {}

//--- PixelRGB ---------------------------------------------------------------
template PixelRGB<float>::PixelRGB(const PixelHLS<float>&);
template PixelRGB<float>::PixelRGB(const PixelXYZ<float>&);
template PixelRGB<float>::PixelRGB(const PixelLuv<float>&);
template PixelRGB<float>::PixelRGB(const PixelLab<float>&);
template PixelRGB<float>::PixelRGB(const PixelLch<float>&);
template PixelRGB<float>::PixelRGB(const PixelHLab<float>&);

template PixelRGB<double>::PixelRGB(const PixelHLS<double>&);
template PixelRGB<double>::PixelRGB(const PixelXYZ<double>&);
template PixelRGB<double>::PixelRGB(const PixelLuv<double>&);
template PixelRGB<double>::PixelRGB(const PixelLab<double>&);
template PixelRGB<double>::PixelRGB(const PixelLch<double>&);
template PixelRGB<double>::PixelRGB(const PixelHLab<double>&);

//--- GetLuminance -----------------------------------------------------------
template float  PixelRGB<float> ::GetLuminance(EColorToGreyConversion iMethod) const;
template double PixelRGB<double>::GetLuminance(EColorToGreyConversion iMethod) const;
template int64  PixelRGB<int64> ::GetLuminance(EColorToGreyConversion iMethod) const;

template float  PixelRGBA<float> ::GetLuminance(EColorToGreyConversion iMethod) const;
template double PixelRGBA<double>::GetLuminance(EColorToGreyConversion iMethod) const;
template int64  PixelRGBA<int64> ::GetLuminance(EColorToGreyConversion iMethod) const;

} // namespace Image
} // namespace eLynx

#endif // __ColorSpace_RGB_hpp__
