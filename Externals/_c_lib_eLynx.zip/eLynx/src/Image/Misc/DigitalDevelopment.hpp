//============================================================================
//  MiscProcessing/DigitalDevelopment.hpp              Image.Component package
//============================================================================
//  The DDP filter (Digital Development Processing) 
//  http://www.asahi-net.or.jp/~RT6K-OKN/its98/ddp1.htm
//
//  This is an algorithm developed by Dr Kunihiko Okano.  
//  It performs a combination stretching and unsharp masking to simulate the 
//  effect of photographic development on CCD images.
//
//  the DDP basic equation: 
//  Yij = k [ Xij / ({Xij} + a ) ] + b 
//
//  When you process the Red image Xij(red), use the mask from Blue image {Xij(blue)+ a}
//  Yij(red) = k [ Xij(red) / {Xij(blue)+ a} ) ] + b 
//
//  When we process the "Red image with blue mask", "Green image with red mask" and 
//  "Blue image with red mask", we call this process RGB/brr.
//
//  There are various combinations: RGB/bgr, RGB/ggg, RGB/sss, etc.
//  where s=R+G+B.
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __MiscProcessing_DigitalDevelopment_hpp__
#define __MiscProcessing_DigitalDevelopment_hpp__

#include <elx/image/ImageLocalProcessingImpl.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel> 
bool ImageMiscProcessingImpl<Pixel>::ApplyDigitalDevelopment(
    ImageImpl<Pixel>& ioImage,
    double iBackground, 
    double iCrossOver, 
    double iPower,
    double iVariance,
    EColorEmphasis iEmphasis,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{ 
  if (!ioImage.IsValid()) return false;

  typedef typename Pixel::type T;
  typedef typename Pixel::F_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
  const uint32 nChannel = Pixel::GetChannelCount();

  // create gaussian filtered image
  boost::shared_ptr< ImageImpl<Pixel> > spFiltered( new ImageImpl<Pixel>(ioImage) );
  ImageLocalProcessingImpl<Pixel>::ApplyGaussian(*spFiltered,
    3,3, iVariance, BF_Nearest, 1, CM_All);

  Pixel * prDst = ioImage.GetPixel();
  Pixel * prEnd = ioImage.GetPixelEnd();
  const Pixel * prFiltered = spFiltered->GetPixel();

  // Yij = k [ Xij / ({Xij} + a ) ] + b
  const F b = F(iBackground);
  const F a = F(iCrossOver);
  const F k = F(iPower);
  const double n = ResolutionTypeTraits<T>::_normScale;
  const double m = ResolutionTypeTraits<T>::_maxNormInDouble;
  F s,f,l;
  
  do 
  { 
    for (uint32 c=0; c<nChannel; c++)
      if (elxUseChannel(c, iChannelMask))
      {
        // normalized source
        s = F(n*prDst->_channel[c]);

        // normalized filtered
        f = F(n*prFiltered->_channel[c]);  

        // K. Okano equation
        // Yij = k [ Xij / ({Xij} + a ) ] + b
        l = k *( s / (f + a) ) + b;

        // save result
        prDst->_channel[c] = ResolutionTypeTraits<T>::Clamp(m*l);
      }
    prFiltered++;
  } 
  while (++prDst != prEnd);

  return true;

} // ApplyDigitalDevelopment

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from IImageMiscProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageMiscProcessingImpl<Pixel>::ApplyDigitalDevelopment(
    AbstractImage& ioImage,
    double iBackground, 
    double iCrossOver, 
    double iPower,
    double iVariance,
    EColorEmphasis iEmphasis,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ApplyDigitalDevelopment(image, iBackground, iCrossOver, iPower, iVariance, iEmphasis,
    iChannelMask, iNotifier);

} // ApplyDigitalDevelopment

} // namespace Image
} // namespace eLynx

#endif // __MiscProcessing_DigitalDevelopment_hpp__
