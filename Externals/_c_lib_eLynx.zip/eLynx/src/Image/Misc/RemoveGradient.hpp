//============================================================================
//  MiscProcessing/RemoveGradient.hpp                  Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __MiscProcessing_RemoveGradient_hpp__
#define __MiscProcessing_RemoveGradient_hpp__

#include <algorithm>
#include <boost/shared_ptr.hpp>

#include <elx/image/ImageRasterizationImpl.h>
#include <elx/image/ImageOperatorsImpl.h>
#include <elx/math/Bezier.h>

//#define USE_Quadratic

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel> 
boost::shared_ptr< ImageImpl<Pixel> > 
  elxLinearBackgroundGradient(
    const ImageImpl<Pixel>& iImage, 
    const Math::Point2iList& iPoints,
    uint32 iChannelMask, 
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid()) return boost::shared_ptr< ImageImpl<Pixel> >();

  // create an image with same size as input
  const uint32 h = iImage.GetHeight();
  const uint32 w = iImage.GetWidth();
  boost::shared_ptr< ImageImpl<Pixel> > spGradient( 
      new ImageImpl<Pixel>(w,h) );

  if (!elxUseable(spGradient.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();
    
  // build triangles list from selected points
  Math::TriangleIdxList triangles;
  if (!Math::elxTriangulate(iPoints, triangles))
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // build synthetised gradient
  int32 x0,y0, x1,y1, x2,y2;
  const size_t n = triangles.size();
  for (size_t i=0; i<n; i++)
  {
    Math::Point2i p0 = iPoints[ triangles[i]._P0 ];
    x0 = p0._x, y0 = p0._y;
    Pixel c0 = *iImage.GetPixel(x0, y0);

    Math::Point2i p1 = iPoints[ triangles[i]._P1 ];
    x1 = p1._x, y1 = p1._y;
    Pixel c1 = *iImage.GetPixel(x1, y1);

    Math::Point2i p2 = iPoints[ triangles[i]._P2 ];
    x2 = p2._x, y2 = p2._y;
    Pixel c2 = *iImage.GetPixel(x2, y2);

    ImageRasterizationImpl<Pixel>::DrawTriangle(*spGradient, 
        x0,y0,c0, x1,y1,c1, x2,y2,c2);
  }

  return spGradient;

} // elxLinearBackgroundGradient

#ifdef USE_Quadratic
namespace {

struct ComparePoint2i
{
  bool operator()(const Math::Point2i& iP0, const Math::Point2i& iP1) const
  {
    return Math::elxComparePoints(iP0, iP1);
  }
};

struct EqualPoint2i
{
  bool operator()(const Math::Point2i& iP0, const Math::Point2i& iP1) const
  {
    return Math::elxEqualPoints(iP0, iP1);
  }
};

#if 0
template<typename T>
class Pixel3
{
public:

  /// Constructor, does nothing.
  Pixel3() :  _x(), _y(), _z() {}
  Pixel3(T iX, T iY, T iZ) :  _x(iX), _y(iY), _z(iZ) {}
  template<typename U>
  Pixel3(U iX, U iY, U iZ) :  _x(iX), _y(iY), _z(iZ) {}
  bool operator==(const Pixel3& iPixel) const 
    { return _x==iPixel._x && _y==iPixel._y && _z==iPixel._z; }

public:
  T _x, _y, _z;
};

template <class Pixel>
inline
Pixel elxMakePixel(typename Pixel::type iValue)
{
  Pixel p;
  const uint32 count = Pixel::GetChannelCount();
  for (uint32 j = 0; j < count; ++j)
    p._channel[j] = iValue;
  return Pixel(p);
}

// Set of 3D control points for Clough-Tocher interpolation
// The first two dimensions represent location in 2D space 
// and the third dimension is the fuction value at that location. 
// The control point actually represents N control points where N 
// is the pixel's channel number. For X and Y dimensions all values 
// across different channels are set to the  pixel's X and Y coordinates
template <class Pixel>
struct ControlPoints
{
  Pixel3<Pixel> _v[3];    // domain triangles V points
  Pixel3<Pixel> _c[3];    // C points
  Pixel3<Pixel> _i[3][2]; // I points 
  Pixel3<Pixel> _t[3][2]; // T points 
  Pixel3<Pixel> _s;       // S point
};

// Calculates XY coordinates for a Control Point
template <class Pixel>
inline
void elxControlPointXY(
    const Pixel3<Pixel>& iCP1, 
    const Pixel3<Pixel>& iCP2, 
    const Pixel3<Pixel>& iCP3,
    Pixel3<Pixel>& oCP)
{
  oCP._x = (iCP1._x + iCP2._x + iCP3._x) / 3;
  oCP._y = (iCP1._y + iCP2._y + iCP3._y) / 3;
}
template <class Pixel>
inline
void elxControlPointXY(
    const Pixel3<Pixel>& iCP1, 
    const Pixel3<Pixel>& iCP2, 
    Pixel3<Pixel>& oCP)
{
  oCP._x = (2 * iCP1._x + iCP2._x) / 3;
  oCP._y = (2 * iCP1._y + iCP2._y) / 3;
}

// Calculates Z coordinate of the oPoint to set it coplanar with the plane 
// defined by the normal iNorm and point iPlaneP  
template <class Pixel>
inline
void elxPointOnPlane(
  const Pixel3<Pixel>& iNorm, 
  const Pixel3<Pixel>& iPlaneP, 
  Pixel3<Pixel>& oPoint)
{
  for (uint32 j = 0; j < Pixel::_channels; ++j)
  {
    typename Pixel::type d = iNorm._x._channel[j] * iPlaneP._x._channel[j] +
      iNorm._y._channel[j] * iPlaneP._y._channel[j] +
      iNorm._z._channel[j] * iPlaneP._z._channel[j];
      
    if(iNorm._z._channel[j] != 0)
      oPoint._z._channel[j] = (d - oPoint._x._channel[j] * iNorm._x._channel[j] -
        oPoint._y._channel[j] * iNorm._y._channel[j]) / iNorm._z._channel[j];
    else
      oPoint._z._channel[j] = 0;
  }
}

// Normalizes vector ioVector
template <class Pixel>
inline
void elxNormalize(Pixel3<Pixel>& ioVector)
{
  for (uint32 i = 0; i < Pixel::_channels; ++i)
  {
    typename Pixel::type norm = Math::elxSqrt(
      ioVector._x._channel[i]*ioVector._x._channel[i] + 
      ioVector._y._channel[i]*ioVector._y._channel[i] +
      ioVector._z._channel[i]*ioVector._z._channel[i]);
      
    BOOST_ASSERT(norm > 0);
    ioVector._x._channel[i] /= norm;
    ioVector._y._channel[i] /= norm;
    ioVector._z._channel[i] /= norm;
  }

} // elxNormalize

template <class Pixel>
inline
void elxCalculateVPoints(
  uint32 iTrIdx, 
  Math::TriangulationData& ioTData, 
  const Pixel* iPixels, 
  ControlPoints<Pixel>* oControlPoints)
{
  const Math::TriangulationData::Vertex* pVertex0 = &ioTData._vertices[0]; 
  Math::TriangulationData::Triangle& triangle = ioTData._triangles[iTrIdx];
  const uint32 idxV[3] = {triangle._vertex[0] - pVertex0,
                        triangle._vertex[1] - pVertex0,
                        triangle._vertex[2] - pVertex0};
  for (uint32 i = 0; i < 3; ++i)
  {
    oControlPoints[iTrIdx]._v[i]._x = 
      elxMakePixel<Pixel>(	
	    float(ioTData._vertices[idxV[i]]._position._x));
    oControlPoints[iTrIdx]._v[i]._y = 
      elxMakePixel<Pixel>(
		float(ioTData._vertices[idxV[i]]._position._y));
    oControlPoints[iTrIdx]._v[i]._z = iPixels[idxV[i]];
  }

} // elxCalculateVPoints

template <class Pixel>
void elxCalculateTPoints(
  uint32 iTrIdx, 
  Math::TriangulationData& ioTData,
  const Pixel* iPixels, 
  const Pixel3<Pixel>* iNormals,
  ControlPoints<Pixel>* ioControlPoints)
{    
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

  const Math::TriangulationData::Vertex* pVertex0 = &ioTData._vertices[0]; 
  Math::TriangulationData::Triangle& triangle = ioTData._triangles[iTrIdx];
  const uint32 idxV[3] = {triangle._vertex[0] - pVertex0,
                        triangle._vertex[1] - pVertex0,
                        triangle._vertex[2] - pVertex0};
  // Point Tij lies on the line 
  // which goes through point Vi and its directional vector Ui can be 
  // computed using two cross products: tmp = Ni x (Vj-Vi) and  Ui = tmp x Ni
  // where Ni is normal vector at Vi and (Vj-Vi) is directional vector of 
  // the edge.
  for (uint32 i = 0; i < 3; ++i)
  {
/*
    elxPointOnPlane(iNormals[idxV[i]], ioControlPoints[iTrIdx]._v[i],
      ioControlPoints[iTrIdx]._t[i][0]);
    elxPointOnPlane(iNormals[idxV[i]], ioControlPoints[iTrIdx]._v[i],
      ioControlPoints[iTrIdx]._t[i][1]);
*/
    for (uint32 k = 0; k < 2; ++k)
    {
      uint32 j = (i+1+k) % 3;
      Pixel3<Pixel> vectorV = Math::elxSubstructPoints(
        ioControlPoints[iTrIdx]._v[j], ioControlPoints[iTrIdx]._v[i]);
      Pixel3<Pixel> tmp = 
        Math::elxCrossProduct(iNormals[idxV[i]], vectorV);
                                 
      Pixel3<Pixel> vectorU = 
        Math::elxCrossProduct(tmp, iNormals[idxV[i]]);
      
      // Tij and Tji split ViVj in 3 equal segments
      const double scale = 3.0f / Math::elxSqrt(
        Math::elxSqr(
          triangle._vertex[i]->_position._x-triangle._vertex[j]->_position._x) +
        Math::elxSqr(
          triangle._vertex[i]->_position._y-triangle._vertex[j]->_position._y));
      elxNormalize(vectorU);
      ioControlPoints[iTrIdx]._t[i][k]._z = 
        ioControlPoints[iTrIdx]._v[i]._z + vectorU._z * float(scale);
    }
  }

} //elxCalculateTPoints

template <class Pixel>
inline
void elxCalculateI1Points(uint32 iTrIdx, Math::TriangulationData& ioTData,
  ControlPoints<Pixel>* ioControlPoints)
{  
  // Ii1 = (Vi + Tij + Tik)/3  
  for (uint32 i = 0; i < 3; ++i)
  {
    // _i[0][0] = I01, _i[0][1] = I02
    // _t[0][0] = T01, _t[0][1] = T02
    // _t[1][0] = T12, _t[1][1] = T10
    // _t[2][0] = T20, _t[2][1] = T21
    ioControlPoints[iTrIdx]._i[i][0]._z = 
    (ioControlPoints[iTrIdx]._v[i]._z + ioControlPoints[iTrIdx]._t[i][0]._z +
      ioControlPoints[iTrIdx]._t[i][1]._z) / 3;
  }

} //elxCalculateI1Points

template <class Pixel>
void elxCalculateCPoints(uint32 iTrIdx, Math::TriangulationData& ioTData,
  ControlPoints<Pixel>* ioControlPoints)
{  
  Math::TriangulationData::Triangle* pTriangle0 = &ioTData._triangles[0];
  Math::TriangulationData::Triangle& triangle = ioTData._triangles[iTrIdx];
  // Ci is a coplanar point with Tjk and Tkj and ^Ci or 
  // vector Ij1 - ^Ij1 + Ik1-^Ik1
  uint32 j,k; 
  Pixel3<Pixel> tmp, tmp1, norm;
  for (uint32 i = 0; i < 3; ++i)
  {
    // C0 = T12, T21, C1 = T20, T02, C2 = T01, T10
    // _t[0][0] = T01, _t[0][1] = T02
    // _t[1][0] = T12, _t[1][1] = T10
    // _t[2][0] = T20, _t[2][1] = T21
    j = (i+1)%3;
    k = (i+2)%3;
    Pixel3<Pixel>& Tjk = ioControlPoints[iTrIdx]._t[j][0];
    Pixel3<Pixel>& Tkj = ioControlPoints[iTrIdx]._t[k][1];

    Pixel3<Pixel>& Ij1 = ioControlPoints[iTrIdx]._i[j][0];
    Pixel3<Pixel>& Ik1 = ioControlPoints[iTrIdx]._i[k][0];    
    Pixel3<Pixel>& Ci = ioControlPoints[iTrIdx]._c[i];
    
    tmp = Math::elxAddPoints(Ij1, Ik1);
    //Edge index C0 - V1V2 -Edge 1
    //Edge index C1 - V0V2 -Edge 2
    //Edge index C2 - V0V1 -Edge 0
    Math::TriangulationData::Edge* pE = 
      ioTData._triangles[iTrIdx]._edge[(i+1)%3];
    if (pE->_triangle[1] != NULL)
    {
      uint32 edgeOtherTrIdx = 
        (pE->_triangle[0] == &ioTData._triangles[iTrIdx]) ? 1 : 0;
      Math::TriangulationData::Triangle* pT = pE->_triangle[edgeOtherTrIdx];
      uint32 otherJ = (pT->_vertex[0] == triangle._vertex[j])? 0 : 
                        (pT->_vertex[1] == triangle._vertex[j])? 1 : 2; 
      uint32 otherK = (pT->_vertex[0] == triangle._vertex[k])? 0 : 
                        (pT->_vertex[1] == triangle._vertex[k])? 1 : 2;
      uint32 otherTrIdx = pT - pTriangle0; 
      Pixel3<Pixel>& Ij1o = ioControlPoints[otherTrIdx]._i[otherJ][0];
      Pixel3<Pixel>& Ik1o = ioControlPoints[otherTrIdx]._i[otherK][0];
      
      tmp1 = Math::elxSubstructPoints(tmp, Ij1o);
      tmp = Math::elxSubstructPoints(tmp1, Ik1o);
    }
    else
    {
      // Since there is no other triangle meaning that the current one
      // is the boundary triangle let use Vj and Vk instead of ^Ij1 and ^Ik1
      tmp1 = Math::elxSubstructPoints(tmp, ioControlPoints[iTrIdx]._v[j]);
      tmp = Math::elxSubstructPoints(tmp1, ioControlPoints[iTrIdx]._v[k]);
    }
    
    tmp1 = Math::elxSubstructPoints(Tjk, Tkj);
    norm = Math::elxCrossProduct(tmp1, tmp);
    // Now norm is a normal to the Tjk, Tkj and ^Ci plane
    // Plane equation is PxNorm = D
    elxPointOnPlane(norm, Tjk, Ci); 
  }

} //elxCalculateCPoints


template <class Pixel>
void elxCalculateI2Points(uint32 iTrIdx, Math::TriangulationData& ioTData,
  ControlPoints<Pixel>* ioControlPoints)
{  
  // Ii2 to lie in the plane sponed by Cj, Ck and Ii1 
  uint32 j,k; 
  Pixel3<Pixel> tmp1, tmp2, tmp3, norm;
  for (uint32 i = 0; i < 3; ++i)
  {
    // _i[0][0] = I01, _i[0][1] = I02
    j = (i+1)%3;
    k = (i+2)%3;
    Pixel3<Pixel>& Cj = ioControlPoints[iTrIdx]._c[j];
    Pixel3<Pixel>& Ck = ioControlPoints[iTrIdx]._c[k];
    Pixel3<Pixel>& Ii1 = ioControlPoints[iTrIdx]._i[i][0];
    Pixel3<Pixel>& Ii2 = ioControlPoints[iTrIdx]._i[i][1];
    
    // Find a normal to a plane sponed by Ii1, Cj and Ck
    tmp1 = Math::elxSubstructPoints(Cj, Ii1);
    tmp2 = Math::elxSubstructPoints(Ck, Ii1);
    norm = Math::elxCrossProduct(tmp1, tmp2);
    
    elxPointOnPlane(norm, Ii1, Ii2);
  }

} //elxCalculateI2Points

template <class Pixel>
inline
void elxCalculateSPoint(uint32 iTrIdx, Math::TriangulationData& ioTData,
  ControlPoints<Pixel>* ioControlPoints)
{  
  // S = (I02 + I12 + I22) /3 
  Pixel3<Pixel>& S = ioControlPoints[iTrIdx]._s;
  Pixel3<Pixel>& I02 = ioControlPoints[iTrIdx]._i[0][1];
  Pixel3<Pixel>& I12 = ioControlPoints[iTrIdx]._i[1][1];
  Pixel3<Pixel>& I22 = ioControlPoints[iTrIdx]._i[2][1];
  S._z = (I02._z + I12._z + I22._z )/3;

} //elxCalculateSPoint

/*
// Following functions are used for interpolation byond the boundary edges
// does not work very well....
inline
Math::TriangulationData::Edge* elxGetTriangleEdge(const uint32 iTrIdx, 
  const Math::TriangulationData& iTData, uint32 iV0, uint32 iV1)
{
  const Math::TriangulationData::Triangle& triangle = iTData._triangles[iTrIdx];
  const Math::TriangulationData::Vertex* pv0 = triangle._vertex[iV0];
  const Math::TriangulationData::Vertex* pv1 = triangle._vertex[iV1];
  Math::TriangulationData::Edge* pe = NULL;
  for (uint32 i = 0; i < 3; ++i)
  {
    pe = triangle._edge[i];
    if ((pv0 == pe->_vertex[0] && pv1 == pe->_vertex[1]) ||
        (pv0 == pe->_vertex[1] && pv1 == pe->_vertex[0]))
      break;
  }
  return pe;
} //elxGetTriangleEdge

inline
bool elxIsImageEdgeXIntersect(
  const Math::Point2i& iVP0, const Math::Point2i& iVP1,
  const Math::Point2i& iIP0, const Math::Point2i& iIP1,
  Math::Point2i& oP)
{
  // oP must be between image's points iIP0 and iIP1 
  // and iVP1 must be between P and iVP0 - edge direction 
  if (Math::elxLineLineIntersect(iVP0, iVP1, iIP0, iIP1, oP))
  {
    if (oP._x >= iIP0._x && oP._x <= iIP1._x)
    {
      if ((iVP0._x <= iVP1._x && iVP1._x <= oP._x) || 
          (iVP0._x >= iVP1._x && iVP1._x >= oP._x))
        return true;
    }
  }
 return false;
} //elxIsImageEdgeXIntersect
inline
bool elxIsImageEdgeYIntersect(
  const Math::Point2i& iVP0, const Math::Point2i& iVP1,
  const Math::Point2i& iIP0, const Math::Point2i& iIP1,
  Math::Point2i& oP)
{
  // oP must be between image's points iIP0 and iIP1 
  // and iVP1 must be between P and iVP0 - edge direction 
  if (Math::elxLineLineIntersect(iVP0, iVP1, iIP0, iIP1, oP))
  {
    if (oP._y >= iIP0._y && oP._y <= iIP1._y)
    {
      if ((iVP0._y <= iVP1._y && iVP1._y <= oP._y) || 
          (iVP0._y >= iVP1._y && iVP1._y >= oP._y))
        return true;
    }
  }
 return false;
} //elxIsImageEdgeYIntersect

Math::Point2i elxGetImageEdgeIntersection(const uint32 iTrIdx, 
  const Math::TriangulationData& iTData, 
  const Math::Point2i& iVP0,const uint32 iV1, const uint32 iW, const uint32 iH)
{
  const Math::TriangulationData::Triangle& triangle = iTData._triangles[iTrIdx];
  const Math::TriangulationData::Vertex* pv1 = triangle._vertex[iV1];
 
  Math::Point2i vP1(int32(pv1->_position._x), int32(pv1->_position._y));
  Math::Point2i iP[4] = {
    Math::Point2i(0,0) , Math::Point2i(iW-1, 0), 
    Math::Point2i(0, iH-1), Math::Point2i(iW-1, iH-1)};
      
  // Find intersection points with image edges
  // P must be between iP0 and iP1 and vP1 must be between P and vP0 
  Math::Point2i p;
  if (elxIsImageEdgeXIntersect(iVP0, vP1, iP[0], iP[1], p))
    return p;
  if (elxIsImageEdgeXIntersect(iVP0, vP1, iP[2], iP[3], p))
    return p;
  if (elxIsImageEdgeYIntersect(iVP0, vP1, iP[0], iP[2], p))
    return p;
  if (elxIsImageEdgeYIntersect(iVP0, vP1, iP[1], iP[3], p))
    return p;
  // Shouldn't get there
  return p;
} //elxGetImageEdgeIntersection

*/
} // namespace

#endif USE_Quadratic

template <class Pixel> 
boost::shared_ptr< ImageImpl<Pixel> > elxCloughTocherBackgroundGradient(
  const ImageImpl<Pixel>& iImage, const Math::Point2iList& iPoints,
  uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
  
  // create an image with same size as input
  const uint32 h = iImage.GetHeight();
  const uint32 w = iImage.GetWidth();
  const uint32 pixelCount = iPoints.size();
  
  boost::shared_ptr< ImageImpl<Pixel> > spGradient( new ImageImpl<Pixel>(w,h) );
  if (!elxUseable(spGradient.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // build triangles list from selected points
  Math::TriangulationData triangulationData;
  if (!Math::elxTriangulate(iPoints, triangulationData))
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const uint32 tiangleCount = triangulationData._triangles.size();
//  const uint32 edgeCount = triangulationData._edges.size();
  
  boost::scoped_array<Pixel_F> spPixels(new Pixel_F[pixelCount]);
  boost::scoped_array<Pixel3<Pixel_F> > 
    spNormals(new Pixel3<Pixel_F>[pixelCount]);
  boost::scoped_array<int32> spCount (new int32[pixelCount]);
  boost::scoped_array<ControlPoints<Pixel_F> > 
    spControlPoints(new ControlPoints<Pixel_F>[tiangleCount]);
  if (spPixels.get() == NULL || spNormals.get() == NULL || 
      spCount.get() == NULL || spControlPoints.get() == NULL)
    return boost::shared_ptr< ImageImpl<Pixel> >();
    
  for (uint32 i = 0; i < pixelCount; ++i)
  {
    spPixels[i] = *iImage.GetPixel(iPoints[i]._x, iPoints[i]._y);
    spCount[i] = 0;
    spNormals[i]._x = spNormals[i]._y = spNormals[i]._z = Pixel_F();
  }
    
  // Calculate normals at each vertex as an average of triangle's normals
  uint32 idx[3];
  Math::TriangulationData::Vertex* pVertex0 = &triangulationData._vertices[0]; 
  Pixel3<Pixel_F> normal;
  for (uint32 i = 0; i < tiangleCount; ++i)
  {
    const Math::TriangulationData::Triangle& triangle = triangulationData._triangles[i];
    idx[0] = triangle._vertex[0] - pVertex0;
    idx[1] = triangle._vertex[1] - pVertex0;
    idx[2] = triangle._vertex[2] - pVertex0;
    BOOST_ASSERT(idx[0]<pixelCount && idx[1]<pixelCount && idx[2]<pixelCount);

    const Pixel_F x1 = elxMakePixel<Pixel_F>( F(triangle._vertex[1]->_position._x - triangle._vertex[0]->_position._x) );
    const Pixel_F y1 = elxMakePixel<Pixel_F>( F(triangle._vertex[1]->_position._y - triangle._vertex[0]->_position._y) );
    const Pixel_F x2 = elxMakePixel<Pixel_F>( F(triangle._vertex[2]->_position._x - triangle._vertex[0]->_position._x) );
    const Pixel_F y2 = elxMakePixel<Pixel_F>( F(triangle._vertex[2]->_position._y - triangle._vertex[0]->_position._y) );
    const Pixel_F p1 = spPixels[idx[1] ] - spPixels[idx[0] ];
    const Pixel_F p2 = spPixels[idx[2] ] - spPixels[idx[0] ];
    //(x1,y1,z1)*(x2,y2,z2) = ((y1*z2-z1*y2),-(x1*z2-z1*x2),(x1*y2-y1*x2))
    normal._x = y1*p2-p1*y2;
    normal._y = p1*x2-x1*p2;
    normal._z = x1*y2-y1*x2;
    
    // Accumulate normals
    for (uint32 j = 0; j < 3; ++j)
    {
      spNormals[idx[j] ]._x += normal._x;
      spNormals[idx[j] ]._y += normal._y;
      spNormals[idx[j] ]._z += normal._z;
      ++spCount[idx[j] ];
    }
  } 

  // Adjust normals  
  for (uint32 i=0; i<pixelCount; i++) 
  {
    BOOST_ASSERT(spCount[i] > 0);
	const F s = 1/F( spCount[i] );
    spNormals[i]._x *= s;
    spNormals[i]._y *= s;
    spNormals[i]._z *= s;
  }
  
  Math::TriangulationData::Triangle* pTr0 = &triangulationData._triangles[0]; 
  // Calculate control points
  for (uint32 i = 0; i < tiangleCount; ++i)
  {
    // 1. V points
    uint32 idx = &triangulationData._triangles[i] - pTr0;
    elxCalculateVPoints(
      idx, triangulationData, spPixels.get(), spControlPoints.get());
      
    // Now calculate X,Y coordinates for all control points
    // 2a. S point is (V0+V1+V2)/3
    elxControlPointXY(spControlPoints[i]._v[0], spControlPoints[i]._v[1],
      spControlPoints[i]._v[2], spControlPoints[i]._s);
    // 2b. Calculate the rest of them using three micro-triangles V0-V1-S,...
    // _i[0][0] = I01, _i[0][1] = I02
    // _t[0][0] = T01, _t[0][1] = T02
    // _t[1][0] = T12, _t[1][1] = T10
    // _t[2][0] = T20, _t[2][1] = T21
    for (uint32 j = 0; j <3; ++j)
    {
      // Tjk = (2*Vj + Vk) / 3; Tkj = (2*Vk + Vj) / 3
      uint32 k = (j + 1)% 3;
      elxControlPointXY(spControlPoints[i]._v[j], spControlPoints[i]._v[k],
         spControlPoints[i]._t[j][0]);   
      elxControlPointXY(spControlPoints[i]._v[k], spControlPoints[i]._v[j],
         spControlPoints[i]._t[k][1]);  
      // Ij1 = (2*Vj + S) / 3; Ij2 = (2*S + Vj) / 3 
      elxControlPointXY(spControlPoints[i]._v[j], spControlPoints[i]._s,
         spControlPoints[i]._i[j][0]);   
      elxControlPointXY(spControlPoints[i]._s, spControlPoints[i]._v[j],
         spControlPoints[i]._i[j][1]);   
      // C point is (Vj+Vk+S)/3
      elxControlPointXY(spControlPoints[i]._v[j], spControlPoints[i]._v[k],
        spControlPoints[i]._s, spControlPoints[i]._c[3-j-k]);
    } 
    
    // 3. T points. Set Tij to lie in targent plane at Vi.
    elxCalculateTPoints(idx, triangulationData,
      spPixels.get(), spNormals.get(), spControlPoints.get());
      
    // 4. Ii1 points
    elxCalculateI1Points(idx, triangulationData, spControlPoints.get());
  }
  
  for (uint32 i = 0; i < tiangleCount; ++i)
  {
    uint32 idx = &triangulationData._triangles[i] - pTr0;
    // 5. C points
    elxCalculateCPoints(idx, triangulationData, spControlPoints.get());
    
    // 6. Ii2 points
    elxCalculateI2Points(idx, triangulationData, spControlPoints.get());

    // 7. S points
    elxCalculateSPoint(idx, triangulationData, spControlPoints.get());
  }
    
  // build synthetised gradient
  for (uint32 i = 0; i < tiangleCount; ++i)
  {
//    uint32 idx = &triangulationData._triangles[i] - pTr0;
    
    // _i[0][0] = I01, _i[0][1] = I02
    // _t[0][0] = T01, _t[0][1] = T02
    // _t[1][0] = T12, _t[1][1] = T10
    // _t[2][0] = T20, _t[2][1] = T21
    for (uint32 j = 0; j < 3; ++j)
    {
      uint32 k = (j+1)%3;
      
      Math::BezierTriangle3<F, Pixel_F> bezier(
        spControlPoints[i]._v[j]._x._channel[0],
        spControlPoints[i]._v[j]._y._channel[0],
        spControlPoints[i]._v[k]._x._channel[0],
        spControlPoints[i]._v[k]._y._channel[0],
        spControlPoints[i]._s._x._channel[0],
        spControlPoints[i]._s._y._channel[0]);
    
      bezier._cp[0] = spControlPoints[i]._v[j];
      bezier._cp[1] = spControlPoints[i]._v[k];
      bezier._cp[2] = spControlPoints[i]._s;
      bezier._cp[3] = spControlPoints[i]._t[j][0];
      bezier._cp[4] = spControlPoints[i]._t[k][1];
      bezier._cp[5] = spControlPoints[i]._i[k][0];
      bezier._cp[6] = spControlPoints[i]._i[k][1];
      bezier._cp[7] = spControlPoints[i]._i[j][1];
      bezier._cp[8] = spControlPoints[i]._i[j][0];
      bezier._cp[9] = spControlPoints[i]._c[3-j-k];        
 
      // Three points defining sub-triangle
      // There is a problem with Render class. If vertecies have fractional part
      // not equal to 0 (i.e 4.55) then there would be gaps (black lines) between 
      // adjacent triangles
      Math::Point2i sPoint (
        int32(Math::elxRound(spControlPoints[i]._s._x._channel[0])),
        int32(Math::elxRound(spControlPoints[i]._s._y._channel[0])));
      Math::Point2i vPoint[2] = {
        Math::Point2i(
          int32(Math::elxRound(spControlPoints[i]._v[j]._x._channel[0])),
          int32(Math::elxRound(spControlPoints[i]._v[j]._y._channel[0]))),
        Math::Point2i ( 
          int32(Math::elxRound(spControlPoints[i]._v[k]._x._channel[0])),
          int32(Math::elxRound(spControlPoints[i]._v[k]._y._channel[0])))};
      
      ImageRasterizationImpl<Pixel>::DrawTriangle(*spGradient, 
        vPoint[0]._x, vPoint[0]._y, vPoint[1]._x, vPoint[1]._y, 
        sPoint._x, sPoint._y, bezier, iChannelMask);
/*     
     // Is it a boundary edge?
      Math::TriangulationData::Edge* pEdge = 
        elxGetTriangleEdge(idx, triangulationData, j, k);
      bool isBoundary = (pEdge->_triangle[1] == NULL) ? true : false;
      // If it is boundary edge do other two edges intersect the same image
      // edge. If they do then we will extend the domain triangle to that edge.
        
      if (isBoundary)
      {
        // iPoint are points of intersection S-Vj and S-Vk edges with
        // image boundaries 
        Math::Point2i iPoint[2];
        iPoint[0] = 
          elxGetImageEdgeIntersection(idx, triangulationData, sPoint, j, w, h);
        iPoint[1] = 
          elxGetImageEdgeIntersection(idx, triangulationData, sPoint, k, w, h);
          
        const int32 iw = int32(w);
        const int32 ih = int32(h);
        Math::Point2i cPoint[4] = {
          Math::Point2i(0,0), Math::Point2i(iw-1,0),
          Math::Point2i(iw-1,ih-1), Math::Point2i(0,ih-1) };

         
        const Pixel* vPixel[2] = { iImage.GetPixel(vPoint[0]._x, vPoint[0]._y),
                                   iImage.GetPixel(vPoint[1]._x, vPoint[1]._y)};
        // Draw area between vPixel and iPixel points          
        ImageRasterizationImpl<Pixel>::DrawTriangle(*spGradient, 
          vPoint[0]._x, vPoint[0]._y, *vPixel[0], 
          vPoint[1]._x, vPoint[1]._y, *vPixel[1],
          iPoint[0]._x, iPoint[0]._y, *vPixel[0], iChannelMask);
        ImageRasterizationImpl<Pixel>::DrawTriangle(*spGradient, 
          iPoint[0]._x, iPoint[0]._y, *vPixel[0],
          iPoint[1]._x, iPoint[1]._y, *vPixel[1], 
          vPoint[1]._x, vPoint[1]._y, *vPixel[1], iChannelMask);
        
        if (Math::elxAbs(iPoint[0]._x - iPoint[1]._x) == iw-1)
        {
          // Two image conners in between: 0,0 and w,0 or 0,h and w,h
          uint32 idx = (iPoint[0]._x == 0)? 0 : 1;

          Math::Point2i intersection;
          Math::elxLineLineIntersect(
            sPoint._x, sPoint._y, iPoint[idx]._x, iPoint[idx]._y,
            iw, 0, iw, ih, intersection._x, intersection._y);
          const bool isTop = (intersection._y > iPoint[1-idx]._y);
          Math::Point2i& c0Point = (isTop) ? cPoint[0] : cPoint[3];
          Math::Point2i& c1Point = (isTop) ? cPoint[1] : cPoint[2];
          ImageRasterizationImpl<Pixel>::DrawTriangle(*spGradient, 
            iPoint[idx]._x, iPoint[idx]._y, *vPixel[idx],
            iPoint[1-idx]._x, iPoint[1-idx]._y, *vPixel[1-idx],
            c0Point._x, c0Point._y, *vPixel[idx], iChannelMask);
          ImageRasterizationImpl<Pixel>::DrawTriangle(*spGradient, 
            iPoint[1-idx]._x, iPoint[1-idx]._y, *vPixel[1-idx],
            c1Point._x, c1Point._y, *vPixel[1-idx], 
            c0Point._x, c0Point._y, *vPixel[idx], iChannelMask);

        }
        else if (Math::elxAbs(iPoint[0]._y - iPoint[1]._y) == ih-1)
        {
           // Two image conners in between: 0,0 and 0,h or w,0 and w,h
          uint32 idx = (iPoint[0]._y == 0)? 0 : 1;
          Math::Point2i intersection;
          Math::elxLineLineIntersect(
            sPoint._x, sPoint._y, iPoint[idx]._x, iPoint[idx]._y,
              0, ih, iw, ih, intersection._x, intersection._y);
          bool isLeft = (intersection._x > iPoint[1-idx]._x);

          Math::Point2i& c0Point = (isLeft) ? cPoint[0] : cPoint[1];
          Math::Point2i& c1Point = (isLeft) ? cPoint[3] : cPoint[2];
          ImageRasterizationImpl<Pixel>::DrawTriangle(*spGradient, 
            iPoint[idx]._x, iPoint[idx]._y, *vPixel[idx],
            iPoint[1-idx]._x, iPoint[1-idx]._y, *vPixel[1-idx],
            c0Point._x, c0Point._y, *vPixel[idx], iChannelMask);
          ImageRasterizationImpl<Pixel>::DrawTriangle(*spGradient, 
            iPoint[1-idx]._x, iPoint[1-idx]._y, *vPixel[1-idx],
            c1Point._x, c1Point._y, *vPixel[1-idx], 
            c0Point._x, c0Point._y, *vPixel[idx], iChannelMask);

        }
        else
        {
          // One image conner in between
          uint32 idx = (iPoint[0]._x == 0 || iPoint[1]._x == 0) ?
            ((Math::elxMin(iPoint[0]._y, iPoint[1]._y) == 0) ? 0 : 3 ) : 
            ((Math::elxMin(iPoint[0]._y, iPoint[1]._y) == 0) ? 1 : 2 );
          ImageRasterizationImpl<Pixel>::DrawTriangle(*spGradient, 
            iPoint[0]._x, iPoint[0]._y, *vPixel[0], 
            iPoint[1]._x, iPoint[1]._y, *vPixel[1], 
            cPoint[idx]._x, cPoint[idx]._y, *vPixel[0], iChannelMask);
        } 
      } // boundary point  
*/    
    } // vertex loop 
  } // triangle loop
  
  return  spGradient; 

} // elxCloughTocherBackgroundGradient
#endif // USE_Quadratic

//----------------------------------------------------------------------------
//  RemoveGradient
//----------------------------------------------------------------------------
template <class Pixel> 
bool ImageMiscProcessingImpl<Pixel>::RemoveGradient(
    ImageImpl<Pixel>& ioImage, 
    ImageImpl<Pixel>& oBackground,
    const Math::Point2iList& iPoints, 
    EGradientMethod iMethod,
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  // remove duplicate points if any
  Math::Point2iList points(iPoints.begin(), iPoints.end());
#if 0
  std::sort(points.begin(), points.end(), ComparePoint2i());
  points.erase(
    std::unique(points.begin(), points.end(), EqualPoint2i()), 
    points.end());
#endif

  // build synthetised gradient from selected background points
  boost::shared_ptr< ImageImpl<Pixel> > spBackground;
  switch (iMethod)
  {
    case GM_Linear: spBackground =
      elxLinearBackgroundGradient(ioImage, points, iChannelMask, iNotifier);
      break;
#ifdef USE_Quadratic
    case GM_Quadratic: spBackground =
      elxCloughTocherBackgroundGradient(ioImage, points, iChannelMask, iNotifier);
      break;
#endif
    default:
      return false;
  }

  // remove gradient from original
  if (spBackground.get() != NULL)
  {
    elxOperator(ioImage, IOP_SubClamp, *spBackground, iChannelMask);
    oBackground.CopyAndForget(spBackground);
    return true;
  }
  return false;

} // RemoveGradient


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from IImageMiscProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageMiscProcessingImpl<Pixel>::RemoveGradient(
    AbstractImage& ioImage, 
    AbstractImage& oBackground,
    const Math::Point2iList& iPoints, 
    EGradientMethod iMethod,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  if (iPoints.empty())
    return false;
    
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  ImageImpl<Pixel>& background = elxDowncast<Pixel>(oBackground);
  return RemoveGradient(
    image, background, iPoints, iMethod, iChannelMask, iNotifier);

} // RemoveGradient

} // namespace Image
} // namespace eLynx

#endif // __MiscProcessing_RemoveGradient_hpp__
