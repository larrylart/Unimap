//============================================================================
//  Misc/RotationalGradient.hpp�                    ���Image.Component package
//============================================================================ 
//  Refers to " The LARSON-SEKANINA filter"
//  http://users.libero.it/mnico/comets/ls.htm
//============================================================================ 
//� Copyright (C) 2007 by eLynx project
//
//� This library is free software; you can redistribute it and/or
//� modify it under the terms of the GNU Library General Public
//� License as published by the Free Software Foundation; either 
//� version 2 of the License, or (at your option) any later version.
//
//� This library is distributed in the hope that it will be useful,
//� but WITHOUT ANY WARRANTY; without even the implied warranty of
//� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//� See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Misc_RotationalGradient_hpp__
#define __Misc_RotationalGradient_hpp__

#include <elx/math/MathCore.h>

namespace eLynx {
namespace Image { 

namespace {

static const double elxROTATE_EPSILON = 1e-10;

template <typename T>
inline
void elxComputeDistance(const int32 iX0, const int32 iX1, const int32 iY0, 
  const int32 iY1, const T iX, const T iY, T* oW)
{
  static const T one = T(1);
  static const T zero = T(0);
  
  oW[0] = (iX - iX0)*(iX - iX0) + (iY - iY0)*(iY - iY0);
  if (oW[0] < elxROTATE_EPSILON)
  {
    oW[0] = one; oW[1]=oW[2]=oW[3]= zero;
  }
  else
  {
    oW[1] = (iX - iX1)*(iX - iX1) + (iY - iY0)*(iY - iY0);
    if (oW[1] < elxROTATE_EPSILON)
    {
      oW[1] = one; oW[0]=oW[2]=oW[3]= zero;
    }
    else
    {
      oW[2] = (iX - iX1)*(iX - iX1) + (iY - iY1)*(iY - iY1);
      if (oW[2] < elxROTATE_EPSILON)
      {
        oW[2] = one; oW[0]=oW[1]=oW[3]= zero;
      }
      else
      {
        oW[3] = (iX - iX0)*(iX - iX0) + (iY - iY1)*(iY - iY1);
        if (oW[3] < elxROTATE_EPSILON)
        {
          oW[3] = one; oW[0]=oW[1]=oW[2]= zero;
        }
        else
        {
          oW[0] = one / Math::elxSqrt(oW[0]);
          oW[1] = one / Math::elxSqrt(oW[1]);
          oW[2] = one / Math::elxSqrt(oW[2]);
          oW[3] = one / Math::elxSqrt(oW[3]);
        }
      }
    }
  }
}

} //namespace

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//������������������� static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//----------------------------------------------------------------------------
//�ApplyRotationalGradient: 
//----------------------------------------------------------------------------
//� public static
//----------------------------------------------------------------------------
//� In� : ImageImpl<Pixel>& ioImage: image to process
//������� ProgressNotifier& iNotifier : default is 0
//� Out : bool 
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageMiscProcessingImpl<Pixel>::ApplyRotationalGradient(
    ImageImpl<Pixel>& ioImage,
    uint32 iX, uint32 iY,
    double iRadialShift, double iRotationalShift, bool ibInterpolation, 
    uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
    
  typedef Pixel Pixel_t;
  typedef typename Pixel_t::type T; 
  typedef typename Pixel_t::F_type F;
     
  const Pixel_t blank = Pixel_t::Black();
  const uint32 nChannel = Pixel_t::GetChannelCount();
  const int32 w = (int32)ioImage.GetWidth();
  const int32 h = (int32)ioImage.GetHeight();
  if (int32(iX) >= w || int32(iY) >= h)
    return false;

  const F Xc = F(iX);
  const F Yc = F(iY);
  const F RadialShift = (F)iRadialShift;
  const F RadiansShift = (F)Math::elxDeg2Rad(iRotationalShift);

  // create output image, ISO resolution, with same dimensions
  boost::shared_ptr< ImageImpl<Pixel> > 
    spImage( new ImageImpl<Pixel>(w, h) );
  if (!elxUseable(spImage.get())) 
    return false;
     
  // --- inits progress ---
  const float ProgressStep = 1.0f / (float)h;
  float Progress = 0.0f;
  iNotifier.SetProgress(Progress);

  // --- inits variables ---
  Pixel_t * prSrc = ioImage.GetPixel();
  Pixel_t * prDst = spImage->GetPixel();

  uint32 c;
  int32 x,y, x0,y0, x1,y1, x2,y2, x3,y3;
  F dx,dy,dy2, x1d,y1d, x2d,y2d;
  F radius, theta, l,l1,l2, w1[4], w2[4];
  bool bP1Out,bP2Out;
  bool bX0Out,bX1Out,bX2Out,bX3Out, bY0Out,bY1Out,bY2Out,bY3Out;

  // --- process all lines ---
  for (y=0; y<h; y++)
  {
    dy = Yc - F(y);
    dy2 = dy*dy;

    // --- process a line ---
    for (x=0; x<w; x++, ++prDst)
    {
      dx = F(x) - Xc;
      radius = Math::elxSqrt(dx*dx + dy2) + RadialShift;
      if (dx != F(0))
        theta = (dx >= 0) ? Math::elxArctan(dy/dx) : F(M_PI) + Math::elxArctan(dy/dx);
      else 
        theta = F((dy > 0) ? M_PIo2 : -M_PIo2);

      x1d = Xc + radius * Math::elxCos(theta + RadiansShift);
      y1d = Yc - radius * Math::elxSin(theta + RadiansShift);
      x2d = Xc + radius * Math::elxCos(theta - RadiansShift);
      y2d = Yc - radius * Math::elxSin(theta - RadiansShift);

      if (ibInterpolation)
      {
        x0 = Math::elxRint( Math::elxFloor(x1d) );
        y0 = Math::elxRint( Math::elxFloor(y1d) );
        x1 = Math::elxRint( Math::elxCeil(x1d) );
        y1 = Math::elxRint( Math::elxCeil(y1d) );
        elxComputeDistance(x0, x1, y0, y1,  x1d, y1d, w1);
        
        x2 = Math::elxRint( Math::elxFloor(x2d) );
        y2 = Math::elxRint( Math::elxFloor(y2d) );
        x3 = Math::elxRint( Math::elxCeil(x2d) );
        y3 = Math::elxRint( Math::elxCeil(y2d) );
        elxComputeDistance(x2, x3, y2, y3, x2d, y2d, w2);

        bX0Out = x0<0 || x0>=w;   bY0Out = y0<0 || y0>=h;
        bX1Out = x1<0 || x1>=w;   bY1Out = y1<0 || y1>=h;
        bX2Out = x2<0 || x2>=w;   bY2Out = y2<0 || y2>=h;
        bX3Out = x3<0 || x3>=w;   bY3Out = y3<0 || y3>=h;

        for (c=0; c<nChannel; c++)
        {
          l  = (F)prSrc[y*w + x]._channel[c];

          l1 =  (bX0Out || bY0Out)? F(0): w1[0]*F(prSrc[y0*w + x0]._channel[c]);
          l1 += (bX1Out || bY0Out)? F(0): w1[1]*F(prSrc[y0*w + x1]._channel[c]);
          l1 += (bX0Out || bY1Out)? F(0): w1[2]*F(prSrc[y1*w + x1]._channel[c]);
          l1 += (bX1Out || bY1Out)? F(0): w1[3]*F(prSrc[y1*w + x0]._channel[c]);

          l2 =  (bX2Out || bY2Out)? F(0): w2[0]*F(prSrc[y2*w + x2]._channel[c]);
          l2 += (bX3Out || bY2Out)? F(0): w2[1]*F(prSrc[y2*w + x3]._channel[c]);
          l2 += (bX2Out || bY3Out)? F(0): w2[2]*F(prSrc[y3*w + x3]._channel[c]);
          l2 += (bX3Out || bY3Out)? F(0): w2[3]*F(prSrc[y3*w + x2]._channel[c]);

          l = Math::elxAbs(2*l - l1/(w1[0]+w1[1]+w1[2]+w1[3]) -
            l2/(w2[0]+w2[1]+w2[2]+w2[3]));
          prDst->_channel[c] = ResolutionTypeTraits<T>::ClampF(l);
        }
      }
      else
      {
        x1 = Math::elxRint(x1d);
        y1 = Math::elxRint(y1d);
        bP1Out = x1 < 0 || x1 >= w || y1 < 0 || y1 >= h;

        x2 = Math::elxRint(x2d);
        y2 = Math::elxRint(y2d);
        bP2Out = x2 < 0 || x2 >= w || y2 < 0 || y2 >= h;

        for (c=0; c<nChannel; c++)
        {
          l =  (F)prSrc[y *w + x ]._channel[c];
          l1 = bP1Out ? F(0) : (F)prSrc[y1*w + x1]._channel[c];
          l2 = bP2Out ? F(0) : (F)prSrc[y2*w + x2]._channel[c];

          l = Math::elxAbs(2*l - l1 - l2);
          prDst->_channel[c] = ResolutionTypeTraits<T>::ClampF(l);
        }
      }
    } 

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // --- progress end ---
  iNotifier.SetProgress(Progress);
  return ioImage.CopyAndForget(spImage);

} // ApplyRotationalGradient

//----------------------------------------------------------------------------
// Specialization for pixel's types where filter does not make sense. 
//                            NOT_IMPLEMENTED 
//----------------------------------------------------------------------------
#ifdef elxUSE_ImageComplex
template <>
bool ImageMiscProcessingImpl< PixelComplexi >::ApplyRotationalGradient(
    ImageImpl< PixelComplexi >&,    
    uint32, uint32, double, double, bool, uint32, ProgressNotifier&)
{ return false; }

template <> 
bool ImageMiscProcessingImpl< PixelComplexf >::ApplyRotationalGradient(
    ImageImpl< PixelComplexf >&, 
    uint32, uint32, double, double, bool, uint32, ProgressNotifier&) 
{ return false; }

template <> 
bool ImageMiscProcessingImpl< PixelComplexd >::ApplyRotationalGradient(
    ImageImpl<PixelComplexd>&,
    uint32, uint32, double, double, bool, uint32, ProgressNotifier&) 
{ return false; }
#endif

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageMisc implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ApplyRotationalGradient: 
//----------------------------------------------------------------------------
//  public virtual from IImageMiscProcessing
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage: image to process
//        ProgressNotifier& iNotifier : default is 0
//  Out : bool 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageMiscProcessingImpl<Pixel>::ApplyRotationalGradient(
			AbstractImage& ioImage,
      uint32 iX, uint32 iY,
      double iR, double iDegrees, bool ibInterpolation, 
      uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return ApplyRotationalGradient(image, iX, iY, iR, iDegrees, ibInterpolation,
    iChannelMask, iNotifier);

} // ApplyRotationalGradient

} // namespace Image
} // namespace eLynx

#endif // __Misc_RotationalGradient_hpp__
