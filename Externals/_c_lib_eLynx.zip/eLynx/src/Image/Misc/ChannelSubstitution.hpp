//============================================================================
//  MiscProcessing/ChannelSubstitution.hpp             Image.Component package
//============================================================================
//  [Y] multicore optimization
//  [Y] LUT type optimization
//  [Y] channel mask
//  [Y] progression notifier
//  [N] cancellation while processing
//----------------------------------------------------------------------------
//  The Channel Substitution 
//
//  http://www.astropix.com/HTML/J_DIGIT/CHANSUB.HTM
//
// There are four different ways to composite and blend high resolution black and 
// white images with color images :
//  1.  L'ab - Substituting the b&w for the L channel in a Lab color image.
//      The original RGB color image is converted from RGB color to Lab color. 
//      The separate black and white exposure is then cut and pasted into the L 
//      channel of the Lab color image in the channels palette. 
//      The image is then converted back to RGB color.
//  2.  LRGB - Blending the b&w luminance layer in a RGB color image.
//      The original separate black and white exposure is pasted into the RGB color 
//      image as a layer. The blending method for the layer is changed to Luminance.
//  3.  HSL - Substituting the luminance channel in HSL color.
//      The original RGB color image is converted in Photoshop from RGB color to HSL color.
//      The separate black and white exposure is then cut and pasted into the B channel 
//      in the channels palette. The image is then converted back to RGB color.
//  4.  HSB - Substituting the brightness channel in HSB color.
//      The original RGB color image is converted in Photoshop from RGB color to HSB color.
//      The separate black and white exposure is then cut and pasted into the B channel in
//      the channels palette. The image is then converted back to RGB color.
//----------------------------------------------------------------------------
//  Copyright (C) 2009 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __MiscProcessing_ChannelSubstitution_hpp__
#define __MiscProcessing_ChannelSubstitution_hpp__
/*
#include <elx/image/ImageGeometryImpl.h>
#include <elx/image/ImageAnalyseImpl.h>
#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    task for multicore optimization
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template <typename Pixel, EChannelSubstitution Substitution>
struct CSMProcessorTask : public IterationRangeTask
{
  typedef typename Pixel::type T;
  typedef typename Pixel::F_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
  
  CSMProcessorTask(
      Pixel * iprColor, 
      Pixel * iprColorEnd, 
      const Pixel * iprGray,
      const double * iprColorMax, 
      const double * iprGrayMax, 
      double iBlendScalar,
      ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _prColor(iprColor), 
    _prGray(iprGray), 
    _Substitution(),
    _prColorMax(iprColorMax), 
    _prGrayMax(iprGrayMax), 
    _BlendScalar(iBlendScalar)
  {}
  
  // Split constructor
  CSMProcessorTask(
      const CSMProcessorTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prColor(iOther._prColor), 
    _prGray(iOther._prGray), 
    _Substitution(),
    _prColorMax(iOther._prColorMax), 
    _prGrayMax(iOther._prGrayMax),
    _BlendScalar(iOther._BlendScalar)
  {}
    
  uint32 operator()()
  {
    Pixel * prColor = _prColor + _begin;
    Pixel * prColorEnd = _prColor + _end;
    const Pixel * prGray = _prGray + _begin;
    
    for (; prColor != prColorEnd; ++prGray, ++prColor) 
    { 
      // convert to F resolution
      Pixel_F fColor = *prColor;
      Pixel_F fGray  = *prGray;
      
      // Enhance pixel
      Pixel_F fPixelE = ConvertPixel(fColor, fGray, _Substitution);
      
      // Convert back to PixelF
      elxPixelClamp(fPixelE, *prColor);
    } 
    return elxOK;
  }
  
  Pixel_F ConvertPixel(Pixel_F& ifColor, Pixel_F& ifGray, 
    const IntToType<CSM_Lab>) const
  {
    const uint32 channelCount = Pixel::GetChannelCount();
    // Normalize
    for (uint32 c = 0; c < channelCount; ++c)
    {
      ifColor._channel[c] /= F(_prColorMax[c]);
      ifGray._channel[c] /= F(_prGrayMax[c]);
    }
    // Convert  to Lab
    PixelLab<F> fColorLab(ifColor);
    PixelLab<F> fGreyLab(ifGray);

     // Replace L channel with the high resolution one
    fColorLab._luminance = fGreyLab._luminance;

    // Convert back to PixelF
    Pixel_F fColor(fColorLab);
    for (uint32 c = 0; c < channelCount; ++c)
      fColor._channel[c] *=  F(_prColorMax[c]);
    return fColor;
  }
  
  Pixel_F ConvertPixel(Pixel_F& ifColor, Pixel_F& ifGray, 
    const IntToType<CSM_HLS>)
  {
    // Convert  to HLS
    PixelHLS<F> fColorHLS(ifColor);
    PixelHLS<F> fGreyHLS(ifGray);

     // Replace L channel with the high resolution one
    fColorHLS._luminance = fGreyHLS._luminance;

    // Convert back to PixelF
    return Pixel_F (fColorHLS);
  }
  
  Pixel_F ConvertPixel(Pixel_F& ifColor, Pixel_F& ifGray, 
    const IntToType<CSM_LRGB>)
  {
    // Blend L and RGB pixels
    return elxPixelBlend(ifColor, ifGray, _BlendScalar);
  }

private:  
  Pixel * _prColor;
  const Pixel * _prGray;
  const IntToType<Substitution> _Substitution;
  const double * _prColorMax;
  const double * _prGrayMax;
  const double _BlendScalar;

}; // CSMProcessorTask

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel> 
boost::shared_ptr<AbstractImage> 
  ImageMiscProcessingImpl<Pixel>::ApplyChannelSubstitution(
    const ImageImpl<Pixel>& iHighResGrayImage,
    const ImageImpl<Pixel>& iLowResColorImage, 
    EChannelSubstitution iSubstitution, 
    double iBlendScalar,
    ProgressNotifier& iNotifier)
{ 
  if (!iHighResGrayImage.IsValid() || !iLowResColorImage.IsValid()) 
    return boost::shared_ptr<AbstractImage>();

  // resize Color image to match the B&W one size
  boost::shared_ptr<ImageImpl<Pixel> > spColorImage = 
    ImageGeometryImpl<Pixel>::CreateResized(
      iLowResColorImage, iHighResGrayImage.GetWidth(), 
      iHighResGrayImage.GetHeight(), iNotifier);
  if (NULL == spColorImage.get())
    return boost::shared_ptr<AbstractImage>();
    
  Pixel * prColor = spColorImage->GetPixel();
  Pixel * prColorEnd = spColorImage->GetPixelEnd();
  const Pixel * prGray = iHighResGrayImage.GetPixel();
  
  const uint32 h = iHighResGrayImage.GetHeight();
  const uint32 w = iHighResGrayImage.GetWidth();
  size_t minRangeSize = 10000;
  
  IterationRange range(0, size_t(w*h), 1, minRangeSize);
  uint32 status = elxOK;
  switch (iSubstitution)
  {
    case CSM_Lab:
    {
      // Compute image max per channel to normalise them
      double grayMin[PC_MAX];
      double grayMax[PC_MAX]; 
      double colorMin[PC_MAX];
      double colorMax[PC_MAX];

      if (!ImageAnalyseImpl<Pixel>::ComputeMinMax(
          iHighResGrayImage, grayMin, grayMax, false))
        return boost::shared_ptr<AbstractImage>(); 

      if (!ImageAnalyseImpl<Pixel>::ComputeMinMax(
          iLowResColorImage, colorMin, colorMax, false))
        return boost::shared_ptr<AbstractImage>(); 

      CSMProcessorTask<Pixel, CSM_Lab> task(prColor, prColorEnd, prGray,
          colorMax, grayMax, iBlendScalar, iNotifier);
      status = elxParallelFor(range, task);
      break;
    }
    case CSM_HLS:
    {
      CSMProcessorTask<Pixel, CSM_HLS> task(prColor, prColorEnd, prGray,
        NULL, NULL, iBlendScalar, iNotifier);
      status = elxParallelFor(range, task);
      break;
    }
    case CSM_LRGB:
    {
      CSMProcessorTask<Pixel, CSM_LRGB> task(prColor, prColorEnd, prGray,
        NULL, NULL, iBlendScalar, iNotifier);
      status = elxParallelFor(range, task);
      break;
    }
    case CSM_HSB:
    default:
      status = elxErrInvalidParams;
  }
  
  return (elxOK == status) ? 
    spColorImage : boost::shared_ptr<AbstractImage>();

} // ApplyChannelSubstitution

#ifdef elxUSE_ImageComplex
template <>
boost::shared_ptr<AbstractImage> 
  ImageMiscProcessingImpl<PixelComplexi>::ApplyChannelSubstitution(
    const ImageImpl<PixelComplexi>&, const ImageImpl<PixelComplexi>&, 
    EChannelSubstitution, double, ProgressNotifier& )
{ return boost::shared_ptr<AbstractImage>(); }

template <>
boost::shared_ptr<AbstractImage> 
  ImageMiscProcessingImpl<PixelComplexf>::ApplyChannelSubstitution(
    const ImageImpl<PixelComplexf>&, const ImageImpl<PixelComplexf>&, 
    EChannelSubstitution, double, ProgressNotifier&)
{ return boost::shared_ptr<AbstractImage>(); }

template <>
boost::shared_ptr<AbstractImage> 
  ImageMiscProcessingImpl<PixelComplexd>::ApplyChannelSubstitution(
    const ImageImpl<PixelComplexd>&, const ImageImpl<PixelComplexd>&, 
    EChannelSubstitution, double, ProgressNotifier&)
{ return boost::shared_ptr<AbstractImage>(); }
#endif

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from IImageMiscProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
boost::shared_ptr<AbstractImage> 
  ImageMiscProcessingImpl<Pixel>::ApplyChannelSubstitution(
    const AbstractImage& iHighResGrayImage,
    const AbstractImage& iLowResColorImage, 
    EChannelSubstitution iSubstitution, 
    double iBlendScalar,
    ProgressNotifier& iNotifier) const
{
  typedef typename Pixel::type T;
  const ImageImpl<Pixel>& grayImage = elxDowncast<Pixel>(iHighResGrayImage);
  const ImageImpl<Pixel>& colorImage = elxDowncast<Pixel>(iLowResColorImage);
  return ApplyChannelSubstitution(grayImage, colorImage, iSubstitution, 
          iBlendScalar, iNotifier);

} // ApplyChannelSubstitution


} // namespace Image
} // namespace eLynx
*/
#endif // __MiscProcessing_ChannelSubstitution_hpp__
