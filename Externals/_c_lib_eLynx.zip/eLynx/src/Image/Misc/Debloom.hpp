//============================================================================
//  MiscProcessing/Debloom.hpp                         Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __MiscProcessing_Debloom_hpp__
#define __MiscProcessing_Debloom_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel> 
bool ImageMiscProcessingImpl<Pixel>::Debloom(
  ImageImpl<Pixel>& ioImage,
  uint32 iChannelMask, ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) 
    return false;
/*
  typedef typename Pixel::type T;
//  typedef typename Pixel::F_type F;
//  typedef typename Pixel::FloatingPixel Pixel_F;
//  const FloatToType< ResolutionTypeTraits<T>::_bFloated > doClamp;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();

  // compute max value
  double localMax;
  ImageAnalyseImpl<Pixel>::ComputeMax(ioImage, localMax, true);

  // create a image mask of potentially impacted regions using threshold
  const T Threshold = T(0.9 * localMax * ResolutionTypeTraits<T>::_max);

  // allocate binary map image
  boost::shared_ptr< ImageLub > spBinary ( new ImageLub(w,h) );
  uint8 * prBin = spBinary->GetSamples();
  
  T * prSample = ioImage.GetSamples();
  T * prEnd = ioImage.GetSamplesEnd();
  do
  {
//    *prBin++ = (*prSample > Threshold) ? 255 : 0;
    *prSample = (*prSample > Threshold) ? 255 : 0;
  }
  while (++prSample != prEnd);

//  uint32 x,y;
//  Pixel * prSrc, * prDst;
  */
  return true;

} // Debloom


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//          virtual from IImageMiscProcessingImpl implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageMiscProcessingImpl<Pixel>::Debloom(
    AbstractImage& ioImage,
    uint32 iChannelMask, ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Debloom(image, iChannelMask, iNotifier);

} // Debloom

} // namespace Image
} // namespace eLynx

#endif // __MiscProcessing_Debloom_hpp__
