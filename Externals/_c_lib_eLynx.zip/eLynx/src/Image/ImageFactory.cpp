//============================================================================
//  ImageFactory.cpp                                   Image.Component package
//============================================================================
//  Usage : Tools to create high level synthetized images
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include "elx/image/ImageFactory.h"
#include "elx/image/ImageVariant.h"

namespace eLynx {
namespace Image {

namespace {

//----------------------------------------------------------------------------
//                          Parameters settings
//----------------------------------------------------------------------------
ParameterEnumItemList s_resolutionEnumList;
static ParameterEnum s_resolutionParameter("Resolution", 0, s_resolutionEnumList);

ParameterEnumItemList s_LensFlareTypeEnumList;
static ParameterEnum s_LensFlareTypeParameter("Type", 0, s_LensFlareTypeEnumList);

static ParameterInteger s_widthParameter ("Width",  1, 8000, 256, 100, 4, "%4.0lf");
static ParameterInteger s_heightParameter("Height", 1, 8000, 256, 100, 4, "%4.0lf");
static ParameterInteger s_SeedParameter("Seed", 0, 9999, 0, 100, 4, "%4.0lf");

static ParameterDouble s_VarianceParameter("Variance", 0.01, 10., 2., 100, 3, "%2.2lf");
static ParameterDouble s_CutoffParameter("Cutoff", 0.01, 1., 0.5, 100, 3, "%1.2lf");
static ParameterDouble s_RotationParameter("Degrees", 0., 360., 180., 100, 4, "%3.1lf");
static ParameterDouble s_RotationRParameter("Red  ", 0., 360., 120., 100, 4, "%3.1lf");
static ParameterDouble s_RotationGParameter("Green", 0., 360.,   0., 100, 4, "%3.1lf");
static ParameterDouble s_RotationBParameter("Blue ", 0., 360., 240., 100, 4, "%3.1lf");
static ParameterDouble s_PowerParameter("Power", 0., 1., 0.5, 100, 3, "%1.2lf");
/*
static ParameterDouble s_LuminanceParameter("L*", 0., 100., 90., 100, 4, "%3.1lf");
static ParameterDouble s_RotationAsParameter("a*", 0., 120., 30., 100, 4, "%3.1lf");
static ParameterDouble s_RotationBsParameter("b*", 0., 120., 90., 100, 4, "%3.1lf");
*/

} // namespace

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                              ImageFactoryBase
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
class ImageFactoryBase
{
public:
  ImageFactoryBase(EImageFactoryType iType) { _type = iType; }
  virtual ~ImageFactoryBase() {}

  EImageFactoryType GetType() const { return _type; }
  void GetParameters(ParameterList& oParameters) { oParameters = _parameters; }
  void Reset() 
  { 
    size_t nParameters = _parameters.size();
    for (size_t i=0; i<nParameters; i++)
      _parameters[i]->Reset();
  }

  virtual const char * GetName() const = 0;
  virtual bool BuildImage(ImageVariant& ioImage) = 0;

protected:
  EImageFactoryType _type;
  ParameterList _parameters;
};

} // namespace Image
} // namespace eLynx

#define USE_ImageFactoryHighLevel

#include "Factory/Checker.hpp"
#include "Factory/Gradient.hpp"
#include "Factory/Noise.hpp"
#include "Factory/Square.hpp"
#include "Factory/Circle.hpp"
#include "Factory/Gaussian.hpp"
#include "Factory/Butterworth.hpp"
#include "Factory/Plate.hpp"
#include "Factory/Bands.hpp"
#include "Factory/ColorWheel.hpp"
#include "Factory/Blend.hpp"
#include "Factory/Plasma.hpp"
#include "Factory/Cellular.hpp"
#include "Factory/Julia.hpp"
#include "Factory/Moivre.hpp"
#include "Factory/LensFlare.hpp"
#include "Factory/Galaxy.hpp"
#include "Factory/Liquid.hpp"
#include "Factory/Perlin.hpp"
#include "Factory/Hearts.hpp"
#include "Factory/GradientWheel.hpp"
//#include "Factory/LabGradient.hpp"

#undef USE_ImageFactoryHighLevel

namespace eLynx {
namespace Image {
 
//----------------------------------------------------------------------------
//  Empty image factory
//----------------------------------------------------------------------------
class EmptyFactory : public ImageFactoryBase
{
public:
  EmptyFactory() : ImageFactoryBase(IFT_Empty),
    _resolution(s_resolutionParameter),
    _width(s_widthParameter),
    _height(s_heightParameter)
  {
    _parameters.push_back(&_resolution);
    _parameters.push_back(&_width);
    _parameters.push_back(&_height);
  }

  virtual const char * GetName() const { return "Empty"; }
  virtual bool BuildImage(ImageVariant& ioImage)
  {
    EResolution resolution = (EResolution)_resolution.GetValue();
    uint32 w = (uint32)_width.GetValue();
    uint32 h = (uint32)_height.GetValue();
    ImageVariant image(PF_Lub, w, h);
    image.ChangeResolution(resolution);
    ioImage = image;
    return true;
  }

protected:
  ParameterEnum    _resolution;
  ParameterInteger _width;
  ParameterInteger _height;
};


//----------------------------------------------------------------------------
//  elxInitImageFactories
//----------------------------------------------------------------------------
static ImageFactoryBase * s_ImageFactories[IFT_MAX];

void elxInitImageFactories()
{
  static bool ms_bFirstTime = true; 
  if (!ms_bFirstTime) return;
  ms_bFirstTime = false;

  // resolution enum
  s_resolutionEnumList.push_back( ParameterEnumItem("8 bits per channel", RT_UINT8) );
  s_resolutionEnumList.push_back( ParameterEnumItem("16 bits per channel", RT_UINT16) );
  s_resolutionEnumList.push_back( ParameterEnumItem("32 bits per channel, integer", RT_INT32) );
  s_resolutionEnumList.push_back( ParameterEnumItem("32 bits per channel, float", RT_Float) );
  s_resolutionEnumList.push_back( ParameterEnumItem("64 bits per channel, float", RT_Double) );

  // lens flare type enum
  s_LensFlareTypeEnumList.push_back( ParameterEnumItem("Basic 1", 0) );
  s_LensFlareTypeEnumList.push_back( ParameterEnumItem("Inverted", 2) );
  s_LensFlareTypeEnumList.push_back( ParameterEnumItem("Thin ring", 3) );
  s_LensFlareTypeEnumList.push_back( ParameterEnumItem("Large ring", 1) );
  s_LensFlareTypeEnumList.push_back( ParameterEnumItem("Circle", 4) );
  s_LensFlareTypeEnumList.push_back( ParameterEnumItem("Bubble", 5) );
  s_LensFlareTypeEnumList.push_back( ParameterEnumItem("Basic 2", 6) );

  // ---
  static EmptyFactory ms_Empty;
  s_ImageFactories[IFT_Empty] = &ms_Empty;

  static CheckerFactory ms_Checker;
  s_ImageFactories[IFT_Checker] = &ms_Checker;

  static GradientFactory ms_Gradient;
  s_ImageFactories[IFT_Gradient] = &ms_Gradient;

  static MoivreFactory ms_Moivre;
  s_ImageFactories[IFT_Moivre] = &ms_Moivre;

  static NoiseFactory ms_Noise;
  s_ImageFactories[IFT_Noise] = &ms_Noise;


  static PerlinFactory ms_Perlin;
  s_ImageFactories[IFT_Perlin] = &ms_Perlin;

  static LiquidFactory ms_Liquid;
  s_ImageFactories[IFT_Liquid] = &ms_Liquid;

  // ---
  static SquareFactory ms_Square;
  s_ImageFactories[IFT_Square] = &ms_Square;

  static CircleFactory ms_Circle;
  s_ImageFactories[IFT_Circle] = &ms_Circle;

  static GaussianFactory ms_Gaussian;
  s_ImageFactories[IFT_Gaussian] = &ms_Gaussian;

  static ButterworthFactory ms_Butterworth;
  s_ImageFactories[IFT_Butterworth] = &ms_Butterworth;

  static LensFlareFactory ms_LensFlare;
  s_ImageFactories[IFT_LensFlare] = &ms_LensFlare;

  static PlateFactory ms_Plate;
  s_ImageFactories[IFT_Plate] = &ms_Plate;

  static GradientWheelFactory ms_GradientWheel;
  s_ImageFactories[IFT_GradientWheel] = &ms_GradientWheel;

  // ---
  static BandsFactory ms_Bands;
  s_ImageFactories[IFT_Bands] = &ms_Bands;

  static ColorWheelFactory ms_ColorWheel;
  s_ImageFactories[IFT_ColorWheel] = &ms_ColorWheel;

  static BlendFactory ms_Blend;
  s_ImageFactories[IFT_Blend] = &ms_Blend;

  static PlasmaFactory ms_Plasma;
  s_ImageFactories[IFT_Plasma] = &ms_Plasma;

  static CellularFactory ms_Cellular;
  s_ImageFactories[IFT_Cellular] = &ms_Cellular;

  static JuliaFactory ms_Julia;
  s_ImageFactories[IFT_Julia] = &ms_Julia;

  static GalaxyFactory ms_Galaxy;
  s_ImageFactories[IFT_Galaxy] = &ms_Galaxy;

  static HeartsFactory ms_Hearts;
  s_ImageFactories[IFT_Hearts] = &ms_Hearts;

/*
  static LabGradientFactory ms_LabGradient;
  s_ImageFactories[IFT_LabGradient] = &ms_LabGradient;
*/

// @TODO
/*
  http://www.cubic.org/docs/marble.htm

 http://en.wikipedia.org/wiki/Fractal
 Speckle pattern
 Line moir�: http://en.wikipedia.org/wiki/Line_moir%C3%A9
 http://en.wikipedia.org/wiki/Test_card

Peter de Jong Map : http://en.wikipedia.org/wiki/Fyre
x' = sin(a * y) - cos(b * x)
y' = sin(c * x) - cos(d * y)
*/

} // elxInitImageFactories


//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EImageFactoryType iType)
{
  elxInitImageFactories();
  return s_ImageFactories[iType]->GetName();

} // elxToString # EImageFactoryType


//----------------------------------------------------------------------------
//  elxGetParameterList
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
void elxGetParameterList(EImageFactoryType iType, ParameterList& oParameters)
{
  elxInitImageFactories();
  s_ImageFactories[iType]->GetParameters(oParameters);

} // elxGetParameterList


//----------------------------------------------------------------------------
//  elxReset
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
void elxReset(EImageFactoryType iType) 
{
  elxInitImageFactories();
  s_ImageFactories[iType]->Reset();

} // elxReset


//----------------------------------------------------------------------------
// elxImageFactory
//----------------------------------------------------------------------------
bool elxImageFactory(ImageVariant& ioImage, EImageFactoryType iType)
{
  elxInitImageFactories();
  return s_ImageFactories[iType]->BuildImage(ioImage);

} // elxImageFactory


} // namespace Image
} // namespace eLynx
