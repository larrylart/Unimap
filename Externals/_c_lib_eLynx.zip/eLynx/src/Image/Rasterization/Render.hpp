//============================================================================
//  Rasterization/Render.hpp�                       ���Image.Component package
//============================================================================ 
//  Draw a triangle into an image
//============================================================================ 
//� Copyright (C) 2007 by eLynx project
//
//� This library is free software; you can redistribute it and/or
//� modify it under the terms of the GNU Library General Public
//� License as published by the Free Software Foundation; either 
//� version 2 of the License, or (at your option) any later version.
//
//� This library is distributed in the hope that it will be useful,
//� but WITHOUT ANY WARRANTY; without even the implied warranty of
//� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//� See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Rasterization_Render_hpp__
#define __Rasterization_Render_hpp__

#include <elx/math/MathCore.h>
#include <elx/math/Geometry.h>
#include <elx/math/Bezier.h>

namespace eLynx {
namespace Image { 

namespace { 

// --- Draw Primitive Flags ---
enum
{
  DPF_Mode3D        = 0x80000000, // 2D = 0, 3D = 1
  DPF_All2dClipIn   = 0x40000000, // all vextex inside 2d clipping zone
  DPF_All2dClipOut  = 0x20000000, // all vextex outside 2d clipping zone

  DPF_Gouraud       = 0x00000001, // Shading : 0= Flat, 1= Gouraud
  DPF_Textured      = 0x00000002, // Texture : 0= Off,  1= On
  DPF_Fogged        = 0x00000004, // Fogged  : 0= Off,  1= On
  DPF_Bezier        = 0x00000008
};

// --- Shading Types ---
enum ShadingType
{
  SHD_Flat        = 0,
  SHD_FlatTex     = DPF_Textured,
  SHD_Gouraud     = DPF_Gouraud,
  SHD_GouraudTex  = DPF_Gouraud + DPF_Textured,
  SHD_Bezier      = DPF_Bezier
};

template <typename Pixel> 
struct Vertex2d
{
  Vertex2d(double iX, double iY) : _x(iX), _y(iY) {}

  Vertex2d(double iX, double iY, const Pixel& iColor) :
    _x(iX), _y(iY), _u(0), _v(0), _Color(iColor) {}

  Vertex2d(double iX, double iY, double iU, double iV) :
    _x(iX), _y(iY), _u(iU), _v(iV) {}

  Vertex2d(double iX, double iY, double iU, double iV, const Pixel& iColor) :
    _x(iX), _y(iY), _u(iU), _v(iV), _Color(iColor) {}

  double _x,_y;   // 2d position
  double _u,_v;   // Texture mapping
  Pixel  _Color;  // vextex color
};

// --- definition ---
struct DrawPrimitive
{
protected:
  uint32 _Flags;  // Internal
	
  // --- global access
  uint32 GetFlags() const       { return _Flags; }
  void SetFlags(uint32 iFlags)  { _Flags = iFlags; }

  // --- bit access
  bool HasFlag(uint32 iFlag) const       { return ((_Flags & iFlag) != 0); }
  void SetFlag(uint32 iFlag)             { _Flags |= iFlag; }
  void UnsetFlag(uint32 iFlag)           { _Flags &= ~iFlag; }
  void SetFlag(uint32 iFlag, bool ibYes) { ibYes ? SetFlag(iFlag) : UnsetFlag(iFlag); }

public:
  DrawPrimitive(const ShadingType iShading=SHD_Flat) : _Flags(iShading) {}

  // --- 3DPrimitive
  bool Is2D() const { return !Is3D(); }
  bool Is3D() const { return HasFlag(DPF_Mode3D); }

  // --- All2dClipIn
  bool IsAll2dClipIn() const            { return HasFlag(DPF_All2dClipIn); }
  void SetAll2dClipIn(bool ibYes=true)  { SetFlag(DPF_All2dClipIn, ibYes); }

  // --- All2dClipOut
  bool IsAll2dClipOut() const           { return HasFlag(DPF_All2dClipOut); }
  void SetAll2dClipOut(bool ibYes=true) { SetFlag(DPF_All2dClipOut, ibYes); }

  // --- Shading ---
  bool IsGouraud() const                { return HasFlag(DPF_Gouraud); }
  bool IsFlat() const                   { return !HasFlag(DPF_Gouraud); }
  void SetGouraud()                     { SetFlag(DPF_Gouraud); }
  void SetFlat()                        { UnsetFlag(DPF_Gouraud); }

  // --- Textured ---
  bool IsTextured() const               { return HasFlag(DPF_Textured); }
  void SetTextured()                    { SetFlag(DPF_Textured); }

  // --- Fogged ---
  bool IsFogged() const                 { return HasFlag(DPF_Fogged); }
  void SetFogged()                      { SetFlag(DPF_Fogged); }

  // ---Bezier---
  bool IsBezier() const                 { return HasFlag(DPF_Bezier); }
  void SetBezier()                      { SetFlag(DPF_Bezier); }
};

//============================================================================ 
//                                  Triangle2DP
//============================================================================ 
template <typename Pixel> 
struct Triangle2DP : public DrawPrimitive
{
  typedef typename ResolutionTypeTraits<typename Pixel::type>::Floating_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
  
  Triangle2DP(ShadingType iShading=SHD_Flat) : 
    DrawPrimitive(iShading) {}

  Triangle2DP(
      const Vertex2d<Pixel>& iV0, 
      const Vertex2d<Pixel>& iV1,
      const Vertex2d<Pixel>& iV2,
      ShadingType iShading=SHD_Flat) : 
    DrawPrimitive(iShading),
    _v0(iV0), _v1(iV1), _v2(iV2)/*, _pBezier(NULL) */{}
/*
  Triangle2DP(
      const Vertex2d<Pixel>& iV0, 
      const Vertex2d<Pixel>& iV1,
      const Vertex2d<Pixel>& iV2,
      Math::BezierTriangle3<F, Pixel_F>& iBezier) : 
    DrawPrimitive(SHD_Bezier),
    _v0(iV0), _v1(iV1), _v2(iV2), _pBezier(&iBezier) {}
*/
  Vertex2d<Pixel> _v0,_v1,_v2;
//  Math::BezierTriangle3<F, Pixel_F>* _pBezier;
};

//============================================================================ 
//                                  Quad2DP
//============================================================================ 
template <typename Pixel> 
struct Quad2DP : public DrawPrimitive
{
  Quad2DP(ShadingType iShading=SHD_Flat) : DrawPrimitive(iShading) {}
  Quad2DP(
      const Vertex2d<Pixel>& iV0, 
      const Vertex2d<Pixel>& iV1,
      const Vertex2d<Pixel>& iV2,
      const Vertex2d<Pixel>& iV3,
      ShadingType iShading=SHD_Flat) : 
    DrawPrimitive(iShading),
    _v0(iV0), _v1(iV1), _v2(iV2), _v3(iV3) {}

  Vertex2d<Pixel> _v0,_v1,_v2,_v3;
};


//============================================================================ 
//                                  Gradient2d
//============================================================================ 
template <typename Pixel> 
struct Gradient2d
{
  typedef typename Pixel::type T;

  Gradient2d() {}
  bool Init(
    const Vertex2d<Pixel>& iV0, 
    const Vertex2d<Pixel>& iV1, 
    const Vertex2d<Pixel>& iV2, 
    bool ibFlat=false,
    bool ibTexture=false)
  {
    _bFlat = ibFlat;
    _bTexture = ibTexture;

    _xRef = iV0._x;
    _yRef = iV0._y;
    const double dx01 = iV1._x - _xRef;
    const double dy01 = iV1._y - _yRef;
    const double dx02 = iV2._x - _xRef;
    const double dy02 = iV2._y - _yRef;

    // Is it a triangle?
    const double dp = dx02 * dy01 - dx01 * dy02;
    if (dp == 0) return false;

    const double oneOdpx = 1 / dp;
    const double oneOdpy = -oneOdpx;

    if (!ibFlat)
    {
      // gouraud
      const Pixel c0 = iV0._Color;
      const Pixel c1 = iV1._Color;
      const Pixel c2 = iV2._Color;

      const uint32 nChannel = Pixel::GetChannelCount();
      for (uint32 c=0; c<nChannel; c++)
      {
        const T l0 = c0._channel[c];
        const double dl01 = double(c1._channel[c] - l0);
        const double dl02 = double(c2._channel[c] - l0);
        _L[c] = l0;
        _dLOdx[c] = (dl02 * dy01 - dl01 * dy02) * oneOdpx;
        _dLOdy[c] = (dl02 * dx01 - dl01 * dx02) * oneOdpy;
      }
    }

    // texture
    if (ibTexture)
    {
      // u
      _u = iV0._u;
      const double du01 = iV1._u - iV0._u;
      const double du02 = iV2._u - iV0._u;
      _duOdx = (du02 * dy01 - du01 * dy02) * oneOdpx;
      _duOdy = (du02 * dx01 - du01 * dx02) * oneOdpy;

      // v
      _v = iV0._v;
      const double dv01 = iV1._v - iV0._v;
      const double dv02 = iV2._v - iV0._v;
      _dvOdx = (dv02 * dy01 - dv01 * dy02) * oneOdpx;
      _dvOdy = (dv02 * dx01 - dv01 * dx02) * oneOdpy;
    }
    return true;
  }

  bool _bFlat, _bTexture;
  
  // reference
  double _xRef,_yRef;

  // pixel interpolation
  double _L[4], _dLOdx[4], _dLOdy[4];

  // texture mapping
  double _u, _duOdx, _duOdy;
  double _v, _dvOdx, _dvOdy;
};

//============================================================================ 
//                                  Edge2d
//============================================================================ 
template <typename Pixel>
struct Edge2d
{
  Edge2d() {}
  void Init(Math::Point2d& iBottom, Math::Point2d& iTop, Gradient2d<Pixel>& iGradient)
  {
    _y = int32(Math::elxFloor(iBottom._y));
    _h = int32(Math::elxCeil(iTop._y)) - _y;

    const double Width  = iTop._x - iBottom._x;
    const double Height = iTop._y - iBottom._y;
    _dxOdy = Width/Height;
    _x = iBottom._x + (iBottom._y - _y)*_dxOdy;

    const double xe = _x - iGradient._xRef;
    const double ye = _y - iGradient._yRef;

    _bFlat = iGradient._bFlat;
    if (!_bFlat)
    {
      const uint32 nChannel = Pixel::GetChannelCount();
      for (uint32 c=0; c<nChannel; c++)
      {
        _L[c] = iGradient._L[c] + ye*iGradient._dLOdy[c] + xe*iGradient._dLOdx[c];
        _dLOdy[c] = iGradient._dLOdy[c] + _dxOdy*iGradient._dLOdx[c];
      }
    }

    _bTexture = iGradient._bTexture;
    if (_bTexture)
    {
      // u
      _u = iGradient._u + ye*iGradient._duOdy + xe*iGradient._duOdx;
      _duOdy = iGradient._duOdy + _dxOdy*iGradient._duOdx;

      // v
      _v = iGradient._v + ye*iGradient._dvOdy + xe*iGradient._dvOdx;
      _dvOdy = iGradient._dvOdy + _dxOdy*iGradient._dvOdx;
    }
  }

  void StepY()
  {
    _x += _dxOdy;
    _y++;
    _h--;
    
    if (!_bFlat)
    {
      const uint32 nChannel = Pixel::GetChannelCount();
      for (uint32 c=0; c<nChannel; c++)
        _L[c] += _dLOdy[c];
    }

    if (_bTexture)
    {
      _u += _duOdy;	
      _v += _dvOdy;
    }
  }

  bool _bFlat, _bTexture;
  int32 _y,_h;                // y and h

  // pixel interplolation
  double _x, _dxOdy;        // x and dx/dy
  double _L[4], _dLOdy[4];  // L and y step

  // texture
  double _u, _duOdy;        // u and y step
  double _v, _dvOdy;        // v and y step
};


//============================================================================ 
//                                  Render
//============================================================================ 
template <typename Pixel> 
class Render
{
  typedef typename Pixel::type T;
  typedef typename Pixel::F_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
  const IntegerToType< ResolutionTypeTraits<T>::_bInteger > _doClamp;

public:
  Render(const ImageImpl<Pixel>& iImage);
  Render(ImageImpl<Pixel>& ioImage);
  Render(int32 iWidth, int32 iHeight, Pixel * iprBitmap);
  ~Render();

  Pixel Pick(int32 iX, int32 iY);
  bool Clear(const Pixel& iPixel, uint32 iChannelMask=CM_All);
  bool Plot(int32 iX, int32 iY, const Pixel& iPixel, uint32 iChannelMask=CM_All);
  bool DrawHLine(int32 iY, int32 iX1, int32 iX2, const Pixel& iPixel, uint32 iChannelMask=CM_All);
  bool DrawLine(int32 iX1, int32 iY1, int32 iX2, int32 iY2, const Pixel& iPixel, uint32 iChannelMask=CM_All);
  bool DrawLineAA(int32 iX1, int32 iY1, int32 iX2, int32 iY2, const Pixel& iPixel, uint32 iChannelMask=CM_All);
  bool DrawRectangle(int32 iX1, int32 iY1, int32 iX2, int32 iY2, const Pixel& iPixel, bool ibSolid=false, uint32 iChannelMask=CM_All);
  bool DrawEllipse(int32 iX, int32 iY, uint32 iRadiusX, uint32 iRadiusY, const Pixel& iPixel, bool ibSolid=false, uint32 iChannelMask=CM_All);
  bool DrawTriangle(int32 iX0, int32 iY0, int32 iX1, int32 iY1, int32 iX2, int32 iY2, const Pixel& iPixel, bool ibSolid=false, uint32 iChannelMask=CM_All);

  void Draw(Triangle2DP<Pixel>& iTriangle, uint32 iChannelMask=CM_All);

  void SetTexture(const ImageImpl<Pixel>& iTexture, uint32 iFlags=0);

  bool Fill(int32 iX, int32 iY, const Pixel& iPixel, uint32 iChannelMask=CM_All);
  bool GetFilledBBox(int32 iX, int32 iY, Math::AOBBox2i& oBBox) const;
private:
  // useless default methods intentionally not accessible (and not generated)
  Render();
  Render(const Render&);
  Render& operator=(const Render&);
  Render * operator&();
  const Render * operator&() const;

protected:
  // drawing surface
  int32 _width, _height;
  Pixel *_prBitmap;
  const Pixel *_prConstBitmap;

  // 2D clipping with Sutherlan-Hogman algorithm
  enum
  { 
    ClipNone    = 0,
    ClipLeft    = 1,
    ClipUp      = 2,
    ClipRight   = 4,
    ClipDown    = 8,
    ClipMaxEdges= 7 // there is 3+4 edges maximum
  };

  bool PreClip2d(Triangle2DP<Pixel>& iTriangle);
  bool PreClip2d(Quad2DP<Pixel>& iQuad);
  bool AreInsideAllLeft(uint32 iCount);
  bool AreInsideAllUp(uint32 iCount);
  bool AreInsideAllRight(uint32 iCount);
  bool AreInsideAllDown(uint32 iCount);
  void Intersect(int32 iClip, int32 iP0, int32 iP1);
  void Clip2d(int32 iClip);
  void Clip2d();
  void ComputeEdges(Math::Point2d * iprPoint, int32 iCount);

  // define clip zone
  int32 _xwMin, _ywMin;	// in window coordinates
  int32 _xwMax, _ywMax;
  double _xMin, _yMin;
  double _xMax, _yMax;

  int32 _InCount, _OutCount;
  int32 _LeftEdgesCount, _RightEdgesCount;
  bool  _bInIsInside[ClipMaxEdges];
  Math::Point2d _PointIn[ClipMaxEdges], _PointOut[ClipMaxEdges];
  Edge2d<Pixel>   _LeftEdges[ClipMaxEdges], _RightEdges[ClipMaxEdges];

  // Gradient
  Gradient2d<Pixel> _Gradient;
  Pixel _FlatColor;

  // Texture
  uint32  _TexFlags;
  int32   _TexWidth;
  int32   _TexHeight;
  const Pixel * _prTexBitmap;
  
  // Bezier
  const Math::BezierTriangle3<F, Pixel_F>* _pBezier;

  // Rendering funtions
  enum FragmentType { FT_Flat = 0, FT_FlatTex, FT_Gouraud, FT_GouraudTex,
                      FT_Bezier };
  void DrawPolygon(FragmentType iFragment, uint32 iChannelMask=CM_All);

  void DrawFragment_Flat(      Edge2d<Pixel>& iLeft, Edge2d<Pixel>& iRight);
  void DrawFragment_FlatTex(   Edge2d<Pixel>& iLeft, Edge2d<Pixel>& iRight);
  void DrawFragment_Gouraud(   Edge2d<Pixel>& iLeft, Edge2d<Pixel>& iRight);
  void DrawFragment_GouraudTex(Edge2d<Pixel>& iLeft, Edge2d<Pixel>& iRight);
  void DrawFragment_Bezier(    Edge2d<Pixel>& iLeft, Edge2d<Pixel>& iRight);

  typedef void (Render::*fnDrawFragment)(Edge2d<Pixel>& iLeft, Edge2d<Pixel>& iRight);
  static fnDrawFragment _sfnDrawFragment[];
};

//----------------------------------------------------------------------------
//  constructor
//----------------------------------------------------------------------------
template <typename Pixel> 
Render<Pixel>::Render(int32 iWidth, int32 iHeight, Pixel * iprBitmap) :
    _doClamp(),
    _width(iWidth), 
    _height(iHeight), 
    _prBitmap(iprBitmap),
    _prConstBitmap(NULL),
    _prTexBitmap(NULL),
    _pBezier(NULL)
{
  // clipping zone
  _xwMin = _ywMin = 0;
  _xwMax = iWidth;
  _ywMax = iHeight;

  _xMin = double(_xwMin);
  _yMin = double(_ywMin);
  _xMax = double(_xwMax);
  _yMax = double(_ywMax);

} // constructor

//----------------------------------------------------------------------------
//  constructor
//----------------------------------------------------------------------------
template <typename Pixel> 
Render<Pixel>::Render(ImageImpl<Pixel>& ioImage) : 
    _doClamp(),
    _width(int32(ioImage.GetWidth())), 
    _height(int32(ioImage.GetHeight())), 
    _prBitmap(ioImage.GetPixel()),
    _prConstBitmap(NULL),
    _prTexBitmap(NULL),
    _pBezier(NULL)
{
  // clipping zone
  _xwMin = _ywMin = 0;
  _xwMax = _width;
  _ywMax = _height;

  _xMin = double(_xwMin);
  _yMin = double(_ywMin);
  _xMax = double(_xwMax);
  _yMax = double(_ywMax);

} // constructor

//----------------------------------------------------------------------------
//  constructor
//----------------------------------------------------------------------------
template <typename Pixel> 
Render<Pixel>::Render(const ImageImpl<Pixel>& iImage) : 
    _doClamp(),
    _width(int32(iImage.GetWidth())), 
    _height(int32(iImage.GetHeight())), 
    _prBitmap(NULL),
    _prConstBitmap(iImage.GetPixel()),
    _prTexBitmap(NULL),
    _pBezier(NULL)
{
  // clipping zone
  _xwMin = _ywMin = 0;
  _xwMax = _width;
  _ywMax = _height;

  _xMin = double(_xwMin);
  _yMin = double(_ywMin);
  _xMax = double(_xwMax);
  _yMax = double(_ywMax);

} // constructor

//----------------------------------------------------------------------------
//  destructor
//----------------------------------------------------------------------------
template <typename Pixel> 
Render<Pixel>::~Render() 
{ 
  _prBitmap = NULL; 
  _prConstBitmap = NULL,
  _prTexBitmap = NULL; 
  _pBezier = NULL;

} // destructor


//----------------------------------------------------------------------------
//  SetTexture
//----------------------------------------------------------------------------
template <typename Pixel> 
void Render<Pixel>::SetTexture(const ImageImpl<Pixel>& iTexture, uint32 iFlags)
{
  if (!iTexture.IsValid()) return;

  _prTexBitmap = iTexture.GetPixel();
  _TexWidth    = iTexture.GetWidth();
  _TexHeight   = iTexture.GetHeight();
  _TexFlags    = iFlags;

} // SetTexture

//----------------------------------------------------------------------------
//  Draw : Triangle2DP
//----------------------------------------------------------------------------
template <typename Pixel> 
void Render<Pixel>::Draw(Triangle2DP<Pixel>& iDP, uint32 iChannelMask)
{
  if (!Pixel::IsMasking(iChannelMask)) return;

  const bool bTextured = iDP.IsTextured();
  if (bTextured && (NULL == _prTexBitmap)) return;

  const bool bFlat = iDP.IsFlat();
  if (PreClip2d(iDP)) return;

  // culls triangle to make it ordered in CCW
  const double x0 = iDP._v0._x;
  const double y0 = iDP._v0._y;
  const double x1 = iDP._v1._x;
  const double y1 = iDP._v1._y;
  const double x2 = iDP._v2._x;
  const double y2 = iDP._v2._y;

  const bool bCCW = (x0*(y1-y2) + y0*(x2-x1) + x1*y2 - y1*x2) < 0.0;
  
//  const bool bBezier = iDP.IsBezier();

  Vertex2d<Pixel>& v0 = iDP._v0;
  Vertex2d<Pixel>& v1 = bCCW ? iDP._v1 : iDP._v2;
  Vertex2d<Pixel>& v2 = bCCW ? iDP._v2 : iDP._v1;
/*
  if (bBezier)
  {
    if (!bCCW) iDP._pBezier->Swap(1,2);
    _pBezier = iDP._pBezier;
  }
*/
  if (!_Gradient.Init(v0,v1,v2, bFlat, bTextured)) return;
  if (bFlat && !bTextured)
    _FlatColor = iDP._v0._Color;

  // 2d clip
  _InCount = 3;
  _PointIn[0]._x = v0._x;	
  _PointIn[0]._y = v0._y;	

  _PointIn[1]._x = v1._x;
  _PointIn[1]._y = v1._y;

  _PointIn[2]._x = v2._x;
  _PointIn[2]._y = v2._y;	

  // All vertex are in clipping zone
  if (iDP.IsAll2dClipIn())
  {
    ComputeEdges(_PointIn, _InCount);
  }
  else
  {
    Clip2d();
    if (_OutCount < 3) return;
    ComputeEdges(_PointOut, _OutCount);
  }
/*      
  const FragmentType fragment = bBezier ? FT_Bezier :
      (bFlat ? (bTextured ? FT_FlatTex : FT_Flat) :
               (bTextured ? FT_GouraudTex : FT_Gouraud));
*/
  const FragmentType fragment = bFlat ? 
      (bTextured ? FT_FlatTex : FT_Flat) :
      (bTextured ? FT_GouraudTex : FT_Gouraud);

  DrawPolygon(fragment, iChannelMask);

} // Draw # Triangle2DP

//----------------------------------------------------------------------------
//  PreClip2d # Triangle2DP
//----------------------------------------------------------------------------
template <typename Pixel> 
bool Render<Pixel>::PreClip2d(Triangle2DP<Pixel>& iDP)
{
  int32 f0, f1, f2;

  // checks vertex 0
  if      (iDP._v0._x < _xMin) f0 = ClipLeft;
  else if (iDP._v0._x > _xMax) f0 = ClipRight;
  else                         f0 = ClipNone;

  if      (iDP._v0._y < _yMin) f0 |= ClipUp;
  else if (iDP._v0._y > _yMax) f0 |= ClipDown;

  // checks vertex 1
  if      (iDP._v1._x < _xMin) f1 = ClipLeft;
  else if (iDP._v1._x > _xMax) f1 = ClipRight;
  else                         f1 = ClipNone;

  if      (iDP._v1._y < _yMin) f1 |= ClipUp;
  else if (iDP._v1._y > _yMax) f1 |= ClipDown;

  // checks vertex 2
  if      (iDP._v2._x < _xMin) f2 = ClipLeft;
  else if (iDP._v2._x > _xMax) f2 = ClipRight;
  else                         f2 = ClipNone;

  if      (iDP._v2._y < _yMin) f2 |= ClipUp;
  else if (iDP._v2._y > _yMax) f2 |= ClipDown;

  const bool bAllInt = (f0 | f1 | f2) == 0;
  iDP.SetAll2dClipIn(bAllInt);

  const bool bAllOut = (f0 & f1 & f2) != 0;
  iDP.SetAll2dClipOut(bAllOut);

  return bAllOut;

} // PreClip2d # Triangle2DP

//----------------------------------------------------------------------------
//  PreClip2d # Quad2DP
//----------------------------------------------------------------------------
template <typename Pixel> 
bool Render<Pixel>::PreClip2d(Quad2DP<Pixel>& iDP)
{
  int32 f0, f1, f2, f3;

  // checks vertex 0
  if      (iDP._v0._x < _xMin) f0 = ClipLeft;
  else if (iDP._v0._x > _xMax) f0 = ClipRight;
  else                         f0 = ClipNone;

  if      (iDP._v0._y < _yMin) f0 |= ClipUp;
  else if (iDP._v0._y > _yMax) f0 |= ClipDown;

  // checks vertex 1
  if      (iDP._v1._x < _xMin) f1 = ClipLeft;
  else if (iDP._v1._x > _xMax) f1 = ClipRight;
  else                         f1 = ClipNone;

  if      (iDP._v1._y < _yMin) f1 |= ClipUp;
  else if (iDP._v1._y > _yMax) f1 |= ClipDown;

  // checks vertex 2
  if      (iDP._v2._x < _xMin) f2 = ClipLeft;
  else if (iDP._v2._x > _xMax) f2 = ClipRight;
  else                         f2 = ClipNone;

  if      (iDP._v2._y < _yMin) f2 |= ClipUp;
  else if (iDP._v2._y > _yMax) f2 |= ClipDown;

  // checks vertex 3
  if      (iDP._v3._x < _xMin) f3 = ClipLeft;
  else if (iDP._v3._x > _xMax) f3 = ClipRight;
  else                         f3 = ClipNone;

  if      (iDP._v3._y < _yMin) f3 |= ClipUp;
  else if (iDP._v3._y > _yMax) f3 |= ClipDown;

  const bool bAllInt = (f0 | f1 | f2 | f3) == 0;
  iDP.SetAll2dClipIn(bAllInt);

  const bool bAllOut = (f0 & f1 & f2 & f3) != 0;
  iDP.SetAll2dClipOut(bAllOut);

  return bAllOut;

} // PreClip2d # Quad2DP

//----------------------------------------------------------------------------
//  AreInsideAllLeft
//----------------------------------------------------------------------------
template <typename Pixel>
bool Render<Pixel>::AreInsideAllLeft(uint32 iCount)
{
  bool b = true;
  for (uint32 i=0; i<iCount; i++)
  {
    _bInIsInside[i] = _PointIn[i]._x >= _xMin;
    b &= _bInIsInside[i];
  }
  return b;

} // AreInsideAllLeft

//----------------------------------------------------------------------------
//  AreInsideAllUp
//----------------------------------------------------------------------------
template <typename Pixel>
bool Render<Pixel>::AreInsideAllUp(uint32 iCount)
{
  bool b = true;
  for (uint32 i=0; i<iCount; i++)
  {
    _bInIsInside[i] = _PointIn[i]._y >= _yMin;
    b &= _bInIsInside[i];
  }
  return b;

} // AreInsideAllUp

//----------------------------------------------------------------------------
//  AreInsideAllRight
//----------------------------------------------------------------------------
template <typename Pixel>
bool Render<Pixel>::AreInsideAllRight(uint32 iCount)
{
  bool b = true;
  for (uint32 i=0; i<iCount; i++)
  {
    _bInIsInside[i] = _PointIn[i]._x <= _xMax;
    b &= _bInIsInside[i];
  }
  return b;

} // AreInsideAllRight

//----------------------------------------------------------------------------
//  AreInsideAllDown
//----------------------------------------------------------------------------
template <typename Pixel>
bool Render<Pixel>::AreInsideAllDown(uint32 iCount)
{
  bool b = true;
  for (uint32 i=0; i<iCount; i++)
  {
    _bInIsInside[i] = _PointIn[i]._y <= _yMax;
    b &= _bInIsInside[i];
  }
  return b;

} // AreInsideAllDown


//----------------------------------------------------------------------------
//  Intersect
//----------------------------------------------------------------------------
template <typename Pixel>
void Render<Pixel>::Intersect(int32 iClip, int32 iP0, int32 iP1)
{
  const double x0 = _PointIn[iP0]._x;
  const double y0 = _PointIn[iP0]._y;
  const double x1 = _PointIn[iP1]._x;
  const double y1 = _PointIn[iP1]._y;

  switch (iClip)
  {
    case ClipLeft:
      _PointOut[_OutCount]._y = (_xMin-x1)*(y0-y1)/(x0-x1) + y1;
      _PointOut[_OutCount]._x = _xMin;
      break;

    case ClipUp:
      _PointOut[_OutCount]._x = (_yMin-y1)*(x0-x1)/(y0-y1) + x1;
      _PointOut[_OutCount]._y = _yMin;
      break;

    case ClipRight:
      _PointOut[_OutCount]._y = (_xMax-x1)*(y0-y1)/(x0-x1) + y1;
      _PointOut[_OutCount]._x = _xMax;
      break;

    case ClipDown:
      _PointOut[_OutCount]._x = (_yMax-y1)*(x0-x1)/(y0-y1) + x1;
      _PointOut[_OutCount]._y = _yMax;
      break;
  }
  _OutCount++;

} // Intersect

//----------------------------------------------------------------------------
//  Clip2d
//----------------------------------------------------------------------------
template <typename Pixel>
void Render<Pixel>::Clip2d(int32 iClip)
{
  // clips In to Out
  _OutCount = 0;
  int32 p0;
  int32 p1 = _InCount - 1;	// Prec point.
  int32 i;
  for (i=0; i<_InCount; i++)
  {
    p0 = i;
    if (_bInIsInside[p0])
    {
      if (_bInIsInside[p1])
        _PointOut[_OutCount++] = _PointIn[p0];
      else
      {
        Intersect(iClip, p0, p1);
        _PointOut[_OutCount++] = _PointIn[p0];
      }
    }
    else
    {
      if (_bInIsInside[p1])
        Intersect(iClip, p0,p1);
    }

    // Prec is now the current.
    p1 = p0;	
  }

  // Copy Out to In
  _InCount = _OutCount;
  for (i=0; i<_InCount; i++)
    _PointIn[i] = _PointOut[i];

} // Clip2d

//----------------------------------------------------------------------------
//  Clip2d :
//----------------------------------------------------------------------------
//  Algorithm:
//    For each edge (XLeft, YUp, XRight, YDown)
//      Test if all vertices inside.
//        if not clip.
//----------------------------------------------------------------------------
template <typename Pixel>
void Render<Pixel>::Clip2d()
{
  if (!AreInsideAllLeft( _InCount)) Clip2d(ClipLeft);
  if (!AreInsideAllUp(   _InCount)) Clip2d(ClipUp);
  if (!AreInsideAllRight(_InCount)) Clip2d(ClipRight);
  if (!AreInsideAllDown( _InCount)) Clip2d(ClipDown);

  // copy In in Out, since we're not sure that a clip has occured
  for (int32 i=0; i<_InCount; i++)
    _PointOut[i] = _PointIn[i];
  _OutCount = _InCount;

} // Clip2d


//----------------------------------------------------------------------------
//  ComputeEdges : compute polygon's edges and split them into left and right
//----------------------------------------------------------------------------
template <typename Pixel>
void Render<Pixel>::ComputeEdges(Math::Point2d * iprPoint, int32 iCount)
{
  if (NULL == iprPoint) return;

  int32 iy,yList[ClipMaxEdges];
  int32 i,p;

  // finds YMin and YMax points
  int32 YMax = int32MIN;
  int32 YMin = int32MAX;
  int32 IMax = 0;
  int32 IMin = 0;
  for (i=0; i<iCount; i++)
  {
    iy = int32(iprPoint[i]._y);
    if (iy > YMax)
    {
      YMax = iy;
      IMax = i;
    }
    if (iy < YMin)
    {
      YMin = iy;
      IMin = i;
    }
    yList[i] = iy;
  }

  // creates left edges
  _LeftEdgesCount = 0;
  p = IMin;
  i = IMin;
  do
  {
    i++;
    if (i >= iCount) i = 0;

    if (yList[i] > yList[p])
    {
      // adds to left edge list
      _LeftEdges[_LeftEdgesCount++].Init(iprPoint[p], iprPoint[i], _Gradient);
    }
    p = i;
  }
  while (i != IMax);

  // creates right edges
  _RightEdgesCount = 0;
  p = IMin;
  i = IMin;
  do
  {
    i--;
    if (i < 0) i = iCount-1;

    if (yList[i] > yList[p])
    {
      // adds the right edge to list
      _RightEdges[_RightEdgesCount++].Init(iprPoint[p], iprPoint[i], _Gradient);
    }
    p = i;
  }
  while ( i != IMax);

} // ComputeEdges


//----------------------------------------------------------------------------
//  DrawPolygon
//----------------------------------------------------------------------------
template <typename Pixel>
void Render<Pixel>::DrawPolygon(FragmentType iFragment, uint32 iChannelMask)
{
  const fnDrawFragment fnDraw = _sfnDrawFragment[iFragment];

  Edge2d<Pixel>& Left = _LeftEdges[0];
  Edge2d<Pixel>& Right = _RightEdges[0];
  int32 hLeft(0), hRight(0), LeftIdx(0), RightIdx(0);
  int32 h;
  while ( (LeftIdx < _LeftEdgesCount) || (RightIdx < _RightEdgesCount) )
  {
    if ((0 == hLeft) && (LeftIdx < _LeftEdgesCount))
    {
      Left = _LeftEdges[LeftIdx++];
      hLeft = Left._h;
    }

    if ((0 == hRight) && (RightIdx < _RightEdgesCount))
    {
      Right = _RightEdges[RightIdx++];
      hRight = Right._h;
    }

    h = Math::elxMin(hLeft, hRight);
    hLeft  -= h;
    hRight -= h;

    if (0 == h) break;
    while (h > 0)
    {
      (this->*fnDraw)(Left, Right);
      Left.StepY();
      Right.StepY();
      h--;
    }
  }

} // DrawPolygon


//----------------------------------------------------------------------------
//  DrawFragment_Flat
//----------------------------------------------------------------------------
template <typename Pixel>
void Render<Pixel>::DrawFragment_Flat(Edge2d<Pixel>& iLeft, Edge2d<Pixel>& iRight)
{
  if (NULL == _prBitmap) return;

  int32 xwLeft = int32(Math::elxCeil(iLeft._x));
  int32 xwRight = int32(Math::elxCeil(iRight._x));

  // clamps xwLeft and xwRight
  if      (xwLeft < _xwMin) xwLeft = _xwMin;
  else if (xwLeft > _xwMax) xwLeft = _xwMax;

  if (xwRight > _xwMax) xwRight = _xwMax;

  int32 wWidth = xwRight - xwLeft;
  if (wWidth <= 0) return;

  Pixel * p = _prBitmap + iLeft._y*_width + xwLeft;
  while (wWidth--) 
    *p++ = _FlatColor;

} // DrawFragment_Flat

//----------------------------------------------------------------------------
//  DrawFragment_FlatTex
//----------------------------------------------------------------------------
template <typename Pixel>
void Render<Pixel>::DrawFragment_FlatTex(Edge2d<Pixel>& iLeft, Edge2d<Pixel>& iRight)
{
  if (NULL == _prBitmap) return;

  int32 xwLeft = int32(Math::elxCeil(iLeft._x));
  int32 xwRight = int32(Math::elxCeil(iRight._x));

  // clamps xwLeft and xwRight
  if      (xwLeft < _xwMin) xwLeft = _xwMin;
  else if (xwLeft > _xwMax) xwLeft = _xwMax;

  if (xwRight > _xwMax) xwRight = _xwMax;

  int32 wWidth = xwRight - xwLeft;
  if (wWidth <= 0) return;
	
  // x quantization error
  double xe = xwLeft - iLeft._x;

  // texture
  int32 tu,tv;
  double u = iLeft._u + xe * _Gradient._duOdx;
  double v = iLeft._v + xe * _Gradient._dvOdx;
  Pixel * p = _prBitmap + iLeft._y*_width + xwLeft;		

  while (wWidth--) 
  {
    // TEXTURE_WRAP_S = REPEAT
    tu = (int32)(_TexWidth*u);
    tu %= _TexWidth;
    if (tu < 0) tu += _TexWidth;

    // TEXTURE_WRAP_T = REPEAT
    tv = (int32)(_TexHeight*v);
    tv %= _TexHeight;
    if (tv < 0) tv += _TexHeight;
/*
    // TEXTURE_WRAP_S = CLAMP
    if      (u < 0)   tu = 0;
    else if (u >= 1)  tu = _TexWidth-1;
    else              tu = int32(_TexWidth*u);

    // TEXTURE_WRAP_T = CLAMP
    if      (v < 0)   tv = 0;
    else if (v >= 1)  tv = _TexHeight-1;
    else              tv = int32(_TexHeight*v);
*/
    *p++ = *(_prTexBitmap + tu + (tv * _TexWidth));

    u += _Gradient._duOdx;
    v += _Gradient._dvOdx;
  }

} // DrawFragment_FlatTex

//----------------------------------------------------------------------------
//  DrawFragment_Gouraud
//----------------------------------------------------------------------------
template <typename Pixel>
void Render<Pixel>::DrawFragment_Gouraud(Edge2d<Pixel>& iLeft, Edge2d<Pixel>& iRight)
{
  if (NULL == _prBitmap) return;

  int32 xwLeft = int32(Math::elxCeil(iLeft._x));
  int32 xwRight = int32(Math::elxCeil(iRight._x));

  // clamps xwLeft and xwRight
  if      (xwLeft < _xwMin) xwLeft = _xwMin;
  else if (xwLeft > _xwMax) xwLeft = _xwMax;

  if (xwRight > _xwMax) xwRight = _xwMax;

  int32 wWidth = xwRight - xwLeft;
  if (wWidth <= 0) return;

  Pixel * p = _prBitmap + iLeft._y*_width + xwLeft;

  // x quantization error
  double xe = xwLeft - iLeft._x;

  // gradient
  const uint32 nChannel = Pixel::GetChannelCount();
  uint32 c;

  Pixel_F pixel;
  double L[4];
  for (c=0; c<nChannel; c++)
    L[c] = iLeft._L[c] + xe * _Gradient._dLOdx[c];

  while (wWidth--) 
  {
    for (c=0; c<nChannel; c++)
      pixel._channel[c] = F(L[c]);

    elxPixelClamp(pixel, *p, _doClamp);
    p++;

    for (c=0; c<nChannel; c++)
      L[c] += _Gradient._dLOdx[c];
  }

} // DrawFragment_Gouraud


//----------------------------------------------------------------------------
//  DrawFragment_GouraudTex
//----------------------------------------------------------------------------
template <typename Pixel>
void Render<Pixel>::DrawFragment_GouraudTex(Edge2d<Pixel>& iLeft, Edge2d<Pixel>& iRight)
{
  if (NULL == _prBitmap) return;

  int32 xwLeft = int32(Math::elxCeil(iLeft._x));
  int32 xwRight = int32(Math::elxCeil(iRight._x));

  // clamps xwLeft and xwRight
  if      (xwLeft < _xwMin) xwLeft = _xwMin;
  else if (xwLeft > _xwMax) xwLeft = _xwMax;

  if (xwRight > _xwMax) xwRight = _xwMax;

  int32 wWidth = xwRight - xwLeft;
  if (wWidth <= 0) return;

  Pixel * p = _prBitmap + iLeft._y*_width + xwLeft;

  // x quantization error
  double xe = xwLeft - iLeft._x;

  // gradient
  const IntegerToType< ResolutionTypeTraits<T>::_bInteger > doClamp =
    IntegerToType< ResolutionTypeTraits<T>::_bInteger >();
  const uint32 nChannel = Pixel::GetChannelCount();
  uint32 c;
  Pixel textel;
  Pixel_F pixel;
  const F s = F(1. / ResolutionTypeTraits<T>::_maxInDouble);

  // pixel
  double L[4];
  for (c=0; c<nChannel; c++)
    L[c] = iLeft._L[c] + xe * _Gradient._dLOdx[c];

  // texture
  int32 tu,tv;
  double u = iLeft._u + xe * _Gradient._duOdx;
  double v = iLeft._v + xe * _Gradient._dvOdx;

  while (wWidth--) 
  {
    // TEXTURE_WRAP_S = CLAMP
    if      (u < 0)   tu = 0;
    else if (u >= 1)  tu = _TexWidth-1;
    else              tu = int32(_TexWidth*u);

    // TEXTURE_WRAP_T = CLAMP
    if      (v < 0)   tv = 0;
    else if (v >= 1)  tv = _TexHeight-1;
    else              tv = int32(_TexHeight*v);

    // pick texel
    textel = *(_prTexBitmap + tu + (tv * _TexWidth));

    // blending in modulate mode
    for (c=0; c<nChannel; c++)
      pixel._channel[c] = F(L[c] * textel._channel[c] * s);

    // save
    elxPixelClamp(pixel, *p, doClamp);

    // next pixel
    p++;
    for (c=0; c<nChannel; c++)
      L[c] += _Gradient._dLOdx[c];

    u += _Gradient._duOdx;
    v += _Gradient._dvOdx;
  }

} // DrawFragment_GouraudTex

//----------------------------------------------------------------------------
//  DrawFragment_Bezier
//----------------------------------------------------------------------------
template <typename Pixel>
void Render<Pixel>::DrawFragment_Bezier(Edge2d<Pixel>& iLeft, Edge2d<Pixel>& iRight)
{
  if (NULL == _prBitmap) return;

  int32 xwLeft = int32(Math::elxCeil(iLeft._x));
  int32 xwRight = int32(Math::elxCeil(iRight._x));

  // clamps xwLeft and xwRight
  if      (xwLeft < _xwMin) xwLeft = _xwMin;
  else if (xwLeft > _xwMax) xwLeft = _xwMax;

  if (xwRight > _xwMax) xwRight = _xwMax;

  int32 wWidth = xwRight - xwLeft;
  if (wWidth <= 0) return;

  Pixel * p = _prBitmap + iLeft._y*_width + xwLeft;  
  Pixel_F pf;
  const F yf = F(iLeft._y);
  while (wWidth--) 
  {
    const F xf = F(xwLeft++);
    _pBezier->Interpolate(xf, yf, &pf);
    elxPixelClamp(pf, *p);
    ++p;
  }

} // DrawFragment_Bezier


// --- static ---
template <typename Pixel>
typename Render<Pixel>::fnDrawFragment Render<Pixel>::_sfnDrawFragment[] =
{
  &Render<Pixel>::DrawFragment_Flat,
  &Render<Pixel>::DrawFragment_FlatTex,
  &Render<Pixel>::DrawFragment_Gouraud,
  &Render<Pixel>::DrawFragment_GouraudTex,
  &Render<Pixel>::DrawFragment_Bezier
};

} // anonymous-namespace


} // namespace Image
} // namespace eLynx

#endif // __Rasterization_Render_hpp__
