//============================================================================
//  Rasterization/Plot.hpp�                         ���Image.Component package
//============================================================================ 
//  Plot a pixel into an image
//============================================================================ 
//� Copyright (C) 2007 by eLynx project
//
//� This library is free software; you can redistribute it and/or
//� modify it under the terms of the GNU Library General Public
//� License as published by the Free Software Foundation; either 
//� version 2 of the License, or (at your option) any later version.
//
//� This library is distributed in the hope that it will be useful,
//� but WITHOUT ANY WARRANTY; without even the implied warranty of
//� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//� See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Rasterization_Plot_hpp__
#define __Rasterization_Plot_hpp__

namespace eLynx {
namespace Image { 

namespace {

//----------------------------------------------------------------------------
//  Plot
//----------------------------------------------------------------------------
template <typename Pixel>
bool Render<Pixel>::Plot(int32 iX, int32 iY, const Pixel& iPixel, uint32 iChannelMask)
{
  if (NULL == _prBitmap) return false;

  // clipping
  if (iX<0 || _width<=iX || iY<0 || _height<=iY) return false;

  if (Pixel::IsFullMask(iChannelMask))
    _prBitmap[iY*_width + iX] = iPixel;
  else
    elxPixelSet(_prBitmap[iY*_width + iX], iPixel, iChannelMask);

  return true;

} // Plot


//----------------------------------------------------------------------------
//  Pick
//----------------------------------------------------------------------------
template <typename Pixel>
Pixel Render<Pixel>::Pick(int32 iX, int32 iY)
{
//  if (NULL == _prBitmap) return Pixel_NULL;
  if (NULL == _prBitmap) return Pixel();

  // clipping
//  if (iX<0 || _width<=iX || iY<0 || _height<=iY) return Pixel_NULL;
  if (iX<0 || _width<=iX || iY<0 || _height<=iY) return Pixel();
  const Pixel pixel = _prBitmap[iY*_width + iX];
  return pixel;

} // Pick

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//������������������� static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 

//----------------------------------------------------------------------------
//  Plot a pixel into image
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::Plot(
    ImageImpl<Pixel>& ioImage,
    int32 iX, int32 iY,
    const Pixel& iPixel,
    uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  // clipping
  const int32 w = (int32)ioImage.GetWidth();
  const int32 h = (int32)ioImage.GetHeight();
  if (iX<0 || w<=iX || iY<0 || h<=iY) return false;

  Pixel * prDst = ioImage.GetPixel();

  if (Pixel::IsFullMask(iChannelMask))
    prDst[iY*w + iX] = iPixel;
  else
    elxPixelSet(prDst[iY*w + iX], iPixel, iChannelMask);

  return true;
}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageRasterization implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <class Pixel>
bool ImageRasterizationImpl<Pixel>::Plot(
    AbstractImage& ioImage,
    int32 iX, int32 iY,
    uint32 iChannelMask) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Plot(image, iX, iX, Pixel::White(), iChannelMask);
 
} // Plot

} // namespace Image
} // namespace eLynx

#endif // __Rasterization_Plot_hpp__
