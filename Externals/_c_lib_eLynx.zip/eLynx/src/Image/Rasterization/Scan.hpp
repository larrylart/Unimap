//============================================================================
//  Rasterization/Scan.hpp�                         ���Image.Component package
//============================================================================ 
//  Scan area of same pixel into an image
//============================================================================ 
//� Copyright (C) 2008 by eLynx project
//
//� This library is free software; you can redistribute it and/or
//� modify it under the terms of the GNU Library General Public
//� License as published by the Free Software Foundation; either 
//� version 2 of the License, or (at your option) any later version.
//
//� This library is distributed in the hope that it will be useful,
//� but WITHOUT ANY WARRANTY; without even the implied warranty of
//� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//� See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Rasterization_Scan_hpp__
#define __Rasterization_Scan_hpp__

namespace eLynx {
namespace Image { 

//============================================================================
//               Scan processing at every integer coordinates
//============================================================================
template <typename Pixel, class Operator>
bool elxProcessScan2i(
    int32 iWidth, int32 iHeight,         // image source size
    const Pixel * iprBitmap,         // image source map
    int32 iX, int32 iY,                  // position of filling point
    Operator& iOperator)             // what's to do at each similar points
{
  if (NULL == iprBitmap) return false;

  // clipping
  if (iX<0 || iWidth<=iX || iY<0 || iHeight<=iY) return false;

  // Pick pixel
  const Pixel pixel = iprBitmap[iY*iWidth + iX];

  int32 l, x1, x2, dy;
  int32 x = int32(iX);
  int32 y = int32(iY);

  // scanned horizontal segment of scanline y for xl<=x<=xr.
  // Parent segment was on line y-dy.  dy=1 or -1
  struct Segment {int32 y, xl, xr, dy;};

// push/pop new segment on stack
#define MAX 10000	// max depth of stack
#define PUSH(Y, XL, XR, DY) if (sp<stack+MAX && Y+(DY)>=0 && Y+(DY)<iHeight) {sp->y = Y; sp->xl = XL; sp->xr = XR; sp->dy = DY; sp++;}
#define POP(Y, XL, XR, DY) {sp--; Y = sp->y+(DY = sp->dy); XL = sp->xl; XR = sp->xr;}

  // stack of scanned segments
  Segment stack[MAX];
  Segment * sp = stack;

  // needed in some cases
  PUSH(y, x, x, 1);

  // seed segment (popped 1st)
  PUSH(y+1, x, x, -1);		

  const Pixel * p;
  while (sp > stack) 
  {
    // pop segment off stack and fill a neighboring scan line
    POP(y, x1, x2, dy);

    // segment of scan line y-dy for x1<=x<=x2 was previously filled,
    // now explore adjacent pixels in scan line y
    p = iprBitmap + y*iWidth;
    for (x=x1; (x >= 0) && (p[x] == pixel); x--)
      iOperator(x,y);

    if (x >= x1) goto skip;

    l = x+1;
    if (l<x1) 
    {
      // leak on left? 
      PUSH(y, l, x1-1, -dy);
    }
    x = x1+1;

    do 
    {
      p = iprBitmap + y*iWidth;
      for (; (x<iWidth) && (p[x] == pixel); x++)
        iOperator(x,y);

      PUSH(y, l, x-1, dy);
      if (x>x2+1) 
      {
        // leak on right?
        PUSH(y, x2+1, x-1, -dy);	
      }

      p = iprBitmap + y*iWidth;
skip:		
      for (x++; x<=x2 && (p[x] != pixel); x++);
        l = x;
    } 
    while (x<=x2);
  }
#undef MAX
#undef PUSH
#undef POP

  return true;

} // elxProcessScan2i


//============================================================================
//               Scan processing at every integer coordinates
//============================================================================
template <typename Pixel, class Atom, class Operator>
bool elxProcessScan2i(
    int32 iWidth, int32 iHeight,         // image source size
    const Pixel * iprBitmap,         // image source map
    int32 iX, int32 iY,                  // position of filling point
    Operator& iOperator)             // what's to do at each similar points
{
  if (NULL == iprBitmap) return false;

  // clipping
  if (iX<0 || iWidth<=iX || iY<0 || iHeight<=iY) return false;

  // Pick pixel
  const Pixel pixel = iprBitmap[iY*iWidth + iX];
  const Atom atom(pixel);

  int32 l, x1, x2, dy;
  int32 x = int32(iX);
  int32 y = int32(iY);

  // scanned horizontal segment of scanline y for xl<=x<=xr.
  // Parent segment was on line y-dy.  dy=1 or -1
  struct Segment {int32 y, xl, xr, dy;};

// push/pop new segment on stack
#define MAX 10000	// max depth of stack
#define PUSH(Y, XL, XR, DY) if (sp<stack+MAX && Y+(DY)>=0 && Y+(DY)<iHeight) {sp->y = Y; sp->xl = XL; sp->xr = XR; sp->dy = DY; sp++;}
#define POP(Y, XL, XR, DY) {sp--; Y = sp->y+(DY = sp->dy); XL = sp->xl; XR = sp->xr;}

  // stack of scanned segments
  Segment stack[MAX];
  Segment * sp = stack;

  // needed in some cases
  PUSH(y, x, x, 1);

  // seed segment (popped 1st)
  PUSH(y+1, x, x, -1);		

  const Pixel * p;
  while (sp > stack) 
  {
    // pop segment off stack and fill a neighboring scan line
    POP(y, x1, x2, dy);

    // segment of scan line y-dy for x1<=x<=x2 was previously filled,
    // now explore adjacent pixels in scan line y
    p = iprBitmap + y*iWidth;
	for (x=x1; (x >= 0) && (Atom(p[x]) == atom); x--)
      iOperator(x,y);

    if (x >= x1) goto skip;

    l = x+1;
    if (l<x1) 
    {
      // leak on left? 
      PUSH(y, l, x1-1, -dy);
    }
    x = x1+1;

    do 
    {
      p = iprBitmap + y*iWidth;
      for (; (x<iWidth) && (Atom(p[x]) == atom); x++)
        iOperator(x,y);

      PUSH(y, l, x-1, dy);
      if (x>x2+1) 
      {
        // leak on right?
        PUSH(y, x2+1, x-1, -dy);	
      }

      p = iprBitmap + y*iWidth;
skip:		
      for (x++; x<=x2 && (p[x] != pixel); x++);
        l = x;
    } 
    while (x<=x2);
  }
#undef MAX
#undef PUSH
#undef POP

  return true;

} // elxProcessScan2i

} // namespace Image
} // namespace eLynx

#endif // __Rasterization_Scan_hpp__
