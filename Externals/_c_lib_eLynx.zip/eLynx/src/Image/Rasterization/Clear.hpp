//============================================================================
//  Rasterization/Clear.hpp�                        ���Image.Component package
//============================================================================ 
//  Clear an image
//============================================================================ 
//� Copyright (C) 2007 by eLynx project
//
//� This library is free software; you can redistribute it and/or
//� modify it under the terms of the GNU Library General Public
//� License as published by the Free Software Foundation; either 
//� version 2 of the License, or (at your option) any later version.
//
//� This library is distributed in the hope that it will be useful,
//� but WITHOUT ANY WARRANTY; without even the implied warranty of
//� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//� See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Rasterization_Clear_hpp__
#define __Rasterization_Clear_hpp__

namespace eLynx {
namespace Image { 

namespace {

//----------------------------------------------------------------------------
//  Clear
//----------------------------------------------------------------------------
template <typename Pixel> 
bool Render<Pixel>::Clear(const Pixel& iPixel, uint32 iChannelMask)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;
  if (NULL == _prBitmap) return false;

  Pixel * prDst = _prBitmap;
  Pixel * prEnd = _prBitmap + _height*_width;

  if (Pixel::IsFullMask(iChannelMask))
  {
    // speed up if no channel mask used
    do { *prDst = iPixel; } while (++prDst != prEnd);
  }
  else
  {
    do { elxPixelSet(*prDst, iPixel, iChannelMask); } while (++prDst != prEnd);
  }

  return true;

} // Clear

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//������������������� static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//----------------------------------------------------------------------------
//  Clear
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::Clear(
    ImageImpl<Pixel>& ioImage,
    const Pixel& iPixel,
    uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  Render<Pixel> render(ioImage);
  return render.Clear(iPixel, iChannelMask);

} // Clear


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageRasterization implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Clear 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageRasterizationImpl<Pixel>::Clear(
    AbstractImage& ioImage,
    uint32 iChannelMask) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Clear(image, Pixel::Black(), iChannelMask);

} // Clear

} // namespace Image
} // namespace eLynx

#endif // __Rasterization_Clear_hpp__
