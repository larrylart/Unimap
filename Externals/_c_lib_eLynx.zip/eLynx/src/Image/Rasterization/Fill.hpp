//============================================================================
//  Rasterization/Fill.hpp�                         ���Image.Component package
//============================================================================ 
//  Fill into an image
//============================================================================ 
//� Copyright (C) 2007 by eLynx project
//
//� This library is free software; you can redistribute it and/or
//� modify it under the terms of the GNU Library General Public
//� License as published by the Free Software Foundation; either 
//� version 2 of the License, or (at your option) any later version.
//
//� This library is distributed in the hope that it will be useful,
//� but WITHOUT ANY WARRANTY; without even the implied warranty of
//� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//� See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Rasterization_Fill_hpp__
#define __Rasterization_Fill_hpp__

#include "Scan.hpp"

namespace eLynx {
namespace Image { 


template <typename Pixel>
struct OperatorFillPixel
{
  OperatorFillPixel(Pixel * iprBitmap, int32 iWidth, const Pixel& iPixel, uint32 iChannelMask) :
    _pixel(iPixel),
    _prBitmap(iprBitmap),
    _width(iWidth),
    _channelMask(iChannelMask)
  {}
   
  void operator()(int32 iX, int32 iY)
  {
    elxPixelSet(_prBitmap[iY*_width + iX], _pixel, _channelMask);
  }
  
  const Pixel& _pixel;
  Pixel * _prBitmap;
  int32 _width;
  uint32 _channelMask; 
};


//----------------------------------------------------------------------------
//  Fill
//----------------------------------------------------------------------------
template <typename Pixel> 
bool Render<Pixel>::Fill(
    int32 iX, int32 iY, 
    const Pixel& iPixel, 
    uint32 iChannelMask)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;

  OperatorFillPixel<Pixel> drawPixel(_prBitmap, _width, iPixel, iChannelMask);
  return elxProcessScan2i(_width, _height, _prBitmap, iX, iY, drawPixel);

} // Fill


//----------------------------------------------------------------------------
//  GetFilledBBox
//----------------------------------------------------------------------------
template <typename Pixel> 
bool Render<Pixel>::GetFilledBBox(int32 iX, int32 iY, Math::AOBBox2i& oBBox) const
{
  if (NULL == _prConstBitmap) return false;

  // clipping
  if (iX<0 || _width<=iX || iY<0 || _height<=iY) return false;

  // Pick pixel
  Pixel pixel = _prConstBitmap[iY*_width + iX];

  int32 xs = iX, ys = iY;
  int32 xe = iX, ye = iY;
  int32 l, x1, x2, dy;
  int32 x = int32(iX);
  int32 y = int32(iY);

  // Filled horizontal segment of scanline y for xl<=x<=xr.
  // Parent segment was on line y-dy.  dy=1 or -1
  struct Segment {int32 y, xl, xr, dy;};

// push/pop new segment on stack
#define MAX 10000	// max depth of stack
#define PUSH(Y, XL, XR, DY) if (sp<stack+MAX && Y+(DY)>=0 && Y+(DY)<_height) {sp->y = Y; sp->xl = XL; sp->xr = XR; sp->dy = DY; sp++;}
#define POP(Y, XL, XR, DY) {sp--; Y = sp->y+(DY = sp->dy); XL = sp->xl; XR = sp->xr;}
#define BOUND { if (x < xs) xs = x; else if (x > xe) xe = x; if (y < ys) ys = y; else if (y > ye) ye = y; }

  // stack of filled segments
  Segment stack[MAX];
  Segment * sp = stack;

  // needed in some cases
  PUSH(y, x, x, 1);

  // seed segment (popped 1st)
  PUSH(y+1, x, x, -1);		

  const Pixel * p;
  while (sp > stack) 
  {
    // pop segment off stack and fill a neighboring scan line
    POP(y, x1, x2, dy);

    // segment of scan line y-dy for x1<=x<=x2 was previously filled,
    // now explore adjacent pixels in scan line y
    p = _prConstBitmap + y*_width;
    for (x=x1; (x >= 0) && (p[x] == pixel); x--)
      BOUND;

    if (x >= x1) goto skip;

    l = x+1;
    if (l<x1) 
    {
      // leak on left? 
      PUSH(y, l, x1-1, -dy);
    }
    x = x1+1;

    do 
    {
      p = _prConstBitmap + y*_width;
      for (; (x<_width) && (p[x] == pixel); x++)	
        BOUND;

      PUSH(y, l, x-1, dy);
      if (x>x2+1) 
      {
        // leak on right?
        PUSH(y, x2+1, x-1, -dy);	
      }

      p = _prConstBitmap + y*_width;
skip:		
      for (x++; x<=x2 && (p[x] != pixel); x++);
        l = x;
    } 
    while (x<=x2);
  }
#undef MAX
#undef PUSH
#undef POP

  oBBox = Math::AOBBox2i( xs,ys, xe-xs+1, ye-ys+1);
  return true;

} // GetFilledBBox


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//������������������� static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//----------------------------------------------------------------------------
//  Fill
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::Fill(
    ImageImpl<Pixel>& ioImage,
    int32 iX, int32 iY,
    const Pixel& iPixel,
    uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  Render<Pixel> render(ioImage);
  return render.Fill(iX,iY, iPixel, iChannelMask);

} // Fill

//----------------------------------------------------------------------------
//  GetFilledBBox
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::GetFilledBBox(
    const ImageImpl<Pixel>& iImage,
    int32 iX, int32 iY,
    Math::AOBBox2i& oBBox)
{
  if (!iImage.IsValid()) return false;

  Render<Pixel> render(iImage);
  return render.GetFilledBBox(iX,iY, oBBox);

} // GetFilledBBox

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageRasterization implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Fill
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageRasterizationImpl<Pixel>::Fill(
    AbstractImage& ioImage,
    int32 iX, int32 iY,
    uint32 iChannelMask) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Fill(image, iX,iY, Pixel::White(), iChannelMask);

} // Fill

//----------------------------------------------------------------------------
//  GetFilledBBox
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageRasterizationImpl<Pixel>::GetFilledBBox(
    const AbstractImage& iImage,
    int32 iX, int32 iY,
    Math::AOBBox2i& oBBox) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return GetFilledBBox(image, iX,iY, oBBox);

} // GetFilledBBox

} // namespace Image
} // namespace eLynx

#endif // __Rasterization_Fill_hpp__
