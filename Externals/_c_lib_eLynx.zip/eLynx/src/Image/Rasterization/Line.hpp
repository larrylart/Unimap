//============================================================================
//  Rasterization/Line.hpp�                         ���Image.Component package
//============================================================================ 
//  Draw a line into an image
//  http://freespace.virgin.net/hugo.elias/graphics/x_wuline.htm
//  http://www.codeproject.com/KB/GDI/antialias.aspx
//============================================================================ 
//� Copyright (C) 2007 by eLynx project
//
//� This library is free software; you can redistribute it and/or
//� modify it under the terms of the GNU Library General Public
//� License as published by the Free Software Foundation; either 
//� version 2 of the License, or (at your option) any later version.
//
//� This library is distributed in the hope that it will be useful,
//� but WITHOUT ANY WARRANTY; without even the implied warranty of
//� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//� See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Rasterization_Line_hpp__
#define __Rasterization_Line_hpp__

#include <elx/math/Geometry.h>
#include "../../Math/Geometry/Line.hpp"

namespace eLynx {
namespace Image { 

namespace {

//----------------------------------------------------------------------------
//  DrawHLine : draws a horizontal line
//----------------------------------------------------------------------------
template <typename Pixel> 
bool Render<Pixel>::DrawHLine(int32 iY, int32 iX1, int32 iX2,
    const Pixel& iPixel, uint32 iChannelMask)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;
  if (NULL == _prBitmap) return false;

  // clipping
  if (iY<0 || _height<=iY) return false;

  if      (iX1 < 0)       iX1 = 0;
  else if (iX1 >= _width) iX1 = _width - 1;

  if      (iX2 < 0)       iX2 = 0;
  else if (iX2 >= _width) iX2 = _width - 1;

  int32 deltaX = iX2 - iX1;
  if (deltaX == 0) return false;

  if (deltaX < 0)
  {
    deltaX = -deltaX;
    iX1 = iX2;
  }

  Pixel * const prStart = _prBitmap + _width*iY + iX1;
  Pixel * const prEnd = prStart + deltaX;

  if (Pixel::IsFullMask(iChannelMask))
  {
    for (Pixel * prPixel=prStart; prPixel<=prEnd; prPixel++)
      *prPixel = iPixel;
  }
  else
  {
    for (Pixel * prPixel=prStart; prPixel<=prEnd; prPixel++)
      elxPixelSet(*prPixel, iPixel, iChannelMask);
  }
  return true;

} // DrawHLine


//----------------------------------------------------------------------------
//  DrawLine: 
//----------------------------------------------------------------------------
template <typename Pixel>
struct OperatorDrawPixel
{
  OperatorDrawPixel(Pixel * iprBitmap, int32 iWidth, const Pixel& iPixel, uint32 iChannelMask) :
    _pixel(iPixel),
    _prBitmap(iprBitmap),
    _width(iWidth),
    _channelMask(iChannelMask)
  {}
   
  void operator()(int32 iX, int32 iY)
  {
    elxPixelSet(_prBitmap[iY*_width + iX], _pixel, _channelMask);
  }
  
  const Pixel& _pixel;
  Pixel * _prBitmap;
  int32 _width;
  uint32 _channelMask; 
};

//----------------------------------------------------------------------------
template <typename Pixel> 
bool Render<Pixel>::DrawLine(int32 iX1, int32 iY1, int32 iX2, int32 iY2,
    const Pixel& iPixel, uint32 iChannelMask)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;
  if (NULL == _prBitmap) return false;
  
  OperatorDrawPixel<Pixel> drawPixel(_prBitmap, _width, iPixel, iChannelMask);
  Math::elxProcessLine2i(iX1, iY1, iX2, iY2, _width, _height, drawPixel);

  return true;

} // DrawLine


//----------------------------------------------------------------------------
//  DrawLineAA: Anti alias
//----------------------------------------------------------------------------
template <typename Pixel> 
bool Render<Pixel>::DrawLineAA(int32 iX1, int32 iY1, int32 iX2, int32 iY2,
    const Pixel& iPixel, uint32 iChannelMask)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;
  if (NULL == _prBitmap) return false;

  double Error;
  int32 dx, dy, XDir;

  // Make sure the line runs top to bottom
  if (iY1 > iY2) 
  {
    int32 t = iY1; iY1 = iY2; iY2 = t;
    t = iX1; iX1 = iX2; iX2 = t;
  }

  // Draw the initial pixel, which is always exactly intersected 
  // by the line and so needs no weighting
  if (0<=iX1 && iX1<_width && 0<=iY1 && iY1<_height)
    elxPixelSet(_prBitmap[iY1*_width + iX1], iPixel, iChannelMask);

  dx = iX2 - iX1;
  if (dx >= 0)
    XDir = 1;
  else 
  {
    // make dx positive
    dx = -dx;
    XDir = -1;
  }

  // Special-case horizontal, vertical, and diagonal lines, 
  // which require no weighting because they go right through 
  // the center of every pixel
  dy = iY2 - iY1;
  if (0 == dy) 
  {
    // Horizontal line
    return DrawHLine(iY1, iX1, iX2, iPixel, iChannelMask);
  }

  if (0 == dx)
  {
    // Vertical line
    if (iY1<0) iY1 = 0;
    if (iY2>=_height) iY2 = _height-1;
    dy = iY2 - iY1;
    do 
    {
      iY1++;
      elxPixelSet(_prBitmap[iY1*_width + iX1], iPixel, iChannelMask);
    } 
    while (--dy != 0);
    return true;
  }

  if (dx == dy) 
  {
    // Diagonal line
    do 
    {
      iX1 += XDir;
      iY1++;
      if (0<=iX1 && iX1<_width && 0<=iY1 && iY1<_height)
        elxPixelSet(_prBitmap[iY1*_width + iX1], iPixel, iChannelMask);
    } 
    while (--dy != 0);
    return true;
  }

  // Line is not horizontal, diagonal, or vertical

  // initialize the line error accumulator to 0
  Error = 0.;
  Pixel * p;

  // Is this an X-major or Y-major line?
  if (dy > dx)
  {
    // Y-major line; calculate fractional part of a pixel that X advances 
    // each time Y advances 1 pixel, truncating the result so that we won't
    // overrun the endpoint along the X axis
    const double d = double(dx)/double(dy);

    // Draw all pixels other than the first and last
    while (--dy) 
    {
      // calculate error for next pixel
      Error += d;

      // The error accumulator turned over, so advance the X coord
      if (Error >= 1.) 
      { 
        Error -= 1.;
        iX1 += XDir;
      }

      // Y-major, so always advance Y
      iY1++;
      if (0<=iY1 && iY1<_height)
      {
        if (0<=iX1 && iX1<_width)
        {
          p = _prBitmap + iY1*_width + iX1;
          *p = elxPixelBlend(*p, iPixel, Error, iChannelMask);
        }
        iX2 = iX1+XDir;
        if (0<=iX2 && iX2<_width)
        {
          p = _prBitmap + iY1*_width + iX2;
          *p = elxPixelBlend(*p, iPixel, 1.-Error, iChannelMask);
        }
      }
    }
  }
  else
  {
    // X-major line; calculate fractional part of a pixel that Y advances 
    // each time X advances 1 pixel, truncating the  result to avoid 
    // overrunning the endpoint along the X axis
    const double d = double(dy)/double(dx);
   
    // Draw all pixels other than the first and last
    while (--dx) 
    {
      // calculate error for next pixel
      Error += d;

      //The error accumulator turned over, so advance the Y coord
      if (Error >= 1.) 
      { 
        Error -= 1.;
        iY1++;
      }

      // X-major, so always advance X
      iX1 += XDir;

      if (0<=iX1 && iX1<_width && 0<=iY1)
      {
        if (iY1<_height)
        {
          p = _prBitmap + iY1*_width + iX1;
          *p = elxPixelBlend(*p, iPixel, Error, iChannelMask);

          if (iY1<=_height)
          {
            p += _width;
            *p = elxPixelBlend(*p, iPixel, 1.-Error, iChannelMask);
          }
        }
      }
    }
  }

  // Draw the final pixel, which is always exactly intersected 
  // by the line and so needs no weighting
  if (0<=iX2 && iX2<_width && 0<=iY2 && iY2<_height)
    elxPixelSet(_prBitmap[iY2*_width + iX2], iPixel, iChannelMask);

  return true;

} // DrawLineAA

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//������������������� static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 

//----------------------------------------------------------------------------
//  DrawHLine : draws a horizontal line
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::DrawHLine(
    ImageImpl<Pixel>& ioImage,
    int32 iY, int32 iX1, int32 iX2,
    const Pixel& iPixel,
    uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  Render<Pixel> render(ioImage);
  return render.DrawHLine(iY,iX1,iX2, iPixel, iChannelMask);

} // DrawHLine


//----------------------------------------------------------------------------
//  DrawLine
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::DrawLine(
    ImageImpl<Pixel>& ioImage,
    int32 iX1, int32 iY1, int32 iX2, int32 iY2,
    const Pixel& iPixel,
    bool ibAntialiasing,
    uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  Render<Pixel> render(ioImage);
  if (ibAntialiasing)
    return render.DrawLineAA(iX1,iY1, iX2,iY2, iPixel, iChannelMask);

  return render.DrawLine(iX1,iY1, iX2,iY2, iPixel, iChannelMask);

} // DrawLine


//----------------------------------------------------------------------------
//  DrawSpot
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::DrawSpot(
    ImageImpl<Pixel>& ioImage,
    int32 iX, int32 iY,
    const Pixel& iPixel,
    int32 iSize,
    uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  Render<Pixel> render(ioImage);
  render.DrawLine(iX-iSize,iY, iX+iSize,iY, iPixel, iChannelMask);
  render.DrawLine(iX,iY-iSize, iX,iY+iSize, iPixel, iChannelMask);
  return true;

} // DrawSpot

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageRasterization implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  DrawHLine: 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageRasterizationImpl<Pixel>::DrawHLine(
    AbstractImage& ioImage,
    int32 iY, int32 iX1, int32 iX2,
    uint32 iChannelMask) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return DrawHLine(image, iY, iX1, iX2, Pixel::White(), iChannelMask);

} // DrawHLine


//----------------------------------------------------------------------------
//  DrawLine: 
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageRasterizationImpl<Pixel>::DrawLine(
    AbstractImage& ioImage,
    int32 iX1, int32 iY1, int32 iX2, int32 iY2,
    bool ibAntialiasing,
    uint32 iChannelMask) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return DrawLine(image, iX1,iY1, iX2, iY2, Pixel::White(), ibAntialiasing, iChannelMask);

} // DrawLine

} // namespace Image
} // namespace eLynx

#endif // __Rasterization_Line_hpp__
