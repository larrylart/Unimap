//============================================================================
//  Rasterization/Triangle.hpp�                     ���Image.Component package
//============================================================================ 
//  Draw a triangle into an image
//============================================================================ 
//� Copyright (C) 2007 by eLynx project
//
//� This library is free software; you can redistribute it and/or
//� modify it under the terms of the GNU Library General Public
//� License as published by the Free Software Foundation; either 
//� version 2 of the License, or (at your option) any later version.
//
//� This library is distributed in the hope that it will be useful,
//� but WITHOUT ANY WARRANTY; without even the implied warranty of
//� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//� See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Rasterization_Triangle_hpp__
#define __Rasterization_Triangle_hpp__

#include <elx/math/MathCore.h>

namespace eLynx {
namespace Image { 

namespace {

//----------------------------------------------------------------------------
//  DrawTriangle : Framed or solid in flat mode
//----------------------------------------------------------------------------
template <typename Pixel> 
bool Render<Pixel>::DrawTriangle(
    int32 iX0, int32 iY0, int32 iX1, int32 iY1, int32 iX2, int32 iY2, 
    const Pixel& iPixel, 
    bool ibSolid, 
    uint32 iChannelMask)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;

  if (ibSolid)
  {
    // draw solid flat triangle
    Vertex2d<Pixel> v0(iX0,iY0, iPixel);
    Vertex2d<Pixel> v1(iX1,iY1, iPixel);
    Vertex2d<Pixel> v2(iX2,iY2, iPixel);
    Triangle2DP<Pixel> triangle(v0,v1,v2, SHD_Flat);
    Draw(triangle, iChannelMask);
  }
  else
  {
    // draw framed triangle
    DrawLine(iX0,iY0, iX1,iY1, iPixel, iChannelMask);
    DrawLine(iX1,iY1, iX2,iY2, iPixel, iChannelMask);
    DrawLine(iX2,iY2, iX0,iY0, iPixel, iChannelMask);
  }
  return true;

} // DrawTriangle

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//������������������� static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//----------------------------------------------------------------------------
//  DrawTriangle: Flat textured
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::DrawTriangle(
  ImageImpl<Pixel>& ioImage,
  int32 iX0, int32 iY0, int32 iU0, int32 iV0,
  int32 iX1, int32 iY1, int32 iU1, int32 iV1,
  int32 iX2, int32 iY2, int32 iU2, int32 iV2,
  const ImageImpl<Pixel>& iTexture,
  uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  // draw solid gouraud triangle
  Vertex2d<Pixel> v0(iX0,iY0, iU0,iV0);
  Vertex2d<Pixel> v1(iX1,iY1, iU1,iV1);
  Vertex2d<Pixel> v2(iX2,iY2, iU2,iV2);
  Triangle2DP<Pixel> triangle(v0,v1,v2, SHD_FlatTex);

  Render<Pixel> render(ioImage);
  render.SetTexture(iTexture);
  render.Draw(triangle, iChannelMask);
  return true;

} // DrawTriangle


//----------------------------------------------------------------------------
//  DrawTriangle: Gouraud
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::DrawTriangle(
  ImageImpl<Pixel>& ioImage,
  int32 iX0, int32 iY0, const Pixel& iPixel0,
  int32 iX1, int32 iY1, const Pixel& iPixel1,
  int32 iX2, int32 iY2, const Pixel& iPixel2,
  uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  // draw solid gouraud triangle
  Vertex2d<Pixel> v0(iX0,iY0, iPixel0);
  Vertex2d<Pixel> v1(iX1,iY1, iPixel1);
  Vertex2d<Pixel> v2(iX2,iY2, iPixel2);
  Triangle2DP<Pixel> triangle(v0,v1,v2, SHD_Gouraud);

  Render<Pixel> render(ioImage);
  render.Draw(triangle, iChannelMask);
  return true;

} // DrawTriangle


//----------------------------------------------------------------------------
//  DrawTriangle: Gouraud textured
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::DrawTriangle(
  ImageImpl<Pixel>& ioImage,
  int32 iX0, int32 iY0, int32 iU0, int32 iV0, const Pixel& iPixel0,
  int32 iX1, int32 iY1, int32 iU1, int32 iV1, const Pixel& iPixel1,
  int32 iX2, int32 iY2, int32 iU2, int32 iV2, const Pixel& iPixel2,
  const ImageImpl<Pixel>& iTexture,
  uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  // draw solid gouraud triangle
  Vertex2d<Pixel> v0(iX0,iY0, iU0,iV0, iPixel0);
  Vertex2d<Pixel> v1(iX1,iY1, iU1,iV1, iPixel1);
  Vertex2d<Pixel> v2(iX2,iY2, iU2,iV2, iPixel2);
  Triangle2DP<Pixel> triangle(v0,v1,v2, SHD_GouraudTex);

  Render<Pixel> render(ioImage);
  render.SetTexture(iTexture);
  render.Draw(triangle, iChannelMask);
  return true;

} // DrawTriangle


//----------------------------------------------------------------------------
//  DrawTriangle : Framed or solid in flat mode
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::DrawTriangle(
  ImageImpl<Pixel>& ioImage,
  int32 iX0, int32 iY0, int32 iX1, int32 iY1, int32 iX2, int32 iY2,
  const Pixel& iPixel,
  bool ibSolid,
  uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  Render<Pixel> render(ioImage);
  return render.DrawTriangle(iX0,iY0, iX1,iY1, iX2,iY2, iPixel, ibSolid, iChannelMask);

} // DrawTriangle

/*
//----------------------------------------------------------------------------
//  DrawTriangle: Bezier
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::DrawTriangle(
  ImageImpl<Pixel>& ioImage,
  int32 iX0, int32 iY0, int32 iX1, int32 iY1, int32 iX2, int32 iY2,
  Math::BezierTriangle3<
    typename ResolutionTypeTraits<typename Pixel::type>::Floating_type, 
    typename Pixel::FloatingPixel>& iBezier,
  uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  // draw solid bezier triangle
  Vertex2d<Pixel> v0(iX0, iY0, iBezier._cp[0]._z);
  Vertex2d<Pixel> v1(iX1, iY1, iBezier._cp[1]._z);
  Vertex2d<Pixel> v2(iX2, iY2, iBezier._cp[2]._z);
  Triangle2DP<Pixel> triangle(v0,v1,v2, iBezier);

  Render<Pixel> render(ioImage);
  render.Draw(triangle, iChannelMask);
  return true;

} // DrawTriangle
*/

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageRasterization implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  DrawTriangle
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageRasterizationImpl<Pixel>::DrawTriangle(
  AbstractImage& ioImage,
  int32 iX0, int32 iY0, int32 iX1, int32 iY1, int32 iX2, int32 iY2,
  bool ibSolid,
  uint32 iChannelMask) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return DrawTriangle(image, iX0,iY0, iX1,iY1, iX2,iY2, Pixel::White(), 
    ibSolid, iChannelMask);

} // DrawTriangle

} // namespace Image
} // namespace eLynx

#endif // __Rasterization_Triangle_hpp__
