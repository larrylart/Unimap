//============================================================================
//  Rasterization/Ellipse.hpp�                      ���Image.Component package
//============================================================================ 
//  Draw a Ellipse into an image
//============================================================================ 
//� Copyright (C) 2007 by eLynx project
//
//� This library is free software; you can redistribute it and/or
//� modify it under the terms of the GNU Library General Public
//� License as published by the Free Software Foundation; either 
//� version 2 of the License, or (at your option) any later version.
//
//� This library is distributed in the hope that it will be useful,
//� but WITHOUT ANY WARRANTY; without even the implied warranty of
//� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//� See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Rasterization_Ellipse_hpp__
#define __Rasterization_Ellipse_hpp__

namespace eLynx {
namespace Image { 

namespace {

//----------------------------------------------------------------------------
//  DrawEllipse:  Fast Bresenham type algorithm
//----------------------------------------------------------------------------
template <typename Pixel> 
bool Render<Pixel>::DrawEllipse(
    int32 iX, int32 iY, uint32 iRadiusX, uint32 iRadiusY,
    const Pixel& iPixel, 
    bool ibSolid,
    uint32 iChannelMask)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;
  if (NULL == _prBitmap) return false;

  int64 MaxT7 = int64(int32(0x3FFFFFFF));
  if (int64(iRadiusY*iRadiusY*iRadiusX*4) >= MaxT7)
  {
    // intermediate terms to speed up loop
    const int64 t1 = iRadiusX*iRadiusX;
    const int64 t2 = t1<<1;
    const int64 t3 = t2<<1;
    const int64 t4 = iRadiusY*iRadiusY;
    const int64 t5 = t4<<1;
    const int64 t6 = t5<<1;
    const int64 t7 = iRadiusX*t5;
    int64 t8 = t7<<1;
    int64 t9 = 0L;

    // error terms
    int64 d1 = t2 - t7 + (t4>>1);
    int64 d2 = (t1>>1) - t8 + t5;

    // ellipse points
    int32 x = iRadiusX, y = 0;	

    if (ibSolid)
    {
      // until slope = -1
      while (d2 < 0)			
      {
        // draw 2 lines using symetry
        DrawHLine(iY + y, iX - x,iX + x, iPixel, iChannelMask);
        DrawHLine(iY - y, iX - x,iX + x, iPixel, iChannelMask);

        // always move up here
        y++;		
        t9 += t3;	

        if (d1 < 0)	
        {
          // move straight up
          d1 += t9 + t2;
          d2 += t9;
        }
        else
        {
          // move up and left
          x--;
          t8 -= t6;
          d1 += t9 + t2 - t8;
          d2 += t9 + t5 - t8;
        }
      }

      // rest of top right quadrant
      do 				
      {
        // draw 2 lines using symetry
        DrawHLine(iY + y, iX - x, iX + x, iPixel, iChannelMask);
        DrawHLine(iY - y, iX - x, iX + x, iPixel, iChannelMask);

        // always move left here
        x--;		
        t8 -= t6;	
        if (d2 < 0)	
        {
          // move up and left
          y++;
          t9 += t3;
          d2 += t9 + t5 - t8;
        }
        else
        {
          // move straight left
          d2 += t5 - t8;
        }
      } 
      while (x >= 0);
    }
    else	// outline
    {
      // until slope = -1
      while (d2 < 0)			
      {
        // draw 4 points using symetry
        Plot(iX + x, iY + y, iPixel, iChannelMask);
        Plot(iX + x, iY - y, iPixel, iChannelMask);
        Plot(iX - x, iY + y, iPixel, iChannelMask);
        Plot(iX - x, iY - y, iPixel, iChannelMask);

        // always move up here
        y++;		
        t9 += t3;	

        if (d1 < 0)	
        {
          // move straight up
          d1 += t9 + t2;
          d2 += t9;
        }
        else
        {
          // move up and left
          x--;
          t8 -= t6;
          d1 += t9 + t2 - t8;
          d2 += t9 + t5 - t8;
        }
      }

      // rest of top right quadrant
      do 				
      {
        // draw 4 points using symetry
        Plot(iX + x, iY + y, iPixel, iChannelMask);
        Plot(iX + x, iY - y, iPixel, iChannelMask);
        Plot(iX - x, iY + y, iPixel, iChannelMask);
        Plot(iX - x, iY - y, iPixel, iChannelMask);

        // always move left here
        x--;		
        t8 -= t6;	
        if (d2 < 0)	
        {
          // move up and left
          y++;
          t9 += t3;
          d2 += t9 + t5 - t8;
        }
        else
        {
          // move straight left
          d2 += t5 - t8;
        }
      } 
      while (x >= 0);
    }
  }
  else
  {
    //  intermediate terms to speed up loop
    const int32 t1 = iRadiusX*iRadiusX;
    const int32 t2 = t1<<1;
    const int32 t3 = t2<<1;
    const int32 t4 = iRadiusY*iRadiusY;
    const int32 t5 = t4<<1;
    const int32 t6 = t5<<1;
    const int32 t7 = iRadiusX*t5;
    int32 t8 = t7<<1;
    int32 t9 = 0L;

    // error terms
    int32 d1 = t2 - t7 + (t4>>1);
    int32 d2 = (t1>>1) - t8 + t5;

    // ellipse points
    int32 x = iRadiusX, y = 0;	

    if (ibSolid)
    {
      // until slope = -1
      while (d2 < 0)			
      {
        DrawHLine(iY + y, iX - x,iX + x, iPixel, iChannelMask);
        DrawHLine(iY - y, iX - x,iX + x, iPixel, iChannelMask);

        // always move up here
        y++;		
        t9 += t3;	

        if (d1 < 0)	
        {
          // move straight up
          d1 += t9 + t2;
          d2 += t9;
        }
        else
        {
          // move up and left
          x--;
          t8 -= t6;
          d1 += t9 + t2 - t8;
          d2 += t9 + t5 - t8;
        }
      }

      // rest of top right quadrant
      do 				
      {
        DrawHLine(iY + y, iX - x, iX + x, iPixel, iChannelMask);
        DrawHLine(iY - y, iX - x, iX + x, iPixel, iChannelMask);

        // always move left here
        x--;		
        t8 -= t6;	
        if (d2 < 0)	
        {
          // move up and left
          y++;
          t9 += t3;
          d2 += t9 + t5 - t8;
        }
        else
        {
          // move straight left
          d2 += t5 - t8;
        }
      } 
      while (x >= 0);
    }
    else	// outline
    {
      // until slope = -1
      while (d2 < 0)			
      {
        // draw 4 points using symetry
        Plot(iX + x, iY + y, iPixel, iChannelMask);
        Plot(iX + x, iY - y, iPixel, iChannelMask);
        Plot(iX - x, iY + y, iPixel, iChannelMask);
        Plot(iX - x, iY - y, iPixel, iChannelMask);

        // always move up here
        y++;		
        t9 += t3;	

        if (d1 < 0)	
        {
          // move straight up
          d1 += t9 + t2;
          d2 += t9;
        }
        else
        {
          // move up and left
          x--;
          t8 -= t6;
          d1 += t9 + t2 - t8;
          d2 += t9 + t5 - t8;
        }
      }

      // rest of top right quadrant
      do 				
      {
        // draw 4 points using symetry
        Plot(iX + x, iY + y, iPixel, iChannelMask);
        Plot(iX + x, iY - y, iPixel, iChannelMask);
        Plot(iX - x, iY + y, iPixel, iChannelMask);
        Plot(iX - x, iY - y, iPixel, iChannelMask);

        // always move left here
        x--;		
        t8 -= t6;	
        if (d2 < 0)	
        {
          // move up and left
          y++;
          t9 += t3;
          d2 += t9 + t5 - t8;
        }
        else
        {
          // move straight left
          d2 += t5 - t8;
        }
      } 
      while (x >= 0);
    }
  }

  return true;

} // DrawEllipse

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//������������������� static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//----------------------------------------------------------------------------
//  DrawEllipse
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::DrawEllipse(
    ImageImpl<Pixel>& ioImage,
    int32 iX, int32 iY, uint32 iRadiusX, uint32 iRadiusY,
    const Pixel& iPixel, 
    bool ibSolid, 
    uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  Render<Pixel> render(ioImage);
  return render.DrawEllipse(iX, iY, iRadiusX, iRadiusY, iPixel, ibSolid, iChannelMask);

} // DrawEllipse

//----------------------------------------------------------------------------
//  DrawCircle
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::DrawCircle(
    ImageImpl<Pixel>& ioImage,
    int32 iX, int32 iY, uint32 iRadius,
    const Pixel& iPixel, 
    bool ibSolid,
    uint32 iChannelMask)
{
  return DrawEllipse(ioImage, iX, iY, iRadius, iRadius, iPixel, ibSolid, iChannelMask);

} // DrawCircle


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageRasterization implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  DrawEllipse
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageRasterizationImpl<Pixel>::DrawEllipse(
    AbstractImage& ioImage,
    int32 iX, int32 iY, uint32 iRadiusX, uint32 iRadiusY, 
    bool ibSolid,
    uint32 iChannelMask) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return DrawEllipse(image, iX, iY, iRadiusX, iRadiusY, Pixel::White(), ibSolid, iChannelMask);

} // DrawEllipse


//----------------------------------------------------------------------------
//  DrawCircle
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageRasterizationImpl<Pixel>::DrawCircle(
    AbstractImage& ioImage,
    int32 iX, int32 iY, uint32 iRadius, 
    bool ibSolid,
    uint32 iChannelMask) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return DrawCircle(image, iX, iY, iRadius, Pixel::White(), ibSolid, iChannelMask);

} // DrawCircle

} // namespace Image
} // namespace eLynx

#endif // __Rasterization_Ellipse_hpp__
