//============================================================================
//  Rasterization/Rectangle.hpp�                    ���Image.Component package
//============================================================================ 
//  Draw a rectangle into an image
//============================================================================ 
//� Copyright (C) 2007 by eLynx project
//
//� This library is free software; you can redistribute it and/or
//� modify it under the terms of the GNU Library General Public
//� License as published by the Free Software Foundation; either 
//� version 2 of the License, or (at your option) any later version.
//
//� This library is distributed in the hope that it will be useful,
//� but WITHOUT ANY WARRANTY; without even the implied warranty of
//� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//� See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Rasterization_Rectangle_hpp__
#define __Rasterization_Rectangle_hpp__

namespace eLynx {
namespace Image { 

namespace {

//----------------------------------------------------------------------------
//  DrawRectangle
//----------------------------------------------------------------------------
template <typename Pixel> 
bool Render<Pixel>::DrawRectangle(
    int32 iX1, int32 iY1, int32 iX2, int32 iY2,
    const Pixel& iPixel,
    bool ibSolid,
    uint32 iChannelMask)
{
  if (!Pixel::IsMasking(iChannelMask)) return true;
  if (NULL == _prBitmap) return false;

  if (!ibSolid)
  {
    // framed
    DrawLine(iX1, iY1, iX2, iY1, iPixel, iChannelMask);
    DrawLine(iX2, iY1, iX2, iY2, iPixel, iChannelMask);
    DrawLine(iX2, iY2, iX1, iY2, iPixel, iChannelMask);
    DrawLine(iX1, iY2, iX1, iY1, iPixel, iChannelMask);
    return true;
  }

  // clipping
  if      (iY1 < 0)         iY1 = 0;
  else if (iY1 >= _height)  iY1 = _height - 1;

  if      (iY2 < 0)         iY2 = 0;
  else if (iY2 >= _height)  iY2 = _height - 1;

  int32 dy = iY2 - iY1;
  if (0 == dy) return false;

  if (dy < 0)
  {
    dy = -dy;
    iY1 = iY2;
  }

  for(int32 y=0; y<=dy; y++)
    DrawHLine(iY1+y, iX1, iX2, iPixel, iChannelMask);

  return true;

} // DrawRectangle

} // anonymous-namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//������������������� static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><> 
//----------------------------------------------------------------------------
//  DrawRectangle: 
//----------------------------------------------------------------------------
template <typename Pixel> 
bool ImageRasterizationImpl<Pixel>::DrawRectangle(
    ImageImpl<Pixel>& ioImage,
    int32 iX1, int32 iY1, int32 iX2, int32 iY2,
    const Pixel& iPixel,
    bool ibSolid,
    uint32 iChannelMask)
{
  if (!ioImage.IsValid()) return false;

  Render<Pixel> render(ioImage);
  return render.DrawRectangle(iX1,iY1, iX2, iY2, iPixel, ibSolid, iChannelMask);

} // DrawRectangle


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//      virtual from IImageRasterization implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  DrawRectangle
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageRasterizationImpl<Pixel>::DrawRectangle(
    AbstractImage& ioImage,
    int32 iX1, int32 iY1, int32 iX2, int32 iY2,
    bool ibSolid,
    uint32 iChannelMask) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return DrawRectangle(image, iX1,iY1, iX2, iY2, Pixel::White(), 
      ibSolid, iChannelMask);

} // DrawRectangle

} // namespace Image
} // namespace eLynx

#endif // __Rasterization_Rectangle_hpp__
