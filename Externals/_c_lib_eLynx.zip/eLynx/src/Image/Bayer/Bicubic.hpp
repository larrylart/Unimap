//============================================================================
//  Bicubic.hpp                                        Image.Component package
//============================================================================
//
//  Exposing Digital Forgeries in Color Filter Array Interpolated Images
//
//  by Alin C. Popescu and Hany Faridy
//  IEEE Transactions on Signal Processing, vol. 53(10), pp. 3948�3959, 2005.
//
//  http://elynxsdk.free.fr/ext-docs/Demosaicing/Bicubic.pdf
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Bicubic_hpp__
#define __Bayer_Bicubic_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateBicubic
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateBicubic(
    const ImageImpl< PixelL<T> >& iImage,
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 3;
  const int32 w1 = int32(border+w+border);
  const int32 w2 = 2*w1;
  const int32 w3 = 3*w1;

  // --- inits progress ---
  const float ProgressStep = 1.0f / h;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

/*
  red/blue at blue/red 
  Hc = 1/16 [-1 0 9 1 9 0 -1] separable kernels

  +1 0 -9 -1 -9 0 +1    R11 G12 R13 G14 R15 G16 R17
   0 0  0  0  0 0  0    G21 B22 G23 B24 G25 B26 G27
  -9 0 81  9 81 0 -9    R31 G32 R33 G34 R35 G36 R37
  -1 0  9  0  9 0 -1    G41 B42 G43[B44]G45 B46 G47
  -9 0 81  9 81 0 -9    R51 G52 R53 G54 R55 G56 R57
   0 0  0  0  0 0  0    G61 B62 G63 B64 G65 B66 G67
  +1 0 -9 -1 -9 0 +1    R71 G72 R73 G74 R75 G76 R77


  +1   -9    -9   +1    R11     R13     R15     R17
                                                   
  -9   81    81   -9    R31     R33     R35     R37
           0                       [B44]            
  -9   81    81   -9    R51     R53     R55     R57
                                                   
  +1   -9    -9   +1    R71     R73     R75     R77
*/
  const int32 idx1[16] = {
    -w3-3, -w3-1, -w3+1, -w3+3,
    -w1-3, -w1-1, -w1+1, -w1+3,
     w1-3,  w1-1,  w1+1,  w1+3,
     w3-3,  w3-1,  w3+1,  w3+3
  };

  const int32 idx2[16] = {
                   -w3, 
	           -w2-1,     -w2+1,
       -w1-2,      -w1,       -w1+2,
    -3,         -1,         1,      3,   
        w1-2,       w1,        w1+2,  
              w2-1,      w2+1,   
                    w3
  };

  const int32 idx3[8] = { 
       -w2-1, -w2+1, 
    -3,   -1,     1,  3, 
        w2-1,  w2+1
  };

/*
   red/blue at green
   0  0  0  1  0  0  0    G11 R12 G13 R14 G15 R16 G17
   0  0 -9  0 -9  0  0    B21 G22 B23 G24 B25 G26 B27
   0 -9  0 81  0 -9  0    G31 R32 G33 R34 G35 R36 G37
   1  0 81  0 81  0  1    B41 G42 B43[G44]B45 G46 B47
   0 -9  0 81  0 -9  0    G51 R52 G53 R54 G55 R56 G57
   0  0 -9  0 -9  0  0    B61 G62 B63 G64 B65 G66 B67
   0  0  0  1  0  0  0    G71 R72 G73 R74 G75 R76 G77

      0     1     0           R12     R14     R16
                                                     
     -9    81    -9           R32     R34     R36
                                     [G44]            
     -9    81    -9           R52     R54     R56
                                                     
      0     1     0           R72     R74     R76
*/
  const int32 idx4[8] = { 
            -w3, 
     -w1-2, -w1, -w1+2, 
      w1-2,  w1,  w1+2, 
             w3
  };

  // Create  a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w,h) );

  uint32 x,y;
  EBayerMatrix Bayer;
  M val1, val2;

  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel();
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          val1 = (
            prSrc[idx1[0]] + prSrc[idx1[3]] + prSrc[idx1[12]] + prSrc[idx1[15]] +
            81*(prSrc[idx1[5]] + prSrc[idx1[6]] + prSrc[idx1[9]] + prSrc[idx1[10]]) -
            9*(prSrc[idx1[1]] + prSrc[idx1[2]] + prSrc[idx1[4]] + prSrc[idx1[7]] +
               prSrc[idx1[8]] + prSrc[idx1[11]] + prSrc[idx1[13]] + prSrc[idx1[14]])
                 )/256;

          if (Bayer == BM_BGGR)
          {
            prDst->_red = ResolutionTypeTraits<T>::ClampM(val1);
            prDst->_blue = prSrc[0];
          }
          else
          {
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(val1);
            prDst->_red = prSrc[0];
          }

          val1 = (
            prSrc[idx2[0]]+prSrc[idx2[15]]+prSrc[idx2[6]]+prSrc[idx2[9]]+
            81*(prSrc[idx2[4]]+prSrc[idx2[7]]+prSrc[idx2[8]]+prSrc[idx2[11]])-
            9*(prSrc[idx2[1]]+prSrc[idx2[2]]+prSrc[idx2[3]]+prSrc[idx2[5]]+
            prSrc[idx2[10]]+prSrc[idx2[12]]+prSrc[idx2[13]]+prSrc[idx2[14]])
                 )/256;

          prDst->_green = ResolutionTypeTraits<T>::ClampM(val1);
          break;

        case BM_GBRG: case BM_GRBG:
          val1 = (
            prSrc[idx3[2]]+prSrc[idx3[5]]+81*(prSrc[idx3[3]]+prSrc[idx3[4]])-
            9*(prSrc[idx3[0]]+prSrc[idx3[1]]+prSrc[idx3[6]]+prSrc[idx3[7]])
                 )/128;
          val2 = (
            prSrc[idx4[0]]+prSrc[idx4[7]]+81*(prSrc[idx4[2]]+prSrc[idx4[5]])-
            9*(prSrc[idx4[1]]+prSrc[idx4[3]]+prSrc[idx4[4]]+prSrc[idx4[6]])
                 )/128;

          if (Bayer == BM_GBRG)
          {
            prDst->_red  = ResolutionTypeTraits<T>::ClampM(val2);
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(val1);
          }
          else
          {
            prDst->_red  = ResolutionTypeTraits<T>::ClampM(val1);
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(val2);
          }
          prDst->_green = prSrc[0];
          break;

        default:
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
  spImageL.reset();
  return spImageRGB;

} // elxCreateBicubic

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Bicubic_hpp__
