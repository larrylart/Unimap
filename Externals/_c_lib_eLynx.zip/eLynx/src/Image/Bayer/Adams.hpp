//============================================================================
//  Adams.hpp                                          Image.Component package
//============================================================================
//
//  Design of practical color filter array interpolation algorithms for digital cameras
//
//  by James E. Adams - Proceedings of SPIE  Vol.3028 P.117-125 
//  http://scien.stanford.edu/class/psych221/projects/99/tingchen/algodep/corrII.html
//
//  Note: we use absolute value of color correction terms.
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Adams_hpp__
#define __Bayer_Adams_hpp__

#include <elx/image/ImageAnalyseImpl.h>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateAdams
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateAdams(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;

  // --- inits progress ---
  const float ProgressStep = 1.0f / (3*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );
    
  // compute thesholds
  T max;
  ImageAnalyseImpl< PixelL<T> >::ComputeMax(iImage, max);
  const M Threshold1 = max * 69  / 255;
  const M Threshold2 = max * 170 / 255;
  const M Threshold3 = max * 250 / 255;

  M V1,V2,V3,V4,V5,V6,V7,V8,V9;
  M G1,G2,G3,G4,G5,G6,G8;
  M CC1, CC2, CC3, CC4, CC5, CC6, CC7, CC8, CC9, CC10;
  M g,v,Vv,Vh;

  uint32 x,y, c;

  EBayerMatrix Bayer, Original = iBayer;
  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel(border,border);

  //-------------------------------------------------------
  // Step I - interpolation of green plane for whole image
  //-------------------------------------------------------
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          //         V1
          //         G2
          //  V3 G4 [V5] G6 V7
          //         G8
          //         V9
                                  V1 = prSrc[-w2];
                                  G2 = prSrc[-w1];
  V3 = prSrc[-2]; G4 = prSrc[-1]; V5 = prSrc[  0]; G6 = prSrc[+1]; V7 = prSrc[+2]; 
                                  G8 = prSrc[+w1];
                                  V9 = prSrc[+w2];

          // CC1 - CC6 are Laplacian second-order derivative operators 
          CC1 = 2*V5 - V3 - V7;
          CC2 = 2*V5 - V1 - V9;
          v = Math::elxMin(Math::elxAbs(CC1), Math::elxAbs(CC2));
          if (v < Threshold1)
          {
            if (v == Math::elxAbs(CC1)) g = (G4 + G6)/2 + CC1/4;
            else                        g = (G2 + G8)/2 + CC2/4;
            break; 
          }

          CC3 = 2*V5 - V1 - V7;
          CC4 = 2*V5 - V7 - V9;
          CC5 = 2*V5 - V9 - V3;
          CC6 = 2*V5 - V3 - V1;
          v = Math::elxMin(
              Math::elxAbs(CC3), Math::elxAbs(CC4), Math::elxAbs(CC5), Math::elxAbs(CC6));
          if (v < Threshold2)
          {
            if      (v == Math::elxAbs(CC3)) g = (G2 + G6)/2 + CC3/4;
            else if (v == Math::elxAbs(CC4)) g = (G6 + G8)/2 + CC4/4;
            else if (v == Math::elxAbs(CC5)) g = (G4 + G8)/2 + CC5/4;
            else                             g = (G2 + G4)/2 + CC6/4;
            break;
          }

          // CC7 - CC10 are Laplacian first-order derivative operators. 
          CC7 = V5 - V1;
          CC8 = V5 - V7;
          CC9 = V5 - V9;
          CC10 = V5 - V3;

          v = Math::elxMin(
            Math::elxAbs(CC7), Math::elxAbs(CC8), Math::elxAbs(CC9), Math::elxAbs(CC10));
          if (v < Threshold3)
          {
            if      (v == Math::elxAbs(CC7)) g = G2 + CC7/2;
            else if (v == Math::elxAbs(CC8)) g = G6 + CC8/2;
            else if (v == Math::elxAbs(CC9)) g = G8 + CC9/2;
            else                             g = G4 + CC10/2;
            break;
          }

          g = (4*V5 - V1 - V3 - V7 - V9) / 8 + (G2 + G4 + G6 + G8) / 4;
          break;

        default:
          // Green plane is direct value
          g = prSrc[0];
          break;
      }
      prDst->_green = ResolutionTypeTraits<T>::ClampM(g);
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //----------------------------------------------------
  // Step II - interpolation of red/blue plane at green
  //----------------------------------------------------
  prSrcV = (T*)spImageL->GetPixel(border,border);
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_GBRG:     case BM_GRBG:
          //      R1           B1            V1
          //  B2 [G3] B4   R2 [G3] R4    V2 [G3] V4
          //      R5           B5            V5
                         G1 = prDst[-w1]._green;
  G2 = prDst[-1]._green; G3 = prDst[  0]._green; G4 = prDst[+1]._green;
                         G5 = prDst[+w1]._green;

                         V1 = prSrc[-w1];
          V2 = prSrc[-1];                V4 = prSrc[+1];
                         V5 = prSrc[+w1];

          // vertical
          CC1 = 2*G3 - G1 - G5;
          CC2 = G3 - G1;
          CC3 = G3 - G5;
          if (Math::elxAbs(CC1) < Threshold1)
            Vv = (V1 + V5 + CC1)/2;
          else if (Math::elxAbs(CC2) < Math::elxAbs(CC3))
            Vv = V1 + CC2;
          else
            Vv = V5 + CC3;
          
          // horizontal
          CC1 = 2*G3 - G2 - G4;
          CC2 = G3 - G2;
          CC3 = G3 - G4;
          if (Math::elxAbs(CC1) < Threshold1)
            Vh = (V2 + V4 + CC1)/2;
          else if (Math::elxAbs(CC2) < Math::elxAbs(CC3))
            Vh = V2 + CC2;
          else 
            Vh = V4 + CC3;
          
          if (Bayer == BM_GRBG)
          {
            prDst->_red  = ResolutionTypeTraits<T>::ClampM(Vh);
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(Vv);
          }
          else // BM_GBRG
          {
            prDst->_red  = ResolutionTypeTraits<T>::ClampM(Vv);
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(Vh);
          }
          break;

        case BM_RGGB:
          prDst->_red  = prSrc[0];
          break;

        case BM_BGGR:
          prDst->_blue = prSrc[0];
          break;

        default: break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
  
  // no more need of original expanded image
  spImageL.reset();

  //--------------------------------------------------------
  // Step III - interpolation of red/blue plane at blue/red
  //--------------------------------------------------------
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prDstV+=w1)
  {
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          //      G2
          //  G4 [V5] G6 
          //      G8

          // red/blue at blue/red
          c = (Bayer == BM_BGGR) ? 0 : 2;

                            G2 = prDst[-w1]._green;
                            V2 = prDst[-w1]._channel[c];
G4 = prDst[-1]._green;      G5 = prDst[  0]._green;     G6 = prDst[+1]._green;
V4 = prDst[-1]._channel[c];                             V6 = prDst[+1]._channel[c];
                            G8 = prDst[+w1]._green;
                            V8 = prDst[+w1]._channel[c];

          CC1 = 2*G5 - G4 - G6;
          CC2 = 2*G5 - G2 - G8;
          v = Math::elxMin(Math::elxAbs(CC1), Math::elxAbs(CC2));
          if (v < Threshold1)
          {          
            if (v == Math::elxAbs(CC1)) v = (V4 + V6 + CC1)/2;
            else                        v = (V2 + V8 + CC2)/2;
            prDst->_channel[c] = ResolutionTypeTraits<T>::ClampM(v);
            break; 
          }

          CC3 = 2*G5 - G2 - G6;
          CC4 = 2*G5 - G6 - G8;
          CC5 = 2*G5 - G4 - G8;
          CC6 = 2*G5 - G2 - G4;
          v = Math::elxMin(
            Math::elxAbs(CC3), Math::elxAbs(CC4), Math::elxAbs(CC5), Math::elxAbs(CC6));
          if (v < Threshold2)
          {
            if      (v == Math::elxAbs(CC3)) v = (V2 + V6 + CC3)/2;
            else if (v == Math::elxAbs(CC4)) v = (V6 + V8 + CC4)/2;
            else if (v == Math::elxAbs(CC5)) v = (V4 + V8 + CC5)/2;
            else                             v = (V2 + V4 + CC6)/2;
            prDst->_channel[c] = ResolutionTypeTraits<T>::ClampM(v);
            break;
          }

          CC7 = G5 - G2;
          CC8 = G5 - G6;
          CC9 = G5 - G8;
          CC10 = G5 - G4;
          v = Math::elxMin(
            Math::elxAbs(CC7), Math::elxAbs(CC8), Math::elxAbs(CC9), Math::elxAbs(CC10));
          if (v < Threshold3)
          {
            if      (v == Math::elxAbs(CC7)) v = V2 + CC7;
            else if (v == Math::elxAbs(CC8)) v = V6 + CC8;
            else if (v == Math::elxAbs(CC9)) v = V8 + CC9;
            else                             v = V4 + CC10;
            prDst->_channel[c] = ResolutionTypeTraits<T>::ClampM(v);
            break;
          }

          v = G5 + (V2-G2 + V4-G4 + V6-G6 + V8-G8)/4;
          prDst->_channel[c] = ResolutionTypeTraits<T>::ClampM(v);
          break;

        default: break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  return ImageGeometryImpl< PixelRGB<T> >::CreateSubImage(*spImageRGB, border,border, w,h);

} // elxCreateAdams

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Adams_hpp__
