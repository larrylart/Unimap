//============================================================================
//  PMI.hpp                                            Image.Component package
//============================================================================
//
//  Color Restoration from Digital Camera Data by Pattern Matching
//
//  Wu,XiaoLin. et.al.
//  Proceedings of SPIE  Vol.3018 P.12-17 
//  http://scien.stanford.edu/class/psych221/projects/99/tingchen/algodep/pttnmatch.html
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_PMI_hpp__
#define __Bayer_PMI_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreatePMI
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreatePMI(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  
  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border+w+border);
  const int32 w2 = 2*w1;

  // --- inits progress ---
  const float ProgressStep = 1.0f / h;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w,h, PixelRGB<T>::Black()) );

  uint32 x,y;
  EBayerMatrix Bayer;  
  M va1,va2,vb1,vb2, v,v1,v2;
  F g2,g4,g6,g8,g10,g12,g14,g16,g18,g20,g22,g24;
  M v7,v9,v17,v19, d7,d9,d17,d19,d[4];
  
  // compute theshold
  T max;
  ImageAnalyseImpl< PixelL<T> >::ComputeMax(iImage, max);
  const M thr = max * 69  / 255;

  const PixelL<T> * prSrc, * prSrcV = spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel();

  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR:        case BM_RGGB: 
          //  R1   G2   R3   G4   R5
          //  G6   B7   G8   B9   G10
          //  R11  G12 [R13] G14  R15
          //  G16  B17  G18  B19  G20
          //  R21  G22  R23  G24  R25
          
          g2 = prSrc[-w2-1]._luminance; g4 = prSrc[-w2+1]._luminance;
          g6 = prSrc[-w1-2]._luminance; g8 = prSrc[-w1]._luminance; g10 = prSrc[-w1+2]._luminance;
          g12 = prSrc[-1]._luminance; g14 = prSrc[1]._luminance;
          g16 = prSrc[w1-2]._luminance; g18 = prSrc[w1]._luminance; g20 = prSrc[w1+2]._luminance;
          g22 = prSrc[w2-1]._luminance; g24 = prSrc[w2+1]._luminance;
          
          v7 = prSrc[-w1-1]._luminance;  v9 = prSrc[-w1+1]._luminance;
          v17 = prSrc[w1-1]._luminance;  v19 = prSrc[w1+1]._luminance;
          
          // Compare the green pattern with four neighboring patterns
          // compute norm of the vectors
          d7 = (M)Math::elxSqrt(Math::elxSqr(g12-g6)+Math::elxSqr(g14-g8)+Math::elxSqr(g8-g2)+Math::elxSqr(g18-g12));
          d9 = (M)Math::elxSqrt(Math::elxSqr(g12-g8)+Math::elxSqr(g14-g10)+Math::elxSqr(g8-g4)+Math::elxSqr(g18-g14));
          d17 = (M)Math::elxSqrt(Math::elxSqr(g12-g16)+Math::elxSqr(g14-g18)+Math::elxSqr(g8-g12)+Math::elxSqr(g18-g22));
          d19 = (M)Math::elxSqrt(Math::elxSqr(g12-g18)+Math::elxSqr(g14-g20)+Math::elxSqr(g8-g14)+Math::elxSqr(g18-g24));

          // Sort them but keep the originals
          d[0]=d7; d[1]=d9; d[2]=d17; d[3]=d19;
          elxInsertionSort(d);
          
          if (d[3] < thr || (d[0] + d[1]) == 0)
            v = (v7 + v9 + v17 + v19)/4;
          else
          {
              v1 = (d[0] == d7)? v17:(d[0] == d9)? v9: (d[0] == d17)? v17: v19;
              v2 = (d[1] == d7)? v17:(d[1] == d9)? v9: (d[1] == d17)? v17: v19;                        
              v = (v1 * d[0] + v2 * d[1]) / (d[0] + d[1]);
          }
          
          if (Bayer == BM_BGGR)
          {  
            prDst->_red = 
              ResolutionTypeTraits<T>::ClampM(v);
            prDst->_blue  = prSrc[0]._luminance;
          }
          else
          {  
            prDst->_blue = 
              ResolutionTypeTraits<T>::ClampM(v);
            prDst->_red  = prSrc[0]._luminance;
          }
          
          // Use bilinear method to interpolate green
          prDst->_green = 
            ResolutionTypeTraits<T>::ClampF((g8 + g12 + g14 + g18) / 4);
          
          break;

        case BM_GBRG:     case BM_GRBG:
          // G   R1  G    G   B1  G
          // B1 [G ] B2   R1 [G ] R2
          // G   R2  G    G   B2  G
                         va1 = prSrc[-w1]._luminance;  
          vb1 = prSrc[-1]._luminance;      vb2 = prSrc[+1]._luminance;
                         va2 = prSrc[+w1]._luminance;

          // Use bilinear method to interpolate red/blue at green
          if (Bayer == BM_GBRG)
          {
            prDst->_red   = ResolutionTypeTraits<T>::ClampM((va1 + va2) / 2);
            prDst->_blue  = ResolutionTypeTraits<T>::ClampM((vb1 + vb2) / 2);
          }
          else
          {
            prDst->_blue   = ResolutionTypeTraits<T>::ClampM((va1 + va2) / 2);
            prDst->_red  = ResolutionTypeTraits<T>::ClampM((vb1 + vb2) / 2);
          }
          prDst->_green = prSrc[0]._luminance;
          break;

        default:
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
  spImageL.reset();
  return spImageRGB;

} // elxCreatePMI

} // namespace Image
} // namespace eLynx

#endif // __Bayer_PMI_hpp__
