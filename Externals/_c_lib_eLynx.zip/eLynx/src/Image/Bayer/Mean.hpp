//============================================================================
//  Bayer/Mean.hpp                                     Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Mean_hpp__
#define __Bayer_Mean_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ComputeMean
//----------------------------------------------------------------------------
//  mean = Sum N(sample) / N
//----------------------------------------------------------------------------
template <typename T>
bool BayerHandlerImpl<T>::ComputeMean(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    double& oMeanR, double& oMeanG, double& oMeanB,
    bool ibNormalized)
{
  oMeanR = oMeanG = oMeanB = 0.0;
  if (!iImage.IsValid() || (BM_None == iBayer)) return false;

  typedef typename ResolutionTypeTraits<T>::BigOverflow_type B;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const T * prSrc = iImage.GetSamples();

  B sumR = B(0);
  B sumG = B(0);
  B sumB = B(0);
  EBayerMatrix Bayer;
  uint32 x,y;
  for (y=0; y<h; y++)
  {
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++)
    {
      switch (Bayer)
      {
        case BM_RGGB: sumR += prSrc[0]; break;
        case BM_BGGR: sumB += prSrc[0]; break;
        default:      sumG += prSrc[0]; break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);
  }
  const uint32 count = iImage.GetSampleCount(); 
  oMeanR = 4.0 * double(sumR) / double(count);
  oMeanG = 2.0 * double(sumG) / double(count);
  oMeanB = 4.0 * double(sumB) / double(count);

  if (ibNormalized)
  {
    oMeanR *= ResolutionTypeTraits<T>::_normScale;
    oMeanG *= ResolutionTypeTraits<T>::_normScale;
    oMeanB *= ResolutionTypeTraits<T>::_normScale;
  }

  return true;

} // ComputeMean


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IBayerHandler implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ComputeMean
//----------------------------------------------------------------------------
template <typename T>
bool BayerHandlerImpl<T>::ComputeMean(
    const AbstractImage& iImage, 
    EBayerMatrix iBayer,
    double& oMeanR, double& oMeanG, double& oMeanB,
    bool ibNormalized) const
{
  const ImageImpl< PixelL<T> >& image = elxDowncast< PixelL<T> >(iImage);
  return ComputeMean(image, iBayer, oMeanR, oMeanG, oMeanB, ibNormalized);

} // ComputeMean

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Mean_hpp__
