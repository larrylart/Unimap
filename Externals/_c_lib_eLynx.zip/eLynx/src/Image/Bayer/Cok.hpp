//============================================================================
//  Cok.hpp                                            Image.Component package
//============================================================================
//
//  Smooth Hue Transition Interpolation
//
//  refers to David Cok implementation's 
//  http://scien.stanford.edu/class/psych221/projects/99/tingchen/algodep/smoothht.html
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Cok_hpp__
#define __Bayer_Cok_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateCok
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateCok(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 1;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);

  // --- inits progress ---
  const float ProgressStep = 1.0f / (2*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );
  
  T g1,g2,g3,g4;
  uint32 x,y;

  EBayerMatrix Bayer, Original = iBayer;
  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel(border,border);

  //-------------------------------------------------------
  // Step I - Bilinear green interpolation for whole image
  //-------------------------------------------------------
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
      case BM_BGGR: case BM_RGGB:
          //     G1
          // G2 [B/R] G3
          //     G4
                          g1 = prSrc[-w1];
          g2 = prSrc[-1];                 g3 = prSrc[+1];
                          g4 = prSrc[+w1];

          prDst->_green = (g1 + g2 + g3 + g4) / 4;
          break;

        default: // BM_GBRG, BM_GRBG
          // G  R  G    G  B  G
          // B [G] B    R [G] R
          // G  R  G    G  B  G
          prDst->_green = prSrc[0];
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //------------------------------------------------------------------------
  // Step II - interpolation of red/blue planes using smooth hue transition
  //------------------------------------------------------------------------
  F R1,R2,R3,R4, r;
  F G1,G2,G3,G4, g;
  F B1,B2,B3,B4, b;
  F E1,E2,E3,E4;
  prSrcV = (T*)spImageL->GetPixel(border,border);
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;

  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR:
          // R1   R2
          //   [B]
          // R3   R4
          R1 = prSrc[-w1-1]; R2 = prSrc[-w1+1];
          R3 = prSrc[+w1-1]; R4 = prSrc[+w1+1];

          g  = prDst[0]._green;
          if (0 == g)
          {
            // bilinear interpolation
            r = (R1 + R2 + R3 + R4)/4;  
          }
          else
          {
            G1 = prDst[-w1-1]._green; G2 = prDst[-w1+1]._green;
            G3 = prDst[+w1-1]._green; G4 = prDst[+w1+1]._green;
         
            // prevents from division by 0
            E1 = (0 == G1) ? F(0) : R1/G1; 
            E2 = (0 == G2) ? F(0) : R2/G2;
            E3 = (0 == G3) ? F(0) : R3/G3;
            E4 = (0 == G4) ? F(0) : R4/G4;
            r = g * (E1 + E2 + E3 + E4) / 4;
          }
          
          prDst->_red  = ResolutionTypeTraits<T>::ClampF(r);
          prDst->_blue = prSrc[0];
          break;

        case BM_RGGB:
          // B1   B2
          //   [R]
          // B3   B4
          B1 = prSrc[-w1-1]; B2 = prSrc[-w1+1];
          B3 = prSrc[+w1-1]; B4 = prSrc[+w1+1];

          g  = prDst[0]._green;
          if (0 == g)
          {
            // bilinear interpolation
            b = (B1 + B2 + B3 + B4)/4;  
          }
          else
          {
            G1 = prDst[-w1-1]._green; G2 = prDst[-w1+1]._green;
            G3 = prDst[+w1-1]._green; G4 = prDst[+w1+1]._green;
            
            // prevents from division by 0
            E1 = (0 == G1) ? F(0) : B1/G1; 
            E2 = (0 == G2) ? F(0) : B2/G2;
            E3 = (0 == G3) ? F(0) : B3/G3;
            E4 = (0 == G4) ? F(0) : B4/G4;
            
            b = g * (E1 + E2 + E3 + E4) / 4;
          }
          
          prDst->_red  = prSrc[0];
          prDst->_blue = ResolutionTypeTraits<T>::ClampF(b);
          break;

        default: 
          if (BM_GBRG == Bayer)
          {
            //     R1  
            // B1 [G ] B2
            //     R2  
                           R1 = prSrc[-w1];
            B1 = prSrc[-1];                B2 = prSrc[+1];
                           R2 = prSrc[+w1];
          }
          else // BM_GRBG
          {
            //     B1  
            // R1 [G ] R2
            //     B2  
                           B1 = prSrc[-w1];
            R1 = prSrc[-1];                R2 = prSrc[+1];
                           B2 = prSrc[+w1];
          }

          g  = prDst[0]._green;
          if (0 == g)
          {
            // bilinear interpolation
            r = (R1 + R2)/2;
            b = (B1 + B2)/2;
          }
          else
          {
                        G1 = prDst[-w1]._green; 
            G2 = prDst[-1]._green; G3 = prDst[+1]._green; 
                        G4 = prDst[+w1]._green;

            // prevents from division by 0
            if (F(0) == G1) G1 = F(1);
            if (F(0) == G2) G2 = F(1);
            if (F(0) == G3) G3 = F(1);
            if (F(0) == G4) G4 = F(1);

            r = g * (R1/G1 + R2/G2) / 2;
            b = g * (B1/G1 + B2/G2) / 2;
          }         
          prDst->_red  = ResolutionTypeTraits<T>::ClampF(r);
          prDst->_blue = ResolutionTypeTraits<T>::ClampF(b);
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  spImageL.reset();
  return ImageGeometryImpl< PixelRGB<T> >::CreateSubImage(*spImageRGB, border,border, w,h);

} // elxCreateCok

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Cok_hpp__
