//============================================================================
//  LarochePrescott.hpp                                Image.Component package
//============================================================================
//
//  Apparatus and method for adaptively interpolating a full color image 
//  utilizing chrominance gradients
//
//  Laroche and Prescott implementation's used in the
//  Kodak DCS 200 digital camera system.
//
//  http://scien.stanford.edu/class/psych221/projects/99/tingchen/algodep/edgesensevar1.html
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_LarochePrescott_hpp__
#define __Bayer_LarochePrescott_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateLarochePrescott
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateLarochePrescott(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;

  // --- inits progress ---
  const float ProgressStep = 1.0f / (2*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );
    
  M V11,V13,V31,V33,V35,V53;
  M G11,G12,G13,G21,G22,G23,G31,G32,G33,G34,G43;
  M R12,R21,R23,R32,B12,B21,B23,B32;
  M r,g,b,v, alpha, beta;
  uint32 x,y;

  EBayerMatrix Bayer, Original = iBayer;
  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel(border,border);

  //-------------------------------------------------------
  // Step I - interpolation of green plane for whole image
  //-------------------------------------------------------
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          //           V13
          //           G23
          //  V31 G32 [V33] G34 V35
          //           G43
          //           V53
                                  V13 = prSrc[-w2];
                                  G23 = prSrc[-w1];
V31 = prSrc[-2]; G32 = prSrc[-1]; V33 = prSrc[  0]; G34 = prSrc[+1]; V35 = prSrc[+2]; 
                                  G43 = prSrc[+w1];
                                  V53 = prSrc[+w2];

          alpha = Math::elxAbs( (V31 - V35)/2 - V33 );
          beta  = Math::elxAbs( (V13 - V53)/2 - V33 );

          if (alpha == beta)
          {
            g = (G32 + G34 + G23 + G43)/4;
          }
          else if (alpha < beta)
          {
            g = (G32 + G34)/2;
          }
          else // (alpha > beta)
          {
            g = (G23 + G43)/2;
          }

          prDst->_green = ResolutionTypeTraits<T>::ClampM(g);
          break;

        default:
          // green plane is direct value
          prDst->_green = prSrc[0];
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //-------------------------------------
  // Step II - interpolation of red/blue 
  //-------------------------------------
  prSrcV = (T*)spImageL->GetPixel(border,border);
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          //  V11       V13
          //  G21 [V22] G23
          //  V31       V33
          V11 = prSrc[-w1-1]; V13 = prSrc[-w1+1];
          V31 = prSrc[+w1-1]; V33 = prSrc[+w1+1];

          G11 = prDst[-w1-1]._green; G13 = prDst[-w1+1]._green;
                         G22 = prDst[0]._green;
          G31 = prDst[+w1-1]._green; G33 = prDst[+w1+1]._green;

          v = G22 + ((V11 - G11) + (V13 - G13) + (V31 - G31) + (V33 - G33))/4;
           
          if (Bayer == BM_BGGR)
          {
            prDst->_red  = ResolutionTypeTraits<T>::ClampM(v);
            prDst->_blue = prSrc[0];
          }
          else
          {
            prDst->_red  = prSrc[0];
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(v);
          }
          break;

        case BM_GBRG:
          //       R12
          //  B21 [G22] B23
          //       R32
                                  R12 = prSrc[-w1];
          B21 = prSrc[-1];                                 B23 = prSrc[+1]; 
                                  R32 = prSrc[+w1];

                                  G12 = prDst[-w1]._green;
          G21 = prDst[-1]._green; G22 = prDst[  0]._green; G23 = prDst[+1]._green;
                                  G32 = prDst[+w1]._green;

          r = G22 + ((R12 - G12) + (R32 - G32))/2;
          b = G22 + ((B21 - G21) + (B23 - G23))/2;
          prDst->_red  = ResolutionTypeTraits<T>::ClampM(r);
          prDst->_blue = ResolutionTypeTraits<T>::ClampM(b);
          break;

        default: //BM_GRBG:
          //       B12
          //  R21 [G22] R23
          //       B32
                                  B12 = prSrc[-w1];
          R21 = prSrc[-1];                                 R23 = prSrc[+1];
                                  B32 = prSrc[+w1];

                                  G12 = prDst[-w1]._green;
          G21 = prDst[-1]._green; G22 = prDst[  0]._green; G23 = prDst[+1]._green;
                                  G32 = prDst[+w1]._green;

          r = G22 + ((R21 - G21) + (R23 - G23))/2;
          b = G22 + ((B12 - G12) + (B32 - G32))/2;
          prDst->_red  = ResolutionTypeTraits<T>::ClampM(r);
          prDst->_blue = ResolutionTypeTraits<T>::ClampM(b);
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  spImageL.reset();
  return ImageGeometryImpl< PixelRGB<T> >::CreateSubImage(*spImageRGB, border,border, w,h);

} // elxCreateLarochePrescott

} // namespace Image
} // namespace eLynx

#endif // __Bayer_LarochePrescott_hpp__
