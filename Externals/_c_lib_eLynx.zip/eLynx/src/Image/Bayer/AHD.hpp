//============================================================================
//  AHD.hpp                                            Image.Component package
//============================================================================
//
//  Adaptive homogeneity-directed demosaicing algorithm (AHD)
//
//  by H. Keigo and T. Park in Cornell
//  http://www.accidentalmark.com/research/papers/Hirakawa03MNdemosaicICIP.pdf
//
//  Implementation is adapted from the Paul Lee original
//  http://home.earthlink.net/~paul.j.lee/
//
//  Great thanks to Luc Coiffier for his help.
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_AHD_hpp__
#define __Bayer_AHD_hpp__

#include <elx/image/ColorSpace.h>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateAHD
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateAHD(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

// compute look-up tables if needed
CIELut::Init();

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);
 
  // Create horizontal & vertical RGB<T> interpolated images
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spRGB_H( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );

  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spRGB_V( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );

  if ((NULL == spImageL.get()) ||
      (NULL == spRGB_H.get()) || (NULL == spRGB_V.get()))
    return boost::shared_ptr< ImageImpl< PixelRGB<T> > >();
  
  M V0,V1,V2,V3,V4, Vh,Vv;
  M G0,G1,G2,G3,G4;
  EBayerMatrix Bayer, Original = iBayer;
  uint32 x,y;

  // --- inits progress ---
  const float ProgressStep = 1.0f / (4*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  //---------------------------------------------------
  // I - Interpolate green horizontally and vertically
  //---------------------------------------------------
  T * prSrc, * prSrc2 = (T*)spImageL->GetPixel(border, border);
  PixelRGB<T> * prRGB_H, * prRGB_H2 = spRGB_H->GetPixel(border, border);
  PixelRGB<T> * prRGB_V, * prRGB_V2 = spRGB_V->GetPixel(border, border);

  for (y=0; y<h; y++, 
      prSrc2+=w1, prRGB_H2+=w1, prRGB_V2+=w1)
  {
    prSrc = prSrc2;
    prRGB_H = prRGB_H2;
    prRGB_V = prRGB_V2;
    Bayer = iBayer;
    for (x=0; x<w; x++, 
        prSrc++, prRGB_H++, prRGB_V++)
    {
      switch (Bayer)
      {
        case BM_BGGR:   case BM_RGGB:
          //      B           R           V
          //      G           G           G
          //  B G[B]G B   R G[R]G R   V G[V]G V
          //      G           G           G
          //      B           R           V
          V2 = prSrc[0];

          // horizontal green interpolation

          // V0 G1 [V2] G3 V4

          G1 = prSrc[-1]; G3 = prSrc[+1];
          if (G1 == G3)
            Vh = G1;
          else
          {
            V0 = prSrc[-2]; V4 = prSrc[+2];
            Vh = (G1 + V2 + G3)/2 - (V0 + V4)/4;
            if (G1 > G3)
            {
              if (Vh > G1 || Vh < G3)
                Vh = (Math::elxAbs(V2 - V0) < Math::elxAbs(V2 - V4)) ?
                  G1 + (V2 - V0)/2 : 
                  G3 + (V2 - V4)/2;
              if      (Vh > G1) Vh = G1;
              else if (Vh < G3) Vh = G3;
            }
            else
            {
              if (Vh < G1 || Vh > G3)
                Vh = (Math::elxAbs(V2 - V0) < Math::elxAbs(V2 - V4)) ?
                  G1 + (V2 - V0)/2 : 
                  G3 + (V2 - V4)/2;
              if      (Vh < G1) Vh = G1;
              else if (Vh > G3) Vh = G3;
            }
          }

          // vertical green interpolation

          //   V0 
          //   G1 
          //  [V2] 
          //   G3 
          //   V4

          G1 = prSrc[-w1];
          G3 = prSrc[+w1];
          if (G1 == G3)
            Vv = G1;
          else
          {
            V0 = prSrc[-w2];
            V4 = prSrc[+w2];
            Vv = (G1 + V2 + G3)/2 - (V0 + V4)/4;
            if (G1 > G3)
            {
              if (Vv > G1 || Vv < G3)
                Vv = (Math::elxAbs(V2 - V0) < Math::elxAbs(V2 - V4)) ?
                  G1 + (V2 - V0)/2 : 
                  G3 + (V2 - V4)/2;
              if      (Vv > G1) Vv = G1;
              else if (Vv < G3) Vv = G3;
            }
            else
            {
              if (Vv < G1 || Vv > G3)
                Vv = (Math::elxAbs(V2 - V0) < Math::elxAbs(V2 - V4)) ?
                  G1 + (V2 - V0)/2 :
                  G3 + (V2 - V4)/2;
              if      (Vv < G1) Vv = G1;
              else if (Vv > G3) Vv = G3;
            }
          }
          prRGB_H->_green = ResolutionTypeTraits<T>::ClampM(Vh);
          prRGB_V->_green = ResolutionTypeTraits<T>::ClampM(Vv);
          break;

        default: 
          // BM_GBRG   BM_GRBG
          // green is just copied
          prRGB_H->_green = 
          prRGB_V->_green = prSrc[0];
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //---------------------------------------------------------
  // II - Interpolate red & blue horizontally and vertically
  //      and convert interpolated RGB to CIE Lab
  //---------------------------------------------------------

  // Create horizontal & vertical CIE Lab interpolated images
  boost::shared_ptr< ImageImpl< PixelLab<F> > >
    spLab_H( new ImageImpl< PixelLab<F> >(w1,h1, PixelLab<F>::Black()) );

  boost::shared_ptr< ImageImpl< PixelLab<F> > >
    spLab_V( new ImageImpl< PixelLab<F> >(w1,h1, PixelLab<F>::Black()) );

  M Vh1,Vh2,Vv1,Vv2;
  prSrc2 = (T*)spImageL->GetPixel(border, border);
  prRGB_H2 = spRGB_H->GetPixel(border, border);
  prRGB_V2 = spRGB_V->GetPixel(border, border);
  PixelLab<F> * prLab_H, * prLab_H2 = spLab_H->GetPixel(border, border);
  PixelLab<F> * prLab_V, * prLab_V2 = spLab_V->GetPixel(border, border);
  iBayer = Original;

  for (y=0; y<h; y++, 
      prSrc2+=w1, prRGB_H2+=w1, prRGB_V2+=w1, prLab_H2+=w1, prLab_V2+=w1)
  {
    prSrc = prSrc2;
    prRGB_H = prRGB_H2;
    prRGB_V = prRGB_V2;
    prLab_H = prLab_H2;
    prLab_V = prLab_V2;
    Bayer = iBayer;
    for (x=0; x<w; x++, 
        prSrc++, prRGB_H++, prRGB_V++, prLab_H++, prLab_V++)
    {
      switch (Bayer)
      {
        case BM_GBRG:  case BM_GRBG:
          //    B      R      V
          //  R[G]R  B[G]B  V[G]V
          //    B      R      V
          G2 = prSrc[0];
            
          // V1 [G2] V3
          V1 = prSrc[-1]; V3 = prSrc[+1];
          if (V1 == V3)
            Vh1 = Vv1 = V1;
          else
          {
            // vertical interpolation
            G1 = prRGB_V[-1]._green; G3 = prRGB_V[+1]._green;
            Vv1 = G2 + (V1 + V3 - G1 - G3)/2;

            // horizontal interpolation
            G1 = prRGB_H[-1]._green; G3 = prRGB_H[+1]._green;
            Vh1 = (V1 + V3)/2 + (2*G2 - G1 - G3)/4;
            Vh1 = Math::elxMedian(V1, V3, Vh1);
          }
                    
          //  V1 
          // [G2] 
          //  V3 
          V1 = prSrc[-w1];
          V3 = prSrc[+w1];
          if (V1 == V3)
            Vh2 = Vv2 = V1;
          else
          {
            // horizontal interpolation
            G1 = prRGB_H[-w1]._green; 
            G3 = prRGB_H[+w1]._green;
            Vh2 = G2 + (V1 + V3 - G1 - G3)/2;

            // vertical interpolation
            G1 = prRGB_V[-w1]._green; 
            G3 = prRGB_V[+w1]._green;
            Vv2 = (V1 + V3)/2 + (2*G2 - G1 - G3)/4;
            Vv2 = Math::elxMedian(V1, V3, Vv2);
          }

          if (Bayer == BM_GBRG)
          {
            prRGB_H->_red  = ResolutionTypeTraits<T>::ClampM(Vh2);
            prRGB_H->_blue = ResolutionTypeTraits<T>::ClampM(Vh1);   

            prRGB_V->_red  = ResolutionTypeTraits<T>::ClampM(Vv2);
            prRGB_V->_blue = ResolutionTypeTraits<T>::ClampM(Vv1);
          }
          else // BM_GRBG
          {
            prRGB_H->_red  = ResolutionTypeTraits<T>::ClampM(Vh1);
            prRGB_H->_blue = ResolutionTypeTraits<T>::ClampM(Vh2);

            prRGB_V->_red  = ResolutionTypeTraits<T>::ClampM(Vv1);
            prRGB_V->_blue = ResolutionTypeTraits<T>::ClampM(Vv2);
          }
          break;
            
        default: // BM_BGGR, BM_RGGB
          //  V0  G   V1
          //  G  [V2] G
          //  V3  G   V4

          V0 = prSrc[-w1-1];  V1 = prSrc[-w1+1];
                        V2 = prSrc[0];
          V3 = prSrc[+w1-1];  V4 = prSrc[+w1+1];
          if ((V0 == V1) && (V1 == V3) && (V3 == V4))
            Vh1 = Vv1 = V0;
          else
          {
            // horizontal interpolation
            G0 = prRGB_H[-w1-1]._green; G1 = prRGB_H[-w1+1]._green;
                        G2 = prRGB_H[0]._green;
            G3 = prRGB_H[+w1-1]._green; G4 = prRGB_H[+w1+1]._green;
            Vh1 = G2 + (V0-G0 + V1-G1 + V3-G3 + V4-G4)/4;

            // vertical interpolation
            G0 = prRGB_V[-w1-1]._green; G1 = prRGB_V[-w1+1]._green;
                        G2 = prRGB_V[0]._green;
            G3 = prRGB_V[+w1-1]._green; G4 = prRGB_V[+w1+1]._green;
            Vv1 = G2 + (V0-G0 + V1-G1 + V3-G3 + V4-G4)/4;
          }

          if (Bayer == BM_BGGR)
          {
            prRGB_H->_blue = prRGB_V->_blue = prSrc[0];

            prRGB_H->_red  = ResolutionTypeTraits<T>::ClampM(Vh1);   
            prRGB_V->_red  = ResolutionTypeTraits<T>::ClampM(Vv1); 
          }
          else // BM_RGGB
          {
            prRGB_H->_red = prRGB_V->_red = prSrc[0];

            prRGB_H->_blue = ResolutionTypeTraits<T>::ClampM(Vh1);   
            prRGB_V->_blue = ResolutionTypeTraits<T>::ClampM(Vv1);
          }
          break;
      }
      Bayer = elxGetBayerRight(Bayer);

      // Fast convert from RGB to CIE Lab
      elxRGBToLab(*prRGB_H, *prLab_H);
      elxRGBToLab(*prRGB_V, *prLab_V);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // no more need of original expanded image
  spImageL.reset();


  //------------------------------------------------------
  // III - Build homogeneity maps from the CIE Lab images
  //------------------------------------------------------
  boost::shared_ptr< ImageImpl< PixelLub > >
    spHomoH( new ImageImpl< PixelLub >(w1,h1, PixelLub::Black()) );
  
  boost::shared_ptr< ImageImpl< PixelLub > >
    spHomoV( new ImageImpl< PixelLub >(w1,h1, PixelLub::Black()) );

  uint8 * prHomoH, * prHomoH2 = (uint8*)spHomoH->GetPixel(border, border);
  uint8 * prHomoV, * prHomoV2 = (uint8*)spHomoV->GetPixel(border, border);
  prLab_H2 = spLab_H->GetPixel(border, border);
  prLab_V2 = spLab_V->GetPixel(border, border);

  uint8 hmV, hmH;
  F L_Epsilon, L_DiffH[4], L_DiffV[4];
  F ab_Epsilon, ab_DiffH[4], ab_DiffV[4];
  const int32 dir[4] = {-1, +1, -w1, +w1};
  int32 i,j;

  for (y=0; y<h; y++, 
      prLab_H2+=w1, prLab_V2+=w1, prHomoH2+=w1, prHomoV2+=w1)
  {
    prLab_H = prLab_H2;
    prLab_V = prLab_V2;
    prHomoH = prHomoH2;
    prHomoV = prHomoV2;
    for (x=0; x<w; x++, 
        prLab_H++, prLab_V++, prHomoH++, prHomoV++)
    {
      // For each pixel in the V and H approximations iterate over its neighbors
      for (i=0; i<4; ++i)
      {
        j = dir[i];
        L_DiffH[i] = Math::elxAbs(prLab_H[0]._luminance - prLab_H[j]._luminance);
        L_DiffV[i] = Math::elxAbs(prLab_V[0]._luminance - prLab_V[j]._luminance);
      }                          
               
      L_Epsilon = Math::elxMin(
        Math::elxMax(L_DiffH[0], L_DiffH[1]), 
        Math::elxMax(L_DiffV[2], L_DiffV[3]));

      for (i=0; i<4; ++i)
      {
        j = dir[i];
        if (L_DiffH[i] <= L_Epsilon || i < 2)
          ab_DiffH[i] = 
            Math::elxSqr(prLab_H[0]._a - prLab_H[j]._a) +
            Math::elxSqr(prLab_H[0]._b - prLab_H[j]._b);
        else
          ab_DiffH[i] = 0;

        if (L_DiffV[i] <= L_Epsilon || i >= 2)
          ab_DiffV[i] = 
            Math::elxSqr(prLab_V[0]._a - prLab_V[j]._a) +
            Math::elxSqr(prLab_V[0]._b - prLab_V[j]._b);
        else
          ab_DiffV[i] = 0;
      }
       
      ab_Epsilon = Math::elxMin(
        Math::elxMax(ab_DiffH[0], ab_DiffH[1]), 
        Math::elxMax(ab_DiffV[2], ab_DiffV[3]));

      // iterate over neighbors
      for (i=0; i<4; ++i) 
      {
        if ((L_DiffH[i] <= L_Epsilon) && (ab_DiffH[i] <= ab_Epsilon))
          prHomoH[0]++;

        if ((L_DiffV[i] <= L_Epsilon) && (ab_DiffV[i] <= ab_Epsilon))
          prHomoV[0]++;
      }
    }

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // no more need of CIE Lab images
  spLab_H.reset();
  spLab_V.reset();


  //--------------------------------------------------------------
  // IV - Combine the most homogenous pixels for the final result
  //--------------------------------------------------------------

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w,h) );

  PixelRGB<T> * prDst = spImageRGB->GetPixel();
  prRGB_H2 = spRGB_H->GetPixel(border,border);
  prRGB_V2 = spRGB_V->GetPixel(border,border);
  prHomoH2 = (uint8*)spHomoH->GetPixel(border,border);
  prHomoV2 = (uint8*)spHomoV->GetPixel(border,border);

  for (y=0; y<h; y++, 
      prRGB_H2+=w1, prRGB_V2+=w1, prHomoH2+=w1, prHomoV2+=w1)
  {
    prRGB_H = prRGB_H2;
    prRGB_V = prRGB_V2;
    prHomoH = prHomoH2;
    prHomoV = prHomoV2;
    for (x=0; x<w; x++, prDst++,
        prRGB_H++, prRGB_V++, prHomoH++, prHomoV++)
    {
      hmH = prHomoH[-w1-1] + prHomoH[-w1] + prHomoH[-w1+1] +
            prHomoH[   -1] + prHomoH[  0] + prHomoH[   +1] +
            prHomoH[+w1-1] + prHomoH[+w1] + prHomoH[+w1+1];

      hmV = prHomoV[-w1-1] + prHomoV[-w1] + prHomoV[-w1+1] +
            prHomoV[   -1] + prHomoV[  0] + prHomoV[   +1] +
            prHomoV[+w1-1] + prHomoV[+w1] + prHomoV[+w1+1];
#if 1
      if (hmV > hmH)
        *prDst = prRGB_V[0];
      else if (hmV < hmH)
        *prDst = prRGB_H[0];
      else
      {
        // no need to clamp this way
        prDst->_red   = (prRGB_H->_red   + prRGB_V->_red  )/2;
        prDst->_green = (prRGB_H->_green + prRGB_V->_green)/2;
        prDst->_blue  = (prRGB_H->_blue  + prRGB_V->_blue )/2;
      }
#else
      // debug homogenous maps
      prDst->_red   = T(8*hmH);
      prDst->_green = (hmH == hmV) ? T(128) : (hmH < hmV) ? T(0) : T(255);
      prDst->_blue  = T(8*hmV);
#endif
    }

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // --- progress end ---
  iNotifier.SetProgress(1.0f);

  return spImageRGB;

} // elxCreateAHD

} // namespace Image
} // namespace eLynx

#endif // __Bayer_AHD_hpp__
