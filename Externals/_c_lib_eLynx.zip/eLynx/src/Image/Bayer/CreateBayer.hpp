//============================================================================
//  Bayer/CreateBayer.hpp                              Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_CreateBayer_hpp__
#define __Bayer_CreateBayer_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateBayer
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelL<T> > > 
  BayerHandlerImpl<T>::CreateBayer(
    const ImageImpl< PixelRGB<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid() || (BM_None == iBayer))
    return boost::shared_ptr< ImageImpl< PixelL<T> > >();

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const PixelRGB<T> * prSrc = iImage.GetPixel();

  // Create output ImageL<T> image
  boost::shared_ptr< ImageImpl< PixelL<T> > >
    spImageL( new ImageImpl< PixelL<T> >(w, h) );
  PixelL<T> * prDst = spImageL->GetPixel();

  uint32 x,y;
  EBayerMatrix Bayer;
  for (y=0; y<h; y++)
  {
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++)
    {
      switch(Bayer)
      {
        case BM_RGGB: *prDst++ = prSrc->_red; break;
        case BM_BGGR: *prDst++ = prSrc->_blue; break;
        default:      *prDst++ = prSrc->_green; break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);
  }
  return spImageL;

} // CreateBayer


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IBayerHandler implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateBayer
//----------------------------------------------------------------------------
template <typename T>
boost::shared_ptr< AbstractImage > BayerHandlerImpl<T>::CreateBayer(
    const AbstractImage& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl< PixelRGB<T> >& image = elxDowncast< PixelRGB<T> >(iImage);
  return CreateBayer(image, iBayer, iNotifier);

} // CreateBayer

} // namespace Image
} // namespace eLynx

#endif // __Bayer_CreateBayer_hpp__
