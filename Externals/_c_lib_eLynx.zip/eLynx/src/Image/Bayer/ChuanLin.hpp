//============================================================================
//  ChuanLin.hpp                                       Image.Component package
//============================================================================
//
//  Pixel Grouping for Color Filter Array Demosaicing
//
//  by Chuan-kai Lin, February 10, 2006 
//  http://web.cecs.pdx.edu/~cklin/demosaic/
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_ChuanLin_hpp__
#define __Bayer_ChuanLin_hpp__

namespace eLynx {
namespace Image {

template<typename T> 
inline
T elxHueTransit(T iL1, T iL2, T iL3, T iV1, T iV3)
{
  if ( ((iL1 < iL2) && (iL2 < iL3)) ||
       ((iL1 > iL2) && (iL2 > iL3)) )
    return (iV1 + (iV3 - iV1) * (iL2 - iL1) / (iL3 - iL1));
  return ((iV1 + iV3)/2 + (2*iL2 - iL1 - iL3)/4 );
}

//----------------------------------------------------------------------------
//  elxCreateChuanLin
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateChuanLin(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;
  enum EDirection { North, East, West, South };

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;

  // --- inits progress ---
  const float ProgressStep = 1.0f / (3*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );

  uint32 x,y;
  T V3,V11,V13,V15,V23, G8,G12,G14,G18;
  M dN,dS,dE,dW,dNE,dNW, g;
  M H,H1,H2, V,V1,V2, G1,G2,G3,G4,G5,G7;
  M B1,B5,R7,R9,B13,R17,R19,B21,B25, G9,G13,G17,G19;
  M R1,R5,B7,B9,R13,B17,B19,R21,R25;
  EDirection min;

  EBayerMatrix Bayer, Original = iBayer;
  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel(border,border);

  //-----------------------------------------------------------------
  // Step I - Interpolation of the green values at blue or red pixels
  //-----------------------------------------------------------------
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          //          V3
          //          G8
          // V11 G12 [V13] G14 V15 
          //          G18
          //          V23
                                  V3  = prSrc[-w2];
                                  G8  = prSrc[-w1];
V11 = prSrc[-2]; G12 = prSrc[-1]; V13 = prSrc[  0]; G14 = prSrc[+1]; V15 = prSrc[+2];
                                  G18 = prSrc[+w1];
                                  V23 = prSrc[+w2];

          dN = 2*Math::elxAbs(V3  - V13) + Math::elxAbs(G8  - G18);
          dS = 2*Math::elxAbs(V13 - V23) + Math::elxAbs(G8  - G18);
          dE = 2*Math::elxAbs(V13 - V15) + Math::elxAbs(G12 - G14);
          dW = 2*Math::elxAbs(V11 - V13) + Math::elxAbs(G12 - G14);

          // looking for min gradient
          if (dN < dS) // dN < dS ? ?
          {
            if (dE < dN) // dE < dN < dS ?
              min = (dW < dE) ? West : East;
            else // dN < dE,dS ?
              min = (dW < dN) ? West : North;
          }
          else // dS < dN ? ?
          {
            if (dE < dS) // dE < dS < dN ?
              min = (dW < dE) ? West : East;
            else // dS < dE,dN ?
              min = (dW < dS) ? West : South;
          }

          if (North == min) 
            g = (3*G8  + V13 + G18 - V3)/4;
          else if (South == min) 
            g = (3*G18 + V13 + G8  - V23)/4;
          else if (East == min) 
            g = (3*G14 + V13 + G12 - V15)/4;
          else // West == min
            g = (3*G12 + V13 + G14 - V11)/4;

          prDst->_green = ResolutionTypeTraits<T>::ClampM(g);
          break;

        default: // BM_GBRG, BM_GRBG
          // G  R  G    G  B  G
          // B [G] B    R [G] R
          // G  R  G    G  B  G
          prDst->_green = prSrc[0];
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //-------------------------------------------------------------------
  // Step II - Interpolation of the blue and red values at green pixels
  //-------------------------------------------------------------------
  prSrcV = (T*)spImageL->GetPixel(border,border);
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;

  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_GBRG: case BM_GRBG:
          //     V1  
          // H1 [G ] H2
          //     V2  
                        V1 = prSrc[-w1];
          H1 = prSrc[-1];              H2 = prSrc[+1];
                        V2 = prSrc[+w1];

                                 G1 = prDst[-w1]._green; 
          G2 = prDst[-1]._green; G3 = prDst[  0]._green; G4 = prDst[+1]._green; 
                                 G5 = prDst[+w1]._green;

          V = elxHueTransit(G1, G3, G5, V1, V2);
          H = elxHueTransit(G2, G3, G4, H1, H2);
         
          if (BM_GBRG == Bayer)
          {
            prDst->_red  = ResolutionTypeTraits<T>::ClampM(V);
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(H);
          }
          else // BM_GRBG 
          {
            prDst->_red  = ResolutionTypeTraits<T>::ClampM(H);
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(V);
          }
          break;

        default: break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //----------------------------------------------------------------------
  // Step III - Interpolation of blue or red values at red or blue pixels
  //----------------------------------------------------------------------
  prSrcV = (T*)spImageL->GetPixel(border,border);
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;

  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR:
          // B1           B5
          //    R7     R9
          //      [B13]
          //    R17    R19
          // B21          B25
          B1  = prSrc[-w2-2];  B5  = prSrc[-w2+2];
          R7  = prSrc[-w1-1];  R9  = prSrc[-w1+1];
                        B13 = prSrc[0];
          R17 = prSrc[+w1-1];  R19 = prSrc[+w1+1];
          B21 = prSrc[+w2-2];  B25 = prSrc[+w2+2];

          G7  = prDst[-w1-1]._green;  G9  = prDst[-w1+1]._green;
                          G13 = prDst[0]._green;
          G17 = prDst[+w1-1]._green;  G19 = prDst[+w1+1]._green;

          dNE = Math::elxAbs(R9-R17) + 
                Math::elxAbs(B5-B13) + Math::elxAbs(B13-B21) +
                Math::elxAbs(G9-G13) + Math::elxAbs(G13-G17);

          dNW = Math::elxAbs(R7-R19) + 
                Math::elxAbs(B1-B13) + Math::elxAbs(B13-B25) +
                Math::elxAbs(G7-G13) + Math::elxAbs(G13-G19);
          
          if (dNE <= dNW)
            V = elxHueTransit(G9, G13, G17, R9, R17);
          else 
            V = elxHueTransit(G7, G13, G19, R7, R19);

          prDst->_red  = ResolutionTypeTraits<T>::ClampM(V);
          prDst->_blue = prSrc[0];
          break;

        case BM_RGGB:
          // R1           R5
          //    B7     B9
          //      [R13]
          //    B17    B19
          // R21          R25
          R1  = prSrc[-w2-2];  R5  = prSrc[-w2+2];
          B7  = prSrc[-w1-1];  B9  = prSrc[-w1+1];
                      R13 = prSrc[0];
          B17 = prSrc[+w1-1];  B19 = prSrc[+w1+1];
          R21 = prSrc[+w2-2];  R25 = prSrc[+w2+2];

          G7  = prDst[-w1-1]._green;  G9  = prDst[-w1+1]._green;
                          G13 = prDst[0]._green;
          G17 = prDst[+w1-1]._green;  G19 = prDst[+w1+1]._green;

          dNE = Math::elxAbs(B9-B17) + 
                Math::elxAbs(R5-R13) + Math::elxAbs(R13-R21) +
                Math::elxAbs(G9-G13) + Math::elxAbs(G13-G17);

          dNW = Math::elxAbs(B7-B19) + 
                Math::elxAbs(R1-R13) + Math::elxAbs(R13-R25) +
                Math::elxAbs(G7-G13) + Math::elxAbs(G13-G19);
          
          if (dNE <= dNW)
            V = elxHueTransit(G9, G13, G17, B9, B17);
          else 
            V = elxHueTransit(G7, G13, G19, B7, B19);

          prDst->_red  = prSrc[0];
          prDst->_blue = ResolutionTypeTraits<T>::ClampM(V);
          break;

        default: break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  spImageL.reset();
  return ImageGeometryImpl< PixelRGB<T> >::CreateSubImage(*spImageRGB, border,border, w,h);

} // elxCreateChuanLin

} // namespace Image
} // namespace eLynx

#endif // __Bayer_ChuanLin_hpp__
