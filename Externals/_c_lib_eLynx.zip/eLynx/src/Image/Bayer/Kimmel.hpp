//============================================================================
//  Kimmel.hpp                                         Image.Component package
//============================================================================
//
//  Image reconstruction from color ccd samples
//
//  by Ron Kimmel, 1999
//  http://citeseer.ist.psu.edu/kimmel99demosaicing.html
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Kimmel_hpp__
#define __Bayer_Kimmel_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateKimmel
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateKimmel(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    uint32 iIterations = 3,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;

  const F c = F(1) / Math::elxSqrt(F(8));
  const F Epsilon = F(1) / F(255);

  // --- inits progress ---
  const float ProgressStep = 1.0f / ((3+2*iIterations)*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create temporaly #1 ImageRGB<F> image
  boost::shared_ptr< ImageImpl< PixelRGB<F> > > 
    spImageRGBTmp1(new ImageImpl< PixelRGB<F> >(w1,h1,PixelRGB<F>::Black()));
 
  uint32 x,y;
  EBayerMatrix Bayer, Original = iBayer;
  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<F> * prTmp1, * prTmp1V = spImageRGBTmp1->GetPixel(border,border);

  //-------------------------------------------------------
  // Step I - interpolation of green plane for whole image
  //-------------------------------------------------------
  {
    F V1,G2,V3,G4,V5,G6,V7,G8,V9;
    F E2,E4,E6,E8, Dx5,Dy5;

    for (y=0; y<h; y++, prSrcV+=w1, prTmp1V+=w1)
    {
      prSrc = prSrcV;
      prTmp1 = prTmp1V;
      Bayer = iBayer;
      for (x=0; x<w; x++, prSrc++, prTmp1++)
      {
        switch (Bayer)
        {
          case BM_BGGR: case BM_RGGB:
            //        V1
            //        G2  
            // V3 G4 [V5] G6 V7  
            //        G8  
            //        V9
                                V1 = prSrc[-w2];
                                G2 = prSrc[-w1];
V3 = prSrc[-2]; G4 = prSrc[-1]; V5 = prSrc[  0]; G6 = prSrc[+1]; V7 = prSrc[+2];
                                G8 = prSrc[+w1];
                                V9 = prSrc[+w2];
        
            Dx5 = (G4 - G6)*(G4 - G6);
            Dy5 = (G2 - G8)*(G2 - G8);
            
            E2 = F(0.5) / Math::elxSqrt( 4 + Dy5 + (V1 - V5)*(V1 - V5) );
            E4 = F(0.5) / Math::elxSqrt( 4 + Dx5 + (V3 - V5)*(V3 - V5) );
            E6 = F(0.5) / Math::elxSqrt( 4 + Dx5 + (V7 - V5)*(V7 - V5) );
            E8 = F(0.5) / Math::elxSqrt( 4 + Dy5 + (V9 - V5)*(V9 - V5) );

            prTmp1->_green = (E2*G2 + E4*G4 + E6*G6 + E8*G8) /
                                  (E2 + E4 + E6 + E8);
            break;

          default: // BM_GRBG, BM_GBRG
            // green plane is direct value
            prTmp1->_green = prSrc[0];
            break;
        }
        Bayer = elxGetBayerRight(Bayer);
      }
      iBayer = elxGetBayerDown(iBayer);

      // --- in progress ... ---
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }
  }

  //-------------------------------------------------------
  // Step II - interpolation of red/blue plane at blue/red
  //-------------------------------------------------------
  prSrcV = (T*)spImageL->GetPixel(border,border);
  prTmp1V = spImageRGBTmp1->GetPixel(border,border);
  iBayer = Original;
  {
    F V1,V2,V3,V4,V5,V6,V7,V8,V9;
    F G3,G4,G5,G6,G7, E3,E4,E6,E7;
    F Dxd,Dyd, s,v;
    for (y=0; y<h; y++, prSrcV+=w1, prTmp1V+=w1)
    {
      prSrc = prSrcV;
      prTmp1 = prTmp1V;
      Bayer = iBayer;
      for (x=0; x<w; x++, prSrc++, prTmp1++)
      {
        switch (Bayer)
        {
          case BM_BGGR: case BM_RGGB:
            // V1        V2
            //   v3    v4
            //     [V5]
            //   v6    v7
            // V8        V9

            V1 = prSrc[-w2-2];                  V2 = prSrc[-w2+2];
                 V3 = prSrc[-w1-1];        V4 = prSrc[-w1+1];
                              V5 = prSrc[0];
                 V6 = prSrc[+w1-1];        V7 = prSrc[+w1+1];
            V8 = prSrc[+w2-1];                  V9 = prSrc[+w2+1];

            G5 = prTmp1[0]._green;
            if (G5 < Epsilon)
            {
              // color ratio is invalid, use bilinear interpolation
              v = (V3 + V4 + V6 + V7)/4;
            }
            else
            {
              Dyd = (V7 - V3)*(V7 - V3);
              Dxd = (V6 - V4)*(V6 - V4);
              
              E3 = c / Math::elxSqrt( 8 + Dyd + (V1 - V5)*(V1 - V5) );
              E4 = c / Math::elxSqrt( 8 + Dxd + (V2 - V5)*(V2 - V5) );
              E7 = c / Math::elxSqrt( 8 + Dyd + (V9 - V5)*(V9 - V5) );
              E6 = c / Math::elxSqrt( 8 + Dxd + (V8 - V5)*(V8 - V5) );

              s =  G5 / (E3 + E4 + E6 + E7);

              G3 = prTmp1[-w1-1]._green; G4 = prTmp1[-w1+1]._green;
              G6 = prTmp1[+w1-1]._green; G7 = prTmp1[+w1+1]._green;

              // prevents from division by 0
              if (F(0) != G3) E3 /= G3;
              if (F(0) != G4) E4 /= G4;
              if (F(0) != G6) E6 /= G6;
              if (F(0) != G7) E7 /= G7;

              v = s * (E3*V3 + E4*V4 + E6*V6 + E7*V7);
            }

            if (Bayer == BM_BGGR)
            {
              prTmp1->_red  = v;
              prTmp1->_blue = prSrc[0];
            }
            else // BM_RGGB
            {
              prTmp1->_red  = prSrc[0];
              prTmp1->_blue = v;
            }
            break;

          default: break;
        }
        Bayer = elxGetBayerRight(Bayer);
      }
      iBayer = elxGetBayerDown(iBayer);

      // --- in progress ... ---
      Progress += ProgressStep;
      iNotifier.SetProgress(Progress);
    }
  }

  //-----------------------------------------------------
  // Step III - interpolation of red/blue plane at green
  //-----------------------------------------------------
  prTmp1V = spImageRGBTmp1->GetPixel(border,border);
  iBayer = Original;
  {
    F G1,G2,G3,G4,G5,G6,G7,G8,G9;
    F B2,B4,B6,B8,EB2,EB4,EB6,EB8; 
    F R2,R4,R6,R8,ER2,ER4,ER6,ER8;
    F DxG4,DxG6,DyG2,DyG8,DxR,DyR,DxB,DyB, sR,sB;
    for (y=0; y<h; y++, prTmp1V+=w1)
    {
      prTmp1 = prTmp1V;
      Bayer = iBayer;
      for (x=0; x<w; x++, prTmp1++)
      {
        switch (Bayer)
        {
          case BM_GRBG:           case BM_GBRG: 
            //        G1                 G1
            //        B2                 R2  
            // G3 R4 [G5] R6 G7   G3 B4 [G5] B6 G7
            //        B8                 R8  
            //        G9                 G9

            G5 = prTmp1[0]._green;
            if (G5 < Epsilon)
            {
              // color ratio is invalid, use bilinear interpolation
                            R2 = prTmp1[-w1]._red;
              R4 = prTmp1[-1]._red; R6 = prTmp1[+1]._red;
                            R8 = prTmp1[+w1]._red;
              prTmp1->_red  = (R2 + R4 + R6 + R8)/4;

                          B2 = prTmp1[-w1]._blue;
              B4 = prTmp1[-1]._blue; B6 = prTmp1[+1]._blue;
                          B8 = prTmp1[+w1]._blue;
              prTmp1->_blue = (B2 + B4 + B6 + B8)/4;
            }
            else
            {
                                      G1 = prTmp1[-w2]._green;
                                      G2 = prTmp1[-w1]._green;
G3 = prTmp1[-2]._green; G4 = prTmp1[-1]._green;  G6 = prTmp1[+1]._green; G7 = prTmp1[+2]._green;
                                      G8 = prTmp1[+w1]._green;
                                      G9 = prTmp1[+w2]._green;
              DxG4 = (G1 - G5)*(G1 - G5);
              DxG6 = (G7 - G5)*(G7 - G5);
              DyG2 = (G1 - G5)*(G1 - G5);
              DyG8 = (G9 - G5)*(G9 - G5);

              // red
                            R2 = prTmp1[-w1]._red;
              R4 = prTmp1[-1]._red; R6 = prTmp1[+1]._red;
                            R8 = prTmp1[+w1]._red;

              DxR = (R4 - R6)*(R4 - R6);
              DyR = (R2 - R8)*(R2 - R8);

              ER4 = F(0.5) / Math::elxSqrt( 4 + DxR + DxG4 );
              ER6 = F(0.5) / Math::elxSqrt( 4 + DxR + DxG6 );
              ER2 = F(0.5) / Math::elxSqrt( 4 + DyR + DyG2 );
              ER8 = F(0.5) / Math::elxSqrt( 4 + DyR + DyG8 );

              sR =  G5 / (ER2 + ER4 + ER6 + ER8);

              // blue
                          B2 = prTmp1[-w1]._blue;
              B4 = prTmp1[-1]._blue; B6 = prTmp1[+1]._blue;
                          B8 = prTmp1[+w1]._blue;

              DxB = (B4 - B6)*(B4 - B6);
              DyB = (B2 - B8)*(B2 - B8);

              EB4 = F(0.5) / Math::elxSqrt( 4 + DxB + DxG4 );
              EB6 = F(0.5) / Math::elxSqrt( 4 + DxB + DxG6 );
              EB2 = F(0.5) / Math::elxSqrt( 4 + DyB + DyG2 );
              EB8 = F(0.5) / Math::elxSqrt( 4 + DyB + DyG8 );

              sB =  G5 / (EB2 + EB4 + EB6 + EB8);

              // prevents from division by 0
              if (F(0) != G2) { ER2 /= G2; EB2 /= G2; }
              if (F(0) != G4) { ER4 /= G4; EB4 /= G4; }
              if (F(0) != G6) { ER6 /= G6; EB6 /= G6; }
              if (F(0) != G8) { ER8 /= G8; EB8 /= G8; }

              prTmp1->_red  = sR * (ER2*R2 + ER4*R4 + ER6*R6 + ER8*R8);
              prTmp1->_blue = sB * (EB2*B2 + EB4*B4 + EB6*B6 + EB8*B8);
            }
            break;

          default: break;
        }
        Bayer = elxGetBayerRight(Bayer);
      }
      iBayer = elxGetBayerDown(iBayer);
    }
    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
  
  // no more need if source copy
  spImageL.reset();

  if (0 != iIterations)
  {
    //------------------------------------------------------
    // Step IV - Post-processing corrections
    //------------------------------------------------------

    // We need a new temporary image to store updated correction

    // Create temporaly #2 ImageRGB<F> image
    boost::shared_ptr< ImageImpl< PixelRGB<F> > > 
      spImageRGBTmp2(new ImageImpl< PixelRGB<F> >(w1,h1));

    // copy tmp1 into tmp2 image
    PixelRGB<F> * prTmp2V, * prTmp2 = spImageRGBTmp2->GetPixel();
    prTmp1 = spImageRGBTmp1->GetPixel();
    ::memcpy(prTmp2, prTmp1, w1*h1*sizeof(PixelRGB<F>));

    for (uint32 n=0; n<iIterations; n++) 
    {
      //-----------------------------------------------------
      // Step IV.a - correct the green to fit the ratio rule
      //-----------------------------------------------------

      prTmp1V = spImageRGBTmp1->GetPixel(border,border);
      prTmp2V = spImageRGBTmp2->GetPixel(border,border);
      iBayer = Original;
      {
        F G4,G5,G6,G8,G10,G12,G13,G14;
        F V1,V2,V3,V4,V5,V6,V7,V8,V9,V10,V11,V12,V13,V14,V15,V16,V17;
        F E4,E5,E6,E8,E10,E12,E13,E14;
        F Dx,Dy,Dyd,Dxd,s, Gb,Gr;
        for (y=0; y<h; y++, prTmp1V+=w1, prTmp2V+=w1)
        {
          prTmp1 = prTmp1V;
          prTmp2 = prTmp2V;
          Bayer = iBayer;
          for (x=0; x<w; x++, prTmp1++, prTmp2++)
          {
            switch (Bayer)
            {
              case BM_BGGR: case BM_RGGB:
                // correct green at blue and red

                // V1      V2      V3
                //    V4   G5  V6
                // V7 G8  [V9] G10 V11 
                //    V12  G13 V14
                // V15     V16     V17
G4  = prTmp1[-w1-1]._green; G5  = prTmp1[-w1]._green; G6  = prTmp1[-w1+1]._green;
G8  = prTmp1[   -1]._green;                           G10 = prTmp1[   +1]._green;
G12 = prTmp1[+w1-1]._green; G13 = prTmp1[+w1]._green; G14 = prTmp1[+w1+1]._green;

                // green from red
                V9  = prTmp1[0]._red;
                if (V9 < Epsilon)
                {
                  // keep unchanged as ratio is invalid 
                  Gr = prTmp1[0]._green;
                }
                else
                {
V1  = prTmp1[-w2-2]._red;                           V2  = prTmp1[-w2]._red;                           V3  = prTmp1[-w2+2]._red;
                          V4  = prTmp1[-w1-1]._red; V5  = prTmp1[-w1]._red; V6  = prTmp1[-w1+1]._red;
V7  = prTmp1[   -2]._red; V8  = prTmp1[   -1]._red;                         V10 = prTmp1[   +1]._red; V11 = prTmp1[   +2]._red;
                          V12 = prTmp1[+w1-1]._red; V13 = prTmp1[+w1]._red; V14 = prTmp1[+w1+1]._red;
V15 = prTmp1[+w2-2]._red;                           V16 = prTmp1[+w2]._red;                           V17 = prTmp1[+w2+2]._red;

                  Dx  = (V8 - V10)*(V8 - V10);
                  Dy  = (V5 - V13)*(V5 - V13);
                  E8  = F(0.5) / Math::elxSqrt( 4 + Dx  + (V7  - V9)*(V7  - V9) );
                  E10 = F(0.5) / Math::elxSqrt( 4 + Dx  + (V11 - V9)*(V11 - V9) );
                  E5  = F(0.5) / Math::elxSqrt( 4 + Dy  + (V2  - V9)*(V2  - V9) );
                  E13 = F(0.5) / Math::elxSqrt( 4 + Dy  + (V16 - V9)*(V16 - V9) );

                  Dyd = (V4 - V14)*(V4 - V14);
                  Dxd = (V6 - V12)*(V6 - V12);
                  E4  = c / Math::elxSqrt( 8 + Dyd + (V1  - V9)*(V1  - V9) );
                  E14 = c / Math::elxSqrt( 8 + Dyd + (V17 - V9)*(V17 - V9) );
                  E6  = c / Math::elxSqrt( 8 + Dxd + (V3  - V9)*(V3  - V9) );
                  E12 = c / Math::elxSqrt( 8 + Dxd + (V15 - V9)*(V15 - V9) );

                  s = V9 / (E4 + E5 + E6 + E8 + E10 + E12 + E13 + E14);

                  // prevents from division by 0
                  if (V5  > Epsilon) E5  /= V5;
                  if (V8  > Epsilon) E8  /= V8;
                  if (V10 > Epsilon) E10 /= V10;
                  if (V13 > Epsilon) E13 /= V13;
                  if (V4  > Epsilon) E4  /= V4;
                  if (V6  > Epsilon) E6  /= V6;
                  if (V12 > Epsilon) E12 /= V12;
                  if (V14 > Epsilon) E14 /= V14;

                  Gr = s * (E4*G4 + E5*G5 + E6*G6 + E8*G8 + E10*G10 + E12*G12 + E13*G13 + E14*G14);
                }

                // green from blue
                V9  = prTmp1[0]._blue;
                if (V9 < Epsilon)
                {
                  // keep unchanged as ratio is invalid 
                  Gb = prTmp1[0]._green;
                }
                else
                {
V1  = prTmp1[-w2-2]._blue;                            V2  = prTmp1[-w2]._blue;                            V3  = prTmp1[-w2+2]._blue;
                           V4  = prTmp1[-w1-1]._blue; V5  = prTmp1[-w1]._blue; V6  = prTmp1[-w1+1]._blue;
V7  = prTmp1[   -2]._blue; V8  = prTmp1[   -1]._blue;                          V10 = prTmp1[   +1]._blue; V11 = prTmp1[   +2]._blue;
                           V12 = prTmp1[+w1-1]._blue; V13 = prTmp1[+w1]._blue; V14 = prTmp1[+w1+1]._blue;
V15 = prTmp1[+w2-2]._blue;                            V16 = prTmp1[+w2]._blue;                            V17 = prTmp1[+w2+2]._blue;

                  Dx  = (V8 - V10)*(V8 - V10);
                  Dy  = (V5 - V13)*(V5 - V13);
                  E8  = F(0.5) / Math::elxSqrt( 4 + Dx  + (V7  - V9)*(V7  - V9) );
                  E10 = F(0.5) / Math::elxSqrt( 4 + Dx  + (V11 - V9)*(V11 - V9) );
                  E5  = F(0.5) / Math::elxSqrt( 4 + Dy  + (V2  - V9)*(V2  - V9) );
                  E13 = F(0.5) / Math::elxSqrt( 4 + Dy  + (V16 - V9)*(V16 - V9) );

                  Dyd = (V4 - V14)*(V4 - V14);
                  Dxd = (V6 - V12)*(V6 - V12);
                  E4  = c / Math::elxSqrt( 8 + Dyd + (V1  - V9)*(V1  - V9) );
                  E14 = c / Math::elxSqrt( 8 + Dyd + (V17 - V9)*(V17 - V9) );
                  E6  = c / Math::elxSqrt( 8 + Dxd + (V3  - V9)*(V3  - V9) );
                  E12 = c / Math::elxSqrt( 8 + Dxd + (V15 - V9)*(V15 - V9) );

                  s = V9 / (E4 + E5 + E6 + E8 + E10 + E12 + E13 + E14);

                  // prevents from division by 0
                  if (V5  > Epsilon) E5  /= V5;
                  if (V8  > Epsilon) E8  /= V8;
                  if (V10 > Epsilon) E10 /= V10;
                  if (V13 > Epsilon) E13 /= V13;
                  if (V4  > Epsilon) E4  /= V4;
                  if (V6  > Epsilon) E6  /= V6;
                  if (V12 > Epsilon) E12 /= V12;
                  if (V14 > Epsilon) E14 /= V14;

                  Gb = s * (E4*G4 + E5*G5 + E6*G6 + E8*G8 + E10*G10 + E12*G12 + E13*G13 + E14*G14);
                }

                // updated green
                prTmp2->_green = (Gr + Gb)/2;
                break;

              default: break;
            }
            Bayer = elxGetBayerRight(Bayer);
          }
          iBayer = elxGetBayerDown(iBayer);

          // --- in progress ... ---
          Progress += ProgressStep;
          iNotifier.SetProgress(Progress);
        }
      }

      //-------------------------------------------------------
      // Step IV.b - correct the blue and red values via 
      //             the ratio rule weighted by edge indicator
      //-------------------------------------------------------
      prTmp1V = spImageRGBTmp1->GetPixel(border,border);
      prTmp2V = spImageRGBTmp2->GetPixel(border,border);
      iBayer = Original;
      {
        F G1,G2,G3,G4,G6,G5,G8,G7,G9,G10,G11,G12,G13,G14,G15,G16,G17;
        F E4,E5,E6,E8,E10,E12,E13,E14;
        F V4,V5,V6,V8,V10,V12,V13,V14;
        F Dx,Dy,Dyd,Dxd,s;
        bool bRed, bBlue; 
        for (y=0; y<h; y++, prTmp1V+=w1, prTmp2V+=w1)
        {
          prTmp1 = prTmp1V;
          prTmp2 = prTmp2V;
          Bayer = iBayer;
          for (x=0; x<w; x++, prTmp1++, prTmp2++)
          {
            // correct blue and red using green

            bRed  = Bayer != BM_RGGB; // do not correct at red
            bBlue = Bayer != BM_BGGR; // do not correct at blue

            // G1      G2      G3
            //    G4   G5  G6
            // G7 G8  [G9] G10 G11 
            //    G12  G13 G14
            // G15     G16     G17
            G9 = prTmp2[0]._green;
            if (G9 < Epsilon)
            {
              // keep unchanged as ratio is invalid 
              if (bRed)
                prTmp2->_red = prTmp1[0]._red;

              if (bBlue)
                prTmp2->_blue = prTmp2[0]._blue;
            }
            else
            {
G1  = prTmp2[-w2-2]._green;                             G2  = prTmp2[-w2]._green;                             G3  = prTmp2[-w2+2]._green;
                            G4  = prTmp2[-w1-1]._green; G5  = prTmp2[-w1]._green; G6  = prTmp2[-w1+1]._green;
G7  = prTmp2[   -2]._green; G8  = prTmp2[   -1]._green;                           G10 = prTmp2[   +1]._green; G11 = prTmp2[   +2]._green;
                            G12 = prTmp2[+w1-1]._green; G13 = prTmp2[+w1]._green; G14 = prTmp2[+w1+1]._green;
G15 = prTmp2[+w2-2]._green;                             G16 = prTmp2[+w2]._green;                             G17 = prTmp2[+w2+2]._green;

              Dx  = (G8 - G10)*(G8 - G10);
              Dy  = (G5 - G13)*(G5 - G13);

              E8  = F(0.5) / Math::elxSqrt( 4 + Dx  + (G7  - G9)*(G7  - G9) );
              E10 = F(0.5) / Math::elxSqrt( 4 + Dx  + (G11 - G9)*(G11 - G9) );
              E5  = F(0.5) / Math::elxSqrt( 4 + Dy  + (G2  - G9)*(G2  - G9) );
              E13 = F(0.5) / Math::elxSqrt( 4 + Dy  + (G16 - G9)*(G16 - G9) );

              Dxd = Math::elxMax( Math::elxAbs(G6 - G9), Math::elxAbs(G12 - G9) );
              Dyd = Math::elxMax( Math::elxAbs(G4 - G9), Math::elxAbs(G14 - G9) );
              Dxd = 4 * Dxd * Dxd;
              Dyd = 4 * Dyd * Dyd;

              E4  = c / Math::elxSqrt( 8 + Dyd + (G1  - G9)*(G1  - G9) );
              E14 = c / Math::elxSqrt( 8 + Dyd + (G17 - G9)*(G17 - G9) );
              E6  = c / Math::elxSqrt( 8 + Dxd + (G3  - G9)*(G3  - G9) );
              E12 = c / Math::elxSqrt( 8 + Dxd + (G15 - G9)*(G15 - G9) );

              s = G9 / (E4 + E5 + E6 + E8 + E10 + E12 + E13 + E14);

              // prevents from division by 0
              if (F(0) != G4)  E4  /= G4;
              if (F(0) != G5)  E5  /= G5;
              if (F(0) != G6)  E6  /= G6;
              if (F(0) != G8)  E8  /= G8;
              if (F(0) != G10) E10 /= G10;
              if (F(0) != G12) E12 /= G12;
              if (F(0) != G13) E13 /= G13;
              if (F(0) != G14) E14 /= G14;

              if (bRed)
              {
                V4  = prTmp1[-w1-1]._red; V5  = prTmp1[-w1]._red; V6  = prTmp1[-w1+1]._red;
                V8  = prTmp1[   -1]._red;                         V10 = prTmp1[   +1]._red;
                V12 = prTmp1[+w1-1]._red; V13 = prTmp1[+w1]._red; V14 = prTmp1[+w1+1]._red;

                prTmp2->_red = s * (E4*V4 + E5*V5 + E6*V6 + E8*V8 + 
                                E10*V10 + E12*V12 + E13*V13 + E14*V14);
              }

              if (bBlue)
              {
                V4  = prTmp1[-w1-1]._blue; V5  = prTmp1[-w1]._blue; V6  = prTmp1[-w1+1]._blue;
                V8  = prTmp1[   -1]._blue;                          V10 = prTmp1[   +1]._blue;
                V12 = prTmp1[+w1-1]._blue; V13 = prTmp1[+w1]._blue; V14 = prTmp1[+w1+1]._blue;

                prTmp2->_blue = s * (E4*V4 + E5*V5 + E6*V6 + E8*V8 + 
                                 E10*V10 + E12*V12 + E13*V13 + E14*V14);
              }
            }
            Bayer = elxGetBayerRight(Bayer);
          }
          iBayer = elxGetBayerDown(iBayer);

          // --- in progress ... ---
          Progress += ProgressStep;
          iNotifier.SetProgress(Progress);
        }
      }

      // updated image is in tmp #2, swap buffers
      spImageRGBTmp1.swap(spImageRGBTmp2);
    }

    // no more need of tmp #2 image
    spImageRGBTmp2.reset();
  }

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w,h) );

  // back to T resolution with border cropping
  prTmp1V = spImageRGBTmp1->GetPixel(border,border);
  PixelRGB<T> * prDst = spImageRGB->GetPixel();
  for (y=0; y<h; y++, prTmp1V+=w1)
  {
    prTmp1 = prTmp1V;
    for (x=0; x<w; x++, prTmp1++, prDst++)
    {
      prDst->_red   = ResolutionTypeTraits<T>::ClampF( prTmp1->_red );
      prDst->_green = ResolutionTypeTraits<T>::ClampF( prTmp1->_green );
      prDst->_blue  = ResolutionTypeTraits<T>::ClampF( prTmp1->_blue );
    }
  }

  // no more need of tmp1 image
  spImageRGBTmp1.reset();

  return spImageRGB;

} // elxCreateKimmel

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Kimmel_hpp__
