//============================================================================
//  HamiltonAdams.hpp                                  Image.Component package
//============================================================================
//
//  Hamilton and Adams implementation's 
//
//  http://www-ise.stanford.edu/~tingchen/algodep/corrI.html
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_HamiltonAdams_hpp__
#define __Bayer_HamiltonAdams_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateHamiltonAdams
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateHamiltonAdams(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;

  // --- inits progress ---
  const float ProgressStep = 1.0f / (3*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );

  M V1,G2,V3,G4,V5,G6,V7,G8,V9,G1,G3,G5;
  M R1,R2,R4,R5,B1,B2,B4,B5;
  M r,g,b, dX,dY, muX,muY;
  uint32 x,y;

  EBayerMatrix Bayer, Original = iBayer;
  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel(border,border);

  //-------------------------------------------------------
  // Step I - interpolation of green plane for whole image
  //-------------------------------------------------------
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          //         V1
          //         G2
          //  V3 G4 [V5] G6 V7
          //         G8
          //         V9
                                  V1 = prSrc[-w2];
                                  G2 = prSrc[-w1];
  V3 = prSrc[-2]; G4 = prSrc[-1]; V5 = prSrc[  0]; G6 = prSrc[+1]; V7 = prSrc[+2]; 
                                  G8 = prSrc[+w1];
                                  V9 = prSrc[+w2];

          muX = V5 - V3 + V5 - V7;
          muY = V5 - V1 + V5 - V9;
          dX = Math::elxAbs(G4 - G6) + Math::elxAbs(muX);
          dY = Math::elxAbs(G2 - G8) + Math::elxAbs(muY);

          if (dX == dY)
          {
            g = (G2 + G8 + G4 + G6)/4 + (muX + muY)/8;
          }
          else if (dX < dY)
          {
            g = (G4 + G6)/2 + muX/4;
          }
          else // (dX > dY)
          {
            g = (G2 + G8)/2 + muY/4;
          }

          prDst->_green = ResolutionTypeTraits<T>::ClampM(g);
          break;

        default:
          // Green plane is direct value
          prDst->_green = prSrc[0];
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //----------------------------------------------------
  // Step II - interpolation of red/blue plane at green
  //----------------------------------------------------
  prSrcV = (T*)spImageL->GetPixel(border,border);
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_GBRG:
          //      R1
          //  B2 [G3] B4
          //      R5
                         G1 = prDst[-w1]._green;
  G2 = prDst[-1]._green; G3 = prDst[  0]._green; G4 = prDst[+1]._green;
                         G5 = prDst[+w1]._green;

                         R1 = prSrc[-w1];
          B2 = prSrc[-1];                B4 = prSrc[+1];
                         R5 = prSrc[+w1];

          r = (R1 + R5)/2 + (G3 - G1 + G3 - G5)/4;
          b = (B2 + B4)/2 + (G3 - G2 + G3 - G4)/4;

          prDst->_red  = ResolutionTypeTraits<T>::ClampM(r);
          prDst->_blue = ResolutionTypeTraits<T>::ClampM(b);
          break;

        case BM_GRBG:
          //      B1
          //  R2 [G3] R4
          //      B5
                         G1 = prDst[-w1]._green;
  G2 = prDst[-1]._green; G3 = prDst[  0]._green; G4 = prDst[+1]._green;
                         G5 = prDst[+w1]._green;

                         B1 = prSrc[-w1];
          R2 = prSrc[-1];                R4 = prSrc[+1];
                         B5 = prSrc[+w1];

          r = (R2 + R4)/2 + (G3 - G2 + G3 - G4)/4;
          b = (B1 + B5)/2 + (G3 - G1 + G3 - G5)/4;

          prDst->_red  = ResolutionTypeTraits<T>::ClampM(r);
          prDst->_blue = ResolutionTypeTraits<T>::ClampM(b);
          break;

        case BM_RGGB:
          prDst->_red  = prSrc[0];
          break;

        case BM_BGGR:
          prDst->_blue = prSrc[0];
          break;

        default: break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //--------------------------------------------------------
  // Step III - interpolation of red/blue plane at blue/red
  //--------------------------------------------------------
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prDstV+=w1)
  {
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: 
          //      G1
          //  G2 [B3] G4
          //      G5
                         G1 = prDst[-w1]._green;
  G2 = prDst[-1]._green; G3 = prDst[  0]._green; G4 = prDst[+1]._green;
                         G5 = prDst[+w1]._green;

                         R1 = prDst[-w1]._red;
  R2 = prDst[-1]._red;                           R4 = prDst[+1]._red;
                         R5 = prDst[+w1]._red;

          muX = G3 - G2 + G3 - G4;
          muY = G3 - G1 + G3 - G5;
          dX = Math::elxAbs(R2 - R4) + Math::elxAbs(muX);
          dY = Math::elxAbs(R1 - R5) + Math::elxAbs(muY);

          if (dX == dY)
          {
            r = (R1 + R2 + R4 + R5 + muX + muY)/4;
          }
          else if (dX < dY)
          {
            r = (R2 + R4 + muX)/2;
          }
          else // (dX > dY)
          {
            r = (R1 + R5 + muY)/2;
          }

          prDst->_red = ResolutionTypeTraits<T>::ClampM(r);
          break;

        case BM_RGGB:
          //      G1
          //  G2 [R3] G4
          //      G5
                         G1 = prDst[-w1]._green;
  G2 = prDst[-1]._green; G3 = prDst[  0]._green; G4 = prDst[+1]._green;
                         G5 = prDst[+w1]._green;

                         B1 = prDst[-w1]._blue;
  B2 = prDst[-1]._blue;                          B4 = prDst[+1]._blue;
                         B5 = prDst[+w1]._blue;

          muX = G3 - G2 + G3 - G4;
          muY = G3 - G1 + G3 - G5;
          dX = Math::elxAbs(B2 - B4) + Math::elxAbs(muX);
          dY = Math::elxAbs(B1 - B5) + Math::elxAbs(muY);

          if (dX == dY)
          {
            b = (B1 + B2 + B4 + B5 + muX + muY)/4;
          }
          else if (dX < dY)
          {
            b = (B2 + B4 + muX)/2;
          }
          else // (dX > dY)
          {
            b = (B1 + B5 + muY)/2;
          }

          prDst->_blue = ResolutionTypeTraits<T>::ClampM(b);
          break;

        default: break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  spImageL.reset();
  return ImageGeometryImpl< PixelRGB<T> >::CreateSubImage(*spImageRGB, border,border, w,h);

} // elxCreateHamiltonAdams

} // namespace Image
} // namespace eLynx

#endif // __Bayer_HamiltonAdams_hpp__
