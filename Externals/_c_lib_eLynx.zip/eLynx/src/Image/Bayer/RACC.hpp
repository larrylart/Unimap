//============================================================================
//  RACC.hpp                                           Image.Component package
//============================================================================
//
//  Region Adaptive Color Demosaicing Algorithm using Color Constancy
//
//  by Chang Won Kim, Hyun Mook Oh, Du Sic Yoo, and Moon Gi Kang
//  http://www.hindawi.com/journals/asp/2010/271078.html
//  http://downloads.hindawi.com/journals/asp/2010/271078.pdf
//----------------------------------------------------------------------------
//  Copyright (C) 2010 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_RACC_hpp__
#define __Bayer_RACC_hpp__

namespace eLynx {
namespace Image {

namespace {

enum ERegion { Normal, Flat, Pattern };

template<typename T>
struct SuperPixel
{ 
  SuperPixel() : _r(0), _g(0), _b(0) {}

  // V means red/blue at red/blue
  // A means missing red/blue at blue/red
  // SSC = Spectral and Spatial Correlation

  // final RGB value built at different moments
  T _r, _g, _b;
  
  // region classification v=vertical, h=horizontal, g=flat/pattern/normal
  T _Dv, _Dh, _Dg;
  ERegion _region;

  // chrominance values
  T _Kr, _Kb;

  // t=top, b=bottom, l=left, r=right
  T _Gt, _Gb, _Gl, _Gr;
  T _DGRt, _DGRb, _DGRl, _DGRr;
  T _DGBt, _DGBb, _DGBl, _DGBr;

  uint32 _idx; // index in range [0..3]
  
  void estimateDg()    { _Dg = Math::elxAbs(_Gt + _Gb - _Gl - _Gr) / 2; }
  void estimateGreen() { _g = estimate(_Gt, _Gb, _Gl, _Gr); }
  void estimateKr()    { _Kr = estimate(_DGRt, _DGRb, _DGRl, _DGRr); }
  void estimateKb()    { _Kb = estimate(_DGBt, _DGBb, _DGBl, _DGBr); }

  void estimateRegion(T iEdge, T iFlat)
  {
    const T d = Math::elxAbs(_Dv - _Dh);
    if (d < iEdge)
      _region = (_Dg < iFlat) ? Flat : Pattern;
    else
      _region = Normal;
  }

  T estimate(T iTop, T iBottom, T iLeft, T iRight)
  {
    if (_Dv > _Dh)
      return ((iLeft + iRight) / 2);
    if (_Dv < _Dh)
      return ((iTop + iBottom) / 2);

    return ((iLeft + iRight + iTop + iBottom) / 4);
  }
};

// real variance is /3 but here it's only used it for variances comparison
// so we optimize without one more unnecessary operation
template<typename T>
T estimateVariance(T iV0, T iV1, T iV2)
{
  const T m = (iV0 + iV1 + iV2) / 3;
  const T dv0 = iV0 - m;
  const T dv1 = iV1 - m;
  const T dv2 = iV2 - m;
  return (dv0*dv0 + dv1*dv1 + dv2*dv2);
}

} // anonymous-namespace

//----------------------------------------------------------------------------
//  elxCreateRACC
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateRACC(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    T iEdgeThreshold = 100, 
    T iFlatThreshold = 1000,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 3;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;
  const int32 w3 = 3*w1;

  const F edge = F(iEdgeThreshold); 
  const F flat = F(iFlatThreshold);

  // --- inits progress ---
  const float ProgressStep = 1.0f / (3*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // pnSuper
  SuperPixel<F> * pnSuper = new SuperPixel<F>[w1*h1];

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );
    
  F G14,V24,G34,G41,V42,G43,G45,V46,G47,G54,V64,G74,V44,A44;
  F G32,G23,G25,G36,G52,G63,G56,G65, A33,A35,A53,A55;
  uint32 x,y, idx,idx1,idx2;

  EBayerMatrix Bayer, Original = iBayer;
  T * prSrc, * prSrcV;
  SuperPixel<F> * p, * pV;

  //--------------------------------------------------------
  // Step I - Initial estimate of color
  //--------------------------------------------------------
  //  - green at red/blue follow the taylor series approximation
  //  - spectral and spatial correlation for the chrominance
  //  - red/blue at blue/red
  //--------------------------------------------------------
  F Da33,Da35,Da53,Da55, tab[4];

  prSrcV = (T*)spImageL->GetPixel(border,border);
  pV = pnSuper + border*(w1+1);
  for (y=0; y<h; y++, prSrcV+=w1, pV+=w1)
  {
    prSrc = prSrcV;
    p = pV;
    Bayer = iBayer;

    for (x=0; x<w; x++, prSrc++, p++)
    {
      switch (Bayer)
      {
      case BM_BGGR: 
      case BM_RGGB:
        //             G14
        //         G23 V24 G25
        //     G32 A33 G34 A35 G36
        // G41 V42 G43[V44]G45 V46 G47
        //     G52 A53 G54 A55 G56
        //         G63 V64 G65
        //             G74

                                        G14 = prSrc[-w3];
                    G23 = prSrc[-w2-1]; V24 = prSrc[-w2]; G25 = prSrc[-w2+1];
G32 = prSrc[-w1-2]; A33 = prSrc[-w1-1]; G34 = prSrc[-w1]; A35 = prSrc[-w1+1]; G36 = prSrc[-w1+1];
V42 = prSrc[   -2]; G43 = prSrc[   -1]; V44 = prSrc[  0]; G45 = prSrc[   +1]; V46 = prSrc[   +2]; 
G52 = prSrc[+w1-2]; A53 = prSrc[+w1-1]; G54 = prSrc[+w1]; A55 = prSrc[+w1+1]; G56 = prSrc[+w1+1];
                    G63 = prSrc[+w2-1]; V64 = prSrc[+w2]; G65 = prSrc[+w2+1];
                                        G74 = prSrc[+w3];
                                G41 = prSrc[-3]; G47 = prSrc[+3];

        // directional missing green sample, t=top, b=bottom, l=left, r=right
        // compute missing green using the Taylor series approximation at each directions
        p->_Gt = G34 + F(0.75)*(V44 - V24) - F(0.25)*(G34 - G14);
        p->_Gb = G54 + F(0.75)*(V44 - V64) - F(0.25)*(G54 - G74);
        p->_Gl = G43 + F(0.75)*(V44 - V42) - F(0.25)*(G43 - G41);
        p->_Gr = G45 + F(0.75)*(V44 - V46) - F(0.25)*(G45 - G47);

        // region classification
        p->_Dv = Math::elxAbs(G34 - G54) + Math::elxAbs(V24 - V44) + Math::elxAbs(V64 - V44);
        p->_Dh = Math::elxAbs(G43 - G45) + Math::elxAbs(V42 - V44) + Math::elxAbs(V46 - V44);
        p->estimateDg();
        p->estimateRegion(edge, flat);
        
        // estimate the missing green from Dv,Dh, Gl,Gr,Gt,Gb
        p->estimateGreen();

        // estimate the missing chrominance R->B, B->R
        // Da i+m,j+n = |Gi+m,j - Gi+2m,j+n| + |Gi,j+n - Gi+m,j+2n|

        //     G23     G25
        // G32 d33 G34 d35 G36
        //     G43 V44 G45 
        // G52 d53 G54 d55 G56
        //     G63     G65

        // Da(-1,-1) = |Gi-1,j - Gi-2,j-1| + |Gi,j-1 - Gi-1,j-2|
        Da33 = Math::elxAbs(G34 - G23) + Math::elxAbs(G43 - G32);

        // Da(-1,+1) = |Gi-1,j - Gi-2,j+1| + |Gi,j+1 - Gi-1,j+2|
        Da35 = Math::elxAbs(G34 - G25) + Math::elxAbs(G45 - G36);

        // Da2(+1,-1) = |Gi+1,j - Gi+2,j-1| + |Gi,j-1 - Gi+1,j-2|
        Da53 = Math::elxAbs(G54 - G63) + Math::elxAbs(G43 - G52);

        // Da(+1,+1) = |Gi+1,j - Gi+2,j+1| + |Gi,j+1 - Gi+1,j+2|
        Da55 = Math::elxAbs(G54 - G65) + Math::elxAbs(G45 - G56);

        if (Da33 < Da35) { idx1 = 0; } else { idx1 = 1; Da33 = Da35; }
        if (Da53 < Da55) { idx2 = 2; } else { idx2 = 3; Da53 = Da55; }
        idx = (Da33 < Da53) ? idx1 : idx2;
        // compute and save the index once
        p->_idx = idx;

        tab[0] = A33; tab[1] = A35; 
        tab[2] = A53; tab[3] = A55;
        A44 = tab[idx];

        // directional SSC at color used for chrominance, estimate KV

        //     G34
        // G43 V44 G45 
        //     G54
        if (BM_BGGR == Bayer)
        { 
          // at blue
          p->_b = V44;
          p->_r = A44;
          p->_DGBt = G34 - V44;
          p->_DGBb = G54 - V44;
          p->_DGBl = G43 - V44;
          p->_DGBr = G45 - V44;
          p->estimateKb();
        }
        else
        { 
          // at red
          p->_r = V44;
          p->_b = A44; 
          p->_DGRt = G34 - V44;
          p->_DGRb = G54 - V44;
          p->_DGRl = G43 - V44;
          p->_DGRr = G45 - V44;
          p->estimateKr();
        }
        break;

      default:
        p->_g = prSrc[0];
        break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);
  }

  //-------------------------------------------------------
  // Step II - Obtaining color constancy gains
  //-------------------------------------------------------
  pV = pnSuper + border*(w1+1);
  iBayer = Original;
  for (y=0; y<h; y++, pV+=w1)
  {
    p = pV;
    Bayer = iBayer;

    for (x=0; x<w; x++, p++)
    {
      switch (Bayer)
      {
        // estimate KA
        //     G23     G25
        // G32 A33 G34 A35 G36
        //     G43 V44 G45 
        // G52 A53 G54 A55 G56
        //     G63     G65

      case BM_BGGR:
        // at blue estimate red chrominance
        tab[0] = p[-w1-1]._r; tab[1] = p[-w1+1]._r;
        tab[2] = p[+w1-1]._r; tab[3] = p[+w1+1]._r;

        A44 = tab[p->_idx];

        p->_DGRt = G34 - A44;
        p->_DGRb = G54 - A44;
        p->_DGRl = G43 - A44;
        p->_DGRr = G45 - A44;
        p->estimateKr();
        break;

      case BM_RGGB:
        // at red estimate blue chrominance
        tab[0] = p[-w1-1]._b; tab[1] = p[-w1+1]._b;
        tab[2] = p[+w1-1]._b; tab[3] = p[+w1+1]._b;

        A44 = tab[p->_idx];
        
        p->_DGBt = G34 - A44;
        p->_DGBb = G54 - A44;
        p->_DGBl = G43 - A44;
        p->_DGBr = G45 - A44;
        p->estimateKb();
        break;

      default:
        break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);
  }

  //-------------------------------------------------------
  // Step III - 
  //-------------------------------------------------------
  pV = pnSuper + border*(w1+1);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;

  for (y=0; y<h; y++, pV+=w1, prDstV+=w1)
  {
    p = pV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, p++, prDst++)
    {
/*
      T r = 0;
      if (Flat == p->_region) r = ResolutionTypeTraits<T>::_max/2;
      else if (Flat == p->_region) r = ResolutionTypeTraits<T>::_max;

      prDst->_red   = r;
      prDst->_green = ResolutionTypeTraits<T>::ClampF(p->_g);
      prDst->_blue  = 0;
*/
      prDst->_red   = ResolutionTypeTraits<T>::ClampF(p->_r);
      prDst->_green = ResolutionTypeTraits<T>::ClampF(p->_g);
      prDst->_blue  = ResolutionTypeTraits<T>::ClampF(p->_b);

      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);
  }

  
  /*
  prSrcV = (T*)spImageL->GetPixel(border,border);
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          // (G11) G12 (G13) G14 (G15)  () Means interpolated
          //  G21 [V22] G23 [V24] G25
          // (G31) G32 (G33) G34 (G35)
          //  G41 [V42] G43 [V44] G45
          // (G51) G52 (G53) G54 (G55)

          // get interpolated green from dst image
G11 = prDst[-w2-2]._green; G12 = prDst[-w2-1]._green;                          G14 = prDst[-w2+1]._green; G15 = prDst[-w2+2]._green;
G21 = prDst[-w1-2]._green; G22 = prDst[-w1-1]._green; G23 = prDst[-w1]._green; G24 = prDst[-w1+1]._green; G25 = prDst[-w1+2]._green;
G31 = prDst[   -2]._green; G32 = prDst[   -1]._green; G33 = prDst[  0]._green; G34 = prDst[   +1]._green; G35 = prDst[   +2]._green;
G41 = prDst[+w1-2]._green; G42 = prDst[+w1-1]._green; G43 = prDst[+w1]._green; G44 = prDst[+w1+1]._green; G45 = prDst[+w1+2]._green;
G51 = prDst[+w2-2]._green; G52 = prDst[+w2-1]._green;                          G54 = prDst[+w2+1]._green; G55 = prDst[+w2+2]._green;

          V22 = prSrc[-w1-1];  V24 = prSrc[-w1+1];
          V42 = prSrc[+w1-1];  V44 = prSrc[+w1+1];

          v22 = V22 + (G33 - G22);
          v24 = V24 + (G33 - G24);
          v42 = V42 + (G33 - G42);
          v44 = V44 + (G33 - G44);

          a22 = F(1) / ( F(1) + 
             Math::elxAbs(G11 - G22) + Math::elxAbs(G22 - G33) +
            (Math::elxAbs(G21 - G32) + Math::elxAbs(G12 - G23))/F(2) );

          a24 = F(1) / ( F(1) + 
             Math::elxAbs(G15 - G24) + Math::elxAbs(G24 - G33) +
            (Math::elxAbs(G14 - G23) + Math::elxAbs(G25 - G34))/F(2) );

          a42 = F(1) / ( F(1) + 
             Math::elxAbs(G51 - G42) + Math::elxAbs(G42 - G33) +
            (Math::elxAbs(G41 - G32) + Math::elxAbs(G52 - G43))/F(2) );

          a44 = F(1) / ( F(1) + 
             Math::elxAbs(G55 - G44) + Math::elxAbs(G44 - G33) +
            (Math::elxAbs(G54 - G43) + Math::elxAbs(G45 - G34))/F(2) );

          v = (a22*v22 + a24*v24 + a42*v42 + a44*v44) /
                      (a22 + a24 + a42 + a44);

          if (Bayer == BM_BGGR)
          {
            prDst->_red  = ResolutionTypeTraits<T>::ClampF(v);
            prDst->_blue = prSrc[0];
          }
          else // BM_RGGB
          {
            prDst->_red  = prSrc[0];
            prDst->_blue = ResolutionTypeTraits<T>::ClampF(v);
          }
          break;

        default: break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //-----------------------------------------------------
  // Step III - interpolation of red/blue plane at green
  //-----------------------------------------------------

  // source is no more needed for this step
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prDstV+=w1)
  {
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prDst++)
    {
      switch (Bayer)
      {
        case BM_GBRG: case BM_GRBG:
          // G11 V12 G13 V14 G15
          // V21 G22 V23 G24 V25
          // G31 V32 G33 V34 G35
          // V41 G42 V43 G44 V45
          // G51 V52 G53 V54 G55

                           G12 = prDst[-w2-1]._green; G13 = prDst[-w2]._green; G14 = prDst[-w2+1]._green;
G21 = prDst[-w1-2]._green; G22 = prDst[-w1-1]._green; G23 = prDst[-w1]._green; G24 = prDst[-w1+1]._green; G25 = prDst[-w1+2]._green;
                           G32 = prDst[   -1]._green; G33 = prDst[  0]._green; G34 = prDst[   +1]._green;
G41 = prDst[+w1-2]._green; G42 = prDst[+w1-1]._green; G43 = prDst[+w1]._green; G44 = prDst[+w1+1]._green; G45 = prDst[+w1+2]._green;
                           G52 = prDst[+w2-1]._green; G53 = prDst[+w2]._green; G54 = prDst[+w2+1]._green;

          a23 = F(1) / ( F(1) + 
             Math::elxAbs(G33 - G23) + Math::elxAbs(G23 - G13) +
            (Math::elxAbs(G32 - G22) + Math::elxAbs(G22 - G12) + 
             Math::elxAbs(G34 - G24) + Math::elxAbs(G24 - G14))/F(2) );

          a32 = F(1) / ( F(1) + 
             Math::elxAbs(G33 - G32) + Math::elxAbs(G32 - G31) +
            (Math::elxAbs(G23 - G22) + Math::elxAbs(G22 - G21) + 
             Math::elxAbs(G43 - G42) + Math::elxAbs(G42 - G41))/F(2) );

          a34 = F(1) / ( F(1) + 
             Math::elxAbs(G33 - G34) + Math::elxAbs(G34 - G35) +
            (Math::elxAbs(G23 - G24) + Math::elxAbs(G24 - G25) + 
             Math::elxAbs(G43 - G44) + Math::elxAbs(G44 - G45))/F(2) );

          a43 = F(1) / ( F(1) + 
             Math::elxAbs(G33 - G43) + Math::elxAbs(G43 - G53) +
            (Math::elxAbs(G32 - G42) + Math::elxAbs(G42 - G52) + 
             Math::elxAbs(G34 - G44) + Math::elxAbs(G44 - G54))/F(2) );

          // red interpolation at green
                                V23 = prDst[-w1]._red;
          V32 = prDst[-1]._red;                        V34 = prDst[+1]._red;
                                V43 = prDst[+w1]._red;

          v23 = V23 + (G33 - G23);
          v32 = V32 + (G33 - G32);
          v34 = V34 + (G33 - G34);
          v43 = V43 + (G33 - G43);

          v = (a23*v23 + a32*v32 + a34*v34 + a43*v43) /
                      (a23 + a32 + a34 + a43);

          prDst->_red = ResolutionTypeTraits<T>::ClampF(v);

          // blue interpolation at green
                                  V23 = prDst[-w1]._blue;          
          V32 = prDst[-1]._blue;                          V34 = prDst[+1]._blue;
                                  V43 = prDst[+w1]._blue;

          v23 = V23 + (G33 - G23);
          v32 = V32 + (G33 - G32);
          v34 = V34 + (G33 - G34);
          v43 = V43 + (G33 - G43);

          v = (a23*v23 + a32*v32 + a34*v34 + a43*v43) /
                      (a23 + a32 + a34 + a43);

          prDst->_blue = ResolutionTypeTraits<T>::ClampF(v);
          break;

        default: break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
*/
  spImageL.reset();
  return ImageGeometryImpl< PixelRGB<T> >::CreateSubImage(*spImageRGB, border,border, w,h);

} // elxCreateRACC

} // namespace Image
} // namespace eLynx

#endif // __Bayer_RACC_hpp__
