//============================================================================
//  Raw.hpp                                            Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Raw_hpp__
#define __Bayer_Raw_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateRaw
//----------------------------------------------------------------------------
//  No interpolation here, just for debugging purpose.
//  It allows to see raw images in color.
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateRaw(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();

  // --- inits progress ---
  const float ProgressStep = 1.0f / h;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w,h) );

  PixelRGB<T> * prDst = spImageRGB->GetPixel();
  const T * prSrc = iImage.GetSamples();

  uint32 x,y;
  EBayerMatrix Bayer;
  for (y=0; y<h; y++)
  {
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++,prDst++)
    {
      switch(Bayer)
      {
        case BM_RGGB: 
          prDst->_red   = *prSrc; 
          prDst->_green = 0;
          prDst->_blue  = 0;
          break;
         
        case BM_BGGR: 
          prDst->_red   = 0; 
          prDst->_green = 0;
          prDst->_blue  = *prSrc;
          break;

        default:
          prDst->_red   = 0; 
          prDst->_green = *prSrc; 
          prDst->_blue  = 0;
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
  return spImageRGB;

} // elxCreateRaw

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Raw_hpp__
