//============================================================================
//  Nearest.hpp                                        Image.Component package
//============================================================================
//
//  The simplest and worst algorithm. Used for cultural reason ;)
//
//  http://scien.stanford.edu/class/psych221/projects/99/tingchen/algodep/nbreplica.html
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Nearest_hpp__
#define __Bayer_Nearest_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateNearest
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateNearest(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 hHalf = h / 2;
  const uint32 wHalf = w / 2;
  const uint32 w2 = 2*w;

  // --- inits progress ---
  const float ProgressStep = 1.0f / hHalf;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w,h) );

  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel();
  const T * prSrc, * prSrcV = iImage.GetSamples();
  
  uint32 x,y;
  T r,g0,g1,b;

  switch (iBayer)
  {
    case BM_BGGR:
      for (y=0; y<hHalf; y++, prSrcV+=w2, prDstV+=w2)
      {
        prSrc = prSrcV;
        prDst = prDstV;
        for (x=0; x<wHalf; x++, prSrc+=2, prDst+=2)
        {
          //  B  G0
          //  G1 R
          b  = prSrc[0];  g0 = prSrc[  1];
          g1 = prSrc[w];  r  = prSrc[w+1];

          prDst[  0]._red = r; prDst[  0]._green = g1; prDst[  0]._blue = b;
          prDst[  1]._red = r; prDst[  1]._green = g0; prDst[  1]._blue = b;
          prDst[w  ]._red = r; prDst[w  ]._green = g1; prDst[w  ]._blue = b;
          prDst[w+1]._red = r; prDst[w+1]._green = g0; prDst[w+1]._blue = b;
        }
        // --- in progress ... ---
        Progress += ProgressStep;
        iNotifier.SetProgress(Progress);
      }
      break;

    case BM_GRBG:
      for (y=0; y<hHalf; y++, prSrcV+=w2, prDstV+=w2)
      {
        prSrc = prSrcV;
        prDst = prDstV;
        for (x=0; x<wHalf; x++, prSrc+=2, prDst+=2)
        {
          //  G0 R
          //  B  G1
          g0 = prSrc[0];  r  = prSrc[  1];
          b  = prSrc[w];  g1 = prSrc[w+1];

          prDst[  0]._red = r; prDst[  0]._green = g0; prDst[  0]._blue = b;
          prDst[  1]._red = r; prDst[  1]._green = g1; prDst[  1]._blue = b;
          prDst[w  ]._red = r; prDst[w  ]._green = g0; prDst[w  ]._blue = b;
          prDst[w+1]._red = r; prDst[w+1]._green = g1; prDst[w+1]._blue = b;
        }
        // --- in progress ... ---
        Progress += ProgressStep;
        iNotifier.SetProgress(Progress);
      }
      break;

    case BM_GBRG:
      for (y=0; y<hHalf; y++, prSrcV+=w2, prDstV+=w2)
      {
        prSrc = prSrcV;
        prDst = prDstV;
        for (x=0; x<wHalf; x++, prSrc+=2, prDst+=2)
        {
          //  G0 B
          //  R  G1
          g0 = prSrc[0];  b  = prSrc[  1];
          r  = prSrc[w];  g1 = prSrc[w+1];

          prDst[  0]._red = r; prDst[  0]._green = g0; prDst[  0]._blue = b;
          prDst[  1]._red = r; prDst[  1]._green = g1; prDst[  1]._blue = b;
          prDst[w  ]._red = r; prDst[w  ]._green = g0; prDst[w  ]._blue = b;
          prDst[w+1]._red = r; prDst[w+1]._green = g1; prDst[w+1]._blue = b;
        }
        // --- in progress ... ---
        Progress += ProgressStep;
        iNotifier.SetProgress(Progress);
      }
      break;

    case BM_RGGB:
      for (y=0; y<hHalf; y++, prSrcV+=w2, prDstV+=w2)
      {
        prSrc = prSrcV;
        prDst = prDstV;
        for (x=0; x<wHalf; x++, prSrc+=2, prDst+=2)
        {
          //  R  G0
          //  G1 B
          r  = prSrc[0];  g0 = prSrc[  1];
          g1 = prSrc[w];  b  = prSrc[w+1];

          prDst[  0]._red = r; prDst[  0]._green = g1; prDst[  0]._blue = b;
          prDst[  1]._red = r; prDst[  1]._green = g0; prDst[  1]._blue = b;
          prDst[w  ]._red = r; prDst[w  ]._green = g1; prDst[w  ]._blue = b;
          prDst[w+1]._red = r; prDst[w+1]._green = g0; prDst[w+1]._blue = b;
        }
      }
      break;

    default:break;
  }
  return spImageRGB;

} // elxCreateNearest

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Nearest_hpp__
