//============================================================================
//  LCH.hpp                                            Image.Component package
//============================================================================
//
//  Low-Complexity Hybrid Demosaicing for Color Filter Arrays
//
//  by Chung-Yen Su
//  http://140.118.16.82/www/index.php/JCIE/article/viewFile/503/222
//----------------------------------------------------------------------------
//  Copyright (C) 2010 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_LCH_hpp__
#define __Bayer_LCH_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateLCH
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateLCH(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 3;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;
  const int32 w3 = 3*w1;

  // --- inits progress ---
  const float ProgressStep = 1.0f / (3*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );
    
  F g,g34,g43,g45,g54, v,v22,v23,v24,v32,v34,v42,v43,v44;
  F G11,G12,G13,G14,G15, G21,G22,G23,G24,G25, 
    G31,G32,G33,G34,G35,G36, G41,G42,G43,G44,G45,G47,
    G51,G52,G53,G54,G55,G56, G63,G65,G74;
  F V22,V23,V24,V32,V34,V42,V43,V44,V46,V64;
  F a34,a43,a45,a54, a22,a24,a42,a44, a23,a32;

  uint32 x,y;

  EBayerMatrix Bayer, Original = iBayer;
  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel(border,border);

  //-------------------------------------------------------
  // Step I - interpolation of green plane for whole image
  //-------------------------------------------------------
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          //             G14
          //         G23 V24 G25
          //     G32     G34     G36
          // G41 V42 G43[V44]G45 V46 G47
          //     G52     G54     G56
          //         G63 V64 G65    
          //             G74
                                        G14 = prSrc[-w3];
                    G23 = prSrc[-w2-1]; V24 = prSrc[-w2]; G25 = prSrc[-w2+1]; 
G32 = prSrc[-w1-2];                     G34 = prSrc[-w1];                     G36 = prSrc[-w1+2];
V42 = prSrc[   -2]; G43 = prSrc[   -1]; V44 = prSrc[  0]; G45 = prSrc[   +1]; V46 = prSrc[   +2]; 
G52 = prSrc[+w1-2];                     G54 = prSrc[+w1];                     G56 = prSrc[+w1+2];
                    G63 = prSrc[+w2-1]; V64 = prSrc[+w2]; G65 = prSrc[+w2+1]; 
                                        G74 = prSrc[+w3];

          G41 = prSrc[-3]; G47 = prSrc[+3];

          g34 = G34 + (V44 - V24)/2;
          g43 = G43 + (V44 - V42)/2;
          g45 = G45 + (V44 - V46)/2;
          g54 = G54 + (V44 - V64)/2;

          a34 = F(1) / ( F(1) + 
             Math::elxAbs(G54 - G34) + Math::elxAbs(G34 - G14) + Math::elxAbs(V44 - V24) +
            (Math::elxAbs(G43 - G23) + Math::elxAbs(G45 - G25))/F(2) );

          a43 = F(1) / ( F(1) + 
             Math::elxAbs(G45 - G43) + Math::elxAbs(G43 - G41) + Math::elxAbs(V44 - V42) +
            (Math::elxAbs(G34 - G32) + Math::elxAbs(G54 - G52))/F(2) );

          a45 = F(1) / ( F(1) + 
             Math::elxAbs(G43 - G45) + Math::elxAbs(G45 - G47) + Math::elxAbs(V44 - V46) +
            (Math::elxAbs(G34 - G36) + Math::elxAbs(G54 - G56))/F(2) );

          a54 = F(1) / ( F(1) + 
             Math::elxAbs(G34 - G54) + Math::elxAbs(G54 - G74) + Math::elxAbs(V44 - V64) +
            (Math::elxAbs(G43 - G63) + Math::elxAbs(G45 - G65))/F(2) );

          g = (a34*g34 + a43*g43 + a45*g45 + a54*g54) /
                      (a34 + a43 + a45 + a54);

          prDst->_green = ResolutionTypeTraits<T>::ClampF(g);
          break;

        default:
          // Green plane is direct value
          prDst->_green = prSrc[0];
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //-------------------------------------------------------
  // Step II - interpolation of red/blue plane at blue/red
  //-------------------------------------------------------
  prSrcV = (T*)spImageL->GetPixel(border,border);
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          // (G11) G12 (G13) G14 (G15)  () Means interpolated
          //  G21 [V22] G23 [V24] G25
          // (G31) G32 (G33) G34 (G35)
          //  G41 [V42] G43 [V44] G45
          // (G51) G52 (G53) G54 (G55)

          // get interpolated green from dst image
G11 = prDst[-w2-2]._green; G12 = prDst[-w2-1]._green;                          G14 = prDst[-w2+1]._green; G15 = prDst[-w2+2]._green;
G21 = prDst[-w1-2]._green; G22 = prDst[-w1-1]._green; G23 = prDst[-w1]._green; G24 = prDst[-w1+1]._green; G25 = prDst[-w1+2]._green;
G31 = prDst[   -2]._green; G32 = prDst[   -1]._green; G33 = prDst[  0]._green; G34 = prDst[   +1]._green; G35 = prDst[   +2]._green;
G41 = prDst[+w1-2]._green; G42 = prDst[+w1-1]._green; G43 = prDst[+w1]._green; G44 = prDst[+w1+1]._green; G45 = prDst[+w1+2]._green;
G51 = prDst[+w2-2]._green; G52 = prDst[+w2-1]._green;                          G54 = prDst[+w2+1]._green; G55 = prDst[+w2+2]._green;

          V22 = prSrc[-w1-1];  V24 = prSrc[-w1+1];
          V42 = prSrc[+w1-1];  V44 = prSrc[+w1+1];

          v22 = V22 + (G33 - G22);
          v24 = V24 + (G33 - G24);
          v42 = V42 + (G33 - G42);
          v44 = V44 + (G33 - G44);

          a22 = F(1) / ( F(1) + 
             Math::elxAbs(G11 - G22) + Math::elxAbs(G22 - G33) +
            (Math::elxAbs(G21 - G32) + Math::elxAbs(G12 - G23))/F(2) );

          a24 = F(1) / ( F(1) + 
             Math::elxAbs(G15 - G24) + Math::elxAbs(G24 - G33) +
            (Math::elxAbs(G14 - G23) + Math::elxAbs(G25 - G34))/F(2) );

          a42 = F(1) / ( F(1) + 
             Math::elxAbs(G51 - G42) + Math::elxAbs(G42 - G33) +
            (Math::elxAbs(G41 - G32) + Math::elxAbs(G52 - G43))/F(2) );

          a44 = F(1) / ( F(1) + 
             Math::elxAbs(G55 - G44) + Math::elxAbs(G44 - G33) +
            (Math::elxAbs(G54 - G43) + Math::elxAbs(G45 - G34))/F(2) );

          v = (a22*v22 + a24*v24 + a42*v42 + a44*v44) /
                      (a22 + a24 + a42 + a44);

          if (Bayer == BM_BGGR)
          {
            prDst->_red  = ResolutionTypeTraits<T>::ClampF(v);
            prDst->_blue = prSrc[0];
          }
          else // BM_RGGB
          {
            prDst->_red  = prSrc[0];
            prDst->_blue = ResolutionTypeTraits<T>::ClampF(v);
          }
          break;

        default: break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //-----------------------------------------------------
  // Step III - interpolation of red/blue plane at green
  //-----------------------------------------------------

  // source is no more needed for this step
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prDstV+=w1)
  {
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prDst++)
    {
      switch (Bayer)
      {
        case BM_GBRG: case BM_GRBG:
          // G11 V12 G13 V14 G15
          // V21 G22 V23 G24 V25
          // G31 V32 G33 V34 G35
          // V41 G42 V43 G44 V45
          // G51 V52 G53 V54 G55

                           G12 = prDst[-w2-1]._green; G13 = prDst[-w2]._green; G14 = prDst[-w2+1]._green;
G21 = prDst[-w1-2]._green; G22 = prDst[-w1-1]._green; G23 = prDst[-w1]._green; G24 = prDst[-w1+1]._green; G25 = prDst[-w1+2]._green;
                           G32 = prDst[   -1]._green; G33 = prDst[  0]._green; G34 = prDst[   +1]._green;
G41 = prDst[+w1-2]._green; G42 = prDst[+w1-1]._green; G43 = prDst[+w1]._green; G44 = prDst[+w1+1]._green; G45 = prDst[+w1+2]._green;
                           G52 = prDst[+w2-1]._green; G53 = prDst[+w2]._green; G54 = prDst[+w2+1]._green;

          a23 = F(1) / ( F(1) + 
             Math::elxAbs(G33 - G23) + Math::elxAbs(G23 - G13) +
            (Math::elxAbs(G32 - G22) + Math::elxAbs(G22 - G12) + 
             Math::elxAbs(G34 - G24) + Math::elxAbs(G24 - G14))/F(2) );

          a32 = F(1) / ( F(1) + 
             Math::elxAbs(G33 - G32) + Math::elxAbs(G32 - G31) +
            (Math::elxAbs(G23 - G22) + Math::elxAbs(G22 - G21) + 
             Math::elxAbs(G43 - G42) + Math::elxAbs(G42 - G41))/F(2) );

          a34 = F(1) / ( F(1) + 
             Math::elxAbs(G33 - G34) + Math::elxAbs(G34 - G35) +
            (Math::elxAbs(G23 - G24) + Math::elxAbs(G24 - G25) + 
             Math::elxAbs(G43 - G44) + Math::elxAbs(G44 - G45))/F(2) );

          a43 = F(1) / ( F(1) + 
             Math::elxAbs(G33 - G43) + Math::elxAbs(G43 - G53) +
            (Math::elxAbs(G32 - G42) + Math::elxAbs(G42 - G52) + 
             Math::elxAbs(G34 - G44) + Math::elxAbs(G44 - G54))/F(2) );

          // red interpolation at green
                                V23 = prDst[-w1]._red;
          V32 = prDst[-1]._red;                        V34 = prDst[+1]._red;
                                V43 = prDst[+w1]._red;

          v23 = V23 + (G33 - G23);
          v32 = V32 + (G33 - G32);
          v34 = V34 + (G33 - G34);
          v43 = V43 + (G33 - G43);

          v = (a23*v23 + a32*v32 + a34*v34 + a43*v43) /
                      (a23 + a32 + a34 + a43);

          prDst->_red = ResolutionTypeTraits<T>::ClampF(v);

          // blue interpolation at green
                                  V23 = prDst[-w1]._blue;          
          V32 = prDst[-1]._blue;                          V34 = prDst[+1]._blue;
                                  V43 = prDst[+w1]._blue;

          v23 = V23 + (G33 - G23);
          v32 = V32 + (G33 - G32);
          v34 = V34 + (G33 - G34);
          v43 = V43 + (G33 - G43);

          v = (a23*v23 + a32*v32 + a34*v34 + a43*v43) /
                      (a23 + a32 + a34 + a43);

          prDst->_blue = ResolutionTypeTraits<T>::ClampF(v);
          break;

        default: break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  spImageL.reset();
  return ImageGeometryImpl< PixelRGB<T> >::CreateSubImage(*spImageRGB, border,border, w,h);

} // elxCreateLCH

} // namespace Image
} // namespace eLynx

#endif // __Bayer_LCH_hpp__
