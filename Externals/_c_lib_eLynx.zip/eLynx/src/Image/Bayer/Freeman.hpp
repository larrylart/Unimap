//============================================================================
//  Freeman.hpp                                        Image.Component package
//============================================================================
//
//  Median filter for reconstructing missing color samples
//
//  W. T. Freeman, 1988, U.S. patent no. 4,724,395.
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Freeman_hpp__
#define __Bayer_Freeman_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateFreeman
//----------------------------------------------------------------------------
//  refers to Freeman implementation's 
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateFreeman(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 1;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);

  // --- inits progress ---
  const float ProgressStep = 1.0f / (2*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create temporary ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGBTmp( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );
    
  uint32 x,y;
  EBayerMatrix Bayer, Original = iBayer;
  T r1,r2,r3,r4, g1,g2,g3,g4, b1,b2,b3,b4;

  //-------------------------------------------------
  // Step I - Bilinear interpolation for whole image
  //-------------------------------------------------
  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<T> * prTmp, * prTmpV = spImageRGBTmp->GetPixel(border,border);

  for (y=0; y<h; y++, prSrcV+=w1, prTmpV+=w1)
  {
    prSrc = prSrcV;
    prTmp = prTmpV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prTmp++)
    {
      switch (Bayer)
      {
        case BM_BGGR:
          // R1  G1  R2
          // G2 [B ] G3
          // R3  G4  R4
          r1 = prSrc[-w1-1];  g1 = prSrc[-w1]; r2 = prSrc[-w1+1];
          g2 = prSrc[   -1];                   g3 = prSrc[   +1];
          r3 = prSrc[+w1-1];  g4 = prSrc[+w1]; r4 = prSrc[+w1+1];

          prTmp->_red   = (r1 + r2 + r3 + r4) / 4;
          prTmp->_green = (g1 + g2 + g3 + g4) / 4;
          prTmp->_blue  = prSrc[0];
          break;

        case BM_GBRG:
          // G   R1  G
          // B1 [G ] B2
          // G   R2  G
                          r1 = prSrc[-w1];  
          b1 = prSrc[-1];                  b2 = prSrc[+1];
                          r2 = prSrc[+w1];

          prTmp->_red   = (r1 + r2) / 2;
          prTmp->_green = prSrc[0];
          prTmp->_blue  = (b1 + b2) / 2;
          break;

        case BM_GRBG:
          // G   B1  G
          // R1 [G ] R2
          // G   B2  G
                          b1 = prSrc[-w1];
          r1 = prSrc[-1];                  r2 = prSrc[+1];
                          b2 = prSrc[+w1];

          prTmp->_red   = (r1 + r2) / 2;
          prTmp->_green = prSrc[0];
          prTmp->_blue  = (b1 + b2) / 2;
          break;

        default: // BM_RGGB:
          // B1  G1  B2
          // G2 [R ] G3
          // B3  G4  B4
          b1 = prSrc[-w1-1];  g1 = prSrc[-w1];  b2 = prSrc[-w1+1];
          g2 = prSrc[   -1];                    g3 = prSrc[   +1];
          b3 = prSrc[+w1-1];  g4 = prSrc[+w1];  b4 = prSrc[+w1+1];

          prTmp->_red   = prSrc[0];
          prTmp->_green = (g1 + g2 + g3 + g4) / 4;
          prTmp->_blue  = (b1 + b2 + b3 + b4) / 4;
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
  spImageL.reset();

  //--------------------------------------
  // Step II - Median filter on gradients
  //--------------------------------------

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w1,h1) );
    
  // fill image as black
  PixelRGB<T> * prDst = spImageRGB->GetPixel();
  ::memset(prDst, 0x00, w1*h1*sizeof(PixelRGB<T>));

  PixelRGB<T> * prDstV = spImageRGB->GetPixel(border,border);
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  iBayer = Original;

  M r,g,b, List[9];
  for (y=0; y<h; y++, prTmpV+=w1, prDstV+=w1)
  {
    prTmp = prTmpV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prTmp++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR:
          // R  G  R
          // G [B] G
          // R  G  R

          // red interpolation at blue
          List[0] = prTmp[-w1-1]._red - prTmp[-w1-1]._blue;
          List[1] = prTmp[-w1  ]._red - prTmp[-w1  ]._blue;
          List[2] = prTmp[-w1+1]._red - prTmp[-w1+1]._blue;
          List[3] = prTmp[   -1]._red - prTmp[   -1]._blue;
          List[4] = prTmp[    0]._red - prTmp[    0]._blue;
          List[5] = prTmp[   +1]._red - prTmp[   +1]._blue;
          List[6] = prTmp[+w1-1]._red - prTmp[+w1-1]._blue;   
          List[7] = prTmp[+w1  ]._red - prTmp[+w1  ]._blue;  
          List[8] = prTmp[+w1+1]._red - prTmp[+w1+1]._blue; 
          elxShellSort(List, 9, 3);
          r = List[4] + prTmp[0]._blue;

          // green interpolation at blue
          List[0] = prTmp[-w1-1]._green - prTmp[-w1-1]._blue;
          List[1] = prTmp[-w1  ]._green - prTmp[-w1  ]._blue;
          List[2] = prTmp[-w1+1]._green - prTmp[-w1+1]._blue;
          List[3] = prTmp[   -1]._green - prTmp[   -1]._blue;
          List[4] = prTmp[    0]._green - prTmp[    0]._blue;
          List[5] = prTmp[   +1]._green - prTmp[   +1]._blue;
          List[6] = prTmp[+w1-1]._green - prTmp[+w1-1]._blue;   
          List[7] = prTmp[+w1  ]._green - prTmp[+w1  ]._blue;  
          List[8] = prTmp[+w1+1]._green - prTmp[+w1+1]._blue; 
          elxShellSort(List, 9, 3);
          g = List[4] + prTmp[0]._blue;

          prDst->_red   = ResolutionTypeTraits<T>::ClampM(r);
          prDst->_green = ResolutionTypeTraits<T>::ClampM(g);
          prDst->_blue  = prTmp[0]._blue;
          break;

        case BM_RGGB:
          // B  G  B
          // G [R] G
          // B  G  B

          // blue interpolation at red
          List[0] = prTmp[-w1-1]._blue - prTmp[-w1-1]._red;
          List[1] = prTmp[-w1  ]._blue - prTmp[-w1  ]._red;
          List[2] = prTmp[-w1+1]._blue - prTmp[-w1+1]._red;
          List[3] = prTmp[   -1]._blue - prTmp[   -1]._red;
          List[4] = prTmp[    0]._blue - prTmp[    0]._red;
          List[5] = prTmp[   +1]._blue - prTmp[   +1]._red;
          List[6] = prTmp[+w1-1]._blue - prTmp[+w1-1]._red;   
          List[7] = prTmp[+w1  ]._blue - prTmp[+w1  ]._red;  
          List[8] = prTmp[+w1+1]._blue - prTmp[+w1+1]._red; 
          elxShellSort(List, 9, 3);
          b = List[4] + prTmp[0]._red;

          // green interpolation at red
          List[0] = prTmp[-w1-1]._green - prTmp[-w1-1]._red;
          List[1] = prTmp[-w1  ]._green - prTmp[-w1  ]._red;
          List[2] = prTmp[-w1+1]._green - prTmp[-w1+1]._red;
          List[3] = prTmp[   -1]._green - prTmp[   -1]._red;
          List[4] = prTmp[    0]._green - prTmp[    0]._red;
          List[5] = prTmp[   +1]._green - prTmp[   +1]._red;
          List[6] = prTmp[+w1-1]._green - prTmp[+w1-1]._red;   
          List[7] = prTmp[+w1  ]._green - prTmp[+w1  ]._red;  
          List[8] = prTmp[+w1+1]._green - prTmp[+w1+1]._red; 
          elxShellSort(List, 9, 3);
          g = List[4] + prTmp[0]._red;

          prDst->_red   = prTmp[0]._red;
          prDst->_green = ResolutionTypeTraits<T>::ClampM(g);
          prDst->_blue  = ResolutionTypeTraits<T>::ClampM(b);
          break;

        default: // BM_GBRG   BM_GRBG
          // G  R  G          G  B  G
          // B [G] B          R [G] R
          // G  R  G          G  B  G

          // red interpolation at green
          List[0] = prTmp[-w1-1]._red - prTmp[-w1-1]._green;
          List[1] = prTmp[-w1  ]._red - prTmp[-w1  ]._green;
          List[2] = prTmp[-w1+1]._red - prTmp[-w1+1]._green;
          List[3] = prTmp[   -1]._red - prTmp[   -1]._green;
          List[4] = prTmp[    0]._red - prTmp[    0]._green;
          List[5] = prTmp[   +1]._red - prTmp[   +1]._green;
          List[6] = prTmp[+w1-1]._red - prTmp[+w1-1]._green;   
          List[7] = prTmp[+w1  ]._red - prTmp[+w1  ]._green;  
          List[8] = prTmp[+w1+1]._red - prTmp[+w1+1]._green; 
          elxShellSort(List, 9, 3);
          r = List[4] + prTmp[0]._green;

          // blue interpolation at green
          List[0] = prTmp[-w1-1]._blue - prTmp[-w1-1]._green;
          List[1] = prTmp[-w1  ]._blue - prTmp[-w1  ]._green;
          List[2] = prTmp[-w1+1]._blue - prTmp[-w1+1]._green;
          List[3] = prTmp[   -1]._blue - prTmp[   -1]._green;
          List[4] = prTmp[    0]._blue - prTmp[    0]._green;
          List[5] = prTmp[   +1]._blue - prTmp[   +1]._green;
          List[6] = prTmp[+w1-1]._blue - prTmp[+w1-1]._green;   
          List[7] = prTmp[+w1  ]._blue - prTmp[+w1  ]._green;  
          List[8] = prTmp[+w1+1]._blue - prTmp[+w1+1]._green; 
          elxShellSort(List, 9, 3);
          b = List[4] + prTmp[0]._green;

          prDst->_red   = ResolutionTypeTraits<T>::ClampM(r);
          prDst->_green = prTmp[0]._green;
          prDst->_blue  = ResolutionTypeTraits<T>::ClampM(b);
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  spImageRGBTmp.reset();
  return ImageGeometryImpl< PixelRGB<T> >::CreateSubImage(*spImageRGB, border,border, w,h);

} // elxCreateFreeman

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Freeman_hpp__
