//============================================================================
//  PRI.hpp                                            Image.Component package
//============================================================================
//
//  Pattern Recognition Interpolation
//
//  http://scien.stanford.edu/class/psych221/projects/99/tingchen/algodep/pttnreg.html
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_PRI_hpp__
#define __Bayer_PRI_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreatePRI
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreatePRI(
    const ImageImpl< PixelL<T> >& iImage,
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border+w+border);
  const int32 w2 = w1*2;

  // --- inits progress ---
  const float ProgressStep = 1.0f / h;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w,h, PixelRGB<T>::Black()) );

  uint32 x,y,i,p[4], count;
  EBayerMatrix Bayer;
  M v,va1,va2,vb1,vb2;
  M g, g1[4], g2[8];

  const PixelL<T> * prSrc, * prSrcV = spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel();

  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:

          // Green interpolation
          //      G1
          //  G2 [g] G3
          //      G4
          g1[0] = prSrc[-w1]._luminance;
          g1[1] = prSrc[-1]._luminance;
          g1[2] = prSrc[1]._luminance;
          g1[3] = prSrc[w1]._luminance;
          g = (g1[0] + g1[1] + g1[2] + g1[3])/4;

          // Determine a pattern
          for (i=count=0; i < 4; ++i)
          {
            p[i] = (g1[i] > g);
            count += p[i];
          }

          if (count == 0)
            // all green pixels have the same value
            //    G
            // G  []  G
            //    G
            g = g1[0];
          if (count == 1 || count == 3)
          {
            //    L           H
            // H  []  H     L [] L
            //    H           L
            //edge pattern
            elxInsertionSort(g1);
            g = (g1[1] + g1[2])/2;
          }
          else if (g1[0] == g1[2])
          {
            // stripe pattern
            //     L
            //   H [] H
            //     L
            g2[0] = prSrc[-w2-1]._luminance; g2[1] = prSrc[-w2+1]._luminance;
            g2[2] = prSrc[-w1-2]._luminance; g2[3] = prSrc[-w1+2]._luminance;
            g2[4] = prSrc[w1-2]._luminance; g2[5] = prSrc[w1+2]._luminance;
            g2[6] = prSrc[w2-1]._luminance; g2[7] = prSrc[w2+1]._luminance;
            g = (g1[0]+g1[1]+g1[2]+g1[3])/2 -
              (g2[0]+g2[1]+g2[2]+g2[3]+g2[4]+g2[5]+g2[6]+g2[7])/8;

            elxInsertionSort(g1);
            Math::elxClamp(g1[1], g1[2], g);
          }
          else
          {
            // corner pattern
            //     L
            //   L [] H
            //     H
            g2[0] = prSrc[-w2+1]._luminance; g2[1] = prSrc[-w1+2]._luminance;
            g2[2] = prSrc[w1-2]._luminance; g2[3] = prSrc[w2-1]._luminance;

            elxInsertionSort(g1);
            g = g1[1] + g1[2] - (g2[0]+g2[1]+g2[2]+g2[3]) / 4;
            Math::elxClamp(g1[1], g1[2], g);
         }

          prDst->_green = ResolutionTypeTraits<T>::ClampM(g);

          //Blue/Red interpolation (bilinear)
          // BGGR            RGGB
          // R1  G1  R2   // B1  G1  B2
          // G4 [B ] G2   // G4 [R ] G2
          // R3  G3  R4   // B3  G3  B4
          v = (prSrc[-w1-1]._luminance + prSrc[-w1+1]._luminance +
               prSrc[w1-1]._luminance + prSrc[w1+1]._luminance) / 4;
          if (Bayer == BM_BGGR)
          {
            prDst->_red = ResolutionTypeTraits<T>::ClampM(v);
            prDst->_blue = prSrc[0]._luminance;
          }
          else
          {
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(v);
            prDst->_red = prSrc[0]._luminance;
          }
          break;

        case BM_GBRG:     case BM_GRBG:
          //Blue/Red interpolation (bilinear)
          // G   R1  G    G   B1  G
          // B1 [G ] B2   R1 [G ] R2
          // G   R2  G    G   B2  G
                         va1 = prSrc[-w1]._luminance;
          vb1 = prSrc[-1]._luminance;      vb2 = prSrc[+1]._luminance;
                         va2 = prSrc[+w1]._luminance;
          if (Bayer == BM_GBRG)
          {
            prDst->_red   = ResolutionTypeTraits<T>::ClampM((va1 + va2) / 2);
            prDst->_blue  = ResolutionTypeTraits<T>::ClampM((vb1 + vb2) / 2);
          }
          else
          {
            prDst->_blue   = ResolutionTypeTraits<T>::ClampM((va1 + va2) / 2);
            prDst->_red  = ResolutionTypeTraits<T>::ClampM((vb1 + vb2) / 2);
          }
          prDst->_green = prSrc[0]._luminance;
          break;
          
          default:
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
  spImageL.reset();
  return spImageRGB;

} // elxCreatePRI

} // namespace Image
} // namespace eLynx

#endif // __Bayer_PRI_hpp__
