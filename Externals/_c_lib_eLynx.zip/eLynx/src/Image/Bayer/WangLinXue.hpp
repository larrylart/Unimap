//============================================================================
//  WangLinXue.hpp                                     Image.Component package
//============================================================================
//
//  Edge-Adaptive color reconstruction for single-sensor digital camera
//
//  by Xiaomeng Wang, Weisi Lin and Ping Xue
//  http://ieeexplore.ieee.org/iel5/9074/28788/01292458.pdf
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_WangLinXue_hpp__
#define __Bayer_WangLinXue_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateWangLinXue
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateWangLinXue(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;

  // --- inits progress ---
  const float ProgressStep = 1.0f / (4*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<F> > > spImageL =
    elxCreateFloatingExpanded<T, PixelL>(iImage, border);

  // Create temporary ImageRGB<F> image
  boost::shared_ptr< ImageImpl< PixelRGB<F> > >
    spImageRGBTmp( new ImageImpl< PixelRGB<F> >(w1,h1, PixelRGB<F>::Black()) );

  F R12,G13,R14,G15,R16;
  F G22,B23,G24,B25,G26;
  F R32,G33,R34,G35,R36;
  F G42,B43,G44,B45,G46;
  F R52,G53,R54,G55,R56;
  F H,Hr,Hg,Hb,Hgr, V,Vr,Vg,Vb,Vgr;
  F r,g,b;
  uint32 x,y;

  EBayerMatrix Bayer, Original = iBayer;
  F * prSrc, * prSrcV = (F*)spImageL->GetPixel(border,border);
  PixelRGB<F> * prTmp, * prTmpV = spImageRGBTmp->GetPixel(border,border);

  // G11 R12 G13 R14 G15 R16
  // B21 G22 B23 G24 B25 G26
  // G31 R32 G33 R34 G35 R36
  // B41 G42 B43 G44 B45 G46
  // G51 R52 G53 R54 G55 R56
  // B61 G62 B63 G64 B65 G66

  //-------------------------------------------------------
  // Step I - interpolation of green plane for whole image
  //-------------------------------------------------------
  for (y=0; y<h; y++, prSrcV+=w1, prTmpV+=w1)
  {
    prSrc = prSrcV;
    prTmp = prTmpV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prTmp++)
    {
      switch (Bayer)
      {
        case BM_RGGB: case BM_BGGR: 
          // R12 G13 R14 G15 R16
          // G22 B23 G24 B25 G26
          // R32 G33[R34]G35 R36
          // G42 B43 G44 B45 G46
          // R52 G53 R54 G55 R56
R12 = prSrc[-w2-2]; G13 = prSrc[-w2-1]; R14 = prSrc[-w2]; G15 = prSrc[-w2+1]; R16 = prSrc[-w2+2];
G22 = prSrc[-w1-2]; B23 = prSrc[-w1-1]; G24 = prSrc[-w1]; B25 = prSrc[-w1+1]; G26 = prSrc[-w1+2];
R32 = prSrc[   -2]; G33 = prSrc[   -1]; R34 = prSrc[  0]; G35 = prSrc[   +1]; R36 = prSrc[   +2];
G42 = prSrc[+w1-2]; B43 = prSrc[-w1-1]; G44 = prSrc[+w1]; B45 = prSrc[+w1+1]; G46 = prSrc[+w1+2];
R52 = prSrc[+w2-2]; G53 = prSrc[+w2-1]; R54 = prSrc[+w2]; G55 = prSrc[+w2+1]; R56 = prSrc[+w2+2];

          Hr = Math::elxAbs(R12 + R16 - 2*R14) +
               Math::elxAbs(R32 + R36 - 2*R34) +
               Math::elxAbs(R52 + R56 - 2*R54);

          Vr = Math::elxAbs(R12 + R52 - 2*R32) +
               Math::elxAbs(R14 + R54 - 2*R34) +
               Math::elxAbs(R16 + R56 - 2*R36);

          Hg = Math::elxAbs(G33 - G35) + 
               Math::elxAbs(G22 + G26 - 2*G24) + 
               Math::elxAbs(G42 + G46 - 2*G44);

          Vg = Math::elxAbs(G24 - G44) + 
               Math::elxAbs(G13 + G53 - 2*G33) + 
               Math::elxAbs(G15 + G55 - 2*G35);

          Hb = Math::elxAbs(B23 - B25) + Math::elxAbs(B43 - B45);
          Vb = Math::elxAbs(B23 - B43) + Math::elxAbs(B25 - B45);

          Hgr = Math::elxAbs(G33 + G35 - 2*R34);
          Vgr = Math::elxAbs(G24 + G44 - 2*R34);

          H = Hr + Hg + Hb + Hgr;
          V = Vr + Vg + Vb + Vgr;

          if (H > V)
          {
            g = R34 + (G24 + G44 - R34)/2 - (R14 + R54)/4;
          }
          else if (H < V)
          {
            g = R34 + (G33 + G35 - R34)/2 - (R32 + R36)/4;
           }
          else
          {
            g = (R34 + (G24 + G44 + G33 + G35)/2 - (R14 + R54 + R32 + R36)/4)/2;
          }
          prTmp->_green = g;

          // save original color in tmp
          (Bayer == BM_RGGB) ? prTmp->_red=R34 : prTmp->_blue=R34;
          break;

        default:
          // save green
          prTmp->_green = prSrc[0];
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // no more need of source image
  spImageL.reset();


  //--------------------------------------------
  // Step II - interpolation of red/blue planes 
  //--------------------------------------------
  F G23,G25,G32,G34,G43,G45;
  F a23,a25,a32,a34,a43,a45;
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prTmpV+=w1)
  {
    prTmp = prTmpV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prTmp++)
    {
      switch (Bayer)
      {
        case BM_RGGB:
          // interpolate blue at red

          // B23     B25
          //    [R34]
          // B43     B45
G23 = prTmp[-w1-1]._green;                      G25 = prTmp[-w1+1]._green;
B23 = prTmp[-w1-1]._blue;                       B25 = prTmp[-w1+1]._blue;
                          G34 = prTmp[0]._green;
G43 = prTmp[+w1-1]._green;                      G45 = prTmp[+w1+1]._green;
B43 = prTmp[+w1-1]._blue;                       B45 = prTmp[+w1+1]._blue;
     
          a23 = F(1) / Math::elxSqrt(1 + (G23-G34)*(G23-G34)/2);
          a25 = F(1) / Math::elxSqrt(1 + (G25-G34)*(G25-G34)/2);
          a43 = F(1) / Math::elxSqrt(1 + (G43-G34)*(G43-G34)/2);
          a45 = F(1) / Math::elxSqrt(1 + (G45-G34)*(G45-G34)/2);

          b = G34 + (a23*(B23-G23) + a25*(B25-G25) + a43*(B43-G43) + a45*(B45-G45)) /
                                        (a23 + a25 + a43 + a45);
          prTmp->_blue = b;
          break;
        
        case BM_BGGR:
          // interpolate red at blue

          // B23     B25  swap B & R
          //    [R34]
          // B43     B45
G23 = prTmp[-w1-1]._green;                      G25 = prTmp[-w1+1]._green;
B23 = prTmp[-w1-1]._red;                        B25 = prTmp[-w1+1]._red;
                          G34 = prTmp[0]._green;
G43 = prTmp[+w1-1]._green;                      G45 = prTmp[+w1+1]._green;
B43 = prTmp[+w1-1]._red;                        B45 = prTmp[+w1+1]._red;
          
          a23 = F(1) / Math::elxSqrt(1 + (G23-G34)*(G23-G34)/2);
          a25 = F(1) / Math::elxSqrt(1 + (G25-G34)*(G25-G34)/2);
          a43 = F(1) / Math::elxSqrt(1 + (G43-G34)*(G43-G34)/2);
          a45 = F(1) / Math::elxSqrt(1 + (G45-G34)*(G45-G34)/2);

          r = G34 + (a23*(B23-G23) + a25*(B25-G25) + a43*(B43-G43) + a45*(B45-G45)) /
                                        (a23 + a25 + a43 + a45);
          prTmp->_red = r;
          break;

        case BM_GRBG:
          //  B23
          // [G33]
          //  B43
          // interpolate blue at green
          G23 = prTmp[-w1]._green;
          B23 = prTmp[-w1]._blue;
          G33 = prTmp[  0]._green;
          G43 = prTmp[+w1]._green; 
          B43 = prTmp[+w1]._blue;

          a23 = F(1) / Math::elxSqrt(1 + (G23-G33)*(G23-G33));
          a43 = F(1) / Math::elxSqrt(1 + (G43-G33)*(G43-G33));
          
          b = G33 + (a23*(B23-G23) + a43*(B43-G43)) /
                              (a23 + a43);

          // R32[G33]R34
          // interpolate red at green
          G32 = prTmp[-1]._green; R32 = prTmp[-1]._red;
          G34 = prTmp[+1]._green; R34 = prTmp[+1]._red;

          a32 = F(1) / Math::elxSqrt(1 + (G32-G33)*(G32-G33));
          a34 = F(1) / Math::elxSqrt(1 + (G34-G33)*(G34-G33));

          r = G33 + (a32*(R32-G32) + a34*(R34-G34)) /
                              (a32 + a34);
          prTmp->_red  = r;
          prTmp->_blue = b;
          break;

        default: // BM_GBRG
          //  B23 
          // [G33]  swap B & R
          //  B43
          // interpolate red at green
          G23 = prTmp[-w1]._green;
          B23 = prTmp[-w1]._red;
          G33 = prTmp[  0]._green;
          G43 = prTmp[+w1]._green; 
          B43 = prTmp[+w1]._red;

          a23 = F(1) / Math::elxSqrt(1 + (G23-G33)*(G23-G33));
          a43 = F(1) / Math::elxSqrt(1 + (G43-G33)*(G43-G33));
          
          r = G33 + (a23*(B23-G23) + a43*(B43-G43)) /
                              (a23 + a43);

          // R32[G33]R34  swap B & R
          // interpolate blue at green
          G32 = prTmp[-1]._green; R32 = prTmp[-1]._blue;
          G34 = prTmp[+1]._green; R34 = prTmp[+1]._blue;

          a32 = F(1) / Math::elxSqrt(1 + (G32-G33)*(G32-G33));
          a34 = F(1) / Math::elxSqrt(1 + (G34-G33)*(G34-G33));

          b = G33 + (a32*(R32-G32) + a34*(R34-G34)) /
                              (a32 + a34);

          prTmp->_red  = r;
          prTmp->_blue = b;
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }


  //--------------------------------------
  // Step III - correction of green plane
  //--------------------------------------
  F R23,R24,R25,B24,R33,R35,B33,B34,B35,R43,R44,R45,B44;
  F Hr1,Hg1,Hb1,Vr1,Vg1,Vb1, Hr2,Hg2,Hb2,Vr2,Vg2,Vb2;
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prTmpV+=w1)
  {
    prTmp = prTmpV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prTmp++)
    {
      switch (Bayer)
      {
        case BM_RGGB:
          // B23 G24 B25
          // G33[R34]G35
          // B43 G44 B45
R23 = prTmp[-w1-1]._red;   R24 = prTmp[-w1]._red;   R25 = prTmp[-w1+1]._red;
G23 = prTmp[-w1-1]._green; G24 = prTmp[-w1]._green; G25 = prTmp[-w1+1]._green;
B23 = prTmp[-w1-1]._blue;  B24 = prTmp[-w1]._blue;  B25 = prTmp[-w1+1]._blue;

R33 = prTmp[   -1]._red;   R34 = prTmp[  0]._red;   R35 = prTmp[   +1]._red;
G33 = prTmp[   -1]._green; G34 = prTmp[  0]._green; G35 = prTmp[   +1]._green;
B33 = prTmp[   -1]._blue;  B34 = prTmp[  0]._blue;  B35 = prTmp[   +1]._blue;

R43 = prTmp[+w1-1]._red;   R44 = prTmp[+w1]._red;   R45 = prTmp[+w1+1]._red;
G43 = prTmp[+w1-1]._green; G44 = prTmp[+w1]._green; G45 = prTmp[+w1+1]._green;
B43 = prTmp[+w1-1]._blue;  B44 = prTmp[+w1]._blue;  B45 = prTmp[+w1+1]._blue;


          Hr1 = Math::elxAbs(R33 - R35); Vr1 = Math::elxAbs(R24 - R44);
          Hg1 = Math::elxAbs(G33 - G35); Vg1 = Math::elxAbs(G24 - G44);
          Hb1 = Math::elxAbs(B33 - B35); Vb1 = Math::elxAbs(B24 - B44);
          
          Hr2 = Math::elxAbs(R33 + R35 - 2*R34); 
          Vr2 = Math::elxAbs(R24 + R44 - 2*R34);
          
          Hg2 = Math::elxAbs(G33 + G35 - 2*G34); 
          Vg2 = Math::elxAbs(G24 + G44 - 2*G34);

          Hb2 = Math::elxAbs(B33 + B35 - 2*B34); 
          Vb2 = Math::elxAbs(B24 + B44 - 2*B34);

          H = Hr1 + Hg1 + Hb1 + Hr2 + Hg2 + Hb2;
          V = Vr1 + Vg1 + Vb1 + Vr2 + Vg2 + Vb2;

          if (H > V)
          {
            g = R34 + (G24 - R24 + G44 - R44)/2;
          }
          else if (H < V)
          {
            g = R34 + (G33 - R33 + G35 - R35)/2;
           }
          else
          {
            g = R34 + (G23-R23 + G24-R24 + G25-R25 + 
                       G33-R33 +           G35-R35 + 
                       G43-R43 + G44-R44 + G45-R45)/8;
          }
          prTmp->_green = g;
          break;

        case BM_BGGR: 
          // B23 G24 B25 
          // G33[R34]G35  swap R & B
          // B43 G44 B45
R23 = prTmp[-w1-1]._red;   R24 = prTmp[-w1]._red;   R25 = prTmp[-w1+1]._red;
G23 = prTmp[-w1-1]._green; G24 = prTmp[-w1]._green; G25 = prTmp[-w1+1]._green;
B23 = prTmp[-w1-1]._blue;  B24 = prTmp[-w1]._blue;  B25 = prTmp[-w1+1]._blue;

R33 = prTmp[   -1]._red;   R34 = prTmp[  0]._red;   R35 = prTmp[   +1]._red;
G33 = prTmp[   -1]._green; G34 = prTmp[  0]._green; G35 = prTmp[   +1]._green;
B33 = prTmp[   -1]._blue;  B34 = prTmp[  0]._blue;  B35 = prTmp[   +1]._blue;

R43 = prTmp[+w1-1]._red;   R44 = prTmp[+w1]._red;   R45 = prTmp[+w1+1]._red;
G43 = prTmp[+w1-1]._green; G44 = prTmp[+w1]._green; G45 = prTmp[+w1+1]._green;
B43 = prTmp[+w1-1]._blue;  B44 = prTmp[+w1]._blue;  B45 = prTmp[+w1+1]._blue;


          Hr1 = Math::elxAbs(R33 - R35); Vr1 = Math::elxAbs(R24 - R44);
          Hg1 = Math::elxAbs(G33 - G35); Vg1 = Math::elxAbs(G24 - G44);
          Hb1 = Math::elxAbs(B33 - B35); Vb1 = Math::elxAbs(B24 - B44);
          
          Hr2 = Math::elxAbs(R33 + R35 - 2*R34); 
          Vr2 = Math::elxAbs(R24 + R44 - 2*R34);
          
          Hg2 = Math::elxAbs(G33 + G35 - 2*G34); 
          Vg2 = Math::elxAbs(G24 + G44 - 2*G34);

          Hb2 = Math::elxAbs(B33 + B35 - 2*B34); 
          Vb2 = Math::elxAbs(B24 + B44 - 2*B34);

          H = Hr1 + Hg1 + Hb1 + Hr2 + Hg2 + Hb2;
          V = Vr1 + Vg1 + Vb1 + Vr2 + Vg2 + Vb2;

          if (H > V)
          {
            g = B34 + (G24 - B24 + G44 - B44)/2;
          }
          else if (H < V)
          {
            g = B34 + (G33 - B33 + G35 - B35)/2;
           }
          else
          {
            g = B34 + (G23-B23 + G24-B24 + G25-B25 + 
                       G33-B33 +           G35-B35 + 
                       G43-B43 + G44-B44 + G45-B45)/8;
          }
          prTmp->_green = g;
          break;

        default: 
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }


  //-----------------------------------------
  // Step IV - correction of red/blue planes
  //-----------------------------------------
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prTmpV+=w1)
  {
    prTmp = prTmpV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prTmp++)
    {
      switch (Bayer)
      {
        case BM_RGGB:
          // B23 G24 B25
          // G33[R34]G35
          // B43 G44 B45
G23 = prTmp[-w1-1]._green; G24 = prTmp[-w1]._green; G25 = prTmp[-w1+1]._green;
B23 = prTmp[-w1-1]._blue;  B24 = prTmp[-w1]._blue;  B25 = prTmp[-w1+1]._blue;

G33 = prTmp[   -1]._green; G34 = prTmp[  0]._green; G35 = prTmp[   +1]._green;
B33 = prTmp[   -1]._blue;  B34 = prTmp[  0]._blue;  B35 = prTmp[   +1]._blue;

G43 = prTmp[+w1-1]._green; G44 = prTmp[+w1]._green; G45 = prTmp[+w1+1]._green;
B43 = prTmp[+w1-1]._blue;  B44 = prTmp[+w1]._blue;  B45 = prTmp[+w1+1]._blue;

          b = G34 + (B23-G23 + B24-G24 + B25-G25 + 
                     B33-G33 +           B35-G35 + 
                     B43-G43 + B44-G44 + B45-G45)/8;

          prTmp->_blue = b;
          break;

        case BM_BGGR: 
          // B23 G24 B25 
          // G33[R34]G35  swap R & B
          // B43 G44 B45
R23 = prTmp[-w1-1]._red;   R24 = prTmp[-w1]._red;   R25 = prTmp[-w1+1]._red;
G23 = prTmp[-w1-1]._green; G24 = prTmp[-w1]._green; G25 = prTmp[-w1+1]._green;

R33 = prTmp[   -1]._red;   R34 = prTmp[  0]._red;   R35 = prTmp[   +1]._red;
G33 = prTmp[   -1]._green; G34 = prTmp[  0]._green; G35 = prTmp[   +1]._green;

R43 = prTmp[+w1-1]._red;   R44 = prTmp[+w1]._red;   R45 = prTmp[+w1+1]._red;
G43 = prTmp[+w1-1]._green; G44 = prTmp[+w1]._green; G45 = prTmp[+w1+1]._green;

          r = G34 + (R23-G23 + R24-G24 + R25-G25 + 
                     R33-G33 +           R35-G35 + 
                     R43-G43 + R44-G44 + R45-G45)/8;

          prTmp->_red = r;
          break;

        default:
R23 = prTmp[-w1-1]._red;   R24 = prTmp[-w1]._red;   R25 = prTmp[-w1+1]._red;
G23 = prTmp[-w1-1]._green; G24 = prTmp[-w1]._green; G25 = prTmp[-w1+1]._green;
B23 = prTmp[-w1-1]._blue;  B24 = prTmp[-w1]._blue;  B25 = prTmp[-w1+1]._blue;

R33 = prTmp[   -1]._red;   R34 = prTmp[  0]._red;   R35 = prTmp[   +1]._red;
G33 = prTmp[   -1]._green; G34 = prTmp[  0]._green; G35 = prTmp[   +1]._green;
B33 = prTmp[   -1]._blue;  B34 = prTmp[  0]._blue;  B35 = prTmp[   +1]._blue;

R43 = prTmp[+w1-1]._red;   R44 = prTmp[+w1]._red;   R45 = prTmp[+w1+1]._red;
G43 = prTmp[+w1-1]._green; G44 = prTmp[+w1]._green; G45 = prTmp[+w1+1]._green;
B43 = prTmp[+w1-1]._blue;  B44 = prTmp[+w1]._blue;  B45 = prTmp[+w1+1]._blue;

          b = G34 + (B23-G23 + B24-G24 + B25-G25 + 
                     B33-G33 +           B35-G35 + 
                     B43-G43 + B44-G44 + B45-G45)/8;

          r = G34 + (R23-G23 + R24-G24 + R25-G25 + 
                     R33-G33 +           R35-G35 + 
                     R43-G43 + R44-G44 + R45-G45)/8;

          prTmp->_red  = r;
          prTmp->_blue = b;

          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }


  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w,h) );

  // back to T resolution with border cropping
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  PixelRGB<T> * prDst = spImageRGB->GetPixel();
  for (y=0; y<h; y++, prTmpV+=w1)
  {
    prTmp = prTmpV;
    for (x=0; x<w; x++, prTmp++, prDst++)
    {
      prDst->_red   = ResolutionTypeTraits<T>::ClampF( prTmp->_red );
      prDst->_green = ResolutionTypeTraits<T>::ClampF( prTmp->_green );
      prDst->_blue  = ResolutionTypeTraits<T>::ClampF( prTmp->_blue );
    }
  }

  return spImageRGB;

} // elxCreateWangLinXue

} // namespace Image
} // namespace eLynx

#endif // __Bayer_WangLinXue_hpp__
