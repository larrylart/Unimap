//============================================================================
//  Bin2x2.hpp                                         Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Bin2x2_hpp__
#define __Bayer_Bin2x2_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateBin2x2
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateBin2x2(
    const ImageImpl< PixelL<T> >& iImage,
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  const uint32 w1 = iImage.GetWidth();
  const uint32 h1 = iImage.GetHeight();
  const uint32 w = w1/2;
  const uint32 h = h1/2;

  // --- inits progress ---
  const float ProgressStep = 1.0f / h1;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w, h) );

  T * prSrc, * prSrcV = (T*)iImage.GetPixel();
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel();

  uint32 x,y;
  EBayerMatrix Bayer;

  for (y=0; y<h; y++, prDstV+=w)
  {
    prSrc = prSrcV + y*2*w1;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc+=2, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR:
          // [B] G1
          //  G2 R
          prDst->_red   = prSrc[w1+1];
          prDst->_green = (prSrc[1] + prSrc[w1])/2;
          prDst->_blue  = prSrc[0];
          break;

        case BM_GBRG:
          // [G] B
          //  R  G
          prDst->_red   = prSrc[w1];
          prDst->_green = (prSrc[0] + prSrc[w1+1])/2;
          prDst->_blue  = prSrc[1];
          break;

        case BM_GRBG:
          // [G] R
          //  B  G
          prDst->_red   = prSrc[1];
          prDst->_green = (prSrc[0] + prSrc[w1+1])/2;
          prDst->_blue  = prSrc[w1];
          break;

        default: // BM_RGGB:
          // [R] G3
          // G4  B
          prDst->_red   = prSrc[0];
          prDst->_green = (prSrc[1] + prSrc[w1])/2;
          prDst->_blue  = prSrc[w1+1];
          break;
      }
    }

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
  return spImageRGB;

} // elxCreateBin2x2

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Bin2x2_hpp__
