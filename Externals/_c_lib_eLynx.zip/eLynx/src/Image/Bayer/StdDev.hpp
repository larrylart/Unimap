//============================================================================
//  Bayer/StdDev.hpp                                   Image.Component package
//============================================================================
//  Usage : image analyse interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_StdDev_hpp__
#define __Bayer_StdDev_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ComputeStdDev: Standard deviation
//----------------------------------------------------------------------------
template <typename T>
bool BayerHandlerImpl<T>::ComputeStandardDeviation(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    double& oMeanR, double& oMeanG, double& oMeanB,
    double& oStdDevR, double& oStdDevG, double& oStdDevB,
    bool ibNormalized)
{
  oStdDevR = oStdDevG = oStdDevB = 0.0;
  if (!iImage.IsValid() || (BM_None == iBayer)) return false;

  typedef typename ResolutionTypeTraits<T>::BigOverflow_type B;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();

  // compute mean first
  B sR = B(0);
  B sG = B(0);
  B sB = B(0);

  const T * prSrc = iImage.GetSamples();
  EBayerMatrix Bayer, Original = iBayer;
  uint32 x,y;
  for (y=0; y<h; y++)
  {
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++)
    {
      switch (Bayer)
      {
        case BM_RGGB: sR += prSrc[0]; break;
        case BM_BGGR: sB += prSrc[0]; break;
        default:      sG += prSrc[0]; break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);
  }
  const uint32 count = iImage.GetSampleCount(); 
  oMeanR = 4.0 * double(sR) / double(count);
  oMeanG = 2.0 * double(sG) / double(count);
  oMeanB = 4.0 * double(sB) / double(count);

  // compute deviation
  double sumR = 0.0;
  double sumG = 0.0;
  double sumB = 0.0;
  double delta;

  prSrc = iImage.GetSamples();
  iBayer = Original;
  for (y=0; y<h; y++)
  {
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++)
    {
      switch (Bayer)
      {
        case BM_RGGB: 
          delta = double(*prSrc) - oMeanR;
          sumR += delta*delta;
          break;
          
        case BM_BGGR: 
          delta = double(*prSrc) - oMeanB;
          sumB += delta*delta;
          break;

        default:      
          delta = double(*prSrc) - oMeanG;
          sumG += delta*delta;
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);
  }

  oStdDevR = Math::elxSqrt( 4.0*sumR / double(count) );
  oStdDevG = Math::elxSqrt( 2.0*sumG / double(count) );
  oStdDevB = Math::elxSqrt( 4.0*sumB / double(count) );

  if (ibNormalized)
  {
    oMeanR *= ResolutionTypeTraits<T>::_normScale;
    oMeanG *= ResolutionTypeTraits<T>::_normScale;
    oMeanB *= ResolutionTypeTraits<T>::_normScale;
    oStdDevR *= ResolutionTypeTraits<T>::_normScale;
    oStdDevG *= ResolutionTypeTraits<T>::_normScale;
    oStdDevB *= ResolutionTypeTraits<T>::_normScale;
  }

  return true;

} // ComputeStdDev


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IBayerHandler implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  ComputeStdDev
//----------------------------------------------------------------------------
template <typename T>
bool BayerHandlerImpl<T>::ComputeStandardDeviation(
    const AbstractImage& iImage, 
    EBayerMatrix iBayer,
    double& oMeanR, double& oMeanG, double& oMeanB,
    double& oStdDevR, double& oStdDevG, double& oStdDevB,
    bool ibNormalized) const
{
  const ImageImpl< PixelL<T> >& image = elxDowncast< PixelL<T> >(iImage);
  return ComputeStandardDeviation(image, iBayer, oMeanR, oMeanG, oMeanB, 
             oStdDevR, oStdDevG, oStdDevB, ibNormalized);

} // ComputeStdDev


} // namespace Image
} // namespace eLynx

#endif // __Bayer_StdDev_hpp__
