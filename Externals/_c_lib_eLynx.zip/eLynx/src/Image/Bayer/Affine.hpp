//============================================================================
//  Bayer/Affine.hpp                                   Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Affine_hpp__
#define __Bayer_Affine_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Affine: transform inplace with clamping
//----------------------------------------------------------------------------
//  r = clamp(iScaleR * r + iOffsetR)
//  g = clamp(iScaleG * g + iOffsetG)
//  b = clamp(iScaleB * b + iOffsetB)
//----------------------------------------------------------------------------
template<typename T>
bool BayerHandlerImpl<T>::Affine(
    ImageImpl< PixelL<T> >& ioImage, 
    EBayerMatrix iBayer,
    double iScaleR, double iOffsetR,
    double iScaleG, double iOffsetG,
    double iScaleB, double iOffsetB)
{
  if (!ioImage.IsValid() || (BM_None == iBayer)) return false;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  T * prSrc = ioImage.GetSamples();

  double v;
  EBayerMatrix Bayer;
  uint32 x,y;
  for (y=0; y<h; y++)
  {
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++)
    {
      switch (Bayer)
      {
        case BM_RGGB: 
          // red
          v = iScaleR * double(*prSrc) + iOffsetR;
          break;
          
        case BM_BGGR: 
          // blue
          v = iScaleB * double(*prSrc) + iOffsetB;
          break;

        default: 
          // green
          v = iScaleG * double(*prSrc) + iOffsetG;
          break;
      }
      *prSrc = ResolutionTypeTraits<T>::Clamp(v);

      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);
  }

  return true;

} // Affine


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IBayerHandler implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Affine
//----------------------------------------------------------------------------
template <typename T>
bool BayerHandlerImpl<T>::Affine(
    AbstractImage& ioImage, 
    EBayerMatrix iBayer,
    double iScaleR, double iOffsetR,
    double iScaleG, double iOffsetG,
    double iScaleB, double iOffsetB) const
{
  ImageImpl< PixelL<T> >& image = elxDowncast< PixelL<T> >(ioImage);
  return Affine(image, iBayer, iScaleR,iOffsetR, iScaleG,iOffsetG, iScaleB,iOffsetB);

} // Affine

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Affine_hpp__
