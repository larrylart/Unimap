//============================================================================
//  Adaptive.hpp                                       Image.Component package
//============================================================================
//
//  RGB "Bayer" Color and MicroLenses 
//
//  http://www.siliconimaging.com/RGB%20Bayer.htm
//  http://scien.stanford.edu/class/psych221/projects/99/tingchen/algodep/edgesense.html
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Adaptive_hpp__
#define __Bayer_Adaptive_hpp__

namespace eLynx {
namespace Image {


//----------------------------------------------------------------------------
//  elxCreateAdaptive
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateAdaptive(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;

  // --- inits progress ---
  const float ProgressStep = 1.0f / h;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );
    
  uint32 x,y;
  EBayerMatrix Bayer;
  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel(border,border);

  T R1,R2,R3,R4, r;
  T G1,G2,G3,G4, g;
  T B1,B2,B3,B4, b;
  T d13,d24;
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR:
          //        B1
          //     R1 G1 R2
          //  B4 G4[B ]G2 B2
          //     R3 G3 R4
          //        B3
                                   B1 = prSrc[-w2];
                R1 = prSrc[-w1-1]; G1 = prSrc[-w1]; R2 = prSrc[-w1+1];
B4 = prSrc[-2]; G4 = prSrc[   -1]; b  = prSrc[  0]; G2 = prSrc[   +1]; B2 = prSrc[+2];
                R3 = prSrc[+w1-1]; G3 = prSrc[+w1]; R4 = prSrc[+w1+1];
                                   B3 = prSrc[+w2];
         
          r = (R1 + R2 + R3 + R4) / 4;

          // adaptive interpolation
          d13 = eLynx::Math::elxAbsDiff(B1, B3);
          d24 = eLynx::Math::elxAbsDiff(B2, B4);
          if (d13 == d24)
            g = (G1 + G2 + G3 + G4) / 4;
          else if (d13 < d24)
            g = (G1 + G3) / 2;
          else
            g = (G2 + G4) / 2;
          break;

        case BM_GBRG:
          //     R1
          // B1 [G ] B2
          //     R2
                          R1 = prSrc[-w1];
          B1 = prSrc[-1]; g  = prSrc[  0]; B2 = prSrc[+1];
                          R2 = prSrc[+w1];

          r = (R1 + R2) / 2;
          b = (B1 + B2) / 2;
          break;

        case BM_GRBG:
          // 
          //     B1
          // R1 [G ] R2
          //     B2
                          B1 = prSrc[-w1];
          R1 = prSrc[-1]; g  = prSrc[  0]; R2 = prSrc[+1];
                          B2 = prSrc[+w1];

          r = (R1 + R2) / 2;
          b = (B1 + B2) / 2;
          break;

        default: // BM_RGGB
          //       R1
          //    B1 G1 B2
          // R4 G4[R ]G2 R2
          //    B3 G3 B4
          //       R3
                                   R1 = prSrc[-w2];
                B1 = prSrc[-w1-1]; G1 = prSrc[-w1]; B2 = prSrc[-w1+1];
R4 = prSrc[-2]; G4 = prSrc[   -1]; r  = prSrc[  0]; G2 = prSrc[   +1]; R2 = prSrc[+2];
                B3 = prSrc[+w1-1]; G3 = prSrc[+w1]; B4 = prSrc[+w1+1];
                                   R3 = prSrc[+w2];
          
          b = (B1 + B2 + B3 + B4) / 4;

          // adaptive interpolation
          d13 = eLynx::Math::elxAbsDiff(R1, R3);
          d24 = eLynx::Math::elxAbsDiff(R2, R4);
          if (d13 == d24)
            g = (G1 + G2 + G3 + G4) / 4;
          else if (d13 < d24)
            g = (G1 + G3) / 2;
          else
            g = (G2 + G4) / 2;
          break;
      }
      prDst->_red   = r;
      prDst->_green = g;
      prDst->_blue  = b;

      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
  spImageL.reset();
  return ImageGeometryImpl< PixelRGB<T> >::CreateSubImage(*spImageRGB, border,border, w,h);
  
} // elxCreateAdaptive

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Adaptive_hpp__
