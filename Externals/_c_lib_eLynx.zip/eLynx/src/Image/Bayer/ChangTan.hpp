//============================================================================
//  ChangTan.hpp                                       Image.Component package
//============================================================================
//
//  Hybrid color filter array demosaicking for effective artifact suppression
//
//  by LanLan Chang and Yap-Peng Tan
//  Journal of Electronic Imaging 15(1), 013003 (Jan�Mar 2006)
//
//  http://www.ntu.edu.sg/home5/CHAN0069/JEI013003.pdf
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_ChangTan_hpp__
#define __Bayer_ChangTan_hpp__

#include "../PointProcessing/Binarize.hpp"

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateChangTan
//----------------------------------------------------------------------------
//                                Algorithm overview
//
// I - Reconstruction process
//
// I.1 - Initialization
// I.1.a - green plane adaptive with Hamilton-Adams interpolation
// I.1.b - red/blue at blue/red using pattern adaptive interpolation
// I.1.c - red/blue at green using pattern adaptive interpolation
//
// I.2 - Enhancement
// I.2.a - green plane using edge weighted interpolation
// I.2.b - red/blue at blue/red using pattern adaptive interpolation
// I.2.c - red/blue at green using pattern adaptive interpolation
//
// II - Refinement process
//
// II.1 - Edge-adaptive median filtering
// II.1.a - Edge adaptive median filtering to remove spurious edges
// II.1.b - Convolution with discrete Laplacian as edge detection
// II.1.c - Build binary edge map using threshold to differenciate 
//          edge regions from smooth regions
// II.1.d - Median filtering in smooth regions
//
// II.2 - Updating step
// II.2.a - Update red/blue at green in smooth regions
// II.2.b - Update red/blue at blue/red in smooth regions 
//          using pattern adaptive interpolation
// II.2.c - Update green in smooth regions using pattern adaptive interpolation
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateChangTan(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

  const int32 w = (int32)iImage.GetWidth();
  const int32 h = (int32)iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;

  // --- inits progress ---
  const float ProgressStep = 1.0f / (8*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<F> > > spImageL =
    elxCreateFloatingExpanded<T, PixelL>(iImage, border);

  // Create temporary ImageRGB<F> image
  boost::shared_ptr< ImageImpl< PixelRGB<F> > >
    spImageRGBTmp( new ImageImpl< PixelRGB<F> >(w1,h1, PixelRGB<F>::Black()) );

  int32 x,y;
  EBayerMatrix Bayer, Original = iBayer;
  
  //----------------------------------------------------------------
  // I.1.a - green plane adaptive with Hamilton-Adams interpolation
  //----------------------------------------------------------------
  F V1,G2,V3,G4,V5,G6,V7,G8,V9,G1,G3;
  F r,g,b, dX,dY, muX,muY;
  F * prSrc, * prSrcV = (F*)spImageL->GetPixel(border,border);
  PixelRGB<F> * prTmp, * prTmpV = spImageRGBTmp->GetPixel(border,border);
  for (y=0; y<h; y++, prSrcV+=w1, prTmpV+=w1)
  {
    prSrc = prSrcV;
    prTmp = prTmpV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prTmp++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          //         V1
          //         G2
          //  V3 G4 [V5] G6 V7
          //         G8
          //         V9
                                  V1 = prSrc[-w2];
                                  G2 = prSrc[-w1];
  V3 = prSrc[-2]; G4 = prSrc[-1]; V5 = prSrc[  0]; G6 = prSrc[+1]; V7 = prSrc[+2]; 
                                  G8 = prSrc[+w1];
                                  V9 = prSrc[+w2];

          muX = 2*V5 - V3 - V7;
          muY = 2*V5 - V1 - V9;
          dX = Math::elxAbs(G4 - G6) + Math::elxAbs(muX);
          dY = Math::elxAbs(G2 - G8) + Math::elxAbs(muY);

          if (dX == dY)
          {
            g = (G2 + G8 + G4 + G6)/4 + (muX + muY)/8;
          }
          else if (dX < dY)
          {
            g = (G4 + G6)/2 + muX/4;
          }
          else // (dX > dY)
          {
            g = (G2 + G8)/2 + muY/4;
          }

          prTmp->_green = g;
        
          // save original color in tmp
          (Bayer == BM_RGGB) ? prTmp->_red=V5 : prTmp->_blue=V5;
          break;

        default: // BM_GBRG   BM_GRBG
          // green is just copied
          prTmp->_green = prSrc[0];
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // no more need of source image
  spImageL.reset();


  //-------------------------------------------------------------------
  // I.1.b - red/blue at blue/red using pattern adaptive interpolation
  //-------------------------------------------------------------------
  F R1,R2,R3,R4, B1,B2,B3,B4, G0, D1,D2;
  F gr1,gr2,gr3,gr4, gb1,gb2,gb3,gb4, gm;
  bool LH1,LH2,LH3,LH4;
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prTmpV+=w1)
  {
    prTmp = prTmpV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prTmp++)
    {
      switch (Bayer)
      {
        case BM_RGGB:
          // interpolate blue at red

          // B1    B2
          //   [R0]
          // B3    B4
G1 = prTmp[-w1-1]._green;                      G2 = prTmp[-w1+1]._green;
B1 = prTmp[-w1-1]._blue;                       B2 = prTmp[-w1+1]._blue;
                          G0 = prTmp[0]._green;
G3 = prTmp[+w1-1]._green;                      G4 = prTmp[+w1+1]._green;
B3 = prTmp[+w1-1]._blue;                       B4 = prTmp[+w1+1]._blue;

          gm = (G1 + G2 + G3 + G4)/4;

          LH1 = G1 > gm;    LH2 = G2 > gm;
          LH3 = G3 > gm;    LH4 = G4 > gm;

          if ((LH1 == LH4) && (LH2 == LH3))
          {
            // stripe pattern
            // L   H      H   L
            //   ?    or    ?
            // H   L      L   H
            D1 = Math::elxAbs(B1 - B4);
            D2 = Math::elxAbs(B2 - B3);
            if (D1 < D2)
              b = G0 + (B1 + B4 - G1 - G4)/2;
            else
              b = G0 + (B2 + B3 - G2 - G3)/2;
          }
          else
          {
            gb1 = G1 - B1;    gb2 = G2 - B2;
            gb3 = G3 - B3;    gb4 = G4 - B4;
            b = G0 - Math::elxMedian(gb1,gb2,gb3,gb4);
          }

          prTmp->_blue = b;
          break;
       
        case BM_BGGR:
          // interpolate red at blue

          // R1    R2
          //   [B0]
          // R3    R4
G1 = prTmp[-w1-1]._green;                      G2 = prTmp[-w1+1]._green;
R1 = prTmp[-w1-1]._red;                        R2 = prTmp[-w1+1]._red;
                          G0 = prTmp[0]._green;
G3 = prTmp[+w1-1]._green;                      G4 = prTmp[+w1+1]._green;
R3 = prTmp[+w1-1]._red;                        R4 = prTmp[+w1+1]._red;

          gm = (G1 + G2 + G3 + G4)/4;

          LH1 = G1 > gm;    LH2 = G2 > gm;
          LH3 = G3 > gm;    LH4 = G4 > gm;

          if ((LH1 == LH4) && (LH2 == LH3))
          {
            // stripe pattern
            // L   H      H   L
            //   ?    or    ?
            // H   L      L   H
            D1 = Math::elxAbs(R1 - R4);
            D2 = Math::elxAbs(R2 - R3);
            if (D1 < D2)
              r = G0 + (R1 + R4 - G1 - G4)/2;
            else
              r = G0 + (R2 + R3 - G2 - G3)/2;
          }
          else
          {
            gr1 = G1 - R1;    gr2 = G2 - R2;
            gr3 = G3 - R3;    gr4 = G4 - R4;
            r = G0 - Math::elxMedian(gr1,gr2,gr3,gr4);
          }

          prTmp->_red = r;
          break;

        default: // BM_GBRG, BM_GRBG
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }


  //-------------------------------------------------------------------
  // I.1.c - red/blue at green using pattern adaptive interpolation
  //-------------------------------------------------------------------
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prTmpV+=w1)
  {
    prTmp = prTmpV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prTmp++)
    {
      switch (Bayer)
      {
        case BM_GRBG: case BM_GBRG:
          // interpolate blue at green

          //     B1          R1     
          // R2 [G0] R3  B2 [G0] B3
          //     B4          R4

                       R1 = prTmp[-w1]._red; 
                       G1 = prTmp[-w1]._green;
                       B1 = prTmp[-w1]._blue;
R2 = prTmp[-1]._red;                           R3 = prTmp[+1]._red;
G2 = prTmp[-1]._green; G0 = prTmp[  0]._green; G3 = prTmp[+1]._green;
B2 = prTmp[-1]._blue;                          B2 = prTmp[+1]._blue;
                       R4 = prTmp[+w1]._red;
                       G4 = prTmp[+w1]._green;
                       B4 = prTmp[+w1]._blue;

          gm = (G1 + G2 + G3 + G4)/4;

          LH1 = G1 > gm;    LH2 = G2 > gm;
          LH3 = G3 > gm;    LH4 = G4 > gm;

          if ((LH1 == LH4) && (LH2 == LH3))
          {
            // stripe pattern
            // L   H      H   L
            //   ?    or    ?
            // H   L      L   H

            // red
            D1 = Math::elxAbs(R1 - R4);
            D2 = Math::elxAbs(R2 - R3);
            if (D1 < D2)
              r = G0 + (R1 + R4 - G1 - G4)/2;
            else
              r = G0 + (R2 + R3 - G2 - G3)/2;

            // blue
            D1 = Math::elxAbs(B1 - B4);
            D2 = Math::elxAbs(B2 - B3);
            if (D1 < D2)
              b = G0 + (B1 + B4 - G1 - G4)/2;
            else
              b = G0 + (B2 + B3 - G2 - G3)/2;
          }
          else
          {
            // red
            gr1 = G1 - R1;    gr2 = G2 - R2;
            gr3 = G3 - R3;    gr4 = G4 - R4;
            r = G0 - Math::elxMedian(gr1,gr2,gr3,gr4);

            // blue
            gb1 = G1 - B1;    gb2 = G2 - B2;
            gb3 = G3 - B3;    gb4 = G4 - B4;
            b = G0 - Math::elxMedian(gb1,gb2,gb3,gb4);
          }

          prTmp->_red  = r;
          prTmp->_blue = b;
          break;
       
        default: // BM_BGGR, BM_RGGB
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }


  //-------------------------------------------------------
  // I.2.a - green plane using edge weighted interpolation
  //-------------------------------------------------------
  F G23,G32,G34,G43, a1,a2,a3,a4;
  F V13,V23,V31,V32,V33,V34,V35,V43,V53;
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prTmpV+=w1)
  {
    prTmp = prTmpV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prTmp++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          //          V13
          //          G23              1
          //  V31 G32[V33]G34 V35    3 0 4
          //          G43              2
          //          V53
                         G23 = prTmp[-w1]._green;
  G32 = prTmp[-1]._green;                        G34 = prTmp[+1]._green;
                         G43 = prTmp[+w1]._green;

          if (Bayer == BM_BGGR)
          {
            // blue
                                              V13 = prTmp[-w2]._blue;
                                              V23 = prTmp[-w1]._blue;
V31 = prTmp[-2]._blue; V32 = prTmp[-1]._blue; V33 = prTmp[  0]._blue; V34 = prTmp[+1]._blue;  V35 = prTmp[+2]._blue; 
                                              V43 = prTmp[+w1]._blue;
                                              V53 = prTmp[+w2]._blue;
          }
          else // BM_RGGB
          {
            // red
                                            V13 = prTmp[-w2]._red;
                                            V23 = prTmp[-w1]._red;
V31 = prTmp[-2]._red; V32 = prTmp[-1]._red; V33 = prTmp[  0]._red; V34 = prTmp[+1]._red;  V35 = prTmp[+2]._red; 
                                            V43 = prTmp[+w1]._red;
                                            V53 = prTmp[+w2]._red;
          }

          G1 = V33 + G23 - V23;
          G2 = V33 + G43 - V43;
          G3 = V33 + G32 - V32;
          G4 = V33 + G34 - V34;

          a1 = Math::elxAbs(V13-V33) + Math::elxAbs(G23-G43) + Math::elxAbs(V23-V33);
          a2 = Math::elxAbs(V53-V33) + Math::elxAbs(G43-G23) + Math::elxAbs(V43-V33);
          a3 = Math::elxAbs(V31-V33) + Math::elxAbs(G32-G34) + Math::elxAbs(V32-V33);
          a4 = Math::elxAbs(V35-V33) + Math::elxAbs(G34-G32) + Math::elxAbs(V34-V33);

          a1 = 1/(1+a1); a2 = 1/(1+a2); a3 = 1/(1+a3); a4 = 1/(1+a4);

          g = (a1*G1 + a2*G2 + a3*G3 + a4*G4) / 
                    (a1 + a2 + a3 + a4);

          prTmp->_green = g;
          break;

        default: // BM_GBRG   BM_GRBG
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }


  //-------------------------------------------------------------------
  // I.2.b - red/blue at blue/red using pattern adaptive interpolation
  //-------------------------------------------------------------------
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prTmpV+=w1)
  {
    prTmp = prTmpV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prTmp++)
    {
      switch (Bayer)
      {
        case BM_RGGB:
          // interpolate blue at red

          // B1    B2
          //   [R0]
          // B3    B4
G1 = prTmp[-w1-1]._green;                      G2 = prTmp[-w1+1]._green;
B1 = prTmp[-w1-1]._blue;                       B2 = prTmp[-w1+1]._blue;
                          G0 = prTmp[0]._green;
G3 = prTmp[+w1-1]._green;                      G4 = prTmp[+w1+1]._green;
B3 = prTmp[+w1-1]._blue;                       B4 = prTmp[+w1+1]._blue;

          gm = (G1 + G2 + G3 + G4)/4;

          LH1 = G1 > gm;    LH2 = G2 > gm;
          LH3 = G3 > gm;    LH4 = G4 > gm;

          if ((LH1 == LH4) && (LH2 == LH3))
          {
            // stripe pattern
            // L   H      H   L
            //   ?    or    ?
            // H   L      L   H
            D1 = Math::elxAbs(B1 - B4);
            D2 = Math::elxAbs(B2 - B3);
            if (D1 < D2)
              b = G0 + (B1 + B4 - G1 - G4)/2;
            else
              b = G0 + (B2 + B3 - G2 - G3)/2;
          }
          else
          {
            gb1 = G1 - B1;    gb2 = G2 - B2;
            gb3 = G3 - B3;    gb4 = G4 - B4;
            b = G0 - Math::elxMedian(gb1,gb2,gb3,gb4);
          }

          prTmp->_blue = b;
          break;
       
        case BM_BGGR:
          // interpolate red at blue

          // R1    R2
          //   [B0]
          // R3    R4
G1 = prTmp[-w1-1]._green;                      G2 = prTmp[-w1+1]._green;
R1 = prTmp[-w1-1]._red;                        R2 = prTmp[-w1+1]._red;
                          G0 = prTmp[0]._green;
G3 = prTmp[+w1-1]._green;                      G4 = prTmp[+w1+1]._green;
R3 = prTmp[+w1-1]._red;                        R4 = prTmp[+w1+1]._red;

          gm = (G1 + G2 + G3 + G4)/4;

          LH1 = G1 > gm;    LH2 = G2 > gm;
          LH3 = G3 > gm;    LH4 = G4 > gm;

          if ((LH1 == LH4) && (LH2 == LH3))
          {
            // stripe pattern
            // L   H      H   L
            //   ?    or    ?
            // H   L      L   H
            D1 = Math::elxAbs(R1 - R4);
            D2 = Math::elxAbs(R2 - R3);
            if (D1 < D2)
              r = G0 + (R1 + R4 - G1 - G4)/2;
            else
              r = G0 + (R2 + R3 - G2 - G3)/2;
          }
          else
          {
            gr1 = G1 - R1;    gr2 = G2 - R2;
            gr3 = G3 - R3;    gr4 = G4 - R4;
            r = G0 - Math::elxMedian(gr1,gr2,gr3,gr4);
          }
  
          prTmp->_red = r;
          break;

        default: // BM_GBRG, BM_GRBG
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }


  //-------------------------------------------------------------------
  // I.2.c - red/blue at green using pattern adaptive interpolation
  //-------------------------------------------------------------------

  // allocate color difference images
  boost::shared_ptr< ImageImpl< PixelL<F> > > 
    spDeltaR( new ImageImpl< PixelL<F> >(w1,h1,PixelL<F>::Black()) );

  boost::shared_ptr< ImageImpl< PixelL<F> > > 
    spDeltaB( new ImageImpl< PixelL<F> >(w1,h1,PixelL<F>::Black()) );

  F * prDcR, * prDcRV = (F*)spDeltaR->GetPixel(border,border);
  F * prDcB, * prDcBV = (F*)spDeltaB->GetPixel(border,border);

  prDcRV = (F*)spDeltaR->GetPixel(border,border);
  prDcBV = (F*)spDeltaB->GetPixel(border,border);
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++,     
    prTmpV+=w1, prDcRV+=w1, prDcBV+=w1)
  {
    prTmp = prTmpV;
    prDcR = prDcRV;
    prDcB = prDcBV;
    Bayer = iBayer;
    for (x=0; x<w; x++, 
        prTmp++, prDcR++, prDcB++)
    {
      switch (Bayer)
      {
        case BM_GRBG: case BM_GBRG:
          // interpolate blue at green

          //     B1          R1     
          // R2 [G0] R3  B2 [G0] B3
          //     B4          R4

                       R1 = prTmp[-w1]._red; 
                       G1 = prTmp[-w1]._green;
                       B1 = prTmp[-w1]._blue;
R2 = prTmp[-1]._red;                           R3 = prTmp[+1]._red;
G2 = prTmp[-1]._green; G0 = prTmp[  0]._green; G3 = prTmp[+1]._green;
B2 = prTmp[-1]._blue;                          B2 = prTmp[+1]._blue;
                       R4 = prTmp[+w1]._red;
                       G4 = prTmp[+w1]._green;
                       B4 = prTmp[+w1]._blue;

          gm = (G1 + G2 + G3 + G4)/4;

          LH1 = G1 > gm;    LH2 = G2 > gm;
          LH3 = G3 > gm;    LH4 = G4 > gm;

          if ((LH1 == LH4) && (LH2 == LH3))
          {
            // stripe pattern
            // L   H      H   L
            //   ?    or    ?
            // H   L      L   H

            // red
            D1 = Math::elxAbs(R1 - R4);
            D2 = Math::elxAbs(R2 - R3);
            if (D1 < D2)
              r = G0 + (R1 + R4 - G1 - G4)/2;
            else
              r = G0 + (R2 + R3 - G2 - G3)/2;

            // blue
            D1 = Math::elxAbs(B1 - B4);
            D2 = Math::elxAbs(B2 - B3);
            if (D1 < D2)
              b = G0 + (B1 + B4 - G1 - G4)/2;
            else
              b = G0 + (B2 + B3 - G2 - G3)/2;
          }
          else
          {
            // red
            gr1 = G1 - R1;    gr2 = G2 - R2;
            gr3 = G3 - R3;    gr4 = G4 - R4;
            r = G0 - Math::elxMedian(gr1,gr2,gr3,gr4);

            // blue
            gb1 = G1 - B1;    gb2 = G2 - B2;
            gb3 = G3 - B3;    gb4 = G4 - B4;
            b = G0 - Math::elxMedian(gb1,gb2,gb3,gb4);
          }

          prTmp->_red  = r;
          prTmp->_blue = b;

          *prDcR = G0 - r;
          *prDcB = G0 - b;
          break;
       
        default: // BM_BGGR, BM_RGGB
          *prDcR = prTmp->_green - prTmp->_red;
          *prDcB = prTmp->_green - prTmp->_blue;
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //------------------------------------------------------------------
  // II.1.a - Edge adaptive median filtering to remove spurious edges
  //------------------------------------------------------------------
  //-------------------------------------------------------------------
  // allocate copy of color difference images 
  // to apply median on smooth regions later
  //-------------------------------------------------------------------
  boost::shared_ptr< ImageImpl< PixelL<F> > > 
    spMedR( new ImageImpl< PixelL<F> >(*spDeltaR) );

  boost::shared_ptr< ImageImpl< PixelL<F> > > 
    spMedB( new ImageImpl< PixelL<F> >(*spDeltaB) );

  ImageMorphologicalProcessingImpl< PixelL<F> >::ApplyMedianWxH(*spMedR, 5,5);
  ImageMorphologicalProcessingImpl< PixelL<F> >::ApplyMedianWxH(*spMedB, 5,5);


  //----------------------------------------------------------------
  // II.1.b - Convolution with discrete Laplacian as edge detection
  //----------------------------------------------------------------
  const double kernel[] = {
    0.0909,  0.8182, 0.0909, 
    0.8182, -3.6364, 0.8182,
    0.0909,  0.8182, 0.0909
  };
  const Math::ConvolutionKerneld Laplacian3x3(3,3, kernel);

  ImageLocalProcessingImpl< PixelL<F> >::Convolve3x3(*spMedR, Laplacian3x3);
  ImageLocalProcessingImpl< PixelL<F> >::Convolve3x3(*spMedB, Laplacian3x3);

  //-----------------------------------------------------------------
  // II.1.c - Build binary edge map using threshold to differenciate 
  //          edge regions from smooth regions
  //-----------------------------------------------------------------

  // 0 = Edge, 255 = Smooth
  const F Threshold = F(10);
  const bool bNegative = true;

  boost::shared_ptr< ImageLub > spBinaryR = 
    elxCreateBinarized<F>(*spMedR, Threshold, bNegative);

  boost::shared_ptr< ImageLub > spBinaryB =
    elxCreateBinarized<F>(*spMedB, Threshold, bNegative);

  // no more need of median filtered images
  spMedR.reset();
  spMedB.reset();

  //---------------------------------------------
  // II.1.d - Median filtering in smooth regions
  //---------------------------------------------
  ImageMorphologicalProcessingImpl< PixelL<F> >::ApplyMedian3x3(*spDeltaR, *spBinaryR);
  ImageMorphologicalProcessingImpl< PixelL<F> >::ApplyMedian3x3(*spDeltaB, *spBinaryB);

  //-----------------------------------------------------
  // II.2.a - Update red/blue at green in smooth regions
  //-----------------------------------------------------
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  prDcRV = (F*)spDeltaR->GetPixel(border,border);
  prDcBV = (F*)spDeltaB->GetPixel(border,border);
  uint8 * prBinR, * prBinRV = spBinaryR->GetSamples();
  uint8 * prBinB, * prBinBV = spBinaryB->GetSamples();
  iBayer = Original;
  for (y=0; y<h; y++, 
      prTmpV+=w1, prDcRV+=w1, prDcBV+=w1, prBinRV+=w1, prBinBV+=w1)
  {
    prTmp = prTmpV;
    prDcR = prDcRV;
    prDcB = prDcBV;
    prBinR = prBinRV;
    prBinB = prBinBV;
    Bayer = iBayer;
    for (x=0; x<w; x++, 
      prTmp++, prDcR++, prDcB++, prBinR++, prBinB++)
    {
      switch (Bayer)
      {
        case BM_GRBG: case BM_GBRG:
          // interpolate blue at green

          //     B1          R1
          // R2 [G0] R3  B2 [G0] B3
          //     B4          R4
          if (*prBinR)
          {
            // update red in smooth regions
            G0 = prTmp[0]._green;
            if (Bayer == BM_GRBG)
            {
              // horizontal red interpolation
              prTmp->_red = G0 - (prDcR[-1] + prDcR[+1])/2;
            }
            else // BM_GBRG
            {
              // vertical red interpolation
              prTmp->_red = G0 - (prDcR[-w] + prDcR[+w])/2;
            }
          }

          if (*prBinB)
          {
            G0 = prTmp[0]._green;
            // update blue in smooth regions
            if (Bayer == BM_GBRG)
            {
              // horizontal blue interpolation
              prTmp->_blue = G0 - (prDcB[-1] + prDcB[+1])/2;
            }
            else // BM_GRBG
            {
              // vertical blue interpolation
              prTmp->_blue = G0 - (prDcB[-w] + prDcB[+w])/2;
            }
          }
          break;
       
        default: // BM_BGGR, BM_RGGB
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //--------------------------------------------------------
  // II.2.b - Update red/blue at blue/red in smooth regions 
  //          using pattern adaptive interpolation
  //--------------------------------------------------------
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  prDcRV = (F*)spDeltaR->GetPixel(border,border);
  prDcBV = (F*)spDeltaB->GetPixel(border,border);
  prBinRV = (uint8*)spBinaryR->GetPixel(border,border);
  prBinBV = (uint8*)spBinaryB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, 
      prTmpV+=w1, prDcRV+=w1, prDcBV+=w1, prBinRV+=w1, prBinBV+=w1)
  {
    prTmp = prTmpV;
    prDcR = prDcRV;    
    prDcB = prDcBV;
    prBinR = prBinRV;
    prBinB = prBinBV;
    Bayer = iBayer;
    for (x=0; x<w; x++, 
        prTmp++, prDcR++, prDcB++, prBinR++, prBinB++)
    {
      switch (Bayer)
      {
        case BM_RGGB:
          if (*prBinB)
          {
            // interpolate blue at red in smooth regions

            //     G1
            // G2 [R0] G3
            //     G4
                       G1 = prTmp[-w1]._green;
                       B1 = prTmp[-w1]._blue;
G2 = prTmp[-1]._green; G0 = prTmp[  0]._green; G3 = prTmp[+1]._green;
B2 = prTmp[-1]._blue;                          B3 = prTmp[+1]._blue;
                       G4 = prTmp[+w1]._green;
                       B4 = prTmp[+w1]._blue;

            gm = (G1 + G2 + G3 + G4)/4;

            gb1 = prDcB[-w1-1]; gb2 = prDcB[-w1+1];
            gb3 = prDcB[+w1-1]; gb4 = prDcB[+w1+1];

            LH1 = G1 > gm;    LH2 = G2 > gm;
            LH3 = G3 > gm;    LH4 = G4 > gm;

            if ((LH1 == LH4) && (LH2 == LH3))
            {
              // stripe pattern
              //   L         H
              // H ? H  or L ? L
              //   L         H
              D1 = Math::elxAbs(B1 - B4);
              D2 = Math::elxAbs(B2 - B3);
              if (D1 < D2)
                prTmp->_blue = G0 - (gb1 + gb4)/2;
              else
                prTmp->_blue = G0 - (gb2 + gb3)/2;
            }
            else
            {
              prTmp->_blue = G0 - Math::elxMedian(gb1,gb2,gb3,gb4);
            }
          }
          break;
       
        case BM_BGGR:
          if (*prBinR)
          {
            // interpolate red at blue in smooth regions

            //     G1
            // G2 [B0] G3
            //     G4
                       G1 = prTmp[-w1]._green;
                       R1 = prTmp[-w1]._red;
G2 = prTmp[-1]._green; G0 = prTmp[  0]._green; G3 = prTmp[+1]._green;
R2 = prTmp[-1]._red;                           R3 = prTmp[+1]._red;
                       G4 = prTmp[+w1]._green;
                       R4 = prTmp[+w1]._red;

            gm = (G1 + G2 + G3 + G4)/4;

            gr1 = prDcR[-w1-1]; gr2 = prDcR[-w1+1];
            gr3 = prDcR[+w1-1]; gr4 = prDcR[+w1+1];

            LH1 = G1 > gm;    LH2 = G2 > gm;
            LH3 = G3 > gm;    LH4 = G4 > gm;

            if ((LH1 == LH4) && (LH2 == LH3))
            {
              // stripe pattern
              //   L         H
              // H ? H  or L ? L
              //   L         H
              D1 = Math::elxAbs(R1 - R4);
              D2 = Math::elxAbs(R2 - R3);
              if (D1 < D2)
                prTmp->_red = G0 - (gr1 + gr4)/2;
              else
                prTmp->_red = G0 - (gr2 + gr3)/2;
            }
            else
            {
              prTmp->_red = G0 - Math::elxMedian(gr1,gr2,gr3,gr4);
            }
          }
          break;

        default: // BM_GBRG, BM_GRBG
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }


  //-----------------------------------------------
  // II.2.c - Update green in smooth regions 
  //          using pattern adaptive interpolation
  //-----------------------------------------------
  F B0,R0;
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  prDcRV = (F*)spDeltaR->GetPixel(border,border);
  prDcBV = (F*)spDeltaB->GetPixel(border,border);
  prBinRV = (uint8*)spBinaryR->GetPixel(border,border);
  prBinBV = (uint8*)spBinaryB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, 
      prTmpV+=w1, prDcRV+=w1, prDcBV+=w1, prBinRV+=w1, prBinBV+=w1)
  {
    prTmp = prTmpV;
    prDcR = prDcRV;
    prDcB = prDcBV;
    prBinR = prBinRV;
    prBinB = prBinBV;
    Bayer = iBayer;
    for (x=0; x<w; x++, 
      prTmp++, prDcR++, prDcB++, prBinR++, prBinB++)
    {
      switch (Bayer)
      {
        case BM_BGGR:
          if (*prBinB)
          {
            // interpolate green at blue

            //     G1
            // G2 [B0] G3
            //     G4
                          G1 = prTmp[-w1]._green;
                          B1 = prTmp[-w1]._blue;
            G2 = prTmp[-1]._green;  G3 = prTmp[+1]._green;
            B2 = prTmp[-1]._blue;   B3 = prTmp[+1]._blue;
                          G4 = prTmp[+w1]._green;
                          B4 = prTmp[+w1]._blue;

            B0 = prTmp[0]._blue;
            gm = (G1 + G2 + G3 + G4)/4;

            LH1 = G1 > gm;  LH2 = G2 > gm;
            LH3 = G3 > gm;  LH4 = G4 > gm;

            if ((LH1 == LH4) && (LH2 == LH3))
            {
              // stripe pattern
              //   L           H
              // H ? H   or  L ? L
              //   L           H
              D1 = Math::elxAbs(G1 - G4);
              D2 = Math::elxAbs(G2 - G3);
              if (D1 < D2)
              {
                gb1 = -prDcB[-w1]; gb4 = -prDcB[+w1];
                prTmp->_green = B0 - (gb1 + gb4)/2;
              }
              else
              {
                gb2 = -prDcB[-1]; gb3 = -prDcB[+1]; 
                prTmp->_green = B0 - (gb2 + gb3)/2;
              }
            }
            else
            {
                         gb1 = -prDcB[-w1]; 
              gb2 = -prDcB[-1]; gb3 = -prDcB[+1]; 
                         gb4 = -prDcB[+w1];
              prTmp->_green = B0 - Math::elxMedian(gb1,gb2,gb3,gb4);
            }
          }
          break;

        case BM_RGGB:
          if (*prBinR)
          {
            // interpolate green at red

            //     G1
            // G2 [R0] G3
            //     G4
                          G1 = prTmp[-w1]._green;
                          R1 = prTmp[-w1]._red;
            G2 = prTmp[-1]._green;  G3 = prTmp[+1]._green;
            R2 = prTmp[-1]._red;    R3 = prTmp[+1]._red;
                          G4 = prTmp[+w1]._green;
                          R4 = prTmp[+w1]._red;

            R0 = prTmp[0]._red;
            gm = (G1 + G2 + G3 + G4)/4;

            LH1 = G1 > gm;  LH2 = G2 > gm;
            LH3 = G3 > gm;  LH4 = G4 > gm;

            if ((LH1 == LH4) && (LH2 == LH3))
            {
              // stripe pattern
              //   L           H
              // H ? H   or  L ? L
              //   L           H
              D1 = Math::elxAbs(G1 - G4);
              D2 = Math::elxAbs(G2 - G3);
              if (D1 < D2)
              {
                gr1 = -prDcR[-w1]; gr4 = -prDcR[+w1];
                prTmp->_green = R0 - (gr1 + gr4)/2;
              }
              else
              {
                gr2 = -prDcR[-1]; gr3 = -prDcR[+1]; 
                prTmp->_green = R0 - (gr2 + gr3)/2;
              }
            }
            else
            {
                         gr1 = -prDcR[-w1]; 
              gr2 = -prDcR[-1]; gr3 = -prDcR[+1]; 
                         gr4 = -prDcR[+w1];

              prTmp->_green = R0 - Math::elxMedian(gr1,gr2,gr3,gr4);
            }
          }
          break;

        default: // BM_GBRG, BM_GRBG
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // no more need of color diff images
  spDeltaR.reset();
  spDeltaB.reset();

  // no more need of binary map images
  spBinaryR.reset();
  spBinaryB.reset();

  //-------------------------------------------------------------------
  // back to T resolution with border cropping
  //-------------------------------------------------------------------

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w,h) );
  
  prTmpV = spImageRGBTmp->GetPixel(border,border);
  PixelRGB<T> * prDst = spImageRGB->GetPixel();
#if 1
  for (y=0; y<h; y++, prTmpV+=w1)
  {
    prTmp = prTmpV;
    for (x=0; x<w; x++, prTmp++, prDst++)
    {
      prDst->_red   = ResolutionTypeTraits<T>::ClampF( prTmp->_red );
      prDst->_green = ResolutionTypeTraits<T>::ClampF( prTmp->_green );
      prDst->_blue  = ResolutionTypeTraits<T>::ClampF( prTmp->_blue );
    }
  }
#else
  prBinR = psBinaryR->GetSamples();
  prBinB = psBinaryB->GetSamples();
  for (y=0; y<h; y++, prTmpV+=w1)
  {
    prTmp = prTmpV;
    for (x=0; x<w; x++, 
        prDst++, prBinR++, prBinB++)
    {
      prDst->_red   = *prBinR;
      prDst->_green = ResolutionTypeTraits<T>::ClampF( prTmp->_green );
      prDst->_blue  = *prBinB;
    }
  }
#endif


  // --- progress end ---
  iNotifier.SetProgress(1.0f);

  return spImageRGB;

} // elxCreateChangTan

} // namespace Image
} // namespace eLynx

#endif // __Bayer_ChangTan_hpp__
