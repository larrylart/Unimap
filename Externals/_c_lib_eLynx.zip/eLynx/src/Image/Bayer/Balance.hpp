//============================================================================
//  Bayer/Balance.hpp                                  Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Balance_hpp__
#define __Bayer_Balance_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

// Define all types and covers all lut types
template <typename T, class MainType=LutType>
struct RampHelper
{
  typedef T type;
  RampHelper(double iRed, double iGreen, double iBlue)
  {    
    _rampR.Mul(iRed);
    _rampG.Mul(iGreen);
    _rampB.Mul(iBlue);

    _prRampR = _rampR.GetRamp();
    _prRampG = _rampG.GetRamp();
    _prRampB = _rampB.GetRamp();
  }

  void UpdateRed(T& ioRed)     const { ioRed   = _prRampR[ioRed]; }
  void UpdateGreen(T& ioGreen) const { ioGreen = _prRampG[ioGreen]; }
  void UpdateBlue(T& ioBlue)   const { ioBlue  = _prRampB[ioBlue]; }

private:
  Math::Ramp<T> _rampR, _rampG, _rampB;
  const T * _prRampR;
  const T * _prRampG;
  const T * _prRampB;
};

// Specialization # non lut type
template <typename T>
struct RampHelper<T, NonLutType>
{
  RampHelper (double iRed, double iGreen, double iBlue) :
    _red((T)iRed), _green((T)iGreen), _blue((T)iBlue)
  {}

  void UpdateRed(T& ioRed)     const { ioRed   *= _red; }
  void UpdateGreen(T& ioGreen) const { ioGreen *= _green; }
  void UpdateBlue(T& ioBlue)   const { ioBlue  *= _blue; }
private:
  T _red, _green, _blue;
};


//----------------------------------------------------------------------------
//  Balance
//----------------------------------------------------------------------------
template<typename T>
bool BayerHandlerImpl<T>::Balance(
    ImageImpl< PixelL<T> >& ioImage,
    EBayerMatrix iBayer, 
    double iRed, double iGreen, double iBlue)
{
  if (!ioImage.IsValid())
    return false;
  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  T * prDst = ioImage.GetSamples();

  RampHelper<T, LutToType<ResolutionTypeTraits<T>::_bLUT> >
    rampHelper(iRed, iGreen, iBlue);

  uint32 x,y;
  EBayerMatrix Bayer;
  for (y=0; y<h; y++)
  {
    Bayer = iBayer;
    for (x=0; x<w; x++, prDst++)
    {
      switch(Bayer)
      {
        case BM_RGGB: rampHelper.UpdateRed(*prDst); break;
        case BM_BGGR: rampHelper.UpdateBlue(*prDst); break;
        default:      rampHelper.UpdateGreen(*prDst); break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);
  }
  return true;

} // Balance


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IBayerHandler implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Balance
//----------------------------------------------------------------------------
template <typename T>
bool BayerHandlerImpl<T>::Balance(
    AbstractImage& ioImage, 
    EBayerMatrix iBayer,
    double iRed, double iGreen, double iBlue) const
{
  ImageImpl< PixelL<T> >& image = elxDowncast< PixelL<T> >(ioImage);
  return Balance(image, iBayer, iRed, iGreen, iBlue);

} // Balance

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Balance_hpp__
