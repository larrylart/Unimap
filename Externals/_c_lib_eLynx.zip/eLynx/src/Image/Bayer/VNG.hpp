//============================================================================
//  VNG.hpp                                            Image.Component package
//============================================================================
//
//  Color Filter Array Recovery Using a Threshold-based Variable Number of Gradients
//
//  by Ed Chang, Shiufun Cheung and Davis Pan
//  http://scien.stanford.edu/class/psych221/projects/99/tingchen/algodep/vargra.html
//----------------------------------------------------------------------------

//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_VNG_hpp__
#define __Bayer_VNG_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateVNG
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateVNG(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 w2 = 2*w1;

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w,h, PixelRGB<T>::Black()) );
    
  M Va[26], Vb[26], G[26];
  M N,E,S,W,NE,SE,NW,SW,TR,Tmin,Tmax;  
  M g, v, va, vb;
  uint32 x,y;
  int32 count;
  
  EBayerMatrix Bayer;
  const PixelL<T> * prSrc, * prSrcV = spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, *prDstV = spImageRGB->GetPixel();

  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_RGGB: case BM_BGGR:
          //  Va1  G2   Va3   G4   Va5
          //  G6   Vb7  G8    Vb9  G10
          //  Va11 G12 [Va13] G14  Va15
          //  G16  Vb17 G18   Vb19 G20
          //  Va21 G22  Va23  G24  Va25
          Va[1]=prSrc[-w2-2]._luminance; G[2]=prSrc[-w2-1]._luminance;  Va[3]=prSrc[-w2]._luminance; G[4]=prSrc[-w2+1]._luminance;  Va[5]=prSrc[-w2+2]._luminance;
          G[6]=prSrc[-w1-2]._luminance;  Vb[7]=prSrc[-w1-1]._luminance; G[8]=prSrc[-w1]._luminance;  Vb[9]=prSrc[-w1+1]._luminance; G[10]=prSrc[-w1+2]._luminance;
          Va[11]=prSrc[-2]._luminance;   G[12]=prSrc[-1]._luminance;    Va[13]=prSrc[0]._luminance;  G[14]=prSrc[+1]._luminance;    Va[15]=prSrc[+2]._luminance;
          G[16]=prSrc[w1-2]._luminance;  Vb[17]=prSrc[w1-1]._luminance; G[18]=prSrc[w1]._luminance;  Vb[19]=prSrc[w1+1]._luminance; G[20]=prSrc[w1+2]._luminance;
          Va[21]=prSrc[w2-2]._luminance; G[22]=prSrc[w2-1]._luminance;  Va[23]=prSrc[w2]._luminance; G[24]=prSrc[w2+1]._luminance;  Va[25]=prSrc[w2+2]._luminance;
          
          N = Math::elxAbs(G[8]-G[18]) + Math::elxAbs(Va[3]-Va[13]) + 
            Math::elxAbs(Vb[7]-Vb[17])/2 + Math::elxAbs(Vb[9]-Vb[19])/2 +
            Math::elxAbs(G[2]-G[12])/2 + Math::elxAbs(G[4]-G[14])/2;
            
          E = Math::elxAbs(G[14]-G[12]) + Math::elxAbs(Va[15]-Va[13]) + 
            Math::elxAbs(Vb[9]-Vb[7])/2 + Math::elxAbs(Vb[19]-Vb[17])/2 +
            Math::elxAbs(G[10]-G[8])/2 + Math::elxAbs(G[20]-G[18])/2;
            
          S = Math::elxAbs(G[18]-G[8]) + Math::elxAbs(Va[23]-Va[13]) + 
            Math::elxAbs(Vb[19]-Vb[9])/2 + Math::elxAbs(Vb[17]-Vb[7])/2 +
            Math::elxAbs(G[24]-G[14])/2 + Math::elxAbs(G[22]-G[12])/2;
            
          W = Math::elxAbs(G[12]-G[14]) + Math::elxAbs(Va[11]-Va[13]) + 
            Math::elxAbs(Vb[17]-Vb[19])/2 + Math::elxAbs(Vb[7]-Vb[9])/2 +
            Math::elxAbs(G[16]-G[18])/2 + Math::elxAbs(G[6]-G[8])/2;
            
          NE = Math::elxAbs(Vb[9]-Vb[17]) + Math::elxAbs(Va[5]-Va[13]) + 
            Math::elxAbs(G[8]-G[12])/2 + Math::elxAbs(G[14]-G[18])/2 +
            Math::elxAbs(G[4]-G[8])/2 + Math::elxAbs(G[10]-G[14])/2;
            
          SE = Math::elxAbs(Vb[19]-Vb[7]) + Math::elxAbs(Va[25]-Va[13]) + 
            Math::elxAbs(G[14]-G[8])/2 + Math::elxAbs(G[18]-G[12])/2 +
            Math::elxAbs(G[20]-G[14])/2 + Math::elxAbs(G[24]-G[18])/2;
            
          NW = Math::elxAbs(Vb[7]-Vb[19]) + Math::elxAbs(Va[1]-Va[13]) + 
            Math::elxAbs(G[12]-G[18])/2 + Math::elxAbs(G[8]-G[14])/2 +
            Math::elxAbs(G[6]-G[12])/2 + Math::elxAbs(G[2]-G[8])/2;
            
          SW = Math::elxAbs(Vb[17]-Vb[9]) + Math::elxAbs(Va[21]-Va[13]) + 
            Math::elxAbs(G[18]-G[14])/2 + Math::elxAbs(G[12]-G[8])/2 +
            Math::elxAbs(G[22]-G[18])/2 + Math::elxAbs(G[16]-G[12])/2;
            
          Tmin = Math::elxMin(
            Math::elxMin(N,E,S,W), Math::elxMin(NE,SE,NW,SW));  
          Tmax = Math::elxMax(
            Math::elxMax(N,E,S,W), Math::elxMax(NE,SE,NW,SW));
          TR = (3 * Tmin + Tmax - Tmin) / 2;  
          
          g = va = vb = M(0);
          count = 0;
          if (N < TR)
          {
            g += G[8]; va += (Va[3] + Va[13])/2; vb += (Vb[7] + Vb[9])/2;
            ++count;
          }
          if (E < TR)
          {
            g += G[14]; va += (Va[13] + Va[15])/2; vb += (Vb[19] + Vb[9])/2;
            ++count;
          }
          if (S < TR)
          {
            g += G[18]; va += (Va[13] + Va[23])/2; vb += (Vb[19] + Vb[17])/2;
            ++count;
          }
          if (W < TR)
          {
            g += G[12]; va += (Va[13] + Va[11])/2; vb += (Vb[7] + Vb[17])/2;
            ++count;
          }
          if (NE < TR)
          {
            g += (G[4]+G[8]+G[10]+G[14])/4; va += (Va[13] + Va[5])/2; vb += Vb[9];
            ++count;
          }
          if (SE < TR)
          {
            g += (G[14]+G[18]+G[20]+G[24])/4; va += (Va[13] + Va[25])/2; vb += Vb[19];
            ++count;
          }
          if (NW < TR)
          {
            g += (G[2]+G[6]+G[8]+G[12])/4; va += (Va[13] + Va[1])/2; vb += Vb[7];
            ++count;
          }
          if (SW < TR)
          {
            g += (G[12]+G[16]+G[18]+G[22])/4; va += (Va[13] + Va[21])/2; vb += Vb[17];
            ++count;
          }
          
          prDst->_green = (count == 0) ?
            ResolutionTypeTraits<T>::ClampM((G[8]+G[12]+G[14]+G[18])/4):
            ResolutionTypeTraits<T>::ClampM(Va[13] + (g - va)/count);
            
          v = (count == 0) ? 
              (Vb[7]+Vb[9]+Vb[17]+Vb[19])/4 : Va[13] + (vb - va)/count;
              
          if (Bayer == BM_BGGR)
          {
            prDst->_red = ResolutionTypeTraits<T>::ClampM(v);
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(Va[13]);
          }
          else
          {
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(v);
            prDst->_red = ResolutionTypeTraits<T>::ClampM(Va[13]);
          }          
          break;

         case BM_GRBG: case BM_GBRG:
          //  G1   Va2  G3    Va4  G5
          //  Vb6  G7   Vb8   G9   Vb10
          //  G11  Va12 [G13] Va14 G15
          //  Vb16 G17  Vb18  G19  Vb20
          //  G21  Va22 G23   Va24 G25
          
          G[1]=prSrc[-w2-2]._luminance;  Va[2]=prSrc[-w2-1]._luminance; G[3]=prSrc[-w2]._luminance;  Va[4]=prSrc[-w2+1]._luminance; G[5]=prSrc[-w2+2]._luminance;
          Vb[6]=prSrc[-w1-2]._luminance; G[7]=prSrc[-w1-1]._luminance;  Vb[8]=prSrc[-w1]._luminance; G[9]=prSrc[-w1+1]._luminance;  Vb[10]=prSrc[-w1+2]._luminance;
          G[11]=prSrc[-2]._luminance;    Va[12]=prSrc[-1]._luminance;   G[13]=prSrc[0]._luminance;   Va[14]=prSrc[+1]._luminance;   G[15]=prSrc[+2]._luminance;
          Vb[16]=prSrc[w1-2]._luminance; G[17]=prSrc[w1-1]._luminance;  Vb[18]=prSrc[w1]._luminance; G[19]=prSrc[w1+1]._luminance;  Vb[20]=prSrc[w1+2]._luminance;
          G[21]=prSrc[w2-2]._luminance;  Va[22]=prSrc[w2-1]._luminance; G[23]=prSrc[w2]._luminance;  Va[24]=prSrc[w2+1]._luminance; G[25]=prSrc[w2+2]._luminance;
          
          N = Math::elxAbs(G[3]-G[13]) + Math::elxAbs(Vb[8]-Vb[18]) + 
            Math::elxAbs(G[7]-G[17])/2 + Math::elxAbs(G[9]-G[19])/2 +
            Math::elxAbs(Va[2]-Va[12])/2 + Math::elxAbs(Va[4]-Va[14])/2;
            
          E = Math::elxAbs(Va[14]-Va[12]) + Math::elxAbs(G[15]-G[13]) + 
            Math::elxAbs(G[9]-G[7])/2 + Math::elxAbs(G[19]-G[17])/2 +
            Math::elxAbs(Vb[10]-Vb[8])/2 + Math::elxAbs(Vb[20]-Vb[18])/2;
            
          S = Math::elxAbs(Vb[18]-Vb[8]) + Math::elxAbs(G[23]-G[13]) + 
            Math::elxAbs(G[19]-G[9])/2 + Math::elxAbs(G[17]-G[7])/2 +
            Math::elxAbs(Va[24]-Va[14])/2 + Math::elxAbs(Va[22]-Va[12])/2;
            
          W = Math::elxAbs(Va[12]-Va[14]) + Math::elxAbs(G[11]-G[13]) + 
            Math::elxAbs(G[17]-G[19])/2 + Math::elxAbs(G[7]-G[9])/2 +
            Math::elxAbs(Vb[16]-Vb[18])/2 + Math::elxAbs(Vb[6]-Vb[8])/2;
            
          NE = Math::elxAbs(G[9]-G[17]) + Math::elxAbs(G[5]-G[13]) + 
            Math::elxAbs(Va[4]-Va[12]) + Math::elxAbs(Vb[10]-Vb[18]);
            
          SE = Math::elxAbs(G[19]-G[7]) + Math::elxAbs(G[25]-G[13]) + 
            Math::elxAbs(Vb[20]-Vb[8]) + Math::elxAbs(Va[24]-Va[12]);
            
          NW = Math::elxAbs(G[7]-G[19]) + Math::elxAbs(G[1]-G[13]) + 
            Math::elxAbs(Vb[6]-Vb[18]) + Math::elxAbs(Va[2]-Va[14]);
            
          SW = Math::elxAbs(G[17]-G[9]) + Math::elxAbs(G[21]-G[13]) + 
            Math::elxAbs(Va[22]-Va[14]) + Math::elxAbs(Vb[16]-Vb[8]);
            
          Tmin = Math::elxMin(
            Math::elxMin(N,E,S,W), Math::elxMin(NE,SE,NW,SW));  
          Tmax = Math::elxMax(
            Math::elxMax(N,E,S,W), Math::elxMax(NE,SE,NW,SW));
          TR = (3 * Tmin + Tmax - Tmin) / 2;  
          
          g = va = vb = M(0);
          count = 0;
          if (N < TR)
          {
            g += (G[3]+G[13])/2; va += (Va[2]+Va[4]+Va[12]+Va[14])/4; vb += Vb[8];
            ++count;
          }
          if (E < TR)
          {
            g += (G[13]+G[15])/2; va += Va[14]; vb += (Vb[8]+Vb[10]+Vb[18]+Vb[20])/4;
            ++count;
          }
          if (S < TR)
          {
            g += (G[13]+G[23])/2; va += (Va[12]+Va[14]+Va[22]+Va[24])/4; vb += Vb[18];
            ++count;
          }
          if (W < TR)
          {
            g += (G[13]+G[11])/2; va += Va[12]; vb += (Vb[6]+Vb[8]+Vb[16]+Vb[18])/4;
            ++count;
          }
          if (NE < TR)
          {
            g += (G[13]+G[9]+G[5])/3; va += (Va[4] + Va[14])/2; vb += (Vb[8]+Vb[10])/2;
            ++count;
          }
          if (SE < TR)
          {
            g += (G[13]+G[19]+G[25])/3; va += (Va[14] + Va[24])/2; vb += (Vb[18]+Vb[20])/2;
            ++count;
          }
          if (NW < TR)
          {
            g += (G[1]+G[7]+G[13])/3; va += (Va[2] + Va[12])/2; vb += (Vb[6]+Vb[8])/2;
            ++count;
          }
          if (SW < TR)
          {
            g += (G[21]+G[17]+G[13])/3; va += (Va[12] + Va[22])/2; vb += (Vb[16]+Vb[18])/2;
            ++count;
          }
          // Green plane is direct value
          prDst->_green = prSrc[0]._luminance;
          if (Bayer == BM_GRBG)
          {
            prDst->_red = (count == 0) ?
              ResolutionTypeTraits<T>::ClampM((Va[12]+Va[14])/2) :
              ResolutionTypeTraits<T>::ClampM(G[13] + (va - g)/count);
            prDst->_blue = (count == 0) ?
              ResolutionTypeTraits<T>::ClampM((Vb[8]+Vb[18])/2) :
              ResolutionTypeTraits<T>::ClampM(G[13] + (vb - g)/count);
          }
          else
          {
            prDst->_blue = (count == 0) ?
              ResolutionTypeTraits<T>::ClampM((Va[12]+Va[14])/2) :
              ResolutionTypeTraits<T>::ClampM(G[13] + (va - g)/count);
            prDst->_red = (count == 0) ?
              ResolutionTypeTraits<T>::ClampM((Vb[8]+Vb[18])/2) :
              ResolutionTypeTraits<T>::ClampM(G[13] + (vb - g)/count);
          }          
          break;
          
        default:
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);
  }

  spImageL.reset();
  return spImageRGB;

} // elxCreateVNG

} // namespace Image
} // namespace eLynx

#endif // __Bayer_VNG_hpp__
