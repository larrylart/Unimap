//============================================================================
//  MalvarHeCutler.hpp                                 Image.Component package
//============================================================================
//
//  High-quality linear interpolation for demosaicing of Bayer-patterned color images
//
//  By Henrique S. Malvar, Li-wei He, and Ross Cutler
//  http://research.microsoft.com/~rcutler/pub/Demosaicing_ICASSP04.pdf
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_MalvarHeCutler_hpp__
#define __Bayer_MalvarHeCutler_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateMalvarHeCutler
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateMalvarHeCutler(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );

  M V1,V2,V3,V4,V5,V6,V7,V8,V9;
  M G1,G2,G3,G4,G5,G6,G7,G8,G9;
  M g,v,v1,v2;
  uint32 x,y;

  EBayerMatrix Bayer; //, Original = iBayer;
  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel(border,border);

  // --- inits progress ---
  const float ProgressStep = 1.0f / h;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          //         V1
          //     V2  G1  V3
          //  V4 G2 [V5] G3 V6
          //     V7  G4  V8
          //         V9
                                     V1 = prSrc[-w2];
                  V2 = prSrc[-w1-1]; G1 = prSrc[-w1]; V3 = prSrc[-w1+1];
  V4 = prSrc[-2]; G2 = prSrc[   -1]; V5 = prSrc[  0]; G3 = prSrc[   +1]; V6 = prSrc[+2]; 
                  V7 = prSrc[+w1-1]; G4 = prSrc[+w1]; V8 = prSrc[+w1+1];
                                     V9 = prSrc[+w2];

          g = (V5 + (G1+G2+G3+G4)/2 - (V1+V4+V6+V9)/4 )/2;
          v = (12*V5 + 4*(V2+V3+V7+V8) -3*(V1+V4+V6+V9))/16;

          prDst->_green = ResolutionTypeTraits<T>::ClampM(g);

          if (Bayer == BM_BGGR)
          {
            prDst->_red   = ResolutionTypeTraits<T>::ClampM(v);
            prDst->_blue  = prSrc[0];
          }
          else // BM_RGGB
          {
            prDst->_red   = prSrc[0];
            prDst->_blue  = ResolutionTypeTraits<T>::ClampM(v);
          }
          break;

        default: // BM_GBRG, BM_GRBG
          //         G1
          //     G2  V1  G3
          //  G4 V2 [G5] V3 G6
          //     G7  V4  G8
          //         G9
                                     G1 = prSrc[-w2];
                  G2 = prSrc[-w1-1]; V1 = prSrc[-w1]; G3 = prSrc[-w1+1];
  G4 = prSrc[-2]; V2 = prSrc[   -1]; G5 = prSrc[  0]; V3 = prSrc[   +1]; G6 = prSrc[+2]; 
                  G7 = prSrc[+w1-1]; V4 = prSrc[+w1]; G8 = prSrc[+w1+1];
                                     G9 = prSrc[+w2];

          v1 = (10*G5 + G1+G9 + 8*(V2+V3) - 2*(G2+G3+G7+G8 + G4+G6))/16;
          v2 = (10*G5 + G4+G6 + 8*(V1+V4) - 2*(G2+G3+G7+G8 + G1+G9))/16;

          prDst->_green = prSrc[0];

          if (Bayer == BM_GRBG)
          {
            prDst->_red   = ResolutionTypeTraits<T>::ClampM(v1);
            prDst->_blue  = ResolutionTypeTraits<T>::ClampM(v2);
          }
          else // BM_GBRG
          {
            prDst->_red   = ResolutionTypeTraits<T>::ClampM(v2);
            prDst->_blue  = ResolutionTypeTraits<T>::ClampM(v1);
          }
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }
  
  spImageL.reset();
  return ImageGeometryImpl< PixelRGB<T> >::CreateSubImage(*spImageRGB, border,border, w,h);

} // elxCreateMalvarHeCutler

} // namespace Image
} // namespace eLynx

#endif // __Bayer_MalvarHeCutler_hpp__
