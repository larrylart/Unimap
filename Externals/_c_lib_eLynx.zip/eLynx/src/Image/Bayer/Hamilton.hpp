//============================================================================
//  Hamilton.hpp                                       Image.Component package
//============================================================================
//
//  Adaptive color plane interpolation in single sensor color electronic camera
//
//  by Hamilton - U.S.Patent 5,629,734
//  http://scien.stanford.edu/class/psych221/projects/99/tingchen/algodep/corrI.html
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_Hamilton_hpp__
#define __Bayer_Hamilton_hpp__

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateHamilton
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  elxCreateHamilton(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    ProgressNotifier& iNotifier=ProgressNotifier_NULL)
{
  typedef typename ResolutionTypeTraits<T>::MulOverflow_type M;

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 border = 2;
  const int32 w1 = int32(border + w + border);
  const int32 h1 = int32(border + h + border);
  const int32 w2 = 2*w1;

  // --- inits progress ---
  const float ProgressStep = 1.0f / (2*h);
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);

  // Create a copy of input image expanded with border black pixels on each sides
  boost::shared_ptr< ImageImpl< PixelL<T> > > spImageL =
    ImageGeometryImpl< PixelL<T> >::CreateExpanded(iImage, border);

  // Create output ImageRGB<T> image
  boost::shared_ptr< ImageImpl< PixelRGB<T> > >
    spImageRGB( new ImageImpl< PixelRGB<T> >(w1,h1, PixelRGB<T>::Black()) );
    
  M V1,G2,V3,G4,V5,G6,V7,G8,V9,G1,G3,G5,G7,G9;
  M R1,R2,R4,R5,B1,B2,B4,B5;
  M r,g,b,v, dH,dV, muH,muV, dN,dP,muN,muP;
  uint32 x,y;

  EBayerMatrix Bayer, Original = iBayer;
  T * prSrc, * prSrcV = (T*)spImageL->GetPixel(border,border);
  PixelRGB<T> * prDst, * prDstV = spImageRGB->GetPixel(border,border);

  //-------------------------------------------------------
  // Step I - interpolation of green plane for whole image
  //-------------------------------------------------------
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_BGGR: case BM_RGGB:
          //         V1
          //         G2
          //  V3 G4 [V5] G6 V7
          //         G8
          //         V9
                                  V1 = prSrc[-w2];
                                  G2 = prSrc[-w1];
  V3 = prSrc[-2]; G4 = prSrc[-1]; V5 = prSrc[  0]; G6 = prSrc[+1]; V7 = prSrc[+2]; 
                                  G8 = prSrc[+w1];
                                  V9 = prSrc[+w2];

          muH = 2*V5 - V3 - V7;
          muV = 2*V5 - V1 - V9;
          dH = Math::elxAbs(G4 - G6) + Math::elxAbs(muH);
          dV = Math::elxAbs(G2 - G8) + Math::elxAbs(muV);

          if (dH == dV)     g = (G2 + G8 + G4 + G6)/4 + (muH + muV)/8;
          else if (dH < dV) g = (G4 + G6)/2 + muH/4;
          else              g = (G2 + G8)/2 + muV/4;

          prDst->_green = ResolutionTypeTraits<T>::ClampM(g);
          break;

        default:
          // copy green plane
          prDst->_green = prSrc[0];
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  //--------------------------------------------
  // Step II - interpolation of red/blue planes
  //--------------------------------------------
  prSrcV = (T*)spImageL->GetPixel(border,border);
  prDstV = spImageRGB->GetPixel(border,border);
  iBayer = Original;
  for (y=0; y<h; y++, prSrcV+=w1, prDstV+=w1)
  {
    prSrc = prSrcV;
    prDst = prDstV;
    Bayer = iBayer;
    for (x=0; x<w; x++, prSrc++, prDst++)
    {
      switch (Bayer)
      {
        case BM_GBRG:
          //      R1
          //  B2 [G3] B4
          //      R5
                         G1 = prDst[-w1]._green;
  G2 = prDst[-1]._green; G3 = prDst[  0]._green; G4 = prDst[+1]._green;
                         G5 = prDst[+w1]._green;

                         R1 = prSrc[-w1];
          B2 = prSrc[-1];                B4 = prSrc[+1];
                         R5 = prSrc[+w1];

          r = (R1 + R5)/2 + (2*G3 - G1 - G5)/4;
          b = (B2 + B4)/2 + (2*G3 - G2 - G4)/4;

          prDst->_red  = ResolutionTypeTraits<T>::ClampM(r);
          prDst->_blue = ResolutionTypeTraits<T>::ClampM(b);
          break;

        case BM_GRBG:
          //      B1
          //  R2 [G3] R4
          //      B5
                         G1 = prDst[-w1]._green;
  G2 = prDst[-1]._green; G3 = prDst[  0]._green; G4 = prDst[+1]._green;
                         G5 = prDst[+w1]._green;

                         B1 = prSrc[-w1];
          R2 = prSrc[-1];                R4 = prSrc[+1];
                         B5 = prSrc[+w1];

          r = (R2 + R4)/2 + (2*G3 - G2 - G4)/4;
          b = (B1 + B5)/2 + (2*G3 - G1 - G5)/4;

          prDst->_red  = ResolutionTypeTraits<T>::ClampM(r);
          prDst->_blue = ResolutionTypeTraits<T>::ClampM(b);
          break;

        default://BM_RGGB   BM_BGGR
          //  B1  G2  B3    R1  G2  R3    V1  G2  V3    
          //  G4 [R5] G6    G4 [B5] G6    G4 [v5] G6
          //  B7  G8  B9    R7  G8  R9    V7  G8  V9
          G1 = prDst[-w1-1]._green;                       G3 = prDst[-w1+1]._green; 
          G4 = prDst[   -1]._green; G5 = prDst[0]._green; G6 = prDst[   +1]._green;
          G7 = prDst[+w1-1]._green;                       G9 = prDst[+w1+1]._green; 

          V1 = prSrc[-w1-1]; V3 = prSrc[-w1+1];
          V7 = prSrc[+w1-1]; V9 = prSrc[+w1+1];

          muN = 2*G5 - G1 - G9;
          muP = 2*G5 - G3 - G7;
          dN = Math::elxAbs(V1 - V9) + Math::elxAbs(muN);
          dP = Math::elxAbs(V3 - V7) + Math::elxAbs(muP);

          if      (dN == dP) v = (V1 + V3 + V7 + V9 + muN + muP)/4;
          else if (dN < dP)  v = (V1 + V9 + muN)/2;
          else               v = (V3 + V7 + muP)/2;

          if (Bayer == BM_RGGB)
          {
            prDst->_red  = prSrc[0];
            prDst->_blue = ResolutionTypeTraits<T>::ClampM(v);
          }
          else
          {
            prDst->_red  = ResolutionTypeTraits<T>::ClampM(v);
            prDst->_blue = prSrc[0];
          }
          break;
      }
      Bayer = elxGetBayerRight(Bayer);
    }
    iBayer = elxGetBayerDown(iBayer);

    // --- in progress ... ---
    Progress += ProgressStep;
    iNotifier.SetProgress(Progress);
  }

  // no more need of original expanded image
  spImageL.reset();
  
  return ImageGeometryImpl< PixelRGB<T> >::CreateSubImage(*spImageRGB, border,border, w,h);

} // elxCreateHamilton

} // namespace Image
} // namespace eLynx

#endif // __Bayer_Hamilton_hpp__
