//============================================================================
//  Bayer/CreateBayer.hpp                              Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Bayer_CreateRGB_hpp__
#define __Bayer_CreateRGB_hpp__

#include <elx/core/CoreSort.h>

// Bayer to color algorithms
#include "Raw.hpp"
#include "Bin2x2.hpp"
#include "Nearest.hpp"
#include "Bilinear.hpp"
#include "MalvarHeCutler.hpp"
#include "Bicubic.hpp"
#include "Cok.hpp"
#include "Freeman.hpp"
#include "Adaptive.hpp"
#include "LarochePrescott.hpp"
#include "HamiltonAdams.hpp"
#include "Hamilton.hpp"
#include "Adams.hpp"
#include "WangLinXue.hpp"
#include "Kimmel.hpp"
#include "LukinKubasov.hpp"
#include "ChuanLin.hpp"
#include "WemmiaoLu.hpp"
#include "PRI.hpp"
#include "PMI.hpp"
#include "VNG.hpp"
#include "AHD.hpp"
#include "ChangTan.hpp"

#ifdef USE_LAST_BAYER_METHODS
#include "LCH.hpp"
#include "AWD.hpp"
#include "RACC.hpp"
#endif

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxCreateFloatingExpanded
//----------------------------------------------------------------------------
template <typename T, template <typename> class Pixel>
boost::shared_ptr< ImageImpl< Pixel< typename ResolutionTypeTraits<T>::Floating_type > > > 
elxCreateFloatingExpanded(
    const ImageImpl< Pixel<T> >& iImage, 
    uint32 iBorder)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl< Pixel<F> > >();

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 W = iBorder + w + iBorder;
  const uint32 H = iBorder + h + iBorder;

  // create the new image
  boost::shared_ptr< ImageImpl< Pixel<F> > > 
    spImage(new ImageImpl< Pixel<F> >(W,H));
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl< Pixel<F> > >();

  const Pixel<T> * prSrc = iImage.GetPixel();
  Pixel<F> * prDst = spImage->GetPixel();
  Pixel<F> bg = Pixel<F>::Black();

  uint32 i,j;
  // fill top with background
  for (j=0; j<iBorder; j++) 
    for (i=0; i<W; i++) 
      *prDst++ = bg;

  // fill central
  for (j=0; j<h; j++) 
  {
    // fill left with background
    for (i=0; i<iBorder; i++) 
      *prDst++ = bg;

    // fill medium with src image
    for (i=0; i<w; i++, prSrc++, prDst++) 
      *prDst = *prSrc;

    // fill right with background
    for (i=0; i<iBorder; i++) 
      *prDst++ = bg;
  }

  // fill bottom with background
  for (j=0; j<iBorder; j++) 
    for (i=0; i<W; i++) 
      *prDst++ = bg;

  return spImage;

} // elxCreateFloatingExpanded


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateRGB
//----------------------------------------------------------------------------
template<typename T>
boost::shared_ptr< ImageImpl< PixelRGB<T> > > 
  BayerHandlerImpl<T>::CreateRGB(
    const ImageImpl< PixelL<T> >& iImage, 
    EBayerMatrix iBayer,
    EBayerToColorConversion iMethod,
    ProgressNotifier& iNotifier)
{
  switch (iMethod)
  {
    case BCC_Raw:               return elxCreateRaw(iImage, iBayer, iNotifier);
    case BCC_Bin2x2:            return elxCreateBin2x2(iImage, iBayer, iNotifier);
    case BCC_Nearest:           return elxCreateNearest(iImage, iBayer, iNotifier);
    case BCC_Bilinear:          return elxCreateBilinear(iImage, iBayer, iNotifier);
    case BCC_MalvarHeCutler:    return elxCreateMalvarHeCutler(iImage, iBayer, iNotifier);
    case BCC_Bicubic:           return elxCreateBicubic(iImage, iBayer, iNotifier);
    case BCC_Cok:               return elxCreateCok(iImage, iBayer, iNotifier);
    case BCC_Freeman:           return elxCreateFreeman(iImage, iBayer, iNotifier);
    case BCC_Adaptive:          return elxCreateAdaptive(iImage, iBayer, iNotifier);
    case BCC_LarochePrescott:   return elxCreateLarochePrescott(iImage, iBayer, iNotifier);
    case BCC_HamiltonAdams:     return elxCreateHamiltonAdams(iImage, iBayer, iNotifier);
    case BCC_Hamilton:          return elxCreateHamilton(iImage, iBayer, iNotifier);
    case BCC_Adams:             return elxCreateAdams(iImage, iBayer, iNotifier);
    case BCC_WangLinXue:        return elxCreateWangLinXue(iImage, iBayer, iNotifier);
    case BCC_Kimmel:            return elxCreateKimmel(iImage, iBayer, 0, iNotifier);
#if 1
    case BCC_LukinKubasov:      return elxCreateLukinKubasov(iImage, iBayer, 0, iNotifier);
    case BCC_ChuanLin:          return elxCreateChuanLin(iImage, iBayer, iNotifier);
    case BCC_WemmiaoLu:         return elxCreateWemmiaoLu(iImage, iBayer, iNotifier);
#else // to test Kimmel's iterative corrections interactivly
    case BCC_LukinKubasov:      return elxCreateKimmel(iImage, iBayer, 1, iNotifier);
    case BCC_ChuanLin:          return elxCreateKimmel(iImage, iBayer, 2, iNotifier);
    case BCC_WemmiaoLu:         return elxCreateKimmel(iImage, iBayer, 3, iNotifier);
#endif
    case BCC_PRI:               return elxCreatePRI(iImage, iBayer, iNotifier);
    case BCC_PMI:               return elxCreatePMI(iImage, iBayer, iNotifier);
    case BCC_VNG:               return elxCreateVNG(iImage, iBayer, iNotifier);
    case BCC_AHD:               return elxCreateAHD(iImage, iBayer, iNotifier);
    case BCC_ChangTan:          return elxCreateChangTan(iImage, iBayer, iNotifier);
#ifdef USE_LAST_BAYER_METHODS
    case BCC_AWD:               return elxCreateAWD(iImage, iBayer, iNotifier);
    case BCC_LCH:               return elxCreateLCH(iImage, iBayer, iNotifier);
    case BCC_RACC:              return elxCreateRACC(iImage, iBayer/*, iNotifier*/);
#endif
    default:                    return elxCreateImageRGBGrey(iImage);
  }
  return boost::shared_ptr< ImageImpl< PixelRGB<T> > >();

} // CreateRGB


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IBayerHandler implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateRGB
//----------------------------------------------------------------------------
template <typename T>
boost::shared_ptr< AbstractImage > BayerHandlerImpl<T>::CreateRGB(
    const AbstractImage& iImage, 
    EBayerMatrix iBayer,
    EBayerToColorConversion iMethod,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl< PixelL<T> >& image = elxDowncast< PixelL<T> >(iImage);
  return CreateRGB(image, iBayer, iMethod, iNotifier);

} // CreateRGB

} // namespace Image
} // namespace eLynx

#endif // __Bayer_CreateRGB_hpp__
