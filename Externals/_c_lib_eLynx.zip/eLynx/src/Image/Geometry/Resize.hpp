//============================================================================
//  Geometry/Resize.hpp                                Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Resize_hpp__
#define __Geometry_Resize_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateResized
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateResized(
    const ImageImpl<Pixel>& iImage,
    uint32 iWidth, uint32 iHeight,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // create the new image
  boost::shared_ptr< ImageImpl<Pixel> > spImage( new ImageImpl<Pixel>(iWidth, iHeight) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();

  const Pixel_t * prSrc = iImage.GetPixel();
  Pixel_t * prDst = spImage->GetPixel();

  uint32 deltaX = (w  << 16) / iWidth;
  uint32 deltaY = (h << 16) / iHeight;

  const Pixel_t * prSrcLine = NULL;
  const Pixel_t * prSrcPixel = NULL;
  uint32 x,y,i,j;

  y = 0;
  for (j=0; j<iHeight; j++)
  {
    prSrcLine = &prSrc[(y>>16)*w];

    x = 0;
    for (i=0; i<iWidth; i++)
    {
      prSrcPixel = &prSrcLine[(x>>16)];
      *prDst++ = *prSrcPixel++;
      x += deltaX;
    }
    y += deltaY;
  }
  return spImage;

} // CreateResized


//----------------------------------------------------------------------------
//  Resize
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Resize(
    ImageImpl<Pixel>& ioImage,
    uint32 iWidth, uint32 iHeight,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid())
    return false;

  boost::shared_ptr< ImageImpl<Pixel> > spImage = 
    CreateResized(ioImage, iWidth, iHeight, iNotifier);
  return ioImage.CopyAndForget(spImage);

} // Resize


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateResized
//----------------------------------------------------------------------------
template <typename Pixel> 
boost::shared_ptr<AbstractImage> ImageGeometryImpl<Pixel>::CreateResized(
    const AbstractImage& iImage,
    uint32 iWidth, uint32 iHeight,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return CreateResized(image, iWidth, iHeight, iNotifier);

} // CreateResized


//----------------------------------------------------------------------------
//  Resize
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Resize(
    AbstractImage& ioImage,
    uint32 iWidth, uint32 iHeight,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Resize(image, iWidth, iHeight, iNotifier);

} // Resize

} // namespace Image
} // namespace eLynx

#endif // __Geometry_Resize_hpp__
