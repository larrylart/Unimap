//============================================================================
//  Geometry/Resample.hpp                              Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Resample_hpp__
#define __Geometry_Resample_hpp__

#include <elx/math/ResampleHelper.h>
#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

namespace {

template <typename Pixel>
struct ResampleHorizontallyTask : public IterationRangeTask
{
  typedef typename Pixel::type T;
  typedef typename Pixel::FloatingPixel Pixel_F;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  
  ResampleHorizontallyTask(
      const Pixel * iprSrc, 
      Pixel_F * iprDst, 
      uint32 iInW, uint32 iOutW, 
      Math::EResampleFilter iFilter,
      ProgressNotifier& iNotifier) : 
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc), 
    _prDst(iprDst), 
    _inWidth(iInW), 
    _outWidth(iOutW), 
    _filter(iFilter)
  {} 

  ResampleHorizontallyTask(
      const ResampleHorizontallyTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc), 
    _prDst(iOther._prDst), 
    _inWidth(iOther._inWidth), 
    _outWidth(iOther._outWidth), 
    _filter(iOther._filter)
  {} 
   
  uint32 operator()()
  {
    uint32 begin = (uint32)_begin;
    uint32 end = (uint32)_end;
    const uint32 wOut= _outWidth;
    const uint32 wIn = _inWidth;
    const Pixel * prSrc =_prSrc + begin*wIn;
    Pixel_F * prDst = _prDst + begin*wOut;
    
    Math::ResampleHelper helper(wIn, wOut, _filter);
    
    // --- inits progress ---
    const float ProgressStep = 1.f / (float)(end-begin);
    float Progress = 0.0f;
    _notifier.SetProgress(0.0f);
    
    uint32 x,y,c, offset;
    F weight;
    Pixel_F pixelF;
    for (y=begin; y<end; y++) 
    {
      for (x=0; x<wOut; x++)
      {
        pixelF = Pixel_F::Null();
        const uint32 nContributor = helper.GetContributorCount(x);
        for (c=0; c<nContributor; c++)
        {
          weight = F( helper.GetWeight(x,c) );
          if (0 == weight) continue;

          offset = helper.GetOldIndex(x,c);
          pixelF += weight * Pixel_F( prSrc[offset] );
        }
        *prDst++ = pixelF;
      }
      prSrc += wIn;

      // --- in progress ... ---
      Progress += ProgressStep;
      _notifier.SetProgress(Progress);
    }
    
    // --- progress end ---
    _notifier.SetProgress(1.0f);
    return elxOK;
  }

private:  
  const Pixel *         _prSrc;    // Source Image
  Pixel_F *             _prDst;    // Destination Image
  const uint32          _inWidth;  // Source Image Width
  uint32                _outWidth; // Destination Image Width
  Math::EResampleFilter _filter;   // Filter
};

template <typename Pixel>
struct ResampleVerticallyTask : public IterationRangeTask
{
  typedef typename Pixel::type T;
  typedef typename Pixel::FloatingPixel Pixel_F;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  
  ResampleVerticallyTask(
      const Pixel_F * iprSrc, 
      Pixel * iprDst, 
      uint32 iInH, 
      uint32 iOutW, 
      uint32 iOutH, 
      Math::EResampleFilter iFilter,
      ProgressNotifier& iNotifier) : 
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc), 
    _prDst(iprDst), 
    _inHeight(iInH), 
    _outWidth(iOutW), 
    _outHeight(iOutH),
    _filter(iFilter)
  {} 

  ResampleVerticallyTask(
      const ResampleVerticallyTask& iOther, 
      const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc), 
    _prDst(iOther._prDst), 
    _inHeight(iOther._inHeight), 
    _outWidth(iOther._outWidth), 
    _outHeight(iOther._outHeight),
    _filter(iOther._filter)
  {} 
   
  uint32 operator()()
  {
    uint32 begin = (uint32)_begin;
    uint32 end = (uint32)_end;
    const uint32 wOut = _outWidth;
    const uint32 hOut = _outHeight;
    const uint32 hIn = _inHeight;
    const Pixel_F * prSrc = _prSrc;
    Pixel * prDst = _prDst + begin*wOut;
    Math::ResampleHelper helper(hIn, hOut, _filter);
    
    // --- inits progress ---
    const float ProgressStep = 1.f / (float)(end-begin);
    float Progress = 0.0f;
    _notifier.SetProgress(0.0f);
    
    uint32 x,y,c, offset;
    F weight;
    Pixel_F pixelF;
    const bool bClamp = !ResolutionTypeTraits<T>::_bLUT;
    if (bClamp)
    {
      // clamp pixel before saving
      for (y=begin; y<end; y++) 
      {
        const uint32 nContributor = helper.GetContributorCount(y);
        for (x=0; x<wOut; x++)      
        {
          pixelF = Pixel_F::Null();
          for (c=0; c<nContributor; c++)
          {
            weight = F( helper.GetWeight(y,c) );
            if (0 == weight) continue;

            offset = x + helper.GetOldIndex(y,c) * wOut;
            pixelF += weight * prSrc[offset];
          }
          elxPixelClamp(pixelF, *prDst);
          prDst++;
        }
        // --- in progress ... ---
        Progress += ProgressStep;
        _notifier.SetProgress(Progress);
      }
    }
    else
    {
      // no need to clamp pixel
      for (y=begin; y<end; y++) 
      {
        const uint32 nContributor = helper.GetContributorCount(y);
        for (x=0; x<wOut; x++)      
        {
          pixelF = Pixel_F::Null();
          for (c=0; c<nContributor; c++)
          {
            weight = F( helper.GetWeight(y,c) );
            if (0 == weight) continue;

            offset = x + helper.GetOldIndex(y,c) * wOut;
            pixelF += weight * prSrc[offset];
          }
          *prDst++ = pixelF;
        }
        // --- in progress ... ---
        Progress += ProgressStep;
        _notifier.SetProgress(Progress);
      }
    }
    
    // --- progress end ---
    _notifier.SetProgress(1.0f);
    return elxOK;
  }

private:
  const Pixel_F *       _prSrc;     // Source Image
  Pixel *               _prDst;     // Destination Image
  const uint32          _inHeight;  // Source Image Height
  uint32                _outWidth;  // Destination Image Width
  uint32                _outHeight; // Destination Image Height
  Math::EResampleFilter _filter;    // Filter
};

} // namespace 

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateResampled
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : const ImageImpl<Pixel>&
//        uint32 iWidth:
//        uint32 iHeight:
//        Math::EResampleFilter iFilter
//  Out : ImageImpl<Pixel> *
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr< ImageImpl<Pixel> > 
  ImageGeometryImpl<Pixel>::CreateResampled(
    const ImageImpl<Pixel>& iImage,
    uint32 iWidth, uint32 iHeight,
    Math::EResampleFilter iFilter,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();


  // create output image, ISO resolution, new dimensions
  boost::shared_ptr< ImageImpl<Pixel> > 
    spImage( new ImageImpl<Pixel>(iWidth, iHeight) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const uint32 wIn = iImage.GetWidth();
  const uint32 hIn = iImage.GetHeight();

  typedef typename Pixel_t::type T;
  typedef typename Pixel_t::FloatingPixel Pixel_F;
  typedef typename ResolutionTypeTraits<T>::Floating_type F;

  // create a temporary image in floating point resolution
  boost::shared_ptr< ImageImpl<Pixel_F> > 
    spImageF( new ImageImpl<Pixel_F>(iWidth, hIn) );
  if (!elxUseable(spImageF.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // -1- filter horizontally from input (T resolution) to temporary image (F resolution)
  IterationRange hRange(0, hIn);
  ResampleHorizontallyTask<Pixel> hTask(iImage.GetPixel(), spImageF->GetPixel(),
    wIn, iWidth, iFilter, iNotifier);
  if (elxOK != elxParallelFor(hRange, hTask))
    return boost::shared_ptr< ImageImpl<Pixel> >();
    
  // -2- filter vertically from temporary image (F resolution) to output image (T resolution)
  IterationRange vRange(0, iHeight);
  ResampleVerticallyTask<Pixel> vTask(spImageF->GetPixel(), spImage->GetPixel(),
    hIn, iWidth, iHeight, iFilter, iNotifier);
  if (elxOK != elxParallelFor(vRange, vTask))
    return boost::shared_ptr< ImageImpl<Pixel> >();
    
  return spImage;

} // CreateResampled


//----------------------------------------------------------------------------
//  Resample
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Resample(
    ImageImpl<Pixel>& ioImage,
    uint32 iWidth, uint32 iHeight,
    Math::EResampleFilter iFilter,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid())
    return false;

  boost::shared_ptr< ImageImpl<Pixel> > spImage = 
    CreateResampled(ioImage, iWidth, iHeight, iFilter);
  return ioImage.CopyAndForget(spImage);

} // Resample


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateResampled
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr<AbstractImage> 
  ImageGeometryImpl<Pixel>::CreateResampled(
    const AbstractImage& iImage,
    uint32 iWidth, uint32 iHeight,
    Math::EResampleFilter iFilter,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return CreateResampled(image, iWidth, iHeight, iFilter);

} // CreateResampled


//----------------------------------------------------------------------------
//  Resample
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Resample(
    AbstractImage& ioImage,
    uint32 iWidth, uint32 iHeight,
    Math::EResampleFilter iFilter,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Resample(image, iWidth, iHeight, iFilter);

} // Resample

} // namespace Image
} // namespace eLynx

#endif // __Geometry_Resample_hpp__
