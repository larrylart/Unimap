//============================================================================
//  Geometry/Crop.hpp                                  Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Crop_hpp__
#define __Geometry_Crop_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateSubImage : Create a sub image.
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr< ImageImpl<Pixel> > 
  ImageGeometryImpl<Pixel>::CreateSubImage(
    const ImageImpl<Pixel>& iImage,
    uint32 iX, uint32 iY,
    uint32 iWidth, uint32 iHeight,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  if ((0 == iWidth) || (0 == iHeight))
    return boost::shared_ptr< ImageImpl<Pixel> >();

  if ((iX >= w) || (iY >= h) ||
      (iX+iWidth > w) || (iY+iHeight > h))
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // create the new image
  boost::shared_ptr< ImageImpl<Pixel> > spImage( 
    new ImageImpl<Pixel>(iWidth, iHeight) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const Pixel_t * prSrc = iImage.GetPixel(iX,iY);
  Pixel_t * prDst = spImage->GetPixel();
  const uint32 dstByteWidth = spImage->sizeofWidth();

  // for each lines 
  do
  {
    // copy sub line as a whole bytes block
    ::memcpy(prDst, prSrc, dstByteWidth);

    // next line
    prSrc += w;
    prDst += iWidth;
  }
  while (--iHeight > 0);

  return spImage;

} // CreateSubImage


//----------------------------------------------------------------------------
//  Crop : Crop image into new rectangle
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Crop(
    ImageImpl<Pixel>& ioImage,
    uint32 iX, uint32 iY,
    uint32 iWidth, uint32 iHeight,
    ProgressNotifier& iNotifier)
{
  // image must be valid
  if (!ioImage.IsValid())
    return false;

  boost::shared_ptr< ImageImpl<Pixel> > spImage = 
    CreateSubImage(ioImage, iX, iY, iWidth, iHeight, iNotifier);
  return ioImage.CopyAndForget(spImage);

} // Crop


//----------------------------------------------------------------------------
//  CheckHLine
//----------------------------------------------------------------------------
template <typename Pixel> inline
bool CheckHLine(Pixel& iPixel, const Pixel * iprLine, uint32 iWidth)
{
  for (uint32 i=0; i<iWidth; i++)
    if (iprLine[i] != iPixel)
      return false;
  return true;

} // CheckHLine

//----------------------------------------------------------------------------
//  CheckVLine
//----------------------------------------------------------------------------
template <typename Pixel> inline
bool CheckVLine(Pixel& iPixel, const Pixel * iprLine, uint32 iWidth, uint32 iHeight)
{
  uint32 idx = 0;
  for (uint32 i=0; i<iHeight; i++, idx+=iWidth)
    if (iprLine[idx] != iPixel)
      return false;
  return true;

} // CheckVLine

//----------------------------------------------------------------------------
//  AutoCrop: Automatic Crop image
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::AutoCrop(
    ImageImpl<Pixel>& ioImage,
    ProgressNotifier& iNotifier)
{
  // image must be valid
  if (!ioImage.IsValid()) return false;

  const uint32 w = ioImage.GetWidth();
  const uint32 h = ioImage.GetHeight();
  bool bFound = false;

  uint32 x=0,y;
  const Pixel * prSrc;
  Pixel p;

  // check top lines
  uint32 yStart = 0;
  prSrc = ioImage.GetPixel(0,yStart);
  p = *prSrc;

  for (y=0; y<h; y++, prSrc+=w)
    if (CheckHLine(p, prSrc, w))
      yStart++;
    else
      break;

  // if image is mono color, don't crop it
  if (yStart == h)
    return false;

  if (yStart > 0) bFound = true;

  // check bottom lines
  uint32 yEnd = h-1;
  prSrc = ioImage.GetPixel(0,yEnd);
  if (!bFound) p = *prSrc;

  for (y=0; y<h; y++, prSrc-=w)
    if (CheckHLine(p, prSrc, w))
      yEnd--;
    else
      break;
  
  if (yEnd < h-1) bFound = true;


  // check left lines
  uint32 xStart = 0;
  prSrc = ioImage.GetPixel(xStart,0);
  if (!bFound) p = *prSrc;

  for (x=0; x<w; x++, prSrc+=1)
    if (CheckVLine(p, prSrc, w,h))
      xStart++;
    else
      break;

  if (xStart > 0) bFound = true;

  // check right lines
  uint32 xEnd = w-1;
  prSrc = ioImage.GetPixel(xEnd,0);
  if (!bFound) p = *prSrc;

  for (x=0; x<w; x++, prSrc-=1)
    if (CheckVLine(p, prSrc, w,h))
      xEnd--;
    else
      break;

  if (xEnd < w-1) bFound = true;

  const uint32 w2 = xEnd - xStart + 1;
  const uint32 h2 = yEnd - yStart + 1;
  
  // do not modify image if image keep the same size
  if ((0 == xStart) && (0 == yStart) && (w == w2) && (h == h2))
    return false;

  return Crop(ioImage, xStart,yStart, w2, h2, iNotifier);

} // AutoCrop

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateSubImage : Create a sub image.
//----------------------------------------------------------------------------
//  public virtual from IImageGeometry
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage
//        bool ibClockwise : true for 90 right, false for 90 left
//  Out : bool : success status
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr<AbstractImage> 
  ImageGeometryImpl<Pixel>::CreateSubImage(
    const AbstractImage& iImage,
    uint32 iX, uint32 iY, uint32 iWidth, uint32 iHeight,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return CreateSubImage(image, iX, iY, iWidth, iHeight, iNotifier);

} // CreateSubImage


//----------------------------------------------------------------------------
//  Crop : Crop image into new rectangle
//----------------------------------------------------------------------------
//  public virtual from IImageGeometry
//----------------------------------------------------------------------------
//  In  : uint32 iX:
//        uint32 iY:
//        uint32 iWidth:
//        uint32 iHeight:
//  Out : bool : success status
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageGeometryImpl<Pixel>::Crop(
    AbstractImage& ioImage,
    uint32 iX, uint32 iY, uint32 iWidth, uint32 iHeight,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Crop(image, iX, iY, iWidth, iHeight, iNotifier);

} // Crop

//----------------------------------------------------------------------------
//  AutoCrop: Automatic Crop
//----------------------------------------------------------------------------
//  public virtual from IImageGeometry
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageGeometryImpl<Pixel>::AutoCrop(
    AbstractImage& ioImage,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return AutoCrop(image, iNotifier);

} // AutoCrop

} // namespace Image
} // namespace eLynx

#endif // __Geometry_Crop_hpp__
