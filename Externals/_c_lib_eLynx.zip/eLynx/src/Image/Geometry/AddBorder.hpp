//============================================================================
//  Geometry/AddBorder.hpp                             Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_AddBorder_hpp__
#define __Geometry_AddBorder_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateEnlarged
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
inline
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateEnlarged(
    const ImageImpl<Pixel>& iImage, 
    uint32 iLeft, uint32 iRight, uint32 iTop, uint32 iBottom, 
    bool ibBlack,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 W = iLeft + w + iRight;
  const uint32 H = iTop + h + iBottom;

  // create the new image
  boost::shared_ptr< ImageImpl<Pixel> > spImage(new ImageImpl<Pixel>(W,H));
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  Pixel bg = ibBlack ? Pixel_t::Black() : Pixel_t::White();
  const Pixel * prSrc = iImage.GetPixel();
  Pixel * prDst = spImage->GetPixel();
  const uint32 byteLineSize = iImage.sizeofWidth();

  uint32 i,j;
  // fill top with background
  for (j=0; j<iTop; j++) 
    for (i=0; i<W; i++) 
      *prDst++ = bg;

  // fill central
  for (j=0; j<h; j++) 
  {
    // fill left with background
    for (i=0; i<iLeft; i++) 
      *prDst++ = bg;

    // fill medium with src image
    ::memcpy(prDst, prSrc, byteLineSize);
    prSrc += w;
    prDst += w;

    // fill right with background
    for (i=0; i<iRight; i++) 
      *prDst++ = bg;
  }

  // fill bottom with background
  for (j=0; j<iBottom; j++) 
    for (i=0; i<W; i++) 
      *prDst++ = bg;

  return spImage;

} // CreateEnlarged


//----------------------------------------------------------------------------
//  AddBorder
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
inline
bool ImageGeometryImpl<Pixel>::AddBorder(
    ImageImpl<Pixel>& ioImage, 
    uint32 iLeft, uint32 iRight, uint32 iTop, uint32 iBottom, 
    bool ibBlack,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid())
    return false;

  boost::shared_ptr< ImageImpl<Pixel> >
    spImage = CreateEnlarged(ioImage, iLeft, iRight, iTop, iBottom, ibBlack, iNotifier);
  return ioImage.CopyAndForget(spImage);

} // AddBorder


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateEnlarged
//----------------------------------------------------------------------------
template <typename Pixel>
inline
boost::shared_ptr<AbstractImage> ImageGeometryImpl<Pixel>::CreateEnlarged(
    const AbstractImage& iImage,
    uint32 iLeft, uint32 iRight, uint32 iTop, uint32 iBottom, 
    bool ibBlack,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return CreateEnlarged(image, iLeft, iRight, iTop, iBottom, ibBlack, iNotifier);

} // CreateEnlarged


//----------------------------------------------------------------------------
//  AddBorder
//----------------------------------------------------------------------------
template <typename Pixel>
inline
bool ImageGeometryImpl<Pixel>::AddBorder(
    AbstractImage& ioImage,
    uint32 iLeft, uint32 iRight, uint32 iTop, uint32 iBottom, 
    bool ibBlack,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return AddBorder(image, iLeft, iRight, iTop, iBottom, ibBlack, iNotifier);

} // AddBorder

} // namespace Image
} // namespace eLynx

#endif // __Geometry_AddBorder_hpp__
