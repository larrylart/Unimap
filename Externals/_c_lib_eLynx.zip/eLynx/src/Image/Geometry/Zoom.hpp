//============================================================================
//  Geometry/Zoom.hpp                                  Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Zoom_hpp__
#define __Geometry_Zoom_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateZoomed : Create a zoomed image.
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : const ImageImpl<Pixel>& iImage
//        uint32 iZoom : zoom magnifier coefficient
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateZoomed(
    const ImageImpl<Pixel>& iImage,
    uint32 iZoom,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid() || (0 == iZoom))
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();

  const uint32 zw = iZoom * w;
  const uint32 zh = iZoom * h;

  // create the new image
  boost::shared_ptr< ImageImpl<Pixel> > spImage( new ImageImpl<Pixel>(zw,zh) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  if (1 == iZoom)
  {
    // just copy whole map
    const uint32 size = iImage.sizeofMap();
    ::memcpy(spImage->GetSamples(), iImage.GetSamples(), size);
    return spImage;
  }

  const uint32 size = spImage->sizeofWidth();
  const Pixel_t * prSrc = iImage.GetPixel();
  Pixel_t * prDst = spImage->GetPixel();
  Pixel_t * prDstStart;

  const Pixel_t * prSrcLine = NULL;
  uint32 x,y, cy,cx;

  for (y=0; y<h; y++)
  {
    prSrcLine = &prSrc[y*w];
    prDstStart = prDst;
    for (x=0; x<w; x++)
    {
      for (cx=0; cx<iZoom; cx++)
        *prDst++ = prSrcLine[x];
    }
    for (cy=iZoom-1; cy>0; cy--)
    {
      ::memcpy(prDst, prDstStart, size);
      prDst += zw;
    }
  }

  return spImage;

} // CreateZoomed

//----------------------------------------------------------------------------
//  Zoom
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Zoom(
    ImageImpl<Pixel>& ioImage, 
    uint32 iZoom,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid())
    return false;

  boost::shared_ptr< ImageImpl<Pixel> > spImage = CreateZoomed(ioImage, iZoom, iNotifier);
  return ioImage.CopyAndForget(spImage);

} // Zoom


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateZoomed
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr<AbstractImage > ImageGeometryImpl<Pixel>::CreateZoomed(
    const AbstractImage& iImage,
    uint32 iZoom,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return CreateZoomed(image, iZoom, iNotifier);

} // CreateZoomed


//----------------------------------------------------------------------------
//  Zoom
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Zoom(
    AbstractImage& ioImage,
    uint32 iZoom,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Zoom(image, iZoom, iNotifier);

} // Zoom

} // namespace Image
} // namespace eLynx

#endif // __Geometry_Zoom_hpp__
