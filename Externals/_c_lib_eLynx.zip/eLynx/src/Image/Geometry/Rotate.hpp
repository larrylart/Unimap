//============================================================================
//  Geometry/Rotate.hpp                                Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Rotate_hpp__
#define __Geometry_Rotate_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

namespace {

template <typename Pixel>
struct Rotate90Task : public IterationRangeTask
{
  Rotate90Task(const Pixel* iprSrc, uint32 iW, uint32 iH, bool ibClockwise, 
      Pixel* iprDst, ProgressNotifier& iNotifier) : 
    IterationRangeTask(iNotifier),
    _prSrc(iprSrc), _prDst(iprDst), _width(iW), _height(iH), 
    _bClockwise(ibClockwise)
  {} 
   
  Rotate90Task(const Rotate90Task& iOther, const IterationRange& iRange) :
      IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc), _prDst(iOther._prDst), _width(iOther._width), 
    _height(iOther._height), _bClockwise(iOther._bClockwise) 
  {}  
    
  uint32 operator()()
  {
    const uint32 begin = (uint32)_begin;
    const uint32 end = (uint32)_end;
    const uint32 w = _width;
    const uint32 h = _height;
    const Pixel* prSrc = _prSrc + begin*w;
    Pixel * prDst = _prDst;
    Pixel * prDstMap = prDst;
    
    // --- inits progress ---
    const float ProgressStep = 1.f / (float)(end-begin);
    float Progress = 0.0f;
    _notifier.SetProgress(0.0f);
    
    if (_bClockwise)
    {
      // 90 right
      for (uint32 y=begin; y<end; y++)
      {
        for (uint32 x=0; x<w; x++)
        {
          prDst = prDstMap + (x+1)*h - y - 1;
          *prDst = *prSrc++;
        }
        // --- in progress ... ---
        Progress += ProgressStep;
        _notifier.SetProgress(Progress);
      }
    }
    else
    {
      // 90 left
      for (uint32 y=begin; y<end; y++)
      {
        for (uint32 x=0; x<w; x++)
        {
          prDst = prDstMap + h*(w-x-1) + y;
          *prDst = *prSrc++;
        }
        // --- in progress ... ---
        Progress += ProgressStep;
        _notifier.SetProgress(Progress);
      }
    }

    // --- progress end ---
    _notifier.SetProgress(1.0f);
    return elxOK;
  }

private:
  const Pixel * _prSrc;
  Pixel *       _prDst;
  uint32        _width, _height;
  bool          _bClockwise;
};

} // namespace


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateRotated90 : Create a basic 90 rotated image.
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateRotated90(
    const ImageImpl<Pixel>& iImage,
    bool ibClockwise,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const uint32 h = iImage.GetHeight();
  const uint32 w = iImage.GetWidth();

  boost::shared_ptr< ImageImpl<Pixel> > spImage( new ImageImpl<Pixel>(h, w) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const Pixel_t * prSrc = iImage.GetPixel();
  Pixel_t * prDst = spImage->GetPixel();

  size_t minRangeSize = (w > 10000) ? 1 : 10000/w;
  IterationRange range(0, size_t(h), 1, minRangeSize);
  Rotate90Task<Pixel> task(prSrc, w,h, ibClockwise, prDst, iNotifier);
  
  if (elxOK != elxParallelFor(range, task))
    return boost::shared_ptr< ImageImpl<Pixel> >();

  return spImage;

} // CreateRotated90

//----------------------------------------------------------------------------
//  Rotate90 : Fast rotate image with basic 90 angles.
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage
//        bool ibClockwise : true for 90 right, false for 90 left
//  Out : bool : success status
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Rotate90(
    ImageImpl<Pixel>& ioImage, 
    bool ibClockwise,
    ProgressNotifier& iNotifier) 
{
  // image must be valid
  if (!ioImage.IsValid())
    return false;

  boost::shared_ptr< ImageImpl<Pixel> > spImage = CreateRotated90(ioImage, ibClockwise, iNotifier);
  return ioImage.CopyAndForget(spImage);

} // Rotate90

//----------------------------------------------------------------------------
//  Rotate180 :
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : ImageImpl<Pixel>& ioImage
//  Out : bool : success status
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageGeometryImpl<Pixel>::Rotate180(ImageImpl<Pixel>& ioImage,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid())
    return false;

  // no need to check, must succeeded
  FlipVertical(ioImage);
  FlipHorizontal(ioImage, iNotifier);
  return true;

} // Rotate180


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Rotate : Fast rotate image with basic 90 angles.
//----------------------------------------------------------------------------
//  public virtual from IImageGeometry
//----------------------------------------------------------------------------
//  In  : AbstractImage& ioImage
//        ERightRotation iRotation
//  Out : bool : success status
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Rotate(
    AbstractImage& ioImage,
    ERightRotation iRotation,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  switch(iRotation)
  {
    case RR_90Left:   return Rotate90(image, false, iNotifier);
    case RR_90Right:  return Rotate90(image, true, iNotifier);
    case RR_180:      return Rotate180(image, iNotifier);
    case RR_0:
    default:
      return true;
  }

} // Rotate


//----------------------------------------------------------------------------
//  CreateRotated : Create a fast rotates image with basic 90 angles.
//----------------------------------------------------------------------------
//  public virtual from IImageGeometry
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr<AbstractImage> ImageGeometryImpl<Pixel>::CreateRotated(
    const AbstractImage& iImage,
    ERightRotation iRotation,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  boost::shared_ptr<AbstractImage> spImage = elxCreateImage(image);
  Rotate(*spImage, iRotation, iNotifier);
  return spImage;

} // CreateRotated

} // namespace Image
} // namespace eLynx

#endif // __Geometry_Rotate_hpp__
