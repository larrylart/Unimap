//============================================================================
//  Geometry/Flip.hpp                                  Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Flip_hpp__
#define __Geometry_Flip_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  FlipVertical : perform vertical symmetry of image
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageGeometryImpl<Pixel>::FlipVertical(
    ImageImpl<Pixel>& ioImage,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid())
    return false;

  const uint32 h = ioImage.GetHeight();
  const uint32 w = ioImage.GetWidth();
  const uint32 bytesWidth = ioImage.sizeofWidth();

  Pixel_t * plBuffer = new Pixel_t[w];
  if (NULL == plBuffer)
    return false;

  Pixel_t * prTop = ioImage.GetPixel();
  Pixel_t * prBottom = prTop + w*(h-1);

  const uint32 Half = h/2;
  for (uint32 i=0; i<Half; ++i)
  {
    // memcpy deals with size in byte
    ::memcpy(plBuffer, prTop,    bytesWidth);
    ::memcpy(prTop,    prBottom, bytesWidth);
    ::memcpy(prBottom, plBuffer, bytesWidth);

    prTop += w;
    prBottom -= w;
  }

  elxSAFE_DELETE_LIST(plBuffer);
  return true;

} // FlipVertical


//----------------------------------------------------------------------------
//  FlipHorizontal : perform horizontal symmetry of image
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageGeometryImpl<Pixel>::FlipHorizontal(ImageImpl<Pixel>& ioImage,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid())
    return false;

  Pixel_t * prLeft, * prRight, tmp;
  Pixel_t * prLine = ioImage.GetPixel();

  const uint32 w = ioImage.GetWidth();
  const uint32 Half = w / 2;  // in pixel
  const uint32 Last = w - 1;  // in pixel

  for (uint32 i=ioImage.GetHeight(); i>0; --i)
  {
    prLeft  = prLine;
    prRight = prLine + Last;
    for (uint32 j=Half; j>0; --j)
    {
      tmp = *prLeft;
      *prLeft++ = *prRight;
      *prRight-- = tmp;
    }
    prLine += w;
  }
  return true;

} // FlipHorizontal


//----------------------------------------------------------------------------
//  Flip :
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageGeometryImpl<Pixel>::Flip(ImageImpl<Pixel>& ioImage,
    EFlipPlane iFlipPlane,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid())
    return false;

  switch(iFlipPlane)
  {
    case FP_Horizontal: return FlipHorizontal(ioImage, iNotifier);
    case FP_Vertical:   return FlipVertical(ioImage, iNotifier);
    case FP_Both:       FlipHorizontal(ioImage); return FlipVertical(ioImage, iNotifier);
    case FP_None:
    default:
      break;
  }
  return false;

} // Flip


//----------------------------------------------------------------------------
//  CreateFlipped
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateFlipped(
    const ImageImpl<Pixel>& iImage,
    EFlipPlane iFlipPlane,
    ProgressNotifier& iNotifier)
{
  boost::shared_ptr< ImageImpl<Pixel> > spImage(new ImageImpl<Pixel>(iImage));
  Flip(*spImage, iFlipPlane, iNotifier);
  return spImage;

} // CreateFlipped


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Flip : perform symmetry of image
//----------------------------------------------------------------------------
//  public virtual from IImageGeometry
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageGeometryImpl<Pixel>::Flip(AbstractImage& ioImage, 
    EFlipPlane iFlipPlane,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Flip(image, iFlipPlane, iNotifier);

} // Flip


//----------------------------------------------------------------------------
//  CreateFlipped
//----------------------------------------------------------------------------
//  public virtual from IImageGeometry
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr<AbstractImage> ImageGeometryImpl<Pixel>::CreateFlipped(
    const AbstractImage& iImage,
    EFlipPlane iFlipPlane,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return CreateFlipped(image, iFlipPlane, iNotifier);

} // CreateFlipped


} // namespace Image
} // namespace eLynx

#endif // __Geometry_Flip_hpp__
