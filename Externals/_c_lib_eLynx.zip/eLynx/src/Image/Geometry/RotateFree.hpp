//============================================================================
//  Geometry/RotateFree.hpp                            Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_RotateFree_hpp__
#define __Geometry_RotateFree_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

static const double elxROTATE_EPSILON = 1e-10;

template <typename T>
inline 
void elxRotate2D(int32 iX,int32 iY, T iCos,T iSin, T iRx,T iRy, T& oXr,T& oYr)
{
  oXr = iRx + (iX - iRx)*iCos - (iY - iRy)*iSin;
  oYr = iRy + (iY - iRy)*iCos + (iX - iRx)*iSin;
}
/*
//----------------------------------------------------------------------------
//  CreateRotated :
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateRotated(
    const ImageImpl<Pixel>& iImage, 
    double iDegrees,
    int32 iFlags,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const bool bExpand        = 0 != (iFlags & RF_Expand);
  const bool bInterpolation = 0 != (iFlags & RF_Interpolation);
  const bool bAntialiasing  = 0 != (iFlags & RF_Antialiasing);

  typedef typename Pixel_t::type T;
  typedef typename Pixel_t::F_type F;
  typedef typename Pixel_t::FloatingPixel Pixel_F;

  const Pixel blank = Pixel::Black();
  const int32 w = iImage.GetWidth();
  const int32 h = iImage.GetHeight();
  const int32 w1 = w - 1;
  const int32 h1 = h - 1;

  // Screen coordinates are a mirror image of math coordinates
  const double radians = Math::elxDeg2Rad(iDegrees);
  const F cos = F(Math::elxCos(radians));
  const F sin = F(Math::elxSin(radians));
  
  // center of rotation in source image
  const F xc1 = F(0.5*w);
  const F yc1 = F(0.5*h);

  int32 nw,nh, x1a,y1a, x2a,y2a;
  if (bExpand)
  {
    // compute rotated image size
    F x1,y1, x2,y2, x3,y3, x4,y4;
    elxRotate2D(0 ,0  ,cos,sin, xc1,yc1, x1,y1);
    elxRotate2D(0 ,h1 ,cos,sin, xc1,yc1, x2,y2);
    elxRotate2D(w1,0  ,cos,sin, xc1,yc1, x3,y3);
    elxRotate2D(w1,h1 ,cos,sin, xc1,yc1, x4,y4);

    x1a = (int32) Math::elxFloor(Math::elxMin(x1, x2, x3, x4) );
    y1a = (int32) Math::elxFloor(Math::elxMin(y1, y2, y3, y4) );
    x2a = (int32) Math::elxCeil( Math::elxMax(x1, x2, x3, x4) );
    y2a = (int32) Math::elxCeil( Math::elxMax(y1, y2, y3, y4) );

    nw = x2a - x1a + 1;
    nh = y2a - y1a + 1;
  }
  else
  {
    x1a = 0; x2a = w1;
    y1a = 0; y2a = h1;
    nw = w; nh = h;
  }

  // center of rotation of output image
  const F xc2 = F(0.5*nw);
  const F yc2 = F(0.5*nh);

  // create output image, ISO resolution, with new dimensions
  boost::shared_ptr< ImageImpl<Pixel> > 
    spImage( new ImageImpl<Pixel>(nw, nh) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // init variables
  const Pixel * prSrc = iImage.GetPixel();
  Pixel * prDst = spImage->GetPixel();

  int32 x;
  F xsd,ysd;
  if (bInterpolation)
  {
    // pixel interpolation, slow but accurate.
    const uint32 nChannel = Pixel::GetChannelCount();
    uint32 c;
    F v;
    for (int32 y=0; y<nh; y++)
    {
      for (x=0; x<nw; x++, prDst++)
      {
        xsd = xc1 + (x - xc2) * cos + (y - yc2) * sin;
        ysd = yc1 + (y - yc2) * cos - (x - xc2) * sin;
        if ((-0.25 < xsd) && (xsd < w1 + 0.25) &&
            (-0.25 < ysd) && (ysd < h1 + 0.25))
        {
          // interpolate using the 4 enclosing grid-points.  
          // Those points can be obtained using floor and 
          // ceiling of the exact coordinates of the point
          int32 x1,y1, x2,y2;

          if ((0 < xsd) && (xsd < w1))
          {
            x1 = Math::elxRint( Math::elxFloor(xsd) );
            x2 = Math::elxRint( Math::elxCeil(xsd) );
          }
          else
          {
            // x is near one of the borders (0 or width-1)
            x1 = x2 = Math::elxRint(xsd);
          }

          if ((0 < ysd) && (ysd < h1))
          {
            y1 = Math::elxRint( Math::elxFloor(ysd) );
            y2 = Math::elxRint( Math::elxCeil(ysd) );
          }
          else
          {
            // y is near one of the borders (0 or height-1)
            y1 = y2 = Math::elxRint(ysd);
          }
    
          // Interpolate as a weighted average of the four surrounding points, 
          // where the weights are the distances to each of those points.

          // If the point is exactly at one point of the grid of the source image, 
          // then don't interpolate, just assign the pixel.
          const F d1 = (xsd-x1)*(xsd-x1) + (ysd-y1)*(ysd-y1);
          if (d1 < elxROTATE_EPSILON)
          {
            *prDst = *(prSrc + y1*w + x1);
          }
          else 
          {
            const F d2 = (xsd-x2)*(xsd-x2) + (ysd-y1)*(ysd-y1);
            if (d2 < elxROTATE_EPSILON)
            {
              *prDst = *(prSrc + y1*w + x2);
            }
            else
            {
              const F d3 = (xsd-x2)*(xsd-x2) + (ysd-y2)*(ysd-y2);
              if (d3 < elxROTATE_EPSILON)
              {
                *prDst = *(prSrc + y2*w + x2);
              }
              else 
              {
                const F d4 = (xsd-x1)*(xsd-x1) + (ysd-y2)*(ysd-y2);
                if (d4 < elxROTATE_EPSILON)
                {
                  *prDst = *(prSrc + y2*w + x1);
                }
                else
                {
                  // weights for the weighted average are proportional to the inverse of the distance
                  F a1 = 1/d1;
                  F a2 = 1/d2;
                  F a3 = 1/d3;
                  F a4 = 1/d4;
                  F s = 1/(a1 + a2 + a3 + a4);

                  const Pixel * p1 = prSrc + y1*w;
                  const Pixel * p2 = prSrc + y2*w;

                  for (c=0; c<nChannel; c++)
                  {
                    v = s * (a1*p1[x1]._channel[c] + a2*p1[x2]._channel[c] + 
                             a3*p2[x2]._channel[c] + a4*p2[x1]._channel[c]);
                    prDst->_channel[c] = ResolutionTypeTraits<T>::ClampF(v);
                  }
                }
              }
            }
          }
        }
        else
        {
          // source pixel out of scope
          *prDst = blank;
        }
      }
    }
  }
  else
  {
    //------------------------------------------------------------
    // no interpolation, just use pixel copy, fast but inaccurate.
    //------------------------------------------------------------
    for (int32 y=0; y<nh; y++)
      for (x=0; x<nw; x++, prDst++)
      {
        xsd = xc1 + (x - xc2) * cos + (y - yc2) * sin;
        ysd = yc1 + (y - yc2) * cos - (x - xc2) * sin;

        const int32 xs = Math::elxRint(xsd);
        const int32 ys = Math::elxRint(ysd);

        // exclude pixels out of source
        if (xs<0 || xs>w1 || ys<0 || ys>h1)
          *prDst = blank;
        else
          *prDst = prSrc[ys*w + xs];
      }
  }
  return spImage;

} // CreateRotated
*/
namespace {

template <typename F>
struct RotatedBaseTask : public IterationRangeTask
{  
  RotatedBaseTask(F iXc1, F iYc1, F iXc2, F iYc2, F iCos, F iSin, 
    uint32 iInWidth, uint32 iInHeight, uint32 iOutWidth, 
    ProgressNotifier& iNotifier) :
    IterationRangeTask(iNotifier),
    _Xc1(iXc1), _Yc1(iYc1),
    _Xc2(iXc2), _Yc2(iYc2),
    _Cos(iCos), _Sin(iSin),
    _InWidth(iInWidth), _InHeight(iInHeight),
    _OutWidth(iOutWidth)
  {}
  
  RotatedBaseTask(
    const RotatedBaseTask& iOther, const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _Xc1(iOther._Xc1), _Yc1(iOther._Yc1),
    _Xc2(iOther._Xc2), _Yc2(iOther._Yc2),
    _Cos(iOther._Cos), _Sin(iOther._Sin),
    _InWidth(iOther._InWidth), _InHeight(iOther._InHeight),
    _OutWidth(iOther._OutWidth)
  {} 
    
  const F _Xc1;           // Center of rotation in source image
  const F _Yc1;
  const F _Xc2;           // Center of rotation in destination image
  const F _Yc2;
  const F _Cos;           // Screen coordinates
  const F _Sin;
  const uint32 _InWidth;    // Source Image Width
  const uint32 _InHeight;   // Source Image Height
  const uint32 _OutWidth;    // Destination Image Width
    
}; // RotatedBaseTask

template <typename Pixel>
struct RotatedInterpolationTask : 
  public RotatedBaseTask<typename Pixel::F_type>
{
  typedef typename Pixel::type T;
  typedef typename Pixel::F_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
  
  RotatedInterpolationTask(const Pixel * iprSrc, Pixel * iprDst,
    F iXc1, F iYc1, F iXc2, F iYc2, F iCos, F iSin, uint32 iInWidth,
    uint32 iInHeight, uint32 iOutWidth, ProgressNotifier& iNotifier) :
    RotatedBaseTask<F>(iXc1, iYc1, iXc2, iYc2, iCos, iSin, iInWidth,
      iInHeight, iOutWidth, iNotifier),
    _prSrc(iprSrc), 
    _prDst(iprDst) 
  {}
  
  RotatedInterpolationTask(
    const RotatedInterpolationTask& iOther, const IterationRange& iRange) :
    RotatedBaseTask<F>(iOther, iRange),
    _prSrc(iOther._prSrc), 
    _prDst(iOther._prDst) 
  {}   
  
  uint32 operator()()
  {
    const Pixel blank = Pixel::Black();
    const F xc1 = this->_Xc1;
    const F yc1 = this->_Yc1;
    const F xc2 = this->_Xc2;
    const F yc2 = this->_Yc2;
    const F cos = this->_Cos;
    const F sin = this->_Sin;
    const int32 nw = (int32)this->_OutWidth;
    const int32 w = (int32)this->_InWidth;
    const int32 w1 = w - 1;
    const int32 h = (int32)this->_InHeight;
    const int32 h1 = h - 1;
    int32 begin = (int32)this->_begin;
    int32 end = (int32)this->_end;
    const Pixel * prSrc = _prSrc;
    Pixel * prDst = _prDst + begin*nw;
    
    // --- inits progress ---
    const float ProgressStep = 1.f / (float)(end-begin);
    float Progress = 0.0f;
    this->_notifier.SetProgress(0.0f);
    
    int32 x,xs,ys;
    F xsd,ysd,dx,dy;
    const Pixel * p1,* p2,* p3,* p4;
    Pixel_F pixel,pixel1,pixel2;
    for (int32 y=begin; y<end; y++)
    {
      for (x=0; x<nw; x++, prDst++)
      {
        xsd = xc1 + (x - xc2) * cos + (y - yc2) * sin;
        ysd = yc1 + (y - yc2) * cos - (x - xc2) * sin;

        // Bottom left coords of bounding rectangle on output image
        xs = Math::elxRint(xsd);
        ys = Math::elxRint(ysd);
        if (0<=xs && xs<w && 0<=ys && ys<h)
        {
          dx = xsd - xs;
          dy = ysd - ys;

          p1 = prSrc + ys*w + xs;           //(x  ,y)
          p2 = (xs == w1) ? &blank : p1+1;  //(x+1,y)
          if (ys != h1)
          {
            p3 = prSrc + (ys+1)*w + xs;       //(x  ,y+1)
            p4 = (xs == w1) ? &blank : p3+1;  //(x+1,y+1)
          }
          else
          {
            p3 = p4 = &blank;
          }
          pixel1 = T(1 - dx) * p1[0] + T(dx) * p2[0];
          pixel2 = T(1 - dx) * p2[0] + T(dx) * p3[0];

          pixel  = (1 - dy) * pixel1 + dy * pixel2;

          elxPixelClamp(pixel, *prDst);
        }
      }
      // --- in progress ... ---
      Progress += ProgressStep;
      this->_notifier.SetProgress(Progress);
    }
    // --- progress end ---
    this->_notifier.SetProgress(1.0f);
    return elxOK;
  }
  
  const Pixel * _prSrc;   // Source Image
  Pixel * _prDst;         // Destination Image
}; // RotatedInterpolationTask

template <typename Pixel>
struct RotatedNoInterpolationTask : 
  public RotatedBaseTask<typename Pixel::F_type>
{
  typedef typename Pixel::type T;
  typedef typename Pixel::F_type F;
  typedef typename Pixel::FloatingPixel Pixel_F;
  
  RotatedNoInterpolationTask(const Pixel * iprSrc, Pixel * iprDst,
    F iXc1, F iYc1, F iXc2, F iYc2, F iCos, F iSin, uint32 iInWidth,
    uint32 iInHeight, uint32 iOutWidth, ProgressNotifier& iNotifier) :
    RotatedBaseTask<F>(iXc1, iYc1, iXc2, iYc2, iCos, iSin,iInWidth,
      iInHeight, iOutWidth, iNotifier),
    _prSrc(iprSrc), 
    _prDst(iprDst) 
  {}
  
  RotatedNoInterpolationTask(
    const RotatedNoInterpolationTask& iOther, const IterationRange& iRange) :
    RotatedBaseTask<F>(iOther, iRange),
    _prSrc(iOther._prSrc), 
    _prDst(iOther._prDst) 
  {}   
  
  uint32 operator()()
  {
    const Pixel blank = Pixel::Black();
    const F xc1 = this->_Xc1;
    const F yc1 = this->_Yc1;
    const F xc2 = this->_Xc2;
    const F yc2 = this->_Yc2;
    const F cos = this->_Cos;
    const F sin = this->_Sin;
    const int32 nw = (int32)this->_OutWidth;
    const int32 w = (int32)this->_InWidth;
    const int32 w1 = w - 1;
    const int32 h1 = (int32)this->_InHeight - 1;
    int32 begin = (int32)this->_begin;
    int32 end = (int32)this->_end;
    const Pixel * prSrc = _prSrc;
    Pixel * prDst = _prDst + begin*nw;
    
    // --- inits progress ---
    const float ProgressStep = 1.f / (float)(end-begin);
    float Progress = 0.0f;
    this->_notifier.SetProgress(0.0f);
    
    int32 x,xs,ys;
    F xsd,ysd;
    for (int32 y=begin; y<end; y++)
    {
      for (x=0; x<nw; x++, prDst++)
      {
        xsd = xc1 + (x - xc2) * cos + (y - yc2) * sin;
        ysd = yc1 + (y - yc2) * cos - (x - xc2) * sin;

        xs = Math::elxRint(xsd);
        ys = Math::elxRint(ysd);

        // exclude pixels out of source
        if (xs<0 || xs>w1 || ys<0 || ys>h1)
          *prDst = blank;
        else
          *prDst = prSrc[ys*w + xs];
      }
      // --- in progress ... ---
      Progress += ProgressStep;
      this->_notifier.SetProgress(Progress);
    }
    // --- progress end ---
    this->_notifier.SetProgress(1.0f);
    return elxOK;
  }
  
  const Pixel * _prSrc;   // Source Image
  Pixel * _prDst;         // Destination Image
}; // RotatedInterpolationTask

} //namespace

//----------------------------------------------------------------------------
//  CreateRotated :
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateRotated(
    const ImageImpl<Pixel>& iImage, 
    double iDegrees,
    int32 iFlags,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const bool bExpand        = 0 != (iFlags & RF_Expand);
  const bool bInterpolation = 0 != (iFlags & RF_Interpolation);
//  const bool bAntialiasing  = 0 != (iFlags & RF_Antialiasing);

  typedef typename Pixel_t::type T;
  typedef typename Pixel_t::F_type F;
  typedef typename Pixel_t::FloatingPixel Pixel_F;

  const Pixel blank = Pixel::Black();
  const int32 w = iImage.GetWidth();
  const int32 h = iImage.GetHeight();
  const int32 w1 = w - 1;
  const int32 h1 = h - 1;

  // Screen coordinates are a mirror image of math coordinates
  const double radians = Math::elxDeg2Rad(iDegrees);
  const F cos = F(Math::elxCos(radians));
  const F sin = F(Math::elxSin(radians));
  
  // center of rotation in source image
  const F xc1 = F(0.5*w);
  const F yc1 = F(0.5*h);

  int32 nw,nh, x1a,y1a, x2a,y2a;
  if (bExpand)
  {
    // compute rotated image size
    F x1,y1, x2,y2, x3,y3, x4,y4;
    elxRotate2D(0 ,0  ,cos,sin, xc1,yc1, x1,y1);
    elxRotate2D(0 ,h1 ,cos,sin, xc1,yc1, x2,y2);
    elxRotate2D(w1,0  ,cos,sin, xc1,yc1, x3,y3);
    elxRotate2D(w1,h1 ,cos,sin, xc1,yc1, x4,y4);

    x1a = (int32) Math::elxFloor(Math::elxMin(x1, x2, x3, x4) );
    y1a = (int32) Math::elxFloor(Math::elxMin(y1, y2, y3, y4) );
    x2a = (int32) Math::elxCeil( Math::elxMax(x1, x2, x3, x4) );
    y2a = (int32) Math::elxCeil( Math::elxMax(y1, y2, y3, y4) );

    nw = x2a - x1a + 1;
    nh = y2a - y1a + 1;
  }
  else
  {
    x1a = 0; x2a = w1;
    y1a = 0; y2a = h1;
    nw = w; nh = h;
  }

  // center of rotation of output image
  const F xc2 = F(0.5*nw);
  const F yc2 = F(0.5*nh);

  // create output image, ISO resolution, with new dimensions
  boost::shared_ptr< ImageImpl<Pixel> > 
    spImage( new ImageImpl<Pixel>(nw, nh) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // init variables
  const Pixel * prSrc = iImage.GetPixel();
  Pixel * prDst = spImage->GetPixel();
  IterationRange range(0, nh);

 if (bInterpolation)
 {
    // pixel interpolation, slow but accurate.
    RotatedInterpolationTask<Pixel> task(prSrc, prDst,
      xc1, yc1, xc2, yc2, cos, sin, w, h, nw, iNotifier);
    if (elxOK != elxParallelFor(range, task))
      return boost::shared_ptr< ImageImpl<Pixel> >();
  }
  else
  {
    //------------------------------------------------------------
    // no interpolation, just use pixel copy, fast but inaccurate.
    //------------------------------------------------------------
    RotatedNoInterpolationTask<Pixel> task(prSrc, prDst,
      xc1, yc1, xc2, yc2, cos, sin, w, h, nw, iNotifier);
    if (elxOK != elxParallelFor(range, task))
      return boost::shared_ptr< ImageImpl<Pixel> >();
  }
  return spImage;

} // CreateRotated


//----------------------------------------------------------------------------
//  Rotate :
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageGeometryImpl<Pixel>::Rotate(
    ImageImpl<Pixel>& ioImage, 
    double iDegrees,
    int32 iFlags,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;
  boost::shared_ptr< ImageImpl<Pixel> > spImage =
    CreateRotated(ioImage, iDegrees, iFlags, iNotifier);
  return ioImage.CopyAndForget(spImage);

} // Rotate

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  Rotate : Rotate image with finest rotation angle in degrees.
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Rotate(
    AbstractImage& ioImage,
    double iDegrees,
    int32 iFlags,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Rotate(image, iDegrees, iFlags, iNotifier);

} // Rotate

//----------------------------------------------------------------------------
//  CreateRotated :
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr<AbstractImage> ImageGeometryImpl<Pixel>::CreateRotated(
    const AbstractImage& iImage,
    double iDegrees,
    int32 iFlags,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return CreateRotated(image, iDegrees, iFlags, iNotifier);

} // CreateRotated

} // namespace Image
} // namespace eLynx

#endif // __Geometry_RotateFree_hpp__
/*
VERSION 5.00
Begin VB.Form Form1 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00E0E0E0&
   Caption         =   "Form1"
   ClientHeight    =   5505
   ClientLeft      =   165
   ClientTop       =   450
   ClientWidth     =   8445
   LinkTopic       =   "Form1"
   ScaleHeight     =   367
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   563
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command3 
      Caption         =   "Anti-aliasing Rotate"
      Height          =   315
      Left            =   870
      TabIndex        =   4
      Top             =   4320
      Width           =   1545
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Rotate && Smooth"
      Height          =   315
      Left            =   840
      TabIndex        =   3
      Top             =   3720
      Width           =   1575
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Rotate"
      Height          =   315
      Left            =   840
      TabIndex        =   2
      Top             =   3120
      Width           =   1575
   End
   Begin VB.PictureBox Picture2 
      BorderStyle     =   0  'None
      Height          =   4425
      Left            =   3270
      ScaleHeight     =   295
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   321
      TabIndex        =   1
      Top             =   420
      Width           =   4815
   End
   Begin VB.PictureBox Picture1 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   2115
      Left            =   495
      ScaleHeight     =   141
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   163
      TabIndex        =   0
      Top             =   420
      Width           =   2445
   End
   Begin VB.Label Label2 
      BackColor       =   &H00E0E0E0&
      Caption         =   "Picture2"
      Height          =   270
      Left            =   4590
      TabIndex        =   6
      Top             =   90
      Width           =   2325
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Picture1 long color"
      Height          =   255
      Left            =   840
      TabIndex        =   5
      Top             =   45
      Width           =   1635
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' Anti-aliasing Demo by Robert Rayment

Option Base 1

DefLng A-W
DefSng X-Z

'Windows API - much faster then VB's PSet and Point
Private Declare Function SetPixelV Lib "gdi32" _
(ByVal hdc As Long, ByVal X As Long, ByVal Y As Long, ByVal crColor As Long) As Long
Private Declare Function GetPixel Lib "gdi32" _
(ByVal hdc As Long, ByVal X As Long, ByVal Y As Long) As Long

Dim LongCul()
Dim redc As Byte, greenc As Byte, bluec As Byte

Const pi# = 3.1415926

Private Sub Form_Load()
Caption = "Rotation & Anti-aliasing  by  Robert Rayment"

Picture1.Picture = LoadPicture("Test.bmp")
ReDim LongCul(4)

End Sub


Private Sub Command1_Click()

'Rotate

Picture2.Cls

zang = pi# / 6

zCos = Cos(zang)
zSin = Sin(zang)

picW = Picture2.Width
picH = Picture2.Height

ixc1 = Picture1.Width / 2: iyc1 = Picture1.Height / 2
ixc2 = Picture2.Width / 2: iyc2 = Picture2.Height / 2

For iy = 1 To picH
For ix = 1 To picW


'   'For each Picture2 point find rotated Picture1 source point
   ixs = ixc1 + (ix - ixc2) * zCos + (iy - iyc2) * zSin
   iys = iyc1 + (iy - iyc2) * zCos - (ix - ixc2) * zSin

'   'Move valid rotated Picture1 source points to Picture2
   LongCulAV = GetPixel(Picture1.hdc, ixs, iys)
   If LongCulAV <> -1 Then
      res& = SetPixelV(Picture2.hdc, ix, iy, LongCulAV)
   End If

Next ix
Next iy


End Sub

Private Sub Command2_Click()

'ReDim LongCul(4)

' Rotate & Smooth

Picture2.Cls

zang = pi# / 6

zCos = Cos(zang)
zSin = Sin(zang)

picW = Picture2.Width
picH = Picture2.Height

ixc1 = Picture1.Width / 2: iyc1 = Picture1.Height / 2
ixc2 = Picture2.Width / 2: iyc2 = Picture2.Height / 2

For iy = 1 To picH
For ix = 1 To picW


   ixs = ixc1 + (ix - ixc2 - 1) * zCos + (iy - iyc2) * zSin
   iys = iyc1 + (iy - iyc2) * zCos - (ix - ixc2 - 1) * zSin
   LongCul(1) = GetPixel(Picture1.hdc, ixs, iys)
   If LongCul(1) = -1 Then GoTo Nextix
   
   ixs = ixc1 + (ix - ixc2 + 1) * zCos + (iy - iyc2) * zSin
   iys = iyc1 + (iy - iyc2) * zCos - (ix - ixc2 + 1) * zSin
   LongCul(2) = GetPixel(Picture1.hdc, ixs, iys)
   If LongCul(2) = -1 Then GoTo Nextix
   
   ixs = ixc1 + (ix - ixc2) * zCos + (iy - iyc2 + 1) * zSin
   iys = iyc1 + (iy - iyc2 + 1) * zCos - (ix - ixc2) * zSin
   LongCul(3) = GetPixel(Picture1.hdc, ixs, iys)
   If LongCul(3) = -1 Then GoTo Nextix

   ixs = ixc1 + (ix - ixc2) * zCos + (iy - iyc2 - 1) * zSin
   iys = iyc1 + (iy - iyc2 - 1) * zCos - (ix - ixc2) * zSin
   LongCul(4) = GetPixel(Picture1.hdc, ixs, iys)
   If LongCul(4) = -1 Then GoTo Nextix
   
   SMOOTH LongCulAV
   
   res& = SetPixelV(Picture2.hdc, ix, iy, LongCulAV)


Nextix:
Next ix
Next iy


End Sub

Private Sub Command3_Click()

' AA Rotate  Anti-aliasing

' 4 point weighting

' Let xs, ys be the point in Picture1 that would go to Picture2 on
' rotation.  xs & ys will not often be integers and in general will
' lie inside a rectangle on Picture1 from Int(xs), Int(ys) to
' Int(xs)+1, Int(ys)+1.  After checking that the point lies inside
' Picture1 a proportionate weighting of the colors at Int(xs) & Int(xs)+1
' at Int(ys) and Int(xs) & Int(xs)+1 at Int(ys)+1 gives 2 colors
' which are then proportionately weighted in the y direction.


Picture2.Cls

zang = pi# / 6 ' Rotation angle

zCos = Cos(zang)
zSin = Sin(zang)

PicW1 = Picture1.Width
PicH1 = Picture1.Height
picW2 = Picture2.Width
picH2 = Picture2.Height

ixc1 = Picture1.Width / 2: iyc1 = Picture1.Height / 2
ixc2 = Picture2.Width / 2: iyc2 = Picture2.Height / 2

For iy = 0 To picH2 - 1
For ix = 0 To picW2 - 1

   xs = ixc1 + (ix - ixc2) * zCos + (iy - iyc2) * zSin
   ys = iyc1 + (iy - iyc2) * zCos - (ix - ixc2) * zSin

   ' Bottom left coords of bounding
   ' rectangle on Picture1
   ixs0 = Int(xs)
   iys0 = Int(ys)
   
   If ixs0 > 0 And ixs0 < PicW1 - 1 And iys0 > 0 And iys0 < PicH1 - 1 Then
      
      xfs1 = xs - Int(xs)
      yfs1 = ys - Int(ys)
      
      'ixs0->ixs0+1, iyso
      LongCul0 = GetPixel(Picture1.hdc, ixs0, iys0)
      CulToRGB LongCul0, redc, greenc, bluec
      culr = (1 - xfs1) * redc
      culg = (1 - xfs1) * greenc
      culb = (1 - xfs1) * bluec
   
      LongCul1 = GetPixel(Picture1.hdc, ixs0 + 1, iys0)
      CulToRGB LongCul1, redc, greenc, bluec
      culr0 = culr + xfs1 * redc
      culg0 = culg + xfs1 * greenc
      culb0 = culb + xfs1 * bluec
      
      'ixs0->ixs0+1, iys0+1
      LongCul0 = GetPixel(Picture1.hdc, ixs0, iys0 + 1)
      CulToRGB LongCul0, redc, greenc, bluec
      culr = (1 - xfs1) * redc
      culg = (1 - xfs1) * greenc
      culb = (1 - xfs1) * bluec
      
      LongCul1 = GetPixel(Picture1.hdc, ixs0 + 1, iys0 + 1)
      CulToRGB LongCul1, redc, greenc, bluec
      culr1 = culr + xfs1 * redc
      culg1 = culg + xfs1 * greenc
      culb1 = culb + xfs1 * bluec
   
      ' Weight along y axis
      culr = (1 - yfs1) * culr0 + yfs1 * culr1
      culg = (1 - yfs1) * culg0 + yfs1 * culg1
      culb = (1 - yfs1) * culb0 + yfs1 * culb1
   
      res& = SetPixelV(Picture2.hdc, ix, iy, RGB(culr, culg, culb))

   End If
   
Next ix
Next iy

End Sub


Public Sub SMOOTH(LongCulAV)

'ReDim LongCul(4)

   D = 4
   CulToRGB LongCul(1), redc, greenc, bluec
   culr = redc / D
   culg = greenc / D
   culb = bluec / D
   
   CulToRGB LongCul(2), redc, greenc, bluec
   culr = culr + redc / D
   culg = culg + greenc / D
   culb = culb + bluec / D
   
   CulToRGB LongCul(3), redc, greenc, bluec
   culr = culr + redc / D
   culg = culg + greenc / D
   culb = culb + bluec / D
   
   CulToRGB LongCul(4), redc, greenc, bluec
   culr = culr + redc / D
   culg = culg + greenc / D
   culb = culb + bluec / D
   
   LongCulAV = RGB(culr, culg, culb)

End Sub
Public Sub CulToRGB(LongCul, redc As Byte, greenc As Byte, bluec As Byte)
'Global redc As Byte, greenc As Byte, bluec As Byte
'Input longcul:  Output: R G B
redc = LongCul And &HFF&
greenc = (LongCul& And &HFF00&) / &H100&
bluec = (LongCul& And &HFF0000) / &H10000
End Sub

Private Sub Picture1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
Label1.Caption = Str$(GetPixel(Picture1.hdc, X, Y))
End Sub
*/

/*
//----------------------------------------------------------------------------
//  CreateRotated :
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateRotated(
    const ImageImpl<Pixel>& iImage, 
    double iDegrees,
    int32 iFlags,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const bool bExpand        = 0 != (iFlags & RF_Expand);
  const bool bInterpolation = 0 != (iFlags & RF_Interpolation);
  const bool bAntialiasing  = 0 != (iFlags & RF_Antialiasing);

  typedef typename Pixel_t::type T;
  typedef typename Pixel_t::F_type F;
  typedef typename Pixel_t::FloatingPixel Pixel_F;

  const Pixel blank = Pixel::Black();
  const int32 w = iImage.GetWidth();
  const int32 h = iImage.GetHeight();
  const int32 w1 = w - 1;
  const int32 h1 = h - 1;

  // Screen coordinates are a mirror image of math coordinates
  const double radians = Math::elxDeg2Rad(iDegrees);
  const F cos = F(Math::elxCos(radians));
  const F sin = F(Math::elxSin(radians));
  
  // center of rotation in source image
  const F xc1 = F(0.5*w);
  const F yc1 = F(0.5*h);

  int32 nw,nh, x1a,y1a, x2a,y2a;
  if (bExpand)
  {
    // compute rotated image size
    F x1,y1, x2,y2, x3,y3, x4,y4;
    elxRotate2D(0 ,0  ,cos,sin, xc1,yc1, x1,y1);
    elxRotate2D(0 ,h1 ,cos,sin, xc1,yc1, x2,y2);
    elxRotate2D(w1,0  ,cos,sin, xc1,yc1, x3,y3);
    elxRotate2D(w1,h1 ,cos,sin, xc1,yc1, x4,y4);

    x1a = (int32) Math::elxFloor(Math::elxMin(x1, x2, x3, x4) );
    y1a = (int32) Math::elxFloor(Math::elxMin(y1, y2, y3, y4) );
    x2a = (int32) Math::elxCeil( Math::elxMax(x1, x2, x3, x4) );
    y2a = (int32) Math::elxCeil( Math::elxMax(y1, y2, y3, y4) );

    nw = x2a - x1a + 1;
    nh = y2a - y1a + 1;
  }
  else
  {
    x1a = 0; x2a = w1;
    y1a = 0; y2a = h1;
    nw = w; nh = h;
  }

  // center of rotation of output image
  const F xc2 = F(0.5*nw);
  const F yc2 = F(0.5*nh);

  // create output image, ISO resolution, with new dimensions
  boost::shared_ptr< ImageImpl<Pixel> > 
    spImage( new ImageImpl<Pixel>(nw, nh) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  // init variables
  const Pixel * prSrc = iImage.GetPixel();
  Pixel * prDst = spImage->GetPixel();

  int32 x;
  F xsd,ysd;
  if (bInterpolation)
  {
    // pixel interpolation, slow but accurate.
    const uint32 nChannel = Pixel::GetChannelCount();
    uint32 c;
    F v;
    int32 xs,ys;
    const Pixel * p1,* p2,* p3,* p4;
    for (int32 y=0; y<nh; y++)
    {
      for (x=0; x<nw; x++, prDst++)
      {
        // p1
        xsd = xc1 + (x - xc2 - 1) * cos + (y - yc2)     * sin;
        ysd = yc1 + (y - yc2)     * cos - (x - xc2 - 1) * sin;
        xs = Math::elxRint(xsd);
        ys = Math::elxRint(ysd);
        p1 = (xs<0 || xs>w1 || ys<0 || ys>h1) ? &blank : prSrc + ys*w + xs;

        // p2
        xsd = xc1 + (x - xc2 + 1) * cos + (y - yc2)     * sin;
        ysd = yc1 + (y - yc2)     * cos - (x - xc2 + 1) * sin;
        xs = Math::elxRint(xsd);
        ys = Math::elxRint(ysd);
        p2 = (xs<0 || xs>w1 || ys<0 || ys>h1) ? &blank : prSrc + ys*w + xs;

        // p3
        xsd = xc1 + (x - xc2)     * cos + (y - yc2 - 1) * sin;
        ysd = yc1 + (y - yc2 - 1) * cos - (x - xc2)     * sin;
        xs = Math::elxRint(xsd);
        ys = Math::elxRint(ysd);
        p3 = (xs<0 || xs>w1 || ys<0 || ys>h1) ? &blank : prSrc + ys*w + xs;

        // p4
        xsd = xc1 + (x - xc2)     * cos + (y - yc2 + 1) * sin;
        ysd = yc1 + (y - yc2 + 1) * cos - (x - xc2)     * sin;
        xs = Math::elxRint(xsd);
        ys = Math::elxRint(ysd);
        p4 = (xs<0 || xs>w1 || ys<0 || ys>h1) ? &blank : prSrc + ys*w + xs;

        for (c=0; c<nChannel; c++)
        {
          v = F(p1->_channel[c] + p2->_channel[c] + p3->_channel[c] + p4->_channel[c]) / 4;
          prDst->_channel[c] = ResolutionTypeTraits<T>::ClampF(v);
        }
      }
    }
  }
  else
  {
    //------------------------------------------------------------
    // no interpolation, just use pixel copy, fast but inaccurate.
    //------------------------------------------------------------
    for (int32 y=0; y<nh; y++)
      for (x=0; x<nw; x++, prDst++)
      {
        xsd = xc1 + (x - xc2) * cos + (y - yc2) * sin;
        ysd = yc1 + (y - yc2) * cos - (x - xc2) * sin;

        const int32 xs = Math::elxRint(xsd);
        const int32 ys = Math::elxRint(ysd);

        // exclude pixels out of source
        if (xs<0 || xs>w1 || ys<0 || ys>h1)
          *prDst = blank;
        else
          *prDst = prSrc[ys*w + xs];
      }
  }
  return spImage;

} // CreateRotated
*/
