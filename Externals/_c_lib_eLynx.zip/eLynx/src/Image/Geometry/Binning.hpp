//============================================================================
//  Geometry/Binning.hpp                               Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Binning_hpp__
#define __Geometry_Binning_hpp__

#include <elx/core/ParallelAlgorithms.h>
#include <elx/core/CoreTask.h>

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
namespace {

template <uint32 Dim, class Pixel>
struct BinningHelper
{
  typedef Pixel (*OP)(const Pixel* (&iPL) [Dim]);

  static Pixel Mean(const Pixel* (&iPL) [Dim]);
  static Pixel Median(const Pixel* (&iPL) [Dim]);
  static Pixel Sum(const Pixel* (&iPL) [Dim]);
  static Pixel Min(const Pixel* (&iPL) [Dim]);
  static Pixel Max(const Pixel* (&iPL) [Dim]);
};

//----------------------------------------------------------------------------
template <class Pixel>
struct BinningHelper<2, Pixel>
{
  typedef Pixel (*OP)(const Pixel* (&iPL) [2]);

  static Pixel Mean(const Pixel* (&iPL) [2]);
  static Pixel Median(const Pixel* (&iPL) [2]);
  static Pixel Sum(const Pixel* (&iPL) [2]);
  static Pixel Min(const Pixel* (&iPL) [2]);
  static Pixel Max(const Pixel* (&iPL) [2]);
};

template <class Pixel>
inline
Pixel BinningHelper<2, Pixel>::Mean(const Pixel * (&iPL) [2])
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::SumOverflow_type S;

  Pixel pixel;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
  {
    pixel._channel[c] = 
      ResolutionTypeTraits<T>::ClampS(
      ( (S)iPL[0][0]._channel[c] + (S)iPL[0][1]._channel[c] +
        (S)iPL[1][0]._channel[c] + (S)iPL[1][1]._channel[c] ) / S(4) );
  }
  return pixel;

} // Mean

template <class Pixel>
inline
Pixel BinningHelper<2, Pixel>::Median(const Pixel * (&iPL) [2])
{
  Pixel pixel;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
  {
    pixel._channel[c] = Math::elxMedian(
      iPL[0][0]._channel[c], iPL[0][1]._channel[c], 
      iPL[1][0]._channel[c], iPL[1][1]._channel[c]);
  }
  return pixel;

} // Median

template <class Pixel>
inline
Pixel BinningHelper<2, Pixel>::Sum(const Pixel * (&iPL) [2])
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::SumOverflow_type S;

  Pixel pixel;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
  {
    pixel._channel[c] = ResolutionTypeTraits<T>::ClampS(
       (S)iPL[0][0]._channel[c] + (S)iPL[0][1]._channel[c] +
       (S)iPL[1][0]._channel[c] + (S)iPL[1][1]._channel[c] );
  }
  return pixel;

} // Sum

template <class Pixel>
inline
Pixel BinningHelper<2, Pixel>::Min(const Pixel * (&iPL) [2])
{
  Pixel pixel;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
  {
    pixel._channel[c] = Math::elxMin(
      iPL[0][0]._channel[c], iPL[0][1]._channel[c], 
      iPL[1][0]._channel[c], iPL[1][1]._channel[c]);
  }
  return pixel;

} // Min

template <class Pixel>
inline
Pixel BinningHelper<2, Pixel>::Max(const Pixel * (&iPL) [2])
{
  Pixel pixel;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
  {
    pixel._channel[c] = Math::elxMax(
      iPL[0][0]._channel[c], iPL[0][1]._channel[c], 
      iPL[1][0]._channel[c], iPL[1][1]._channel[c]);
  }
  return pixel;

} // Max

//----------------------------------------------------------------------------
template <class Pixel>
struct BinningHelper<3, Pixel>
{
  typedef Pixel (*OP)(const Pixel* (&iPL) [3]);

  static Pixel Mean(const Pixel* (&iPL) [3]);
  static Pixel Median(const Pixel* (&iPL) [3]);
  static Pixel Sum(const Pixel* (&iPL) [3]);
  static Pixel Min(const Pixel* (&iPL) [3]);
  static Pixel Max(const Pixel* (&iPL) [3]);
};

template <class Pixel>
inline
Pixel BinningHelper<3, Pixel>::Mean(const Pixel* (&iPL) [3])
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::SumOverflow_type S;

  Pixel pixel;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
  {
    pixel._channel[c] = 
      ResolutionTypeTraits<T>::ClampS(
      (((S)iPL[0][0]._channel[c] + (S)iPL[0][1]._channel[c] + (S)iPL[0][2]._channel[c] + 
        (S)iPL[1][0]._channel[c] + (S)iPL[1][1]._channel[c] + (S)iPL[1][2]._channel[c] +
        (S)iPL[2][0]._channel[c] + (S)iPL[2][1]._channel[c] + (S)iPL[2][1]._channel[c]) / S(9) ));
  }
  return pixel;  

} // Mean

template <class Pixel>
inline
Pixel BinningHelper<3, Pixel>::Median(const Pixel * (&iPL) [3])
{
  Pixel pixel;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
  {
    pixel._channel[c] = Math::elxMedian(
        iPL[0][0]._channel[c], iPL[0][1]._channel[c], iPL[0][2]._channel[c],
        iPL[1][0]._channel[c], iPL[1][1]._channel[c], iPL[1][2]._channel[c],
        iPL[2][0]._channel[c], iPL[2][1]._channel[c], iPL[2][2]._channel[c]);
  }
  return pixel;

} // Median

template <class Pixel>
inline
Pixel BinningHelper<3, Pixel>::Sum(const Pixel * (&iPL) [3])
{
  typedef typename Pixel::type T;
  typedef typename ResolutionTypeTraits<T>::SumOverflow_type S;

  Pixel pixel;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
  {
    pixel._channel[c] = 
      ResolutionTypeTraits<T>::ClampS(
        (S)iPL[0][0]._channel[c] + (S)iPL[0][1]._channel[c] + (S)iPL[0][2]._channel[c] + 
        (S)iPL[1][0]._channel[c] + (S)iPL[1][1]._channel[c] + (S)iPL[1][2]._channel[c] +
        (S)iPL[2][0]._channel[c] + (S)iPL[2][1]._channel[c] + (S)iPL[2][1]._channel[c]);
  }
  return pixel;  

} // Sum

template <class Pixel>
inline
Pixel BinningHelper<3, Pixel>::Min(const Pixel * (&iPL) [3])
{
  Pixel pixel;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
  {
    pixel._channel[c] = Math::elxMin(
        iPL[0][0]._channel[c], iPL[0][1]._channel[c], iPL[0][2]._channel[c],
        iPL[1][0]._channel[c], iPL[1][1]._channel[c], iPL[1][2]._channel[c],
        iPL[2][0]._channel[c], iPL[2][1]._channel[c], iPL[2][2]._channel[c]);
  }
  return pixel;

} // Min

template <class Pixel>
inline
Pixel BinningHelper<3, Pixel>::Max(const Pixel * (&iPL) [3])
{
  Pixel pixel;
  const uint32 nChannel = Pixel::GetChannelCount();
  for (uint32 c=0; c<nChannel; c++)
  {
    pixel._channel[c] = Math::elxMax(
        iPL[0][0]._channel[c], iPL[0][1]._channel[c], iPL[0][2]._channel[c],
        iPL[1][0]._channel[c], iPL[1][1]._channel[c], iPL[1][2]._channel[c],
        iPL[2][0]._channel[c], iPL[2][1]._channel[c], iPL[2][2]._channel[c]);
  }
  return pixel;

} // Max

//----------------------------------------------------------------------------
template<int32 Dim, class Pixel>
typename BinningHelper<Dim, Pixel>::OP
inline
elxGetBinningMethod(EBinningMethod iMethod)
{
  switch (iMethod)
  {
    case BM_Mean:   return &BinningHelper<Dim, Pixel>::Mean;
    case BM_Median: return &BinningHelper<Dim, Pixel>::Median;
    case BM_Sum:    return &BinningHelper<Dim, Pixel>::Sum;
    case BM_Min:    return &BinningHelper<Dim, Pixel>::Min;
    case BM_Max:    return &BinningHelper<Dim, Pixel>::Max;
    default: return NULL;
  }
} // elxGetBinningMethod

template <uint32 N, uint32 P, typename T>
struct AssignArray
{
  static void assign(T (&array)[N], T iWindow, const uint32 iWidth)
  {
    array[P] = iWindow + P * iWidth;
    AssignArray<N, P + 1, T>::assign(array, iWindow, iWidth);
  }
};

//Specialization to stop recursion

template <uint32 N, typename T>
struct AssignArray<N, N, T>
{
  static void assign(T (&array)[N], T iWindow, const uint32 width) { return; }
};

template <uint32 N, typename T>
inline
void elxAssignArray(T (&array)[N], T iWindow, const uint32 width)
{
  AssignArray<N,0, T>::assign(array, iWindow, width);
}

template <typename Pixel, uint32 Dim>
struct BinningTask : public IterationRangeTask
{
  BinningTask(const Pixel * iprSrc, Pixel * iprDst, uint32 iWidth, uint32 iHeight,
      typename BinningHelper<Dim, Pixel>::OP iBinningOp, 
      ProgressNotifier& iNotifier) :
    IterationRangeTask(
      IterationRange(0, size_t(iHeight/Dim)), iNotifier),
    _prSrc(iprSrc), _prDst(iprDst), _width(iWidth), _BinningOp(iBinningOp)
  {}

  // Split constructor
  BinningTask(const BinningTask& iOther, const IterationRange& iRange) :
    IterationRangeTask(iRange, iOther._notifier),
    _prSrc(iOther._prSrc), _prDst(iOther._prDst), 
    _width(iOther._width), _BinningOp(iOther._BinningOp)
  {}
  
  uint32 operator()()
  {
    // --- declares variables ---
    const uint32 begin = uint32(_begin/Dim);
    const uint32 end = uint32(_end/Dim);
    const uint32 w = _width;
    const uint32 bw = w/Dim;
    const Pixel * prSrc = _prSrc + _begin*w;
    typename BinningHelper<Dim, Pixel>::OP binningOp = _BinningOp;
    
    uint32 x,y;
    Pixel * prDst = _prDst + begin*bw;
    const Pixel * prL[Dim], * prWindow;
    
    // --- inits progress ---
    const float ProgressStep = 1 / (float)(end-begin);
    float Progress = 0.0f;
    _notifier.SetProgress(0.0f);

    // --- process all lines ---
    for (y=begin; y<end; ++y)
    {
      prWindow = prSrc;

     // --- process a line ---
      for (x=0; x<bw; ++x)
      {
        elxAssignArray(prL, prWindow, w);
        *prDst++ = binningOp(prL);
        prWindow += Dim;
      }

      // --- next line ---
      prSrc += Dim * w;
      // --- in progress ... ---
      Progress += ProgressStep;
      _notifier.SetProgress(Progress);
    }

    // --- progress end ---
    _notifier.SetProgress(1.0f);
    return elxOK;
  }
  
private:
  const Pixel * _prSrc; // Source image;
  Pixel * _prDst;       // Destination binning image;
  uint32 _width;          // Source width;
  typename BinningHelper<Dim, Pixel>::OP _BinningOp;  // Binning operation
};

} // anonymous-namespace

//----------------------------------------------------------------------------
//  elxCreateBinned
//----------------------------------------------------------------------------
template <typename Pixel, uint32 Dim>
ExportedByImage
boost::shared_ptr< ImageImpl<Pixel> > elxCreateBinned(
    const ImageImpl<Pixel>& iImage,
    EBinningMethod iMethod,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  typename BinningHelper<Dim, Pixel>::OP binningOp =
    elxGetBinningMethod<Dim, Pixel>(iMethod);
  if (NULL == binningOp)
    return boost::shared_ptr< ImageImpl<Pixel> >();

  uint32 w = iImage.GetWidth();
  uint32 h = iImage.GetHeight();
  uint32 bw = w / Dim;
  uint32 bh = h / Dim;

  // --- allocate space for the new image ---
  boost::shared_ptr< ImageImpl<Pixel> > spImage( new ImageImpl<Pixel>(bw, bh) );
  if (!spImage->IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();
    

  const size_t minRangeSize = (w > 10000)? 1 : 10000/w;
  IterationRange range(0, size_t(h), size_t(Dim), minRangeSize);
  
  BinningTask<Pixel, Dim> 
    task(iImage.GetPixel(), spImage->GetPixel(), w, h, binningOp, iNotifier);
  if (elxOK != elxParallelFor(range, task))
    return boost::shared_ptr< ImageImpl<Pixel> >();
  return spImage;

} // elxCreateBinned


//----------------------------------------------------------------------------
//  CreateBinned
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateBinned(
    const ImageImpl<Pixel>& iImage, 
    uint32 iDim, 
    EBinningMethod iMethod, 
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  switch (iDim)
  {
    case 2: return elxCreateBinned<Pixel, 2>(iImage, iMethod, iNotifier);
    case 3: return elxCreateBinned<Pixel, 3>(iImage, iMethod, iNotifier);
    default: break;
  }
  return boost::shared_ptr< ImageImpl<Pixel> >();
  
} // CreateBinned


//----------------------------------------------------------------------------
//  Bin
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Bin(
    ImageImpl<Pixel>& ioImage,
    uint32 iDim,
    EBinningMethod iMethod,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid())
    return false;

  boost::shared_ptr< ImageImpl<Pixel> > spImage =
    CreateBinned(ioImage, iDim, iMethod, iNotifier);
  return ioImage.CopyAndForget(spImage);

} // Bin

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateBinned
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr<AbstractImage> ImageGeometryImpl<Pixel>::CreateBinned(
    const AbstractImage& iImage,
    uint32 iDim,
    EBinningMethod iMethod,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return CreateBinned(image, iDim,iMethod, iNotifier);
  
} // CreateBinned


//----------------------------------------------------------------------------
//  Binning
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Bin(
    AbstractImage& ioImage,
    uint32 iDim,
    EBinningMethod iMethod,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Bin(image, iDim, iMethod, iNotifier);

} // Bin

} // namespace Image
} // namespace eLynx

#endif // __Geometry_Binning_hpp__
