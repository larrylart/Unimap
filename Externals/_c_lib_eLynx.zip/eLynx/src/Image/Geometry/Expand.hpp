//============================================================================
//  Geometry/Expand.hpp                                Image.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Expand_hpp__
#define __Geometry_Expand_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateExpanded
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
inline
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateExpanded(
    const ImageImpl<Pixel>& iImage, 
    uint32 iBorder, 
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid())
    return boost::shared_ptr< ImageImpl<Pixel> >();

  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();
  const uint32 W = iBorder + w + iBorder;
  const uint32 H = iBorder + h + iBorder;

  // create the new image
  boost::shared_ptr< ImageImpl<Pixel> > spImage(new ImageImpl<Pixel>(W,H));
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  Pixel bg = Pixel_t::Black();
  const Pixel * prSrc = iImage.GetPixel();
  Pixel * prDst = spImage->GetPixel();
  const uint32 byteLineSize = iImage.sizeofWidth();

  uint32 i,j;
  // fill top with background
  for (j=0; j<iBorder; j++) 
    for (i=0; i<W; i++) 
      *prDst++ = bg;

  // fill central
  for (j=0; j<h; j++) 
  {
    // fill left with background
    for (i=0; i<iBorder; i++) 
      *prDst++ = bg;

    // fill medium with src image
    ::memcpy(prDst, prSrc, byteLineSize);
    prSrc += w;
    prDst += w;

    // fill right with background
    for (i=0; i<iBorder; i++) 
      *prDst++ = bg;
  }

  // fill bottom with background
  for (j=0; j<iBorder; j++) 
    for (i=0; i<W; i++) 
      *prDst++ = bg;

  return spImage;

} // CreateExpanded


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateExpanded
//----------------------------------------------------------------------------
template <typename Pixel>
inline
boost::shared_ptr<AbstractImage> ImageGeometryImpl<Pixel>::CreateExpanded(
    const AbstractImage& iImage,
    uint32 iBorder, 
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return CreateExpanded(image, iBorder, iNotifier);

} // CreateExpanded

} // namespace Image
} // namespace eLynx

#endif // __Geometry_Expand_hpp__
