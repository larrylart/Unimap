//============================================================================
//  Geometry/Insert.hpp                                Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Insert_hpp__
#define __Geometry_Insert_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  Insert : Insert a sub image.
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageGeometryImpl<Pixel>::Insert(
    ImageImpl<Pixel>& ioImage,
    const ImageImpl<Pixel>& iInserted, 
    int32 iX, int32 iY,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid()) return false;

  // --- pre-clipping ---
  const int32 w = ioImage.GetWidth();
  const int32 h = ioImage.GetHeight();
  const int32 w2 = iInserted.GetWidth();
  const int32 h2 = iInserted.GetHeight();
  if ((iX >= w) || (iX + w2 <= 0) || 
      (iY >= h) || (iY + h2 <= 0))
    return false;

  // --- Clipping ---
  int32 x1c = iX;
  int32 y1c = iY;
  int32 x2c = 0;
  int32 y2c = 0;
  int32 w2c = w2;
  int32 h2c = h2;
  if (iX < 0)
  {
    x1c = 0;		
    x2c = -iX;
    w2c += iX;
  }
  if (x1c + w2c > w)
    w2c = w - x1c;

  if (iY < 0)
  {
    y1c = 0;
    y2c = -iY;
    h2c += iY;
  }
  if (y1c + h2c > h)
    h2c = h - y1c;

  Pixel * prDst = ioImage.GetPixel(x1c, y1c);
  const Pixel * prSrc = iInserted.GetPixel(x2c, y2c);
  const uint32 size = w2c*sizeof(Pixel);
 
  for (int32 y=0; y<h2c; y++)
  {
    ::memcpy(prDst, prSrc, size);
    prDst += w;
    prSrc += w2;
  }
  return true;
  
} // Insert


//----------------------------------------------------------------------------
//  CreateInserted
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateInserted(
    const ImageImpl<Pixel>& iImage,
    const ImageImpl<Pixel>& iInserted,
    int32 iX, int32 iY,
    ProgressNotifier& iNotifier)
{
  boost::shared_ptr< ImageImpl<Pixel> > spImage( new ImageImpl<Pixel>(iImage) );
  Insert(*spImage.get(), iInserted, iX, iY, iNotifier);
  return spImage;

} // CreateInserted



//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateInserted : 
//----------------------------------------------------------------------------
//  public virtual from IImageGeometry
//============================================================================
//  caller is responsible to delete the created object when no longer used 
//============================================================================
template <typename Pixel>
boost::shared_ptr<AbstractImage> ImageGeometryImpl<Pixel>::CreateInserted(
    const AbstractImage& iImage,
    const AbstractImage& iInserted,
    int32 iX, int32 iY,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  const ImageImpl<Pixel>& inserted = elxDowncast<Pixel>(iInserted);
  return CreateInserted(image, inserted, iX, iY, iNotifier);

} // CreateInserted


//----------------------------------------------------------------------------
//  Insert : 
//----------------------------------------------------------------------------
//  public virtual from IImageGeometry
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageGeometryImpl<Pixel>::Insert(
    AbstractImage& ioImage,
    const AbstractImage& iInserted, 
    int32 iX, int32 iY,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  const ImageImpl<Pixel>& inserted = elxDowncast<Pixel>(iInserted);
  return Insert(image, inserted, iX, iY, iNotifier);

} // Insert

} // namespace Image
} // namespace eLynx

#endif // __Geometry_Insert_hpp__
