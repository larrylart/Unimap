//============================================================================
//  Geometry/Shift.hpp                                 Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Shift_hpp__
#define __Geometry_Shift_hpp__

namespace eLynx {
namespace Image {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                    static specialized services
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

//----------------------------------------------------------------------------
//  CreateShifted : Create a shifted image by full pixels.
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : const ImageImpl<Pixel>& iImage
//  Out : const ImageImpl<Pixel> *
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateShifted(
    const ImageImpl<Pixel>& iImage,
    int32 iHorizontal, int32 iVertical,
    ProgressNotifier& iNotifier)
{
  if (!iImage.IsValid()) return boost::shared_ptr< ImageImpl<Pixel> >();
  
  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();

  // create the new image
  boost::shared_ptr< ImageImpl<Pixel> > spImage( new ImageImpl<Pixel>(w,h) );
  if (!elxUseable(spImage.get())) 
    return boost::shared_ptr< ImageImpl<Pixel> >();

  iHorizontal = -iHorizontal;
  iVertical = -iVertical;

  while (iHorizontal < 0) iHorizontal += w;
  iHorizontal %= w;

  while (iVertical < 0) iVertical += h;
  iVertical %= h;

  const Pixel * prSrc = iImage.GetPixel();
  Pixel * prDst = spImage->GetPixel();

  const uint32 w1 = uint32(iHorizontal);
  const uint32 w2 = w - w1;
  uint32 h2;
  const Pixel * prSrcLine;
  for (uint32 y=0; y<h; y++)
  {
    h2 = y + iVertical;
    if (h2 >= h) h2 -= h;
    prSrcLine = prSrc + h2*w;
    
    // process a line
    ::memcpy(prDst, prSrcLine+w1, w2*sizeof(Pixel));
    prDst += w2;
    ::memcpy(prDst, prSrcLine, w1*sizeof(Pixel));
    prDst += w1;
  }

  return spImage;

} // CreateShifted


//----------------------------------------------------------------------------
//  CreateShifted : Create a shifted image by decimal pixel parts.
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr< ImageImpl<Pixel> > ImageGeometryImpl<Pixel>::CreateShifted(
    const ImageImpl<Pixel>& iImage,
    double iHorizontal, double iVertical,
    ProgressNotifier& iNotifier)
{
  elxFIXME;
  return boost::shared_ptr< ImageImpl<Pixel> >();

} // CreateShifted


//----------------------------------------------------------------------------
//  Shift
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Shift(
    ImageImpl<Pixel>& ioImage, 
    int32 iHorizontal, int32 iVertical,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid())
    return false;

  boost::shared_ptr< ImageImpl<Pixel> > spImage = 
    CreateShifted(ioImage, iHorizontal,iVertical, iNotifier);
  return ioImage.CopyAndForget(spImage);

} // Shift

//----------------------------------------------------------------------------
//  Shift
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Shift(
    ImageImpl<Pixel>& ioImage, 
    double iHorizontal, double iVertical,
    ProgressNotifier& iNotifier)
{
  if (!ioImage.IsValid())
    return false;

  boost::shared_ptr< ImageImpl<Pixel> > spImage = 
    CreateShifted(ioImage, iHorizontal,iVertical, iNotifier);
  return ioImage.CopyAndForget(spImage);

} // Shift

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//            virtual from IImageGeometry implementation
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//----------------------------------------------------------------------------
//  CreateShifted
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr<AbstractImage> ImageGeometryImpl<Pixel>::CreateShifted(
    const AbstractImage& iImage,
    int32 iHorizontal, int32 iVertical,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return CreateShifted(image, iHorizontal,iVertical, iNotifier);

} // CreateShifted

//----------------------------------------------------------------------------
//  CreateShifted
//----------------------------------------------------------------------------
template <typename Pixel>
boost::shared_ptr<AbstractImage> ImageGeometryImpl<Pixel>::CreateShifted(
    const AbstractImage& iImage,
    double iHorizontal, double iVertical,
    ProgressNotifier& iNotifier) const
{
  const ImageImpl<Pixel>& image = elxDowncast<Pixel>(iImage);
  return CreateShifted(image, iHorizontal,iVertical, iNotifier);

} // CreateShifted

//----------------------------------------------------------------------------
//  Shift
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Shift(
    AbstractImage& ioImage,
    int32 iHorizontal, int32 iVertical,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Shift(image, iHorizontal,iVertical, iNotifier);

} // Shift

//----------------------------------------------------------------------------
//  Shift
//----------------------------------------------------------------------------
template <typename Pixel>
bool ImageGeometryImpl<Pixel>::Shift(
    AbstractImage& ioImage,
    double iHorizontal, double iVertical,
    ProgressNotifier& iNotifier) const
{
  ImageImpl<Pixel>& image = elxDowncast<Pixel>(ioImage);
  return Shift(image, iHorizontal,iVertical);

} // Shift

} // namespace Image
} // namespace eLynx

#endif // __Geometry_Shift_hpp__
