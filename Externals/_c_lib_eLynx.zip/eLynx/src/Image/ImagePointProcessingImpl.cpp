//============================================================================
//  ImagePointProcessingImpl.cpp                       Image.Component package
//============================================================================
//  Usage : image point to point processing interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/ImagePointProcessingImpl.h>
#include <elx/math/Ramp.h>

#include "PointProcessing/Brightness.hpp"
#include "PointProcessing/Contrast.hpp"
#include "PointProcessing/Gamma.hpp"
#include "PointProcessing/BCG.hpp"
#include "PointProcessing/Balance.hpp"
#include "PointProcessing/Midtone.hpp"
#include "PointProcessing/Sigmoid.hpp"
#include "PointProcessing/Posterize.hpp"
#include "PointProcessing/Solarize.hpp"
#include "PointProcessing/Binarize.hpp"
#include "PointProcessing/Blend.hpp"
#include "PointProcessing/HueSaturation.hpp"
#include "PointProcessing/Colorize.hpp"
#include "PointProcessing/Desaturate.hpp"
#include "PointProcessing/ShadowHighlight.hpp"

namespace eLynx {
namespace Image {

IImagePointProcessing::~IImagePointProcessing() {}

//----------------------------------------------------------------------------
//  explicit instantiation of all image types
//----------------------------------------------------------------------------
elxINSTANTIATE_CLASS_FOR_ALL_IMAGE_TYPES( ImagePointProcessingImpl );

} // namespace Image
} // namespace eLynx
