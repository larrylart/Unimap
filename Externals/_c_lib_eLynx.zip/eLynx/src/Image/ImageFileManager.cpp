//============================================================================
//  ImageFileManager.cpp                               Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreCore.h>
#include <elx/core/CoreMacros.h>
#include <elx/core/CoreFile.h>
#include <elx/core/IPluginPackage.h>

#include <elx/image/ImageFileManager.h>
#include <elx/image/ImageVariant.h>

//
// File extensions used for bitmap images and raster graphics files:
//
// http://www.file-extensions.org/filetype/extension/name/bitmap-image-files
//
// 032    RAW image file 
// 24b    Bitmap graphics (24-bit data) 
// 73i    TI bitmap file 
// 82i    TI bitmap file 
// 83i    TI bitmap file 
// 854    Bitmap image file 
// 85i    TI bitmap file 
// 86i    TI bitmap file 
// 89i    TI bitmap file 
// 92i    TI bitmap file 
// 9xi    Texas Instruments TI-92 Plus bitmap file 
// acr    Bitmap graphics 
// acr    Dicom medicine image file format 
// adc    Bitmap graphics (16 colors) 
// alias  Alias image file 
// als    Alias fmage file 
// apng   Animated portable network graphics 
// apt    APT encoded bitmap file 
// apu    Canon RAW file 
// arf    Flexible image transport system bitmap 
// arw    Sony Digital Camera Raw Image File 
// atk    Andrew Toolkit raster object file 
// att    AT&T Group 4 bitmap graphics 
// avs    Bitmap image format 
// avs    Stardent AVS X image file 
// b&w    Bitmap image (atari - mac) 
// bdf    X11 Bitmap Distribution Format 
// bfl    BFLI image format 
// bfli   BFLI image format 
// bga    OS/2 graphic array 
// bif    byLight image format 
// bif    Image Capture board bitmap image 
// bip    ArcView image file (band interleaved by pixel) 
// bit    X11 bitmap image 
// blz    Bitmap graphic file 
// bm     X Windows system bitmap image 
// bmf    Corel Flow image format 
// bml    BPM Studio skin bitmap 
// bmp    Standard Windows Bitmap image (also OS/2) 
// bmx    BMXdesign extended bitmap graphic file 
// bob    BOB Raytracer bitmap image 
// bpp    BatchPhoto project file 
// bpt    CorelDraw bitmap file 
// bpx    Truevision Targa bitmap image 
// btn    JustButtons animated bitmap image format 
// btpc   BTPC encoded bitmap file 
// bw     Silicon Graphics image file 
// bwc    BeadWizard color palette 
// c4     JEDMICS bitmap image 
// cal    CALS Raster Goup 1 image format 
// cal    CALS Raster Group 4 fax compressed bitmap 
// cam    Casio QV digital CAMera image 
// cbm    XLib compiled bitmap picture 
// cbm    Fuzzy bitmap image format 
// cdr    Corel Draw bitmap (preview) image format 
// ce     Digital Vision IFF bitmap file 
// ce1    Computer Eyes Raw image format 
// ce2    Computer Eyes Raw image format 
// cel    Autodesk Animator, 3D Studio cel bitmap animation 
// cel    Lumena CEL bitmap image 
// cfp    bitmap native format for CoverFactory 
// cg4    CALS Group IV bitmap graphics file 
// cin    Kodak Cineon image format 
// cin    Digital Moving Picture Exchange Bitmap 
// clp    Bitmap image file 
// cmp    Leadview bitmap file 
// cmu    CMU Window Manager bitmap image  
// cmyk   Raw cyan, magenta, yellow and black bytes bitmap image 
// cmyka  Raw cyan, magenta, yellow, black, and alpha samples image 
// cpd    PhotoDefiner lossless compressed photo image 
// cpi    Bitmap image (Colorlab processed image) 
// cr     Iris CT format bitmap image 
// cr2    Canon digital camera RAW image format version 2.0 
// crf    Bitmap image 
// crw    Canon digital camera RAW image format 
// ct     IRIS CT image format 
// ct     SciTex continuous Tone bitmap image (32bit CMYK) 
// ctf    TIFF compressed file 
// cube   Bitmap image file 
// cut    Dr Halo bitmap picture 
// dat    Mitsubishi DJ-1000 and Photorun native format 
// dbx    DATABEAM bitmap image 
// dc3    Medicine image file format 
// dcm    Dicom medicine image file format 
// dcr    RIF picture 
// dcr    Kodak Digital Camera Raw Image Format 
// dcs    QuarkXPress bitmap graphic  
// dct    DALiM LiTHO continuous tone bitmap file 
// dcx    Zsoft PC Publisher's Paintbrush image (multi-pcx file) 
// ddb    Device dependent bitmap graphics file 
// dds    Direct Draw surface 
// dib    Device-Independent bitmap graphic 
// dic    Medicine image file format 
// dicm   Medicine image file format 
// dicom  Medicine image file format 
// dip    Windows bitmap format 
// djvu   DjVu file bitmap image 
// dng    Digital Negative 
// dpx    Kodak Cineon image format 
// dpx    Digital Moving Picture Exchange bitmap file 
// drs    BMP bitmap file 
// dsf    DriveSurf picture 
// dt2    Microsoft Live Messenger file 
// dx     Auto-trol raster image 
// ecw    Enhanced Compressed Wavelet image format 
// eidi   Bitmap image (Electric Image EIDI file) 
// emf    Enhanced Windows Metafile picture 
// emz    Microsoft Windows enhanced compressed metafile 
// eps    EPS Tiff preview 
// exf    Exchangeable Image File Format 
// exr    OpenEXR Image Format 
// fac    UNIX FaceSaver bitmap image 
// face   UNIX FaceSaver bitmap image 
// fbm    Fuzzy bitmap image 
// fff    Maggi Hairstyles & Cosmetics image format 
// fido   Kodak Cineon image format 
// fif    Fractal Image Format file 
// fits   Flexible Image Transport System 
// fp     Vinal Page Vector TIFF image 
// fpx    Kodak FlashPiX bitmap image 
// fs     Bitmap image (Usenix FaceServer file) 
// gbm    MapServer bitmap store file 
// gg     Koala Paint compressed image format 
// gif    Graphics interchange file format 
// gif87  Gif(87) file 
// gif89a Gif 89a image file 
// giff   CompuServe bitmap image (Graphics Interchange Format) 
// gif_   Graphics Interchange Format - Mac File Type 
// gis    Erdas gray-scale bitmap image 
// gm     Autologic bitmap image 
// gm2    Autologic bitmap image  
// gm4    Autologic bitmap image 
// goo    Kai's Power Goo picture file 
// gray   Raw gray samples bitmap image 
// grb    HP-48sx GROB bitmap image 
// gro    HP-48/49 grob graphic image format 
// ham    Amiga hold and modify image 
// hdp    HD Photo 
// hpe    Canon JPEG file 
// hpi    Hemera Photo Image image format 
// hsi    Handmade Software bitmap image 
// hsi    HSI JPEG bitmap file 
// hta    Hemera thumbs 
// ica    Citrix image object content architecture file  
// icb    Truevision Targa format 
// ico    Icon file 
// idc    Core Software tech IDC file 
// idx    Header information file 
// iff    Amiga bitmap image file 
// iff    Bitmap image 
// iff    Electronic Arts bitmap image  
// iff    DESR VFF greyscale bitmap image 
// iff    Autodesk Maya image format 
// ige    Erdas imagine Large Raster Spill file 
// ilbm   Amiga Interleaved bitmap format 
// ilbm   Deluxe Paint graphic file 
// im     Sun raster grey bitmap graphics file 
// im32   Sun 32bit raster file 
// image  UNIX bitmap source 
// img    Bitmap Graphic (several programs) 
// img    ADEX Corporation bitmap graphics 
// img    ERDAS Imagine image file 
// img    Img software set bitmap  
// img    Planetary Data System image format 
// img    Radiance picture format 
// img    Bitmap graphics VDI image format 
// img    Whatnot image file 
// img    Microtek Eyestar image 
// img    VICAR graphic file 
// int    Silicon Graphics Image File Format 
// inta   Silicon Graphics Image File Format 
// ioca   IBM Image Object Content Architecture (IOCA) bitmap graphics 
// ipg    Mindjongg Format image format 
// ism    Image System (Multicolor) image format 
// iso    CALS ISO 8613 bitmap graphics file 
// itg    Intergraph format bitmap graphics 
// ivb    Truevision Targa format bitmap graphics 
// ivp    Truevision Targa bitmap image 
// iw4    DjVu image format 
// iw44   DjVu image format 
// j      JPEG/JFIF image 
// j2c    JPEG2000 image format 
// j2k    JPEG2000 code stream image 
// j6i    Ricoh Digital Camera image format 
// jap    JAlbum album file 
// jas    Bitmap graphics 
// jfif   JPEG bitmap image file format 
// jif    Jeff's Image Format image format 
// jif    JPEG/JIFF image 
// jls    JPEG-LS image format 
// jng    JPEG Network Graphic file 
// jp2    JPEG2000 image format 
// jpc    Japan Picture bitmap graphic format 
// jpc    JPEG2000 code stream image format 
// jpd    PhotoDefiner lossy compressed photo 
// jpe    JPEG Image 
// jpeg   JPEG image, picture file format 
// jpeg   Joint Photographic Experts Group 
// jpf    JPEG2000 image format 
// jpg    JPEG bitmap image file format 
// jpg    CompactDRAW e-JPG graphic file 
// jpg_t  Jpg images file 
// jpm    JPEG 2000 jpm file format 
// jpx    JPEG-2000 JP2 file format 
// jtf    JPEG Tagged Interchange Format image 
// jtf    TIFF 6.0 bitmap image JPEG compression 
// k25    Kodak DC25 digital camera file 
// kfx    Kofax Group 4 bitmap graphics 
// koa    Koala paint C64 format 
// kps    IBM KIPS bitmap image graphics 
// kqp    Konica camera file 
// lbm    Amiga Deluxe Paint bitmap  
// lbm    Bitmap image file 
// lbm    XLib linear bitmap graphic  
// ldf    LuraDocument Format image format 
// lgo    Microsoft Windows 3.0 logo driver (bitmap) 
// ljp    Lossless JPEG bitmap image 
// ln03   DEC LN03+ sixel bitmap image 
// mac    MacPaint bitmap image 
// macp   Apple Macintosh MacPaint bitmap image 
// map    Fenix map  
// mbfavs Stardent AVS X bitmap image file 
// mbfs   Stardent AVS X bitmap image file 
// mbm    EPOC multi-bitmap file 
// mf     Metafont text file 
// mfw    Mamiya camera RAW file 
// mgf    MalieGF bitmap 
// mgr    MGR bitmap image 
// miff   Magick image file format 
// mng    Multiple Network Graphics animation 
// mng    Multiple Network Graphics bitmap image 
// mos    Mamiya Digital Camera Raw Image File 
// mp     Monochrome picture TIFF bitmap 
// mpc    Magick Persistent Cache image file format 
// mpnt   MacPaint image format 
// mrw    Minolta Dimage Raw Image File 
// msp    Microsoft Paint bitmap picture 
// nef    Nikon Digital SLR camera RAW image file 
// ngg    Nokia Group Graphics image format 
// nif    NIFF Navy Image File Format (bitmap) graphics interchange format 
// niff   Bitmap image (Navy Interchange File Format) 
// nlm    Nokia Logo file image format 
// nol    Nokia Operator Logo image format 
// nrf    Neutral raster file bitmap image 
// nth    ImageMagick VisualMagick jbig file 
// otb    Nokia OTA bitmap file 
// p7     XV Visual Schnauzer bitmap format 
// pac    Photo-CD multi-resolution image file 
// paint  Apple Macintosh MacPaint bitmap file 
// pam    Portable arbitrary map 
// pam    Common 2-dimensional bitmap format 
// pattern PhotoLine 5 Default File 
// pbf    Portable bitmap format file  
// pbm    Portable Bitmap file 
// pbm    UNIX Portable bitmap graphic 
// pbm    Xlib bitmap graphics 
// pbmv   Portable bitmap file 
// pc1    Atari Degas image 
// pc2    Atari Degas image 
// pc3    Atari Degas bitmap image 
// pcc    ZSoft PC Paintbrush format 
// pcd    Kodak Picture CD multiresolution image 
// pcd    Photo CD format 
// pct    NIST ihdr image 
// pct    Apple Macintosh QuickDraw/PICT bitmap graphics format 
// pct    PC Paint bitmap file 
// pcx    PC Paintbrush bitmap graphics 
// pdb    MonkeyCard image format 
// pdd    Corel Paint Shop Pro bitmap graphics 
// pdf    ED-Scan graphics file 
// pef    Pentax Digital Camera Raw Image Format 
// pfi    Panorama Factory bitmap image format 
// pfm    Portable bitmap file 
// pfn    Portable Bitmap File 
// pgm    Portable graymap file format 
// pgx    Portable graphics format 
// pi1    Atari Degas bitmap image 
// pi2    Atari Degas image 
// pi3    Atari Degas image 
// pi4    Atari Degas image file 
// pi5    Atari Degas image file 
// pi6    Atari Degas image file 
// pic    Autodesk Animator PIC/CEL file 
// pic    General picture extension 
// pic    IBM Storyboard bitmap file 
// pic    Pixar PIC file 
// pic    Psion Series 3 image format 
// pic    Radiance image file 
// picio  PIXAR picture file 
// pict   Macintosh PICT image 
// pict   Bitmap graphics file format 
// pict2  Apple Macintosh QuickDraw/PICT bitmap graphics format 
// pix    Inset Systems raster & vector format 
// pix    Truevision Targa bitmap image 
// pix    PABX background bitmap  
// pixar  PIXAR picture file 
// pjpeg  JPEG image 
// plt    BioWare Infinity game engine bitmap graphic 
// pm     Presentation Manager bitmap graphics file 
// pm     X Window PixelMap bitmap graphics 
// pnf    Portable Network Graphics bitmap graphics 
// png    Portable (Public) Network Graphic 
// png24  Portable Network Graphics 
// png32  Portable Network Graphics 
// png8   Portable Network Graphics 
// pnm    Portable anymap bitmap graphic file 
// pnt    Apple MacPaint format graphic file 
// pntg   Apple Macintosh MacPaint bitmap graphics 
// pp4    Micrografix Picture Publisher bitmap graphics 
// pp5    Micrografx Picture Publisher bitmap file 
// ppm    Portable pixelmap graphic 
// pps    Paint Shop Pro image 
// pr     Sun icon file 
// pre    CMYK bitmap image (Stork format) 
// prf    Fastgraph bitmap graphics 
// prn    Calcomp Raster bitmap graphics 
// psd    Adobe Photoshop graphics 
// pse    IBM Printer Page Segment bitmap graphics 
// ptif   Pyramid encoded TIFF bitmap graphics 
// ptx    Printronix bitmap graphic file 
// ptx    Pentax RAW bitmap graphic 
// pxm    Pixel Magician graphic bitmap file 
// pzl    Unix Puzzle bitmap graphics 
// q0     Japanese Q0 bitmap image 
// qdv    Random Dot QDV bitmap image 
// qrt    Qrt Ray-Tracer ray-traced bitmap image 
// qtl    YUV SECAM or PAL image 
// raf    Fuji CCD-RAW graphic file 
// ras    Sun raster bitmap image 
// rast   Sun Raster bitmap image 
// raw    Digital Camera Image Format (Panasonic) 
// raw    HSI temporary raw bitmap image format 
// raw    Generally a digital camera's image raw file format 
// rdb    Wavelet image recording 
// rdi    Device independent bitmap file 
// rf     Sun bitmap image (raster file) 
// rg     Bitmap image 
// rgb    SGI RGB bitmap file 
// rgb    Japanese Q0 bitmap image 
// rgba   Silicon Graphics Image File Format 
// rif    Resource Interchange File Format bitmap image 
// rif    Fractal Painter bitmap file 
// riff   Resource Interchange File Format bitmap image 
// rix    ColoRIX bitmap image 
// rl2    Nokia ST (Star Torrent) mobile phones series picture image 
// rl4    Microsoft Windows bitmap image 
// rl8    Microsoft Windows bitmap image 
// rla    Alias/Wavefront bitmap image 
// rlb    Alias/Wavefront bitmap image 
// rle    Bitmap graphics - 4bit or 8bit ADEX file 
// rle    Run Length Encoded bitmap image 
// rle    Raster bitmap image 
// rpbm   Portable Bitmap image format 
// rpgm   Portable greyscale image 
// rpnm   Portable Image image format 
// rppm   Portable Image image format 
// rs     Sun Raster bitmap image format 
// rsb    Red Storm bitmap file 
// rw2    Panasonic Lumix RAW image file 
// sc2    Msx 2 screen image format 
// sc?    ColoRix bitmap image 
// scc    Microsoft eXtended home computer bitmap image (MSX) 
// scd    Matrix/Imapro/Agfa SCODL film recorder bitmap image 
// sci    ColoRIX bitmap image 
// scr    Sun Raster bitmap image format 
// scr    bitmap file 
// sct    Scitex CT bitmap image file 
// scx    ColoRIX bitmap image 
// sd2    Dali Raw image 
// sdpx   Kodak Cineon image format 
// sdw    MrSID header file (ESRI picture file) 
// sep    Tagged Image File Format (TIFF) bitmap image 
// seq    ATARI STAD image format 
// sev    SevenUp picture file 
// sfc    Motic Images Plus image file 
// sfw    Seattle Film Works graphics 
// sid    LizardTech MrSID image file 
// sim    Aurora image format 
// sir    Bitmap image (Solitaire file) 
// snx    Second Nature screensaver image 
// spc    Atari compressed Spectrum bitmap file 
// spf    Still Picture Interchange File Format 
// sprite Acorn - Bitmap file 
// sps    Atari Spectrum 512 smooshed bitmap image 
// spu    Atari Spectrum bitmap image 
// sr     Sun raster bitmap graphics 
// sr2    Sony Digital Camera Raw Image File 
// srf    Sun raster file 
// srf    Sony Digital Camera Raw Image File 
// srs    Sun raster file 
// ss     Splash bitmap graphics 
// sun    Sun raster bitmap image  
// suniff Bitmap image (Sun TAAC Image File Format) 
// syn    Bitmap image (Synthetic Universe image file) 
// syn    SDSC image tool file 
// synu   Bitmap image (SDSC Synu image file) 
// synu   Synthetic Universe image format 
// sys    Microsoft Windows bitmap image format 
// taac   Sun TAAC bitmap image 
// tdi    Alias Wavefront image 
// tex    Corel Paint Shop Pro texture image format 
// tga    Truevision TarGA bitmap image  
// thm    Thumbnail bitmap image 
// thm    Olympus digital image thumbnail 
// thm    Canon G3 digital camera thumbnail 
// tif    Aldus Tagged Image File Format (TIFF) bitmap image 
// tif    BigTIFF image file 
// tiff   Aldus Tagged Image File Format (TIFF) bitmap image 
// tiff   Tagged Image File Format 
// tim    Sony PlayStation bitmap image 
// tim    Tagged Image file format 
// tn1    Tiny image format 
// tn2    Tiny image format 
// tn3    Tiny image format 
// tny    TiNY bitmap image 
// tpic   TrueVision TARGA 
// u      Subsampled raw YUV bitmap image 
// udi    Corel Graphics draw scripts textures bitmap file 
// ufo    Ulead PhotoImpact object file 
// ufp    Ulead photo project file 
// uil    X-Motif UIL icon file Bitmap image 
// upf    Universal Picture Format bitmap image 
// upf    Nokia Phone digital photo 
// urt    Utah Run-Length encoded bitmap image file 
// v      Subsampled raw YUV bitmap image 
// vbm    V IDE bitmap file 
// vbm    Video bitmap file 
// vda    Truevision Targa bitmap image 
// vda    Video Display Adapter image format 
// vdi    Digital Research GEM VDI bitmap image 
// vff    DESR VFF greyscale bitmap image 
// vff    Sun TAAC bitmap image file 
// vga    OS/2 bitmap image 
// vga    Microsoft Windows bitmap image 
// vi     Jovian Logic VI bitmap image 
// vic    Vicar graphics file 
// vid    YUV12C M-Motion Frame Buffer file 
// vif    Verity 1bit CCITT Group 4 bitmap image 
// vif    Khoros Visualization bitmap image 
// viff   Khoros Visualization bitmap image 
// vit    VITec scanner raster format 
// vst    Vista Truevision Targa bitmap image 
// wap    Wireless bitmap (level 0) image format 
// wbm    Wireless Bitmap image format 
// wbmp   Wireless Bitmap image format 
// wdp    Windows Media HD Photo 
// wi     Wavelet image file 
// wic    J Wavelet Image Codec image format 
// win    Truevision Targa bitmap image 
// wlm    CompW image format 
// wmp    Microsoft Windows Media HD Photo file 
// x      Stardent AVS X bitmap image 
// x-png  Portable (Public) Network Graphic bitmap file 
// x11    Bitmap image (X Windows system window dump) 
// x3f    Sigma Camera RAW Picture File 
// xbm    X Windows system bitmap image 
// xcf    Gimp bitmap image format 
// xim    X11 Xim Toolkit bitmap file 
// xjt    Compressed GIMP image file 
// xpm    Image file 
// xv     Khoros Visualization bitmap image 
// xwd    X Windows window screen dump or bitmap 
// y      Subsampled raw YUV bitmap image 
// yuv    YUV 16Bits image format 
// zgm    Zenographics bitmap image file 
// zif    Zooming Interface Format 
// zxp    ZX-Paintbrush document 

#define IMAGE_FILE_PLUGIN_EXT "iio"

/// UUID of IImageFilePlugin {97564967-5E7E-4676-B021-75DA9654A6AE}
const eLynx::UUID UUID_IImageFilePlugin( 
  0x97564967, 0x5e7e, 0x4676, 0xb0, 0x21, 0x75, 0xda, 0x96, 0x54, 0xa6, 0xae);

namespace eLynx {
namespace Image {

ImageFileManager the_ImageFileManager;

IImageFileFormat::~IImageFileFormat() {}

//----------------------------------------------------------------------------
//  constructor
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : -
//  Out : -
//----------------------------------------------------------------------------
ImageFileManager::ImageFileManager() :
  _manager(UUID_IImageFilePlugin),
  _nInputFileFormat(0),
  _nOutputFileFormat(0)
{
  _inExts.clear();
  _outExts.clear();

} // constructor


//----------------------------------------------------------------------------
//  destructor
//----------------------------------------------------------------------------
//  public virtual from ImageFileManager
//----------------------------------------------------------------------------
//  In  : -
//  Out : -
//----------------------------------------------------------------------------
ImageFileManager::~ImageFileManager()
{
  Unregister();

} // destructor


//----------------------------------------------------------------------------
//  Register
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : iprPath :
//  Out : bool
//----------------------------------------------------------------------------
bool ImageFileManager::Register(const char * iprPath)
{
  // load all package
  _manager.Register(iprPath, IMAGE_FILE_PLUGIN_EXT);
  const size_t nPlugin = _manager.GetPluginCount();

  for (size_t i=0; i<nPlugin; i++)
  {
    const IPlugin * prPlugin = _manager.GetPlugin(i);
    IImageFilePlugin * prIFFPlugin = (IImageFilePlugin*)prPlugin;
    elxASSERT(NULL != prIFFPlugin);

    Register(*prIFFPlugin);
  }

  // if no plugin found, think about error
  if (0 == GetPluginCount())
    return false;

  // if plugins found but no// to import & export, think about error
  if ((0 == GetInputExtCount()) && (0 == GetOutputExtCount()))
    return false;

  // we can at least save or write a file
  return true;

} // Register


//----------------------------------------------------------------------------
//  Unregister
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const IPluginPackage& iPackage
//  Out : -
//----------------------------------------------------------------------------
void ImageFileManager::Unregister(const IPluginPackage& iPackage)
{
  // unregister all plugins from package
  const size_t nPlugin = iPackage.GetPluginCount();
  for (size_t i=0; i<nPlugin; i++)
  {
    const IPlugin * prPlugin = iPackage.GetPlugin(i);
    IImageFilePlugin * prIFFPlugin = (IImageFilePlugin*)prPlugin;
    elxASSERT(NULL != prIFFPlugin);
    Unregister(*prIFFPlugin);
  }

} // Unregister


//----------------------------------------------------------------------------
//  Register
//----------------------------------------------------------------------------
//  protected
//----------------------------------------------------------------------------
//  In  : IImageFilePlugin& iPlugin
//  Out : -
//----------------------------------------------------------------------------
void ImageFileManager::Register(IImageFilePlugin& iPlugin)
{
  size_t i;

  // register all new input extensions
  const size_t nInExt = iPlugin.GetInputExtCount();
  for (i=0; i<nInExt; i++)
  {
    const char * prExt = iPlugin.GetInputExt(i);
    if (NULL != prExt)
    {
      MapExt::const_iterator it = _inExts.find(prExt);
      if (it == _inExts.end())
      {
        // new, register
        _inExts[prExt] = &iPlugin;
      }
    }
  }

  // register all new output extensions
  const size_t nOutExt = iPlugin.GetOutputExtCount();
  for (i=0; i<nOutExt; i++)
  {
    const char * prExt = iPlugin.GetOutputExt(i);
    if (NULL != prExt)
    {
      MapExt::const_iterator it = _outExts.find(prExt);
      if (it == _outExts.end())
      {
        // new, register
        _outExts[prExt] = &iPlugin;
      }
    }
  }

} // Register


//----------------------------------------------------------------------------
//  Unregister a plugin
//----------------------------------------------------------------------------
//  protected
//----------------------------------------------------------------------------
//  In  : const IImageFilePlugin& iPlugin
//  Out : -
//----------------------------------------------------------------------------
void ImageFileManager::Unregister(const IImageFilePlugin& iPlugin)
{
  size_t i;

  // unregister all input extensions
  const size_t nInExt = iPlugin.GetInputExtCount();
  for (i=0; i<nInExt; i++)
  {
    const char * prExt = iPlugin.GetInputExt(i);
    UnregisterInExt(prExt);
  }

  // register all new output extensions
  const size_t nOutExt = iPlugin.GetOutputExtCount();
  for (i=0; i<nOutExt; i++)
  {
    const char * prExt = iPlugin.GetOutputExt(i);
    UnregisterOutExt(prExt);
  }

  _manager.Unregister(&iPlugin);

} // Unregister



//----------------------------------------------------------------------------
//  UnregisterInExt
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const char * iprExt
//  Out : bool true if succeeded, false otherwise.
//----------------------------------------------------------------------------
bool ImageFileManager::UnregisterInExt(const char * iprExt)
{
  if (NULL == iprExt)
    return false;

  // ext only in lower case
  char lowerExt[elxPATH_MAX];
  ::strcpy(lowerExt, iprExt);
  elxToLower(lowerExt); 

  MapExt::iterator it = _inExts.find(lowerExt);
  if (it == _inExts.end())
    return false;

  // found, unregister
  _inExts.erase(it);
  return true;

} // UnregisterInExt


//----------------------------------------------------------------------------
//  UnregisterOutExt
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const char * iprExt
//  Out : bool true if succeeded, false otherwise.
//----------------------------------------------------------------------------
bool ImageFileManager::UnregisterOutExt(const char * iprExt)
{
  if (NULL == iprExt)
    return false;

  // ext only in lower case
  char lowerExt[elxPATH_MAX];
  ::strcpy(lowerExt, iprExt);
  elxToLower(lowerExt); 

  MapExt::iterator it = _outExts.find(lowerExt);
  if (it == _outExts.end())
    return false;

  // found, unregister
  _outExts.erase(it);
  return true;

} // UnregisterOutExt


//----------------------------------------------------------------------------
//  GetInPlugin
//----------------------------------------------------------------------------
//  protected
//----------------------------------------------------------------------------
//  In  : const char * iprFilename : image filename
//  Out : The plugin that support reading of the image file.
//----------------------------------------------------------------------------
IImageFilePlugin * ImageFileManager::GetInPlugin(const char * iprFilename)
{
  if (NULL == iprFilename)
    return NULL;

  // Don't take care of extension case
  const char * prExt = elxGetFileExt(iprFilename);
  if (NULL == prExt)
    return NULL;

  // ext only in lower case
  char lowerExt[elxPATH_MAX];
  ::strcpy(lowerExt, prExt);
  elxToLower(lowerExt); 

  MapExt::const_iterator it = _inExts.find(lowerExt);
  if (it == _inExts.end())
    return NULL;

  return it->second;

} // GetInPlugin


//----------------------------------------------------------------------------
//  GetOutPlugin
//----------------------------------------------------------------------------
//  protected
//----------------------------------------------------------------------------
//  In  : const char * iprFilename : image filename
//  Out : The plugin that support to write the image.
//----------------------------------------------------------------------------
IImageFilePlugin * ImageFileManager::GetOutPlugin(const char * iprFilename)
{
  if (NULL == iprFilename)
    return NULL;

  const char * prExt = elxGetFileExt(iprFilename);
  if (NULL == prExt)
    return NULL;

  // ext only in lower case
  char lowerExt[elxPATH_MAX];
  ::strcpy(lowerExt, prExt);
  elxToLower(lowerExt); 

  MapExt::const_iterator it = _outExts.find(lowerExt);
  if (it == _outExts.end())
    return NULL;

  return it->second;

} // GetOutPlugin


//----------------------------------------------------------------------------
//  CanImport
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const char * iprFilename : image filename
//  Out : bool true if file can be created with CreateImage, false otherwise.
//----------------------------------------------------------------------------
bool ImageFileManager::CanImport(
    const char * iprFilename,
    ImageFileInfo * oprInfo,
    bool ibThumbnail)
{
  if (NULL == iprFilename)
    return false;

  // get plugin according file extension
  IImageFilePlugin * prPlugin = GetInPlugin(iprFilename);
  if (NULL == prPlugin)
    return false;

  bool bSupported = false;
  if (NULL == oprInfo)
  {
    ImageFileInfo info;
    bSupported = prPlugin->IsSupported(iprFilename, info);
  }
  else
  {
    bSupported = prPlugin->IsSupported(iprFilename, *oprInfo, ibThumbnail);
  }
  return bSupported;

} // CanImport


//----------------------------------------------------------------------------
bool ImageFileManager::Import(
    ImageVariant& oImage,
    const char * iprFilename,
    ImageFileInfo * oprInfo,
    ProgressNotifier& iNotifier)
{
  // get plugin for this file extension
  IImageFilePlugin * prPlugin = GetInPlugin(iprFilename);
  if (NULL == prPlugin)
    return false;

  // does it a valid file ?
  if (NULL == oprInfo)
  {
    ImageFileInfo info;
    if (!prPlugin->IsSupported(iprFilename, info))
      return false;

    return prPlugin->Import(oImage, iprFilename, info, iNotifier);
  }

  if (!prPlugin->IsSupported(iprFilename, *oprInfo))
    return false;

  return prPlugin->Import(oImage, iprFilename, *oprInfo, iNotifier);

} // Import


//----------------------------------------------------------------------------
//  GeneratePreview
//----------------------------------------------------------------------------
bool ImageFileManager::GeneratePreview(
    const char * iprFilenameIn,
    const char * iprFilenameOut,
    ProgressNotifier& iNotifier)
{
  // get plugin for this file extension
  IImageFilePlugin * prPlugin = GetInPlugin(iprFilenameIn);
  if (NULL == prPlugin)
    return false;

  return prPlugin->GeneratePreview(iprFilenameIn, iprFilenameOut, iNotifier);

} // GeneratePreview


//----------------------------------------------------------------------------
//  CanExport
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : ImageVariant *& iImage : the image to export
//        const char * iprFilename : the image filename
//  Out : bool
//----------------------------------------------------------------------------
bool ImageFileManager::CanExport(
    const ImageVariant& iImage,
    const char * iprFilename,
    const ImageFileOptions * iprOptions)
{
  // get plugin for this file extension
  IImageFilePlugin * prPlugin = GetOutPlugin(iprFilename);
  if (NULL == prPlugin)
    return false;

  // check that this plugin supports to Export this kind of image format
  bool bSupported = false;
  const size_t nPixelFormat = prPlugin->GetOutputImageFormatCount();
  const EPixelFormat PixelFormat = iImage.GetPixelFormat();
  for (size_t i=0; i<nPixelFormat; i++)
  {
    if (PixelFormat == prPlugin->GetOutputPixelFormat(i))
    {
      bSupported = true;
      break;
    }
  }

  return bSupported;

} // CanExport

//----------------------------------------------------------------------------
//  Export
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : ImageVariant *& iImage : the image to export
//        const char * iprFilename : the image filename
//  Out : bool
//----------------------------------------------------------------------------
bool ImageFileManager::Export(
    const ImageVariant& iImage, 
    const char * iprFilename,
    ProgressNotifier& iNotifier,
    const ImageFileOptions * iprOptions)
{
  // get plugin for this file extension
  IImageFilePlugin * prPlugin = GetOutPlugin(iprFilename);
  if (NULL == prPlugin)
    return false;

  // check that this plugin supports to Export this kind of image format
  bool bSupported = false;
  const size_t nPixelFormat = prPlugin->GetOutputImageFormatCount();
  const EPixelFormat PixelFormat = iImage.GetPixelFormat();
  for (size_t i=0; i<nPixelFormat; i++)
  {
    if (PixelFormat == prPlugin->GetOutputPixelFormat(i))
    {
      bSupported = true;
      break;
    }
  }

  if (!bSupported)
    return false;

  // if file exist, delete old
  if (elxIsFileExist(iprFilename))
    elxDeleteFile(iprFilename);

  // export image from plugin
  return prPlugin->Export(iImage, iprFilename, iNotifier, iprOptions);

} // Export


//----------------------------------------------------------------------------
//  GetInputFileFormatList
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
const char * ImageFileManager::GetInputFileFormatList(bool ibAllInOne)
{
  std::string allExts = "";
  std::string formats = "";

  size_t nFormat = 0;
  const size_t nPlugin = GetPluginCount();
  for (size_t p=0; p<nPlugin; p++)
  {
    IImageFilePlugin * prPlugin = GetPlugin(p);
    if (NULL != prPlugin)
    {
      const size_t nExt = prPlugin->GetInputExtCount();
      if (nExt > 0)
      {
        const char * prDescription = prPlugin->GetDescription(PDI_LongDescription);
        if (NULL != prDescription)
        {
          // build extension list
          std::string ext = "";
          for (size_t e=0; e<nExt; e++)
          {
            const char * prExt = prPlugin->GetInputExt(e);
            if (NULL != prExt)
            {
              if (0 != e)
                ext += ";";

              ext += "*." + std::string(prExt);
            }
          }

          if (0 != nFormat)
          {
            formats += "|";
            allExts += ";";
          }
          nFormat++;
          formats += std::string(prDescription) + " (" + ext + ")|" + ext;
          allExts += ext;
        }
      }
    }
  }

  if (ibAllInOne)
  {
    // add all supported extension as first choice
    formats = "Image files (" + allExts + ")|" + allExts + "|" + formats;
  }
  _inFormatList = formats;
  return _inFormatList.c_str();

} // GetInputFileFormatList


//----------------------------------------------------------------------------
//  GetOutputFileFormatList
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
const char * ImageFileManager::GetOutputFileFormatList(bool ibAllInOne)
{
  std::string allExts = "";
  std::string formats = "";

  size_t nFormat = 0;
  const size_t nPlugin = GetPluginCount();
  for (size_t p=0; p<nPlugin; p++)
  {
    IImageFilePlugin * prPlugin = GetPlugin(p);
    if (NULL != prPlugin)
    {
      const size_t nExt = prPlugin->GetOutputExtCount();
      if (nExt > 0)
      {
        const char * prDescription = prPlugin->GetDescription(PDI_LongDescription);
        if (NULL != prDescription)
        {
          // build extension list
          std::string ext = "";
          for (size_t e=0; e<nExt; e++)
          {
            const char * prExt = prPlugin->GetOutputExt(e);
            if (NULL != prExt)
            {
              if (0 != e)
                ext += ";";

              ext += "*." + std::string(prExt);
            }
          }

          if (0 != nFormat)
          {
            formats += "|";
            allExts += ";";
          }
          nFormat++;
          formats += std::string(prDescription) + " (" + ext + ")|" + ext;
          allExts += ext;
        }
      }
    }
  }

  if (ibAllInOne)
  {
    // add all supported extension as first choice
    formats = "Image files (" + allExts + ")|" + allExts + "|" + formats;
  }
  _outFormatList = formats;
  return _outFormatList.c_str();

} // GetOutputFileFormatList

//----------------------------------------------------------------------------
//  GetOutputFileFormatList
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
const char * ImageFileManager::GetSupportedOutputFileFormatList(
    const ImageVariant& iImage,
    bool ibAllInOne)
{
  if (!iImage.IsValid())
    return NULL;

  const EPixelFormat pf = iImage.GetPixelFormat();
  std::string allExts = "";
  std::string formats = "";

  size_t nFormat = 0;
  const size_t nPlugin = GetPluginCount();
  for (size_t p=0; p<nPlugin; p++)
  {
    IImageFilePlugin * prPlugin = GetPlugin(p);
    if (NULL != prPlugin)
    {
      const size_t nPixelFormat = prPlugin->GetOutputImageFormatCount();
      for (size_t f=0; f<nPixelFormat; f++)
      {
        if (pf == prPlugin->GetOutputPixelFormat(f))
        {
          // found one to add to the list
          const size_t nExt = prPlugin->GetOutputExtCount();
          if (nExt > 0)
          {
            const char * prDescription = prPlugin->GetDescription(PDI_LongDescription);
            if (NULL != prDescription)
            {
              // build extension list
              std::string ext = "";
              for (size_t e=0; e<nExt; e++)
              {
                const char * prExt = prPlugin->GetOutputExt(e);
                if (NULL != prExt)
                {
                  if (0 != e)
                    ext += ";";

                  ext += "*." + std::string(prExt);
                }
              }

              if (0 != nFormat)
              {
                formats += "|";
                allExts += ";";
              }
              nFormat++;
              formats += std::string(prDescription) + " (" + ext + ")|" + ext;
              allExts += ext;
            }
          }
        }
      }
    }
  }

  // add all supported extension as first choice
  if (ibAllInOne)
    formats = "Image files (" + allExts + ")|" + allExts + "|" + formats;

  _outFormatList = formats;
  return _outFormatList.c_str();

} // GetSupportedOutputFileFormatList


//----------------------------------------------------------------------------
bool ImageFileManager::IsEmpty() const
{
  return _manager.IsEmpty();
}

//----------------------------------------------------------------------------
size_t ImageFileManager::GetPackageCount() const
{
  return _manager.GetPackageCount();
}

//----------------------------------------------------------------------------
size_t ImageFileManager::GetPluginCount() const
{
  return _manager.GetPluginCount();
}

//----------------------------------------------------------------------------
size_t ImageFileManager::GetInputExtCount() const
{
  return _inExts.size();
}

//----------------------------------------------------------------------------
size_t ImageFileManager::GetOutputExtCount() const
{
  return _outExts.size();
}

//----------------------------------------------------------------------------
IImageFilePlugin * ImageFileManager::GetPlugin(const UUID& iClass)
{
   return (IImageFilePlugin*)_manager.GetPlugin(iClass);
}

//----------------------------------------------------------------------------
IImageFilePlugin * ImageFileManager::GetPlugin(const char * iprName) 
{
  return (IImageFilePlugin*)_manager.GetPlugin(iprName);
}

//----------------------------------------------------------------------------
IImageFilePlugin * ImageFileManager::GetPlugin(size_t iIndex) const
{
  return (IImageFilePlugin*)_manager.GetPlugin(iIndex);
}

//----------------------------------------------------------------------------
void ImageFileManager::Unregister()
{
  _inExts.clear();
  _outExts.clear();
  _manager.Unregister();
}

//----------------------------------------------------------------------------
bool ImageFileManager::UnregisterExt(const char * iprExt)
{
  const bool bIn = UnregisterInExt(iprExt);
  const bool bOut = UnregisterOutExt(iprExt);
  return (bIn && bOut);
}


//----------------------------------------------------------------------------
void ImageFileManager::UnregisterPackage(const char * iprFilename)
{
  const IPluginPackage * prPackage = _manager.GetPackageFromFilename(iprFilename);
  Unregister(*prPackage);

} // UnregisterPackage

//----------------------------------------------------------------------------
void ImageFileManager::UnregisterPackage(const UUID& iUUID)
{
  const IPluginPackage * prPackage = _manager.GetPackageFromPackageID(iUUID);
  Unregister(*prPackage);

} // UnregisterPackage

//----------------------------------------------------------------------------
void ImageFileManager::UnregisterPlugin(const char * iprName)
{
  const IPlugin * prPlugin = _manager.GetPlugin(iprName);
  IImageFilePlugin * prIFFPlugin = (IImageFilePlugin*)prPlugin;
  Unregister(*prIFFPlugin);

} // UnregisterPlugin

//----------------------------------------------------------------------------
void ImageFileManager::UnregisterPlugin(const UUID& iUUID)
{
  const IPlugin * prPlugin = _manager.GetPlugin(iUUID);
  IImageFilePlugin * prIFFPlugin = (IImageFilePlugin*)prPlugin;
  Unregister(*prIFFPlugin);

} // UnregisterPlugin

} // namespace Image
} // namespace eLynx
