//============================================================================
//  ImageGeometryImpl.cpp                              Image.Component package
//============================================================================
//  Usage : image geometry class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <string>
#include <map>

#include <elx/image/ImageGeometryImpl.h>
#include <elx/image/AbstractImageManager.h> // elxCreateImage with AbstractImage

#include "Geometry/Crop.hpp"
#include "Geometry/Binning.hpp"
#include "Geometry/Flip.hpp"
#include "Geometry/Resize.hpp"
#include "Geometry/Rotate.hpp"
#include "Geometry/RotateFree.hpp"
#include "Geometry/Zoom.hpp"
#include "Geometry/AddBorder.hpp"
#include "Geometry/Shift.hpp"
#include "Geometry/Insert.hpp"
#include "Geometry/Resample.hpp"
#include "Geometry/Expand.hpp"

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EBinningMethod iBinningMethod)
{
  static const char * ms_lutDsc[] =
  {
    "Average", "Median", "Sum ", "Min", "Max"
  };
  return ms_lutDsc[iBinningMethod];
} // elxToString

//----------------------------------------------------------------------------
//  elxToEBinningMethod
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EBinningMethod elxToEBinningMethod(const char * iprBinningMethodr)
{
  static std::map<std::string, EBinningMethod> ms_lut;
  if (ms_lut.empty())
  {
    ms_lut.insert(make_pair(std::string("BM_Mean"),BM_Mean));
    ms_lut.insert(make_pair(std::string("BM_Median"),BM_Median));
    ms_lut.insert(make_pair(std::string("BM_Sum"),BM_Sum));
    ms_lut.insert(make_pair(std::string("BM_Min"),BM_Min));
    ms_lut.insert(make_pair(std::string("BM_Max"),BM_Max));
  }
  return ms_lut[std::string(iprBinningMethodr)];
} // elxToEBinningMethod

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EFlipPlane iFlipPlane)
{
  static const char * ms_lutDsc[] =
  {
    "Horizontal symmetry", "Vertical symmetry", "Rotation by 180�", "Unchanged"
  };
  return ms_lutDsc[iFlipPlane];
} // elxToString

//----------------------------------------------------------------------------
//  elxToEFlipPlane
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EFlipPlane elxToEFlipPlane(const char * iprFlipPlane)
{
  static std::map<std::string, EFlipPlane> ms_lut;
  if (ms_lut.empty())
  {
    ms_lut.insert(make_pair(std::string("FP_Horizontal"),FP_Horizontal));
    ms_lut.insert(make_pair(std::string("FP_Vertical"),FP_Vertical));
    ms_lut.insert(make_pair(std::string("FP_Both"),FP_Both));
    ms_lut.insert(make_pair(std::string("FP_None"),FP_None));
  }
  return ms_lut[std::string(iprFlipPlane)];
} // elxToEFlipPlane

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(ERightRotation iRightRotation)
{
  static const char * ms_lutDsc[] =
  {
    "No rotation", "Left rotation by 90�", "Rotation by 180�", 
    "Right rotation by 90�"
  };
  return ms_lutDsc[iRightRotation];
} // elxToString

//----------------------------------------------------------------------------
//  elxToERightRotation
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
ERightRotation elxToERightRotation(const char * iprFlipPlane)
{
  static std::map<std::string, ERightRotation> ms_lut;
  if (ms_lut.empty())
  {
    ms_lut.insert(make_pair(std::string("RR_0"),RR_0));
    ms_lut.insert(make_pair(std::string("RR_90Left"),RR_90Left));
    ms_lut.insert(make_pair(std::string("RR_180"),RR_180));
    ms_lut.insert(make_pair(std::string("RR_90Right"),RR_90Right));
  }
  return ms_lut[std::string(iprFlipPlane)];
} // elxToERightRotation

//----------------------------------------------------------------------------
//  elxEGeometryFlagToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxEGeometryFlagToString(int32 iFlag)
{
  static const char * ms_lutDsc[] =
  {
    "Image size is expanded to the rotated image size otherwise conserve source image size", 
    "Interpolation are required for better precision, for speed-up don't use it", 
    "Antialiasing", 
    "All of the above"
  };
  return ms_lutDsc[iFlag];
} // elxEGeometryFlagToString

//----------------------------------------------------------------------------
//  elxToEGeometryFlag
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
int32 elxToEGeometryFlag(const char * iprFlipPlane)
{
  static std::map<std::string, int32> ms_lut;
  if (ms_lut.empty())
  {
    ms_lut.insert(std::make_pair<std::string, int32>(
      std::string("RF_Expand"),RF_Expand));
    ms_lut.insert(std::make_pair<std::string, int32>(
      std::string("RF_Interpolation"),RF_Interpolation));
    ms_lut.insert(std::make_pair<std::string, int32>(
      std::string("RF_Antialiasing"),RF_Antialiasing));
    ms_lut.insert(std::make_pair<std::string, int32>(
      std::string("RF_Default"),RF_Default));
  }
  return ms_lut[std::string(iprFlipPlane)];
} // elxToEGeometryFlag

IImageGeometry::~IImageGeometry() {}

//----------------------------------------------------------------------------
//  explicit instantiation of all image types
//----------------------------------------------------------------------------
elxINSTANTIATE_CLASS_FOR_ALL_IMAGE_TYPES( ImageGeometryImpl );

} // namespace Image
} // namespace eLynx
