//============================================================================
//  ImageImpl.hpp                                      Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __ImageImpl_hpp__
#define __ImageImpl_hpp__

#include <elx/image/ImageImpl.h>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  default constructor : construct an invalid image.
//----------------------------------------------------------------------------
//  public 
//----------------------------------------------------------------------------
template <class Pixel>
ImageImpl<Pixel>::ImageImpl() :
    AbstractImage(),
  _spMap()
{
} // default constructor


//----------------------------------------------------------------------------
//  constructor : construct image of size iWidth by iHeight.
//  map is allocated but non-initialized (for performance reason)
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : uint32 iWidth : image width
//        uint32 iHeight : image height
//----------------------------------------------------------------------------
template <class Pixel>
ImageImpl<Pixel>::ImageImpl(uint32 iWidth, uint32 iHeight) :
    AbstractImage(iWidth, iHeight),
  _spMap()
{
  const uint32 nPixel = iWidth*iHeight;
  if (0 != nPixel)
    _spMap.reset( new Pixel_t[nPixel] );

} // constructor


//----------------------------------------------------------------------------
//  constructor : construct image of size iWidth by iHeight fill a pixel value.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : uint32 iWidth : image width
//        uint32 iHeight : image height
//        const Pixel& iPixel : the pixel value to fill map with
//----------------------------------------------------------------------------
template <class Pixel>
ImageImpl<Pixel>::ImageImpl(uint32 iWidth, uint32 iHeight, const Pixel& iPixel) :
    AbstractImage(iWidth, iHeight), 
  _spMap()
{
  const uint32 nPixel = iWidth*iHeight;
  if (0 != nPixel)
  {
    _spMap.reset( new Pixel_t[nPixel] );

    // Fill map with pixel value
    Pixel * prDst = GetPixel();
    Pixel * prEnd = GetPixelEnd();
    do { *prDst = iPixel; } while (++prDst != prEnd);
  }

} // constructor


//----------------------------------------------------------------------------
//  copy constructor
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const ImageImpl& iImage: image to copy
//----------------------------------------------------------------------------
template <class Pixel>
ImageImpl<Pixel>::ImageImpl(const ImageImpl& iImage) :
    AbstractImage(iImage), 
  _spMap()
{
  if (!iImage.IsValid())
    return;

  const uint32 nPixel = GetPixelCount();
  if (0 != nPixel)
  {
    // copy map
    _spMap.reset( new Pixel_t[nPixel] );
    ::memcpy(_spMap.get(), iImage._spMap.get(), sizeofMap());
  }
    
} // copy constructor


//----------------------------------------------------------------------------
//  operator =
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const ImageImpl& iImage: image to assign
//  Out : const ImageImpl&
//----------------------------------------------------------------------------
template <class Pixel>
const ImageImpl<Pixel>& ImageImpl<Pixel>::operator = (const ImageImpl& iImage)
{
  // guard against assigning to the "this" pointer
  if (this == &iImage)
    return *this;

  if (!iImage.IsValid())
  {
    _width = _height = 0;
    _spMap.reset();
    return *this;
  }

  _width  = iImage._width;
  _height = iImage._height;
  const uint32 size = sizeofMap();
  if (0 != size)
  {
    // copy map
    _spMap.reset( new Pixel_t[_width*_height] );
    ::memcpy(_spMap.get(), iImage._spMap.get(), size);
  }

  return *this;

} // operator =


//----------------------------------------------------------------------------
//  CopyAndForget : Assign image to this and release image
//  Use this method for memory performance reason in restricted area
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : iospImage : image to copy and release
//  Out : bool : success status
//----------------------------------------------------------------------------
template <class Pixel>
bool ImageImpl<Pixel>::CopyAndForget(
  boost::shared_ptr< ImageImpl<Pixel> >& iospImage)
{
  if (!elxUseable(iospImage.get()))
    return false;

  // update new size
  _width  = iospImage->_width;
  _height = iospImage->_height;
  _spMap.swap(iospImage->_spMap);

  // release old image
  iospImage->_spMap.reset();

  return true;

} // CopyAndForget

//----------------------------------------------------------------------------
//  Begin : Returns PixelIterator pointing to the beginning of the Image
//----------------------------------------------------------------------------
//  virtual public from AbstractImage
//----------------------------------------------------------------------------
template <class Pixel>
inline
boost::shared_ptr<IPixelIterator> ImageImpl<Pixel>::Begin()
{
  return boost::shared_ptr<IPixelIterator>(
    new PixelIterator<Pixel>(_spMap.get(), _width));

} // Begin

//----------------------------------------------------------------------------
//  Begin : Returns Const PixelIterator pointing to the beginning of the Image
//----------------------------------------------------------------------------
//  virtual public from AbstractImage
//----------------------------------------------------------------------------
template <class Pixel>
inline
boost::shared_ptr<IPixelIterator> ImageImpl<Pixel>::Begin() const
{
  return boost::shared_ptr<IPixelIterator>(
    new PixelIterator<Pixel const>(_spMap.get(), _width));

} // Begin const

//----------------------------------------------------------------------------
//  End : Returns PixelIterator pointing to the end of the Image
//----------------------------------------------------------------------------
//  virtual public from AbstractImage
//----------------------------------------------------------------------------
template <class Pixel>
inline
boost::shared_ptr<IPixelIterator> ImageImpl<Pixel>::End()
{
  return boost::shared_ptr<IPixelIterator>(
    new PixelIterator<Pixel>(this->GetPixelEnd(), _width));

} // End

//----------------------------------------------------------------------------
//  End : Returns const PixelIterator pointing to the end of the Image
//----------------------------------------------------------------------------
//  virtual public from AbstractImage
//----------------------------------------------------------------------------
template <class Pixel>
inline
boost::shared_ptr<IPixelIterator> ImageImpl<Pixel>::End() const
{
  return boost::shared_ptr<IPixelIterator>(
    new PixelIterator<Pixel const>(this->GetPixelEnd(), _width));

} // End const

//----------------------------------------------------------------------------
//  GetPixelFormat : Retrieve pixel format
//----------------------------------------------------------------------------
//  public virtual from AbstractImage
//----------------------------------------------------------------------------
//  In  : -
//  Out : EPixelFormat - Pixel Format
//----------------------------------------------------------------------------
template <class Pixel>
inline
EPixelFormat ImageImpl<Pixel>::GetPixelFormat() const
{
  return Pixel_t::GetPixelFormat();

} // GetPixelFormat


//----------------------------------------------------------------------------
//  IsValid : 
//----------------------------------------------------------------------------
//  virtual public from AbstractImage
//----------------------------------------------------------------------------
template <class Pixel>
inline
bool ImageImpl<Pixel>::IsValid() const
{
  return ((0 != _width) && (0 != _height) && (NULL != _spMap.get())); 

} // IsValid


//----------------------------------------------------------------------------
//  Null_Pixel : return pixel with 0 values
//----------------------------------------------------------------------------
//  public static
//----------------------------------------------------------------------------
//  In  : -
//  Out : Pixel_t : pixel with zero value
//----------------------------------------------------------------------------
template <class Pixel>
inline
Pixel ImageImpl<Pixel>::Null() { return Pixel::Null(); }

template <class Pixel>
inline
Pixel ImageImpl<Pixel>::White() { return Pixel::White(); }

template <class Pixel>
inline
Pixel ImageImpl<Pixel>::Black() { return Pixel::Black(); }

//----------------------------------------------------------------------------
//  GetPixel : Retrieve pointeur to read/write pixel.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : uint32 iX : x pixel's coordinate
//        uint32 iY : y pixel's coordinate
//  Out : Pixel * : pointer to the pixel at (x,y)
//----------------------------------------------------------------------------
template <class Pixel>
inline
Pixel * ImageImpl<Pixel>::GetPixel(uint32 iX, uint32 iY)
{
  // clip pixel location
  if ((iX >= GetWidth()) || (iY >= GetHeight()) || (NULL == _spMap))
    return NULL;

  Pixel_t * prPixel = _spMap.get() + iX + iY*_width;
  return prPixel;

} // GetPixel


//----------------------------------------------------------------------------
//  GetPixel : Retrieve pointer to read pixel.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : uint32 iX : x pixel's coordinate
//        uint32 iY : y pixel's coordinate
//  Out : Pixel * : pointer to the pixel at (x,y)
//----------------------------------------------------------------------------
template <class Pixel>
inline
const Pixel * ImageImpl<Pixel>::GetPixel(uint32 iX, uint32 iY) const
{
  // clip pixel location
  if ((iX >= GetWidth()) || (iY >= GetHeight()) || (NULL == _spMap))
    return NULL;

  const Pixel_t * prPixel = _spMap.get() + iX + iY*_width;
  return prPixel;

} // GetPixel


//----------------------------------------------------------------------------
template <class Pixel>
inline
const Pixel * ImageImpl<Pixel>::GetPixelEnd() const
{
  if (NULL == _spMap.get()) return NULL;
  return _spMap.get() + _width*_height;
}
//----------------------------------------------------------------------------
template <class Pixel>
inline
Pixel * ImageImpl<Pixel>::GetPixelEnd()
{
  if (NULL == _spMap.get()) return NULL;
  return _spMap.get() + _width*_height;
}

//----------------------------------------------------------------------------
template <class Pixel>
inline
const typename Pixel::type * ImageImpl<Pixel>::GetSamples() const
{
 return static_cast<const typename Pixel::type*>(static_cast<void*>(_spMap.get()));
}
//----------------------------------------------------------------------------
template <class Pixel>
inline
typename Pixel::type * ImageImpl<Pixel>::GetSamples()
{
  return static_cast<typename Pixel::type*>(static_cast<void*>(_spMap.get()));
}

//----------------------------------------------------------------------------
template <class Pixel>
inline
const typename Pixel::type * ImageImpl<Pixel>::GetSamplesEnd() const
{
  return static_cast<const typename Pixel::type*>(static_cast<void*>(_spMap.get() + _width*_height));
}
//----------------------------------------------------------------------------
template <class Pixel>
inline
typename Pixel::type * ImageImpl<Pixel>::GetSamplesEnd()
{
  return static_cast<typename Pixel::type*>(static_cast<void*>(_spMap.get() + _width*_height));
}
//----------------------------------------------------------------------------
template <class Pixel>
inline 
uint32 ImageImpl<Pixel>::sizeofMap() const
{
  return _width * _height * sizeof(Pixel);
}
//----------------------------------------------------------------------------
template <class Pixel>
inline 
uint32 ImageImpl<Pixel>::sizeofWidth() const
{
  return _width * sizeof(Pixel);
}

} // namespace Image
} // namespace eLynx

#endif // __ImageImpl_h__
