//============================================================================
//  ImageOperatorsImpl.cpp                       Image.Component package
//============================================================================
//  Usage :  implementation of image operators
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/ImageOperatorsImpl.h>

#include "Operators/Constant.hpp"
#include "Operators/Image.hpp"
#include "Operators/ListAdd.hpp"
#include "Operators/ListMul.hpp"
#include "Operators/ListMin.hpp"
#include "Operators/ListMax.hpp"
#include "Operators/ListMean.hpp"
#include "Operators/ListMedian.hpp"
#include "Operators/ListClip.hpp"
#include "Operators/ListEntropy.hpp"
#include "Operators/ImageList.hpp"

namespace eLynx {
namespace Image {

IImageOperators::~IImageOperators() {}

namespace {

// on LINUX GCC Performs dead code elimination (-fdce) with optimization level 
// set to -O or higher. This leads to the elimination of the elxOperator 
// instantiations for all Pixel types which uses Ramp and results in linking 
// error. elxOperatorDummyTo tricks GCC into keeping them rather then throwing 
// away. If anyone knows better way of avoiding this problem, please let me know
void elxOperatorDummy()
{
  ImageImpl<PixelRGB<uint8> > imageRGBub;
  elxOperator(imageRGBub,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

  ImageImpl<PixelRGB<uint16> > imageRGBus;
  elxOperator(imageRGBus,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

  ImageImpl<PixelRGB<int32> > imageRGBi;
  elxOperator(imageRGBi,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

  ImageImpl<PixelL<uint8> > imageLub;
  elxOperator(imageLub,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

  ImageImpl<PixelL<uint16> > imageLus;
  elxOperator(imageLus,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

  ImageImpl<PixelL<int32> > imageLi;
  elxOperator(imageLi,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

  ImageImpl<PixelLA<uint8> > imageLAub;
  elxOperator(imageLAub,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

  ImageImpl<PixelLA<uint16> > imageLAus;
  elxOperator(imageLAus,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

  ImageImpl<PixelLA<int32> > imageLAi;
  elxOperator(imageLAi,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

  ImageImpl<PixelRGBA<uint8> > imageRGBAub;
  elxOperator(imageRGBAub,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

  ImageImpl<PixelRGBA<uint16> > imageRGBAus;
  elxOperator(imageRGBAus,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

  ImageImpl<PixelRGBA<int32> > imageRGBAi;
  elxOperator(imageRGBAi,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);

#ifdef elxUSE_ImageComplex
  ImageImpl<PixelComplex<int32> > imageCi;
  elxOperator(imageCi,IOP_Add, 1.0, CM_All, ProgressNotifier_NULL);
#endif

} // elxOperatorDummy

} // anonymous-namespace

//----------------------------------------------------------------------------
//  explicit instantiation of all image types
//----------------------------------------------------------------------------
elxINSTANTIATE_CLASS_FOR_ALL_IMAGE_TYPES( ImageOperatorsImpl );

} // namespace Image
} // namespace eLynx
