//============================================================================
//  Pixels.cpp                                         Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <string>
#include <map>

#include <boost/utility.hpp>

#include <elx/image/Pixels.h>
#include <elx/image/PixelServices.h>
#include <elx/image/IPixelIterator.h>

namespace eLynx {
namespace Image {

IPixelIterator::~IPixelIterator() {}

//----------------------------------------------------------------------------
template<> const uint8 SampleTypeTraits<uint8>::_black = uint8MIN;
template<> const uint8 SampleTypeTraits<uint8>::_white = uint8MAX;
//----------------------------------------------------------------------------
template<> const uint16 SampleTypeTraits<uint16>::_black = uint16MIN;
template<> const uint16 SampleTypeTraits<uint16>::_white = uint16MAX;
//----------------------------------------------------------------------------
template<> const int32 SampleTypeTraits<int32>::_black = 0;
template<> const int32 SampleTypeTraits<int32>::_white = int32MAX;
//----------------------------------------------------------------------------
template<> const int64 SampleTypeTraits<int64>::_black = 0;
template<> const int64 SampleTypeTraits<int64>::_white = int64MAX;
//----------------------------------------------------------------------------
template<> const float SampleTypeTraits<float>::_black = 0.0f;
template<> const float SampleTypeTraits<float>::_white = 1.0f;
//----------------------------------------------------------------------------
template<> const double SampleTypeTraits<double>::_black = 0.0;
template<> const double SampleTypeTraits<double>::_white = 1.0;


//----------------------------------------------------------------------------
// PixelComplex
//----------------------------------------------------------------------------
template<> const int32  PixelComplex<int32 >::_min[2] = { int32MIN, int32MIN };
template<> const int32  PixelComplex<int32 >::_max[2] = { int32MAX, int32MAX };

template<> const float  PixelComplex<float >::_min[2] = { floatMIN, floatMIN };
template<> const float  PixelComplex<float >::_max[2] = { floatMAX, floatMAX };

template<> const double PixelComplex<double>::_min[2] = { doubleMIN, doubleMIN };
template<> const double PixelComplex<double>::_max[2] = { doubleMAX, doubleMAX };


//----------------------------------------------------------------------------
// L
//----------------------------------------------------------------------------
template<> const int32  PixelL<int32 >::_min[1] = { int32MIN };
template<> const int32  PixelL<int32 >::_max[1] = { int32MAX };

template<> const float  PixelL<float >::_min[1] = { 0.f };
template<> const float  PixelL<float >::_max[1] = { 1.f };

template<> const double PixelL<double>::_min[1] = { 0.0 };
template<> const double PixelL<double>::_max[1] = { 1.0 };

//----------------------------------------------------------------------------
// LA
//----------------------------------------------------------------------------
template<> const int32  PixelLA<int32 >::_min[2] = { int32MIN, int32MIN };
template<> const int32  PixelLA<int32 >::_max[2] = { int32MAX, int32MAX };

template<> const float  PixelLA<float >::_min[2] = { 0.f, 0.f };
template<> const float  PixelLA<float >::_max[2] = { 1.f, 1.f };

template<> const double PixelLA<double>::_min[2] = { 0.0, 0.0 };
template<> const double PixelLA<double>::_max[2] = { 1.0, 1.0 };

//----------------------------------------------------------------------------
// RGB
//----------------------------------------------------------------------------
template<> const int32  PixelRGB<int32 >::_min[3] = { int32MIN, int32MIN, int32MIN };
template<> const int32  PixelRGB<int32 >::_max[3] = { int32MAX, int32MAX, int32MAX };

template<> const float  PixelRGB<float >::_min[3] = { 0.f, 0.f, 0.f };
template<> const float  PixelRGB<float >::_max[3] = { 1.f, 1.f, 1.f };

template<> const double PixelRGB<double>::_min[3] = { 0.0, 0.0, 0.0 };
template<> const double PixelRGB<double>::_max[3] = { 1.0, 1.0, 1.0 };

//----------------------------------------------------------------------------
// RGBA
//----------------------------------------------------------------------------
template<> const int32  PixelRGBA<int32 >::_min[4] = { int32MIN, int32MIN, int32MIN, int32MIN };
template<> const int32  PixelRGBA<int32 >::_max[4] = { int32MAX, int32MAX, int32MAX, int32MAX };

template<> const float  PixelRGBA<float >::_min[4] = { 0.f, 0.f, 0.f, 0.f };
template<> const float  PixelRGBA<float >::_max[4] = { 1.f, 1.f, 1.f, 1.f };

template<> const double PixelRGBA<double>::_min[4] = { 0.0, 0.0, 0.0, 0.0 };
template<> const double PixelRGBA<double>::_max[4] = { 1.0, 1.0, 1.0, 1.0 };

//----------------------------------------------------------------------------
// HLS
//----------------------------------------------------------------------------
template<> const float  PixelHLS<float >::_min[3] = { 0.f, 0.f, 0.f };
template<> const float  PixelHLS<float >::_max[3] = { 1.f, 1.f, 1.f };

template<> const double PixelHLS<double>::_min[3] = { 0.0, 0.0, 0.0 };
template<> const double PixelHLS<double>::_max[3] = { 1.0, 1.0, 1.0 };

//----------------------------------------------------------------------------
// CIE XYZ: Y [0, 100], X,Z [-120, +120]
//----------------------------------------------------------------------------
template<> const float  PixelXYZ<float >::_min[3] = { -120.f,   0.f, -120.f };
template<> const float  PixelXYZ<float >::_max[3] = { +120.f, 100.f, +120.f };
                                                             
template<> const double PixelXYZ<double>::_min[3] = { -120.0,   0.0, -120.0 };
template<> const double PixelXYZ<double>::_max[3] = { +120.0, 100.0, +120.0 };

//----------------------------------------------------------------------------
// CIE Lab: L [0, 100], a,b [-120, +120]
//----------------------------------------------------------------------------
template<> const float  PixelLab<float >::_min[3] = {   0.f, -120.f, -120.f };
template<> const float  PixelLab<float >::_max[3] = { 100.f, +120.f, +120.f };

template<> const double PixelLab<double>::_min[3] = {   0.0, -120.0, -120.0 };
template<> const double PixelLab<double>::_max[3] = { 100.0, +120.0, +120.0 };

//----------------------------------------------------------------------------
// CIE Luv: L [0, 100], u [-134, +220], v [-140, +122]
//----------------------------------------------------------------------------
template<> const float  PixelLuv<float >::_min[3] = {   0.f, -134.f, -140.f };
template<> const float  PixelLuv<float >::_max[3] = { 100.f, +220.f, +122.f };

template<> const double PixelLuv<double>::_min[3] = {   0.0, -134.0, -140.0 };
template<> const double PixelLuv<double>::_max[3] = { 100.0, +220.0, +122.0 };

//----------------------------------------------------------------------------
// CIE Lch: L [0, 100], c [0, 170], h [0, 360]
//----------------------------------------------------------------------------
template<> const float  PixelLch<float >::_min[3] = {   0.f,   0.f,   0.f };
template<> const float  PixelLch<float >::_max[3] = { 100.f, 170.f, 360.f };

template<> const double PixelLch<double>::_min[3] = {   0.0,   0.0,   0.0 };
template<> const double PixelLch<double>::_max[3] = { 100.0, 170.0, 360.0 };

//----------------------------------------------------------------------------
// Hunter Lab
//----------------------------------------------------------------------------
template<> const float  PixelHLab<float >::_min[3] = {   0.f, -120.f, -120.f };
template<> const float  PixelHLab<float >::_max[3] = { 100.f, +120.f, +120.f };

template<> const double PixelHLab<double>::_min[3] = {   0.0, -120.0, -120.0 };
template<> const double PixelHLab<double>::_max[3] = { 100.0, +120.0, +120.0 };


//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EPixelMode iPixelMode)
{
  static const char * ms_lut[PM_Undefined+1] =
  {
    "Grey", "Color", "Complex", "Undefined"
  };
  return ms_lut[iPixelMode];

} // elxToString

//----------------------------------------------------------------------------
//  elxToEPixelFormat
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EPixelFormat elxToEPixelFormat(const char * iprType)
{
  static std::map<std::string, EPixelFormat> ms_lut;
  if (ms_lut.empty())
  {
    ms_lut.insert(make_pair(std::string("PF_Lub"),PF_Lub));
    ms_lut.insert(make_pair(std::string("PF_Lus"),PF_Lus));
    ms_lut.insert(make_pair(std::string("PF_Li"),PF_Li));
    ms_lut.insert(make_pair(std::string("PF_Lf"),PF_Lf));
    ms_lut.insert(make_pair(std::string("PF_Ld"),PF_Ld));
    ms_lut.insert(make_pair(std::string("PF_LAub"),PF_LAub));
    ms_lut.insert(make_pair(std::string("PF_LAus"),PF_LAus));
    ms_lut.insert(make_pair(std::string("PF_LAi"),PF_LAi));
    ms_lut.insert(make_pair(std::string("PF_LAf"),PF_LAf));
    ms_lut.insert(make_pair(std::string("PF_LAd"),PF_LAd));
    ms_lut.insert(make_pair(std::string("PF_RGBub"),PF_RGBub));
    ms_lut.insert(make_pair(std::string("PF_RGBus"),PF_RGBus));
    ms_lut.insert(make_pair(std::string("PF_RGBi"),PF_RGBi));
    ms_lut.insert(make_pair(std::string("PF_RGBf"),PF_RGBf));
    ms_lut.insert(make_pair(std::string("PF_RGBd"),PF_RGBd));
    ms_lut.insert(make_pair(std::string("PF_RGBAub"),PF_RGBAub));
    ms_lut.insert(make_pair(std::string("PF_RGBAus"),PF_RGBAus));
    ms_lut.insert(make_pair(std::string("PF_RGBAi"),PF_RGBAi));
    ms_lut.insert(make_pair(std::string("PF_RGBAf"),PF_RGBAf));
    ms_lut.insert(make_pair(std::string("PF_RGBAd"),PF_RGBAd));
    ms_lut.insert(make_pair(std::string("PF_CPLXi"),PF_CPLXi));
    ms_lut.insert(make_pair(std::string("PF_CPLXf"),PF_CPLXf));
    ms_lut.insert(make_pair(std::string("PF_CPLXd"),PF_CPLXd));
    ms_lut.insert(make_pair(std::string("PF_HLSf"),PF_HLSf));
    ms_lut.insert(make_pair(std::string("PF_HLSd"),PF_HLSd));
    ms_lut.insert(make_pair(std::string("PF_XYZf"),PF_XYZf));
    ms_lut.insert(make_pair(std::string("PF_XYZd"),PF_XYZd));
    ms_lut.insert(make_pair(std::string("PF_Luvf"),PF_Luvf));
    ms_lut.insert(make_pair(std::string("PF_Luvd"),PF_Luvd));
    ms_lut.insert(make_pair(std::string("PF_Labf"),PF_Labf));
    ms_lut.insert(make_pair(std::string("PF_Labd"),PF_Labd));
    ms_lut.insert(make_pair(std::string("PF_Lchf"),PF_Lchf));
    ms_lut.insert(make_pair(std::string("PF_Lchd"),PF_Lchd));
    ms_lut.insert(make_pair(std::string("PF_HLabf"),PF_HLabf));
    ms_lut.insert(make_pair(std::string("PF_HLabd"),PF_HLabd));
    ms_lut.insert(make_pair(std::string("PF_Undefined"),PF_Undefined));
  }
  std::map<std::string, EPixelFormat>::iterator it = 
    ms_lut.find(std::string(iprType));
  return it == ms_lut.end() ? PF_Undefined: it->second;

} // elxToEPixelFormat

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EColorSpace iColorSpace)
{
  static const char * ms_lut[CS_Undefined+1] =
  {
    "RGB", "HLS", 
    "CIE XYZ", "CIE Luv", "CIE Lab", "CIE Lch",
    "Hunter Lab",
    "Undefined"
  };
  return ms_lut[iColorSpace];

} // elxToString

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EPixelFormat iFormat)
{
  static const char * ms_lut[PF_Undefined+1] =
  {
    "Lub",    "Lus",    "Li",    "Lf",    "Ld",
    "LAub",   "LAus",   "LAi",   "LAf",   "LAd",
    "RGBub",  "RGBus",  "RGBi",  "RGBf",  "RGBd",
    "RGBAub", "RGBAus", "RGBAi", "RGBAf", "RGBAd",
                        "CPLXi", "CPLXf", "CPLXd",
                                 "HLSf",  "HLSd",
                                 "XYZf",  "XYZd",
                                 "Luvf",  "Luvd",
                                 "Labf",  "Labd",
                                 "Lchf",  "Lchd",
                                 "HLabf", "HLabd",
                                 "Undefined"
  };
  return ms_lut[iFormat];

} // elxToString


//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EPixelType iPixelType)
{
  static const char * ms_lut[PT_Undefined+1] =
  {
    "L", "LA", 
    "Complex", 
    "RGB", "RGBA", "HLS",
    "CIE XYZ", "CIE Luv", "CIE Lab", "CIE Lch", 
    "Hunter Lab",
    "?"
  };
  return ms_lut[iPixelType];

} // elxToString


//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EPixelFormat iFormat, uint32 iChannelIndex)
{
  if (iChannelIndex > 3)
    return NULL;

  static const char * ms_lut[4*(PT_Undefined+1)] =
  {
    "Luminance", NULL, NULL, NULL,            // PF_L
    "Luminance", "Alpha", NULL, NULL,         // PF_LA
    "Norm", "Phase", NULL, NULL,              // PF_Complex
    "Red", "Green", "Blue", NULL,             // PF_RGB
    "Red", "Green", "Blue", "Alpha",          // PF_RGBA
    "Hue", "Luminance", "Saturation", NULL,   // PF_HLS
    "CIE X", "CIE Y", "CIE Z", NULL,          // PF_XYZ
    "CIE L", "CIE u", "CIE v", NULL,          // PF_Luv
    "CIE L", "CIE a", "CIE b", NULL,          // PF_Lab
    "CIE L", "CIE c", "CIE h", NULL,          // PF_Lch
    "Hunter L", "Hunter a", "Hunter b", NULL, // PF_HLab
    NULL, NULL, NULL, NULL,                   // PF_Unknown
  };
  const EPixelType type = elxGetPixelType(iFormat);
  const uint32 idx = uint32(type)*4 + iChannelIndex;
  return ms_lut[idx];

} // elxToString

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EColorToGreyConversion iMethod)
{
  static const char * ms_lut[CGC_Max] =
  {
    "Green", "Mean", "Desaturate", "CCIR 601", "CCIR 709", "ITU"
  };
  return ms_lut[iMethod];

} // elxToString


//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EGreyToColorConversion iMethod)
{
  static const char * ms_lut[GCC_Max] =
  {
    "Palettized", "False color"
  };
  return ms_lut[iMethod];

} // elxToString


//----------------------------------------------------------------------------
//  elxSizeofPixel
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
uint32 elxSizeofPixel(EPixelFormat iFormat)
{
  static uint32 ms_lut[PF_Undefined+1] =
  {
     1, 2, 4, 4, 8, // PF_Lub,    PF_Lus,   PF_Li,    PF_Lf,    PF_Ld
     2, 4, 8, 8,16, // PF_LAub,   PF_LAus,  PF_LAi,   PF_LAf,   PF_LAd
     3, 6,12,12,24, // PF_RGBub,  PF_RGBus, PF_RGBi,  PF_RGBf,  PF_RGBd
     4, 8,16,16,32, // PF_RGBAub, PF_RGBAus,PF_RGBAi, PF_RGBAf, PF_RGBAd
     8, 8,16,       //                      PF_CPLXi, PF_CPLXf, PF_CPLXd
    12,24,          //                                PF_HLSf,  PF_HLSd
    12,24,          //                                PF_XYZf,  PF_XYZd
    12,24,          //                                PF_Luvf,  PF_Luvd,
    12,24,          //                                PF_Labf,  PF_Labd
    12,24,          //                                PF_Lchf,  PF_Lchbd
    12,24,          //                                PF_HLabf, PF_HLabd
    0               // PF_Undefined
  };
  return ms_lut[iFormat];

} // elxSizeofPixel


//----------------------------------------------------------------------------
//  elxGetResolution
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EResolution elxGetResolution(EPixelFormat iFormat)
{
  static EResolution ms_lut[PF_Undefined+1] =
  {
    // PF_Lub,    PF_Lus,    PF_Li,    PF_Lf,    PF_Ld
    RT_UINT8, RT_UINT16, RT_INT32, RT_Float, RT_Double,

    // PF_LAub,   PF_LAus,   PF_LAi,   PF_LAf,   PF_LAd
    RT_UINT8, RT_UINT16, RT_INT32, RT_Float, RT_Double,

    // PF_RGBub,  PF_RGBs,  PF_RGBi,  PF_RGBf,  PF_RGBd
    RT_UINT8, RT_UINT16, RT_INT32, RT_Float, RT_Double,

    // PF_RGBAub, PF_RGBAus, PF_RGBAi, PF_RGBAf, PF_RGBAd
    RT_UINT8, RT_UINT16, RT_INT32, RT_Float, RT_Double,

    //  PF_CPLXi, PF_CPLXf, PF_CPLXd
    RT_INT32, RT_Float, RT_Double,

    // PF_HLSf,   PF_HLSd
    RT_Float, RT_Double,

    // PF_XYZf,  PF_XYZd
    RT_Float, RT_Double,

    // PF_Luvf,  PF_Luvd,
    RT_Float, RT_Double,

    // PF_Labf,  PF_Labd
    RT_Float, RT_Double,

    // PF_Lchf,  PF_Lchd
    RT_Float, RT_Double,

    // PF_HLabf,  PF_HLabd
    RT_Float, RT_Double
  };
  return ms_lut[iFormat];

} // elxGetResolution

//----------------------------------------------------------------------------
//  elxGetPixelMode
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EPixelMode elxGetPixelMode(EPixelFormat iFormat)
{
  static EPixelMode ms_lut[PF_Undefined+1] =
  {
    // PF_Lub,    PF_Lus,    PF_Li,    PF_Lf,    PF_Ld
    PM_Grey, PM_Grey, PM_Grey, PM_Grey, PM_Grey,

    // PF_LAub,   PF_LAus,   PF_LAi,   PF_LAf,   PF_LAd
    PM_Grey, PM_Grey, PM_Grey, PM_Grey, PM_Grey,

    // PF_RGBub,  PF_RGBs,  PF_RGBi,  PF_RGBf,  PF_RGBd
    PM_Color, PM_Color, PM_Color, PM_Color, PM_Color,

    // PF_RGBAub, PF_RGBAus, PF_RGBAi, PF_RGBAf, PF_RGBAd
    PM_Color, PM_Color, PM_Color, PM_Color, PM_Color,

    //  PF_CPLXi, PF_CPLXf, PF_CPLXd
    PM_Complex, PM_Complex, PM_Complex,

    // PF_HLSf,   PF_HLSd
    PM_Color, PM_Color,

    // PF_XYZf,  PF_XYZd
    PM_Color, PM_Color,

    // PF_Luvf,  PF_Luvd,
    PM_Color, PM_Color,

    // PF_Labf,  PF_Labd
    PM_Color, PM_Color,

    // PF_Lchf,  PF_Lchd
    PM_Color, PM_Color,

    // PF_HLabf,  PF_HLabd
    PM_Color, PM_Color,

    // PF_Undefined
    PM_Undefined
  };
  return ms_lut[iFormat];

} // elxGetPixelMode

//----------------------------------------------------------------------------
//  elxGetPixelType
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EPixelType elxGetPixelType(EPixelFormat iFormat)
{
  static EPixelType ms_lut[PF_Undefined+1] =
  {
    // PF_Lub,    PF_Lus,    PF_Li,    PF_Lf,    PF_Ld
    PT_L, PT_L, PT_L, PT_L, PT_L,

    // PF_LAub,   PF_LAus,   PF_LAi,   PF_LAf,   PF_LAd
    PT_LA, PT_LA, PT_LA, PT_LA, PT_LA,

    // PF_RGBub,  PF_RGBs,  PF_RGBi,  PF_RGBf,  PF_RGBd
    PT_RGB, PT_RGB, PT_RGB, PT_RGB, PT_RGB,

    // PF_RGBAub, PF_RGBAus, PF_RGBAi, PF_RGBAf, PF_RGBAd
    PT_RGBA, PT_RGBA, PT_RGBA, PT_RGBA, PT_RGBA,

    //  PF_CPLXi, PF_CPLXf, PF_CPLXd
    PT_Complex, PT_Complex, PT_Complex,

    // PF_HLSf,   PF_HLSd
    PT_HLS, PT_HLS,

    // PF_XYZf,  PF_XYZd
    PT_XYZ, PT_XYZ,

    // PF_Luvf,  PF_Luvd,
    PT_Luv, PT_Luv,

    // PF_Labf,  PF_Labd
    PT_Lab, PT_Lab,

    // PF_Lchf,  PF_Lchd
    PT_Lch, PT_Lch,

    // PF_HLabf,  PF_HLabd
    PT_HLab, PT_HLab
  };
  return ms_lut[iFormat];

} // elxGetPixelType


//----------------------------------------------------------------------------
//  elxGetColorSpace
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EColorSpace elxGetColorSpace(EPixelFormat iFormat)
{
  static EColorSpace ms_lut[PF_Undefined+1] =
  {
    // PF_Lub,    PF_Lus,    PF_Li,    PF_Lf,    PF_Ld
    CS_Undefined, CS_Undefined, CS_Undefined, CS_Undefined, CS_Undefined,

    // PF_LAub,   PF_LAus,   PF_LAi,   PF_LAf,   PF_LAd
    CS_Undefined, CS_Undefined, CS_Undefined, CS_Undefined, CS_Undefined,

    // PF_RGBub,  PF_RGBs,  PF_RGBi,  PF_RGBf,  PF_RGBd
    CS_RGB, CS_RGB, CS_RGB, CS_RGB, CS_RGB,

    // PF_RGBAub, PF_RGBAus, PF_RGBAi, PF_RGBAf, PF_RGBAd
    CS_RGB, CS_RGB, CS_RGB, CS_RGB, CS_RGB,

    //  PF_CPLXi, PF_CPLXf, PF_CPLXd
    CS_Undefined, CS_Undefined, CS_Undefined,

    // PF_HLSf,   PF_HLSd
    CS_HLS, CS_HLS,

    // PF_XYZf,  PF_XYZd
    CS_CIE_XYZ, CS_CIE_XYZ,

    // PF_Luvf,  PF_Luvd,
    CS_CIE_Luv, CS_CIE_Luv,

    // PF_Labf,  PF_Labd
    CS_CIE_Lab, CS_CIE_Lab,

    // PF_Lchf,  PF_Lchd
    CS_CIE_Lch, CS_CIE_Lch,

    // PF_HLabf,  PF_HLabd
    CS_Hunter_Lab, CS_Hunter_Lab,


    // PF_Undefined
    CS_Undefined
  };
  return ms_lut[iFormat];

} // elxGetColorSpace

//----------------------------------------------------------------------------
//  elxGetChannelCount
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
uint32 elxGetChannelCount(EPixelFormat iFormat)
{
  static uint32 ms_lut[PF_Undefined+1] =
  {
    1,1,1,1,1,  // PF_Lub,    PF_Lus,    PF_Li,    PF_Lf,    PF_Ld
    2,2,2,2,2,  // PF_LAub,   PF_LAus,   PF_LAi,   PF_LAf,   PF_LAd
    3,3,3,3,3,  // PF_RGBub,  PF_RGBs,  PF_RGBi,  PF_RGBf,  PF_RGBd
    4,4,4,4,4,  // PF_RGBAub, PF_RGBAus, PF_RGBAi, PF_RGBAf, PF_RGBAd
    2,2,2,      //                      PF_CPLXi, PF_CPLXf, PF_CPLXd
    3,3,        //                                PF_HLSf,  PF_HLSd
    3,3,        //                                PF_XYZf,  PF_XYZd
    3,3,        //                                PF_Luvf,  PF_Luvd
    3,3,        //                                PF_Labf,  PF_Labd
    3,3,        //                                PF_Lchf,  PF_Lchd
    3,3,        //                                PF_HLabf, PF_HLabd
    0
  };
  return ms_lut[iFormat];

} // elxGetChannelCount


//----------------------------------------------------------------------------
//  elxHasAlpha
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
bool elxHasAlpha(EPixelFormat iFormat)
{
  return ( (PF_LAub == iFormat) || (PF_RGBAub == iFormat) ||
           (PF_LAus == iFormat) || (PF_RGBAus == iFormat) ||
           (PF_LAi  == iFormat) || (PF_RGBAi  == iFormat) ||
           (PF_LAf  == iFormat) || (PF_RGBAf  == iFormat) ||
           (PF_LAd  == iFormat) || (PF_RGBAd  == iFormat) );

} // elxHasAlpha


//----------------------------------------------------------------------------
//  elxGetPixelFormat
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EPixelFormat elxGetPixelFormat(
    EPixelType iPixelType, 
    EResolution iResolution)
{
  switch(iPixelType)
  {
  case PT_L:
    switch(iResolution)
    {
      case RT_UINT8:  return PF_Lub;
      case RT_UINT16: return PF_Lus;
      case RT_INT32:  return PF_Li;
      case RT_Float:  return PF_Lf;
      case RT_Double: return PF_Ld;
      default:        return PF_Undefined;
    }
  case PT_LA:
    switch(iResolution)
    {
      case RT_UINT8:  return PF_LAub;
      case RT_UINT16: return PF_LAus;
      case RT_INT32:  return PF_LAi;
      case RT_Float:  return PF_LAf;
      case RT_Double: return PF_LAd;
      default:        return PF_Undefined;
    }
    case PT_Complex:
      switch(iResolution)
      {
        case RT_INT32:  return PF_CPLXi;
        case RT_Float:  return PF_CPLXf;
        case RT_Double: return PF_CPLXf;
        default:        return PF_Undefined;
      }
    case PT_RGB:
      switch(iResolution)
      {
        case RT_UINT8:  return PF_RGBub;
        case RT_UINT16: return PF_RGBus;
        case RT_INT32:  return PF_RGBi;
        case RT_Float:  return PF_RGBf;
        case RT_Double: return PF_RGBd;
        default:        return PF_Undefined;
      }
    case PT_RGBA:
      switch(iResolution)
      {
        case RT_UINT8:  return PF_RGBAub;
        case RT_UINT16: return PF_RGBAus;
        case RT_INT32:  return PF_RGBAi;
        case RT_Float:  return PF_RGBAf;
        case RT_Double: return PF_RGBAd;
        default:        return PF_Undefined;
      }
    case PT_HLS:
      switch(iResolution)
      {
        case RT_Float:  return PF_HLSf;
        case RT_Double: return PF_HLSd;
        default:        return PF_Undefined;
      }
    case PT_XYZ:
      switch(iResolution)
      {
        case RT_Float:  return PF_XYZf;
        case RT_Double: return PF_XYZd;
        default:        return PF_Undefined;
      }
    case PT_Luv:
      switch(iResolution)
      {
        case RT_Float:  return PF_Luvf;
        case RT_Double: return PF_Luvd;
        default:        return PF_Undefined;
      }
    case PT_Lab:
      switch(iResolution)
      {
        case RT_Float:  return PF_Labf;
        case RT_Double: return PF_Labd;
        default:        return PF_Undefined;
      }
    case PT_Lch:
      switch(iResolution)
      {
        case RT_Float:  return PF_Lchf;
        case RT_Double: return PF_Lchd;
        default:        return PF_Undefined;
      }
    case PT_HLab:
      switch(iResolution)
      {
        case RT_Float:  return PF_HLabf;
        case RT_Double: return PF_HLabd;
        default:        return PF_Undefined;
      }
    default:  return PF_Undefined;
  }

} // elxGetPixelFormat


//----------------------------------------------------------------------------
//  elxGetPixelFormat
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EPixelFormat elxGetPixelFormat(
    EPixelMode iPixelMode,
    EResolution iResolution,
    EColorSpace iColorSpace, 
    bool ibHasAlpha)
{
  switch(iPixelMode)
  {
    case PM_Grey:
      if (ibHasAlpha)
      {
        switch(iResolution)
        {
          case RT_UINT8:  return PF_LAub;
          case RT_UINT16: return PF_LAus;
          case RT_INT32:  return PF_LAi;
          case RT_Float:  return PF_LAf;
          case RT_Double: return PF_LAd;
          default:        return PF_Undefined;
        }
      }
      else
      {
        switch(iResolution)
        {
          case RT_UINT8:  return PF_Lub;
          case RT_UINT16: return PF_Lus;
          case RT_INT32:  return PF_Li;
          case RT_Float:  return PF_Lf;
          case RT_Double: return PF_Ld;
          default:        return PF_Undefined;
        }
      }

    case PM_Complex:
      switch(iResolution)
      {
        case RT_INT32:  return PF_CPLXi;
        case RT_Float:  return PF_CPLXf;
        case RT_Double: return PF_CPLXf;
        default:        return PF_Undefined;
      }

    case PM_Color:
      switch(iColorSpace)
      {
        case CS_RGB:
          if (ibHasAlpha)
          {
            switch(iResolution)
            {
              case RT_UINT8:  return PF_RGBAub;
              case RT_UINT16: return PF_RGBAus;
              case RT_INT32:  return PF_RGBAi;
              case RT_Float:  return PF_RGBAf;
              case RT_Double: return PF_RGBAd;
              default:        return PF_Undefined;
            }
          }
          else
          {
            switch(iResolution)
            {
              case RT_UINT8:  return PF_RGBub;
              case RT_UINT16: return PF_RGBus;
              case RT_INT32:  return PF_RGBi;
              case RT_Float:  return PF_RGBf;
              case RT_Double: return PF_RGBd;
              default:        return PF_Undefined;
            }
          }
        case CS_HLS:
          switch(iResolution)
          {
            case RT_Float:  return PF_HLSf;
            case RT_Double: return PF_HLSd;
            default:        return PF_Undefined;
          }
        case CS_CIE_XYZ:
          switch(iResolution)
          {
            case RT_Float:  return PF_XYZf;
            case RT_Double: return PF_XYZd;
            default:        return PF_Undefined;
          }
        case CS_CIE_Lab:
          switch(iResolution)
          {
            case RT_Float:  return PF_Labf;
            case RT_Double: return PF_Labd;
            default:        return PF_Undefined;
          }
        case CS_CIE_Luv:
          switch(iResolution)
          {
            case RT_Float:  return PF_Luvf;
            case RT_Double: return PF_Luvd;
            default:        return PF_Undefined;
          }
        case CS_CIE_Lch:
          switch(iResolution)
          {
            case RT_Float:  return PF_Lchf;
            case RT_Double: return PF_Lchd;
            default:        return PF_Undefined;
          }
        case CS_Hunter_Lab:
          switch(iResolution)
          {
            case RT_Float:  return PF_HLabf;
            case RT_Double: return PF_HLabd;
            default:        return PF_Undefined;
          }

        case CS_Undefined:
        default:            return PF_Undefined;
      }
    default:  return PF_Undefined;
  }

} // elxGetPixelFormat


//----------------------------------------------------------------------------
//  elxGetPixelFormat
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EPixelFormat elxGetPixelFormat(EPixelFormat iFormat, EResolution iResolution)
{
  static EPixelFormat ms_lut[(PF_Undefined+1)*(RT_Undefined+1)] =
  {
    // RT_INT8, RT_UINT8, RT_INT16, RT_UINT16, RT_INT32, RT_UINT32, RT_INT64, RT_UINT64, RT_Float, RT_Double, RT_Undefined
    // PF_Lub
    PF_Undefined, PF_Lub, PF_Undefined, PF_Lus, PF_Li, PF_Undefined, PF_Undefined, PF_Undefined, PF_Lf, PF_Ld, PF_Undefined, 
    // PF_Lus    
    PF_Undefined, PF_Lub, PF_Undefined, PF_Lus, PF_Li, PF_Undefined, PF_Undefined, PF_Undefined, PF_Lf, PF_Ld, PF_Undefined, 
    // PF_Li
    PF_Undefined, PF_Lub, PF_Undefined, PF_Lus, PF_Li, PF_Undefined, PF_Undefined, PF_Undefined, PF_Lf, PF_Ld, PF_Undefined, 
    // PF_Lf
    PF_Undefined, PF_Lub, PF_Undefined, PF_Lus, PF_Li, PF_Undefined, PF_Undefined, PF_Undefined, PF_Lf, PF_Ld, PF_Undefined, 
    // PF_Ld
    PF_Undefined, PF_Lub, PF_Undefined, PF_Lus, PF_Li, PF_Undefined, PF_Undefined, PF_Undefined, PF_Lf, PF_Ld, PF_Undefined, 
    // PF_LAub
    PF_Undefined, PF_LAub, PF_Undefined, PF_LAus, PF_LAi, PF_Undefined, PF_Undefined, PF_Undefined, PF_LAf, PF_LAd, PF_Undefined, 
    // PF_LAus
    PF_Undefined, PF_LAub, PF_Undefined, PF_LAus, PF_LAi, PF_Undefined, PF_Undefined, PF_Undefined, PF_LAf, PF_LAd, PF_Undefined, 
    // PF_LAi
    PF_Undefined, PF_LAub, PF_Undefined, PF_LAus, PF_LAi, PF_Undefined, PF_Undefined, PF_Undefined, PF_LAf, PF_LAd, PF_Undefined, 
    // PF_LAf
    PF_Undefined, PF_LAub, PF_Undefined, PF_LAus, PF_LAi, PF_Undefined, PF_Undefined, PF_Undefined, PF_LAf, PF_LAd, PF_Undefined, 
    // PF_LAd
    PF_Undefined, PF_LAub, PF_Undefined, PF_LAus, PF_LAi, PF_Undefined, PF_Undefined, PF_Undefined, PF_LAf, PF_LAd, PF_Undefined, 
    // PF_RGBub
    PF_Undefined, PF_RGBub, PF_Undefined, PF_RGBus, PF_RGBi, PF_Undefined, PF_Undefined, PF_Undefined, PF_RGBf, PF_RGBd, PF_Undefined,
    // PF_RGBus
    PF_Undefined, PF_RGBub, PF_Undefined, PF_RGBus, PF_RGBi, PF_Undefined, PF_Undefined, PF_Undefined, PF_RGBf, PF_RGBd, PF_Undefined,
    // PF_RGBi
    PF_Undefined, PF_RGBub, PF_Undefined, PF_RGBus, PF_RGBi, PF_Undefined, PF_Undefined, PF_Undefined, PF_RGBf, PF_RGBd, PF_Undefined,
    // PF_RGBf
    PF_Undefined, PF_RGBub, PF_Undefined, PF_RGBus, PF_RGBi, PF_Undefined, PF_Undefined, PF_Undefined, PF_RGBf, PF_RGBd, PF_Undefined,
    // PF_RGBd
    PF_Undefined, PF_RGBub, PF_Undefined, PF_RGBus, PF_RGBi, PF_Undefined, PF_Undefined, PF_Undefined, PF_RGBf, PF_RGBd, PF_Undefined,
    // PF_RGBAub
    PF_Undefined, PF_RGBAub, PF_Undefined, PF_RGBAus, PF_RGBAi, PF_Undefined, PF_Undefined, PF_Undefined, PF_RGBAf, PF_RGBAd, PF_Undefined,
    // PF_RGBAus
    PF_Undefined, PF_RGBAub, PF_Undefined, PF_RGBAus, PF_RGBAi, PF_Undefined, PF_Undefined, PF_Undefined, PF_RGBAf, PF_RGBAd, PF_Undefined,
    // PF_RGBAi
    PF_Undefined, PF_RGBAub, PF_Undefined, PF_RGBAus, PF_RGBAi, PF_Undefined, PF_Undefined, PF_Undefined, PF_RGBAf, PF_RGBAd, PF_Undefined,
    // PF_RGBAf
    PF_Undefined, PF_RGBAub, PF_Undefined, PF_RGBAus, PF_RGBAi, PF_Undefined, PF_Undefined, PF_Undefined, PF_RGBAf, PF_RGBAd, PF_Undefined,
    // PF_RGBAd
    PF_Undefined, PF_RGBAub, PF_Undefined, PF_RGBAus, PF_RGBAi, PF_Undefined, PF_Undefined, PF_Undefined, PF_RGBAf, PF_RGBAd, PF_Undefined,
    // PF_CPLXi
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_CPLXi, PF_Undefined, PF_Undefined, PF_Undefined, PF_CPLXf, PF_CPLXd, PF_Undefined,
    // PF_CPLXf
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_CPLXi, PF_Undefined, PF_Undefined, PF_Undefined, PF_CPLXf, PF_CPLXd, PF_Undefined,
    // PF_CPLXd
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_CPLXi, PF_Undefined, PF_Undefined, PF_Undefined, PF_CPLXf, PF_CPLXd, PF_Undefined,
    // PF_HLSf
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_HLSf, PF_HLSd, PF_Undefined,
    // PF_HLSd
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_HLSf, PF_HLSd, PF_Undefined,
    // PF_XYZf
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_XYZf, PF_XYZd, PF_Undefined,
    // PF_XYZd
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_XYZf, PF_XYZd, PF_Undefined,
    // PF_Luvf
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Luvf, PF_Luvd, PF_Undefined,
    // PF_Luvd
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Luvf, PF_Luvd, PF_Undefined,
    // PF_Labf
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Labf, PF_Labd, PF_Undefined,
    // PF_Labd
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Labf, PF_Labd, PF_Undefined,
    // PF_Lchf
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Lchf, PF_Lchd, PF_Undefined,
    // PF_Lchd
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Lchf, PF_Lchd, PF_Undefined,
    // PF_HLabf
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_HLabf, PF_HLabd, PF_Undefined,
    // PF_HLabd
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_HLabf, PF_HLabd, PF_Undefined,
    // PF_Undefined
    PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined, PF_Undefined
  };
  const int32 idx = (RT_Undefined+1) * iFormat + iResolution;
  return ms_lut[idx];

} // elxGetPixelFormat

//----------------------------------------------------------------------------
//  elxIsMasking
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
bool elxIsMasking(EPixelFormat iFormat, uint32 iChannelMask)
{
  static uint32 ms_lut[PF_Undefined+1] =
  { 
    // PF_Lub,  PF_Lus,      PF_Li,      PF_Lf,      PF_Ld
    CM_Channel0,CM_Channel0,CM_Channel0,CM_Channel0,CM_Channel0,

    // PF_LAub,   PF_LAus,       PF_LAi,       PF_LAf,       PF_LAd
    CM_Channel01, CM_Channel01, CM_Channel01, CM_Channel01, CM_Channel01,  

    // PF_RGBub,   PF_RGBs,       PF_RGBi,       PF_RGBf,       PF_RGBd
    CM_Channel012, CM_Channel012, CM_Channel012, CM_Channel012, CM_Channel012,

    // PF_RGBAub,   PF_RGBAus,       PF_RGBAi,       PF_RGBAf,       PF_RGBAd
    CM_Channel0123, CM_Channel0123, CM_Channel0123, CM_Channel0123, CM_Channel0123,
    
    // PF_CPLXi,  PF_CPLXf,     PF_CPLXd
    CM_Channel01, CM_Channel01, CM_Channel01,

    // PF_HLSf,     PF_HLSd
    CM_Channel012, CM_Channel012,

    // PF_XYZf,  PF_XYZd
    CM_Channel012, CM_Channel012,

    // PF_Luvf,  PF_Luvd
    CM_Channel012, CM_Channel012,

    // PF_Labf,  PF_Labd
    CM_Channel012, CM_Channel012,

    // PF_Lchf,  PF_Lchd
    CM_Channel012, CM_Channel012,

    // PF_HLabf, PF_HLabd
    CM_Channel012, CM_Channel012,
    0
  };

  return (0 != (iChannelMask & ms_lut[iFormat]));
}

//----------------------------------------------------------------------------
// Check to make sure that Pixels do not have extra padding
//----------------------------------------------------------------------------
typedef boost::enable_if_c<sizeof(PixelLub) == sizeof(uint8),  PixelLub>::type TestPixelLub;
typedef boost::enable_if_c<sizeof(PixelLus) == sizeof(uint16), PixelLus>::type TestPixelLus;
typedef boost::enable_if_c<sizeof(PixelLi)  == sizeof(int32),  PixelLi>::type TestPixelLi;
typedef boost::enable_if_c<sizeof(PixelLl)  == sizeof(int64),  PixelLl>::type TestPixelLl;
typedef boost::enable_if_c<sizeof(PixelLf)  == sizeof(float),  PixelLf>::type TestPixelLf;
typedef boost::enable_if_c<sizeof(PixelLd)  == sizeof(double), PixelLd>::type TestPixelLd;

typedef boost::enable_if_c<sizeof(PixelLAub) == 2*sizeof(uint8),  PixelLAub>::type TestPixelLAub;
typedef boost::enable_if_c<sizeof(PixelLAus) == 2*sizeof(uint16), PixelLAus>::type TestPixelLAus;
typedef boost::enable_if_c<sizeof(PixelLAi)  == 2*sizeof(int32),  PixelLAi>::type TestPixelLAi;
typedef boost::enable_if_c<sizeof(PixelLAl)  == 2*sizeof(int64),  PixelLAl>::type TestPixelLAl;
typedef boost::enable_if_c<sizeof(PixelLAf)  == 2*sizeof(float),  PixelLAf>::type TestPixelLAf;
typedef boost::enable_if_c<sizeof(PixelLAd)  == 2*sizeof(double), PixelLAd>::type TestPixelLAd;

typedef boost::enable_if_c<sizeof(PixelComplexi) == 2*sizeof(int32),  PixelComplexi>::type TestPixelComplexi;
typedef boost::enable_if_c<sizeof(PixelComplexf) == 2*sizeof(float),  PixelComplexf>::type TestPixelComplexf;
typedef boost::enable_if_c<sizeof(PixelComplexd) == 2*sizeof(double), PixelComplexd>::type TestPixelComplexd;

typedef boost::enable_if_c<sizeof(PixelRGBub) == 3*sizeof(uint8),  PixelRGBub>::type TestPixelRGBub;
typedef boost::enable_if_c<sizeof(PixelRGBus) == 3*sizeof(uint16), PixelRGBus>::type TestPixelRGBus;
typedef boost::enable_if_c<sizeof(PixelRGBi)  == 3*sizeof(int32),  PixelRGBi>::type TestPixelRGBi;
typedef boost::enable_if_c<sizeof(PixelRGBl)  == 3*sizeof(int64),  PixelRGBl>::type TestPixelRGBl;
typedef boost::enable_if_c<sizeof(PixelRGBf)  == 3*sizeof(float),  PixelRGBf>::type TestPixelRGBf;
typedef boost::enable_if_c<sizeof(PixelRGBd)  == 3*sizeof(double), PixelRGBd>::type TestPixelRGBd;

typedef boost::enable_if_c<sizeof(PixelHLSf) == 3*sizeof(float),  PixelHLSf>::type TestPixelHLSf;
typedef boost::enable_if_c<sizeof(PixelHLSd) == 3*sizeof(double), PixelHLSd>::type TestPixelHLSd;

typedef boost::enable_if_c<sizeof(PixelXYZf) == 3*sizeof(float),  PixelXYZf>::type TestPixelXYZf;
typedef boost::enable_if_c<sizeof(PixelXYZd) == 3*sizeof(double), PixelXYZd>::type TestPixelXYZd;

typedef boost::enable_if_c<sizeof(PixelLabf) == 3*sizeof(float),  PixelLabf>::type TestPixelLabf;
typedef boost::enable_if_c<sizeof(PixelLabd) == 3*sizeof(double), PixelLabd>::type TestPixelLabd;

typedef boost::enable_if_c<sizeof(PixelLuvf) == 3*sizeof(float),  PixelLuvf>::type TestPixelLuvf;
typedef boost::enable_if_c<sizeof(PixelLuvd) == 3*sizeof(double), PixelLuvd>::type TestPixelLuvd;

typedef boost::enable_if_c<sizeof(PixelLchf) == 3*sizeof(float),  PixelLchf>::type TestPixelLchf;
typedef boost::enable_if_c<sizeof(PixelLchd) == 3*sizeof(double), PixelLchd>::type TestPixelLchd;

typedef boost::enable_if_c<sizeof(PixelHLabf) == 3*sizeof(float),  PixelHLabf>::type TestPixelHLabf;
typedef boost::enable_if_c<sizeof(PixelHLabd) == 3*sizeof(double), PixelHLabd>::type TestPixelHLabd;

typedef boost::enable_if_c<sizeof(PixelRGBAub) == 4*sizeof(uint8),  PixelRGBAub>::type TestPixelRGBAub;
typedef boost::enable_if_c<sizeof(PixelRGBAus) == 4*sizeof(uint16), PixelRGBAus>::type TestPixelRGBAus;
typedef boost::enable_if_c<sizeof(PixelRGBAi)  == 4*sizeof(int32),  PixelRGBAi>::type TestPixelRGBAi;
typedef boost::enable_if_c<sizeof(PixelRGBAl)  == 4*sizeof(int64),  PixelRGBAl>::type TestPixelRGBAl;
typedef boost::enable_if_c<sizeof(PixelRGBAf)  == 4*sizeof(float),  PixelRGBAf>::type TestPixelRGBAf;
typedef boost::enable_if_c<sizeof(PixelRGBAd)  == 4*sizeof(double), PixelRGBAd>::type TestPixelRGBAd;


//----------------------------------------------------------------------------
// explicit instantiations
//----------------------------------------------------------------------------

// 1D : Grey
template struct PixelL<uint8>;
template struct PixelL<uint16>;
template struct PixelL<int32>;
template struct PixelL<float>;
template struct PixelL<double>;

// 2D : Complex, GreyAlpha 
template struct PixelComplex<int32>;
template struct PixelComplex<float>;
template struct PixelComplex<double>;

template struct PixelLA<uint8>;
template struct PixelLA<uint16>;
template struct PixelLA<int32>;
template struct PixelLA<float>;
template struct PixelLA<double>;

// 3D : Colors 
// RGB, HLS, CIE XYZ, Lab, Luv, Lch, Hunter Lab
template struct PixelRGB<uint8>;
template struct PixelRGB<uint16>;
template struct PixelRGB<int32>;
template struct PixelRGB<float>;
template struct PixelRGB<double>;

template struct PixelHLS<float>;
template struct PixelHLS<double>;

template struct PixelXYZ<float>;
template struct PixelXYZ<double>;

template struct PixelLab<float>;
template struct PixelLab<double>;

template struct PixelLuv<float>;
template struct PixelLuv<double>;

template struct PixelLch<float>;
template struct PixelLch<double>;

template struct PixelHLab<float>;
template struct PixelHLab<double>;

// 4D : Extended Colors
template struct PixelRGBA<uint8>;
template struct PixelRGBA<uint16>;
template struct PixelRGBA<int32>;
template struct PixelRGBA<float>;
template struct PixelRGBA<double>;

// extra
template struct PixelL<int64>;
template struct PixelLA<int64>;
template struct PixelRGB<int64>;
template struct PixelRGBA<int64>;

} // namespace Image
} // namespace eLynx
