//============================================================================
//  ImageEdgeProcessingImpl.cpp                        Image.Component package
//============================================================================
//  Usage : image local to point processing interface implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/ImageEdgeProcessingImpl.h>

// external
#include <elx/math/KernelCollection.h>
#include <elx/image/ImageLocalProcessingImpl.h>
#include <elx/image/ImageOperatorsImpl.h>

// --- edges detection filters
#include "EdgeProcessing/Roberts.hpp"
#include "EdgeProcessing/ZeroCrossing.hpp"
#include "EdgeProcessing/NonMaxSuppression.hpp"
#include "EdgeProcessing/Threshold.hpp"
#include "EdgeProcessing/Canny.hpp"
#include "EdgeProcessing/Gradient.hpp"
#include "EdgeProcessing/ImageSegmentation.hpp"

using namespace eLynx::Math;

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EEdgeDetector iType)
{
  static const char * ms_lutDsc[] =
  {
    "Pixel difference", "Separated pixel difference", "Roberts",
    "Sobel", "Prewitt", "FreiChen"
  };
  return ms_lutDsc[iType];
} // elxToString

//----------------------------------------------------------------------------
//  
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EEdgeDetector elxToEEdgeDetector(const char * iprType)
{
  static std::map<std::string, EEdgeDetector> ms_lut;
  if (ms_lut.empty())
  {
    ms_lut.insert(make_pair(std::string("ED_PixelDifference"),ED_PixelDifference));
    ms_lut.insert(make_pair(std::string("ED_Basic"),ED_Basic));
    ms_lut.insert(make_pair(std::string("ED_Roberts"),ED_Roberts));
    ms_lut.insert(make_pair(std::string("ED_Sobel"),ED_Sobel));
    ms_lut.insert(make_pair(std::string("ED_Prewitt"),ED_Prewitt));
    ms_lut.insert(make_pair(std::string("ED_FreiChen"),ED_FreiChen));
  }
  return ms_lut[std::string(iprType)];
} // elxToEEdgeDetector

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EEdgeGradient iType)
{
  static const char * ms_lutDsc[] =
  {
    "North", "South", "East", "West",
    "North-East", "North-West", "South-East", "South-West",
    "Vertical", "Horizontal", "Diagonal NW-SE", "Diagonal SW-NE",
    "Fast", "Fast Diagonal", "Accurate", "Accurate Diagonal", 
    "Max 2", "Max 2 Diagonal", "Max 4"
  };
  return ms_lutDsc[iType];
} // elxToString

//----------------------------------------------------------------------------
//  elxToEEdgeGradient
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EEdgeGradient elxToEEdgeGradient(const char* iprType)
{
  static std::map<std::string, EEdgeGradient> ms_lut;
  if (ms_lut.empty())
  {
    ms_lut.insert(make_pair(std::string("EG_North"), EG_North));
    ms_lut.insert(make_pair(std::string("EG_South"), EG_South));
    ms_lut.insert(make_pair(std::string("EG_East"), EG_East));
    ms_lut.insert(make_pair(std::string("EG_West"), EG_West));
    ms_lut.insert(make_pair(std::string("EG_NorthEast"), EG_NorthEast));
    ms_lut.insert(make_pair(std::string("EG_NorthWest"), EG_NorthWest));
    ms_lut.insert(make_pair(std::string("EG_SouthEast"), EG_SouthEast));
    ms_lut.insert(make_pair(std::string("EG_SouthWest"), EG_SouthWest));
    ms_lut.insert(make_pair(std::string("EG_Vertical"), EG_Vertical));
    ms_lut.insert(make_pair(std::string("EG_Horizontal"), EG_Horizontal));
    ms_lut.insert(make_pair(std::string("EG_DiagonalNWSE"), EG_DiagonalNWSE));
    ms_lut.insert(make_pair(std::string("EG_DiagonalSWNE"), EG_DiagonalSWNE));
    ms_lut.insert(make_pair(std::string("EG_Fast"), EG_Fast));
    ms_lut.insert(make_pair(std::string("EG_FastDiagonal"), EG_FastDiagonal));
    ms_lut.insert(make_pair(std::string("EG_Accurate"), EG_Accurate));
    ms_lut.insert(make_pair(std::string("EG_AccurateDiagonal"), EG_AccurateDiagonal));
    ms_lut.insert(make_pair(std::string("EG_Max2"), EG_Max2));
    ms_lut.insert(make_pair(std::string("EG_Max2Diagonal"), EG_Max2Diagonal));
    ms_lut.insert(make_pair(std::string("EG_Max4"), EG_Max4));
  }
  return ms_lut[std::string(iprType)];
} // elxToEEdgeGradient

//----------------------------------------------------------------------------
//  elxGetDirection
//----------------------------------------------------------------------------
ECompassDirection elxGetDirection(EEdgeGradient iGradient)
{
  static const ECompassDirection ms_lut[] =
  {
    CD_North, CD_South, CD_East, CD_West, 
    CD_NorthEast, CD_NorthWest, CD_SouthEast, CD_SouthWest,
    CD_North, CD_East, CD_NorthWest, CD_SouthWest,
    CD_North,CD_North,CD_North,CD_North,
    CD_North,CD_North,CD_North
  };
  return ms_lut[iGradient];

} // elxGetDirection

//----------------------------------------------------------------------------
//  elxGetKernel
//----------------------------------------------------------------------------
ConvolutionKerneld elxGetKernel(
    EEdgeDetector iDetector, 
    ECompassDirection iDirection)
{
  switch (iDetector)
  { 
    case ED_PixelDifference:  return elxMakePixelDifference3x3d().Rotated(iDirection);
    case ED_Basic:     return elxMakeSeparatedPixelDifference3x3d().Rotated(iDirection);
    case ED_Roberts:   return elxMakeRoberts3x3d().Rotated(iDirection);
    case ED_Sobel:     return elxMakeSobel3x3d().Rotated(iDirection);
    case ED_Prewitt:   return elxMakePrewitt3x3d().Rotated(iDirection);
    case ED_FreiChen:  return elxMakeFreiChen3x3d().Rotated(iDirection);
    default:           return ConvolutionKerneld(3,3);
  }

} // elxGetKernel


//----------------------------------------------------------------------------
//  elxGetKernel
//----------------------------------------------------------------------------
ExportedByImage ConvolutionKerneld elxGetKernel(
    EEdgeDetector iDetector,
    EEdgeGradient iGradient)
{
  const ECompassDirection compass = elxGetDirection(iGradient);
  return elxGetKernel(iDetector, compass);

} // elxGetKernel

IImageEdgeProcessing::~IImageEdgeProcessing() {}

// Function definitions from ImageSegmentation.hpp
namespace {

//----------------------------------------------------------------------------
//  Iterates over the component and marks non-boundary points
//----------------------------------------------------------------------------
template <>
void elxSetFlags<4>(
    std::map<int32, uint32>& ioQ, 
    uint32 iW)
{
  typedef std::map<int32, uint32>::iterator ComponentIterator;
    ComponentIterator itBegin =  ioQ.begin(); 
    ComponentIterator itEnd =  ioQ.end();
  for (ComponentIterator it = itBegin; it != itEnd; ++it)
  {
    if (it->second & POINT_INTERNAL)
      continue;
    it->second &= POINT_NOT_USED;
    if ((ioQ.find(it->first - iW) != itEnd) &&
        (ioQ.find(it->first -  1) != itEnd) &&
        (ioQ.find(it->first +  1) != itEnd) &&
        (ioQ.find(it->first + iW) != itEnd))
      it->second |= POINT_INTERNAL;
  } 
}

template <>
void elxSetFlags<8>(
    std::map<int32, uint32>& ioQ, 
    uint32 iW)
{
  typedef std::map<int32, uint32>::iterator ComponentIterator;
  ComponentIterator itBegin = ioQ.begin(); 
  ComponentIterator itEnd   = ioQ.end();

  for (ComponentIterator it = itBegin; it != itEnd; ++it)
  {
    if (it->second & POINT_INTERNAL)
      continue;
    if ((ioQ.find(it->first - iW - 1) != itEnd) &&
        (ioQ.find(it->first - iW)     != itEnd) &&
        (ioQ.find(it->first - iW + 1) != itEnd) &&
        (ioQ.find(it->first      - 1) != itEnd) &&
        (ioQ.find(it->first      + 1) != itEnd) &&
        (ioQ.find(it->first + iW - 1) != itEnd) &&
        (ioQ.find(it->first + iW)     != itEnd) &&
        (ioQ.find(it->first + iW + 1) != itEnd))
      it->second |= POINT_INTERNAL;
  } 
}

//----------------------------------------------------------------------------
//  Returns true if Pixel represented by iPointCoord is connected to iComponent
//----------------------------------------------------------------------------
template <>
inline
bool elxAreConnected<4>(
    int32 iPointCoord, 
    std::map<int32,uint32>& iComponent, 
    uint32 iW)
{
  typedef std::map<int32,uint32>::iterator MapIterator;
  MapIterator itPointEnd = iComponent.end();

  if (iComponent.find(iPointCoord - iW) != itPointEnd)
    return true;
  else if (iComponent.find(iPointCoord - 1) != itPointEnd)
    return true;
  else if (iComponent.find(iPointCoord + 1) != itPointEnd)
    return true;
  else if (iComponent.find(iPointCoord + iW) != itPointEnd)
    return true;
  else
    return false;
}
  
template <>
inline
bool elxAreConnected<8>(
    int32 iPointCoord, 
    std::map<int32,uint32>& iComponent, 
    uint32 iW)
{
  typedef std::map<int32,uint32>::iterator MapIterator;
  MapIterator itPointEnd = iComponent.end();

  if (iComponent.find(iPointCoord - iW -1) != itPointEnd)
    return true;
  else if (iComponent.find(iPointCoord - iW) != itPointEnd)
    return true;
  else if (iComponent.find(iPointCoord - iW  + 1) != itPointEnd)
    return true;
  else if (iComponent.find(iPointCoord - 1) != itPointEnd)
    return true;
  else if (iComponent.find(iPointCoord + 1) != itPointEnd)
    return true;
  else if (iComponent.find(iPointCoord + iW - 1) != itPointEnd)
    return true;
  else if (iComponent.find(iPointCoord + iW) != itPointEnd)
    return true;
  else if (iComponent.find(iPointCoord + iW + 1) != itPointEnd)
    return true;
  else
    return false;
}

//----------------------------------------------------------------------------
//  Dilates component ioC constrained by component ioQ
//  oC contains the newly added points which are marked as non-available for
// the other components within ioQ
// Structural element is 1 1 1
//                       1 1 1
//                       1 1 1
// The point is eligible for the dilation only if
//    -- it is boundary points
//    -- does not already belong to a dam
//----------------------------------------------------------------------------
bool elxDilateComponent(
    std::map<int32, uint32>& ioC, 
    std::map<int32, uint32>& ioQ, 
    const std::set<int32>& iDam, 
    int32 iW, 
    uint32 iConnectivity, 
    std::map<int32, uint32>& oC)
{
  const static Math::Point2i neighbours[8] = { 
    Math::Point2i(-1, -1),  Math::Point2i(0, -1), Math::Point2i(1, -1),
    Math::Point2i(-1,  0),                        Math::Point2i(1,  0),
    Math::Point2i(-1,  1),  Math::Point2i(0,  1), Math::Point2i(1,  1)
  }; 

  std::map<int32, uint32>::iterator end = ioC.end();
  for (std::map<int32, uint32>::iterator it = ioC.begin(); it != end; ++it)
  {
    if (it->second & POINT_INTERNAL || elxIsConstrained(iDam, it->first))
       continue;

    int32 w = it->first % iW;
    for (uint32 j = 0; j < 8; ++j)
    {
      int32 x = w + neighbours[j]._x;
      if (x < 0 || x  >= iW)
        continue;
      int32 point = it->first + neighbours[j]._y*iW + neighbours[j]._x;
      if (!elxIsConstrained(ioC, point) && elxIsAvailable(ioQ, point)/* &&
          !elxIsConstrained(iDam, point) */)
        oC.insert(std::make_pair(point, 0));
    }

    // Mark the dilated point as internal (non-boundary)
    it->second |= POINT_INTERNAL;

    // temporarely mark it as anavailable to make sure that 
    // this point won't be dilated one more time in other components 
    // constrained by ioQ
    std::map<int32, uint32>::iterator mapIt = ioQ.find(it->first);
    BOOST_ASSERT(mapIt != ioQ.end());
    mapIt->second |= POINT_USED;
  }  
  return !oC.empty();

} // elxDilateComponent


//----------------------------------------------------------------------------
//  Build Dam between multiple components iC constrained by component ioQ
//  oQ contains the points which originally belong to ioQ and were added
//  to the one of the iC component during the dilation and removed from the 
//  ioQ to prevent them from being added to more then one component. 
//  They will be added back to the ioQ after Dam is built.
//----------------------------------------------------------------------------
void elxBuildDam(
    std::map<int32, uint32>** iC, 
    size_t iSize, 
    uint32 iConnectivity, 
    std::map<int32, uint32>& ioQ, 
    uint32 iW, 
    std::set<int32>& oDam)
{
  size_t i;

  // Array of components to hold added points during the dilation 
  // for each input component
  boost::scoped_array<std::map<int32, uint32> > 
    dilatedC(new std::map<int32, uint32>[iSize]);
  boost::scoped_array<bool> isDilated (new bool[iSize]);

  // Dilate each component
  for (i=0; i<iSize; ++i)
    isDilated[i] = elxDilateComponent(
      *iC[i], ioQ, oDam,  iW, iConnectivity, dilatedC[i]);
    
  // Find intersection points between all pairs of dilated components
  // The intersection points belong to the Dam
  for (i=0; i<iSize - 1; ++i)
  {
    if (isDilated[i]) 
      for (size_t j=i+1; j<iSize; ++j)
        if (isDilated[j])
          elxFindIntersection(dilatedC[i], dilatedC[j], oDam);
  }

  // Merge new and old points
  for (i=0; i<iSize; ++i)
  {
    if (isDilated[i])
      iC[i]->insert(dilatedC[i].begin(), dilatedC[i].end());
  }

  // Sort out non-dilated components
  std::map<int32, uint32>** lastDilated = iC;
  std::map<int32, uint32>** first = iC;
  std::map<int32, uint32>** last = iC + iSize;
  for ( ; first != last; ++first)
    if (isDilated[first - iC]) 
      *lastDilated++ = *first;
  size_t newSize = lastDilated - iC;
  
  dilatedC.reset();
  isDilated.reset();
 
  // Recursive call untill nothing left to dilate
  if (newSize < 2)
    return;
  else
    elxBuildDam(iC, newSize, iConnectivity, ioQ, iW, oDam);

} // elxBuildDam

} // anonymous-namespace


//----------------------------------------------------------------------------
//  explicit instantiation of all image types
//----------------------------------------------------------------------------
elxINSTANTIATE_CLASS_FOR_ALL_IMAGE_TYPES( ImageEdgeProcessingImpl );

} // namespace Image
} // namespace eLynx
