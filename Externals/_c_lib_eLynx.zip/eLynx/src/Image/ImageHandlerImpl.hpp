//============================================================================
//  ImageHandlerImpl.hpp                               Image.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __ImageHandlerImpl_hpp__
#define __ImageHandlerImpl_hpp__

#include <elx/image/ImageImpl.h>

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  CreateImageFullDynamicUByte : create an image with uint8 resolution 
//                                covering full dynamic range
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
template <class Pixel>
boost::shared_ptr<AbstractImage> 
  ImageHandlerImpl<Pixel>::CreateImageUByteFullDynamic(
    const AbstractImage& iImage) const
{
  if (!iImage.IsValid())
    return boost::shared_ptr<AbstractImage>();
  
  const uint32 w = iImage.GetWidth();
  const uint32 h = iImage.GetHeight();

  typedef typename Pixel::type T;
  const T * prSrc = NULL;
  uint8 * prDst = NULL;
  uint8 * prEnd = NULL;
  
  // for the moment only L & RGB input images are supported
  boost::shared_ptr<AbstractImage> spImage;
  if (iImage.IsL())
  {
    const ImageImpl<Pixel>& image = static_cast< const ImageImpl<Pixel>& >(iImage);
    prSrc = image.GetSamples();
  
    ImageLub * psImage = new ImageLub(w,h);
    spImage = boost::shared_ptr<AbstractImage>( psImage );
    prDst = psImage->GetSamples();
    prEnd = psImage->GetSamplesEnd();
  }
  else if (iImage.IsRGB())
  {
    const ImageImpl<Pixel>& image = static_cast< const ImageImpl<Pixel>& >(iImage);
    prSrc = image.GetSamples();
  
    ImageRGBub * psImage = new ImageRGBub(w,h);
    spImage = boost::shared_ptr<AbstractImage>( psImage );
    prDst = psImage->GetSamples();
    prEnd = psImage->GetSamplesEnd();
  }
  else
    elxFIXME;

  double min, max ,v;
  GetAnalyseHandler().ComputeMinMax(iImage, min,max, false);
  
  if (min == max)
  { 
    do { *prDst = 255;  } while (++prDst != prEnd);
  }
  else
  {
    const double s = 255.0/(max - min);
    do 
    { 
      v = s*(double(*prSrc) - min);
      *prDst = uint8(int32(v + 0.5));
    } 
    while (++prSrc, ++prDst != prEnd);
  }
  return spImage;
  
} // CreateImageUByteFullDynamic

} // namespace Image
} // namespace eLynx

#endif // __ImageHandlerImpl_hpp__
