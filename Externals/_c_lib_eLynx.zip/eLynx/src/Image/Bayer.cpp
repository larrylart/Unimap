//============================================================================
//  Bayer.cpp                                          Image.Component package
//============================================================================
//  Usefull links :
//  http://www-ise.stanford.edu/~tingchen/main.htm
//  http://www.hindawi.com/GetArticle.aspx?doi=10.1155/ASP/2006/25072&e=ref
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <string>
#include <map>

#include <elx/image/Bayer.h>
#include <elx/image/BayerHandlerImpl.h>

#include <elx/math/MathCore.h>
#include <elx/math/Ramp.h>
#include <elx/math/ConvolutionKernel.h>
#include <elx/image/Pixels.h>
#include <elx/image/ImageGeometryImpl.h>
#include <elx/image/ImagePointProcessingImpl.h>
#include <elx/image/ImageLocalProcessingImpl.h>
#include <elx/image/ImageMorphologicalProcessingImpl.h>
#include <elx/image/ImageConversion.h>


#include "Bayer/Balance.hpp"
#include "Bayer/Mean.hpp"
#include "Bayer/StdDev.hpp"
#include "Bayer/Affine.hpp"
#include "Bayer/CreateBayer.hpp"
#include "Bayer/CreateRGB.hpp"

namespace eLynx {
namespace Image {

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EBayerMatrix iBayer)
{
  static const char * ms_lut[5] =
  {
    "None", "GRBG", "GBRG", "RGGB", "BGGR"
  };
  return ms_lut[iBayer];

} // elxToString

//----------------------------------------------------------------------------
//  elxToEBayerMatrix
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EBayerMatrix elxToEBayerMatrix(const char * iprType)
{
  static std::map<std::string, EBayerMatrix> ms_lut;
  if (ms_lut.empty())
  {
    ms_lut.insert(make_pair(std::string("BM_None"),BM_None));
    ms_lut.insert(make_pair(std::string("BM_GRBG"),BM_GRBG));
    ms_lut.insert(make_pair(std::string("BM_GBRG"),BM_GBRG));
    ms_lut.insert(make_pair(std::string("BM_RGGB"),BM_RGGB));
    ms_lut.insert(make_pair(std::string("BM_BGGR"),BM_BGGR));
  }
  std::map<std::string, EBayerMatrix>::iterator it = 
    ms_lut.find(std::string(iprType));
  return it == ms_lut.end() ? BM_None : it->second;
}

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EBayerToGreyConversion iMethod)
{
  static const char * ms_lut[BGC_Max] =
  {
    "As is"
  };

  return ms_lut[iMethod];

} // elxToString

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EBayerToColorConversion iMethod)
{
  static const char * ms_lut[BCC_Max] =
  {
    "Grey", "Bin2x2", "Raw", "Nearest", "Bilinear", "Malvar He Cutler", "Bicubic", 
    "David Cok", "Freeman", 
    "Adaptive", "Laroche-Prescott", "Hamilton-Adams", "Hamilton", "Adams", "Wang-Lin-Xue",
    "Ron Kimmel", "Lukin-Kubasov", "Chuan-kai Lin", "Wemmiao Lu", 
    "PRI", "PMI", "VNG", "AHD", "Chang-Tan"
#ifdef USE_LAST_BAYER_METHODS
    ,"AWD", "LCH", "RACC"
#endif
  };
  return ms_lut[iMethod];

} // elxToString


//----------------------------------------------------------------------------
//  elxGetBayerAt : static table out of method for performance reason
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
static EBayerMatrix s_lutBayerGetAt[5][4] =
{
  //   +-+-+-+  +-+-+-+  +-+-+-+  +-+-+-+
  //   |x|.| |  | |x|.|  | | | |  | | | |
  //   |.|.| |  | |.|.|  |x|.| |  | |x|.|
  //   | | | |  | | | |  |.|.| |  | |.|.|
  //   +-+-+-+  +-+-+-+  +-+-+-+  +-+-+-+
  // { Value1,  Value2,  Value3,  Value4 }

  // +-+-+
  // |L|L| BM_None
  // |L|L|
  // +-+-+
  { BM_None, BM_None, BM_None, BM_None },

  // +-+-+-+
  // |G|R|G|
  // |B|G|B|  BM_GRBG
  // |G|R|G|
  // +-+-+-+
  { BM_GRBG, BM_RGGB, BM_BGGR, BM_GBRG },

  // +-+-+-+
  // |G|B|G|
  // |R|G|R|  BM_GBRG
  // |G|B|G|
  // +-+-+-+
  { BM_GBRG, BM_BGGR, BM_RGGB, BM_GRBG },

  // +-+-+-+
  // |R|G|R|
  // |G|B|G|  BM_RGGB
  // |R|G|R|
  // +-+-+-+
  { BM_RGGB, BM_GRBG, BM_GBRG, BM_BGGR },

  // +-+-+-+
  // |B|G|B|
  // |G|R|G|  BM_BGGR
  // |B|G|B|
  // +-+-+-+
  { BM_BGGR, BM_GBRG, BM_GRBG, BM_RGGB }
};

EBayerMatrix elxGetBayerAt(EBayerMatrix iBayer, uint32 iX, uint32 iY)
{
  const int32 index = (iX & 1) + 2*(iY & 1);
  return s_lutBayerGetAt[(int32)iBayer][index];

} // elxGetBayerAt


//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
static EBayerMatrix s_lutBayerLeftOrRight[5] =
  // BM_None    BM_GRBG    BM_GBRG   BM_RGGB   BM_BGGR
  // +-+-+      +-+-+      +-+-+     +-+-+     +-+-+
  // |L|L|      |G|R|      |G|B|     |R|G|     |B|G|
  // |L|L|      |B|G|      |R|G|     |G|B|     |G|R|
  // +-+-+      +-+-+      +-+-+     +-+-+     +-+-+
  { BM_None,    BM_RGGB,   BM_BGGR,  BM_GRBG,  BM_GBRG };

EBayerMatrix elxGetBayerLeft(EBayerMatrix iBayer)  { return s_lutBayerLeftOrRight[iBayer]; }
EBayerMatrix elxGetBayerRight(EBayerMatrix iBayer) { return s_lutBayerLeftOrRight[iBayer]; }

static EBayerMatrix s_lutBayerUpOrDown[5] =
  // BM_None    BM_GRBG    BM_GBRG   BM_RGGB   BM_BGGR
  // +-+-+      +-+-+      +-+-+     +-+-+     +-+-+
  // |L|L|      |G|R|      |G|B|     |R|G|     |B|G|
  // |L|L|      |B|G|      |R|G|     |G|B|     |G|R|
  // +-+-+      +-+-+      +-+-+     +-+-+     +-+-+
  { BM_None,    BM_BGGR,   BM_RGGB,  BM_GBRG,  BM_GRBG };

EBayerMatrix elxGetBayerUp(EBayerMatrix iBayer)    { return s_lutBayerUpOrDown[iBayer]; }
EBayerMatrix elxGetBayerDown(EBayerMatrix iBayer)  { return s_lutBayerUpOrDown[iBayer]; }


//----------------------------------------------------------------------------
//  elxFlipHorizontal
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EBayerMatrix elxFlipHorizontal(EBayerMatrix iBayer, uint32 iWidth)
{
  EBayerMatrix ms_lut[5] =
  {
    // +-+-+ 
    // |L|L| BM_None
    // |L|L|
    // +-+-+
    BM_None,

    // +-+-+-+-+    +-+-+-+-+   +-+-+-+    +-+-+-+
    // |G|R|G|R|    |R|G|R|G|   |G|R|G|    |G|R|G|
    // |B|G|B|G| => |G|B|G|B|   |B|G|B| => |B|G|B|  BM_GRBG
    // +-+-+-+-+    +-+-+-+-+   +-+-+-+    +-+-+-+
    BM_RGGB,

    // +-+-+-+-+    +-+-+-+-+   +-+-+-+    +-+-+-+
    // |G|B|G|B|    |B|G|B|G|   |G|B|G|    |G|B|G|
    // |R|G|R|G| => |G|R|G|R|   |R|G|R| => |R|G|R|  BM_GBRG
    // +-+-+-+-+    +-+-+-+-+   +-+-+-+    +-+-+-+
    BM_BGGR,

    // +-+-+-+-+    +-+-+-+-+   +-+-+-+    +-+-+-+
    // |R|G|R|G|    |G|R|G|R|   |R|G|R|    |R|G|R|
    // |G|B|G|B| => |B|G|B|G|   |G|B|G| => |G|B|G|  BM_RGGB
    // +-+-+-+-+    +-+-+-+-+   +-+-+-+    +-+-+-+
    BM_GRBG,

    // +-+-+-+-+    +-+-+-+-+   +-+-+-+    +-+-+-+
    // |B|G|B|G|    |G|B|G|B|   |B|G|B|    |B|G|B|
    // |G|R|G|R| => |R|G|R|G|   |G|R|G| => |G|R|G|  BM_BGGR
    // +-+-+-+-+    +-+-+-+-+   +-+-+-+    +-+-+-+
    BM_GBRG
  };

  if (iWidth & 1)
    return iBayer;

  return ms_lut[ (int32)iBayer ];

} // elxFlipHorizontal


//----------------------------------------------------------------------------
//  elxFlipVertical
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EBayerMatrix elxFlipVertical(EBayerMatrix iBayer, uint32 iHeight)
{
  EBayerMatrix ms_lut[5] =
  {
    // +-+-+ 
    // |L|L| BM_None
    // |L|L|
    // +-+-+
    BM_None,

    // +-+-+    +-+-+   +-+-+    +-+-+
    // |G|R|    |B|G|   |G|R|    |G|R|
    // |B|G| => |G|R|   |B|G| => |B|G|  BM_GRBG
    // |G|R|    |B|G|   |G|R|    |G|R|
    // |B|G|    |G|R|   +-+-+    +-+-+
    // +-+-+    +-+-+
    BM_BGGR,

    // +-+-+    +-+-+   +-+-+    +-+-+
    // |G|B|    |R|G|   |G|B|    |G|B|
    // |R|G| => |G|B|   |R|G| => |R|G|  BM_GBRG
    // |G|B|    |R|G|   |G|B|    |G|B|
    // |R|G|    |G|R|   +-+-+    +-+-+
    // +-+-+    +-+-+
    BM_RGGB,

    // +-+-+    +-+-+   +-+-+    +-+-+
    // |R|G|    |G|B|   |R|G|    |R|G|
    // |G|B| => |R|G|   |G|B| => |G|B|  BM_RGGB
    // |R|G|    |G|B|   |R|G|    |R|G|
    // |G|B|    |R|G|   +-+-+    +-+-+
    // +-+-+    +-+-+
    BM_GBRG,

    // +-+-+    +-+-+   +-+-+    +-+-+
    // |B|G|    |G|R|   |B|G|    |B|G|
    // |G|R| => |B|G|   |G|R| => |G|R|  BM_BGGR
    // |B|G|    |G|R|   |B|G|    |B|G|
    // |G|R|    |B|G|   +-+-+    +-+-+
    // +-+-+    +-+-+
    BM_GRBG
  };

  if (iHeight & 1)
    return iBayer;

  return ms_lut[ (int32)iBayer ];

} // elxFlipVertical

//----------------------------------------------------------------------------
//  elxFlip
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EBayerMatrix elxFlip(EBayerMatrix iBayer, EFlipPlane iFlipPlane, uint32 iWidth, uint32 iHeight)
{
  switch(iFlipPlane)
  {
    case FP_Horizontal: return elxFlipHorizontal(iBayer, iWidth);
    case FP_Vertical:   return elxFlipVertical(iBayer, iHeight);
    case FP_Both:       return elxFlipVertical(elxFlipHorizontal(iBayer, iWidth), iHeight);
    case FP_None:
    default:
      return iBayer;
  }

} // elxFlip


//----------------------------------------------------------------------------
//  elxRotate180
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EBayerMatrix elxRotate180(EBayerMatrix iBayer, uint32 iWidth, uint32 iHeight)
{
  return elxFlipHorizontal(elxFlipVertical(iBayer, iHeight), iWidth);

} // elxRotate180


//----------------------------------------------------------------------------
//  elxRotate90Right
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EBayerMatrix elxRotate90Right(EBayerMatrix iBayer, uint32 iHeight)
{
  EBayerMatrix ms_lut[5] =
  {
    BM_None,  //    1234 => 3142
    BM_BGGR,  // BM_GRBG    BGGR
    BM_RGGB,  // BM_GBRG    RGGB
    BM_GRBG,  // BM_RGGB    GRBG
    BM_GBRG   // BM_BGGR    GBRG 
  };
  iBayer = elxGetBayerAt(iBayer, 0, iHeight);
  return ms_lut[ (int32)iBayer ];

} // elxRotate90Right

//----------------------------------------------------------------------------
//  elxRotate90Left
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EBayerMatrix elxRotate90Left(EBayerMatrix iBayer, uint32 iWidth)
{
  EBayerMatrix ms_lut[5] =
  {
    BM_None,  //    1234 => 2413
    BM_RGGB,  // BM_GRBG    RGGB
    BM_BGGR,  // BM_GBRG    BGGR
    BM_GBRG,  // BM_RGGB    GBRG
    BM_GRBG   // BM_BGGR    GRBG
  };
  iBayer = elxGetBayerAt(iBayer, iWidth, 0);
  return ms_lut[ (int32)iBayer ];

} // elxRotate90Left

//----------------------------------------------------------------------------
//  elxRotate
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EBayerMatrix elxRotate(EBayerMatrix iBayer, ERightRotation iRotation, uint32 iWidth, uint32 iHeight)
{
  switch(iRotation)
  {
    case RR_90Left:   return elxRotate90Left(iBayer, iWidth);
    case RR_90Right:  return elxRotate90Right(iBayer, iHeight);
    case RR_180:      return elxRotate180(iBayer, iWidth, iHeight);
    case RR_0:
    default:
      return iBayer;
  }

} // elxRotate


IBayerHandler::~IBayerHandler() {}

//----------------------------------------------------------------------------
// explicit instantiations
//----------------------------------------------------------------------------
static BayerHandlerImpl<uint8>  s_Handlerub;
static BayerHandlerImpl<uint16> s_Handlerus;
static BayerHandlerImpl<int32>  s_Handleri;
static BayerHandlerImpl<float>  s_Handlerf;
static BayerHandlerImpl<double> s_Handlerd;

//----------------------------------------------------------------------------
// Defined in same order as in EPixelFormat declaration
//----------------------------------------------------------------------------
static const IBayerHandler * s_prImageTypeHandler_lut[PF_Undefined] =
{
//   uint8      uint16        integer      float        double
  &s_Handlerub, &s_Handlerus, &s_Handleri, &s_Handlerf, &s_Handlerd,
  NULL,         NULL,         NULL,        NULL,        NULL,
  &s_Handlerub, &s_Handlerus, &s_Handleri, &s_Handlerf, &s_Handlerd,
  NULL,         NULL,         NULL,        NULL,        NULL,
                              NULL,        NULL,        NULL,
                                           NULL,        NULL,
                                           NULL,        NULL,
                                           NULL,        NULL,
                                           NULL,        NULL,
                                           NULL,        NULL,
                                           NULL,        NULL
};

//----------------------------------------------------------------------------
//  elxGetBayerHandler : return IBayerHandler for a given image type
//----------------------------------------------------------------------------
//  public global
//----------------------------------------------------------------------------
const IBayerHandler& elxGetBayerHandler(EPixelFormat iPixelFormat)
{
  elxASSERT(NULL != s_prImageTypeHandler_lut[iPixelFormat]);
  return *s_prImageTypeHandler_lut[iPixelFormat];
}

const IBayerHandler& elxGetBayerHandler(const AbstractImage& iImage)
{
  return elxGetBayerHandler( iImage.GetPixelFormat() );
}

} // namespace Image
} // namespace eLynx
