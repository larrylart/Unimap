//============================================================================
//  ImageRasterizationImpl.cpp                         Image.Component package
//============================================================================
//  Usage : interface for image rasterization primitives implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/image/ImageRasterizationImpl.h>

// --- Rasterization primitive
#include "Rasterization/Render.hpp"
#include "Rasterization/Clear.hpp"
#include "Rasterization/Plot.hpp"
#include "Rasterization/Line.hpp"
#include "Rasterization/Rectangle.hpp"
#include "Rasterization/Ellipse.hpp"
#include "Rasterization/Triangle.hpp"
#include "Rasterization/Fill.hpp"

namespace eLynx {
namespace Image {

IImageRasterization::~IImageRasterization() {}

//----------------------------------------------------------------------------
//  explicit instantiation of all image types
//----------------------------------------------------------------------------
elxINSTANTIATE_CLASS_FOR_ALL_IMAGE_TYPES( ImageRasterizationImpl );

} // namespace Image
} // namespace eLynx
