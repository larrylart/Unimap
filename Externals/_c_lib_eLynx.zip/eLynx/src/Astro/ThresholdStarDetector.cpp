//============================================================================
//  ThresholdStarDetector.cpp                          Astro.Component package
//============================================================================
//  Usage : simple star detector based on pixel threshold implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------

#include <math.h>

#include <stack>

#include <boost/scoped_ptr.hpp>

#include <elx/astro/ThresholdStarDetector.h>
#include <elx/core/CoreException.h>
#include <elx/image/PixelIterator.h>
#include <elx/math/MathCore.h>

#include "ThresholdStarDetector.hpp"

namespace eLynx {
namespace Astro {
	
using namespace eLynx::Image;
 
//----------------------------------------------------------------------------
// constructor

ThresholdStarDetector::ThresholdStarDetector()
{
	// set the absolute value to white
	SetAbsoluteValue(1.0f);
}


//--------------------------------------------------------
// returns threshold value type

EThresholdValue ThresholdStarDetector::GetValueType() const
{
	return _ValueType;
}


//--------------------------------------------------------
// returns absolute threshold value
// if threshold is not of type absolute, exception
// is raised


float ThresholdStarDetector::GetAbsoluteValue() const
{
	// check value type
	if (GetValueType() != tvAbsolute)
		elxThrow(elxErrInvalidContext, elxMsgFormat("Invalid value type (%i).", 
			GetValueType()));
	return _AbsoluteValue;
}


//--------------------------------------------------------
// returns relative threshold value
// if threshold is not of type relative, exception
// is raised


float ThresholdStarDetector::GetRelativeValue() const
{
	// check value type
	if (GetValueType() != tvRelative)
		elxThrow(elxErrInvalidContext, elxMsgFormat("Invalid value type (%i).", 
			GetValueType()));
		
	return _RelativeValue;
}


//--------------------------------------------------------
// returns threshold offset value
// if threshold is not of type offset, exception
// is raised


float ThresholdStarDetector::GetOffsetValue() const
{
	// check value type
	if (GetValueType() != tvOffset)
		elxThrow(elxErrInvalidContext, elxMsgFormat("Invalid value type (%i).", 
			GetValueType()));
		
	return _OffsetValue;
}


//--------------------------------------------------------
// sets the threshold type to absolute and threshold
// value to given value


void ThresholdStarDetector::SetAbsoluteValue(float iValue)
{
	_ValueType = tvAbsolute;
	_AbsoluteValue = iValue;
}


//--------------------------------------------------------
// sets the threshold type to relative and threshold
// value to given value
// checks, if the value is in interval <0, 1>


void ThresholdStarDetector::SetRelativeValue(float iValue)
{
	// check, if the value is from 0 to 1
	if (iValue < 0.0 || iValue >= 1.0)
		elxThrow(elxErrOutOfRange, elxMsgFormat("Value %i out of range <0, 1>.", 
			iValue));
			
	// set the value
	_ValueType = tvRelative;
	_RelativeValue = iValue;
}


//--------------------------------------------------------
// sets the threshold type to offset and threshold
// offset value to given value
// checks, if the value is not positive


void ThresholdStarDetector::SetOffsetValue(float iValue)
{
	// set the value
	_ValueType = tvOffset;
	_OffsetValue = iValue;
}


//--------------------------------------------------------
// computes maximal pixel intensity on the image


float ThresholdStarDetector::GetMaximalIntensity(
	const ImageVariant &iImage) const
{
	if (!iImage.IsLf()) 
		elxThrow(elxErrInvalidParams, 
			elxMsgFormat("Lf image format requested, found %s.", 
				elxToString(iImage.GetPixelFormat())));
		
	// init the result to small value
	float result = 0.0f;
	
	// go through all pixels
	PixelIterator<const PixelLf> pixel = 
		elxConstDowncast<const PixelLf>(iImage.GetImpl()->Begin());
	PixelIterator<const PixelLf> end = 
		elxConstDowncast<const PixelLf>(iImage.GetImpl()->End());
	//const float *pixel = (const float*)iImage.GetMap();
	//const float *end = (const float*)iImage.GetMapEnd();

	while (pixel != end) {

		// compute pixel intensity and update result, if necessary
		if (pixel->_channel[0] > result) result = pixel->_channel[0];
		++pixel;
	}
		
	// return result
	return result;
}


//--------------------------------------------------------
// computes actual threshold value for given image


float ThresholdStarDetector::GetActualThreshold(
	const ImageVariant &iImage) const
{
	// if the threshold is absolute, there is nothing to compute
	if (GetValueType() == tvAbsolute) return GetAbsoluteValue();
	
	// otherwise, we will need the maximal image instensity
	float max_int = GetMaximalIntensity(iImage);
	//printf("image maximal intensity = %g\n", max_int);
	
	// for relative value, compute the actual threshold
	if (GetValueType() == tvRelative) 
		return max_int * GetRelativeValue();
		
	// for offset value, compute the actual threshold
	if (GetValueType() == tvOffset) {
		// prevent underflow of unsigned values
		if (max_int < GetOffsetValue()) return 0.0f;
		else return max_int - GetOffsetValue();
	}

	// we should never get here
  return 1.0f;
}


//--------------------------------------------------------
// applies the threshold to the image and creates
// threshold bitmap

void ThresholdStarDetector::CreatePixelMap(
  const ImageVariant &iImage, float iThreshold, 
  BaseStarDetector::PixelMap &oPixelMap) const
{
	if (!iImage.IsLf()) 
		elxThrow(elxErrInvalidParams, 
			elxMsgFormat("Lf image format requested, found %s.", 
				elxToString(iImage.GetPixelFormat())));
		
	// resize the bitmap to the image size
	oPixelMap.reset(new uint[iImage.GetWidth()*iImage.GetHeight()]());
	
	// init the bitmap iterator
	uint idx = 0;
	
	// go through all image pixels
	// go through all pixels
	PixelIterator<const PixelLf> pixel = 
		elxConstDowncast<const PixelLf>(iImage.GetImpl()->Begin());
	PixelIterator<const PixelLf> end = 
		elxConstDowncast<const PixelLf>(iImage.GetImpl()->End());

	while (pixel != end) 
  {
		// assign proper value to the bitmap
		if(pixel->_channel[0] >= iThreshold)
      elxSPT_SET_STAR(oPixelMap[idx]);

		// shift the iterators to next bit and pixel
		++idx;
		++pixel;
	}
}

//--------------------------------------------------------
// perform recursive star detection
/*
This version does not work properly in case of star having irregular form
like blooming star with bloom direction other the X or Y axies. The problem 
is in the following 
			while (left_x >= 0 && elxSPT_IS_TO_SEE(ioPixelMap[left])) {
}
on the same line star's pixels could be separated by non-star's ones. The above
works properly only if all star's pixels on a single line are connected
void ThresholdStarDetector::DetectStarLine(const ImageVariant &iImage,
  BaseStarDetector::PixelMap &ioPixelMap, uint iIdx, 
  Math::Rectangle2i& ioStarRectangle, Math::Point2d& oStarPosition, 
  double& oStarDiameter, double& oStarIntensity) const
{
	std::stack<uint> point_stack;
	point_stack.push(iIdx);
  
  const uint w = iImage.GetWidth();
  const uint h = iImage.GetHeight(); 
	
	while (!point_stack.empty()) {
		
		uint idx = point_stack.top();
		point_stack.pop();
	
		// check, if the SEEN bit is still set
		if (!elxSPT_IS_TO_SEE(ioPixelMap[idx])) 
      return; 
		
		// get the pointer to image content
		PixelIterator<const PixelLf> image_begin = 
			elxConstDowncast<const PixelLf>(iImage.GetImpl()->Begin());
		
		PixelIterator<const PixelLf> image_pixel = image_begin+idx;
		// init star statistics for first pixel
    int x = idx % w;
    int y = idx / w;
		double center_x = (double(x)+0.5)*(double)(image_pixel->_channel[0]);
		double center_y = (double(y)+0.5)*(double)(image_pixel->_channel[0]);
		double total_luminances = (double)(image_pixel->_channel[0]);
		uint size = 1;
		
		// set SEEN bit for the first pixel
		elxSPT_SET_SEEN(ioPixelMap[idx]);
		
		// include all pixels to the left of the given pixel
		int left_x = x;
		int left = idx;
		if (left_x > 0) {
			left_x--; 
			left--;
			// while not at the beginning of row and pixels are set
			while (left_x >= 0 && elxSPT_IS_TO_SEE(ioPixelMap[left])) {
				// include pixel in star
				image_pixel = image_begin+left;
				center_x += (double)(left_x+0.5)*(double)(image_pixel->_channel[0]);
				center_y += (double)(y+0.5)*(double)(image_pixel->_channel[0]);
				total_luminances += (double)(image_pixel->_channel[0]);
				size++;
				// clear it
				elxSPT_SET_SEEN(ioPixelMap[left]); 
				// and shift the pointers
				left_x--;
				left--;
			}
		}
    
		// include all pixels to the right of the given pixel
		uint right_x = x;
		uint right = idx;
		if (right_x < w-1) {
			right_x++; 
			right++;
			// while not at the end of row and pixels are set
			while (right_x < w && elxSPT_IS_TO_SEE(ioPixelMap[right])) {
				// include pixel in star
				image_pixel = image_begin+right;
				center_x += (double)(right_x+0.5)*(double)(image_pixel->_channel[0]);
				center_y += (double)(y+0.5)*(double)(image_pixel->_channel[0]);
				total_luminances += (double)(image_pixel->_channel[0]);
				size++;
				// clear it
				elxSPT_SET_SEEN(ioPixelMap[right]); 
				// and shift the pointers
				right_x++;
				right++;
			}
		}
		      
		// actualize star
		oStarPosition._x += center_x;
    oStarPosition._y += center_y;
		oStarIntensity += total_luminances;
		oStarDiameter += (double)size;
		
    // update  circumferent rectangle
    if (ioStarRectangle._P0._x > (int)left_x)
      ioStarRectangle._P0._x = left_x;
    if (ioStarRectangle._P1._x < (int)right_x)
      ioStarRectangle._P1._x = right_x;
    if (ioStarRectangle._P0._y > y)
      ioStarRectangle._P0._y = y;
    if (ioStarRectangle._P1._y < y)
      ioStarRectangle._P1._y = y;
		
    // go through upper and lower bitmap line
		for (uint i = left_x+1; i <= right_x-1; i++) {
			
			// if this is not topmost line
			if (y > 0) {
				// get the pixel above
				uint up = left+(i-left_x-w);
				// and include it in star, if the pixel is set
				if (elxSPT_IS_TO_SEE(ioPixelMap[up])) 
          point_stack.push(up);
					  //DetectStarLine(iImage, ioPixelMap, up, i, pt._Y-1, iWidth, iHeight, oStar);
      }
			
			// if this is not bottom line
			if (y < int(h-1)) {
				// get the pixel below
				uint down = left+(i-left_x+w);
				// and include it in star, if the pixel is set
				if (elxSPT_IS_TO_SEE(ioPixelMap[down])) 
          point_stack.push(down);
					  //DetectStarLine(iImage, ioPixelMap, down, i, pt._Y+1, iWidth, iHeight, oStar);
      }
		}
	}

}
*/
void ThresholdStarDetector::DetectStarLine(const ImageVariant &iImage,
  BaseStarDetector::PixelMap &ioPixelMap, uint iIdx, 
  Math::Rectangle2i& ioStarRectangle, Math::Point2d& oStarPosition, 
  double& oStarDiameter, double& oStarIntensity) const
{
	std::stack<uint> point_stack;
	point_stack.push(iIdx);
  
  const int w = iImage.GetWidth();
  const int h = iImage.GetHeight(); 
  
	// get the pointer to image content
	PixelIterator<const PixelLf> image_begin = 
		elxConstDowncast<const PixelLf>(iImage.GetImpl()->Begin());
  const int x_neighbors[4] = {-1, 0, 1, 0};
  const int y_neighbors[4] = {0, -1, 0, 1};
  
	uint size = 0;
	
	while (!point_stack.empty()) 
  {
		uint idx = point_stack.top();
		point_stack.pop();
	
		// check, if the SEEN bit is set
		if (elxSPT_IS_SEEN(ioPixelMap[idx])) 
      continue; 
				
		PixelIterator<const PixelLf> image_pixel = image_begin+idx;
		// init star statistics for first pixel
    int x = idx % w;
    int y = idx / w;
		double center_x = (double(x)+0.5)*(double)(image_pixel->_channel[0]);        
		double center_y = (double(y)+0.5)*(double)(image_pixel->_channel[0]);
		double total_luminances = (double)(image_pixel->_channel[0]);
 		size++;

		// actualize star
		oStarPosition._x += center_x;
    oStarPosition._y += center_y;
		oStarIntensity += total_luminances;
		oStarDiameter += (double)size;

    // update  circumferent rectangle
    if (ioStarRectangle._P0._x > x)
      ioStarRectangle._P0._x = x;
    if (ioStarRectangle._P0._y > y)
      ioStarRectangle._P0._y = y;
    if (ioStarRectangle._P1._x < x)
      ioStarRectangle._P1._x = x;
    if (ioStarRectangle._P1._y < y)
      ioStarRectangle._P1._y = y;
		
		// set SEEN bit for the first pixel
		elxSPT_SET_SEEN(ioPixelMap[idx]);
		
		// include neighboring pixels to the given pixel
    for (uint i = 0; i < 4; ++i)
    {
      int next_x = x + x_neighbors[i];
      int next_y = y + y_neighbors[i];
      // exclude outside the image boundaries pixels
      if (next_x < 0 || next_x >= w || next_y < 0 || next_y >= h)
        continue;
      int next_idx = idx + y_neighbors[i]*w + x_neighbors[i];
     // exclude non-star pixels and already seen ones
      if (!elxSPT_IS_STAR(ioPixelMap[next_idx]) || 
          elxSPT_IS_SEEN(ioPixelMap[next_idx]))
        continue;
      // if we got there then it's star's pixel
      point_stack.push(next_idx);
    }
  }
	oStarDiameter = (double)size;
}

//--------------------------------------------------------

//----------------------------------------------------------------------------
//  explicit instantiation for all Star types
//----------------------------------------------------------------------------
template void ThresholdStarDetector::DetectStars<Star>(
  const Image::ImageVariant &iImage, std::vector<Star> &oStars) const;
template void ThresholdStarDetector::DetectStars<BloomingStar>(
  const Image::ImageVariant &iImage, std::vector<BloomingStar> &oStars) const;
  
} // namespace Astro
} // namespace eLynx
