//============================================================================
//  ProfileStarDetector.cpp                            Astro.Component package
//============================================================================
//  Usage : advanced star detector, based on star profiles
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <boost/scoped_ptr.hpp>

#include <elx/astro/ProfileStarDetector.h>
#include <elx/astro/BaseStarDetector.h>
#include <elx/core/CoreException.h>
#include <elx/image/PixelIterator.h>
#include <elx/astro/ThresholdStarDetector.h>
#include <elx/math/Matrix.h>

#include <boost/scoped_array.hpp>

namespace eLynx {
namespace Astro {
	
using namespace eLynx::Image;


//--------------------------------------------------------
// simple square implementation to simplify some
// expressions


//--------------------------------------------------------
// constructor, initializes star detector

ProfileStarDetector::ProfileStarDetector(uint iMaximalStarDiameter) :
  _MaximalStarDiameter(iMaximalStarDiameter),
	_ThresholdFactor(1.0f),
	_BackgroundBinnings(4)
{}

	
//--------------------------------------------------------
// detects stars on the image

void ProfileStarDetector::DetectStars(const ImageVariant &iImage, 
  StarList &oStars) const
{
	// convert image into float-based luminance image if needed
  boost::scoped_ptr<Image::ImageVariant> spLuminanceImage;
  if (!iImage.IsLf())
  {
	  spLuminanceImage.reset(new ImageVariant(iImage));
	  spLuminanceImage->ChangePixelFormat(PF_Lf);
    if (!spLuminanceImage->IsLf())
		  elxThrow(elxErrOperationFailed, "Unable to change image pixel format.");
  }
  const Image::ImageVariant* pLuminanceImage = 
    (iImage.IsLf()) ? &iImage : spLuminanceImage.get();
		
	// estimate image background value
	/*float back = EstimateBackgroundLevel(*pLuminanceImage);
  if (back < 1e-4f) back = 1e-4f;*/
  
  //printf("estimated background level = %g\n", back);
  
  //_MinG0 = back;
	
	// detect star candidates using threshold star detector 
	StarList star_candidates;
	ThresholdStarDetector tsd;
	
	// set threshold value to x-times background
	tsd.SetOffsetValue(0.5f);
  
  //printf("detection threshold = %g\n", tsd.GetAbsoluteValue());
	
	// and detect star candidates
	tsd.DetectStars(*pLuminanceImage, star_candidates);
  
  //printf("%i star candidates detected\n", star_candidates.size());
  
  //float diam = EstimateStarDiameter(star_candidates);
  
  //printf("estimated diameter = %g\n", diam);
	
	// examine star candidates and if fine, put them into output list
	Star detected;
	for (uint i = 0; i < star_candidates.size(); i++)
		if (DetectStar(*pLuminanceImage, star_candidates[i], detected)) 
			oStars.push_back(detected);
	
}

  
//--------------------------------------------------------
// estimates image background using median of binned image
	
float ProfileStarDetector::EstimateBackgroundLevel(
  const ImageVariant &iImage) const
{
	// copy the luminance image
	ImageVariant binned = iImage;
	
	// bin the image enough times
	for (uint i = 0; i < _BackgroundBinnings; i++) binned.Bin2x2(BM_Mean);

  uint binned_size = binned.GetWidth()*binned.GetHeight(); 
	boost::scoped_array<float> intensities(new float[binned_size]);
  
  // go through all pixels
  PixelIterator<PixelLf> pixel = 
    elxDowncast<PixelLf>(binned.GetImpl()->Begin());
  PixelIterator<PixelLf> end = 
    elxDowncast<PixelLf>(binned.GetImpl()->End());

  uint index = 0;
  while (pixel != end) {
    intensities[index++] = pixel->_channel[0];
    ++pixel;
  }
  
  std::sort(intensities.get(), intensities.get()+binned_size);
  
  uint percentile = (uint)((double)(binned_size-1) * 0.99);
  return intensities[percentile];
  //return 0.7f;*/
  
  /*binned.ApplyMedian(5, 5);
	double back;
	binned.ComputeMean(back, true);
  
  binned.ChangeResolution(RT_UByte);
  binned.ChangePixelFormat(PF_RGBub);
  binned.Save("/tmp/binned.png");
	
	// return the estimated background value
	return (float)back;*/
}


//--------------------------------------------------------
// estimates average star diameter

float ProfileStarDetector::EstimateStarDiameter(
  const StarList &iCandidates) const
{
  // allocate array of required size for star candidate diameters
  boost::scoped_array<double> diameters(new double[iCandidates.size()]);
  
  // fill the array with diameters of star candidates
  for (uint i = 0; i < iCandidates.size(); i++)
    diameters[i] = iCandidates[i].GetDiameter();
    
  // sort the diameter array
  std::sort(diameters.get(), diameters.get()+iCandidates.size());
  
  // compute first and last index to average (median +- 5%)
  int delta = iCandidates.size()/20;
  uint first_index = (uint)((double)iCandidates.size()*0.8);
  if ((int)first_index > delta) first_index -= delta;
  else first_index = 0;
  uint last_index = first_index+delta+1;
  if (last_index > iCandidates.size()-1) last_index = iCandidates.size()-1;
  
  // compute and return average of those values
  float result = 0.0f;
  uint count = 0;
  for (uint i = first_index; i <= last_index; i++) {
    result += (float)diameters[i];
    count++;
  }
  
  return result/(float)count;
}


//--------------------------------------------------------
// examines star candidate profile

bool ProfileStarDetector::DetectStar(const ImageVariant &iImage, 
  const Star &iCandidate, Star &oDetected) const
{
  // reject star candidates with too big diameter
  float d = (float)iCandidate.GetDiameter();
  if (d > _MaximalStarDiameter) return false;

  // compute star center using weighted average
  float x_c, y_c;
  ComputeStarCenter(iImage, iCandidate, x_c, y_c);
  
  // if the region of star diameter exceeds image boundaries, reject it
  // (maybe, there will be better implementation later)
  //float r = (iAverageD/2.0f+0.5f);
  float r = ((float)_MaximalStarDiameter/2.0f+0.5f);
  if (x_c-r < 0 || y_c-r < 0 || 
      x_c+r >= (float)iImage.GetWidth() || 
      y_c+r >= (float)iImage.GetHeight()) return false;
      
  // evaluate star candidate gaussian profile
  //printf("star candidate at %g, %g with radius %g\n", x_c, y_c, iCandidate.GetDiameter()/2.0f);
  //fflush(stdout);
  float g0, h, b, i0, err;
  bool ok = EvaluateProfile(iImage, x_c, y_c, float(_MaximalStarDiameter*0.5), float(iCandidate.GetDiameter()*0.5), 
    g0, h, b, i0, err);
    
  if (!ok) return false;
  /*float g_0, i_0, b, err;
  EvaluateProfile(iImage, x_c, y_c, iCandidate.GetDiameter(), iAverageD, g_0, i_0, b, err);*/
  
  //printf("  profile: g0 = %g, i0 = %g, h = %g, b = %g, err = %g\n", g0, i0, h, b, err);
  //fflush(stdout);
  
  // check for reasonable values
  if (g0 < 0.0f || g0 > 5.0f || h <= 0.5f || b > 1.0f) return false;
  
  // check for average square error per pixel
  //if (err > 0.05) return false;
  
  // check for too big stars
  if (2.0f*h > _MaximalStarDiameter) return false;
  
  // check for signal-to-noise ratio
  if (b > 1e-3 && i0/b < 0.5) return false;
  
  // if star intensity is too low, reject it (probably noise artefact)
  //if (g0 < _MinG0) return false;
	
  // compute "sharp" parameter (sharpness of the profile)
  //float sharp = i0/g0;
	
  // if above 1.0, reject it as hot pixel
  //if (sharp >= 1.0f) return false;
  
  //if (g0 < 0.5f) return false;
	
  /*
  // compute shape parameter 
	float shape;
	EvaluateShape(iImage, x_c, y_c, shape);
	
  
	if (shape > _MaxShape) return false;*/
  
  static double factor = Math::elxSqr(2.0)*Math::elxSqrt(M_PI)*M_PI;
	
  oDetected.SetPosition((double)x_c+0.5, (double)y_c+0.5);
  oDetected.SetIntensity((double)factor*g0*h);
  oDetected.SetDiameter((double)2.0*h);
  
  //printf("accepted\n");
	
  return true;
}
	
	  
//--------------------------------------------------------
// computes star center

void ProfileStarDetector::ComputeStarCenter(const Image::ImageVariant &iImage, 
    const Star &iCandidate, float &oXC, float &oYC) const
{
  // get star candidate center and area size
  int xc = (int)iCandidate.GetX();
  int yc = (int)iCandidate.GetY();
  int delta = (int)(iCandidate.GetDiameter()/2.0f+0.5f);
  if (delta == 0) delta = 1;
  
  // init results
  oXC = 0.0f; oYC = 0.0f;
  float totalI = 0.0f;
  
  // get image implementation (always PixelLf)
  boost::shared_ptr<const AbstractImage> ai = iImage.GetImpl();
  const ImageImpl<PixelLf>& image = elxDowncast<PixelLf>(*ai);
  
  // go through all pixel of square star candidate region
  for (int y = yc-delta; y <= yc+delta; y++) {
    if (y < 0 || y >= (int)iImage.GetHeight()) continue;
    
    for (int x = xc-delta; x <= xc+delta; x++) {
      if (x < 0 || x >= (int)iImage.GetWidth()) continue;
      
      // get pixel value
      float value = image.GetPixel(x, y)->_channel[0];
      
      // add to weighted summas
      oXC += (float)x * value;
      oYC += (float)y * value;
      totalI += value;
    }
  }
  
  // compute weighted average
  oXC /= totalI;
  oYC /= totalI;
}  

	  
//--------------------------------------------------------
// evaluates star gaussian profile

bool ProfileStarDetector::EvaluateProfile(const Image::ImageVariant &iImage, 
  float iXC, float iYC, float iMaxRadius, float iRadius, float &oG0, float &oH, float &oB, 
  float &oI0, float &oError) const
{
  uint r = (uint)(iMaxRadius+0.5f);
  uint d = 2*r + 1;
  
  //Math::Matrix samples(d*d, 3);
  Math::Matrix samples(d, 2);
  
  PixelIterator<const PixelLf> pixelItBegin = 
    elxConstDowncast<const PixelLf>(iImage.Begin());
  PixelIterator<const PixelLf> pixelIt = pixelItBegin;
  
  // compute center of the image region
  uint xc = (uint)iXC;
  uint yc = (uint)iYC;
  
  // init matrix row index
  uint index = 0;
  
  // go through the region
  pixelIt.advance(xc-r, yc);
  //for (uint y = yc-r; y <= yc+r; y++)
    for (uint x = xc-r; x <= xc+r; x++, ++pixelIt) {
      samples(index, 0) = (float)x-(float)xc;
      //samples(index, 1) = (float)y-(float)yc;
      //samples(index, 2) = pixelIt->_channel[0];
      samples(index, 1) = pixelIt->_channel[0];
      if (samples(index, 1) < 0.96) index++; 
      //printf("sample(%g, %g) = %g\n", samples(index, 0), samples(index, 1), samples(index, 2));
      //index++; 
    }
 
   return BaseStarDetector::EvaluateProfile(
    pixelItBegin, samples, index, xc, yc, iRadius, oG0, oH, oB, oI0, oError);
}
    
//--------------------------------------------------------

float ProfileStarDetector::GetTotalIntensity(float iG0, float iD)
{
  float r = iD/2.0f;
  
  float coeff = +Math::elxSqr(iD)*iG0;
  float integral = -coeff*exp(-(Math::elxSqr(r)/(2.0f*Math::elxSqr(iD))))+coeff;
  
  return float(M_PI)*integral;
}


//--------------------------------------------------------

} // namespace Astro
} // namespace eLynx
