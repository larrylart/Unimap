//============================================================================
//  Star.cpp                                           Image.Component package
//============================================================================
//  Usage : star object implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/astro/Star.h>
#include <elx/astro/AstroImage.h>

namespace eLynx {
namespace Astro {

//--------------------------------------------------------
// constructor, creates uninitialized star

Star::Star()
{
	SetPosition(0.0, 0.0);
	SetIntensity(0.0);
	SetDiameter(0.0);
}


//--------------------------------------------------------
// constructor, creates star with specified positions,
// intensity and diameter

Star::Star(double iX, double iY, double iIntensity, double iDiameter)
{
	SetPosition(iX, iY);
	SetIntensity(iIntensity);
	SetDiameter(iDiameter);
}


//--------------------------------------------------------
// copy constructor

Star::Star(const Star &iStar)
{
	CopyData(iStar);
}


//--------------------------------------------------------
// assignement operator

Star& Star::operator = (const Star &iStar)
{
	if (&iStar != this) CopyData(iStar);
	return *this;
}


//--------------------------------------------------------
// equality operator

bool Star::operator == (const Star &iStar) const
{
	if (GetX() != iStar.GetX()) return false;
	if (GetY() != iStar.GetY()) return false;
	if (GetIntensity() != iStar.GetIntensity()) return false;
	if (GetDiameter() != iStar.GetDiameter()) return false;
	return true;
}

//--------------------------------------------------------
// inequality operator

bool Star::operator != (const Star &iStar) const
{
	if (GetX() == iStar.GetX()) return false;
	if (GetY() == iStar.GetY()) return false;
	if (GetIntensity() == iStar.GetIntensity()) return false;
	if (GetDiameter() == iStar.GetDiameter()) return false;
	return true;
}

//--------------------------------------------------------
// returns x position of the star center

double Star::GetX() const
{
	return _X;
}


//--------------------------------------------------------
// returns y position of the star center

double Star::GetY() const
{
	return _Y;
}


//--------------------------------------------------------
// returns specified position coordinates

double Star::GetCoord(uint iIndex) const
{
	// check index 
	if (iIndex >= 2)
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %1 out of range <0, 1>.", iIndex));
	
	// return appropriate coordinate
	return (iIndex == 0 ? _X : _Y);
}


//--------------------------------------------------------
// returns the intensity of the star
double Star::GetIntensity() const
{
	return _Intensity;
}


//--------------------------------------------------------
// returns diameter of the star

double Star::GetDiameter() const
{
	return _Diameter;
}

//--------------------------------------------------------
// sets x position of the star center

void Star::SetX(double iX)
{
	_X = iX;
}


//--------------------------------------------------------
// sets y position of the star center

void Star::SetY(double iY)
{
	_Y = iY;
}


//--------------------------------------------------------
// sets position of the star center

void Star::SetPosition(double iX, double iY)
{
	_X = iX;
	_Y = iY;
}


//--------------------------------------------------------
// sets intensity of the star

void Star::SetIntensity(double iIntensity)
{
	_Intensity = iIntensity;
}


//--------------------------------------------------------
// sets diameter of the star

void Star::SetDiameter(double iDiameter)
{
	_Diameter = iDiameter;
}


//--------------------------------------------------------
// copies object data

void Star::CopyData(const Star &iStar)
{
	_X = iStar._X;
	_Y = iStar._Y;
	_Intensity = iStar._Intensity;
	_Diameter = iStar._Diameter;
}

//--------------------------------------------------------

} // namespace Astro
} // namespace eLynx
