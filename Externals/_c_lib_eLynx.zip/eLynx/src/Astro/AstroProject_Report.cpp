//============================================================================
//  AstroProject_Report.cpp                            Astro.Component package
//============================================================================
//  Usage : astronomical image processing project class implementation.
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
//  ReportGeneral
//----------------------------------------------------------------------------
bool AstroProject::ReportGeneral(FILE * iprFile)
{
  if (NULL == iprFile) return false;
 
  cout << "reporting general" << endl;

  ::fprintf(iprFile, "<h2>General informations</h2>\n");
  ::fprintf(iprFile, "<ul>\n");

  ::fprintf(iprFile, "<li>Project type: <b>%s</b></li>\n", elxToString(_Type));
  int count = GetDetectedFileCount();
  if (count)
    ::fprintf(iprFile, "<li>Found <b>%d</b> file(s).</li>\n", count);
  else
    ::fprintf(iprFile, "<li>No file found.</li>\n");

  // Camera info
  const AstroImage * image = GetValidImage();
  if (NULL != image)
  {
    ImageFileInfo info = image->GetInfo();
    time_t timeStamp;
    if (info.GetTimeStamp(timeStamp)) ::fprintf(iprFile, "<li>Acquisition date: <b>%s</b></li>\n", ctime(&timeStamp));
    ::fprintf(iprFile, "<li>Camera used: <b>%s - %s</b></li>\n", info.GetMaker(), info.GetModel());
    ::fprintf(iprFile, "<li>Image format: ");
    uint w,h;
    if (info.GetDimension(w,h)) ::fprintf(iprFile, "<b>%d</b> x <b>%d</b> ", w,h);
    EResolution resolution;
    if (info.GetResolution(resolution)) ::fprintf(iprFile, "<b>%d</b>-bits ", elxGetBits(resolution));
    EBayerMatrix Bayer;
    if (info.GetBayer(Bayer)) 
      if (BM_None != Bayer)
        ::fprintf(iprFile, "Bayer:<b>%s</b> ", elxToString(Bayer));
    ::fprintf(iprFile, "</li>\n");

    int exposure = ComputeGlobalExposureTime();
    if (0 != exposure)
    {
      int h = exposure/3600;
      int m = (exposure - h*3600)/60;
      int s = exposure - h*3600 - m*60;
      ::fprintf(iprFile, "<li>Total exposure time: <b>%d h %02d m %02d s</b></li>",h,m,s);
    }
  }
  ::fprintf(iprFile, "</ul>\n");

  return true;

} // ReportGeneral


//----------------------------------------------------------------------------
//  ReportBias
//----------------------------------------------------------------------------
bool AstroProject::ReportBias(FILE * iprFile)
{
  if (NULL == iprFile) return false;
  
  cout << "reporting bias" << endl;
  FrameList& list = GetBiasList();

  ::fprintf(iprFile, "<h3>Bias</h3>\n");
  int count = list.GetCount();
  if (0 == count)
  {
    ::fprintf(iprFile, "<p>No Bias available.\n");
    return true;
  }
  ::fprintf(iprFile, "<p>Found %d file(s).\n", count);
  ::fprintf(iprFile, "<p><table border=1>\n");
  const int l = ::strlen(_DataPath);
  const int col=4;
  for (int i=0; i<count; i++)
  {
    AstroImage& image = list.GetFrame(i);

    // get filename without extension
    char name[elxPATH_MAX];
    const char * prName = image.GetFilename().c_str() + l;
    ::strcpy(name, prName);
    char * prExt = ::strrchr(name, '.');
    *prExt = '\0';

    char preview[elxPATH_MAX];
    ::sprintf(preview, PREVIEW_PATH"/%s.jpg", name);
    char thumbnail[elxPATH_MAX];
    ::sprintf(thumbnail, PREVIEW_PATH"/%s_tn.jpg", name);

    if (0 == (i % col))
      ::fprintf(iprFile, "%s", (0==i) ? "<tr>\n" : "</tr>\n<tr>\n");

    ::fprintf(iprFile, "\t<td><center><a target=_blank href=\"%s\"><img border=0 src=\"%s\" width=%d height=%d><br>%s</a><br>",
              preview, thumbnail, _FrameHolder.GetThumbnailWidth(), _FrameHolder.GetThumbnailHeight(), prName);

    ImageFileInfo info = image.GetInfo();
    float shutter;
    if (info.GetShutter(shutter)) 
      ::fprintf(iprFile, "1/%d", int(1.00/shutter));
    uint ISO;
    if (info.GetISO(ISO)) ::fprintf(iprFile, ", %d ISO", ISO);
    time_t timeStamp;
    if (info.GetTimeStamp(timeStamp))
    {
      struct tm * m;
      m = ::localtime(&timeStamp);
      ::fprintf(iprFile, "<br>[%d:%02d:%02d]", m->tm_hour, m->tm_min, m->tm_sec);
    }
    ::fprintf(iprFile, "</center></td>\n");
  }
  ::fprintf(iprFile, "</tr>\n</table>\n");
  return true;

} // ReportBias


//----------------------------------------------------------------------------
//  ReportDarks
//----------------------------------------------------------------------------
bool AstroProject::ReportDarks(FILE * iprFile)
{
  if (NULL == iprFile) return false;
  
  cout << "reporting darks" << endl;
  FrameList& list = GetDarkList();

  ::fprintf(iprFile, "<h3>Darks</h3>\n");
  int count = list.GetCount();
  if (0 == count)
  {
    ::fprintf(iprFile, "<p>No dark available.\n");
    return true;
  }
  ::fprintf(iprFile, "<p>Found %d file(s).\n", count);
  ::fprintf(iprFile, "<p><table border=1>\n");
  const int l = ::strlen(_DataPath);
  const int col=4;
  for (int i=0; i<count; i++)
  {
    AstroImage& image = list.GetFrame(i);

    // get filename without extension
    char name[elxPATH_MAX];
    const char * prName = image.GetFilename().c_str() + l;
    ::strcpy(name, prName);
    char * prExt = ::strrchr(name, '.');
    *prExt = '\0';

    char preview[elxPATH_MAX];
    ::sprintf(preview, PREVIEW_PATH"/%s.jpg", name);
    char thumbnail[elxPATH_MAX];
    ::sprintf(thumbnail, PREVIEW_PATH"/%s_tn.jpg", name);

    if (0 == (i % col))
      ::fprintf(iprFile, "%s", (0==i) ? "<tr>\n" : "</tr>\n<tr>\n");

    ::fprintf(iprFile, "\t<td><center><a target=_blank href=\"%s\"><img border=0 src=\"%s\" width=%d height=%d><br>%s</a><br>",
              preview, thumbnail, _FrameHolder.GetThumbnailWidth(), _FrameHolder.GetThumbnailHeight(), prName);

    ImageFileInfo info = image.GetInfo();
    float shutter;
    if (info.GetShutter(shutter)) 
    {
      int min = int(shutter)/60;
      int sec = int(shutter) - 60*min;
      ::fprintf(iprFile, "%d'%02d\"", min, sec);
    }
    uint ISO;
    if (info.GetISO(ISO)) ::fprintf(iprFile, ", %d ISO", ISO);
    time_t timeStamp;
    if (info.GetTimeStamp(timeStamp))
    {
      struct tm * m;
      m = ::localtime(&timeStamp);
      ::fprintf(iprFile, "<br>[%d:%02d:%02d]", m->tm_hour, m->tm_min, m->tm_sec);
    }
    ::fprintf(iprFile, "</center></td>\n");
  }
  ::fprintf(iprFile, "</tr>\n</table>\n");
  return true;

} // ReportDarks


//----------------------------------------------------------------------------
//  ReportFlats
//----------------------------------------------------------------------------
bool AstroProject::ReportFlats(FILE * iprFile)
{
  if (NULL == iprFile) return false;
  
  cout << "reporting flats" << endl;
  FrameList& list = GetFlatList();

  ::fprintf(iprFile, "<h3>Flat-fields</h3>\n");
  int count = list.GetCount();
  if (0 == count)
  {
    ::fprintf(iprFile, "<p>No flat-field available.\n");
    return true;
  }
  ::fprintf(iprFile, "<p>Found %d file(s).\n", count);
  ::fprintf(iprFile, "<p><table border=1>\n");
  const int l = ::strlen(_DataPath);
  const int col=4;
  for (int i=0; i<count; i++)
  {
    AstroImage& image = list.GetFrame(i);

    // get filename without extension
    char name[elxPATH_MAX];
    const char * prName = image.GetFilename().c_str() + l;
    ::strcpy(name, prName);
    char * prExt = ::strrchr(name, '.');
    *prExt = '\0';

    char preview[elxPATH_MAX];
    ::sprintf(preview, PREVIEW_PATH"/%s.jpg", name);
    char thumbnail[elxPATH_MAX];
    ::sprintf(thumbnail, PREVIEW_PATH"/%s_tn.jpg", name);

    if (0 == (i % col))
      ::fprintf(iprFile, "%s", (0==i) ? "<tr>\n" : "</tr>\n<tr>\n");

    ::fprintf(iprFile, "\t<td><center><a target=_blank href=\"%s\"><img border=0 src=\"%s\" width=%d height=%d><br>%s</a><br>",
              preview, thumbnail, _FrameHolder.GetThumbnailWidth(), _FrameHolder.GetThumbnailHeight(), prName);

    ImageFileInfo info = image.GetInfo();
    float shutter;
    if (info.GetShutter(shutter)) 
      ::fprintf(iprFile, "1/%d", int(1.00/shutter));

    uint ISO;
    if (info.GetISO(ISO)) ::fprintf(iprFile, ", %d ISO", ISO);
    time_t timeStamp;
    if (info.GetTimeStamp(timeStamp))
    {
      struct tm * m;
      m = ::localtime(&timeStamp);
      ::fprintf(iprFile, "<br>[%d:%02d:%02d]", m->tm_hour, m->tm_min, m->tm_sec);
    }
    ::fprintf(iprFile, "</center></td>\n");
  }
  ::fprintf(iprFile, "</tr>\n</table>\n");
  return true;

} // ReportFlat


//----------------------------------------------------------------------------
//  ReportLights
//----------------------------------------------------------------------------
bool AstroProject::ReportLights(FILE * iprFile)
{
  if (NULL == iprFile) return false;
  
  cout << "reporting lights" << endl;
  FrameList& list = GetLightList();

  ::fprintf(iprFile, "<h3>Lights</h3>\n");
  int count = list.GetCount();
  if (0 == count)
  {
    ::fprintf(iprFile, "<p>No light available.\n");
    return true;
  }
  ::fprintf(iprFile, "<p>Found %d file(s).\n", count);
  ::fprintf(iprFile, "<p><table border=1>\n");
  const int l = ::strlen(_DataPath);
  const int col=4;
  for (int i=0; i<count; i++)
  {
    AstroImage& image = list.GetFrame(i);

    // get filename without extension
    char name[elxPATH_MAX];
    const char * prName = image.GetFilename().c_str() + l;
    ::strcpy(name, prName);
    char * prExt = ::strrchr(name, '.');
    *prExt = '\0';

    char preview[elxPATH_MAX];
    ::sprintf(preview, PREVIEW_PATH"/%s.jpg", name);
    char thumbnail[elxPATH_MAX];
    ::sprintf(thumbnail, PREVIEW_PATH"/%s_tn.jpg", name);

    if (0 == (i % col))
      ::fprintf(iprFile, "%s", (0==i) ? "<tr>\n" : "</tr>\n<tr>\n");

    ::fprintf(iprFile, "\t<td><center><a target=_blank href=\"%s\"><img border=0 src=\"%s\" width=%d height=%d><br>%s</a><br>",
              preview, thumbnail, _FrameHolder.GetThumbnailWidth(), _FrameHolder.GetThumbnailHeight(), prName);

    ImageFileInfo info = image.GetInfo();
    float shutter;
    if (info.GetShutter(shutter)) 
    {
      int min = int(shutter)/60;
      int sec = int(shutter) - 60*min;
      ::fprintf(iprFile, "%d'%02d\"", min, sec);
    }
    uint ISO;
    if (info.GetISO(ISO)) ::fprintf(iprFile, ", %d ISO", ISO);
    time_t timeStamp;
    if (info.GetTimeStamp(timeStamp))
    {
      struct tm * m;
      m = ::localtime(&timeStamp);
      ::fprintf(iprFile, "<br>[%d:%02d:%02d]", m->tm_hour, m->tm_min, m->tm_sec);
    }
    ::fprintf(iprFile, "</center></td>\n");

  }
  ::fprintf(iprFile, "</tr>\n</table>\n");
  return true;

} // ReportLights


//----------------------------------------------------------------------------
//  GenerateReport
//----------------------------------------------------------------------------
bool AstroProject::GenerateReport(
    const std::string& iSoftware,
    const std::string& iVersion,
    const std::string& iLink,
    ProgressNotifier &iNotifier)
{
  cout << "reporting..." << endl;
  
  if (_DataPath[0] == '\0') return false;

  // create Preview repository
  char path[elxPATH_MAX]; 
  ::sprintf(path, "%s"PREVIEW_PATH, _DataPath);
  elxMakePath(path);

  char name[elxPATH_MAX];
  ::sprintf(name, "%sindex.htm", _DataPath);
    
  // create html file
  FILE * paFile = ::fopen(name, "wt+");
  if (NULL == paFile)
    return false;

  fprintf(paFile, "<HTML>\n<HEAD>\n<STYLE type=""text/css"">\n<!--body { font-size: 10pt; font-family: Verdana, Helvetica, Arial, sans-serif }-->\n</STYLE>\n</HEAD>\n");
  fprintf(paFile, "<BODY>\n");

  ReportGeneral(paFile);

  time_t now; time(&now);
  fprintf(paFile, "<p>Generated on %s by <a target=_blank href=\"%s\">%s</a> v%s\n",
      ctime(&now), iLink.c_str(), iSoftware.c_str(), iVersion.c_str());

  fprintf(paFile, "<h2>Image list</h2>\n");
  ReportLights(paFile);
  ReportBias(paFile);
  ReportDarks(paFile);
  ReportFlats(paFile);

  fprintf(paFile, "</BODY></HTML>\n");
  ::fclose(paFile); paFile=NULL;

  GeneratePreviews(iNotifier);
  return true;
  
} // GenerateReport


//----------------------------------------------------------------------------
//  GeneratePreviews
//----------------------------------------------------------------------------
void AstroProject::GeneratePreviews(ProgressNotifier &iNotifier)
{
  // --- inits progress ---
  const uint nFrame = _FrameHolder.GetFrameCount();
  const float ProgressStep = 1.0f / nFrame;
  float Progress = 0.0f;
  iNotifier.SetProgress(0.0f);
  
  GeneratePreviews( GetBiasList(), iNotifier, Progress, ProgressStep);
  GeneratePreviews( GetDarkList(), iNotifier, Progress, ProgressStep);
  GeneratePreviews( GetFlatList(), iNotifier, Progress, ProgressStep);
  GeneratePreviews( GetLightList(), iNotifier, Progress, ProgressStep);

  iNotifier.SetProgress(0.0f);

} // GeneratePreviews


//----------------------------------------------------------------------------
//  GeneratePreviews
//----------------------------------------------------------------------------
void AstroProject::GeneratePreviews(
    FrameList& iList, 
    ProgressNotifier &iNotifier,
    float& ioProgress,
    float iProgressStep)
{
  const uint w = _FrameHolder.GetThumbnailWidth(); 
  const uint h = _FrameHolder.GetThumbnailHeight();

  const int count = iList.GetCount();
  for (int i=0; i<count; i++)
  {
    AstroImage& image = iList.GetFrame(i);
    image.SavePreview();

    image.SetThumbnailDimension(w,h);
    image.SaveThumbnail();

    // --- in progress ... ---
    ioProgress += iProgressStep;
    iNotifier.SetProgress(ioProgress);
  }

} // GeneratePreviews
