//============================================================================
//  ImageRecord.cpp                                    Astro.Component package
//============================================================================
//  Usage : registration image record
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/astro/ImageRecord.h>

#include <math.h>

#include <algorithm>

namespace eLynx {
namespace Astro {

//--------------------------------------------------------
// constructor, creates record for given image

ImageRecord::ImageRecord(const AstroImage *iprImage)
{
	SetImage(iprImage);
	_DistTableUpToDate = false;
	_TriangleListSorted = false;
}


//--------------------------------------------------------
// returns the image 

const AstroImage* ImageRecord::GetImage() const
{
	return _prImage;
}


//--------------------------------------------------------
// sets the image

void ImageRecord::SetImage(const AstroImage *iprImage)
{
	_prImage = iprImage;
}


//--------------------------------------------------------
// returns the number of stars

uint ImageRecord::GetStarCount() const
{
	return _Stars.size();
}


//--------------------------------------------------------
// returns specified star (const version)

const Star& ImageRecord::GetStar(uint iIndex) const
{
	// check index
	if (iIndex >= GetStarCount())
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %i out of bounds <0, %i>.", 
			iIndex, GetStarCount()));
			
	return _Stars.at(iIndex);
}


//--------------------------------------------------------
// returns specified star 

Star& ImageRecord::GetStar(uint iIndex)
{
	// check index
	if (iIndex >= GetStarCount())
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %i out of bounds <0, %i>.", 
			iIndex, GetStarCount()));
			
	return _Stars.at(iIndex);
}


//--------------------------------------------------------
// adds new star 

void ImageRecord::AddStar(const Star &star)
{
	_Stars.push_back(new Star(star));
	_DistTableUpToDate = false;
}


//--------------------------------------------------------
// clears list of stars

void ImageRecord::ClearStars()
{
	_Stars.clear();
	_DistTableUpToDate = false;
}


//--------------------------------------------------------
// sorts triangles by b/a ratio

void ImageRecord::SortTrianglesByBA() const
{
	_Triangles.sort(CompareTrianglesByBA);
	_TriangleListSorted = true;
}


//--------------------------------------------------------
// compares triangles according to their b/a ratio

bool ImageRecord::CompareTrianglesByBA(const StarTriangle &iA, 
  const StarTriangle &iB)
{
	return iA.GetBARatio() < iB.GetBARatio();	
}
	


//--------------------------------------------------------
// builds distance table from first N stars

void ImageRecord::BuildDistTable(uint iFirstN)
{
	_DistTable.BuildArray(*this, iFirstN);
	_DistTableUpToDate = true;
}


//--------------------------------------------------------
// returns distance table

const StarDistArray& ImageRecord::GetDistTable() const
{
	// check if DistTable is up to date
	if (!_DistTableUpToDate)
		elxThrow(elxErrInvalidContext, "Star distance table is not up-to-date.");
	
	return _DistTable;
}


//--------------------------------------------------------
// return the number of triangles

uint ImageRecord::GetTriangleCount() const
{
	return _Triangles.size();
}


//--------------------------------------------------------
// returns the specified triangle
	
const StarTriangle& ImageRecord::GetTriangle(uint iIndex) const
{
	// check index
	if (iIndex >= GetTriangleCount()) 
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %i out of range <0, %i>.", 
			iIndex, GetTriangleCount()-1));
			
	return _Triangles.at(iIndex);
}	
	
//--------------------------------------------------------
// builds the list of triangles to match

void ImageRecord::BuildTriangleList(uint iFirstNStars, double iMinCARatio)
{
	// clear the triangle list
	_Triangles.clear();
	_TriangleListSorted = false;
	
	// build the distance table
	BuildDistTable(iFirstNStars);
	
	// go through all processed stars and create all possible triangles
	for (uint a = 0; a < GetDistTable().GetStarCount(); a++)
		for (uint b = a+1; b < GetDistTable().GetStarCount(); b++)
			for (uint c = b+1; c < GetDistTable().GetStarCount(); c++) {
				
				// create the triangle
				StarTriangle triangle(this);
				triangle.SetStarIndices(a, b, c);
				
				// check the c/a ratio
				if (triangle.GetCARatio() < iMinCARatio) continue;
				
				// add triangle to the list
				_Triangles.push_back(new StarTriangle(triangle));
			}
}


//--------------------------------------------------------
// finds similar triangles to the given triangle

void ImageRecord::FindSimilarTriangles(const StarTriangle &iTriangle, 
	double iEpsilon, std::vector<uint> &oIndices) const
{
		
	// sort triangle list if necessary
	if (!_TriangleListSorted) SortTrianglesByBA();
	
	// compute squared epsilon for faster checks
	double epsilon2 = iEpsilon*iEpsilon;
	
	// find lower bound (pivot) of the possible matches
	// this is a triangle with b/a equal or greater to iTriangle b/a ratio
	StarTrianglePtrList::const_iterator lb = std::lower_bound(
		_Triangles.begin(), _Triangles.end(), iTriangle, CompareTrianglesByBA);

	// convert iterator to index
	uint pivot = (lb-_Triangles.begin());
	
	// init index to triangle just before lower bound
	int i = (int)pivot-1;

	// check possible triangles below the pivot
	while (i >= 0 && 
	       GetTriangle((uint)i).GetBARatio() >= iTriangle.GetBARatio()-iEpsilon) {
		// if similar, add index to the list
		if (IsSimilarTriangle(iTriangle, GetTriangle((uint)i), epsilon2))
			oIndices.push_back((uint)i);
		i--;
	}
	
	// init index to the lower bound
	i = (int)pivot;
	
	// check possible triangles above the pivot
	while ((uint)i < GetTriangleCount() && 
	       GetTriangle((uint)i).GetBARatio() <= iTriangle.GetBARatio()+iEpsilon) {
	  // if similar, add index to the list
		if (IsSimilarTriangle(iTriangle, GetTriangle((uint)i), epsilon2))
			oIndices.push_back((uint)i);
		i++;
	}
}
		
		
//--------------------------------------------------------
// checks whether triangles are similar

bool ImageRecord::IsSimilarTriangle(const StarTriangle &iA, 
	const StarTriangle &iB, double iEpsilon2)
{
	// compute ratio differences in triangle space
	double ba_diff = iA.GetBARatio()-iB.GetBARatio();
	double ca_diff = iA.GetCARatio()-iB.GetCARatio();
	
	// compute squared triangle distance in triangle space
	double ratio_dist2 = ba_diff*ba_diff + ca_diff*ca_diff;
	
	// compare squared distance with squared epsilon
	return (ratio_dist2 <= iEpsilon2);
}

//--------------------------------------------------------

} // namespace Astro
} // namespace eLynx
