//============================================================================
//  TemporaryStack.cpp                                 Astro.Component package
//============================================================================
//  Usage : used for temporary storage of parts of many astro images
//          during the masterization/stacking process
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/astro/TemporaryStack.h>
#include <elx/core/CoreException.h>

#include <math.h>

using namespace std;
using namespace boost;

namespace eLynx {
namespace Astro {

//----------------------------------------------------------------------------
//  ComputeStackProperties: computes size of particular stack and number
//    of needed stacks, according to given image list and size of the
//    allowed memory
//----------------------------------------------------------------------------
void TemporaryStack::ComputeStackProperties(FrameList &iFrames, 
  uint iAllowedMemoryKB, uint &oTileHeight, uint &oLastTileHeight, 
  uint &oStackCount)
{
  // init the output parameters
  oTileHeight = 0;
  oLastTileHeight = 0;
  oStackCount = 0;
  
  // if there are no frames, there's nothing to be computed
  if (iFrames.GetValidCount() == 0) return;
  
  // get the reference frame
  iFrames.LoadFrame(0);
  AstroImage &frame = iFrames.GetFrame(0);
  uint sp = frame.sizeofPixel();
  
  // compute the desired tile size to not exceed the memory limit
  uint tile_size = (1024*iAllowedMemoryKB/sp)/iFrames.GetValidCount();
  
  // compute the height of one tile (minimum 1 row)
  oTileHeight = tile_size / frame.GetWidth();
  if (oTileHeight == 0) oTileHeight = 1;
  
  // compute the height of the last tile (rest of the image)
  oLastTileHeight = frame.GetHeight() % oTileHeight;
  
  // compute the number of stacks needed
  oStackCount = frame.GetHeight()/oTileHeight;
  if (oLastTileHeight > 0) oStackCount++;
  
  iFrames.UnloadFrame(0);
  
}
    
    
//----------------------------------------------------------------------------
//  DeleteOldTempFiles: deletes any existing eLynx temporary stack files
//    although temporary file is usually deleted automatically, it can
//    be left behind, if program crashes
//----------------------------------------------------------------------------
void TemporaryStack::DeleteOldTempFiles()
{
  // get the temporary file
  string tmp_dir = GetTmpDir();
  
  // get the list of eLynx astro temporary files
  vector<string> tmp_files;
  elxGetFileList(tmp_dir + elxPATH_SEPARATOR + "ela_*", tmp_files);
  
  // delete the files
  for (uint i = 0; i < tmp_files.size(); i++)
    ::remove(tmp_files[i].c_str());
}

//----------------------------------------------------------------------------
// constructor, creates stack with tile of the specified size
//----------------------------------------------------------------------------
TemporaryStack::TemporaryStack(uint iImageWidth, uint iTileHeight, 
  uint iPixelSize)
{
  _ImageWidth = iImageWidth;
  _TileHeight = iTileHeight;
  _TileCount = 0;
  _PixelSize = iPixelSize; 
  _pFile = NULL;
  
  CreateFile();
}
  
//----------------------------------------------------------------------------
// destructor, deletes the stack file
//----------------------------------------------------------------------------
TemporaryStack::~TemporaryStack()
{
  if (_pFile) {
    ::fclose(_pFile);
    ::remove(_FileName.c_str());
  }
}

//----------------------------------------------------------------------------
//  SaveImageTile: saves the tile from the specified image into the stack
//    file
//----------------------------------------------------------------------------  
void TemporaryStack::SaveImageTile(const ImageVariant &iFrame, uint iY)
{
  // check the image pixel size
  if (iFrame.sizeofPixel() != _PixelSize)
    elxThrow(elxErrInvalidParams, elxMsgFormat(
      "Pixel size of given image (%i) differs from the expected one (%i).",
      iFrame.sizeofPixel(), _PixelSize));
      
  // check the image size
  if (iFrame.GetWidth() != _ImageWidth)
    elxThrow(elxErrInvalidParams, "Image and stack width don't match.");
  
  if (iFrame.GetHeight()-iY < _TileHeight)
    elxThrow(elxErrInvalidParams, "Tile exceeds the image boundary.");
  
  // get the pointer to the image memory
  shared_ptr<IPixelIterator> start = iFrame.Begin();
  const char* image_ptr = (const char*)(start->getMap());
  image_ptr += iY*iFrame.GetWidth()*_PixelSize;
  
  // seek the end of the file
  fseek(_pFile, 0, SEEK_END);
  fwrite(image_ptr, _PixelSize, _ImageWidth*_TileHeight, _pFile);  
  
  // increment the tile count
  _TileCount++; 
}

//----------------------------------------------------------------------------
//  LoadTileAsImage: loads the specified tile as a new image
//----------------------------------------------------------------------------  
void TemporaryStack::LoadTileAsImage(uint iIndex, ImageVariant &ioFrame)
{
  // check the tile index
  if (iIndex >= _TileCount)
    elxThrow(elxErrOutOfRange, elxMsgFormat(
      "Tile index %i out of range <0, %i>.", iIndex, _TileCount-1));
  
  // check, if the image is appropriate to contain the tile
  if (ioFrame.sizeofPixel() != _PixelSize)
    elxThrow(elxErrInvalidParams, elxMsgFormat(
      "Target pixel size (%i) differs from tile pixel size (%i).",
      ioFrame.sizeofPixel(), _PixelSize));
      
  if (ioFrame.GetWidth() != _ImageWidth ||
      ioFrame.GetHeight() != _TileHeight)
    elxThrow(elxErrInvalidParams, elxMsgFormat( 
      "Target resolution (%i x %i) differs from the tile resolution (%i x %i).",
      ioFrame.GetWidth(), ioFrame.GetHeight(), _ImageWidth, _TileHeight));
      
  // get the pointer to the image memory
  shared_ptr<IPixelIterator> start = ioFrame.Begin();
  void* image_ptr = start->getMap();
  
  // seek the appropriate position in the file 
  fseek(_pFile, iIndex*_ImageWidth*_TileHeight*_PixelSize, SEEK_SET);
  
  // read the image content
  fread(image_ptr, _PixelSize, _ImageWidth*_TileHeight, _pFile);
}

//----------------------------------------------------------------------------
//  CopyTile: copies the content of the tile image into target image
//----------------------------------------------------------------------------
void TemporaryStack::CopyTile(ImageVariant &oTarget, const ImageVariant &iTile, 
  uint iY)
{
  // check, if the image is appropriate to contain the tile
  if (oTarget.sizeofPixel() != iTile.sizeofPixel())
    elxThrow(elxErrInvalidParams, elxMsgFormat(
      "Target pixel size (%i) differs from tile pixel size (%i).",
      oTarget.sizeofPixel(), iTile.sizeofPixel()));
      
  if (oTarget.GetWidth() != iTile.GetWidth())
    elxThrow(elxErrInvalidParams, elxMsgFormat(
      "Image width (%i) differs from the tile width (%i).",
      oTarget.GetWidth(), iTile.GetWidth()));
      
  if (iY+iTile.GetHeight() > oTarget.GetHeight())
    elxThrow(elxErrInvalidParams, elxMsgFormat(
      "Tile is outside bounds of the target image (%i > %i).", 
      iY+iTile.GetHeight(), oTarget.GetHeight()));
    
  // get the pointer to the target image memory
  shared_ptr<IPixelIterator> start = oTarget.Begin();
  char* target_ptr = (char*)start->getMap();
  target_ptr += oTarget.GetWidth()*oTarget.sizeofPixel()*iY;
  
  // get the pointer to the tile image memory
  start = iTile.Begin();
  const char* tile_ptr = (const char*)(start->getMap());
  
  // copy the content
  memcpy(target_ptr, tile_ptr, 
    iTile.GetWidth()*iTile.GetHeight()*iTile.sizeofPixel());
  
}

//----------------------------------------------------------------------------
// GetTmpDir: returns temporary directory 
//----------------------------------------------------------------------------
string TemporaryStack::GetTmpDir()
{
  char *tmp_path = ::getenv("TMP");
  if (tmp_path != NULL) return string(tmp_path);
  
  tmp_path = ::getenv("TEMP");
  if (tmp_path != NULL) return string(tmp_path);
  
  return string(".");
}

//----------------------------------------------------------------------------
// CreateFile: creates and opens the temporary file
//----------------------------------------------------------------------------
void TemporaryStack::CreateFile()
{
  string tmp_dir = GetTmpDir();

  char *name = ::tempnam(tmp_dir.c_str(), "ela_");
  _FileName = string(name);
  free(name);
  
  printf("creating temp name = '%s'\n", _FileName.c_str());
  
  _pFile = ::fopen(_FileName.c_str(), "wb");
  if (_pFile == NULL)
    elxThrow(elxErrOperationFailed, 
      elxMsgFormat("Unable to create temporary file %s.", _FileName.c_str()));  
}

//----------------------------------------------------------------------------

} // namespace Astro
} // namespace eLynx
