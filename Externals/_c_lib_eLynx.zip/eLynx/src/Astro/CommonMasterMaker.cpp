//============================================================================
//  CommonMasterMaker.cpp                              Astro.Component package
//============================================================================
//  Usage : abstract predecessor for master frame makers
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/astro/CommonMasterMaker.h>

#include <math.h>

#include <iostream>
using namespace std;

namespace eLynx {
namespace Astro {

//----------------------------------------------------------------------------

CommonMasterMaker::CommonMasterMaker(FrameHolder &ioHolder) 
  : _FrameHolder(ioHolder)
{
}
  
//----------------------------------------------------------------------------
// checks the list of dark frames

bool CommonMasterMaker::CheckList(uint iReference, bool iScaled, 
  bool iRejectBad, uint &oValidFrames, string &oReason,
  ProgressNotifier &iNotifier)
{
  // clear the failure reason string
  oReason = "";

  // get the list of frames
  FrameList &frames = GetFrameList();
  oValidFrames = frames.GetCount();
  
  // if there are no frames, we are done
  if (frames.GetCount() == 0) {
    oReason = "No frames have been found.";
    return false;
  }
  
  // if there is just one, there's also no work to be done
  // however, we can use it as master fra,e
  if (frames.GetCount() == 1) return true;
  
  // init result
  bool result = true;
  
  // check the reference frame index
  if (iReference >= frames.GetCount())
    elxThrow(elxErrOutOfRange, elxMsgFormat("Reference frame %i out of "
      "range (0, %i).", iReference, frames.GetCount()-1));
      
  // check, if the reference frame is not already rejected
  if (frames.IsRejected(iReference))
    elxThrow(elxErrInvalidParams, "Reference frame is rejected."); 
  
  // compare frame infos to the reference frame
  for (uint i = 0; i < frames.GetCount(); i++) {
    
    // skip the reference frame
    if (i == iReference) continue;
    
    // skip already rejected frames
    if (frames.IsRejected(i)) {
      oValidFrames--;
      continue;
    }
    
    // compare frames 
    if (!CompareFileInfos(frames, iReference, i, iScaled, oReason)) {
      
      // reject frame if required
      if (iRejectBad) frames.RejectFrame(i);
      
      // decremenet number of valid frames
      oValidFrames--;
     
      // update result 
      result = false;
    }
  }
  
  // return result
  return result;
}

//----------------------------------------------------------------------------
// creates and saves the preview and thumbnail

void CommonMasterMaker::SavePreview(const string &iPrevName, 
  uint iPrevWidth, uint iPrevHeight, 
  const string &iThumbName, 
  uint iThumbWidth, uint iThumbHeight)
{
  ImageVariant preview = GetMasterFrame();

  // create preview
  preview.SetBayerMatrix(BM_None);
  if (iPrevWidth != 0 && iPrevHeight != 0)
    preview.Resample(iPrevWidth, iPrevHeight);
  preview.ChangeToUByteFullDynamic();
  preview.AdjustGamma(1.8);
  
  // save preview
  _FrameHolder.MakePathForFile(iPrevName);
  preview.Save(iPrevName.c_str());
  
  // create thumbnail for preview
  preview.Resample(iThumbWidth, iThumbHeight);
  
  // save thumbnail
  _FrameHolder.MakePathForFile(iThumbName);
  preview.Save(iThumbName.c_str());
}

//----------------------------------------------------------------------------
// compares two file infos

bool CommonMasterMaker::CompareFileInfos(FrameList &iList, uint iA, uint iB,
                                       bool iScaled, string &oReason)
{
  // get frames to compare infos
  AstroImage &A = iList.GetFrame(iA);
  AstroImage &B = iList.GetFrame(iB);
  
  // get frame infos
  ImageFileInfo &A_info = A.GetInfo();
  ImageFileInfo &B_info = B.GetInfo();
  
  // compare frames ISO
  uint A_ISO, B_ISO;
  A_info.GetISO(A_ISO);
  B_info.GetISO(B_ISO);
  if (A_ISO != B_ISO) {
    oReason += string("Frame ")+B.GetFilename()+" ISO does not match the reference"
      " frame.";
    return false;
  }
  
  if (fabs(GetShutterDelta(iScaled)) > 1e-10) {
    // compare frames Shutters
    float A_Shutter, B_Shutter;
    A_info.GetShutter(A_Shutter);
    B_info.GetShutter(B_Shutter);
    //cout << "    comparing exposures " << A_Shutter << " and " << B_Shutter << endl;
    if (fabs(A_Shutter-B_Shutter) > GetShutterDelta(iScaled)) {
      oReason = string("Frame ")+B.GetFilename()+" exposure does not match the"
        " reference frame.";
      return false;
    }
  }
  
  // compare frames sizes
  uint A_Width, A_Height;
  uint B_Width, B_Height;
  A_info.GetDimension(A_Width, A_Height);
  B_info.GetDimension(B_Width, B_Height);
  if ((A_Width != B_Width) || (A_Height != B_Height)) {
    oReason = string("Frame ")+B.GetFilename()+" size does not match the"
      " reference frame.";
    return false;
  } 
  
  // compare frames resolution
  EResolution A_Res, B_Res;
  A_info.GetResolution(A_Res);
  B_info.GetResolution(B_Res);
  if (A_Res != B_Res) {
    oReason = string("Frame ")+B.GetFilename()+" resolution does not match the"
      " reference frame.";
    return false;
  }
  
  // compare frames bayer matrices
  EBayerMatrix A_Bayer, B_Bayer;
  A_info.GetBayer(A_Bayer);
  B_info.GetBayer(B_Bayer);
  if (A_Bayer != B_Bayer) {
    oReason = string("Frame ")+B.GetFilename()+" bayer matrix does not match the"
      " reference frame.";
    return false;
  }
  
  return true;
  
}

//----------------------------------------------------------------------------
// returns the index of the first valid frame

int CommonMasterMaker::GetFirstValidFrame(FrameList &iList)
{
  for (uint i = 0; i < iList.GetCount(); i++)
    if (!iList.IsRejected(i)) return (int)i;
  
  return -1;  
}

//----------------------------------------------------------------------------

void CommonMasterMaker::CreateStackList(uint iAllowedMemoryKB, 
  ProgressNotifier &iNotifier)
{
  uint tile_height, last_tile_height;
  uint stacks_count;
  
  // get the frame list used
  FrameList &frames = GetFrameList();
  
  // compute properties of required temporary stacks
  TemporaryStack::ComputeStackProperties(frames, iAllowedMemoryKB,
    tile_height, last_tile_height, stacks_count);
  
  // clear the actual stack and delete any old temp files left (if any)
  _StackList.clear();
  TemporaryStack::DeleteOldTempFiles();
  
  // get the reference frame
  int frame_index = GetFirstValidFrame(frames);
  if (frame_index == -1)
    elxThrow(elxErrInvalidContext, "No valid frames in the list.");
  frames.LoadFrame(frame_index);
  AstroImage& frame = frames.GetFrame(frame_index);
  
  // if there is only one stack to be created, there's no need to create it
  // all images could just be loaded directly into memory
  if (stacks_count > 1) {
   
    // create temporary stacks
    for (uint i = 0; i < stacks_count; i++) {
      uint th = tile_height;
      if (i == stacks_count-1 && last_tile_height > 0)
        th = last_tile_height;
      _StackList.push_back(
        new TemporaryStack(frame.GetWidth(), th, frame.sizeofPixel())
      );
    }  
    
    // distribute images to the stacks
    uint count = frames.GetValidCount();
    uint actual = 0;
    for (uint i = 0; i < frames.GetCount(); i++) {
      
      // skip rejected images
      if (frames.IsRejected(i)) continue;
      
      // load the image into memory
      frames.LoadFrame(i, iNotifier);
      AstroImage &f = frames.GetFrame(i);
      
      // do any preprocessing needed (like subtracting bias)
      PreprocessFrame(f);
      
      // store image tiles into appropriate stacks
      uint y = 0;
      for (uint j = 0; j < _StackList.size(); j++) {
        _StackList[j].SaveImageTile(f, y);
        y += tile_height;
      }
      
      // unload the frame from memory
      frames.UnloadFrame(i);
      
      // notify the progress
      actual++;
      iNotifier.SetProgress((float)actual/(float)count);
    }
  }
  else iNotifier.SetProgress(1.0f);
}

//----------------------------------------------------------------------------

void CommonMasterMaker::PrepareStackImageList(TemporaryStack &iStack, 
    const AstroImage &iReference, boost::ptr_vector<ImageVariant> &oTiles, 
    std::vector<const ImageVariant*> &oReferences, ImageVariant &oResult)
{
  // clear the lists
  oReferences.clear();
  oTiles.clear();
  
  // create temporary image for each tile in the stack
  for (size_t i = 0; i < iStack.GetTileCount(); i++) {
    // create the image
    oTiles.push_back(
      new ImageVariant(iReference.GetPixelFormat(), 
        iStack.GetImageWidth(), iStack.GetTileHeight())
      );
    // and store it's constant reference for Build command
    oReferences.push_back(&(oTiles[i]));
  }
  
  // update the result image format and size
  oResult.ChangePixelFormat(iReference.GetPixelFormat());
  oResult.Resize(iStack.GetImageWidth(), iStack.GetTileHeight());
}
    
//----------------------------------------------------------------------------
    
void CommonMasterMaker::LoadImageStack(TemporaryStack &iStack, 
    boost::ptr_vector<ImageVariant> &oTiles)
{
  // create temporary image for each tile in the stack
  for (size_t i = 0; i < iStack.GetTileCount(); i++) 
    iStack.LoadTileAsImage(i, oTiles[i]);
}
    
//----------------------------------------------------------------------------

} // namespace Astro
} // namespace eLynx
