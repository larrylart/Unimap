//============================================================================
//  FrameHolder.cpp                                      Astro.Component package
//============================================================================
//  Usage : holder for all stacking data
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/astro/FrameHolder.h>

#ifdef elxWINDOWS
#pragma warning (disable:4996)
#endif

#include <boost/format.hpp>
using namespace boost;
using namespace std;

namespace eLynx {
namespace Astro {
  
//----------------------------------------------------------------------------
// constructor, sets masters (if specified)

FrameHolder::FrameHolder(const string &iMasterBias, const string &iMasterDark, 
    const string &iMasterFlat) 
    : _BiasFrames(AIT_Bias), _DarkFrames(AIT_Dark), _FlatFrames(AIT_FlatField),
      _LightFrames(AIT_Light), _ReducedFrames(AIT_ReducedLight) 
{
  _MasterBias.SetType(AIT_MasterBias);
  _MasterBias.SetFilename(iMasterBias);
  
  _MasterDark.SetType(AIT_MasterDark);
  _MasterDark.SetFilename(iMasterDark);
  
  _MasterFlat.SetType(AIT_MasterFlatField);
  _MasterFlat.SetFilename(iMasterFlat);
  
  _StackedImage.SetType(AIT_Stacked);

  SetupDefaultPatterns();
}

//----------------------------------------------------------------------------
// sets master bias frame

void FrameHolder::SetMasterBias(const string &iMasterBias)
{
  _MasterBias.Unload();
  _MasterBias.SetFilename(iMasterBias);
}

//----------------------------------------------------------------------------
// sets master dark frame

void FrameHolder::SetMasterDark(const string &iMasterDark)
{
  _MasterDark.Unload();
  _MasterDark.SetFilename(iMasterDark);
}

//----------------------------------------------------------------------------
// sets master flat frame

void FrameHolder::SetMasterFlat(const string &iMasterFlat)
{
  _MasterFlat.Unload();
  _MasterFlat.SetFilename(iMasterFlat);
}

//----------------------------------------------------------------------------
// clears all frames

void FrameHolder::ClearAll()
{
  _BiasFrames.Clear();
  _MasterBias.Unload();
  
  _DarkFrames.Clear();
  _MasterDark.Unload();
  
  _FlatFrames.Clear();
  _MasterFlat.Unload();
  
  _LightFrames.Clear();
  _ReducedFrames.Clear();
  _StackedImage.Unload();
}

//----------------------------------------------------------------------------
// checks, whether master bias is available.

bool FrameHolder::IsMasterBiasAvailable() const
{
  return IsMasterAvailable(_MasterBias);
}

//----------------------------------------------------------------------------
// checks whether master dark is available
  
bool FrameHolder::IsMasterDarkAvailable() const
{
  return IsMasterAvailable(_MasterDark);
}

//----------------------------------------------------------------------------
// checks whether master flat is available

bool FrameHolder::IsMasterFlatAvailable() const
{
  return IsMasterAvailable(_MasterFlat);
}

//----------------------------------------------------------------------------
// prepares master bias to be used

void FrameHolder::PrepareMasterBias(const ImageFileInfo &iInfo)
{
  PrepareMaster(_MasterBias, iInfo);
}

//----------------------------------------------------------------------------
// prepares master dark to be used

void FrameHolder::PrepareMasterDark(const ImageFileInfo &iInfo)
{
  PrepareMaster(_MasterDark, iInfo);
}

//----------------------------------------------------------------------------
// prepares master flat to be used

void FrameHolder::PrepareMasterFlat(const ImageFileInfo &iInfo)
{
  PrepareMaster(_MasterFlat, iInfo);
}

//----------------------------------------------------------------------------
// checks whether specified master frame is available

bool FrameHolder::IsMasterAvailable(const AstroImage &iMaster) const
{
  return iMaster.GetFilename() != "";
}

//----------------------------------------------------------------------------
// prepares specified master frame to be used
  
void FrameHolder::PrepareMaster(AstroImage &iMaster, const ImageFileInfo &iInfo)
{
  if (!IsMasterAvailable(iMaster))
    elxThrow(elxErrInvalidContext, "Specified master frame is not available.");
    
  if (!iMaster.IsValid()) iMaster.LoadImage();
  EBayerMatrix bayer;
  iInfo.GetBayer(bayer);
  iMaster.SetBayerMatrix(bayer);
}

//----------------------------------------------------------------------------
// adds frame by its type to the correct frame list

void FrameHolder::AddFrameByType(AstroImage *iImage)
{
  switch (iImage->GetType()) 
  {
    case AIT_Bias :       _BiasFrames.AddFrame(iImage);  break;
    case AIT_Dark :       _DarkFrames.AddFrame(iImage);  break;
    case AIT_FlatField :  _FlatFrames.AddFrame(iImage);  break;
    case AIT_Light :      _LightFrames.AddFrame(iImage); break;
    default: elxThrow(elxErrInvalidParams, "Unexpected image type.");
  }
}

//----------------------------------------------------------------------------
// gets first valid frame image file info

const ImageFileInfo& FrameHolder::GetValidImageFileInfo() const
{
  if (GetLightFrames().GetCount() > 0)
    return GetLightFrames().GetFrame(0).GetInfo(); 
  else {
    if (GetDarkFrames().GetCount() > 0) 
      return GetDarkFrames().GetFrame(0).GetInfo();
    else {
      if (GetFlatFrames().GetCount() > 0) 
        return GetFlatFrames().GetFrame(0).GetInfo();
      else {
        if (GetBiasFrames().GetCount() > 0) 
          return GetBiasFrames().GetFrame(0).GetInfo();
      }
    }
  }
  elxThrow(elxErrOperationFailed, "Unable to find valid frame.");
  return GetLightFrames().GetFrame(0).GetInfo();
}

//----------------------------------------------------------------------------
// sets up default values for filename patterns and so on

void FrameHolder::SetupDefaultPatterns()
{
  // previews will be stored to the Previews subdirectory as jpegs
  // and the size will be same as original
  _PreviewNamePattern = string("Previews") + elxPATH_SEPARATOR + "%1%.jpg";
  _PreviewWidth = 0;
  _PreviewHeight = 0;

  // thumbnails will be stored to the Previews subdirectory as pngs
  // and the size will be 200 x 150
  _ThumbnailNamePattern = string("Previews") + elxPATH_SEPARATOR + "%1%_tn.png";
  _ThumbnailWidth = 200;
  _ThumbnailHeight = 150;

  // masters will be stored in the Masters subdirectory as tifs
  _MasterBiasNamePattern = string("Masters") + elxPATH_SEPARATOR + "MasterBias.tif";
  _MasterDarkNamePattern = string("Masters") + elxPATH_SEPARATOR + "MasterDark.tif";
  _MasterFlatNamePattern = string("Masters") + elxPATH_SEPARATOR + "MasterFlat.tif";

  // master previews and thumbnails will be stored in the Previews subdirectory as pngs
  _MasterFramePreviewPattern = string("..") + elxPATH_SEPARATOR + "Previews" +
    elxPATH_SEPARATOR + "%1%.png";
  _MasterFrameThumbnailPattern = string("..") + elxPATH_SEPARATOR + "Previews" +
    elxPATH_SEPARATOR + "%1%_tn.png";

  // Reduced raws and rgbs will be stored in the Reduced subdirectory as tifs
  _ReducedRawNamePattern = string("Reduced") + elxPATH_SEPARATOR + "%1%_raw.tif";
  _ReducedRgbNamePattern = string("Reduced") + elxPATH_SEPARATOR + "%1%_rgb.tif";
  _ReducedInfoFileNamePattern = "%1%_info.xml";

}

//----------------------------------------------------------------------------
// generates filename from pattern and original filename

string FrameHolder::ApplyNamePattern(const string &iPattern, 
                                     const string &iFilename) const
{
  string path, name, ext;
  elxSplitFilename(iFilename, path, name, ext);

  string result;
  if (iPattern.find("%1%") != iPattern.npos)
    result = path + str(format(iPattern) % name);
  else 
    result = path + iPattern;

  return result;
}

//----------------------------------------------------------------------------

void FrameHolder::MakePathForFile(const string &iFilename) const
{
  string path, name, ext;
  elxSplitFilename(iFilename, path, name, ext);
  
  elxMakePath(path);
  
  if (elxIsPath(path) == false) 
    elxThrow(elxErrOperationFailed, elxMsgFormat(
      "Unable to create path '%s' for file %s.", 
      path.c_str(), iFilename.c_str()
      )
    );
}

//----------------------------------------------------------------------------

} // namespace Astro
} // namespace eLynx
