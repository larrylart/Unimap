//============================================================================
//  Registrator.cpp                                    Astro.Component package
//============================================================================
//  Usage : main image registration class
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifdef elxWINDOWS
#pragma warning (disable:4996)
#endif

#include <vector>
#include <algorithm>

#include <elx/core/CoreOS.h>
#include <elx/core/CoreException.h>
#include <elx/astro/Registrator.h>
#include <elx/astro/AstroErrorIds.h>
#include <elx/math/LinearTransformation.h>
#include <elx/math/Matrix.h>
#include <elx/math/Vector.h>
#include <elx/math/LeastSquares.h>



namespace eLynx {
namespace Astro {
	

//----------------------------------------------------------------------------
// constructor, creates registration object for given pair of images

Registrator::Registrator(const AstroImage &iBaseImage, 
	const AstroImage &iRegisteredImage)
{
	_spBaseImage.reset(new ImageRecord(&iBaseImage));
	_spRegisteredImage.reset(new ImageRecord(&iRegisteredImage));

	_VoteArraySize = 0;
	_VoteArray.reset(NULL);
}


//----------------------------------------------------------------------------
// returns base image

const AstroImage& Registrator::GetBaseImage() const
{
	return *(_spBaseImage->GetImage());
}


//----------------------------------------------------------------------------
// returns registered image

const AstroImage& Registrator::GetRegisteredImage() const
{
	return *(_spRegisteredImage->GetImage());
}


//----------------------------------------------------------------------------
// tries to register two images using given params

bool Registrator::Register(const RegistrationParams &iParams, 
	boost::shared_ptr<Math::AbstractTransformation>& oTransformation,
	ProgressNotifier &iNotifier)
	
{
	// detect stars on both images
	DetectStars(iParams);
	//printf("%i stars detected on base image\n", _spBaseImage->GetStarCount());
	//printf("%i stars detected on registered image\n", _spRegisteredImage->GetStarCount());
	
	// build triangle lists on both images
	BuildTriangleLists(iParams);
	//printf("%i triangles found on base image\n", _spBaseImage->GetTriangleCount());
	//printf("%i triangles found on registered image\n", _spRegisteredImage->GetTriangleCount());
	
	// match triangles on both images, producing vote array
	MatchTriangles(iParams, iNotifier);
	//printf("triangles matching completed, computing transformation\n");
	
	Math::LinearTransformation trf;
	MatchedStarList matches;
	bool trf_found = ComputeLinearTransformation(iParams, trf, matches);
	if (!trf_found) return false;

	//printf("transformation found on %i good matches\n", matches.size());
	oTransformation.reset(new Math::LinearTransformation(trf));

	return true;
}


//----------------------------------------------------------------------------
// detects stars on both images

void Registrator::DetectStars(const RegistrationParams &iParams)
{
	
	// check if at least 6 stars were available
	if (GetBaseImage().GetStarsCount() < 6) 
		elxThrow(elxErrNotEnoughStars, elxMsgFormat(
			"Not enough stars (%i) detected on base image.", 
      GetBaseImage().GetStarsCount()));
      
	// add stars to the image
	_spBaseImage->ClearStars();
	for (uint i = 0; i < GetBaseImage().GetStarsCount(); i++) 
    _spBaseImage->AddStar(GetBaseImage().GetStar(i));
	
	// check if at least 6 stars were found
	if (GetRegisteredImage().GetStarsCount() < 6) 
		elxThrow(elxErrNotEnoughStars, elxMsgFormat(
			"Not enough stars (%i) detected on registered image.", 
      GetRegisteredImage().GetStarsCount()));
	// add stars to the image
	_spRegisteredImage->ClearStars();
	for (uint i = 0; i < GetRegisteredImage().GetStarsCount(); i++) 
    _spRegisteredImage->AddStar(GetRegisteredImage().GetStar(i));
}


//----------------------------------------------------------------------------
// builds image triangle lists and initializes vote array

void Registrator::BuildTriangleLists(const RegistrationParams &iParams)
{
	// get desired number of stars to match
	uint n = iParams.GetStarsToMatch();
	
	// if there are less stars, update the number
	if (_spBaseImage->GetStarCount() < n) 
		n = _spBaseImage->GetStarCount();
	if (_spRegisteredImage->GetStarCount() < n) 
		n = _spRegisteredImage->GetStarCount();
	
	// build triangle lists
	_spBaseImage->BuildTriangleList(n);
	_spRegisteredImage->BuildTriangleList(n);
	
	// initialize n x n vote array
	_VoteArray.reset(new uint[n*n]);
	_VoteArraySize = n;
	for (uint i = 0; i < n*n; i++) _VoteArray[i] = 0;
}


//----------------------------------------------------------------------------
// finds matches between triangle lists

void Registrator::MatchTriangles(const RegistrationParams &iParams, 
	ProgressNotifier &iNotifier)
{
	// go through all triangles on base image
	for (uint i = 0; i < _spBaseImage->GetTriangleCount(); i++) {
		
    // match the triangle
		MatchTriangle(i, iParams);
		
		// notify progress
		iNotifier.SetProgress((float)i/(float)(_spBaseImage->GetTriangleCount()-1));
	}
}


//----------------------------------------------------------------------------
// matches specified triangle to other triangles

void Registrator::MatchTriangle(uint iTriangle, 
  const RegistrationParams &iParams)
{
  // get the triangle
  const StarTriangle &st = _spBaseImage->GetTriangle(iTriangle);
    
  // find similar triangles
  std::vector<uint> similar;
  _spRegisteredImage->FindSimilarTriangles(st, iParams.GetTriangleEpsilon(),
    similar);
      
  // update vote array for all triangle pairs
  for (std::vector<uint>::iterator j = similar.begin(); j != similar.end(); j++)
    UpdateVoteArray(st, _spRegisteredImage->GetTriangle(*j));
    
}
	

//----------------------------------------------------------------------------
// updates vote array for given pair of similar triangles

void Registrator::UpdateVoteArray(const StarTriangle &iBase, 
	const StarTriangle &iReg)
{
	IncrementVoteArray(iBase.GetStarIndexBA(), iReg.GetStarIndexBA());
	IncrementVoteArray(iBase.GetStarIndexCA(), iReg.GetStarIndexCA());
	IncrementVoteArray(iBase.GetStarIndexCB(), iReg.GetStarIndexCB());
}


//----------------------------------------------------------------------------
// increment vote array value for given pair of objects

void Registrator::IncrementVoteArray(uint iBaseStar, uint iRegisteredStar)
{
	uint index = iBaseStar*_VoteArraySize+iRegisteredStar;
	_VoteArray[index]++;
}


//----------------------------------------------------------------------------
// computes the linear transformation from triangle matching resuls

bool Registrator::ComputeLinearTransformation(const RegistrationParams &iParams,
	Math::LinearTransformation &oTrf, MatchedStarList &oMatches)
{
	// get N best matched star candidates (N is maximum possible number of
	// positive matches)
	GetBestMatches(iParams.GetStarsToMatch(), oMatches);
	
	// compute linear transformation using first six matched stars (most probable
	// matches)
	uint best_matches = 6;
	if (oMatches.size() < best_matches) best_matches = oMatches.size();
	LeastSquaresTrf(oMatches, best_matches, oTrf);
	
	// reject matches, that don't fit computed transformation
	ClipWrongMatches(oMatches, oTrf, iParams);
	
	// if there is not enough matches left, registration was not successfull
	if (oMatches.size() < 3) return false;
	
	// iteratively compute transformation and clip false matches
	bool some_clipped;
	do {
		// compute new transformation using all remaining matches
		LeastSquaresTrf(oMatches, oMatches.size(), oTrf);
		
		// reject matches, that don't fit computed transformation
		some_clipped = ClipWrongMatches(oMatches, oTrf, iParams);
		
	// repeat until all matches fit the transformation
	} while (some_clipped);
	
	// registration is successfull, if enough matches were detected
	return (oMatches.size() > 3);
	
}


//----------------------------------------------------------------------------
// compute linear transformation using least squares method

void Registrator::LeastSquaresTrf(const MatchedStarList &iMatches, 
	uint iCount, Math::LinearTransformation &oTrf) const
{
	// init linear system matrix and right side vectors
	Math::Matrix A(iCount, 3);
	Math::Vector B0(iCount);
	Math::Vector B1(iCount);
	
	// init result vectors
	Math::Vector X0(3);
	Math::Vector X1(3);
	
	// fill in linear system matrix and right side vectors for each coordinate
	for (uint i = 0; i < iCount; i++) {
		const MatchedStar &ms = iMatches[i];
		A(i, 0) = ms.GetStar(msiBase).GetX();
		A(i, 1) = ms.GetStar(msiBase).GetY();
		A(i, 2) = 1.0;
		B0(i) = ms.GetStar(msiRegistered).GetCoord(0);
		B1(i) = ms.GetStar(msiRegistered).GetCoord(1);
	}
	
	// solve the systems using least squares
	Math::LeastSquares::Solve(A, B0, X0);
	Math::LeastSquares::Solve(A, B1, X1);
	
	// create the transformation
	oTrf.GeneralTransformation(X0(0), X0(1), X0(2), X1(0), X1(1), X1(2));
}


//----------------------------------------------------------------------------
// reject matches, that don't fit given transformation
		
bool Registrator::ClipWrongMatches(MatchedStarList &ioMatches, 
	Math::LinearTransformation &iTrf, 
	const RegistrationParams &iParams) const
{
	// compute array of residuals for all matched star candidates
	boost::scoped_array<double> residuals(new double[ioMatches.size()]);
	ComputeResiduals(ioMatches, iTrf, residuals);
	
	// create sorted version of the array of residuals
	boost::scoped_array<double> sorted_residuals(new double[ioMatches.size()]);
	std::copy(residuals.get(), residuals.get()+ioMatches.size(), 
		sorted_residuals.get());
	std::sort(sorted_residuals.get(), sorted_residuals.get()+ioMatches.size());
	
	// compute index of the Nth percentile of the residuals
	uint pNth_index = (uint)((double)(
		iParams.GetMatchClippingPercentile()*(ioMatches.size()+1))/100.0+0.5
		);
	if (pNth_index >= ioMatches.size()) 
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Unexpected %ith percentile index %i of %i.", 
				iParams.GetMatchClippingPercentile(), pNth_index, ioMatches.size()));
				
	// compute squared maximal local distortion
	double max_distortion = (double)_spRegisteredImage->GetImage()->GetWidth() * 
		iParams.GetMaxRelativeDistortion();
	max_distortion *= max_distortion;
				
	// use twice Nth percentile as a default the sigma clipping limit
	double sigma = 2.0*sorted_residuals[pNth_index];
	
	// if maximal local distortion is smaller, use it instead of Nth percentile
	if (max_distortion < sigma) sigma = max_distortion;
	// don't use sigma smaller than 1/10th of the pixel 
	// otherwise, too many good matches would be rejected 
	if (sigma < 0.1) sigma = 0.1;
	//printf("sigma value = %g\n", sigma);
	
	// go through all matches (in reverse order to allow easy erasing)
	uint clipped = 0;
	for (int i = ioMatches.size()-1; i >= 0; i--) 
	
		// if the matched star residual is greater than sigma limit
		if (residuals[i] > sigma) {
			
			// erase the matched star candidate as the false match
			ioMatches.erase(ioMatches.begin()+i);
			
			// and increment counter of erased matches
			clipped++;
		}
	
	// return true, if some match candidates were rejected
	return (clipped > 0);
}


//----------------------------------------------------------------------------
// compute residuals for matched star candidates

void Registrator::ComputeResiduals(const MatchedStarList &iMatches, 
	Math::LinearTransformation &iTrf, 
	boost::scoped_array<double> &oResiduals) const
{
	//printf("residuals:\n");
	// go through all matches
	for (uint i = 0; i < iMatches.size(); i++) {

		// get the matched star reference
		const MatchedStar &ms = iMatches[i];
		
		// get the star on base image
		const Star &s1 = ms.GetStar(msiBase);
		// and transform its position using given transformation
		double tx, ty;
		iTrf.Transform(s1.GetX(), s1.GetY(), tx, ty);
		
		// get the star on registered image
		const Star &s2 = ms.GetStar(msiRegistered);
		
		// compute squared distance between transformed position of the first
		// star and real position of the second star
		double dx = tx-s2.GetX();
		double dy = ty-s2.GetY();
		
		// use computed value as a residual for this candidate
		oResiduals[i] = dx*dx+dy*dy;
		//printf("  %g\n", oResiduals[i]);
	}
}


//----------------------------------------------------------------------------
// get first N best matched star candidates

void Registrator::GetBestMatches(uint iN, MatchedStarList &oMatches)
{
	// find N best matches
	while (iN > 0) {
		
		uint greatest = 0;
		uint row = 0, col = 0;
		bool found = false;
		
		// find the greates value in the vote array
		for (uint r = 0; r < _VoteArraySize; r++)
			for (uint c = 0; c < _VoteArraySize; c++) {
				uint index = r*_VoteArraySize+c;
				if (_VoteArray[index] > greatest) {
					greatest = _VoteArray[index];
					row = r;
					col = c;
					found = true;
				}
			}
			
		// if value > 0 was found
		if (found) {
			// reset this value in the vote array
			_VoteArray[row*_VoteArraySize+col] = 0;
			
			// create matched star candidate for appropriate row and column
			MatchedStar ms;
			ms.SetImage(msiBase, _spBaseImage.get());
			ms.SetImage(msiRegistered, _spRegisteredImage.get());
			ms.SetStarIndex(msiBase, row);
			ms.SetStarIndex(msiRegistered, col);
			ms.SetMatches(greatest);
			
			// add matched star candidate to the list
			oMatches.push_back(ms);
		}
		
		iN--;
	}
}


//----------------------------------------------------------------------------

} // namespace Astro
} // namespace eLynx
