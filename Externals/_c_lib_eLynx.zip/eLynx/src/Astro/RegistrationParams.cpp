//============================================================================
//  RegistrationParams.cpp                             Astro.Component package
//============================================================================
//  Usage : class, encapsulating parameters for the registration process
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/astro/RegistrationParams.h>
#include <elx/core/CoreException.h>
#include <elx/astro/ThresholdStarDetector.h>

namespace eLynx {
namespace Astro {
	

//----------------------------------------------------------------------------
// constructor, creates parameters with default values

RegistrationParams::RegistrationParams()
{
	SetDefaultParams();
}


//----------------------------------------------------------------------------
// sets registration parameters to default values

void RegistrationParams::SetDefaultParams()
{
  /*_spStarDetector.reset(new ThresholdStarDetector());
  (dynamic_cast<ThresholdStarDetector*>(_spStarDetector.get())
    )->SetOffsetValue(0.2f);*/
	_StarsToMatch = 40;
	_TriangleEpsilon = 0.002;
	_MatchClippingPercentile = 60;
	_MaxRelativeDistortion = 0.003;
}


/*
//----------------------------------------------------------------------------
// returns star detector instance 

boost::shared_ptr<AbstractStarDetector> RegistrationParams::GetStarDetector()
{
	return _spStarDetector;
}


//----------------------------------------------------------------------------
// sets the star detector instance

void RegistrationParams::SetStarDetector(
  boost::shared_ptr<AbstractStarDetector> iDetector)
{
  _spStarDetector = iDetector;
}
*/

//----------------------------------------------------------------------------
// returns number of stars to match

uint RegistrationParams::GetStarsToMatch() const
{
	return _StarsToMatch;
}


//----------------------------------------------------------------------------
// sets number of stars to match

void RegistrationParams::SetStarsToMatch(uint iCount)
{
	_StarsToMatch = iCount;
}


//----------------------------------------------------------------------------
// returns triangle epsilon value

double RegistrationParams::GetTriangleEpsilon() const
{
	return _TriangleEpsilon;
}


//----------------------------------------------------------------------------
// sets triangle epsilon value
	
void RegistrationParams::SetTriangleEpsilon(double iEpsilon)
{
	if (iEpsilon < 0.0 || iEpsilon > 1.0)
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Triangle epsilon value %g out of range <0, 1>.", iEpsilon));
			
	_TriangleEpsilon = iEpsilon;
}


//----------------------------------------------------------------------------
//

uint RegistrationParams::GetMatchClippingPercentile() const
{
	return _MatchClippingPercentile;
}


//----------------------------------------------------------------------------
//

void RegistrationParams::SetMatchClippingPercentile(uint iPercent)
{
	if (iPercent > 100)
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Match clipping percentile value %i out of range <0, 100>.", 
				iPercent));
				
	_MatchClippingPercentile = iPercent;
}


//----------------------------------------------------------------------------
//

double RegistrationParams::GetMaxRelativeDistortion() const
{
	return _MaxRelativeDistortion;
}


//----------------------------------------------------------------------------
//

void RegistrationParams::SetMaxRelativeDistortion(double iDistortion)
{
	if (iDistortion < 0.0 || iDistortion > 1.0)
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Max relative distortion value %g out of range <0, 1>.", 
				iDistortion));
				
	_MaxRelativeDistortion = iDistortion;
}


//----------------------------------------------------------------------------

	
} // namespace Astro
} // namespace eLynx
