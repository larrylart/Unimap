//============================================================================
//  LightReducer.cpp                                   Astro.Component package
//============================================================================
//  Usage : reduces light frames using master bias, dark and flat
//----------------------------------------------------------------------------
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/astro/LightReducer.h>

#include <iostream>
using namespace std;

namespace eLynx {
namespace Astro {
  
//----------------------------------------------------------------------------

LightReducer::LightReducer(FrameHolder &ioHolder) : _FrameHolder(ioHolder)
{
}


//----------------------------------------------------------------------------

bool LightReducer::CheckList(uint iReference, bool iRejectBad, 
  uint& oValidFrames, string &oReason, ProgressNotifier &iNotifier)
{
  // get the list of frames
  FrameList &frames = _FrameHolder.GetLightFrames();
  oValidFrames = frames.GetCount();
  
  // if there are no frames, we are done
  if (frames.GetCount() == 0) {
    oReason = "No frames have been found.";
    return false;
  }
  
  // if there is just one, no problem
  if (frames.GetCount() == 1) return true;
  
  // init result
  bool result = true;
  
  // check the reference frame index
  if (iReference >= frames.GetCount())
    elxThrow(elxErrOutOfRange, elxMsgFormat("Reference frame %i out of "
      "range (0, %i).", iReference, frames.GetCount()-1));
      
  // check, if the reference frame is not already rejected
  if (frames.IsRejected(iReference))
    elxThrow(elxErrInvalidParams, "Reference frame is rejected."); 
  
  // compare frame infos to the reference frame
  for (uint i = 0; i < frames.GetCount(); i++) {
    
    // skip the reference frame
    if (i == iReference) continue;
    
    // skip already rejected frames
    if (frames.IsRejected(i)) {
      oValidFrames--;
      continue;
    }
    
    // compare frames 
    if (!CompareFileInfos(frames, iReference, i, oReason)) {
      
      // reject frame if required
      if (iRejectBad) frames.RejectFrame(i);
      
      // decrement number of valid frames
      oValidFrames--;
     
      // update result 
      result = false;
    }
  }
  
  // return result
  return result;
}


//----------------------------------------------------------------------------

void LightReducer::ReduceLights(ProgressNotifier &iNotifier)
{

  cout << "ReduceLights" << endl;

  // get the list of light frames
  FrameList &frames = _FrameHolder.GetLightFrames();
  
  // find first valid frame
  int ref = -1;
  for (uint i = 0; i < frames.GetCount(); i++) 
    if (!frames.IsRejected(i)) {
      ref = i;
      break;
    }

  // if there is no valid frame, throw an exception
  if (ref == -1)
      elxThrow(elxErrInvalidContext, "No valid light frames to Reduce.");

  cout << "  first valid frame = " << ref << endl;
    
  // check the list and get the number of valid frames
  uint valid_frames;
  string reason;
  CheckList(ref, true, valid_frames, reason, iNotifier);

  cout << "  list checked, " << valid_frames << " valid frames" << endl;
  cout << "  reason = " << reason << endl;
  
  // prepare masters, if available
  
  // get reference image info
  ImageFileInfo &ref_info = frames.GetFrame(ref).GetInfo();
  
  // prepare master bias
  if (_FrameHolder.IsMasterBiasAvailable()) {
    cout << "  preparing master bias" << endl;
    _FrameHolder.PrepareMasterBias(ref_info);
  }
    
  // prepare master dark
  if (_FrameHolder.IsMasterDarkAvailable()) {
    cout << "  preparing master dark" << endl;
    _FrameHolder.PrepareMasterDark(ref_info);
  }
    
  // prepare master flat and convert it to float
  if (_FrameHolder.IsMasterFlatAvailable()) {
    cout << "  preparing master flat" << endl;
    _FrameHolder.PrepareMasterFlat(ref_info); 
    _FrameHolder.GetMasterFlat().ChangeResolution(RT_Float, true);
    double median;
    _FrameHolder.GetMasterFlat().ComputeMedian(median, false);
    _FrameHolder.GetMasterFlat().Div(median);
  }

  cout << "  reducing lights" << endl;
     
  // go through all light frames
  for (uint i = 0; i < frames.GetCount(); i++) {
    
    // skip rejected
    if (frames.IsRejected(i)) continue;

    cout << "    loading frame " << i << endl;
    
    // load the frame
    frames.LoadFrame(i);

    cout << "    reducing frame" << endl;
    
    // Reduce the frame
    ReduceFrame(frames.GetFrame(i));

    cout << "    unloading frame" << endl;
    
    // unload the frame
    frames.UnloadFrame(i);
    
    // notify progress
    iNotifier.SetProgress((float)i/(float)valid_frames);
    
  } 
  
}

//----------------------------------------------------------------------------

void LightReducer::ReduceFrame(AstroImage &iFrame)
{
  AstroImage& Reduced = _FrameHolder.GetReducedFrames().AddFrame(
    new AstroImage(iFrame)
  );
 
  if (_FrameHolder.IsMasterBiasAvailable())
    Reduced.SubClamp(_FrameHolder.GetMasterBias());
    
  if (_FrameHolder.IsMasterDarkAvailable())
    Reduced.SubClamp(_FrameHolder.GetMasterDark());
   
  if (_FrameHolder.IsMasterFlatAvailable()) {
    EResolution old_res = Reduced.GetResolution();
    Reduced.ChangeResolution(RT_Float, false);
    Reduced.Div(_FrameHolder.GetMasterFlat());
    Reduced.ChangeResolution(old_res, false);
  }
  
  Reduced.SetFilename(_FrameHolder.GetReducedRawName(iFrame));
  _FrameHolder.MakePathForFile(Reduced.GetFilename());
  Reduced.ImageVariant::Save(Reduced.GetFilename().c_str());

  /*
  // create preview
  AstroImage preview(Reduced);
  preview.Normalize();
  preview.Balance(1.5, 1.0, 1.24);

  // convert Bayer to color
  EBayerToColorConversion Method = BCC_Bilinear;
  preview.ChangeToColor(Method);
  preview.ChangeResolution(RT_UShort);
  
  preview.ImageVariant::Save(_FrameHolder.GetReducedRgbName(iFrame).c_str());*/

  // unload Reduced frame to save memory
  _FrameHolder.GetReducedFrames().UnloadFrame(
    _FrameHolder.GetReducedFrames().GetCount()-1
  );
  
}

//----------------------------------------------------------------------------

bool LightReducer::CompareFileInfos(FrameList &iList, uint iA, uint iB, 
  string &oReason)
{
  // get frames to compare infos
  AstroImage &A = iList.GetFrame(iA);
  AstroImage &B = iList.GetFrame(iB);
  
  // get frame infos
  ImageFileInfo &A_info = A.GetInfo();
  ImageFileInfo &B_info = B.GetInfo();
  
  // compare frames sizes
  uint A_Width, A_Height;
  uint B_Width, B_Height;
  A_info.GetDimension(A_Width, A_Height);
  B_info.GetDimension(B_Width, B_Height);
  if ((A_Width != B_Width) || (A_Height != B_Height)) {
    oReason = "Frame "+B.GetFilename()+" size does not match the"
      " reference frame.";
    return false;
  } 
  
  // compare frames resolution
  EResolution A_Res, B_Res;
  A_info.GetResolution(A_Res);
  B_info.GetResolution(B_Res);
  if (A_Res != B_Res) {
    oReason = "Frame "+B.GetFilename()+" resolution does not match the"
      " reference frame.";
    return false;
  }
  
  // compare frames bayer matrices
  EBayerMatrix A_Bayer, B_Bayer;
  A_info.GetBayer(A_Bayer);
  B_info.GetBayer(B_Bayer);
  if (A_Bayer != B_Bayer) {
    oReason = "Frame "+B.GetFilename()+" bayer matrix does not match the"
      " reference frame.";
    return false;
  }
  
  return true;
}

//----------------------------------------------------------------------------

} // namespace Astro
} // namespace eLynx
