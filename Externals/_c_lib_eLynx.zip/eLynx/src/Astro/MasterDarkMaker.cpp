//============================================================================
//  MasterDarkMaker.cpp                                Astro.Component package
//============================================================================
//  Usage : creates master Dark frame
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/astro/MasterDarkMaker.h>

#include <boost/scoped_array.hpp>
using namespace boost;

#include <algorithm>
#include <iostream>
using namespace std;

namespace eLynx {
namespace Astro {
  
//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EMasterDarkMethod iMethod)
{
  static const char * ms_lut[4] = 
  { 
    "Mean", "Median", "Time scaled mean", "Time scaled median"
  };
  return ms_lut[iMethod];

} // elxToString
  

//----------------------------------------------------------------------------

MasterDarkMaker::MasterDarkMaker(FrameHolder &ioHolder) 
  : CommonMasterMaker(ioHolder)
{
}

//----------------------------------------------------------------------------
// creates master dark frame in the frame holder

void MasterDarkMaker::MakeMasterDark(EMasterDarkMethod iMethod, 
  ProgressNotifier &iNotifier)
{
  
  cout << "MakeMasterDark" << endl;
  
  // get the list of dark frames
  FrameList &frames = GetFrameList();
  
  // get the reference frame (as first valid frame)
  int ref = GetFirstValidFrame(frames);
  if (ref == -1)
    elxThrow(elxErrInvalidContext, "No valid dark frames.");
    
  cout << "  first valid frame = " << ref << endl;
    
  // check, if the method includes frame scaling
  bool scaled = (iMethod == MDM_TimeScaledMean || 
    iMethod == MDM_TimeScaledMedian); 
   
  // check the list to get number of valid frames
  uint valids;
  string reason;
  CheckList(ref, scaled, true, valids, reason, iNotifier);
  
  cout << "  list checked, " << valids << " valid frames" << endl;
  cout << "  reason = " << reason << endl;
  
  // init the progress notifier
  iNotifier.SetProgress(0.0f);
  
  // if master bias is available, subtract it from all valid dark frames
  if (_FrameHolder.IsMasterBiasAvailable()) {
    
    cout << "  preparing master bias" << endl;
    
    // prepare the image
    _FrameHolder.PrepareMasterBias(frames.GetFrame(ref).GetInfo());
  }
  
  // if there is just one valid frame, we will use it as master dark
  if (valids == 1) {
    
    cout << "  just one dark frame, using as master" << endl;
    
    // load it into memory
    frames.LoadFrame(ref);
    
    // preprocess the frame
    PreprocessFrame(frames.GetFrame(ref));
    
    // copy the valid frame to master dark
    GetMasterFrame() = frames.GetFrame(ref);
    
    // set the master dark filename
    GetMasterFrame().SetFilename(
      _FrameHolder.GetDefaultMasterDarkName(frames.GetFrame(ref))
      );
     
    // update the progress notifier
    iNotifier.SetProgress(1.0f);
    
  }
  
  // if there are more dark frames
  else {

    cout << "  loading all frames" << endl;

    frames.LoadAllFrames(iNotifier);
    
    // !!!!!!!!!!!!!!!!!!!!!
    // preprocess the frames
    // !!!!!!!!!!!!!!!!!!!!!
    
    cout << "  scaling frames" << endl;
    
    // if required, scale all frames to the reference shutter
    if (scaled) ScaleFrames(frames, valids);
    
    cout << "  getting variant list" << endl;
    
    // get the list of valid frames as const ImageVariant pointers
    vector<const ImageVariant*> valid_frames;
    frames.GetConstVariantList(valid_frames, true);
    
    // init the operator
    EImageListOperator op = ILO_Median;
    switch (iMethod)
    {
      case MDM_Mean:   
      case MDM_TimeScaledMean :   op = ILO_Mean; break;
      case MDM_Median:
      case MDM_TimeScaledMedian : op = ILO_Median; break;
      default: break;
    } 
    
    cout << "  building master dark" << endl;
    
    // try to build the master dark frame 
    bool success = GetMasterFrame().ImageVariant::Build(
      op, valid_frames, CM_All, iNotifier);
      
    // if not successfull, throw an exception
    if (!success) 
      elxThrow(elxErrOperationFailed, elxMsgFormat("Failed to build master dark"
        " from the list of %i valid bias frames.", valids));
        
    
  }
  
  cout << "  saving master dark" << endl;
  
  // set the master dark filename
  GetMasterFrame().SetFilename(
    _FrameHolder.GetDefaultMasterDarkName(frames.GetFrame(ref))
    );
  
  // update master dark image file info
  ImageFileInfo info = frames.GetFrame(ref).GetInfo();
  info.SetResolution(GetMasterFrame().GetResolution());
  GetMasterFrame().GetInfo() = info;
  
  // save the master dark
  _FrameHolder.MakePathForFile(GetMasterFrame().GetFilename());
  GetMasterFrame().ImageVariant::Save(
    GetMasterFrame().GetFilename().c_str(), iNotifier);
    
  // unload dark frames, they're no longer needed
  GetFrameList().UnloadAllFrames();

}

//----------------------------------------------------------------------------
// scales all valid frames to the reference shutter

void MasterDarkMaker::ScaleFrames(FrameList &iFrames, uint iValidFrames)
{
  // prepare array of shutter values
  scoped_array<float> shutters(new float[iValidFrames]);
  
  // collect shutter values
  uint index = 0;
  for (uint i = 0; i < iFrames.GetCount(); i++)
    if (!iFrames.IsRejected(i)) {
      ImageFileInfo &info = iFrames.GetFrame(i).GetInfo();
      info.GetShutter(shutters[index++]);
    }
    
  // sort the array
  sort(shutters.get(), shutters.get()+iValidFrames);
  
  // take the median
  float ref_shutter;
  index = iValidFrames/2;
  if (iValidFrames%2 == 0) 
    ref_shutter =(shutters[index-1]+shutters[index])/2.0f;
  else ref_shutter = shutters[index];
  
  // scale valid frames
  for (uint i = 0; i < iFrames.GetCount(); i++)
    if (!iFrames.IsRejected(i)) {
      // get image shutter value
      ImageFileInfo &info = iFrames.GetFrame(i).GetInfo();
      float shutter;
      info.GetShutter(shutter);
      
      // compute scale factor
      double scale = (double)ref_shutter/(double)shutter;
      
      // if it differs from 1.0, scale the image
      if (fabs(scale-1.0) > 1e-6)
        iFrames.GetFrame(i).MulClamp(scale);
    }
}

//----------------------------------------------------------------------------
// saves master dark preview and thumbnail

void MasterDarkMaker::SavePreview()
{
  CommonMasterMaker::SavePreview(
    _FrameHolder.GetMasterFramePreviewName(_FrameHolder.GetMasterDark()),
    0, 0,
    _FrameHolder.GetMasterFrameThumbnailName(_FrameHolder.GetMasterDark()),
    _FrameHolder.GetThumbnailWidth(), _FrameHolder.GetThumbnailHeight());
}

//----------------------------------------------------------------------------

void MasterDarkMaker::PreprocessFrame(AstroImage& ioFrame)
{
  if (_FrameHolder.IsMasterBiasAvailable())
    ioFrame.SubClamp(_FrameHolder.GetMasterBias());
}

//----------------------------------------------------------------------------

} // namespace Astro
} // namespace eLynx
