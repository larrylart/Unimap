//============================================================================
//  AstroProject.cpp                                   Astro.Component package
//============================================================================
//  Usage : astronomical image processing project class implementation.
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <stdio.h>

#include <elx/core/CoreMacros.h>
#include <elx/core/CoreFile.h>
#include <elx/astro/AstroProject.h>
#include <elx/astro/AstroProjectParser.h>
#include <elx/astro/AstroImage.h>
#include <elx/image/ImageFileManager.h>
#include <elx/image/ImageFileInfo.h>
#include <elx/image/ImageImpl.h>
#include <elx/astro/ThresholdStarDetector.h>

#include <iostream>
using namespace std;

namespace eLynx {
namespace Astro {

//#define MORE_INFO

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EAstroProjectType iType)
{
  static const char * ms_lut[APT_Unknown+1] =
  {
    "Deep sky", "Planetary", "Moon mosaic", "Solar corona", "Comet", "Unknown"
  };
  return ms_lut[iType];

} // elxToString


//----------------------------------------------------------------------------
//  default constructor
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
AstroProject::AstroProject(
  EAstroProjectType iType,
  const char * iprPath) : 
  _Type(iType)
{
  _ProjectName[0] = _DataPath[0] = '\0';
  if (NULL != iprPath)
    SetDataPath(iprPath);
}

//----------------------------------------------------------------------------
//  destructor
//----------------------------------------------------------------------------
//  public virtual
//----------------------------------------------------------------------------
AstroProject::~AstroProject()
{
  Reset();
  
} // destructor


//----------------------------------------------------------------------------
//  Reset
//----------------------------------------------------------------------------
void AstroProject::Reset()
{
  _ProjectName[0] = _DataPath[0] = '\0';
  _FrameHolder.ClearAll();

} // Reset


//----------------------------------------------------------------------------
//  Construction from filename
//----------------------------------------------------------------------------
AstroProject::AstroProject(const char * iprFilename):
  _Type(APT_Unknown)
{
  _ProjectName[0] = _DataPath[0] = '\0';
  Load(iprFilename);
}

//----------------------------------------------------------------------------
EAstroProjectType AstroProject::GetType() const     { return _Type; }
void AstroProject::SetType(EAstroProjectType iType) { _Type = iType; }

//----------------------------------------------------------------------------
const char * AstroProject::GetProjectName() const { return _ProjectName; }
void AstroProject::SetProjectName(const char * iprName) 
{ 
  if (NULL == iprName)
  {
    _ProjectName[0] = '\0';
    return;
  }
  ::strcpy(_ProjectName, iprName);
  elxForceFilename(_DataPath);
}

//----------------------------------------------------------------------------
const char * AstroProject::GetDataPath() const { return _DataPath; }
void AstroProject::SetDataPath(const char * iprName) 
{ 
  if (NULL == iprName)
  {
    _DataPath[0] = '\0';
    return;
  }
  strcpy(_DataPath, iprName);
  elxForceFilename(_DataPath);

  // add last separator
  const size_t l = ::strlen(_DataPath);
  if ((l > 0) && (_DataPath[l-1] == elxPATH_SEPARATOR))
    return;

  _DataPath[l] = elxPATH_SEPARATOR;
  _DataPath[l+1] = '\0';

} // SetDataPath


//----------------------------------------------------------------------------
//  Load
//----------------------------------------------------------------------------
bool AstroProject::Load(const char * iprFilename)
{
  // forget current datas
  _Type = APT_Unknown;
  _ProjectName[0] = _DataPath[0] = '\0';
  if (NULL == iprFilename) return false;
  bool bSuccess = false;
  
  // Init parser
  DOMParser::Init();
  
  // create the parser and parse the config file
  AstroProjectParser parser;
  parser.LoadProjectInfo(iprFilename);
  
  // Clean up  
  DOMParser::CleanUp(); 
  return bSuccess;
} // Load


//----------------------------------------------------------------------------
//  Save
//----------------------------------------------------------------------------
bool AstroProject::Save(const char * iprFilename) 
{
  if ((NULL == iprFilename) && (_ProjectName[0] == '\0'))
    return false;

  if (NULL != iprFilename)
    SetProjectName(iprFilename);
    
  // Init parser
  DOMParser::Init();
  // create the parser and save the config file
  AstroProjectParser parser;
  parser.SaveProjectInfo(iprFilename, *this);
  // Clean up  
  DOMParser::CleanUp(); 
    
  return true;
} // Save


//----------------------------------------------------------------------------
//  ComputeGlobalExposureTime : TODO modify to take into account rejected frame
//----------------------------------------------------------------------------
int AstroProject::ComputeGlobalExposureTime()
{
  int count =_FrameHolder.GetLightFrames().GetCount();
  if (0 == count) return 0;

  float shutter;
  int sum = 0;
  for (int i=0; i<count; i++)
  {
/*
    _FrameHolder.GetLightFrames().GetFrame(i);
    IsRejected()
*/
    const ImageFileInfo& info = _FrameHolder.GetLightFrames().GetFrame(i).GetInfo();
    if (info.GetShutter(shutter)) 
      sum += int(shutter);
  }
  return sum;

} // ComputeGlobalExposureTime


//----------------------------------------------------------------------------
//  GetDetectedFileCount
//----------------------------------------------------------------------------
uint AstroProject::GetDetectedFileCount() const
{
  return _FrameHolder.GetBiasFrames().GetCount() + 
    _FrameHolder.GetDarkFrames().GetCount() + 
    _FrameHolder.GetFlatFrames().GetCount() + 
    _FrameHolder.GetLightFrames().GetCount();
         
} // GetDetectedFileCount

//----------------------------------------------------------------------------
//  GetValidImage
//----------------------------------------------------------------------------
const AstroImage * AstroProject::GetValidImage() const
{
  if (_FrameHolder.GetLightFrames().GetCount()) 
    return &(_FrameHolder.GetLightFrames().GetFrame(0));
  
  if (_FrameHolder.GetBiasFrames().GetCount()) 
    return &(_FrameHolder.GetBiasFrames().GetFrame(0));
  
  if (_FrameHolder.GetDarkFrames().GetCount()) 
    return &(_FrameHolder.GetDarkFrames().GetFrame(0));
    
  if (_FrameHolder.GetFlatFrames().GetCount()) 
    return &(_FrameHolder.GetFlatFrames().GetFrame(0));
    
  return NULL; 

} // GetValidImage


//----------------------------------------------------------------------------
bool AstroProject::GetPreviewPath(char * ioprPath) const
{
  if (NULL == ioprPath) return false;
  ::sprintf(ioprPath, "%sPreviews", _DataPath);
  return true;
}
//----------------------------------------------------------------------------
bool AstroProject::GetMasterPath(char * ioprPath) const
{
  if (NULL == ioprPath) return false;
  ::sprintf(ioprPath, "%sMasters", _DataPath);
  return true;
}
//----------------------------------------------------------------------------
bool AstroProject::GetReducedPath(char * ioprPath) const
{
  if (NULL == ioprPath) return false;
  ::sprintf(ioprPath, "%sReduced", _DataPath);
  return true;
}

//----------------------------------------------------------------------------
//  CheckBiasList
//----------------------------------------------------------------------------
bool AstroProject::CheckBiasList(
    uint iReference, 
    string &oReason,
    ProgressNotifier &iNotifier)
{
  MasterBiasMaker maker(_FrameHolder);
  uint valid_frames;
  bool bSuccess = maker.CheckList(iReference, false, true, valid_frames,
                                   oReason,iNotifier);
  if (bSuccess) 
    iNotifier.Log("All frames checked ok.");
  else 
  {
    iNotifier.Log("Some files were rejected because of reason:");
    iNotifier.Log(oReason.c_str());
  }
  return bSuccess;

} // CheckBiasList


//----------------------------------------------------------------------------
//  MakeMasterBias
//----------------------------------------------------------------------------
bool AstroProject::MakeMasterBias(
    EMasterBiasMethod iMethod, 
    bool ibGeneratePreview, 
    ProgressNotifier& iNotifier)
{
  if (_FrameHolder.GetBiasFrames().GetCount() == 0) return false;
  
  cout << "mastering bias" << endl;
  
  MasterBiasMaker maker(_FrameHolder);
  maker.MakeMasterBias(iMethod, 50*1024, iNotifier);

  if (ibGeneratePreview) maker.SavePreview();
    
  return true;

} // MakeMasterBias


//----------------------------------------------------------------------------
//  CheckDarkList
//----------------------------------------------------------------------------
bool AstroProject::CheckDarkList(
    uint iReference, 
    string &oReason,
    ProgressNotifier &iNotifier)
{
  MasterDarkMaker maker(_FrameHolder);
  uint valid_frames;
  bool bSuccess = maker.CheckList(iReference, true, true, valid_frames, 
                                    oReason, iNotifier);
  if (bSuccess) 
    iNotifier.Log("All frames checked ok.");
  else 
  {
    iNotifier.Log("Some files were rejected because of reason:");
    iNotifier.Log(oReason.c_str());
  }
  return bSuccess;

} // CheckDarkList


//----------------------------------------------------------------------------
//  MakeMasterDark
//----------------------------------------------------------------------------
bool AstroProject::MakeMasterDark(
    EMasterDarkMethod iMethod, 
    bool ibGeneratePreview, 
    ProgressNotifier& iNotifier)
{
  if (_FrameHolder.GetDarkFrames().GetCount() == 0) return false;
  
  cout << "mastering dark" << endl;
  
  MasterDarkMaker maker(_FrameHolder);
  maker.MakeMasterDark(iMethod, iNotifier);
  
  if (ibGeneratePreview) maker.SavePreview();

  return true;

} // MakeMasterDark


//----------------------------------------------------------------------------
//  CheckFlatList
//----------------------------------------------------------------------------
bool AstroProject::CheckFlatList(
    uint iReference, 
    string &oReason,
    ProgressNotifier &iNotifier)
{
  MasterFlatMaker maker(_FrameHolder);
  uint valid_frames;
  bool bSuccess = maker.CheckList(iReference, true, true, valid_frames, 
                                  oReason, iNotifier);
  if (bSuccess) 
    iNotifier.Log("All frames checked ok.");
  else 
  {
    iNotifier.Log("Some files were rejected because of reason:");
    iNotifier.Log(oReason.c_str());
  }
  return bSuccess;

} // CheckFlatList


//----------------------------------------------------------------------------
//  MakeMasterFlat
//----------------------------------------------------------------------------
bool AstroProject::MakeMasterFlat(
    EMasterFlatMethod iMethod, 
    bool ibGeneratePreview, 
    ProgressNotifier& iNotifier)
{
  if (_FrameHolder.GetFlatFrames().GetCount() == 0) return false;
  
  cout << "mastering flat" << endl;
  
  MasterFlatMaker maker(_FrameHolder);
  maker.MakeMasterFlat(iMethod, iNotifier);

  if (ibGeneratePreview) maker.SavePreview();
    
  return true;

} // MakeMasterFlat


//----------------------------------------------------------------------------
//  CheckLightList
//----------------------------------------------------------------------------
bool AstroProject::CheckLightList(
    uint iReference, 
    string &oReason,
    ProgressNotifier &iNotifier)
{
  LightReducer reducer(_FrameHolder);
  uint valid_frames;
  bool bSuccess = reducer.CheckList(iReference, true, valid_frames, 
                                    oReason, iNotifier);
  if (bSuccess) 
    iNotifier.Log("All frames checked ok.");
  else 
  {
    iNotifier.Log("Some files were rejected because of reason:");
    iNotifier.Log(oReason.c_str());
  }
  return bSuccess;

} // CheckLightList


//----------------------------------------------------------------------------
//  ReduceLights
//----------------------------------------------------------------------------
bool AstroProject::ReduceLights(ProgressNotifier& iNotifier)
{
  if (_FrameHolder.GetLightFrames().GetCount() == 0) return false;

  cout << "reducing lights" << endl;

  LightReducer reducer(_FrameHolder);
  reducer.ReduceLights(iNotifier);

  return true;

} // ReduceLights

//----------------------------------------------------------------------------
//  DetectStars
//----------------------------------------------------------------------------
bool AstroProject::DetectStars(ProgressNotifier& iNotifier)
{
  // check, if there's something to detect stars on
  FrameList &frames = _FrameHolder.GetReducedFrames(); 
  if (frames.GetCount() == 0) return false;
  
  cout << "detecting stars" << endl;
  
  // create the star detector 
  ThresholdStarDetector detector;
  detector.SetRelativeValue(0.8f);
  
  // init the progress notifier
  iNotifier.SetProgress(0.0f);
  
  // get the number of valid frames
  uint valid_frames = frames.GetValidCount();
  uint processed_frames = 0;
  
  cout << "  on " << valid_frames << " reduced frames" << endl;
  
  // go through the reduced frames
  for (uint i = 0; i < frames.GetCount(); i++) {
    
    // skip rejected frames
    if (frames.IsRejected(i)) continue;
    
    cout << "detecting stars on frame " << frames.GetFrame(i).GetFileNameExt() 
      << endl;
      
    // load the frame into memory
    frames.LoadFrame(i);
    AstroImage &frame = frames.GetFrame(i);
    
    // detect the stars
    frame.DetectStars(detector);
    
    cout << "  " << frame.GetStarsCount() << " stars detected, ";
    cout << " image score is " << frame.GetImageScore() << endl;
    
    // save stars information file
    frame.SaveStarsInfo(_FrameHolder.GetReducedInfoFileName(frame));
    
    try {
      frame.LoadStarsInfo(_FrameHolder.GetReducedInfoFileName(frame));
      cout << "xml back load ok" << endl;
    }
    catch (elxException &e) {
      cout << e._what << endl;
    }
    
    // unload the frame
    frames.UnloadFrame(i);
    
    // update the progress
    iNotifier.SetProgress((float)(processed_frames+1) / (float)valid_frames);
    processed_frames++;
  }
  
  return true;
  
} // DetectStars

bool AstroProject::RegisterLights(uint iBaseFrame, ProgressNotifier& iNotifier)
{
  // check, if there's something to detect stars on
  FrameList &frames = _FrameHolder.GetReducedFrames(); 
  if (frames.GetCount() == 0) return false;
  
  // check the base frame validity
  if (iBaseFrame >= frames.GetCount())
    elxThrow(elxErrOutOfRange, 
      elxMsgFormat("Base frame index %i out of range <0, %i>.",
        iBaseFrame, frames.GetCount()));
        
  if (frames.IsRejected(iBaseFrame))
    elxThrow(elxErrInvalidContext,
      elxMsgFormat("Invalid base frame %i.", iBaseFrame)); 
      
  // get the image other images will be registered to
  AstroImage &base_frame = frames.GetFrame(iBaseFrame);
  cout << "registering to image " << base_frame.GetFileNameExt() << endl;
  
  // prepare the registration params (default ones)
  RegistrationParams params;
  
  // init the progress notifier
  iNotifier.SetProgress(0.0f);
  
  // get the number of valid frames
  uint valid_frames = frames.GetValidCount();
  uint processed_frames = 0;
  
  // go through all the reduced frames
  for (uint i = 0; i < frames.GetCount(); i++) {
    
    // skip rejected frames and the base frame
    if (i == iBaseFrame || frames.IsRejected(i)) continue;
    
    // get the frame to register
    AstroImage &frame = frames.GetFrame(i);
    
    cout << "registering image " << frame.GetFileNameExt() << " to the base frame...";
    
    // register image to the base frame
    bool result = frame.RegisterImage(params, base_frame, iNotifier);
    
    // if not successfull, reject frame from the further processing
    if (!result) {
      frames.RejectFrame(i);
      cout << "failed!" << endl;
    }
    else cout << "success!" << endl;
    
    // update the progress
    iNotifier.SetProgress((float)(processed_frames+1) / (float)valid_frames);
    processed_frames++;
  }
  
  return true;
}

//----------------------------------------------------------------------------
//  UnloadAllFrames
//----------------------------------------------------------------------------
bool AstroProject::UnloadAllFrames(int iSelection)
{
  GetBiasList().UnloadAllFrames(iSelection);
  GetDarkList().UnloadAllFrames(iSelection);
  GetFlatList().UnloadAllFrames(iSelection);
  GetLightList().UnloadAllFrames(iSelection);
  return true;

} // UnloadAllFrames


//----------------------------------------------------------------------------

using namespace eLynx::Math;
#include "AstroProject_Detection.cpp"
#include "AstroProject_Sort.cpp"
#include "AstroProject_Report.cpp"

} // namespace Astro
} // namespace eLynx
