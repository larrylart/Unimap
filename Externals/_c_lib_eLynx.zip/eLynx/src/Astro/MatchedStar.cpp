//============================================================================
//  MatchedStar.cpp                                    Astro.Component package
//============================================================================
//  Usage : star match - reference to two images of the same star on two
//  pictures
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/astro/MatchedStar.h>

namespace eLynx {
namespace Astro {
	
//--------------------------------------------------------
// constructor, creates uninitialized matched star
	
MatchedStar::MatchedStar()
{
	_prImages[msiBase] = _prImages[msiRegistered] = NULL;
	_StarIndices[msiBase] = _StarIndices[msiRegistered] = 0;
	_Matches = 0;
}


//--------------------------------------------------------
// copy constructor
	
MatchedStar::MatchedStar(const MatchedStar &c)
{
	CopyData(c);
}


//--------------------------------------------------------
// an assignement operator 
	
MatchedStar& MatchedStar::operator = (const MatchedStar &c)
{
	if (&c != this) CopyData(c);
	return *this;
}


//--------------------------------------------------------
// returns specified image record
	
const ImageRecord* MatchedStar::GetImage(MatchedStarImage iImage) const
{
	// check index
	if (iImage < msiBase || iImage > msiRegistered)
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %i out of range <0, 1>.", iImage));

	return _prImages[iImage];
}


//--------------------------------------------------------
// sets specified image record
	
void MatchedStar::SetImage(MatchedStarImage iImage, const ImageRecord *iprImage)
{
	// check index
	if (iImage < msiBase || iImage > msiRegistered)
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %i out of range <0, 1>.", iImage));
	
	_prImages[iImage] = iprImage;
}


//--------------------------------------------------------
// returns specified star index

uint MatchedStar::GetStarIndex(MatchedStarImage iImage) const
{
	// check index
	if (iImage < msiBase || iImage > msiRegistered)
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %i out of range <0, 1>.", iImage));
	
	return _StarIndices[iImage];
}


//--------------------------------------------------------
// sets specified star index
	
void MatchedStar::SetStarIndex(MatchedStarImage iImage, uint iStarIndex)
{
	// check index
	if (iImage < msiBase || iImage > msiRegistered)
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %i out of range <0, 1>.", iImage));

	// check image validity
	if (GetImage(iImage) == NULL)
		elxThrow(elxErrInvalidContext, elxMsgFormat("Image %i not defined.", iImage));
		
	// check star index validity
	if (iStarIndex >= GetImage(iImage)->GetStarCount())
		elxThrow(elxErrOutOfRange, elxMsgFormat("Star index %i out of bounds of image star list"
			" <0, %i>.", iStarIndex, GetImage(iImage)->GetStarCount()));
	
	_StarIndices[iImage] = iStarIndex;
}


//--------------------------------------------------------
// returns specified star
	
const Star& MatchedStar::GetStar(MatchedStarImage iImage) const
{
	// check index
	if (iImage < msiBase || iImage > msiRegistered)
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %i out of range <0, 1>.", iImage));

	// check image validity
	if (GetImage(iImage) == NULL)
		elxThrow(elxErrInvalidContext, elxMsgFormat("Image %i not defined.", iImage));
	
	return GetImage(iImage)->GetStar(GetStarIndex(iImage));
}


//--------------------------------------------------------
// returns number of matches for this star

uint MatchedStar::GetMatches() const
{
	return _Matches;
}


//--------------------------------------------------------
// sets number of matches for this star

void MatchedStar::SetMatches(uint iMatches)
{
	_Matches = iMatches;
}


//--------------------------------------------------------
// copies object data
	
void MatchedStar::CopyData(const MatchedStar &c)
{
	_prImages[0] = c._prImages[0];
	_prImages[1] = c._prImages[1];
	_StarIndices[0] = c._StarIndices[0];
	_StarIndices[1] = c._StarIndices[1];
	_Matches = c._Matches;
}

//--------------------------------------------------------
	
} // namespace Astro
} // namespace eLynx
