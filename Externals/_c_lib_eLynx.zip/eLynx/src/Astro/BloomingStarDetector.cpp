//============================================================================
//  BloomingStarDetector.cpp                           Astro.Component package
//============================================================================
//  Usage : blooming star detector
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <boost/scoped_ptr.hpp>

#include <elx/image/PixelIterator.h>
#include <elx/astro/BloomingStarDetector.h>
#include <elx/astro/ThresholdStarDetector.h>
#include <elx/math/Matrix.h>

namespace eLynx {
namespace Astro {
	
using namespace eLynx::Image;

//----------------------------------------------------------------------------
// constructor, initializes star detector
//----------------------------------------------------------------------------
BloomingStarDetector::BloomingStarDetector(
  const Math::Point2f& iBloomVector,
  uint iMaxStarDiameter, 
  float iThreshold, 
  float iMinRatio) :
  _bloomingVector(iBloomVector),
  _maxStarDiameter(iMaxStarDiameter), 
  _threshold(iThreshold),
  _minRatio(iMinRatio)
{}

	
//----------------------------------------------------------------------------
// detects blooming stars on the image
//----------------------------------------------------------------------------
void BloomingStarDetector::DetectStars(
    const ImageVariant& iImage, 
    BloomingStarList& oStars) const
{
  // convert image into float-based luminance image if needed
  boost::scoped_ptr<Image::ImageVariant> spLuminanceImage;
  if (!iImage.IsLf())
  {
    spLuminanceImage.reset(new ImageVariant(iImage));
    spLuminanceImage->ChangePixelFormat(PF_Lf);
    if (!spLuminanceImage->IsLf())
      elxThrow(elxErrOperationFailed, "Unable to change image pixel format.");
  }
  const Image::ImageVariant* pLuminanceImage = 
    (iImage.IsLf()) ? &iImage : spLuminanceImage.get();
    
  // detect star candidates using threshold star detector 
  BloomingStarList star_candidates;
  ThresholdStarDetector tsd;

  // set threshold value to x-times background
  tsd.SetOffsetValue(_threshold);

  // and detect star candidates
  tsd.DetectStars(*pLuminanceImage, star_candidates);
  
  // examine star candidates 
  for (uint i = 0; i < star_candidates.size(); i++)
    if (DetectStar(*pLuminanceImage, star_candidates[i])) 
      oStars.push_back(star_candidates[i]);

} // DetectStars

  
//----------------------------------------------------------------------------
// examines blooming star candidate
//----------------------------------------------------------------------------
bool BloomingStarDetector::DetectStar(
    const ImageVariant &iImage, 
    BloomingStar &ioCandidate) const
{
  // identify all star's pixels which belong to the line coming through the star's
  // center (max diameter) and parallel to the blooming direction 
  Math::Point2iList bloomLine;
  CalculateCrossLine(ioCandidate, iImage, _bloomingVector, bloomLine);
  // identify all star's pixels which belong to the line coming through the star's
  // center (max diameter) and perpendicular to the blooming direction 
  Math::Point2iList otherLine;
  Math::Point2f otherDir(-_bloomingVector._y, _bloomingVector._x);
  CalculateCrossLine(ioCandidate, iImage, otherDir, otherLine);
  
  // Star's linear size in the blooming and perperndicular directions
  float dbloom = EstimateStarDiameter(bloomLine);
  float dother = EstimateStarDiameter(otherLine);
  BOOST_ASSERT(dother > 0.f);
  if (dbloom/dother < _minRatio)
    return false;
    
  // Compute Geometrical center
  const uint size = otherLine.size(); 
  float x = float(otherLine[0]._x + otherLine[size-1]._x) / 2.0f;
  float y = float(otherLine[0]._y + otherLine[size-1]._y) / 2.0f;
  ioCandidate.SetPosition(x, y);  

  // Set star's diameter
  ioCandidate.SetDiameter(dother);
  
  // reject star candidates with too big diameter
  float d = (float)ioCandidate.GetDiameter();
  if (d > _maxStarDiameter) return false;
      
  // evaluate star candidate gaussian profile in the directions
  // other then blooming direction (for example 90 degree)
  float g0, h, b, i0, err;
  bool ok = EvaluateProfile(iImage, ioCandidate, otherLine, g0, h, b, i0, err);
    
  if (!ok) 
    return false;
  if (g0 < 0.0f || g0 > 5.0f || h <= 0.5f || b > 1.0f) 
    return false;
    
 ioCandidate.SetCentralLuminance(i0);
 ioCandidate.SetBackgroundLuminance(b);
 ioCandidate.SetHalfLuminanceRadius(h);
 ioCandidate.SetApproximationError(err);
  
  return true;

} // DetectStar


struct Partition
{
  Partition(uint iMaxValue, uint iPercent) :
    _threshold (iMaxValue*iPercent)
  {}

  bool operator()(const std::pair<uint, uint>& iTuple) const
  {
    return iTuple.second * 100 > _threshold;
  }
  uint _threshold;
};

//----------------------------------------------------------------------------
// Identifies star's diameter in a given direction by sliding accross the
// the star's box and finding the position where crosssection of the
// sliding line and star has max amount of star's pixel 
//----------------------------------------------------------------------------
void BloomingStarDetector::CalculateCrossLine(
    const BloomingStar& iStar, 
    const Image::ImageVariant &iImage, 
    const Math::Point2f& iDirection, 
    Math::Point2iList& oLine) const
{
  const Math::Point2i& upperLeft = iStar.GetUpperLeft();
  const Math::Point2i& lowerRight = iStar.GetLowerRight();
  const BaseStarDetector::PixelMap starMap = iStar.GetThresholdMap();
  
  const uint w = iImage.GetWidth();
  const uint h = iImage.GetHeight();
  const int dx = lowerRight._x - upperLeft._x + 1;
  const int dy = lowerRight._y - upperLeft._y + 1;
  Math::Point2iList iteratePoints;
  iteratePoints.reserve(dx + dy);
  if (iDirection._x == 0)
    for (int x = upperLeft._x; x <= lowerRight._x; ++x)
      iteratePoints.push_back(Math::Point2i(x, lowerRight._y));
  else if (iDirection._y == 0)
    for (int y = upperLeft._y; y <= lowerRight._y; ++y)
      iteratePoints.push_back(Math::Point2i(upperLeft._x, y));
  else if (iDirection._x * iDirection._y > 0)
  {
    for (int y = lowerRight._y; y >= upperLeft._y; --y)
      iteratePoints.push_back(Math::Point2i(upperLeft._x, y));
    for (int x = upperLeft._x; x <= lowerRight._x; ++x)
      iteratePoints.push_back(Math::Point2i(x, upperLeft._y));
  }
  else
  {
    for (int x = upperLeft._x; x <= lowerRight._x; ++x)
      iteratePoints.push_back(Math::Point2i(x, upperLeft._y));
    for (int y = upperLeft._y; y <= lowerRight._y; ++y)
      iteratePoints.push_back(Math::Point2i(lowerRight._x, y));
  }
       
  const uint size = iteratePoints.size();
  uint maxPixelCount = 0;
  Math::Segment2i segment;
  Math::Rectangle2i rectangle(upperLeft, lowerRight);
  Math::Point2iList crossLine;
  // vector of tuples to keep track of cross line size for every position
  // The first element is position, the second is the size
  std::vector<std::pair<uint, uint> > sizeMap;
  for (uint i = 0; i < size; ++i)
  {
    crossLine.clear();
    
    // Calculate intersection points of the line passing through the next point
    // and star's circumferent rectangle
    const Math::Point2i& p1 = iteratePoints[i];
    const Math::Point2i p2(
      int(Math::elxRound(float(p1._x)+iDirection._x)), 
      int(Math::elxRound(float(p1._y+iDirection._y)))); 
    BOOST_ASSERT(Math::elxIntersectLineRectangle(p1, p2, rectangle, segment));
  
    // Compute all points of this line
    Math::elxComputeLinePoints(segment._P0, segment._P1, w, h, crossLine);
    // remove ones that below the threshold
    uint crossSize = crossLine.size();
    uint currentCount = 0;
    for (uint j = 0; j < crossSize; ++j)
    {
      uint idx = 
        (crossLine[j]._y - upperLeft._y)*dx + crossLine[j]._x - upperLeft._x;
      if (elxSPT_IS_STAR(starMap[idx]))
        ++currentCount;
    }
    sizeMap.push_back(std::make_pair(i,currentCount)); 
    if (maxPixelCount < currentCount)
      maxPixelCount = currentCount;
  }
  
  // now find all cases where size of the line is > 95% of the maxPixelCount
  std::vector<std::pair<uint, uint> >::iterator itMiddle = 
    std::partition(sizeMap.begin(), sizeMap.end(), Partition( maxPixelCount, 95));
  const uint partSize = itMiddle - sizeMap.begin();
  BOOST_ASSERT(partSize > 0);
  // compute the middle position
  float findex = 0;
  for (uint i = 0; i < partSize; ++i)
     findex += float(sizeMap[i].first);
  uint index = uint(Math::elxRound(findex/float(partSize)));  
    
  // Recalculate the cross line 
  const Math::Point2i& p1 = iteratePoints[index];
  const Math::Point2i p2(
    int(Math::elxRound(float(p1._x)+iDirection._x)), 
    int(Math::elxRound(float(p1._y+iDirection._y)))); 
  BOOST_ASSERT(Math::elxIntersectLineRectangle(p1, p2, rectangle, segment));
  // Compute all points of this line
  Math::elxComputeLinePoints(segment._P0, segment._P1, w, h, oLine);
  // remove ones that below the threshold
  for (Math::Point2iList::iterator pIt = oLine.begin();
       pIt != oLine.end();)
  {
    uint idx = (pIt->_y - upperLeft._y)*dx + pIt->_x - upperLeft._x;
    if (elxSPT_IS_STAR(starMap[idx]))
      ++pIt;
    else
      pIt = oLine.erase(pIt);
  }

} // CalculateCrossLine


//----------------------------------------------------------------------------
// Estimates star's diameter in a given direction
//----------------------------------------------------------------------------
float BloomingStarDetector::EstimateStarDiameter(const Math::Point2iList& iLine) const
{
  BOOST_ASSERT(!iLine.empty()); 
  const uint size = iLine.size();
  const float dx = float(iLine[0]._x - iLine[size-1]._x + 1);
  const float dy = float(iLine[0]._y - iLine[size-1]._y + 1);
  return Math::elxSqrt(Math::elxSqr(dx) + Math::elxSqr(dy));

} // EstimateStarDiameter
	
//----------------------------------------------------------------------------
// evaluates star gaussian profile
//----------------------------------------------------------------------------
bool BloomingStarDetector::EvaluateProfile(
  const Image::ImageVariant &iImage, 
  const BloomingStar& iCandidate, 
  const Math::Point2iList& iCrossLine, 
  float &oG0, float &oH, float &oB, float &oI0,
  float &oError) const
{  
  PixelIterator<const PixelLf> pixelItBegin = 
    elxConstDowncast<const PixelLf>(iImage.Begin());
  PixelIterator<const PixelLf> pixelIt = pixelItBegin;
  
  // compute center of the image region
  uint xc = (uint)iCandidate.GetX();
  uint yc = (uint)iCandidate.GetY();
      
  // go through the region along the direction line
  //Math::Matrix samples(d*d, 3);
  uint size = iCrossLine.size();
  
  Math::Matrix samples(size, 2);
  
  // init matrix row index
  uint index = 0;
  int prevx = 0, prevy = 0;  
  for (uint i = 0; i < size; ++i) 
  {
    pixelIt.advance(iCrossLine[i]._x - prevx, iCrossLine[i]._y - prevy);
    samples(index, 0) = Math::elxSqrt(
      float(Math::elxSqr(iCrossLine[i]._x - xc) +
            Math::elxSqr(iCrossLine[i]._y - yc)));
    samples(index, 1) = pixelIt->_channel[0];
    if (samples(index, 1) < 0.96) index++; 
    //printf("sample(%g, %g) = %g\n", samples(index, 0), samples(index, 1), samples(index, 2));
    //index++;
    prevx = iCrossLine[i]._x;
    prevy = iCrossLine[i]._y;
  }
  float r = (float)(iCandidate.GetDiameter() * 0.5);
  return BaseStarDetector::EvaluateProfile(
    pixelItBegin, samples, index, xc, yc, r, oG0, oH, oB, oI0, oError);

} // EvaluateProfile
  
} // namespace Astro
} // namespace eLynx
