//============================================================================
//  FrameList.cpp                                      Astro.Component package
//============================================================================
//  Usage : list of frames (astro images of the same type)
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/astro/FrameList.h>

#include <math.h>
using namespace std;
using namespace boost;

namespace eLynx {
namespace Astro {
  
//----------------------------------------------------------------------------
// constructor, creates empty list

FrameList::FrameList(EAstroImageType type) : _Type(type)
{
}

//----------------------------------------------------------------------------
// returns the number of valid frames

uint FrameList::GetValidCount() const
{
  uint result = 0;
  for (uint i = 0; i < GetCount(); i++) if (!IsRejected(i)) result++;
  return result;
} 

//----------------------------------------------------------------------------
// returns specified frame filename

const string& FrameList::GetFrameName(uint iIndex) const
{
  if (iIndex >= GetCount()) 
    elxThrow(elxErrOutOfRange, elxMsgFormat(
      "Frame index %i out of range <0, %i>.", iIndex, GetCount()-1));
      
  return _Frames[iIndex].GetFilename(); 
}

//----------------------------------------------------------------------------
// returns specified frame

const AstroImage& FrameList::GetFrame(uint iIndex) const
{
  if (iIndex >= GetCount()) 
    elxThrow(elxErrOutOfRange, elxMsgFormat(
      "Frame index %i out of range <0, %i>.", iIndex, GetCount()-1));
      
  return _Frames[iIndex];
}

//----------------------------------------------------------------------------
// returns specified frame

AstroImage& FrameList::GetFrame(uint iIndex)
{
  if (iIndex >= GetCount()) 
    elxThrow(elxErrOutOfRange, elxMsgFormat(
      "Frame index %i out of range <0, %i>.", iIndex, GetCount()-1));
      
  return _Frames[iIndex];
}


//----------------------------------------------------------------------------
// checks, if specified frame is rejected

bool FrameList::IsRejected(uint iIndex) const
{
  if (iIndex >= GetCount()) 
    elxThrow(elxErrOutOfRange, elxMsgFormat(
      "Frame index %i out of range <0, %i>.", iIndex, GetCount()-1));
      
  return _Frames[iIndex].IsRejected();
}


//----------------------------------------------------------------------------
// adds new frame to the list

void FrameList::AddFrame(const string &iName)
{
  _Frames.push_back(new AstroImage());
  _Frames.back().SetType(_Type);
  _Frames.back().SetFilename(iName);
}


//----------------------------------------------------------------------------
// adds new frame to the list

AstroImage& FrameList::AddFrame(AstroImage *iFrame)
{
  _Frames.push_back(iFrame);
  _Frames.back().SetType(_Type);
  return _Frames.back();
}


//----------------------------------------------------------------------------
// sets specified frame rejected flag to true

void FrameList::RejectFrame(uint iIndex)
{
  if (iIndex >= GetCount()) 
    elxThrow(elxErrOutOfRange, elxMsgFormat(
      "Frame index %i out of range <0, %i>.", iIndex, GetCount()-1));
      
  _Frames[iIndex].Reject();
  UnloadFrame(iIndex);
}


//----------------------------------------------------------------------------
// deletes specified frame from the list

void FrameList::DeleteFrame(uint iIndex)
{
  if (iIndex >= GetCount()) 
    elxThrow(elxErrOutOfRange, elxMsgFormat(
      "Frame index %i out of range <0, %i>.", iIndex, GetCount()-1));
      
  _Frames.erase(_Frames.begin()+iIndex);
}


//----------------------------------------------------------------------------
// deletes all frames

void FrameList::Clear()
{
  _Frames.clear();
}


//----------------------------------------------------------------------------
// loads frame, if not already loaded

void FrameList::LoadFrame(uint iIndex, ProgressNotifier& iNotifier)
{
  if (iIndex >= GetCount()) 
    elxThrow(elxErrOutOfRange, elxMsgFormat(
      "Frame index %i out of range <0, %i>.", iIndex, GetCount()-1));
      
  if (_Frames[iIndex].IsValid()) return;
  _Frames[iIndex].LoadImage(iNotifier);
}


//----------------------------------------------------------------------------
// unloads the frame from memory

void FrameList::UnloadFrame(uint iIndex, int iSelection)
{
  if (iIndex >= GetCount()) 
    elxThrow(elxErrOutOfRange, elxMsgFormat(
      "Frame index %i out of range <0, %i>.", iIndex, GetCount()-1));
      
  _Frames[iIndex].Unload(iSelection);
}


//----------------------------------------------------------------------------
// loads all frames into memory

void FrameList::LoadAllFrames(ProgressNotifier& iNotifier)
{
  for (uint i = 0; i < GetCount(); i++)
    if (!IsRejected(i)) LoadFrame(i, iNotifier);
}


//----------------------------------------------------------------------------
// unloads all frames from memory

void FrameList::UnloadAllFrames(int iSelection)
{
  for (uint i=0; i<GetCount(); i++)
    UnloadFrame(i, iSelection);
}


//----------------------------------------------------------------------------
// creates the const ImageVariant list of frames

void FrameList::GetConstVariantList(vector<const ImageVariant*> &oList, 
    bool iExcludeRejected)
{
  oList.clear();
  
  for (uint i = 0; i < GetCount(); i++) {
    
    if (iExcludeRejected && IsRejected(i)) continue;
    
    oList.push_back(&(_Frames[i]));
    
  }
    
}


//----------------------------------------------------------------------------
// subtracts specified master frame from all frames in the list

void FrameList::SubtractMasterFromFrames(AstroImage& iMaster, 
    bool iExcludeRejected)
{
  for (uint i = 0; i < GetCount(); i++) {
    
    if (iExcludeRejected && IsRejected(i)) continue;
    
    LoadFrame(i);
    
    GetFrame(i).SubClamp(iMaster);
    
  }
}    
    
//----------------------------------------------------------------------------

} // namespace Astro
} // namespace eLynx
