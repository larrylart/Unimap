//============================================================================
//  MasterBiasMaker.cpp                                Astro.Component package
//============================================================================
//  Usage : creates master bias frame
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/astro/MasterBiasMaker.h>

#include <iostream>
using namespace std;
using namespace boost;

namespace eLynx {
namespace Astro {
  
//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EMasterBiasMethod iMethod)
{
  static const char * ms_lut[2] = { "Mean", "Median" };
  return ms_lut[iMethod];

} // elxToString
  
//----------------------------------------------------------------------------

MasterBiasMaker::MasterBiasMaker(FrameHolder &ioHolder) 
  : CommonMasterMaker(ioHolder)
{
}


//----------------------------------------------------------------------------
// creates master bias frame int he frame holder

void MasterBiasMaker::MakeMasterBias(EMasterBiasMethod iMethod, 
  uint iAllowedMemoryKB, ProgressNotifier &iNotifier)
{
  cout << "MakeMasterBias" << endl;
  
  // get the list of bias frames
  FrameList &frames = GetFrameList();
  
  // get the reference frame (as first valid frame)
  int ref = GetFirstValidFrame(frames);
  if (ref == -1)
    elxThrow(elxErrInvalidContext, "No valid bias frames.");
    
  cout << "  first valid frame = " << ref << endl;
   
  // check the list to get number of valid frames
  uint valids;
  string reason;
  CheckList(ref, false, true, valids, reason, iNotifier);
  
  cout << "  list checked, " << valids << " valid frames" << endl;
  cout << "  reason = " << reason << endl;
  
  // init the progress notifier
  iNotifier.SetProgress(0.0f);
  
  // if there is just one valid frame, we will use it as master bias
  if (valids == 1) {
    
    cout << "  just one bias frame, using as master" << endl;
    
    // load reference frame into memory
    frames.LoadFrame(ref);
    
    // copy the valid frame to master bias
    GetMasterFrame() = frames.GetFrame(ref);
    
    // set the master bias filename
    GetMasterFrame().SetFilename(
      _FrameHolder.GetDefaultMasterBiasName(frames.GetFrame(ref))
      );
     
    // update the progress notifier
    iNotifier.SetProgress(1.0f);
    
  }
  
  // if there are more bias frames
  else {
    
    // init the operator
    EImageListOperator op = ILO_Median;
    switch (iMethod)
    {
      case MOM_Mean:   op = ILO_Mean; break;
      case MOM_Median: op = ILO_Median; break;
      default: break;
    }
    
    cout << "  distributing frames into temporary stacks" << endl;
  
    // create list of temporary stacks
    CreateStackList(iAllowedMemoryKB, iNotifier);
    
    // if the stacks are not needed, just load all the images
    // and do the masterization
    if (_StackList.size() == 0) {
      
      cout << "  stacks not used, loading all frames" << endl;
      
      frames.LoadAllFrames();
    
      cout << "  getting variant list" << endl;
    
      // get the list of valid frames as const ImageVariant pointers
      vector<const ImageVariant*> valid_frames;
      frames.GetConstVariantList(valid_frames, true); 
      
      cout << "  building master bias" << endl;
      
      // try to build the master bias frame 
      bool success = GetMasterFrame().ImageVariant::Build(
        op, valid_frames, CM_All, iNotifier);
        
      // if not successfull, throw an exception
      if (!success) 
        elxThrow(elxErrOperationFailed, elxMsgFormat("Failed to build master bias"
          " from the list of %i valid bias frames.", valids));
          
      // unload bias frames, they're no longer needed
      GetFrameList().UnloadAllFrames();
    }  
      
    else {
      
      // load reference frame into memory
      frames.LoadFrame(ref);
      
      // prepare the master frame for filling in tiles
      cout << "  preparing master frame image" << endl;
      GetMasterFrame() = AstroImage(
        frames.GetFrame(ref).GetPixelFormat(),
        frames.GetFrame(ref).GetWidth(),
        frames.GetFrame(ref).GetHeight()
        );
    
      // prepare images to hold the tiles
      ImageVariant result;
      ptr_vector<ImageVariant> stack_images;
      vector<const ImageVariant*> references;
      
      // init stack size and row number
      size_t scount = _StackList.size();
      uint y = 0;
      
      cout << "  going through " << scount << " stacks to build master bias" << endl;
      
      // go through the whole stack list
      for (size_t i = 0; i < scount; i++) {
        
        cout << "    stack " << i << endl;
        
        // check, if there is need to prepare tile lists
        bool need_to_prepare = false;
        
        // prepare them for the first time
        if (i == 0) need_to_prepare = true;
        
        // update them also for the last tile, if the size is different
        if (i == scount-1 && 
          _StackList[0].GetTileHeight() != _StackList[scount-1].GetTileHeight())
          need_to_prepare = true;
         
        // prepare the tile lists if needed
        if (need_to_prepare) {
          cout << "    preparing tile lists" << endl;
          PrepareStackImageList(_StackList[i], frames.GetFrame(ref), 
            stack_images, references, result);
        } 
        
        cout << "    loading tiles from stack" << endl;
        // load all the tiles from actual stack
        LoadImageStack(_StackList[i], stack_images);
        
        cout << "    combining tiles" << endl;
        // try to build the tile of master bias
        bool success = result.Build(op, references, CM_All, iNotifier);
        
        // if not successfull, throw an exception
        if (!success) 
          elxThrow(elxErrOperationFailed, elxMsgFormat("Failed to build master bias"));
          
        // copy the tile content into the appropriate position of the master
        // flat and update the row index
        cout << "    copying tile into the master frame" << endl;
        _StackList[i].CopyTile(GetMasterFrame(), result, y);
        y += _StackList[i].GetTileHeight();
          
      }
      
      // clear the temporary images
      references.clear();
      stack_images.clear();
      DeleteStackList();
    }
    
  }
  
  cout << "  saving master bias" << endl;
  
  // set the master bias filenam
  GetMasterFrame().SetFilename(
    _FrameHolder.GetDefaultMasterBiasName(frames.GetFrame(ref))
    );
  
  // update master bias image file info
  ImageFileInfo info = frames.GetFrame(ref).GetInfo();
  info.SetResolution(GetMasterFrame().GetResolution());
  GetMasterFrame().GetInfo() = info;
  
  // save the master bias
  _FrameHolder.MakePathForFile(GetMasterFrame().GetFilename());
  GetMasterFrame().ImageVariant::Save(
    GetMasterFrame().GetFilename().c_str(), iNotifier);
    
  

}

//----------------------------------------------------------------------------
// saves master bias preview and thumbnail

void MasterBiasMaker::SavePreview()
{
  CommonMasterMaker::SavePreview(
    _FrameHolder.GetMasterFramePreviewName(_FrameHolder.GetMasterBias()),
    0, 0,
    _FrameHolder.GetMasterFrameThumbnailName(_FrameHolder.GetMasterBias()),
    _FrameHolder.GetThumbnailWidth(), _FrameHolder.GetThumbnailHeight());
}

//----------------------------------------------------------------------------

} // namespace Astro
} // namespace eLynx
