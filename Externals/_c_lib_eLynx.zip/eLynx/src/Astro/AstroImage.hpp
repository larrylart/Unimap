//============================================================================
//  AstroImage.hpp                                     Astro.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __AstroImage_hpp__
#define __AstroImage_hpp__

namespace eLynx {
namespace Astro {

using namespace eLynx::Image;

//----------------------------------------------------------------------------
//  DetectStars: detects the stars on the image
//----------------------------------------------------------------------------
template <class StarDetector>
void AstroImage::DetectStars(StarDetector &iDetector)
{
  // check, if image is valid
  if (!IsValid())
    elxThrow(elxErrInvalidContext, "Can't detect stars on invalid image.");

  ImageVariant *to_detect = this;
  boost::scoped_ptr<ImageVariant> debayerized;

  if (IsBayer()) 
  {
    debayerized.reset(new ImageVariant(*this));
    debayerized->Normalize();
    debayerized->Balance(1.4, 1.0, 1.24);

    // convert Bayer to color
    debayerized->ChangeToColor(BCC_Bilinear);
    to_detect = debayerized.get();
  }
  
  // invalidate the score
  _bScoreValid = false;
  
  // discard current stars
  _Stars.clear();
  
  // detect stars
  iDetector.DetectStars(*to_detect, _Stars);
  
  // sort stars according to their diameter
  // !!! do not remove or change, many things depends on it !!!
  std::sort(_Stars.begin(), _Stars.end(), CompareStars);

} // DetectStars


} // namespace Astro
} // namespace eLynx

#endif // __AstroImage_hpp__
