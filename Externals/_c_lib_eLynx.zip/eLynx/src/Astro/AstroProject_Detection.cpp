//============================================================================
//  AstroProject_Detection.cpp                         Astro.Component package
//============================================================================
//  Usage : astronomical image processing project class implementation.
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------

// static private members
uint AstroProject::_snFileToScan=0;
uint AstroProject::_snScannedFile=0;
ProgressNotifier * AstroProject::_sprNotifier=NULL;

//----------------------------------------------------------------------------
//  AutoDetect
//----------------------------------------------------------------------------
bool AstroProject::AutoDetect(const char * iprName, ProgressNotifier& iNotifier)
{
  if (NULL != iprName)
    SetDataPath(iprName);

  if (_DataPath[0] == '\0') 
    return false;

  _sprNotifier = &iNotifier;

  // add filter
  char Filter[elxPATH_MAX];
  
  ::sprintf(Filter, "%s*.*", _DataPath);

  // Count files in directory
  _snFileToScan = 0;
  elxEnumerateFile(Filter, FileCountCallback, (void*)this);
  if (0 == _snFileToScan)
    return false;

  // Enumerate files in directory
  _snScannedFile = 0;
  elxEnumerateFile(Filter, FileEnumCallback, (void*)this);

  _sprNotifier->SetProgress(0.0);
  _sprNotifier = NULL;
  
  cout << "all files detected" << endl;
  
  return true;

} // AutoDetect


//----------------------------------------------------------------------------
//  FileCountCallback
//----------------------------------------------------------------------------
//  static protected
//----------------------------------------------------------------------------
bool AstroProject::FileCountCallback(const char * iprFilename, void * iprUserData)
{
  // check paramaters
  if ((NULL == iprUserData) || (NULL == iprFilename))
    return false;

  AstroProject& me = *((AstroProject*)iprUserData);
  me._snFileToScan++;
  return true;

} // FileCountCallback


//----------------------------------------------------------------------------
//  FileEnumCallback
//----------------------------------------------------------------------------
//  static protected
//----------------------------------------------------------------------------
bool AstroProject::FileEnumCallback(const char * iprFilename, void * iprUserData)
{
  // check paramaters
  if ((NULL == iprUserData) || (NULL == iprFilename))
    return false;

  AstroProject& me = *((AstroProject*)iprUserData);
  
  // check if it's a supported image format
  if (the_ImageFileManager.CanImport(iprFilename))
  {
    char info[2*elxPATH_MAX];
    const char * prName = elxGetFileNameExt(iprFilename);

    AstroImage * psImage = new AstroImage();

    bool bValid = psImage->Load(iprFilename, LO_Overview);
    if (bValid)
    {
      me._FrameHolder.AddFrameByType(psImage);
      if (AIS_Unknown != psImage->GetSubtype())
        ::sprintf(info, "%s is detected as %s-%s.", 
            prName, elxToString( psImage->GetType() ), elxToString( psImage->GetSubtype() ));
      else
        ::sprintf(info, "%s is detected as %s.", prName, elxToString( psImage->GetType() ));

      if (_sprNotifier) _sprNotifier->Log(info);
    }
    else
    {
      ::sprintf(info, "%s is not an astronomical raw image.", prName);
      if (_sprNotifier) _sprNotifier->Log(info);

      // image is not added, release it now
      elxSAFE_RELEASE(psImage);
    }
  }

  // Notify progress
  me._snScannedFile++;
  if (_sprNotifier)
    _sprNotifier->SetProgress(float(me._snScannedFile)/float(me._snFileToScan));

  return true;

} // FileEnumCallback





