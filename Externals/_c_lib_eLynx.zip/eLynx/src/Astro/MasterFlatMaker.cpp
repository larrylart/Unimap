//============================================================================
//  MasterFlatMaker.cpp                                Astro.Component package
//============================================================================
//  Usage : creates master flat frame
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/astro/MasterFlatMaker.h>

#include <iostream>
using namespace std;

namespace eLynx {
namespace Astro {
  
//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EMasterFlatMethod iMethod)
{
  static const char * ms_lut[2] = 
  { 
    "Mean", "Median"
  };
  return ms_lut[iMethod];

} // elxToString
  

//----------------------------------------------------------------------------

MasterFlatMaker::MasterFlatMaker(FrameHolder &ioHolder) 
  : CommonMasterMaker(ioHolder)
{
}

//----------------------------------------------------------------------------
// creates master flat frame in the frame holder

void MasterFlatMaker::MakeMasterFlat(EMasterFlatMethod iMethod, 
  ProgressNotifier &iNotifier)
{
  cout << "MakeMasterFlat" << endl;
  
  // get the list of flat frames
  FrameList &frames = GetFrameList();
  
  // get the reference frame (as first valid frame)
  int ref = GetFirstValidFrame(frames);
  if (ref == -1)
    elxThrow(elxErrInvalidContext, "No valid flat frames."); 

  cout << "  first valid frame = " << ref << endl;
   
  // check the list to get number of valid frames
  uint valids;
  string reason;
  CheckList(ref, true, true, valids, reason, iNotifier);

  cout << "  list checked, " << valids << " valid frames" << endl;
  cout << "  reason = " << reason << endl;
  
  // init the progress notifier
  iNotifier.SetProgress(0.0f);
  
  // if master bias is available, subtract it from all valid flat frames
  if (_FrameHolder.IsMasterBiasAvailable()) {

    cout << "  preparing master bias" << endl;
    
    // prepare the image
    _FrameHolder.PrepareMasterBias(frames.GetFrame(ref).GetInfo());

    cout << "  subtracting master bias" << endl;
    
    // subtract it from flat frames
    frames.SubtractMasterFromFrames(_FrameHolder.GetMasterBias());
  }
  
  // if there is just one valid frame, we will use it as master Flat
  if (valids == 1) {

    cout << "  just one flat frame, using as master" << endl;
    
    // load it into memory
    frames.LoadFrame(ref);
    
    // copy the valid frame to master Flat
    GetMasterFrame() = frames.GetFrame(ref);
    
    // set the master Flat filename
    GetMasterFrame().SetFilename(
      _FrameHolder.GetDefaultMasterFlatName(frames.GetFrame(ref))
      );
     
    // update the progress notifier
    iNotifier.SetProgress(1.0f);
    
  }
  
  // if there are more Flat frames
  else {

    cout << "  loading all frames" << endl;

    frames.LoadAllFrames(iNotifier);
  
    cout << "  normalizing frames" << endl;
   
    // normalizes range of all frames to the reference one
    NormalizeFrames(frames, valids, ref);

    cout << "  getting variant list" << endl;
    
    // get the list of valid frames as const ImageVariant pointers
    vector<const ImageVariant*> valid_frames;
    frames.GetConstVariantList(valid_frames, true);
    
    // init the operator
    EImageListOperator op = ILO_Median;
    switch (iMethod)
    {
      case MFM_Mean :   op = ILO_Mean; break;
      case MFM_Median : op = ILO_Median; break;
      default: break;
    } 

    cout << "  building master flat" << endl;
    
    // try to build the master Flat frame 
    bool success = GetMasterFrame().ImageVariant::Build(
      op, valid_frames, CM_All, iNotifier);
      
    // if not successfull, throw an exception
    if (!success) 
      elxThrow(elxErrOperationFailed, elxMsgFormat("Failed to build master flat"
        " from the list of %i valid flat frames.", valids));
        
  }
  
  // set the master flat filename
  GetMasterFrame().SetFilename(
    _FrameHolder.GetDefaultMasterFlatName(frames.GetFrame(ref))
    );
  
  // update master flat image file info
  ImageFileInfo info = frames.GetFrame(ref).GetInfo();
  info.SetResolution(GetMasterFrame().GetResolution());
  GetMasterFrame().GetInfo() = info;
  GetMasterFrame().SetBayerMatrix(frames.GetFrame(ref).GetBayerMatrix());

  cout << "  normalizing channels" << endl;

  // normalize all channels to each other
  NormalizeChannels(GetMasterFrame());

  // smooth the image by 2x2 binning
  SmoothImage(GetMasterFrame());
  
  cout << "  saving master flat" << endl;
  
  // save the master flat
  _FrameHolder.MakePathForFile(GetMasterFrame().GetFilename());
  GetMasterFrame().ImageVariant::Save(
    GetMasterFrame().GetFilename().c_str(), iNotifier);
    
  // unload flat frames, they're no longer needed
  GetFrameList().UnloadAllFrames();

}

//----------------------------------------------------------------------------
// normalizes all valid frames to the reference frame

void MasterFlatMaker::NormalizeFrames(FrameList &ioFrames, uint iValidFrames, 
  uint iRefFrame)
{
  // allocate arrays for frames statistics
  boost::scoped_array<double> means(new double[iValidFrames*3]);
  boost::scoped_array<double> stddevs(new double[iValidFrames*3]);
  
  // go through all frames
  uint index = 0;
  uint ref_index = 0;
  for (uint i = 0; i < ioFrames.GetCount(); i++) {
        
    if (ioFrames.IsRejected(i)) continue;
    

    // compute image mean and standard deviations
    bool success = ioFrames.GetFrame(i).ComputeStandardDeviation(
      means[index*3], means[index*3+1], means[index*3+2], 
      stddevs[index*3], stddevs[index*3+1], stddevs[index*3+2]);

    if (!success) 
      elxThrow(elxErrOperationFailed, elxMsgFormat("Failed to compute stddev"
        " for the frame %i.", i));

    if (i == iRefFrame) ref_index = index;
    
    index++;
  }

  index = 0;
  
  // go through all frames except the reference one
  for (uint i = 0; i < ioFrames.GetCount(); i++) {

    if (ioFrames.IsRejected(i)) continue;
    
    // skip reference frame
    if (i != iRefFrame) 
    
      // normalize the frame
      NormalizeFrame(ioFrames.GetFrame(i), means.get(), stddevs.get(),
        index, ref_index);

    index++;
  }
}


//----------------------------------------------------------------------------
// normalizes the frame to the reference range

void MasterFlatMaker::NormalizeFrame(AstroImage &ioFrame, 
  double iMeans[], double iStdDevs[], uint iFrameIndex, uint iRefIndex)
{
  double a[3], b[3];
  
  // compute transformation coefficients
  for (uint i = 0; i < 3; i++) {
    a[i] = iStdDevs[iRefIndex*3+i] / iStdDevs[iFrameIndex*3+i];
    b[i] = (iStdDevs[iRefIndex*3+i] * iMeans[iFrameIndex*3+i] -
      iStdDevs[iFrameIndex*3+i]*iMeans[iRefIndex*3+i])/iStdDevs[iFrameIndex*3+i];
  }

  // for each pixel, apply p = p*a + b
  bool success = ioFrame.Affine(a[0], b[0], a[1], b[1], a[2], b[2]);
  if (!success)
    elxThrow(elxErrOperationFailed, elxMsgFormat("Failed to normalize frame %i to %i.", 
      iFrameIndex, iRefIndex));
}

//----------------------------------------------------------------------------

void MasterFlatMaker::NormalizeChannels(AstroImage &ioMaster)
{
  double mean[3], stddev[3];

  bool success = ioMaster.ComputeStandardDeviation(mean[0], mean[1], mean[2], 
    stddev[0], stddev[1], stddev[2]);

  if (!success)
    elxThrow(elxErrOperationFailed, "Failed to compute stddev from the master flat.");

  uint max_range = 0;
  if (stddev[1] > stddev[0]) {
    max_range = (stddev[2] > stddev[1] ? 2 : 1);
  }
  else {
    max_range = (stddev[2] > stddev[0] ? 2 : 0);
  }

  double a[3], b[3];

  for (uint i = 0; i < 3; i++) {
    if (i == max_range) {
      a[i] = 1.0; b[i] = 0.0;
    }
    else {
      a[i] = stddev[max_range]/stddev[i];
      b[i] = (stddev[max_range]*mean[i]-stddev[i]*mean[max_range])/stddev[i];
    }
  }

  success = ioMaster.Affine(a[0], b[0], a[1], b[1], a[2], b[2]);
  if (!success)
    elxThrow(elxErrOperationFailed, "Failed to normalize master flat channels.");
}

//----------------------------------------------------------------------------

void MasterFlatMaker::SmoothImage(AstroImage &ioMaster)
{
  EBayerMatrix backup = ioMaster.GetBayerMatrix();
  ioMaster.SetBayerMatrix(BM_None);
  bool success = ioMaster.Bin2x2();
  if (!success)
    elxThrow(elxErrOperationFailed, "Failed to bin master flat.");

  success = ioMaster.Resize(ioMaster.GetWidth()*2, ioMaster.GetHeight()*2);
  if (!success)
    elxThrow(elxErrOperationFailed, "Failed to resize master flat.");
  ioMaster.SetBayerMatrix(backup);
}

//----------------------------------------------------------------------------
// saves master flat preview and thumbnail

void MasterFlatMaker::SavePreview()
{
  CommonMasterMaker::SavePreview(
    _FrameHolder.GetMasterFramePreviewName(_FrameHolder.GetMasterFlat()),
    0, 0,
    _FrameHolder.GetMasterFrameThumbnailName(_FrameHolder.GetMasterFlat()),
    _FrameHolder.GetThumbnailWidth(), _FrameHolder.GetThumbnailHeight());
}

//----------------------------------------------------------------------------

void MasterFlatMaker::PreprocessFrame(AstroImage& ioFrame)
{
  if (_FrameHolder.IsMasterBiasAvailable())
    ioFrame.SubClamp(_FrameHolder.GetMasterBias());
}

//----------------------------------------------------------------------------

} // namespace Astro
} // namespace eLynx
