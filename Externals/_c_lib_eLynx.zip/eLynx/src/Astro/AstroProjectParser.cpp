//============================================================================
//  AstroProjectparser.cpp                             Astro.Component package
//============================================================================
//  Usage : parse project config file
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/astro/AstroProjectParser.h>
#include <elx/astro/AstroProject.h>

namespace eLynx {
namespace Astro {
 
//----------------------------------------------------------------------------
// constructor
//----------------------------------------------------------------------------
ProjectTagNames::ProjectTagNames() :
  TAG_PROJECT(    xercesc::XMLString::transcode( "project"    ) ) ,            
  TAG_CAMERA(     xercesc::XMLString::transcode( "camera"     ) ) ,            
  TAG_MAKER(      xercesc::XMLString::transcode( "maker"      ) ) ,            
  TAG_MODEL(      xercesc::XMLString::transcode( "model"      ) ) ,            
  TAG_WIDTH(      xercesc::XMLString::transcode( "width"      ) ) ,            
  TAG_HEIGHT(     xercesc::XMLString::transcode( "height"     ) ) ,            
  TAG_RESOLUTION( xercesc::XMLString::transcode( "resolution" ) ) ,            
  TAG_BAYER(      xercesc::XMLString::transcode( "bayer"      ) ) ,            
  TAG_BIAS_LIST(  xercesc::XMLString::transcode( "bias_list"  ) ) ,            
  TAG_DARK_LIST(  xercesc::XMLString::transcode( "dark_list"  ) ) ,            
  TAG_FLAT_LIST(  xercesc::XMLString::transcode( "flat_list"  ) ) ,            
  TAG_LIGHT_LIST( xercesc::XMLString::transcode( "light_list" ) ) ,            
  TAG_FRAME(      xercesc::XMLString::transcode( "frame"      ) ) ,            
  TAG_NAME(       xercesc::XMLString::transcode( "name"       ) ) ,            
  TAG_ISO(        xercesc::XMLString::transcode( "iso"        ) ) ,            
  TAG_SHUTTER(    xercesc::XMLString::transcode( "shutter"    ) ) ,            
  TAG_TIME(       xercesc::XMLString::transcode( "time"       ) ) ,
  TAG_TYPE(       xercesc::XMLString::transcode( "type"       ) ) ,            
  TAG_PATH(       xercesc::XMLString::transcode( "path"       ) ) ,            
  TAG_IMAGE(      xercesc::XMLString::transcode( "image"      ) )            
{} // ProjectTagNames::ProjectTagNames() 

//----------------------------------------------------------------------------
// destructor
//----------------------------------------------------------------------------
ProjectTagNames::~ProjectTagNames()
{
  try
  {
    xercesc::XMLString::release( &TAG_PROJECT   );             
    xercesc::XMLString::release( &TAG_CAMERA    );            
    xercesc::XMLString::release( &TAG_MAKER     );            
    xercesc::XMLString::release( &TAG_MODEL     );            
    xercesc::XMLString::release( &TAG_WIDTH     );            
    xercesc::XMLString::release( &TAG_HEIGHT    );            
    xercesc::XMLString::release( &TAG_RESOLUTION);            
    xercesc::XMLString::release( &TAG_BAYER     );            
    xercesc::XMLString::release( &TAG_BIAS_LIST );            
    xercesc::XMLString::release( &TAG_DARK_LIST );            
    xercesc::XMLString::release( &TAG_FLAT_LIST );            
    xercesc::XMLString::release( &TAG_LIGHT_LIST);            
    xercesc::XMLString::release( &TAG_FRAME     );            
    xercesc::XMLString::release( &TAG_NAME      );            
    xercesc::XMLString::release( &TAG_ISO       );            
    xercesc::XMLString::release( &TAG_SHUTTER   );            
    xercesc::XMLString::release( &TAG_TIME      );
    xercesc::XMLString::release( &TAG_TYPE      );
    xercesc::XMLString::release( &TAG_PATH      );
    xercesc::XMLString::release( &TAG_IMAGE     );
  }
  catch( ... )
  {}
} // ProjectTagNames::~ProjectTagNames() 

//----------------------------------------------------------------------------
// constructor
//----------------------------------------------------------------------------
AstroProjectParser::AstroProjectParser() :
  _Tags()
{} // AstroProjectParser::AstroProjectParser


//----------------------------------------------------------------------------
// Loads project info from a file. May throw in case of errors
//----------------------------------------------------------------------------
void AstroProjectParser::LoadProjectInfo(const char* iprInfoFile) const
{
  elxThrow(elxErrMethodNotImplemented, 
    elxMsgFormat("AstroProjectParser::LoadProjectInfo not implemented")); 

} // AstroProjectParser::LoadProjectInfo

//----------------------------------------------------------------------------
// Saves project info into a file. May throw in case of errors
//----------------------------------------------------------------------------
void AstroProjectParser::SaveProjectInfo(
  const char* iprInfoFile, const AstroProject& iAstroProject) const
{
  xercesc::DOMLSSerializer* prSerializer = NULL;
  xercesc::DOMDocument* prDoc = NULL;
  xercesc::DOMLSOutput* prOutput = NULL;
  
  try
  {
    // The DOM implementation retains ownership of the returned object. 
    // Application code should NOT delete it. 
    xercesc::DOMImplementation* prDomImpl = 
      xercesc::DOMImplementation::getImplementation();
    prDoc = prDomImpl->createDocument(
               NULL,                    // root element namespace URI.
               _Tags.TAG_PROJECT,       // root element name
               NULL);                   // document type object (DTD).
    xercesc::DOMElement* prRootElem = prDoc->getDocumentElement();
    
    Parser::AppendCommentNode(prDoc, 
      " eLynx Astronomical Image Processing project ", prRootElem);

    // type 
    Parser::AppendTextNode(
      prDoc,_Tags.TAG_TYPE, elxToString(iAstroProject.GetType()),prRootElem);  
    // path
    Parser::AppendTextNode(
      prDoc,_Tags.TAG_PATH, iAstroProject.GetDataPath(), prRootElem);  
      
    const ImageFileInfo &info = iAstroProject.GetImageFileInfo();

    // camera
    xercesc::DOMElement* prCamera = 
      Parser::AppendNode(prDoc,_Tags.TAG_CAMERA, prRootElem);  
    // maker
    Parser::AppendTextNode(prDoc,_Tags.TAG_MAKER, info.GetMaker(), prCamera);
    // model
    Parser::AppendTextNode(prDoc,_Tags.TAG_MODEL, info.GetModel(), prCamera);   
  
    // image
    xercesc::DOMElement* prImage = 
      Parser::AppendNode(prDoc,_Tags.TAG_IMAGE, prRootElem);  
  
    // width & height
    uint w,h;
    if (info.GetDimension(w,h)) 
    {
      Parser::AppendUIntNode(prDoc,_Tags.TAG_WIDTH, w, prImage);
      Parser::AppendUIntNode(prDoc,_Tags.TAG_HEIGHT, h, prImage);
    }
     
    // resolution
    EResolution resolution;
    if (info.GetResolution(resolution))
      Parser::AppendTextNode(
        prDoc,_Tags.TAG_RESOLUTION, elxToString(resolution), prImage);
    
    // bayer
    EBayerMatrix bayer;
    if (info.GetBayer(bayer))
      Parser::AppendTextNode(
        prDoc,_Tags.TAG_BAYER, elxToString(bayer), prImage);

    CreateXMLImageList(
      prDoc, prRootElem, iAstroProject.GetBiasList(), _Tags.TAG_BIAS_LIST);
    CreateXMLImageList(
      prDoc, prRootElem, iAstroProject.GetDarkList(), _Tags.TAG_DARK_LIST);
    CreateXMLImageList(
      prDoc, prRootElem, iAstroProject.GetFlatList(), _Tags.TAG_FLAT_LIST);
    CreateXMLImageList(
      prDoc, prRootElem, iAstroProject.GetLightList(), _Tags.TAG_LIGHT_LIST);

    // Write the XML to the file
    prSerializer = ((xercesc::DOMImplementationLS*)prDomImpl)->createLSSerializer();
    xercesc::LocalFileFormatTarget  *prFormTarget = 
      new xercesc::LocalFileFormatTarget(iprInfoFile);
    prOutput = ((xercesc::DOMImplementationLS*)prDomImpl)->createLSOutput();
    prOutput->setByteStream(prFormTarget);
    prSerializer->write(prDoc, prOutput);

    
    // release resources
    prOutput->release();
    prSerializer->release();
    prDoc->release();
  }
  catch(...)
  {
    if (NULL != prOutput) prOutput->release(); 
    if (NULL != prSerializer) prSerializer->release(); 
    if (NULL != prDoc) prDoc->release();
    elxThrow(elxErrOperationFailed, 
      elxMsgFormat("Failed to save project info in %s.", iprInfoFile));
  }

} // AstroProjectParser::SaveProjectInfo

//----------------------------------------------------------------------------
// Build Image list to save
//----------------------------------------------------------------------------
void AstroProjectParser::CreateXMLImageList(
  xercesc::DOMDocument* iprDoc, xercesc::DOMElement* ioprRootElem, 
  const FrameList& iFrameList, const XMLCh* iTagName) const
{
  // list
  xercesc::DOMElement* prListElem = 
    Parser::AppendNode(iprDoc, iTagName, ioprRootElem);  
  
  const uint32 frameSize = iFrameList.GetCount();  
  for (uint32 i = 0; i < frameSize; i++) 
  {
    // frame
    xercesc::DOMElement* prFrameElem = 
      Parser::AppendNode(iprDoc, _Tags.TAG_FRAME, prListElem);  
    
    Parser::AppendTextNode(iprDoc, _Tags.TAG_NAME, 
      iFrameList.GetFrame(i).GetFileNameExt().c_str(), prFrameElem);
    
    const ImageFileInfo &info = iFrameList.GetFrame(i).GetInfo();
     
    uint32 ISO;
    if (info.GetISO(ISO))
      Parser::AppendUIntNode(iprDoc,_Tags.TAG_ISO, ISO, prFrameElem);
    
    float shutter;
    if (info.GetShutter(shutter))
      Parser::AppendFloatNode(iprDoc,_Tags.TAG_SHUTTER, shutter, prFrameElem);
      
    time_t time_stamp;
    if (info.GetTimeStamp(time_stamp)) 
    {
      char *time_str = ctime(&time_stamp);
      time_str[strlen(time_str)-1] = '\0';
      Parser::AppendTextNode(iprDoc,_Tags.TAG_TIME, time_str, prFrameElem);
    }
  }

} // AstroProjectParser::CreateXMLImageList   

} // namespace Astro
} // namespace eLynx
