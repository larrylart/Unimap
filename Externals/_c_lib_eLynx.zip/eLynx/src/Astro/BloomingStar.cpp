//============================================================================
//  BloomingStar.cpp                                   Image.Component package
//============================================================================
//  Usage : star object implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/astro/BloomingStar.h>

namespace eLynx {
namespace Astro {

//----------------------------------------------------------------------------
// constructor, creates uninitialized star
//----------------------------------------------------------------------------
BloomingStar::BloomingStar() : 
  Star(), 
  _UpperLeft(), 
  _LowerRight(), 
  _ThresholdMap(),
  _LuminanceMap(),
  _I0(),
  _B0(),
  _H2(),
  _Error2()
{}

//----------------------------------------------------------------------------
// copy constructor
//----------------------------------------------------------------------------
BloomingStar::BloomingStar(const BloomingStar& iOther) : 
  Star(iOther),
  _UpperLeft(iOther._UpperLeft),
  _LowerRight(iOther._LowerRight), 
  _ThresholdMap(iOther._ThresholdMap),
  _LuminanceMap(iOther._LuminanceMap),
  _I0(iOther._I0),
  _B0(iOther._B0),
  _H2(iOther._H2),
  _Error2(iOther._Error2)
{}

//----------------------------------------------------------------------------
// returns upper left conner
//----------------------------------------------------------------------------
Math::Point2i BloomingStar::GetUpperLeft() const
{
  return _UpperLeft;
}

//----------------------------------------------------------------------------
// returns lower right conner
//----------------------------------------------------------------------------
Math::Point2i BloomingStar::GetLowerRight() const
{
  return _LowerRight;
}

//----------------------------------------------------------------------------
// returns star's pixel map
//----------------------------------------------------------------------------
BaseStarDetector::PixelMap BloomingStar::GetThresholdMap() const
{
  return _ThresholdMap;
}	

//----------------------------------------------------------------------------
// returns star's Luminance map
//----------------------------------------------------------------------------
BaseStarDetector::LuminanceMap BloomingStar::GetLuminanceMap() const
{
  return _LuminanceMap;
}

//----------------------------------------------------------------------------
// Returns star's luminance at the center
//----------------------------------------------------------------------------
float BloomingStar::GetCentralLuminance() const
{
  return _I0;
}
  
//----------------------------------------------------------------------------
// Returns estimated background luminance
//----------------------------------------------------------------------------
float BloomingStar::GetBackgroundLuminance() const
{
  return _B0;
}
  
//----------------------------------------------------------------------------
// Returns Star's radius at half maximum
//----------------------------------------------------------------------------
float BloomingStar::GetHalfLuminanceRadius() const
{
  return _H2;
}
  
//----------------------------------------------------------------------------
// Returns approximation error square
//----------------------------------------------------------------------------
float BloomingStar::GetApproximationError() const
{
  return _Error2;
}

//----------------------------------------------------------------------------
// sets upper left conner
//----------------------------------------------------------------------------
void BloomingStar::SetUpperLeft(const Math::Point2i& iConner)
{
  _UpperLeft = iConner;
}

//----------------------------------------------------------------------------
// sets lower right conner
//----------------------------------------------------------------------------
void BloomingStar::SetLowerRight(const Math::Point2i& iConner)
{
  _LowerRight = iConner;
}

//----------------------------------------------------------------------------
// sets star's pixel map
//----------------------------------------------------------------------------
void BloomingStar::SetThresholdMap(BaseStarDetector::PixelMap iThresholdMap) 
{
  _ThresholdMap = iThresholdMap;
}	

//----------------------------------------------------------------------------
// sets star's luminance map
//----------------------------------------------------------------------------
void BloomingStar::SetLuminanceMap(BaseStarDetector::LuminanceMap iLuminanceMap)
{
  _LuminanceMap = iLuminanceMap;
}

//----------------------------------------------------------------------------
// Sets star's luminance at the center
//----------------------------------------------------------------------------
void BloomingStar::SetCentralLuminance(float iLuminance)
{
  _I0 = iLuminance;
}
  
//----------------------------------------------------------------------------
// Sets estimated background luminance
//----------------------------------------------------------------------------
void BloomingStar::SetBackgroundLuminance(float iLuminance)
{
  _B0 = iLuminance;
}
  
//----------------------------------------------------------------------------
// Sets Star's radius at half maximum
//----------------------------------------------------------------------------
void BloomingStar::SetHalfLuminanceRadius(float iRadius)
{
  _H2 =  iRadius;
} 
  
//----------------------------------------------------------------------------
// Returns approximation error square
//----------------------------------------------------------------------------
void BloomingStar::SetApproximationError(float iError2)
{
  _Error2 = iError2;
}

} // namespace Astro
} // namespace eLynx
