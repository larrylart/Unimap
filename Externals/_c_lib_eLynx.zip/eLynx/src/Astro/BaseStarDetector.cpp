//============================================================================
//  BaseStarDetector.cpp                               Astro.Component package
//============================================================================
//  Usage : abstract star detector
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------

#include <elx/astro/BaseStarDetector.h>

#include <elx/math/Vector.h>
#include <elx/math/BellCurve.h>
#include <elx/math/GaussNewton.h>

namespace eLynx {
namespace Astro {

//--------------------------------------------------------
// evaluates star gaussian profile

bool BaseStarDetector::EvaluateProfile(
  Image::PixelIterator<const Image::PixelLf> pixelIt, 
  const Math::Matrix& iSamples, uint iIndex, uint iXC, uint iYC, float iRadius,
  float &oG0, float &oH, float &oB, float &oI0, float &oError)
{
  if (iIndex < 3) return false; 
    
  Math::Matrix good_samples(iIndex, 2);
  for (uint i = 0; i < iIndex; i++) {
    good_samples(i, 0) = iSamples(i, 0);
    good_samples(i, 1) = iSamples(i, 1);
    //printf("sample(%g) = %g\n", good_samples(i, 0), good_samples(i, 1));
  }
  
  // prepare initial guess
  Math::Vector params(3);
  params(0) = 0.0f; // oI0 is not initialized yet.
  params(1) = iRadius;
  params(2) = 0.0f;
  
  Math::Vector result(3);
  //Math::BellSurface bs;
  Math::BellCurve bc;
  
  // fit gaussian profile to values
  Math::GaussNewton::FitParams(bc, good_samples, params, result, 1e-6, 30);
  
  // fill in the results
  oG0 = (float)result(0);
  oH = (float)result(1);
  oB = (float)result(2);
  pixelIt.advance(iXC, iYC);
  oI0 = pixelIt->_channel[0] - oB;
  
  // compute the error
  oError = 0.0f;
  //Math::Vector vars(2);
  Math::Vector vars(1);
  for (uint i = 0; i < iSamples.GetHeight(); i++) 
  {
    vars(0) = iSamples(i, 0);
    double delta = bc.Evaluate(vars, result) - iSamples(i, 1);
    oError += float(delta*delta);
  }
  oError /= iSamples.GetHeight();
  
  return true;
}
    

/*void BaseStarDetector::EvaluateProfile(const Image::ImageVariant &iImage, 
  float iXC, float iYC, float iD, float &oG0, float &oI0, float &oB, 
  float &oError)
{
  
  //printf("evaluating profile for star candidate at %g, %g with diameter %g\n", iXC, iYC, iD);
  // compute integer size of the image region to compute
  uint r = (uint)(iD/2.0f+0.5f);
  uint d = 2*r + 1;
  
  //printf("  r = %i, d = %i\n", r, d);
  
  // init equation system matrix and right size vector
  Math::Matrix A(d*d, 2);
  Math::Vector B(d*d);
  
  // init result vectors
  Math::Vector X(2);
  
  // get image implementation (always PixelLf)
  boost::shared_ptr<const AbstractImage> ai = iImage.GetImpl();
  const ImageImpl<PixelLf>& image = elxDowncast<PixelLf>(*ai);
  
  // compute center of the image region
  uint xc = (uint)iXC;
  uint yc = (uint)iYC;
  
  // init matrix row index
  uint index = 0;
  
  // prepare maximal intensity computation
  uint max_x = iImage.GetWidth();
  uint max_y = iImage.GetHeight();
  float max_value = 0.0f;
  
  // go through the region
  for (uint y = yc-r; y <= yc+r; y++)
    for (uint x = xc-r; x <= xc+r; x++) {
      
      // fill the matrix
      A(index, 0) = exp(-(Math::elxSqr((float)x-iXC)+Math::elxSqr((float)y-iYC))/(2.0f*Math::elxSqr(iD)));
      A(index, 1) = 1.0;
      
      // get pixel value
      float value = image.GetPixel(x, y)->_channel[0];
      
      // fill the right side vector 
      B(index) = value;
      
      // check for maximal intensity value
      if (value > max_value) {
        max_value = value;
        max_x = x; max_y = y;
      }
      
      index++; 
    }
    
  // if the maximum was not found, throw an error
  if (max_x == iImage.GetWidth() || max_y == iImage.GetHeight())
    elxThrow(elxErrInvalidContext, "Star profile maximum not found."); 
    
  // solve the systems using least squares
  Math::LeastSquares::Solve(A, B, X);
  
  // compute local background (average of all pixels except maximum)
  float b0 = 0.0f;
  for (uint y = yc-r; y <= yc+r; y++)
    for (uint x = xc-r; x <= xc+r; x++) {
      if (x == max_x && y == max_y) continue;
      b0 += image.GetPixel(x, y)->_channel[0];
    }
  b0 /= (float)(d*d-1);
  
  // compute results
  oG0 = X(0);
  oB = X(1);
  oI0 = image.GetPixel(max_x, max_y)->_channel[0] - b0;
 
  boost::scoped_array<float> differences(new float[d*d]);
  index = 0;
  float mean = 0.0f;
  
  for (uint y = yc-r; y <= yc+r; y++)
    for (uint x = xc-r; x <= xc+r; x++) {
      float g = oG0*exp(-(Math::elxSqr((float)x-iXC)+Math::elxSqr((float)y-iYC))/(2.0f*Math::elxSqr(iD)))+oB;
      differences[index] = g-image.GetPixel(x, y)->_channel[0];
      mean += differences[index];
      index++;
    }
    
 mean /= d*d;
 oError = 0;
 for (index = 0; index < d*d; index++) { 
   float diff = differences[index]-mean;
   oError += diff*diff;
 }

 oError /= Math::elxSqrt(oError/(d*d));
}*/

//--------------------------------------------------------

} // namespace Astro
} // namespace eLynx
