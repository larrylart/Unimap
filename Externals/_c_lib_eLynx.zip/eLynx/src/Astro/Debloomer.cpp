//============================================================================
//  Debloomer.cpp                                      Astro.Component package
//============================================================================
//  Usage : blooming star detector
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/core/CoreTypes.h>
#include <elx/math/Geometry.h>
#include <elx/astro/Debloomer.h>
#include <elx/astro/ThresholdStarDetector.h>
#include <elx/image/PixelIterator.h>
#include <elx/image/PixelMacros.h>

namespace eLynx {
namespace Astro {

namespace {

//----------------------------------------------------------------------------
//  elxRestoreStarInnerArea
//----------------------------------------------------------------------------
template <typename Pixel>
void elxRestoreStarInnerArea(const BloomingStar &iStar, 
  const Image::ImageVariant& iInnerMask, Image::ImageVariant& ioImage)
{
  typedef typename Pixel::F_type F;
  typedef typename Pixel::FloatingPixel FPixel;
  
  const uint w = ioImage.GetWidth();
  const uint h = ioImage.GetHeight();
  BOOST_ASSERT(w == iInnerMask.GetWidth() && h == iInnerMask.GetHeight());
  
  const Math::Point2i& upperLeft = iStar.GetUpperLeft();
  const F xc = F(iStar.GetX()) - F(upperLeft._x);
  const F yc = F(iStar.GetY()) - F(upperLeft._y);
  const uint ixc = uint(Math::elxRound(xc));
  const uint iyc = uint(Math::elxRound(yc));
  const F b0 = F(iStar.GetBackgroundLuminance());
  const F h2 = F(iStar.GetHalfLuminanceRadius());
  
  Image::PixelIterator<const Image::PixelLub> maskIter = 
    Image::elxConstDowncast<const Image::PixelLub>(iInnerMask.Begin());
  Image::PixelIterator<const Image::PixelLub> maskIterEnd = 
    Image::elxConstDowncast<const Image::PixelLub>(iInnerMask.End());
    
	Image::PixelIterator<Pixel> starIterBegin = 
    Image::elxDowncast<Pixel>(ioImage.Begin());
  Image::PixelIterator<Pixel> starIter = starIterBegin;
  starIter.advance(ixc, iyc);
  const Pixel cPixel = *starIter;
  const uint nChannel = Pixel::GetChannelCount();
  starIter = starIterBegin;
  FPixel fPixel;
   
  for(uint i = 0; maskIter != maskIterEnd; ++i, ++maskIter, ++starIter)
  {
    if (maskIter->GetLuminance())
    {
      const int x = i%w;
      const int y = i/w;
      F dist2 = Math::elxSqr(F(x) - xc) + Math::elxSqr(F(y) - yc);
    
      for (uint c=0; c<nChannel; c++)
        //  I = I0 * exp(-x^2 / 2*h^2) + b. See BellCurve.h
        fPixel._channel[c]= 
          F(cPixel._channel[c])*Math::elxExp(-dist2/(F(2.0f) * Math::elxSqr(h2))) + b0;

      Image::elxPixelClamp(fPixel, *starIter);
    }  
  }

} // elxRestoreStarInnerArea

} //namespace 	

//----------------------------------------------------------------------------
// constructor
//----------------------------------------------------------------------------
Debloomer::Debloomer(Image::ERestorationMethod iRestorationMethod) :
  _RestorationMethod(iRestorationMethod)
{}

//----------------------------------------------------------------------------
// Returns current restoration method. 
//----------------------------------------------------------------------------
Image::ERestorationMethod Debloomer::GetRestorationMethod() const
{
  return _RestorationMethod;
}
  
//----------------------------------------------------------------------------
// Sets new restoration method. 
//----------------------------------------------------------------------------
void Debloomer::SetRestorationMethod(Image::ERestorationMethod iRestorationMethod )
{
  _RestorationMethod = iRestorationMethod;
}

//----------------------------------------------------------------------------
// corrects blooming star
//----------------------------------------------------------------------------
void Debloomer::RemoveBloom(
  Image::ImageVariant &ioImage, const BloomingStar &iStar) const
{
  const Math::Point2i& upperLeft = iStar.GetUpperLeft();
  const Math::Point2i& lowerRight = iStar.GetLowerRight();
  const uint dx = lowerRight._x - upperLeft._x + 1;
  const uint dy = lowerRight._y - upperLeft._y + 1;
  
  // 1. Extract sub-image corresponding to the star's bounding rectangle
  Image::ImageVariant subImage;
  if (!subImage.GetSubImage(ioImage, upperLeft._x, upperLeft._y, dx, dy))
    elxThrow(elxErrOperationFailed, "Debloomer::RemoveBloom. Failed to extract sub-image");
  
  // 2. Create inpainting masks to remove bloom
  Image::ImageVariant innerMask(Image::PF_Lub, dx, dy);
  Image::ImageVariant outerMask(Image::PF_Lub, dx, dy);
  this->CreateInpaintBitmaps(iStar, innerMask, outerMask);

  // 3. Restore inner Area
  this->RestoreStarInnerArea(iStar, innerMask, subImage);
  
  // 4. Restore outer Area
  this->RestoreStarOuterArea(iStar, outerMask, subImage);

  // 5. Merge back sub-image
  if (!ioImage.Insert(subImage, upperLeft._x, upperLeft._y))
    elxThrow(elxErrOperationFailed, "Debloomer::RemoveBloom. Failed to insert sub-image");
  
} // RemoveBloom


//----------------------------------------------------------------------------
// creates star's bitmaps
//----------------------------------------------------------------------------
void Debloomer::CreateInpaintBitmaps(const BloomingStar &iStar, 
  Image::ImageVariant& oInnerMask, Image::ImageVariant& oOuterMask) const
{
  static const float LUMINANCE_THRESHOLD = 0.3f;
  static const float INPAINT_LIMIT = 1.3f;

  const Math::Point2i& upperLeft = iStar.GetUpperLeft();
  const Math::Point2i& lowerRight = iStar.GetLowerRight();
  const uint dx = lowerRight._x - upperLeft._x + 1;
  const uint dy = lowerRight._y - upperLeft._y + 1;
  const uint size = dx*dy;
  BOOST_ASSERT(dx == oOuterMask.GetWidth() &&
               dy == oOuterMask.GetHeight() &&
               dx == oInnerMask.GetWidth() &&
               dy == oInnerMask.GetHeight());
   
  const BaseStarDetector::PixelMap thresholdMap = iStar.GetThresholdMap();
  const BaseStarDetector::LuminanceMap luminanceMap = iStar.GetLuminanceMap();
  const float radius2 = Math::elxSqr(float(iStar.GetDiameter())/2.0f);
  const float xc = float(iStar.GetX());
  const float yc = float(iStar.GetY());
  const float i0 = iStar.GetCentralLuminance();
  const float b0 = iStar.GetBackgroundLuminance();
  const float h2 = iStar.GetHalfLuminanceRadius();
//  const float err2 = iStar.GetApproximationError();
  
  Image::PixelIterator<Image::PixelLub> pPixelIterInner = 
    Image::elxDowncast<Image::PixelLub>(oInnerMask.Begin());
  Image::PixelIterator<Image::PixelLub> pPixelIterOuter = 
    Image::elxDowncast<Image::PixelLub>(oOuterMask.Begin());
    
  for (uint i = 0; i < size; ++i, ++pPixelIterInner, ++pPixelIterOuter)
  {
    const int x = i%dx + upperLeft._x;
    const int y = i/dx + upperLeft._y;
    float dist2 = Math::elxSqr(float(x) - xc) + Math::elxSqr(float(y) - yc);
    
    //  I = I0 * exp(-x^2 / 2*h^2) + b. See BellCurve.h
    float calcLuminance = i0*Math::elxExp(-dist2/(2.0f * Math::elxSqr(h2))) + b0;
    float pixelLuminance = float(luminanceMap[i]);
    
    //need to take bloom direction into the considirations ?
    if (dist2 <= radius2)
    {
      // Inside region
      *pPixelIterInner = (Math::elxAbs(calcLuminance - pixelLuminance) > 
                          LUMINANCE_THRESHOLD*calcLuminance) ?
        ResolutionTypeTraits<uint8>::_Max : ResolutionTypeTraits<uint8>::_Min;  
      
      *pPixelIterOuter = ResolutionTypeTraits<uint8>::_Min;
    }
    else
    {
      // Outside  region
      // we don't want to start inpainting right  at the star's edge. 
      // If the distance to star's center dist2 < 1.3f*radius2 then 
      // blooming pixels will be reconstructed using Gaussian curve 
      // as inner pixels
     *pPixelIterInner = (elxSPT_IS_STAR(thresholdMap[i]) && dist2 <= 
                         INPAINT_LIMIT*radius2) ?
        ResolutionTypeTraits<uint8>::_Max : ResolutionTypeTraits<uint8>::_Min;
        
      // If the distance is greater then 1.3f*radius2 then inpaint it.
      *pPixelIterOuter = (elxSPT_IS_STAR(thresholdMap[i]) && dist2 > 
                          INPAINT_LIMIT*radius2) ? 
        ResolutionTypeTraits<uint8>::_Max : ResolutionTypeTraits<uint8>::_Min;
    }
  }

} // CreateInpaintBitmaps 


//----------------------------------------------------------------------------
// restores star's inner area
//----------------------------------------------------------------------------
void Debloomer::RestoreStarInnerArea(const BloomingStar &iStar, 
  const Image::ImageVariant& iInnerMask, Image::ImageVariant& ioImage) const
{
  elxCALL_FUNCTION_FOR_ALL_PIXEL_TYPES(
    elxRestoreStarInnerArea, ioImage.GetPixelFormat(), iStar, iInnerMask, ioImage);

} // RestoreStarInnerArea

//----------------------------------------------------------------------------
// restores star's outer area
//----------------------------------------------------------------------------
void Debloomer::RestoreStarOuterArea(const BloomingStar &iStar, 
  const Image::ImageVariant& iOuterMask, Image::ImageVariant& ioImage) const
{
  const uint d = uint(Math::elxRound(iStar.GetDiameter()));
  if (_RestorationMethod == Image::RM_FAST_INPAINT)
  {
    if (!ioImage.FastInpaint(iOuterMask, false))
      elxThrow(elxErrOperationFailed, 
        "Debloomer::RestoreStarOuterArea. Failed to FastInpaint sub-image");
  }
  else if (_RestorationMethod == Image::RM_FAST_MARCHING)
  {
    if (!ioImage.FastMarchingInpaint(iOuterMask, d/3, false))
      elxThrow(elxErrOperationFailed, 
        "Debloomer::RestoreStarOuterArea. Failed to FastMarchingInpaint sub-image");
  }
  else if (_RestorationMethod == Image::RM_EXEMPLAR_BASED)
  {
    const Math::Point2i& upperLeft = iStar.GetUpperLeft();
    const Math::Point2i& lowerRight = iStar.GetLowerRight();
    const uint dx = lowerRight._x - upperLeft._x + 1;
    const uint dy = lowerRight._y - upperLeft._y + 1;
    Math::AOBBox2i iSearchArea;
    iSearchArea._x = iSearchArea._y = 0;
    iSearchArea._w = dx;
    iSearchArea._h = dy;
    if (!ioImage.ExemplarBasedInpaint(iOuterMask, iSearchArea, d/3, false))
      elxThrow(elxErrOperationFailed, 
        "Debloomer::RestoreStarOuterArea. Failed to ExemplarBasedInpaint sub-image");
   }
   else
      elxThrow(elxErrInvalidParams, 
          "Debloomer::RestoreStarOuterArea. Invalid inpainting method");   

} // RestoreStarOuterArea

} // namespace Astro
} // namespace eLynx
