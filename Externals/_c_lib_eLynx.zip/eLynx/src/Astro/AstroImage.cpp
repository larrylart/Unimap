//============================================================================
//  AstroImage.cpp                                     Astro.Component package
//============================================================================
//  Usage : astronomical image class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <iostream>
#include <algorithm>

#include <elx/astro/AstroImage.h>
#include <elx/astro/StarParser.h>
#include <elx/astro/Registrator.h>
#include <elx/astro/ThresholdStarDetector.h>
#include <elx/astro/ProfileStarDetector.h>
#include <elx/image/ImageFileManager.h>
#include <elx/math/LinearTransformation.h>
#include <elx/core/CoreConversion.h>

#include "AstroImage.hpp"


using namespace eLynx::Math;
using namespace boost;
using namespace std;

namespace eLynx {
namespace Astro {

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EAstroImageType iType)
{
  static const char * ms_lut[AIT_Unknown+1] =
  {
    "Bias", 
    "Dark", 
    "Flat field", 
    "Light",
    "Master bias", 
    "Master dark", 
    "Master flat field", 
    "Reduced light",
    "Stacked", 
    "Unknown"
  };
  return ms_lut[iType];

} // elxToString


//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EAstroImageSubtype iSubtype)
{
  static const char * ms_lut[AIS_Unknown+1] =
  {
    "Unused",
    "Luminance",
    "Red",
    "Green",
    "Blue",
    "Halpha",
    "Hbeta",
    "OIII",
    "SII",
    "Unknown" 
  };
  return ms_lut[iSubtype];

} // elxToString


//----------------------------------------------------------------------------
//  elxUseable
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
bool elxUseable(const AstroImage * iprImage)
{
  if (NULL == iprImage) return false;
  return iprImage->IsValid();

} // elxUseable


//----------------------------------------------------------------------------
//  default constructor : construct invalid image
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
AstroImage::AstroImage() : ImageVariant(),
  _Type(AIT_Unknown),
  _Subtype(AIS_Unknown),
  _bPreviewLoaded(false),
  _bPreviewEmbedded(false),
  _bThumbnailLoaded(false),
  _vwWidth(800), _vwHeight(600),
  _tnWidth(200), _tnHeight(150),
  _bRejected(false),
  _bScoreValid(false),
  _Score(-1.0f)
{
  _Filename[0] = '\0';
  _spTrf.reset(new LinearTransformation());
}

//----------------------------------------------------------------------------
//  constructor : construct uninitialized image map of size iWidth by iHeight and type.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : EPixelFormat iPixelFormat
//        uint iWidth
//        uint iHeight
//----------------------------------------------------------------------------
AstroImage::AstroImage(EPixelFormat iPixelFormat, uint iWidth, uint iHeight) :
  ImageVariant(iPixelFormat, iWidth, iHeight),
  _Type(AIT_Unknown),
  _Subtype(AIS_Unused),
  _bPreviewLoaded(false),
  _bPreviewEmbedded(false),
  _bThumbnailLoaded(false),
  _vwWidth(800), _vwHeight(600),
  _tnWidth(200), _tnHeight(150),
  _bRejected(false),
  _bScoreValid(false),
  _Score(-1.0f)
{
  _Filename[0] = '\0';
  _spTrf.reset(new LinearTransformation());
}

//----------------------------------------------------------------------------
//  copy constructor from AstroImage
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const AstroImage& iImage
//----------------------------------------------------------------------------
AstroImage::AstroImage(const AstroImage& iImage):
  ImageVariant(iImage),
  _Info(iImage._Info),
  _Type(iImage._Type),
  _Subtype(iImage._Subtype),
  _bPreviewEmbedded(iImage._bPreviewEmbedded),
  _vwWidth(iImage._vwWidth), 
  _vwHeight(iImage._vwHeight),
  _tnWidth(iImage._tnWidth), 
  _tnHeight(iImage._tnHeight),
  _bRejected(iImage._bRejected),
  _bScoreValid(iImage._bScoreValid),
  _Score(iImage._Score),
  _spTrf(iImage._spTrf->Clone())
{
  _Filename = iImage._Filename;
  elxForceFilename(_Filename);

  _bPreviewLoaded = iImage._bPreviewLoaded;
  if (_bPreviewLoaded) _Preview = iImage._Preview;
  
  _bThumbnailLoaded = iImage._bThumbnailLoaded;
  if (_bThumbnailLoaded) _Thumbnail = iImage._Thumbnail;

  _Stars.resize(iImage._Stars.size());
  std::copy(iImage._Stars.begin(), iImage._Stars.end(), _Stars.begin());
 
} // copy constructor


//----------------------------------------------------------------------------
//  operator =
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const AstroImage& iImage: image to assign
//  Out : const AstroImage&
//----------------------------------------------------------------------------
const AstroImage& AstroImage::operator = (const AstroImage& iImage) 
{
  // guard against assigning to the "this" pointer
  if (this == &iImage)  return *this;
  ImageVariant::operator=(iImage);

  _Filename = iImage._Filename;
  elxForceFilename(_Filename);
  _Info = iImage._Info;
  _Type = iImage._Type;
  _Subtype = iImage._Subtype;
  _bRejected = iImage._bRejected;
  _bScoreValid = iImage._bScoreValid;
  _Score = iImage._Score;
  _tnWidth = iImage._tnWidth; 
  _tnHeight = iImage._tnHeight;
  _vwWidth = iImage._vwWidth;
  _vwHeight = iImage._vwHeight;

  _bPreviewEmbedded = iImage._bPreviewEmbedded;
  _bPreviewLoaded = iImage._bPreviewLoaded;
  if (_bPreviewLoaded) _Preview = iImage._Preview;
    
  _bThumbnailLoaded = iImage._bThumbnailLoaded;
  if (_bThumbnailLoaded) _Thumbnail = iImage._Thumbnail;
  
  _Stars.resize(iImage._Stars.size());
  std::copy(iImage._Stars.begin(), iImage._Stars.end(), _Stars.begin());
  _spTrf = iImage._spTrf->Clone();
  
  return *this;

} // operator =


//----------------------------------------------------------------------------
//  destructor
//----------------------------------------------------------------------------
//  public virtual
//----------------------------------------------------------------------------
AstroImage::~AstroImage()
{
} // destructor

//----------------------------------------------------------------------------
//  destructor
//----------------------------------------------------------------------------
void AstroImage::Release() { delete this; }

//----------------------------------------------------------------------------
void AstroImage::SetType(EAstroImageType iType) { _Type = iType; }
EAstroImageType AstroImage::GetType() const     { return _Type; }

EAstroImageSubtype AstroImage::GetSubtype() const        { return _Subtype; }
void AstroImage::SetSubtype(EAstroImageSubtype iSubtype) { _Subtype = iSubtype; }

//----------------------------------------------------------------------------
void AstroImage::Reject(bool ibRejected) { _bRejected = ibRejected; }
bool AstroImage::IsRejected() const      { return _bRejected; }

//----------------------------------------------------------------------------
const string& AstroImage::GetFilename() const         { return _Filename;}
void AstroImage::SetFilename(const string& iFilename) { _Filename = iFilename; }
string AstroImage::GetFileNameExt() const   
{
  string path, name, ext;
  elxSplitFilename(_Filename, path, name, ext);
  return name+"."+ext;
} 

//----------------------------------------------------------------------------
const ImageFileInfo& AstroImage::GetInfo() const  { return _Info; }
ImageFileInfo& AstroImage::GetInfo()              { return _Info; }

//----------------------------------------------------------------------------
time_t AstroImage::GetTimeStamp() const
{
  time_t t=0;
  _Info.GetTimeStamp(t);
  return t;
}

//----------------------------------------------------------------------------
//  AutoDetect
//----------------------------------------------------------------------------
bool AstroImage::AutoDetect()
{
  if (_Filename == "") return false;
//  bool bSuccess = false;

  // plugin has retrieve info?
  EImageContent content = IC_Unknown;
  if (_Info.GetContent(content))
  {
    switch (content)
    {
      case IC_Bias:      _Type = AIT_Bias; break;
      case IC_Dark:      _Type = AIT_Dark; break;
      case IC_FlatField: _Type = AIT_FlatField; break;
      case IC_Light:     _Type = AIT_Light; _Subtype = AIS_Unknown; break;
      case IC_Green:     _Type = AIT_Light; _Subtype = AIS_Green; break;
      case IC_Red:       _Type = AIT_Light; _Subtype = AIS_Red; break;
      case IC_Blue:      _Type = AIT_Light; _Subtype = AIS_Blue; break;
      case IC_Luminance: _Type = AIT_Light; _Subtype = AIS_Luminance; break;
      case IC_Halpha:    _Type = AIT_Light; _Subtype = AIS_Halpha; break;
      case IC_Hbeta:     _Type = AIT_Light; _Subtype = AIS_Hbeta; break;
      case IC_OIII:      _Type = AIT_Light; _Subtype = AIS_OIII; break;
      case IC_SII:       _Type = AIT_Light; _Subtype = AIS_SII; break;
      default: break;
    }
    if (AIT_Unknown != _Type)
      return true;
  }

  // Quick analyse of a copy of preview image in Lub format
  ImageHistogram histogram;
  ImageVariant preview(_Preview);
  preview.ChangePixelFormat(PF_Lub);
  preview.ComputeHistogram(histogram);

  double energy = 0.0;
  preview.ComputeEnergy(energy);
  const float dominance = histogram.ComputeDominance();
  std::cout << _Filename << std::endl;
  std::cout << "=> dominance=" << dominance << " energy=" << energy << " detected as ";
 
  // bias = very short exposure
  float shutter;
  if (_Info.GetShutter(shutter))
  {
    if (shutter <= 0.01f)
    {
      // should be bias or flat-field
      if ((dominance < 0.1f) || (energy < 1.0))
      {
        _Type = AIT_Bias;
        return true;
      }
      else
      {
        _Type = AIT_FlatField;
        return true;
      }
    }
    else if (shutter < 4.0f)
    {
      _Type = AIT_FlatField;
      return true;
    }
  }

  if (energy < 100.0)
  {
    // -dark is 'back' image
    _Type = AIT_Dark;
  }
  else if (dominance > 0.4f)
  {
    // -flat field is 'white' image
    _Type = (shutter < 4.0f) ? AIT_FlatField : AIT_Light;
  }
  else
  {
    // -object is 'nor back nor white' image
    _Type = AIT_Light;
  }

  return true;

} // AutoDetect


//----------------------------------------------------------------------------
//  Construction from filename
//----------------------------------------------------------------------------
AstroImage::AstroImage(const string &iFilename, int iFlags):
  ImageVariant(),
  _Type(AIT_Unknown)
{
  Load(iFilename, iFlags);
}

//----------------------------------------------------------------------------
//  Load
//----------------------------------------------------------------------------
bool AstroImage::Load(const string &iFilename, int iFlags)
{
  // forget current datas
  Invalidate();
  _Type = AIT_Unknown;

  if (iFilename == "") return false;
  bool bSuccess = false;

  // try to load full image
  if (iFlags & LO_Image)
  {
    bSuccess = the_ImageFileManager.Import(*this, iFilename.c_str(), &_Info);
    if (!bSuccess) return false;

    // update filename
    _Filename = iFilename;
    elxForceFilename(_Filename);
    if (iFlags & LO_AutoDetectType)
    {
      // Auto detection of image type
      bSuccess = AutoDetect();
      std::cout<< elxToString(_Type) << std::endl;
    }
    return bSuccess;
  }

  if (iFlags & LO_Preview)
  {
    // load image info & generate preview if available
    bSuccess = the_ImageFileManager.CanImport(iFilename.c_str(), &_Info, true);
    if (!bSuccess) return false;

    // update filename
    _Filename = iFilename;
    elxForceFilename(_Filename);

    // get preview from info if it has been generated
    if (_Info.GetPreview(_Preview))
    {
      _bPreviewLoaded = true;
      _bPreviewEmbedded = true;

      // free memory
      _Info.UnloadPreview();
    }
    else
    {
      bSuccess = GeneratePreview(false);
    }
  }

  if (iFlags & LO_AutoDetectType)
  {
    // Auto detection of image type
    bSuccess = AutoDetect();
    std::cout<< elxToString(_Type) << std::endl;
  }
  return bSuccess;

} // Load


//----------------------------------------------------------------------------
//  LoadImage
//----------------------------------------------------------------------------
bool AstroImage::LoadImage(ProgressNotifier& iNotifier)
{
  if (AIT_Unknown == _Type) return false;
  if (_Filename == "") return false;
  if (!IsValid())
  {
    ImageFileInfo Info;
    return the_ImageFileManager.Import(*this, _Filename.c_str(), &Info, iNotifier);
  }
  // already loaded
  return true;
}


//----------------------------------------------------------------------------
//  GetPreview
//----------------------------------------------------------------------------
bool AstroImage::GetPreview(ImageVariant& oImage)
{
  if (!_Preview.IsValid()) return false;
  oImage = _Preview;
  return true;
  
} // GetPreview

//----------------------------------------------------------------------------
//  GetPreviewName
//----------------------------------------------------------------------------
string AstroImage::GetPreviewName() const
{
  if (_Filename == "") 
    elxThrow(elxErrInvalidContext, "AstroImage filename is not set.");

  string path, name, ext;
  elxSplitFilename(_Filename, path, name, ext);

  string result = path + PREVIEW_PATH + elxPATH_SEPARATOR + name + ".jpg"; 
  elxForceFilename(result);
  
  cout << result << endl;
  
  return result;
  
} // GetPreviewName

//----------------------------------------------------------------------------
//  GeneratePreview: 
//----------------------------------------------------------------------------
bool AstroImage::GeneratePreview(bool ibForce)
{
  // if already loaded no need to load again if not forced
  if (_bPreviewLoaded && !ibForce)
    return true;

  // try to generate preview, in cache directory, from plugin.
  // this is optimized if main image handle a preview (mode RAW+jpeg)
  ImageFileInfo Info;
  string preview = GetPreviewName(); 
  bool bSuccess = the_ImageFileManager.
    GeneratePreview(_Filename.c_str(), preview.c_str());

  if (bSuccess)
  {
    // try to load already generated preview in cache
    _bPreviewLoaded = the_ImageFileManager.Import(_Preview, preview.c_str());
  }
  else if (ibForce)
  {
    // force generation, loading main image (performance cost)
    ImageVariant image( _Filename.c_str() );
    if (_bPreviewEmbedded)
    {
      // preview generated by the camera
      image.ChangeResolution(RT_UINT8);
      image.Resize(_vwWidth, _vwHeight);
      image.Normalize();
      if (AIT_Light == _Type)
        image.AdjustGamma(1.4);
    }
    else
    {
      // preview generated by hand...
      switch(_Type)
      {
        case AIT_Bias: 
        case AIT_MasterBias:      GenerateBiasPreview(image);  break;
        case AIT_Dark:
        case AIT_MasterDark:      GenerateDarkPreview(image);  break;
        case AIT_FlatField: 
        case AIT_MasterFlatField: GenerateFlatPreview(image);  break;
        case AIT_Light: default:  GenerateLightPreview(image); break;
      }
    }
    _Preview = image;
    _bPreviewLoaded = true;
  }

  return _bPreviewLoaded;

} // GeneratePreview


//----------------------------------------------------------------------------
//  GenerateBiasPreview: 
//----------------------------------------------------------------------------
void AstroImage::GenerateBiasPreview(ImageVariant& ioImage)
{
  // we try to enhance noice details
  // min & max are in the low range of histogram
  ioImage.Resize(_vwWidth, _vwHeight);

  // full dynamic range
  ioImage.Normalize();

  // gamma correction CCD => Screen
  ioImage.AdjustGamma(2.2);
  ioImage.ChangeResolution(RT_UINT8);

} // GenerateBiasPreview

//----------------------------------------------------------------------------
//  GenerateDarkPreview: 
//----------------------------------------------------------------------------
void AstroImage::GenerateDarkPreview(ImageVariant& ioImage)
{
  ioImage.Resize(_vwWidth, _vwHeight);

  // full dynamic range
  ioImage.Normalize();

  // gamma correction CCD => Screen
  ioImage.AdjustGamma(2.2);
  ioImage.ChangeResolution(RT_UINT8);
  
  // enhance low level details to see noise
  ioImage.AdjustMidtone(0.01);

} // GenerateDarkPreview

//----------------------------------------------------------------------------
//  GenerateFlatPreview: 
//----------------------------------------------------------------------------
void AstroImage::GenerateFlatPreview(ImageVariant& ioImage)
{
  // full dynamic range
  ioImage.Normalize();
  ioImage.Resize(_vwWidth, _vwHeight);

  // gamma correction CCD => Screen
  ioImage.AdjustGamma(2.2);
  ioImage.ChangeResolution(RT_UINT8);

  // enhance map to see where optical problems
  ioImage.AdjustBrightness(-0.3);
  ioImage.Normalize();
  ioImage.AdjustGamma(0.4);
  ioImage.AdjustContrast(0.5);

} // GenerateFlatPreview


//----------------------------------------------------------------------------
//  GenerateLightPreview: 
//----------------------------------------------------------------------------
void AstroImage::GenerateLightPreview(ImageVariant& ioImage)
{
  // we try to enhance details
  ioImage.Normalize();
  ioImage.Resize(_vwWidth, _vwHeight);
  ioImage.AdjustGamma(2.2);
  ioImage.ChangeResolution(RT_UINT8);

  ioImage.AdjustMidtone(0.1);
  ioImage.AdjustContrast(0.3);

} // GenerateLightPreview


//----------------------------------------------------------------------------
//  LoadPreview
//----------------------------------------------------------------------------
bool AstroImage::LoadPreview(ProgressNotifier& iNotifier)
{
  return _Preview.Load(GetPreviewName().c_str(), NULL, iNotifier);
}

//----------------------------------------------------------------------------
//  SavePreview
//----------------------------------------------------------------------------
bool AstroImage::SavePreview(ProgressNotifier& iNotifier)
{
  if (!_Preview.IsValid())
  {
    // Preview does not exist try to generate it
    if (!GeneratePreview(true))
      return false;
  }
  ImageFileOptions options;
  options.SetQuality(80);
  return _Preview.Save( GetPreviewName().c_str(), iNotifier, &options );

} // SavePreview

//----------------------------------------------------------------------------
//  SetPreviewDimension
//----------------------------------------------------------------------------
void AstroImage::SetPreviewDimension(uint iWidth, uint iHeight)
{
  _vwWidth = iWidth;
  _vwHeight = iHeight;

} // SetPreviewDimension


//----------------------------------------------------------------------------
//  GetThumbnail
//----------------------------------------------------------------------------
bool AstroImage::GetThumbnail(ImageVariant& oImage)
{
  if (!_Thumbnail.IsValid()) 
    if (!GenerateThumbnail(false))
      if (!GenerateThumbnail(true))
        return false;
  oImage = _Thumbnail;
  return true;
  
} // GetThumbnail


//----------------------------------------------------------------------------
//  GetThumbnailName
//----------------------------------------------------------------------------
string AstroImage::GetThumbnailName() const
{
  if (_Filename == "") 
    elxThrow(elxErrInvalidContext, "AstroImage filename is not set.");

  string path, name, ext;
  elxSplitFilename(_Filename, path, name, ext);

  string result = path + PREVIEW_PATH + elxPATH_SEPARATOR + name + "_tn.jpg"; 
  elxForceFilename(result);
  
  cout << result << endl;
  return result;  

} // GetThumbnailName


//----------------------------------------------------------------------------
//  SetThumbnailDimension
//----------------------------------------------------------------------------
void AstroImage::SetThumbnailDimension(uint iWidth, uint iHeight)
{
  _tnWidth = iWidth;
  _tnHeight = iHeight;

} // SetThumbnailDimension

//----------------------------------------------------------------------------
//  GenerateThumbnail in memory
//----------------------------------------------------------------------------
bool AstroImage::GenerateThumbnail(bool ibForce)
{
  // if already loaded no need to load again if not forced
  if (_bThumbnailLoaded && !ibForce)
    return true;

  if (!GeneratePreview(ibForce)) return false;

  _Thumbnail = _Preview;
  _bThumbnailLoaded = true;

  switch(_Type)
  {
    case AIT_Bias: case AIT_MasterBias:
    case AIT_FlatField: case AIT_MasterFlatField:
      // quick but inaccurate
      _Thumbnail.Resize(_tnWidth, _tnHeight);
      break;

    default:  //case AIT_Dark: case AIT_MasterDark: case AIT_Light:
      // better quality but slower
      _Thumbnail.Resample(_tnWidth, _tnHeight);
    break;
  }

  if (!_bPreviewEmbedded) return true;

  _Thumbnail.Normalize();
  if (AIT_Light == _Type)
    _Thumbnail.AdjustGamma(1.4);

  return true;

} // GenerateThumbnail

//----------------------------------------------------------------------------
//  LoadThumbnail
//----------------------------------------------------------------------------
bool AstroImage::LoadThumbnail(ProgressNotifier& iNotifier)
{
  return _Thumbnail.Load(GetThumbnailName().c_str(), NULL, iNotifier);
}

//----------------------------------------------------------------------------
//  SaveThumbnail
//----------------------------------------------------------------------------
bool AstroImage::SaveThumbnail(ProgressNotifier& iNotifier)
{
  if (!_Thumbnail.IsValid())
  {
    // _Thumbnail does not exist try to generate it
    if (!GenerateThumbnail(false))
      return false;
  }
  ImageFileOptions options;
  options.SetQuality(70);
  return _Thumbnail.Save( GetThumbnailName().c_str(), iNotifier, &options );

} // SaveThumbnail


//----------------------------------------------------------------------------
//  Unload
//----------------------------------------------------------------------------
void AstroImage::Unload(int iSelection)
{
  if (iSelection & SI_Main)
  {
    Invalidate();
    _bScoreValid = false;
  }
  if (iSelection & SI_Preview)
  {
    _Preview.Invalidate();
    _bPreviewLoaded = false;
  }
  if (iSelection & SI_Thumbnail)
  {
    _Thumbnail.Invalidate();
    _bThumbnailLoaded = false;
  }

} // Unload


//----------------------------------------------------------------------------
//  Save
//----------------------------------------------------------------------------
bool AstroImage::Save(const string &iFilename) const
{
  return false;

} // Save


//----------------------------------------------------------------------------
//  CanSave
//----------------------------------------------------------------------------
bool AstroImage::CanSave(const string &iFilename) const
{
  if (NULL == _spAbstractImpl.get()) return false;
  if (iFilename == "") return false;
  return the_ImageFileManager.CanExport(*_spAbstractImpl, iFilename.c_str());

} // CanSave


//----------------------------------------------------------------------------
//  GetStarsCount: get the number of detected stars
//----------------------------------------------------------------------------
uint AstroImage::GetStarsCount() const
{
  return _Stars.size();
}

//----------------------------------------------------------------------------
//  GetStar: get the specified star (const version)
//----------------------------------------------------------------------------
const Star& AstroImage::GetStar(uint iIndex) const
{
  if (iIndex >= GetStarsCount()) 
    elxThrow(elxErrOutOfRange, elxMsgFormat(
      "Star index %i out of range <0, %i>.", iIndex, GetStarsCount()-1));
      
  return _Stars[iIndex];
}

//----------------------------------------------------------------------------
//  GetStar: get the specified star
//----------------------------------------------------------------------------
Star& AstroImage::GetStar(uint iIndex)
{
  if (iIndex >= GetStarsCount()) 
    elxThrow(elxErrOutOfRange, elxMsgFormat(
      "Star index %i out of range <0, %i>.", iIndex, GetStarsCount()-1));
      
  return _Stars[iIndex];
}

//----------------------------------------------------------------------------
//  GetStarList: get list of stars (const version)
//----------------------------------------------------------------------------
const StarList& AstroImage::GetStarList() const
{
  return _Stars;
}

//----------------------------------------------------------------------------
//  GetStarList: get list of stars
//----------------------------------------------------------------------------
StarList& AstroImage::GetStarList()
{
  return _Stars;
}

//----------------------------------------------------------------------------
//  LoadStarsInfo: loads the stars positions and sizes from the file
//----------------------------------------------------------------------------
void AstroImage::LoadStarsInfo(const std::string &iInfoFile)
{
  // Init parser
  DOMParser::Init();
  
  // create the parser and parse the config file
  StarParser parser;
  _Stars.clear();
  parser.LoadStarInfo(iInfoFile, _Stars);

  // Clean up  
  DOMParser::CleanUp(); 
} // LoadStarsInfo
  
  
//----------------------------------------------------------------------------
//  SaveStarsInfo: saves the stars positions and sizes to the file
//----------------------------------------------------------------------------
void AstroImage::SaveStarsInfo(const std::string &iInfoFile)
{
  const uint32 starSize = GetStarsCount();
  // check if there are some stars to save
  if (starSize == 0)
    elxThrow(elxErrInvalidContext, 
      elxMsgFormat("Image %s contains no stars to be saved.", 
        GetFileNameExt().c_str()));
        
  // Init parser
  DOMParser::Init();
  // create the parser and save stars
  StarParser parser;
  parser.SaveStarInfo(iInfoFile, GetStarList());
  // Clean up  
  DOMParser::CleanUp();
   
} // SaveStarsInfo
  
  
//----------------------------------------------------------------------------
// CompareStars: compare star diameters
//----------------------------------------------------------------------------
bool AstroImage::CompareStars(const Star& iStar1, const Star& iStar2)
{
  return iStar1.GetDiameter() > iStar2.GetDiameter();
} 


//----------------------------------------------------------------------------
//  GetImageScore: computes and returns image score
//----------------------------------------------------------------------------
double AstroImage::GetImageScore() const
{
  // if not computed, compute it
  if (!_bScoreValid) {
  
    // check, if image is valid
    if (!IsValid()) 
      elxThrow(elxErrInvalidContext, "Can't evaluate score of invalid image.");
      
    // check, if there are some stars
    if (GetStarsCount() == 0)
      elxThrow(elxErrInvalidContext, 
        "Stars must be detected to evaluate score.");
        
    // stars are already sorted by diameter, so simply take the diameter
    // of the middle one
    double d;
    uint mid = GetStarsCount()/2;
    if (GetStarsCount()%2 == 1) d = GetStar(mid).GetDiameter();
    else d = (GetStar(mid-1).GetDiameter()+GetStar(mid).GetDiameter())/2.0;
    /*for (uint i = 0; i < GetStarsCount(); i++)
      d += GetStar(i).GetDiameter();
    d /= (double)GetStarsCount();*/ 
    
    // check the value (stars should have diameters above 1/2 of pixel)
    if (d < 0.1) 
      elxThrow(elxErrInvalidContext, elxMsgFormat(
        "Invalid median star diameter %g.", d));
    
    // compute the score
    _Score = 1.0/d;
    _bScoreValid = true;
  }
    
  // return the score
  return _Score;

} // GetImageScore


//----------------------------------------------------------------------------
//  RegisterImage: register this image to given image
//----------------------------------------------------------------------------
bool AstroImage::RegisterImage(
    const RegistrationParams &iParams, 
    const AstroImage &iReferenceImage, 
    ProgressNotifier &iNotifier)
{ 
  // create registrator for given images
  Registrator registrator(iReferenceImage, *this);
  
  // register the images
  return registrator.Register(iParams, _spTrf, iNotifier);

} // RegisterImage

//----------------------------------------------------------------------------
//  explicit instantiation for all Star Detector types
//----------------------------------------------------------------------------
template void AstroImage::DetectStars<ThresholdStarDetector>(
  ThresholdStarDetector&);
template void AstroImage::DetectStars<ProfileStarDetector>(
  ProfileStarDetector&);
  
} // namespace Astro
} // namespace eLynx
