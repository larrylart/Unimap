//============================================================================
//  StarTriangle.cpp                                   Astro.Component package
//============================================================================
//  Usage : the triangle formed from three stars on one image
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/astro/StarTriangle.h>
#include <elx/astro/ImageRecord.h>

#include <math.h>

namespace eLynx {
namespace Astro {

//--------------------------------------------------------
// constructor, creates uninitialized triangle

StarTriangle::StarTriangle()
{
	_prOwner = NULL;
	_StarIndices[0] = _StarIndices[1] = _StarIndices[2] = 0;
	_BAStarIndex = _CAStarIndex = _CBStarIndex = 0;
	_BARatio = _CARatio = 0.0;
}


//--------------------------------------------------------
// constructor, creates triangle on given image
	
StarTriangle::StarTriangle(ImageRecord *iOwner)
{
	_prOwner = iOwner;
	_StarIndices[0] = _StarIndices[1] = _StarIndices[2] = 0;
	_BAStarIndex = _CAStarIndex = _CBStarIndex = 0;
	_BARatio = _CARatio = 0.0;
}


//--------------------------------------------------------
// copy constructor

StarTriangle::StarTriangle(const StarTriangle &c)
{
	CopyData(c);
}


//--------------------------------------------------------
// an assignement operator

StarTriangle& StarTriangle::operator = (const StarTriangle &c)
{
	if (&c != this) CopyData(c);
	return *this;
}


//--------------------------------------------------------
// returns triangle owner image (const version)

const ImageRecord* StarTriangle::GetOwner() const
{
	return _prOwner;
}


//--------------------------------------------------------
// returns triangle owner image

ImageRecord* StarTriangle::GetOwner()
{
	return _prOwner;
}


//--------------------------------------------------------
// sets triangle owner to specified image

void StarTriangle::SetOwner(ImageRecord *iprOwner)
{
	_prOwner = iprOwner;
}


//--------------------------------------------------------
// returns index of the specified star (vertex)

uint StarTriangle::GetStarIndex(uint iIndex) const
{
	// check index
	if (iIndex >= 3) 
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %i out of range <0, 2>.", iIndex));
		
	return _StarIndices[iIndex];
}


//--------------------------------------------------------
// returns specified star (vertex) (const version)

const Star& StarTriangle::GetStar(uint iIndex) const
{
	// check index
	if (iIndex >= 3) 
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %i out of range <0, 2>.", iIndex));
		
	// check owner
	if (_prOwner == NULL)
		elxThrow(elxErrInvalidContext, "Triangle owner image is not defined.");
		
	return _prOwner->GetStar(_StarIndices[iIndex]);
}


//--------------------------------------------------------
// returns specified star (vertex)

Star& StarTriangle::GetStar(uint iIndex)
{
	// check index
	if (iIndex >= 3) 
		elxThrow(elxErrOutOfRange, elxMsgFormat("Index %i out of range <0, 2>.", iIndex));
		
	// check owner
	if (_prOwner == NULL)
		elxThrow(elxErrInvalidContext, "Triangle owner image is not defined.");
		
	return _prOwner->GetStar(_StarIndices[iIndex]);
}


//--------------------------------------------------------
// returns star index between b and a sides

uint StarTriangle::GetStarIndexBA() const
{
	return _BAStarIndex;
}


//--------------------------------------------------------
// returns star index between c and a sides

uint StarTriangle::GetStarIndexCA() const
{
	return _CAStarIndex;
}


//--------------------------------------------------------
// returns star index between c and b sides

uint StarTriangle::GetStarIndexCB() const
{
	return _CBStarIndex;
}


//--------------------------------------------------------
// sets star indices and computes side ratios

void StarTriangle::SetStarIndices(uint iA, uint iB, uint iC)
{
	// check if star indices are distinct
	if (iA == iB || iA == iC || iB == iC)
		elxThrow(elxErrInvalidParams, elxMsgFormat("Star indices (%i, %i, %i) must not be equal.",
			iA, iB, iC));

	// set indices
	_StarIndices[0] = iA;
	_StarIndices[1] = iB;
	_StarIndices[2] = iC;
	
	// compute side ratios
	ComputeRatios();
}


//--------------------------------------------------------
// returns B/A side ratio

double StarTriangle::GetBARatio() const
{
	return _BARatio;
}


//--------------------------------------------------------
// returns C/A side ratio

double StarTriangle::GetCARatio() const
{
	return _CARatio;
}


//--------------------------------------------------------
// copies data of specified object into this object

void StarTriangle::CopyData(const StarTriangle &c)
{
	_prOwner = c._prOwner;
	_StarIndices[0] = c._StarIndices[0];
	_StarIndices[1] = c._StarIndices[1];
	_StarIndices[2] = c._StarIndices[2];
	_BAStarIndex = c._BAStarIndex;
	_CAStarIndex = c._CAStarIndex;
	_CBStarIndex = c._CBStarIndex;
	_BARatio = c._BARatio;
	_CARatio = c._CARatio;
}


//--------------------------------------------------------
// computes side ratios

void StarTriangle::ComputeRatios()
{
	// check owner
	if (_prOwner == NULL)
		elxThrow(elxErrInvalidContext, "Triangle owner image is not defined.");
	
	// get the star distances table
	const StarDistArray &dist_table = GetOwner()->GetDistTable();
	
	// get sizes of triangle sides
	TriangleSide sides[3];
	
	sides[0]._Vertex1 = 0; sides[0]._Vertex2 = 1;
	sides[0]._Length = dist_table.GetDistance(GetStarIndex(0), GetStarIndex(1));
	
	sides[1]._Vertex1 = 1; sides[1]._Vertex2 = 2;
	sides[1]._Length = dist_table.GetDistance(GetStarIndex(1), GetStarIndex(2));
	
	sides[2]._Vertex1 = 0; sides[2]._Vertex2 = 2;
	sides[2]._Length = dist_table.GetDistance(GetStarIndex(0), GetStarIndex(2));
	
	// sort distances in descending order (longest first)
	SimpleSort(sides);
	
	// check if longest side is not zero
	if (fabs(sides[0]._Length) < 1e-6) 
		elxThrow(elxErrInvalidParams, "Triangle has no size.");
	
	// compute side ratios (middle/longest, shortest/longest)
	_BARatio = sides[1]._Length/sides[0]._Length;
	_CARatio = sides[2]._Length/sides[0]._Length;
	
	// update side/side vertex indices
	_BAStarIndex = GetCommonVertex(sides[0], sides[1]);
	_CAStarIndex = GetCommonVertex(sides[0], sides[2]);
	_CBStarIndex = GetCommonVertex(sides[1], sides[2]);
}


//--------------------------------------------------------
// effectively sorts three double values

void StarTriangle::SimpleSort(StarTriangle::TriangleSide ioValues[3]) const
{
	#define swap(a, b) { TriangleSide tmp = a; a = b; b = tmp; }
	
	if (ioValues[1]._Length > ioValues[0]._Length) swap(ioValues[0], ioValues[1]);
	if (ioValues[2]._Length > ioValues[1]._Length) swap(ioValues[1], ioValues[2]);
	if (ioValues[1]._Length > ioValues[0]._Length) swap(ioValues[0], ioValues[1]);
}


//--------------------------------------------------------
// returns common star index for given sides

uint StarTriangle::GetCommonVertex(const StarTriangle::TriangleSide &iA, 
	const StarTriangle::TriangleSide &iB) const
{
	if (iA._Vertex1 == iB._Vertex1 || iA._Vertex1 == iB._Vertex2)
		return _StarIndices[iA._Vertex1];
	return _StarIndices[iA._Vertex2];
}

} // namespace Astro
} // namespace eLynx
