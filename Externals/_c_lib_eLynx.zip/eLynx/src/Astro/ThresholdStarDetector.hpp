//============================================================================
//  ThresholdStarDetector.hpp                          Astro.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __ThresholdStarDetector_hpp__
#define __ThresholdStarDetector_hpp__

#include <elx/math/MathCore.h>
#include <elx/astro/Star.h>
#include <elx/astro/BloomingStar.h>


namespace eLynx {
namespace Astro {

using namespace eLynx::Image;

namespace {

inline
bool elxStarHasBitmap(const Star&)
{
  return false;
}
inline
bool elxStarHasBitmap(const BloomingStar&)
{
  return true;
}

inline
void elxSetStarData(Star&, const Image::ImageVariant &,
  const Math::Rectangle2i&, BaseStarDetector::PixelMap)
{}
inline
void elxSetStarData(BloomingStar& ioStar, 
  const Image::ImageVariant &iImage, const Math::Rectangle2i& iStarRectangleBase,
  BaseStarDetector::PixelMap iPixelMap)
{
  const uint w = iImage.GetWidth();
  PixelIterator<const PixelLf> pixelIt = 
    elxConstDowncast<const PixelLf>(iImage.Begin());
  pixelIt.moveto(iStarRectangleBase._P0._x, iStarRectangleBase._P0._y);
  
  ioStar.SetUpperLeft(iStarRectangleBase._P0);
  ioStar.SetLowerRight(iStarRectangleBase._P1);
  const uint dx = iStarRectangleBase._P1._x - iStarRectangleBase._P0._x + 1;
  const uint dy = iStarRectangleBase._P1._y - iStarRectangleBase._P0._y + 1;
  
  BaseStarDetector::PixelMap thresholdMap(new uint[dx*dy]());
  BaseStarDetector::LuminanceMap luminanceMap(new float[dx*dy]());
  for (int y = iStarRectangleBase._P0._y, idx = 0; 
       y <= iStarRectangleBase._P1._y; ++y, pixelIt.moveto(iStarRectangleBase._P0._x,y))
    for (int x = iStarRectangleBase._P0._x; 
       x <= iStarRectangleBase._P1._x; ++x, ++idx, pixelIt.advance(1))
    {
      thresholdMap[idx] = iPixelMap[y*w+x];
      luminanceMap[idx] = pixelIt->GetLuminance();
    }
  ioStar.SetThresholdMap(thresholdMap);
  ioStar.SetLuminanceMap(luminanceMap);
}

} // namespace

//--------------------------------------------------------
// detects the stars on image, whose intensities are above
// given threshold
template <class StarType>
void ThresholdStarDetector::DetectStars(
  const Image::ImageVariant &iImage, std::vector<StarType>& oStars) const
{
  boost::scoped_ptr<Image::ImageVariant> spLuminanceImage;
  if (!iImage.IsLf())
  {
	  spLuminanceImage.reset(new ImageVariant(iImage));
	  spLuminanceImage->ChangePixelFormat(PF_Lf);
    if (!spLuminanceImage->IsLf())
		  elxThrow(elxErrOperationFailed, "Unable to change image pixel format.");
  }
  const Image::ImageVariant* pLuminanceImage = 
    (iImage.IsLf()) ? &iImage : spLuminanceImage.get();
  
	// get actual threshold value
	float threshold = GetActualThreshold(*pLuminanceImage);
	
	// create the threshold bitmap
	BaseStarDetector::PixelMap pixelMap;
	CreatePixelMap(*pLuminanceImage, threshold, pixelMap);
  
	// perform the star detection over all bitmap pixels
  const uint nPixel = pLuminanceImage->GetPixelCount();
	for (uint idx = 0; idx < nPixel; ++idx) 
  {
		// if the SPT_STAR bit is set, detect star for this pixel
		// star detection sets SPT_SEEN bit for all pixels, belonging to star, so 
		// we can be sure that no star is detected twice
		if (elxSPT_IS_STAR(pixelMap[idx]) && !elxSPT_IS_SEEN(pixelMap[idx]))
      DetectStar(*pLuminanceImage, pixelMap, idx, oStars);
		// go to next pixel
	}

}


//--------------------------------------------------------
// detects the star, that contains given pixel

template <class StarType>
void ThresholdStarDetector::DetectStar(const Image::ImageVariant &iImage, 
	BaseStarDetector::PixelMap &ioBitmap, uint iIdx, 
  std::vector<StarType>& oStars) const
{
	// create new star on image
  Math::Rectangle2i starRectangle(
    Math::Point2i(iImage.GetWidth(), iImage.GetHeight()),
    Math::Point2i(0, 0));
    
  Math::Point2d starPosition;
  double starDiameter = 0.0, starIntensity = 0.0;
  
	// perform recursive star detection, starting with given pixel
	DetectStarLine(iImage, ioBitmap, iIdx, starRectangle, starPosition, 
    starDiameter, starIntensity);
    
	// skip stars of size 1 pixel
	if (starDiameter <= 1.0 || 
      Math::elxAbs(starRectangle._P0._x - starRectangle._P1._x) <  2 || 
      Math::elxAbs(starRectangle._P0._y - starRectangle._P1._y) <  2) 
      return;
      
	StarType star;
	//star.SetOwner(&iImage);
  
	// star position is weighted sum of all pixel positions
	// to compute correct position, we will divide them by size, to compute
	// weighted average pixel position
  star.SetIntensity(starIntensity);
  star.SetPosition(starPosition._x/starIntensity, starPosition._y/starIntensity);
	star.SetDiameter(Math::elxSqrt(4.0*starDiameter/M_PI));
  elxSetStarData(star,  iImage, starRectangle, ioBitmap);
	
	// add star to the list
	oStars.push_back(star);
}


} // namespace Astro
} // namespace eLynx

#endif // __ThresholdStarDetector_hpp__
