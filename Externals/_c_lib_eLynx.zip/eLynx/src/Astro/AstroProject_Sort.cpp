//============================================================================
//  AstroProject_Sort.cpp                              Astro.Component package
//============================================================================
//  Usage : astronomical image processing project class implementation.
//  Luc's request.
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------

/*
Light_xxxISO_yyys 
Dark_xxxISO_yyys
Flat_xxxISO
Bias_xxxISO
*/

//----------------------------------------------------------------------------
//  SortFiles
//----------------------------------------------------------------------------
bool AstroProject::SortFiles()
{ 
  char name[elxPATH_MAX];
  ::sprintf(name, "%srename.bat", _DataPath);
  
  FILE * paFile = ::fopen(name, "wt+");
  if (NULL == paFile) return false;

  const int l = ::strlen(_DataPath);
  int count = _FrameHolder.GetBiasFrames().GetCount();
  ::fprintf(paFile, "mkdir Bias\n");
  for (int i=0; i<count; i++)
  {
    AstroImage & prImage = _FrameHolder.GetBiasFrames().GetFrame(i);

    // get filename without extension
    char name[elxPATH_MAX];
    const char * prName = prImage.GetFilename().c_str() + l;
    ::strcpy(name, prName);
    char * prExt = ::strrchr(name, '.');
    *prExt = '\0';

    ImageFileInfo info = prImage.GetInfo();
    uint ISO;       
    info.GetISO(ISO);

    char newName[elxPATH_MAX];
    ::sprintf(newName, "Bias/%dISO_%s\n", 
      ISO, prImage.GetFilename().c_str() + l);

    ::fprintf(paFile, "move %s %s", prImage.GetFilename().c_str() + l, newName);

  }


  count = _FrameHolder.GetDarkFrames().GetCount();
  ::fprintf(paFile, "mkdir Dark\n");
  for (int i=0; i<count; i++)
  {
    AstroImage & prImage = _FrameHolder.GetDarkFrames().GetFrame(i);

    // get filename without extension
    char name[elxPATH_MAX];
    const char * prName = prImage.GetFilename().c_str() + l;
    ::strcpy(name, prName);
    char * prExt = ::strrchr(name, '.');
    *prExt = '\0';

    ImageFileInfo info = prImage.GetInfo();
    float shutter;  info.GetShutter(shutter);
    uint ISO;       info.GetISO(ISO);

    char newName[elxPATH_MAX];
    ::sprintf(newName, "Dark/%dISO_%ds_%s\n", 
      ISO, int(shutter), prImage.GetFilename().c_str() + l);

    ::fprintf(paFile, "move %s %s", prImage.GetFilename().c_str() + l, newName);
    
  }

  count = _FrameHolder.GetFlatFrames().GetCount();
  ::fprintf(paFile, "mkdir Flat\n");
  for (int i=0; i<count; i++)
  {
    AstroImage & prImage = _FrameHolder.GetFlatFrames().GetFrame(i);

    // get filename without extension
    char name[elxPATH_MAX];
    const char * prName = prImage.GetFilename().c_str() + l;
    ::strcpy(name, prName);
    char * prExt = ::strrchr(name, '.');
    *prExt = '\0';

    ImageFileInfo info = prImage.GetInfo();
    uint ISO;       
    info.GetISO(ISO);

    char newName[elxPATH_MAX];
    ::sprintf(newName, "Flat/%dISO_%s\n", 
      ISO, prImage.GetFilename().c_str() + l);

    ::fprintf(paFile, "move %s %s", prImage.GetFilename().c_str() + l, newName);
  }


  count = _FrameHolder.GetLightFrames().GetCount();
  ::fprintf(paFile, "mkdir Light\n");
  for (int i=0; i<count; i++)
  {
    AstroImage & prImage = _FrameHolder.GetLightFrames().GetFrame(i);

    // get filename without extension
    char name[elxPATH_MAX];
    const char * prName = prImage.GetFilename().c_str() + l;
    ::strcpy(name, prName);
    char * prExt = ::strrchr(name, '.');
    *prExt = '\0';

    ImageFileInfo info = prImage.GetInfo();
    float shutter;  info.GetShutter(shutter);
    uint ISO;       info.GetISO(ISO);

    char newName[elxPATH_MAX];
    ::sprintf(newName, "Light/%dISO_%ds_%s\n", 
      ISO, int(shutter), prImage.GetFilename().c_str() + l);

    ::fprintf(paFile, "move %s %s", prImage.GetFilename().c_str() + l, newName);

  }
  ::fclose(paFile);
  paFile = NULL;
  return true;

} // SortFiles
