//============================================================================
//  StarParser.cpp                                    Astro.Component package
//============================================================================
//  Usage :
//----------------------------------------------------------------------------
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/core/CoreConversion.h>
#include <elx/astro/StarParser.h>

namespace eLynx {
namespace Astro {

//----------------------------------------------------------------------------
// constructor
//----------------------------------------------------------------------------
StarInfo::StarInfo() :
  _X_pos(),
  _Y_pos(),
  _Intensity(),
  _Diameter()
{}

StarInfo::StarInfo(const std::string& iX_pos, const std::string& iY_pos,
    const std::string& iIntensity, const std::string& iDiameter) :
  _X_pos(iX_pos),
  _Y_pos(iY_pos),
  _Intensity(iIntensity),
  _Diameter(iDiameter)
{}
    
StarInfo::StarInfo(
  double iX_pos, double iY_pos, double iIntensity, double iDiameter) :
  _X_pos(),
  _Y_pos(),
  _Intensity(),
  _Diameter()
{
  char buffer[60];
  snprintf(buffer, 60, "%.10f", iX_pos);
  _X_pos = std::string(buffer);
  snprintf(buffer, 60, "%.10f", iY_pos);
  _Y_pos = std::string(buffer);
  snprintf(buffer, 60, "%.10f", iIntensity);
  _Intensity = std::string(buffer);
  snprintf(buffer, 60, "%.10f", iDiameter);
  _Diameter = std::string(buffer);
}


//----------------------------------------------------------------------------
// constructor
//----------------------------------------------------------------------------
StarTagNames::StarTagNames() :
  TAG_IMAGE(      xercesc::XMLString::transcode( "image"      ) ) ,
  TAG_STAR(       xercesc::XMLString::transcode( "star"       ) ) ,
  TAG_X_POS(      xercesc::XMLString::transcode( "x_pos"      ) ) ,
  TAG_Y_POS(      xercesc::XMLString::transcode( "y_pos"      ) ) ,
  TAG_INTENSITY(  xercesc::XMLString::transcode( "intensity"  ) ) ,
  TAG_DIAM(       xercesc::XMLString::transcode( "diam"       ) ) 
{} // StarTagNames::StarTagNames() 

//----------------------------------------------------------------------------
// destructor
//----------------------------------------------------------------------------
StarTagNames::~StarTagNames()
{
  try
  {
    xercesc::XMLString::release( &TAG_IMAGE     );
    xercesc::XMLString::release( &TAG_STAR      );
    xercesc::XMLString::release( &TAG_X_POS     );
    xercesc::XMLString::release( &TAG_Y_POS     );
    xercesc::XMLString::release( &TAG_INTENSITY );
    xercesc::XMLString::release( &TAG_DIAM      );
  }
  catch( ... )
  {}
} // StarTagNames::~StarTagNames() 

//----------------------------------------------------------------------------
// constructor
//----------------------------------------------------------------------------
StarParser::StarParser() :
  _Tags()
{}


//----------------------------------------------------------------------------
// Loads star info from a file. May throw in case of errors
//----------------------------------------------------------------------------
void StarParser::LoadStarInfo(const std::string &iInfoFile,
  StarList& oStars) const
{
  Parser parser(iInfoFile);
  try
  {
    const xercesc::DOMNodeList* prStarNodes = 
      parser.GetTopElement()->getElementsByTagName(_Tags.TAG_STAR);
    XMLSize_t sizeStar = prStarNodes->getLength();
    std::string strValue;
    double xpos, ypos, intensity, diameter; 
    for( XMLSize_t i = 0 ; i < sizeStar; ++i)
    {
      Star star;
      xercesc::DOMElement* starNode = 
        dynamic_cast<xercesc::DOMElement*>(prStarNodes->item(i));
      parser.ParseChildNodeValue(starNode, _Tags.TAG_X_POS, strValue);
      if (!elxStringToType(strValue.c_str(), xpos))
        elxThrow(elxErrOperationFailed, 
          elxMsgFormat("Star X coordinate is not numeric: %s.", strValue.c_str()));
      parser.ParseChildNodeValue(starNode, _Tags.TAG_Y_POS, strValue);
      if (!elxStringToType(strValue.c_str(), ypos))
        elxThrow(elxErrOperationFailed, 
          elxMsgFormat("Star Y coordinate is not numeric: %s.", strValue.c_str())); 
      parser.ParseChildNodeValue(starNode, _Tags.TAG_INTENSITY, strValue);
      if (!elxStringToType(strValue.c_str(), intensity))
        elxThrow(elxErrOperationFailed, 
          elxMsgFormat("Star Intensity is not numeric: %s.", strValue.c_str())); 
      parser.ParseChildNodeValue(starNode, _Tags.TAG_DIAM, strValue);
      if (!elxStringToType(strValue.c_str(), diameter))
        elxThrow(elxErrOperationFailed, 
          elxMsgFormat("Star Diameter is not numeric: %s.", strValue.c_str()));
      oStars.push_back(Star(xpos, ypos, intensity, diameter));
    }
  }
  catch (elxException& ex)
  {
    throw;
  }
  catch(...)
  {
    elxThrow(elxErrOperationFailed, 
      elxMsgFormat("Failed to init AstroParser with %s.", iInfoFile.c_str()));
  }
  
} // StarParser::LoadStarInfo

//----------------------------------------------------------------------------
// Saves star info into a file. May throw in case of errors
//----------------------------------------------------------------------------
void StarParser::SaveStarInfo(const std::string &iInfoFile,
  const StarList& iStars) const
{
  xercesc::DOMLSSerializer* prSerializer = NULL;
  xercesc::DOMDocument* prDoc = NULL;
  xercesc::DOMLSOutput* prOutput = NULL;
  
  try
  {
    // The DOM implementation retains ownership of the returned object. 
    // Application code should NOT delete it. 
    xercesc::DOMImplementation* prDomImpl = 
      xercesc::DOMImplementation::getImplementation();
    prDoc = prDomImpl->createDocument(
               NULL,                    // root element namespace URI.
               _Tags.TAG_IMAGE,         // root element name
               NULL);                   // document type object (DTD).
    xercesc::DOMElement* prRootElem = prDoc->getDocumentElement();

    const uint32 starSize = iStars.size();
    // iterate over the stars
    for (uint32 i = 0; i < starSize; ++i)
    {
      //Star element
      xercesc::DOMElement*  prStarElem = prDoc->createElement(_Tags.TAG_STAR);
      prRootElem->appendChild(prStarElem);
      
      // X_POS 
      Parser::AppendFloatNode(
        prDoc,_Tags.TAG_X_POS, iStars[i].GetX(), prStarElem);  
      
      // Y_POS 
      Parser::AppendFloatNode(
        prDoc,_Tags.TAG_Y_POS, iStars[i].GetY(), prStarElem);  
      
      // Intensity 
      Parser::AppendFloatNode(
        prDoc,_Tags.TAG_INTENSITY, iStars[i].GetIntensity(), prStarElem);  
      
      // Diameter 
      Parser::AppendFloatNode(
        prDoc,_Tags.TAG_DIAM, iStars[i].GetDiameter(), prStarElem);  
    }
    
    // Write the XML to the file
    prSerializer = ((xercesc::DOMImplementationLS*)prDomImpl)->createLSSerializer();
    xercesc::LocalFileFormatTarget  *prFormTarget = 
      new xercesc::LocalFileFormatTarget(iInfoFile.c_str());
    prOutput = ((xercesc::DOMImplementationLS*)prDomImpl)->createLSOutput();
    prOutput->setByteStream(prFormTarget);
    prSerializer->write(prDoc, prOutput);
    
    // release resources
    prOutput->release();
    prSerializer->release();
    prDoc->release();
  }
  catch(...)
  {
    if (NULL != prOutput) prOutput->release(); 
    if (NULL != prSerializer) prSerializer->release(); 
    if (NULL != prDoc) prDoc->release();
    elxThrow(elxErrOperationFailed, 
      elxMsgFormat("Failed to save star info in %s.", iInfoFile.c_str()));
  }
}
  
} // namespace Astro
} // namespace eLynx
