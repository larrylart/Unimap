//============================================================================
//  StarDistArray.cpp                                  Astro.Component package
//============================================================================
//  Usage : two-dimensional array of distances between stars on image
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/astro/StarDistArray.h>
#include <elx/astro/ImageRecord.h>

#include <math.h>

namespace eLynx {
namespace Astro {
	
//--------------------------------------------------------
// constructor, creates uninitialized array

StarDistArray::StarDistArray()
{
	_nArraySize = 0;
	_spArray.reset(NULL);
}


//--------------------------------------------------------
// build array from first N of specified stars
	
void StarDistArray::BuildArray(const ImageRecord &iImage, uint iFirstN)
{
	if (iFirstN == 0) iFirstN = iImage.GetStarCount();
	
	if (iFirstN > iImage.GetStarCount())
		elxThrow(elxErrOutOfRange, elxMsgFormat("Number of stars %i out of range <1, %i>",
			iFirstN, iImage.GetStarCount()));
			
	_spArray.reset(new double[iFirstN*iFirstN]);
	_nArraySize = iFirstN;
	
	///compute distances
	for (uint i = 0; i < iFirstN; i++) {
		const Star &star1 = iImage.GetStar(i);
		for (uint j = i; j < iFirstN; j++) {
			if (i == j) SetDistance(i, j, 0.0);
			else {
				const Star &star2 = iImage.GetStar(j);
				double dx = star1.GetX()-star2.GetX();
				double dy = star1.GetY()-star2.GetY();
				double distance = sqrt(dx*dx+dy*dy);
				SetDistance(i, j, distance);
				SetDistance(j, i, distance);
			}
		}
	}
	
}


//--------------------------------------------------------
// returns the nubmer of stars in array
	
uint StarDistArray::GetStarCount() const
{
	return _nArraySize;
}


//--------------------------------------------------------
// returns the distance between specified stars
	
double StarDistArray::GetDistance(uint iStarA, uint iStarB) const
{
	// check indices
	if (iStarA >= GetStarCount() || iStarB > GetStarCount())
		elxThrow(elxErrOutOfRange, elxMsgFormat("Table index (%i, %i) out of range (0, %i)x(0, %i).",
			iStarA, iStarB, GetStarCount()-1, GetStarCount()-1));
			
	return _spArray[iStarB*GetStarCount()+iStarA];
}


//--------------------------------------------------------
// sets the distance between specified stars

void StarDistArray::SetDistance(uint iStarA, uint iStarB, double iDistance)
{
	// check indices
	if (iStarA >= GetStarCount() || iStarB > GetStarCount())
		elxThrow(elxErrOutOfRange, elxMsgFormat("Table index (%i, %i) out of range (0, %i)x(0, %i).",
			iStarA, iStarB, GetStarCount()-1, GetStarCount()-1));
			
	_spArray[iStarB*GetStarCount()+iStarA] = iDistance;
}

//--------------------------------------------------------

} // namespace Astro
} // namespace eLynx
