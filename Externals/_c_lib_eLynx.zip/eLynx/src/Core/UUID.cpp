//============================================================================
//  UUID.cpp                                            Core.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/UUID.h>
#include <stdio.h>
#include <string.h>

namespace eLynx {

//----------------------------------------------------------------------------
//  constructor from string
//----------------------------------------------------------------------------
UUID::UUID(const char * prString) :
  _data1(0),
  _data2(0), 
  _data3(0)
{
  _data4[0] = _data4[1] = _data4[2] = _data4[3] =
  _data4[4] = _data4[5] = _data4[6] = _data4[7] = 0;
  if (NULL == prString)
    return;
		
  // temporary array to suppress compiler warning
  uint16 Data[8];
  ::sscanf(prString, "{%08x-%04hx-%04hx-%02hx%02hx-%02hx%02hx%02hx%02hx%02hx%02hx}",
    &_data1, &_data2, &_data3, 
    &Data[0], &Data[1], &Data[2], &Data[3], &Data[4], &Data[5], &Data[6], &Data[7]);
  for (int32 i=0; i<8; i++)
    _data4[i] = (uint8)Data[i];

} // constructor


//----------------------------------------------------------------------------
//  GetString
//----------------------------------------------------------------------------
//           1         2         3   
// 012345678901234567890123456789012345678
// {xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx}
//----------------------------------------------------------------------------
void UUID::GetString(char oString[39]) const
{
  ::sprintf(oString, "{%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x}",
    _data1, _data2, _data3, _data4[0],_data4[1],
    _data4[2],_data4[3],_data4[4],_data4[5],_data4[6],_data4[7]);

} // GetString


//----------------------------------------------------------------------------
UUID::UUID() :
  _data1(0),
  _data2(0), 
  _data3(0)
{
  _data4[0]=_data4[1]=_data4[2]=_data4[3]=_data4[4]=_data4[5]=_data4[6]=_data4[7] = 0;

} // constructor

//----------------------------------------------------------------------------
UUID::UUID(uint32 iD1, uint16 iD2, uint16 iD3, 
    uint8 iD40, uint8 iD41, uint8 iD42, uint8 iD43, uint8 iD44, uint8 iD45, uint8 iD46, uint8 iD47) :
  _data1(iD1),
  _data2(iD2), 
  _data3(iD3)
{
  _data4[0] = iD40;
  _data4[1] = iD41;
  _data4[2] = iD42;
  _data4[3] = iD43;
  _data4[4] = iD44;
  _data4[5] = iD45;
  _data4[6] = iD46;
  _data4[7] = iD47;

} // constructor

//----------------------------------------------------------------------------
UUID::UUID(const UUID& iOther)
{
  ::memcpy(this, &iOther, sizeof(UUID));

} // copy constructor
 
//----------------------------------------------------------------------------
void UUID::operator= (const UUID& iOther)
{
  ::memcpy(this, &iOther, sizeof(UUID));

} // assignment operator

//----------------------------------------------------------------------------
bool UUID::operator == (const UUID& iUUID) const
{
  return (0 == ::memcmp(this, &iUUID, sizeof(UUID)));

} // operator ==

//----------------------------------------------------------------------------
bool UUID::operator != (const UUID& iUUID) const
{
  return (0 != ::memcmp(this, &iUUID, sizeof(UUID)));

} // operator !=

} // namespace eLynx
