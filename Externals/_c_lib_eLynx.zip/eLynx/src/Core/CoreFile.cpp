//============================================================================
//  CoreFile.cpp                                        Core.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreFile.h>
#include <elx/core/CoreTrace.h>

#include <string.h>
#include <stdio.h>
#include <algorithm>

#ifdef elxWINDOWS

  #include <io.h>

#elif elxLINUX

  #include <sys/param.h>
  #include <sys/stat.h>
  #include <stdlib.h>
  #include <string.h>
  #include <dlfcn.h>
  #include <unistd.h>
  #include <glob.h>
  #include <fcntl.h>

#elif elxMACOSX

  // @TODO

#endif


namespace eLynx {

//############################################################################
//                            Module methods
//############################################################################

//----------------------------------------------------------------------------
//  elxLoadModule: Load a .dll
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const char * iprFilename : module (dll) file name.
//        ModuleId& oModule ! ModuleId is the lib handle
//  Out : bool true is succeeded, false otherwise
//----------------------------------------------------------------------------
bool elxLoadModule(const char * iprFilename, ModuleId& oModule)
{
#ifdef elxWINDOWS

  oModule = ::LoadLibrary(iprFilename);
  return (0 != oModule);

#elif elxLINUX

  oModule = ::dlopen(iprFilename, RTLD_LAZY);
  if (NULL == oModule) 
  {
    char * prErrorStr = ::dlerror();
    elxTRACE_ERROR(CORE_L,
      ("elxLoadModule(%s) failed, try absolute file.\n", iprFilename));
    elxTRACE_ERROR(CORE_L,
      ("A dynamic linking error occurred: (%s)\n", prErrorStr));

    // Convert the name to an absolute file name
    char FullName[elxPATH_MAX];
    char * prAbsolute = realpath(iprFilename, FullName);
    if (NULL != prAbsolute) 
    {
      oModule = ::dlopen(prAbsolute, RTLD_LAZY);
      if (NULL == oModule) 
      {
        prErrorStr = ::dlerror();
        elxTRACE_ERROR(CORE_L,
          ("elxLoadModule(%s) failed too.\n", prAbsolute));
        elxTRACE_ERROR(CORE_L,
          ("A dynamic linking error occurred: (%s)\n", prErrorStr));
      }
    }
  }
  return (NULL != oModule);

#elif elxMACOSX

  // @todo
  void * prSymbol = NULL;

#endif

} // elxLoadModule


//----------------------------------------------------------------------------
//  elxUnloadModule : free a dll.
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : ModuleId& ioModuleId The module to unload.
//  Out : if succeeded set ioModuleId to 0.
//----------------------------------------------------------------------------
void elxUnloadModule(ModuleId& ioModuleId)
{
  if (0 == ioModuleId)
    return;

#ifdef elxWINDOWS

  ::FreeLibrary(ioModuleId);
  ioModuleId = 0;

#elif elxLINUX

  ::dlclose(ioModuleId);
  ioModuleId = 0;

#elif elxMACOSX

  // @todo

#endif

} // elxUnloadModule


//----------------------------------------------------------------------------
//  elxResolveSymbol: Resolve the symbol in a module file.
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : iModule The module file id to look for symbol.
//        iprSymbolName The symbol name to resolve.
//  Out : The address of the exported symbol, NULL if fails.
//----------------------------------------------------------------------------
void * elxResolveSymbol(const ModuleId& iModuleId, const char * iprSymbolName)
{
#ifdef elxWINDOWS

  if (0 == iModuleId) return NULL;
  void * prSymbol = ::GetProcAddress(iModuleId, iprSymbolName);

#elif elxLINUX

  if (0 == iModuleId) return NULL;
  void * prSymbol = ::dlsym(iModuleId, iprSymbolName);

#elif elxMACOSX

  // @todo
  return NULL;

#endif

  return prSymbol;

} // elxResolveSymbol



//############################################################################
//                            Path methods
//############################################################################

//----------------------------------------------------------------------------
//  elxIsPath: check a directory
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const char * iprPath : The path name to check.
//  Out : bool : true if path exists, false otherwise.
//----------------------------------------------------------------------------
bool elxIsPath(const char * iprPath)
{
  if (NULL == iprPath)
    return false;

#ifdef elxWINDOWS

  const DWORD Attributes = ::GetFileAttributes(iprPath);
  return (FILE_ATTRIBUTE_DIRECTORY == Attributes);

#elif elxLINUX

  struct stat buffer;
  ::stat(iprPath, &buffer);
  return (S_ISDIR(buffer.st_mode));

#elif elxMACOSX

  // @todo
  return false;

#endif

}

//----------------------------------------------------------------------------
//  elxMakePath: Make a directory
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const char * iprPath : The path name to make.
//  Out : bool : true if creation succeeds, false otherwise.
//----------------------------------------------------------------------------
bool elxMakePath(const char * iprPath)
{
  if (NULL == iprPath)
    return false;

#ifdef elxWINDOWS

  const BOOL bResult = ::CreateDirectory(iprPath, NULL);
  return (bResult == TRUE);

#elif elxLINUX

  const int rc = ::mkdir(iprPath, S_IRWXU);
  return (0 == rc);

#elif elxMACOSX

  // @todo
  return false;

#endif

} // elxMakePath


//----------------------------------------------------------------------------
//  elxDeletePath: Delete a directory
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const char * iprPath : The path name to delete.
//  Out : bool : true if deletion succeeds, false otherwise.
//----------------------------------------------------------------------------
bool elxDeletePath(const char * iprPath)
{
  if (NULL == iprPath)
    return false;

#ifdef elxWINDOWS

  const BOOL bResult = ::RemoveDirectory(iprPath);
  return (bResult == TRUE);

#elif elxLINUX

  const int rc = ::rmdir(iprPath);
  return (0 == rc);

#elif elxMACOSX

  // @todo
  return false;

#endif

} // DeletePath


//############################################################################
//                            File methods
//############################################################################

//----------------------------------------------------------------------------
//  elxEnumerateFile: Enumerate files that match the target.
//  Callback must return true to continue enumeration, false to stop enumeration.
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const char * iprTarget: The target file to enumerate. Ex "doc\*.htm".
//        elxFileEnumCB ifnCallback: The callback to call when a file is found.
//        void * iprUserData: Datas to transmit to the callback
//  Out : -
//----------------------------------------------------------------------------
void elxEnumerateFile(
    const char * iprTarget,
    elxFileEnumCB ifnCallback,
    void * iprUserData)
{
  // check parameters
  if ((NULL == iprTarget) || (NULL == ifnCallback))
    return;

#ifdef elxWINDOWS

  char Fullname[elxPATH_MAX];
  ::strcpy(Fullname, iprTarget);
  elxForceFilename(Fullname);

  // point after the last file separator
  char * prStart = ::strrchr(Fullname, elxPATH_SEPARATOR);
  if (NULL == prStart)
    prStart = Fullname;
  else
    prStart++;

 //char tmp[1024]; GetCurrentDirectory(1024, tmp);

  // look for first file
  _finddata_t FileData;
  //long 
  intptr_t hFile = _findfirst(iprTarget, &FileData);
  if (-1L == hFile)
    return;

  // enumerate first file 
  ::strcpy(prStart, FileData.name);
  const bool bContinue = ifnCallback(Fullname, iprUserData);

  // more file ?
  if (bContinue)
  {
    while (_findnext(hFile, &FileData) == 0)
    {
      ::strcpy(prStart, FileData.name);
      if (!ifnCallback(Fullname, iprUserData))
        break;
    }
  }
  _findclose(hFile);

#elif elxLINUX

  char Target[elxPATH_MAX];
  ::strcpy(Target, iprTarget);
  elxForceFilename(Target);

  glob_t buffer;
  buffer.gl_offs = 0;

  ::glob(Target, GLOB_DOOFFS, NULL, &buffer);
  const int nItem = buffer.gl_pathc;
  for (int i=0; i<nItem; i++)
  {
    if (!ifnCallback(buffer.gl_pathv[i], iprUserData))	
      break;
  }
  ::globfree(&buffer);

#elif elxMACOSX

  // @todo

#endif

} // elxEnumerateFile


//----------------------------------------------------------------------------
//  elxIsFileExist: Check if a file exist
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const char * iprFilename : The filename to check.
//  Out : bool : true if file exists, false otherwise.
//----------------------------------------------------------------------------
bool elxIsFileExist(const char * iprFilename)
{
  if (NULL == iprFilename)
    return false;

#ifdef elxWINDOWS

  const int rc = _access(iprFilename, 0);
  return (0 == rc);

#elif elxLINUX

  const int rc = ::access(iprFilename, 0);
  return (0 == rc);

#elif elxMACOSX

  // @todo
  return false;

#endif

} // IsFileExist


//----------------------------------------------------------------------------
//  elxDeleteFile: Delete a file
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const char * iprFilename The filename to delete.
//  Out : bool : true if deletion succeeds, false otherwise.
//----------------------------------------------------------------------------
bool elxDeleteFile(const char * iprFilename)
{
  if (NULL == iprFilename)
    return false;

#ifdef elxWINDOWS

  const int rc = _unlink(iprFilename);
  return (0 == rc);

#elif elxLINUX

  const int rc = ::unlink(iprFilename);
  return (0 == rc);

#elif elxMACOSX

  // @todo
  return false;

#endif

} // DeleteFile



//############################################################################
//                            Filename methods
//############################################################################

//----------------------------------------------------------------------------
//  elxForceFilename: Force full filename with OS specific separator
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : char * ioprFilename : the filename to force
//  Out : -
//----------------------------------------------------------------------------
void elxForceFilename(char * ioprFilename)
{
  if (NULL == ioprFilename)
    return;

#ifdef elxWINDOWS

  // force Windows filename
  for (char * p=ioprFilename; *p != '\0'; p++)
  {
    if (*p == '/') 
      *p = elxPATH_SEPARATOR;
  }

#else // elxLINUX, elxMACOSX

  // force UNIX style filename
  for (char * p=ioprFilename; *p != '\0'; p++)
  {
    if (*p == '\\') 
      *p = elxPATH_SEPARATOR;
  }

#endif

} // ForceFilename # char


//----------------------------------------------------------------------------
//  elxForceFilename: Force full filename with OS specific separator
//----------------------------------------------------------------------------
void elxForceFilename(std::string &ioFilename)
{
#ifdef elxWINDOWS
  std::replace(ioFilename.begin(), ioFilename.end(), '/', elxPATH_SEPARATOR);
#else
  std::replace(ioFilename.begin(), ioFilename.end(), '\\', elxPATH_SEPARATOR);
#endif

} // ForceFilename # std::string


//----------------------------------------------------------------------------
//  elxGetFileExt: const version
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const char * iprFilename :
//  Out : const char * The file extension.
//----------------------------------------------------------------------------
const char * elxGetFileExt(const char * iprFilename)
{
  // check parameter
  if ((NULL == iprFilename))
    return NULL;

  const size_t sizeName = ::strlen(iprFilename);
  if (!sizeName)
    return NULL;

  const char * prLastPoint = ::strrchr(iprFilename, '.');
  if (NULL == prLastPoint)
    return NULL;

  prLastPoint++;
  if (::strlen(prLastPoint))
    return prLastPoint;

  return NULL;

} // elxGetFileExt


//----------------------------------------------------------------------------
//  elxGetFileExt: none-const version
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const char * iprFilename :
//  Out : const char * The file extension.
//----------------------------------------------------------------------------
char * elxGetFileExt(char * iprFilename)
{
  // check parameter
  if ((NULL == iprFilename))
    return NULL;

  const size_t sizeName = ::strlen(iprFilename);
  if (!sizeName)
    return NULL;

  char * prLastPoint = ::strrchr(iprFilename, '.');
  if (NULL == prLastPoint)
    return NULL;

  prLastPoint++;
  if (::strlen(prLastPoint))
    return prLastPoint;

  return NULL;

} // elxGetFileExt


//----------------------------------------------------------------------------
//  elxCheckFileExt
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const char * iprFilename :
//        const char * iprExt :
//        bool ibCase : true if test case, false if case don't mind.
//  Out : bool true if the requested extension is at the end of filename.
//----------------------------------------------------------------------------
bool elxCheckFileExt(const char * iprFilename, const char * iprExt, bool ibCase)
{
  // check parameters
  if ((NULL == iprFilename) || (NULL == iprExt))
    return false;

  const size_t sizeName = ::strlen(iprFilename);
  const size_t sizeExt = ::strlen(iprExt);
  if (!sizeName || !sizeExt || (sizeName <= sizeExt))
    return false;

  const char * prStart = iprFilename + (sizeName - sizeExt);

  int rc = 1;

#ifdef elxWINDOWS  
  if (ibCase)
    rc = ::strcmp(prStart, iprExt);
  else
    rc = _stricmp(prStart, iprExt);
#else // elxLINUX, elxMACOSX
    rc = ::strcmp(prStart, iprExt); // TODO write X platform _stricmp
#endif

  return (rc == 0);

} // elxCheckFileExt


//----------------------------------------------------------------------------
//  elxGetFileName: filename = path/name.ext retrieve name
//----------------------------------------------------------------------------
bool elxGetFileName(const char * iprFilename, char * oprName)
{
  if ((NULL == iprFilename) || (NULL == oprName))
    return false;

  if ('\0' == iprFilename[0]) 
    return false;

  char path[elxPATH_MAX];
  ::strcpy(path, iprFilename);
  elxForceFilename(path);

  // hide extension
  char * prExt = ::strrchr(path, '.');
  if (NULL == prExt) return false;
  *prExt = '\0';

  char * prName = ::strrchr(path, elxPATH_SEPARATOR);
  if (NULL == prName)
  {
    ::strcpy(oprName, path);
  }
  else
  {
    *prName++ = '\0';
    ::strcpy(oprName, prName);
  }
  return true;

} // elxGetFileName


//----------------------------------------------------------------------------
//  elxGetFileNameExt: filename = path/name.ext retrieve name.ext
//----------------------------------------------------------------------------
const char * elxGetFileNameExt(const char * iprFilename)
{
  if (NULL == iprFilename)
    return false;

  if ('\0' == iprFilename[0]) 
    return false;

  const char * prName = ::strrchr(iprFilename, elxPATH_SEPARATOR);

  // no separator found ie no path
  if (NULL == prName)
    return iprFilename;

  return prName+1;

} // elxGetFileNameExt


//----------------------------------------------------------------------------
//  elxGetFilePath: filename = path/name.ext retrieve path/
//----------------------------------------------------------------------------
bool elxGetFilePath(const char * iprFilename, char * oprPath)
{
  if ((NULL == iprFilename) || (NULL == oprPath))
    return false;

  if ('\0' == iprFilename[0]) 
    return false;

  char path[elxPATH_MAX];
  ::strcpy(path, iprFilename);
  elxForceFilename(path);

  char * prName = ::strrchr(path, elxPATH_SEPARATOR);
  if (NULL == prName)
  {
    // no path detected
    oprPath[0] = '\0';
    return true;
  }

  // hide name
  prName[1] = '\0';
  ::strcpy(oprPath, path);
  return true;

} // elxGetFilePath


//----------------------------------------------------------------------------
//  elxSplitFilename: filename = path/name.ext retrieve path/, name and ext
//----------------------------------------------------------------------------
bool elxSplitFilename(const char * iprFilename, 
    char * oprPath, char * oprName, char * oprExtension)
{
  if ((NULL == iprFilename) || (NULL == oprPath) ||
      (NULL == oprName) || (NULL == oprExtension))
    return false;

  // init output with empty string
  oprPath[0] = oprName[0] = oprExtension[0] = '\0';

  // no filename
  if ('\0' == iprFilename[0])
    return true;

  // copy full filename in path
  ::strcpy(oprPath, iprFilename);
  elxForceFilename(oprPath);

  // --- split extension ---
  char * prLastPoint = ::strrchr(oprPath, '.');
  if (NULL != prLastPoint)
  {
    // hide extension
    prLastPoint[0] = '\0';
    prLastPoint++;
    if (::strlen(prLastPoint))
    {
      // none empty extension found
      ::strcpy(oprExtension, prLastPoint);
    }
  }

  // --- split name ---
  char * prName = ::strrchr(oprPath, elxPATH_SEPARATOR);
  if (NULL == prName)
  {
    // no path detected, filename is only name
    ::strcpy(oprName, oprPath);
    oprPath[0] = '\0';
    return true;
  }

  // get name
  ::strcpy(oprName, prName+1);

  // hide name to get path
  prName[1] = '\0';
  return true;

} // elxSplitFilename # char


//----------------------------------------------------------------------------
//  elxSplitFilename: filename = path/name.ext retrieve path/, name and ext
//----------------------------------------------------------------------------
void elxSplitFilename(const std::string &iFilename,
    std::string &oPath, std::string &oName, std::string &oExt)
{
  oPath = oName = oExt = "";
  size_t pos = iFilename.find_last_of("/\\");
  if (pos == iFilename.npos) 
    pos = 0;
  else 
  {
    oPath = iFilename.substr(0, pos+1);
    pos++;
  }

  if (pos < iFilename.length()) 
  {
    size_t pos2 = iFilename.find_last_of('.');
    oName = iFilename.substr(pos, (pos2 == iFilename.npos ? pos2 : pos2-pos));
    
    if (pos2 != iFilename.npos) 
      oExt = iFilename.substr(pos2+1); 
  }

} // elxSplitFilename # sdt::string


//----------------------------------------------------------------------------
//  elxMakePath: Make a directory
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
void elxMakePath(const std::string &iPath)
{
  if ("" == iPath) return;
  
#ifdef elxWINDOWS

  ::CreateDirectory(iPath.c_str(), NULL);

#elif elxLINUX

  ::mkdir(iPath.c_str(), S_IRWXU);

#elif elxMACOSX

  // @todo
  return false;

#endif

} // elxMakePath # sdt::string


//----------------------------------------------------------------------------
//  elxIsPath: check a directory
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const string& iPath : The path name to check.
//  Out : bool : true if path exists, false otherwise.
//----------------------------------------------------------------------------
bool elxIsPath(const std::string &iPath)
{
  if ("" == iPath) return false;

#ifdef elxWINDOWS

  const DWORD Attributes = ::GetFileAttributes(iPath.c_str());
  return (FILE_ATTRIBUTE_DIRECTORY == Attributes);

#elif elxLINUX

  struct stat buffer;
  ::stat(iPath.c_str(), &buffer);
  return (S_IFDIR & buffer.st_mode);

#elif elxMACOSX

  // @todo
  return false;

#endif

} // elxIsPath # sdt::string


//----------------------------------------------------------------------------
//  elxGetFileList: gets the list of all specified files 
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : iTarget - The target file to enumerate. Ex "doc\*.htm".
//  Out : oFileList - The list of the files. 
//----------------------------------------------------------------------------
void elxGetFileList(const std::string &iTarget, 
    std::vector<std::string> &oFileList)
{
#ifdef elxWINDOWS

  std::string path, name, ext;
  elxSplitFilename(iTarget, path, name, ext);

  _finddata_t FileData;
  //long 
  intptr_t hFile = _findfirst(iTarget.c_str(), &FileData);
  if (-1L == hFile) return;
    
  oFileList.push_back(path+elxPATH_SEPARATOR+FileData.name);
  
  do 
  {
    oFileList.push_back(path+elxPATH_SEPARATOR+FileData.name);
  } 
  while (_findnext(hFile, &FileData) == 0);
  
  _findclose(hFile);  
  
#elif elxLINUX

  glob_t buffer;
  buffer.gl_offs = 0;

  ::glob(iTarget.c_str(), GLOB_DOOFFS, NULL, &buffer);
  for (uint i = 0; i < buffer.gl_pathc; i++)
    oFileList.push_back(std::string(buffer.gl_pathv[i]));

  ::globfree(&buffer);

#elif elxMACOSX

  // @todo

#endif
} // elxGetFileList # sdt::string

} // namespace eLynx
