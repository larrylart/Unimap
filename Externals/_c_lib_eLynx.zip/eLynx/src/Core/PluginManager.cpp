//============================================================================
//  PluginManager.cpp                                   Core.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <string.h>
#include <stdio.h>

// eLynx.Core
#include <elx/core/CoreOS.h>
#include <elx/core/CoreTrace.h>
#include <elx/core/IPlugin.h>
#include <elx/core/IPluginPackage.h>
#include <elx/core/PluginFile.h>
#include <elx/core/PluginManager.h>

namespace eLynx {

IPlugin::~IPlugin() {}
IPluginPackage::~IPluginPackage() {}


//----------------------------------------------------------------------------
PluginManager::PluginManager(const UUID& iFamilyType) :
  _familyType(iFamilyType)
{
  _files.clear();
  _plugins.clear();
}

//----------------------------------------------------------------------------
PluginManager::~PluginManager()
{
  Unregister();
}

//----------------------------------------------------------------------------
size_t PluginManager::GetPackageCount() const 
{ 
  return _files.size(); 
}

//----------------------------------------------------------------------------
size_t PluginManager::GetPluginCount() const 
{ 
  return _plugins.size();
}

//----------------------------------------------------------------------------
bool PluginManager::IsEmpty() const
{
  return (GetPluginCount() == 0);
}

//----------------------------------------------------------------------------
const IPlugin * PluginManager::GetPlugin(size_t iIndex) const
{
  if (iIndex >= _plugins.size())
    return NULL;

  PluginMap::const_iterator it = _plugins.begin();
  for (size_t i=0; i<iIndex; i++, it++);

  return it->first;

} // GetPlugin

//----------------------------------------------------------------------------
const IPluginPackage * PluginManager::GetPackage(
  const UUID& iUUID, 
  bool ibPlugin) const
{
  if (ibPlugin)
    return GetPackageFromPluginID(iUUID);

  return GetPackageFromPackageID(iUUID);

} // GetPackage

//----------------------------------------------------------------------------
const IPluginPackage * PluginManager::GetPackage(
  const char * iprName,
  bool ibPlugin) const
{
  if (ibPlugin)
    return GetPackageFromPluginName(iprName);

  return GetPackageFromFilename(iprName);

} // GetPackage

//----------------------------------------------------------------------------
bool PluginManager::UnregisterPackage(const char * iprFilename)
{
  const IPluginPackage * prPackage = GetPackageFromFilename(iprFilename);
  return Unregister(prPackage);

} // UnregisterPackage

//----------------------------------------------------------------------------
bool PluginManager::UnregisterPackage(const UUID& iUUID)
{
  const IPluginPackage * prPackage = GetPackageFromPackageID(iUUID);
  return Unregister(prPackage);

} // UnregisterPackage

//----------------------------------------------------------------------------
bool PluginManager::UnregisterPlugin(const char * iprName)
{
  const IPlugin * prPlugin = GetPlugin(iprName);
  return Unregister(prPlugin);

} // UnregisterPlugin

//----------------------------------------------------------------------------
bool PluginManager::UnregisterPlugin(const UUID& iUUID)
{
  const IPlugin * prPlugin = GetPlugin(iUUID);
  return Unregister(prPlugin);

} // UnregisterPlugin

//----------------------------------------------------------------------------
//  Register all package files in a directory with a file extension.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const char * iprPath:
//        const char * iprExt:
//  Out : -
//----------------------------------------------------------------------------
void PluginManager::Register(const char * iprPath, const char * iprExt)
{
  // check parameters
  if ((NULL == iprPath) || (NULL == iprExt))
    return;

  elxTRACE_PROD(CORE_L,
    ("PluginManager::Register(\"%s\\*.%s\")\n", iprPath, iprExt));

  Unregister();

  // build target
  char Target[elxPATH_MAX];
  ::strcpy(Target, iprPath);
  elxForceFilename(Target);

  // remove last separator
  const size_t l = ::strlen(Target);
  if ((l > 0) && (Target[l-1] == elxPATH_SEPARATOR))
    Target[l-1] = '\0';

  // add filter
  char Filter[elxPATH_MAX];
  ::sprintf(Filter, "%c*.%s", elxPATH_SEPARATOR, iprExt);
  ::strcat(Target, Filter);

  // Enumerate files in directory
  elxEnumerateFile(Target, FileEnumCallback, (void*)this);

} // Register


//----------------------------------------------------------------------------
//  Unregister all registered packages
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : -
//  Out : -
//----------------------------------------------------------------------------
void PluginManager::Unregister()
{
  // files are aggregated
  const size_t size = _files.size();
  for (size_t i=0; i<size; i++)
  {
    if (NULL != _files[i])
      delete _files[i];
  }
  _files.clear();

  // plugins are referenced
  _plugins.clear();

} // Unregister


//----------------------------------------------------------------------------
//  TracePackage : internal debug
//----------------------------------------------------------------------------
static void TracePackage(const IPluginPackage& iPackage)
{
  char id[39];
  char family[39];

  iPackage.GetID().GetString(id);
  iPackage.GetFamilyType().GetString(family);
  const size_t nPlugins = iPackage.GetPluginCount();

  elxTRACE_PROD(CORE_L, ("---------------------\n"));
  elxTRACE_PROD(CORE_L, ("Package %s.\n", id));
  elxTRACE_PROD(CORE_L, ("Family type %s.\n", family));
  elxTRACE_PROD(CORE_L, ("Number of plugin(s) : %d.\n", nPlugins));

  const size_t nPlugin = iPackage.GetPluginCount();
  for (size_t i=0; i<nPlugin; i++)
  {
    const IPlugin * prPlugin = iPackage.GetPlugin(i);
    elxTRACE_PROD(CORE_L, 
      ("-Plugin #%d %s, %s\n", i, prPlugin->GetDescription(0), prPlugin->GetDescription(2)));
  }
  elxTRACE_PROD(CORE_L, ("---------------------\n"));

} // TracePackage


//----------------------------------------------------------------------------
//  RegisterFile a package file
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const char * iprFileName
//  Out : bool
//----------------------------------------------------------------------------
bool PluginManager::RegisterFile(const char * iprFileName)
{
  // checks that package exist
  PluginFile * pnPluginFile = new PluginFile(iprFileName);
  if (NULL == pnPluginFile)
  {
    elxTRACE_ERROR(CORE_L,
      ("PluginManager::Register(\"%s\") failed.\n", iprFileName));
    return false;
  }

  // checks that package is valid
  if (!pnPluginFile->IsValid())
  {
    elxTRACE_ERROR(CORE_L,
      ("PluginManager::Register(\"%s\") is invalid package.\n", iprFileName));
    delete pnPluginFile;
    pnPluginFile = NULL;
    return false;
  }

  // gets package
  const IPluginPackage * prPackage = pnPluginFile->GetPackage();
  TracePackage(*prPackage);

  // checks that package adheres to _familyType
  if (prPackage->GetFamilyType() != _familyType)
  {
    elxTRACE_ERROR(CORE_L,
      ("PluginManager::Register(\"%s\") bad family type.\n", iprFileName));
    delete pnPluginFile;
    pnPluginFile = NULL;
    return false;
  }

  // checks that package is not already loaded
  const size_t nFile = _files.size();
  for (size_t f=0; f<nFile; f++)
  {
    // for all package
    const IPluginPackage * prLoadedPackage = _files[f]->GetPackage();
    if (prLoadedPackage->GetID() == prPackage->GetID())
    {
      char id[39];
      prLoadedPackage->GetID().GetString(id);
      elxTRACE_PROD(CORE_L,
          ("PluginManager::Register(\"%s\"), the package is already registered as package #%d.",
          iprFileName, f));

      // already loaded, discard
      delete pnPluginFile;
      pnPluginFile = NULL;
      return false;
    }
  }

  // register in file list
  _files.push_back(pnPluginFile);

  // register in plugins list
  const size_t nPlugin = prPackage->GetPluginCount();
  for (size_t i=0; i<nPlugin; i++)
  {
    const IPlugin * prPlugin = prPackage->GetPlugin(i);
    _plugins[prPlugin] = prPackage;
  }
  elxTRACE_PROD(CORE_L,
    ("PluginManager::Register(\"%s\") Successfull.\n\n", iprFileName));
  return true;

} // RegisterFile


//----------------------------------------------------------------------------
//  GetPackage
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const size_t iIndex
//  Out : const IPluginPackage * : reference on factory by index
//----------------------------------------------------------------------------
const IPluginPackage * PluginManager::GetPackage(size_t iIndex) const
{
  if (iIndex < _files.size())
    return _files[iIndex]->GetPackage();

  return NULL;

} // GetPackage


//----------------------------------------------------------------------------
//  GetPackage : Get the package containing a requested plugin
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const IPlugin& iPlugin
//  Out : const IPluginPackage * : reference on factory 
//----------------------------------------------------------------------------
const IPluginPackage * PluginManager::GetPackage(const IPlugin& iPlugin) const
{
  PluginMap::const_iterator it = _plugins.find(&iPlugin);
  if (it == _plugins.end())
    return NULL;

  return it->second;

} // GetPackage


//----------------------------------------------------------------------------
//  GetPackageFromPackageID
//----------------------------------------------------------------------------
//  protected
//----------------------------------------------------------------------------
//  In  : const UUID& iUUID : the package UUID to look for
//  Out : const IPluginPackage * : reference on package
//----------------------------------------------------------------------------
const IPluginPackage * PluginManager::GetPackageFromPackageID(
    const UUID& iUUID) const
{
  // for all files
  const size_t nFile = _files.size();
  for (size_t i=0; i<nFile; i++)
  {
    const IPluginPackage * prPackage = _files[i]->GetPackage();
    if (prPackage->GetID() == iUUID)
      return prPackage;
  }

  // not found
  return NULL;

} // GetPackageFromPackageID


//----------------------------------------------------------------------------
//  GetPackageFromFilename
//----------------------------------------------------------------------------
//  protected
//----------------------------------------------------------------------------
//  In  : const char * iprFilename : package filename
//  Out : const IPluginPackage * : reference on package
//----------------------------------------------------------------------------
const IPluginPackage * PluginManager::GetPackageFromFilename(
    const char * iprFilename) const
{
  if (NULL == iprFilename)
    return NULL;

  const size_t nFile = _files.size();
  for (size_t f=0; f<nFile; f++)
  {
    const char * prFilename = _files[f]->GetFilename();
    if (0 == ::strcmp(prFilename, iprFilename))
    {
      const IPluginPackage * prPackage = _files[f]->GetPackage();
      return prPackage;
    }
  }

  // not found
  return NULL;

} // GetPackageFromFilename


//----------------------------------------------------------------------------
//  GetPackageFromPluginName
//----------------------------------------------------------------------------
//  protected
//----------------------------------------------------------------------------
//  In  : const char * iprName : plugin name is description(0)
//  Out : const IPluginPackage * : reference on package
//----------------------------------------------------------------------------
const IPluginPackage * PluginManager::GetPackageFromPluginName(
    const char * iprName) const
{
  const IPlugin * prPlugin = GetPlugin(iprName);
  if (NULL == prPlugin)
    return NULL;

  const IPluginPackage * prPackage = GetPackage(*prPlugin);
  return prPackage;

} // GetPackageFromPluginName


//----------------------------------------------------------------------------
//  GetPackageFromPluginID
//----------------------------------------------------------------------------
//  protected
//----------------------------------------------------------------------------
//  In  : const UUID& iUUID : the requested plugin ClassID
//  Out : const IPluginPackage * : reference on package
//----------------------------------------------------------------------------
const IPluginPackage * PluginManager::GetPackageFromPluginID(
      const UUID& iUUID) const
{
  const IPlugin * prPlugin = GetPlugin(iUUID);
  if (NULL == prPlugin)
    return NULL;

  const IPluginPackage * prPackage = GetPackage(*prPlugin);
  return prPackage;

} // GetPackageFromPluginID


//----------------------------------------------------------------------------
//  GetPlugin
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const UUID& iUUID
//  Out : const IPlugin * : reference on plugin by UUID
//----------------------------------------------------------------------------
const IPlugin * PluginManager::GetPlugin(const UUID& iUUID) const
{
  PluginMap::const_iterator it = _plugins.begin();
  while (it != _plugins.end()) 
  {
    if (it->first->GetID() == iUUID)
      return it->first;
    it++;	
  }

  // not found
  return NULL;

} // GetPlugin


//----------------------------------------------------------------------------
//  GetPlugin
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const char * iprName
//  Out : const IPluginPackage * : reference on plugin by description
//----------------------------------------------------------------------------
const IPlugin * PluginManager::GetPlugin(const char * iprName) const
{
  if (NULL == iprName)
    return NULL;

  PluginMap::const_iterator it = _plugins.begin();
  while (it != _plugins.end()) 
  {
    const char * prDescription = it->first->GetDescription(0);
    if (0 == ::strcmp(iprName, prDescription))
      return it->first;
    it++;	
  }

  // not found
  return NULL;

} // GetPlugin


//----------------------------------------------------------------------------
//  Unregister : Unregister a package.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const IPluginPackage * iprPackage :the package to unregister
//  Out : bool true if succeeded, false otherwise
//----------------------------------------------------------------------------
bool PluginManager::Unregister(const IPluginPackage * iprPackage)
{
  std::vector<PluginFile*>::iterator it = _files.begin();
  while (it != _files.end()) 
  {
    const IPluginPackage * prPackage = (*it)->GetPackage();
    if (prPackage == iprPackage)
    {
      // unregister all plugins from package
      const size_t nPlugin = prPackage->GetPluginCount();
      for (size_t i=0; i<nPlugin; i++)
      {
        const IPlugin * prPlugin = prPackage->GetPlugin(i);
        Unregister(prPlugin);
      }

      // unload library
      delete (*it);

      // remove package from list
      _files.erase(it, it+1);
      return true;
    }

    // next
    it++;	
  }

  // package not found
  return false;

} // Unregister


//----------------------------------------------------------------------------
//  Unregister : Unregister a plugin.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const IPlugin * iprPlugin :the plugin to unregister
//  Out : bool true if succeeded, false otherwise
//----------------------------------------------------------------------------
bool PluginManager::Unregister(const IPlugin * iprPlugin)
{
  PluginMap::iterator it = _plugins.find(iprPlugin);
  if (it == _plugins.end())
    return false;

  // found, remove from list of registred plugins
  _plugins.erase(it);
  return true;

} // Unregister


//----------------------------------------------------------------------------
//  FileEnumCallback
//----------------------------------------------------------------------------
//  static protected
//----------------------------------------------------------------------------
bool PluginManager::FileEnumCallback(const char * iprFilename, void * iprUserData)
{
  // check paramaters
  if ((NULL == iprUserData) || (NULL == iprFilename))
    return false;

  PluginManager& me = *((PluginManager*)iprUserData);
  elxTRACE_PROD(CORE_L, ("=>Enumeration of %s plugin.\n", iprFilename));
  me.RegisterFile(iprFilename);
  return true;

} // FileEnumCallback

} // namespace eLynx
