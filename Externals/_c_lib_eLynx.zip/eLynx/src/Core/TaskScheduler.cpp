//============================================================================
//  TaskScheduler.cpp                                   Core.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <boost/thread.hpp>
#include <boost/ref.hpp>

#include <elx/core/CoreOS.h>

#ifdef elxUSE_THREAD

#ifdef elxWINDOWS

  // nothing

#elif defined elxLINUX

  #include <unistd.h>
  #include <linux/unistd.h>
  #include <sys/types.h>
  #include <errno.h>
  #include <sched.h>

#endif

#include <elx/core/TaskScheduler.h>
#include <elx/core/CoreErrorIds.h>

namespace eLynx {

const size_t TaskScheduler::_nCPU = TaskScheduler::GetCPUCount();

//----------------------------------------------------------------------------
//  TaskSchedulerBase::GetCPUCount.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
uint32 TaskScheduler::GetCPUCount()
{
  return boost::thread::hardware_concurrency();

} // GetCPUCount


//----------------------------------------------------------------------------
//  TaskScheduler::TaskScheduler.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
TaskScheduler::TaskScheduler() : 
  _tasks(), 
  _CPU()
{
  _tasks.reserve(TaskScheduler::_nCPU);

} // constructor

//----------------------------------------------------------------------------
//  TaskScheduler::AddTask.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : F iTask to execute.
//----------------------------------------------------------------------------
void TaskScheduler::AddTask(TaskScheduler::Task iTask)
{
  _tasks.push_back(CoreTask(TaskScheduler::Task(iTask), _CPU));
  
  // Wrap around if number of tasks is greater then number of CPUs
  if (++_CPU == TaskScheduler::_nCPU)
    _CPU = 0;

} // AddTask

//----------------------------------------------------------------------------
//  TaskScheduler::Run.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
uint32 TaskScheduler::Run()
{
  // single or multi core machine
  return (TaskScheduler::_nCPU == 1 || _tasks.size() == 1) ? 
    RunSingleCore() : RunMultiCore();

} // Run

//----------------------------------------------------------------------------
//  TaskScheduler::RunSingleCore.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
uint32 TaskScheduler::RunSingleCore()
{
  // No need to create threads
  const size_t count = _tasks.size();
  uint32 status = elxOK;
  for (size_t i=0; i<count; ++i)
    if (elxOK != (status = _tasks[i]._task()))
      return status;

  return elxOK;

} // RunSingleCore 

//----------------------------------------------------------------------------
//  TaskScheduler::RunMultiCore.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
uint32 TaskScheduler::RunMultiCore()
{
  // Create thread per each task and execute them
  boost::thread_group tg;
  const size_t count = _tasks.size() - 1;
  if (count < 0)
    return elxOK;

  size_t i;
  for (i=0; i<count; ++i)
    // need to pass task by reference to collect the status back
    tg.create_thread( boost::ref(_tasks[i]) );

  // run the last task in the current thread
  _tasks[count]();
  
  // wait to finish
  tg.join_all();

  for(i=0; i< count; ++i)
    if (elxOK != _tasks[i]._status)
      return _tasks[i]._status;

  return elxOK;

} // RunMultiCore 


//----------------------------------------------------------------------------
//  TaskScheduler::CoreTask::CoreTask.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : F iTask to execute.
//        size_t iCPU CPU to assign this task to
//----------------------------------------------------------------------------
TaskScheduler::CoreTask::CoreTask(
    TaskScheduler::Task iTask, 
    size_t iCPU) :
  _task(iTask), 
  _CPU(iCPU), 
  _status(elxOK)
{} // CoreTask::CoreTask 


//----------------------------------------------------------------------------
//  TaskScheduler::CoreTask::operator()().
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : F iTask to execute.
//        uint32 iCPU CPU to assign this task to
//----------------------------------------------------------------------------
uint32 TaskScheduler::CoreTask::operator()()
{
  // Copy all member variables to give compiler a hint to keep them in registers
  Task task(_task);
  
#ifdef elxWINDOWS

  // nothing

#elif defined elxLINUX

  // Set CPU affinity
  size_t cpu = _CPU; 
  cpu_set_t mask;
  CPU_ZERO(&mask); 	
  CPU_SET(cpu, &mask);  
  sched_setaffinity(0, sizeof(mask), &mask);

#else

  elxFIXME;

#endif

  // Do the actual job
  return _status = task();
  
} // operator()()


} // namespace eLynx

#else // elxUSE_THREAD

#include <elx/core/TaskScheduler.h>

namespace eLynx {

//----------------------------------------------------------------------------
//  TaskSchedulerBase::GetCPUCount.
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
uint32 TaskScheduler::GetCPUCount()
{
  return 1;

} // GetCPUCount

} // namespace eLynx

#endif // elxUSE_THREAD

#include <elx/core/CoreTask.h>
#include <elx/core/ParallelAlgorithms.h>

namespace eLynx {

//============================================================================
// IterationRange::IterationRange
//============================================================================
IterationRange::IterationRange(
    size_t iBegin, size_t iEnd,  
    size_t iGrainSize, 
    size_t iMinSize,
    ESubRangePosition iPosition) :
  _begin(iBegin), 
  _end(iEnd), 
  _grainSize(iGrainSize), 
  _minSize(iMinSize),
  _position(iPosition)
{}

//============================================================================
// IterationRangeTask::IterationRangeTask
//============================================================================
IterationRangeTask::IterationRangeTask(ProgressNotifier& iNotifier) :
  _begin(0), 
  _end(0), 
  _position(SRP_NONE), 
  _notifier(iNotifier)
{}
  
//============================================================================
// IterationRangeTask::IterationRangeTask
//============================================================================
IterationRangeTask::IterationRangeTask(
    const IterationRange& iRange, 
    ProgressNotifier& iNotifier) :
  _begin(iRange._begin), 
  _end(iRange._end), 
  _position(iRange._position),
  _notifier( (iRange.IsLast() || iRange.IsAll()) ?
      iNotifier : ProgressNotifier_NULL)
{}

} // namespace eLynx
