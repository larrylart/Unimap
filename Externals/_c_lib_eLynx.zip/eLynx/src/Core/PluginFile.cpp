//============================================================================
//  PluginFile.cpp                                      Core.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <stdio.h>
#include <string.h>

// eLynx.Core
#include <elx/core/CoreOS.h>
#include <elx/core/CoreTrace.h>
#include <elx/core/PluginFile.h>
#include <elx/core/IPluginPackage.h>

namespace eLynx {

  //----------------------------------------------------------------------------
PluginFile::PluginFile() :
    _prPackage(NULL),
    _moduleId(0)
{
  _filename[0] = '\0';
}

//----------------------------------------------------------------------------
PluginFile::PluginFile(const char * iprFilename) :
    _prPackage(NULL),
    _moduleId(0)
{
  _filename[0] = '\0';
  if (NULL == iprFilename)
    return;
  Load(iprFilename);
}

//----------------------------------------------------------------------------
PluginFile::~PluginFile()
{
  Unload();
}

//----------------------------------------------------------------------------
bool PluginFile::IsValid() const
{
  return (NULL != _prPackage);
}

//----------------------------------------------------------------------------
const IPluginPackage * PluginFile::GetPackage() const
{
  return _prPackage;
}

//----------------------------------------------------------------------------
const char * PluginFile::GetFilename() const
{
  return _filename;
}

//----------------------------------------------------------------------------
//  Load
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : const char * iprFilename
//  Out : bool : true if succeeded loading file
//----------------------------------------------------------------------------
bool PluginFile::Load(const char * iprFilename)
{
  // if already load
  Unload();

  // load library from filename
  bool bSuccess = elxLoadModule(iprFilename, _moduleId);
  if (!bSuccess) 
  {
    elxTRACE_ERROR(CORE_L,
      ("PluginFile::Load(%s), module not found.\n", iprFilename));
    return false;
  }
    elxTRACE_PROD(CORE_L,
      ("PluginFile::Load(%s), module loaded.\n", iprFilename));

  // get fnPluginPackage from library
  elxGetPluginPackage pfnGetPackage = (elxGetPluginPackage)elxResolveSymbol(_moduleId, EXPORT_PLUGIN_PACKAGE);
  bSuccess = (NULL != pfnGetPackage);
  if (bSuccess)
  {
    elxTRACE_PROD(CORE_L,
      ("PluginFile::Load(%s), symbol %s found.\n", iprFilename, EXPORT_PLUGIN_PACKAGE));
    _prPackage = pfnGetPackage();
    bSuccess = (NULL != _prPackage);
  }
  else
  {
    elxTRACE_ERROR(CORE_L,
      ("PluginFile::Load(%s), symbol %s not found.\n", iprFilename, EXPORT_PLUGIN_PACKAGE));
  }

  if (!bSuccess)
  {
    elxTRACE_ERROR(CORE_L,
      ("PluginFile::Load(%s), failed to get package.\n", iprFilename));
    elxUnloadModule(_moduleId);
    _prPackage = NULL;
    return false;
  }
  else
  {
    char id[39];
    _prPackage->GetID().GetString(id);
    elxTRACE_PROD(CORE_L,
      ("PluginFile::Load(%s), package UUID is %s.\n", iprFilename, id));
  }

  // set filename
  ::strcpy(_filename, iprFilename);
  return true;

} // Load


//----------------------------------------------------------------------------
//  Unload : To be call when plugin is no longer needed/used
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
//  In  : -
//  Out : -
//----------------------------------------------------------------------------
void PluginFile::Unload()
{
  if (!IsValid()) 
    return;

  _prPackage = NULL;
  elxUnloadModule(_moduleId);
  _filename[0] = '\0';

} // Unload

} // namespace eLynx
