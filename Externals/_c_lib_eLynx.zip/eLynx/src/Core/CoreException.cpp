//============================================================================
//  CoreException.cpp                                   Core.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include "elx/core/CoreOS.h"
#include "elx/core/CoreException.h"

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

namespace eLynx {
	
//----------------------------------------------------------------------------
//  elxThrowException: Throws an exception
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : uint32 iId           : the error id
//        const char * iFile : name of the file where error appeared
//        int32 iLine          : number of the line where error appeared
//        const char * iMsg  : the error message
//----------------------------------------------------------------------------	
void elxThrowException(
    uint32 iId, 
    const char * iFile, 
    int32 iLine, 
    const char * iMsg)
{
  // prepare the exception object
  elxException to_throw;
  to_throw._id = iId;

  // format the '_where' string from file and line
  elxSNPrintf(to_throw._where, elxExWhereLength, 
	  "in file %s, line %i", iFile, iLine);
  	
  // copy a message into the exception
  strncpy(to_throw._what, iMsg, elxExWhatLength);

  // throw an exception
  throw to_throw;

} // elxThrowException


//----------------------------------------------------------------------------
//  elxMsgFormat: Formats an error message
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : const char * iFormatStr : format string in the printf style
//        ...                     : message parameters
//  Out : the formatted string
//----------------------------------------------------------------------------	
const char * elxMsgFormat(const char *iFormatStr, ...)
{
  // static buffer to hold formatted message
  static char message[elxExWhatLength+1];

  // parse argument list
  va_list arg_ptr; 
  va_start(arg_ptr, iFormatStr);

  // format the message
  elxVSNPrintf(message, elxExWhatLength, iFormatStr, arg_ptr);

  // return the message
  return message;

} // elxMsgFormat
	
} // eLynx
