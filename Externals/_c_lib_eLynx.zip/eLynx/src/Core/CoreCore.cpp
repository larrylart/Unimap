//============================================================================
//  CoreCore.cpp                                        Core.Component package
//============================================================================
//  Does nothing, just for building something
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <string.h>
#include <string>
#include <map>

#include <elx/core/CoreCore.h>
#include <elx/core/CoreMacros.h>
#include <elx/core/UUID.h>

namespace eLynx {

//----------------------------------------------------------------------------
const uint8  ResolutionTypeTraits<uint8>::_min = uint8MIN;
const uint8  ResolutionTypeTraits<uint8>::_max = uint8MAX;
const uint8  ResolutionTypeTraits<uint8>::_norm = uint8MAX;
const double ResolutionTypeTraits<uint8>::_minInDouble = double(uint8MIN);
const double ResolutionTypeTraits<uint8>::_maxInDouble = double(uint8MAX);
const double ResolutionTypeTraits<uint8>::_maxNormInDouble = double(uint8MAX);
const float  ResolutionTypeTraits<uint8>::_minInFloat = float(uint8MIN);
const float  ResolutionTypeTraits<uint8>::_maxInFloat = float(uint8MAX);
const double ResolutionTypeTraits<uint8>::_normScale = 1.0/_maxInDouble;
const ResolutionTypeTraits<uint8>::SumOverflow_type ResolutionTypeTraits<uint8>::_minS = SumOverflow_type(_min);
const ResolutionTypeTraits<uint8>::SumOverflow_type ResolutionTypeTraits<uint8>::_maxS = SumOverflow_type(_max);
const ResolutionTypeTraits<uint8>::MulOverflow_type ResolutionTypeTraits<uint8>::_minM = MulOverflow_type(_min);
const ResolutionTypeTraits<uint8>::MulOverflow_type ResolutionTypeTraits<uint8>::_maxM = MulOverflow_type(_max);
const ResolutionTypeTraits<uint8>::BigOverflow_type ResolutionTypeTraits<uint8>::_minB = BigOverflow_type(_min);
const ResolutionTypeTraits<uint8>::BigOverflow_type ResolutionTypeTraits<uint8>::_maxB = BigOverflow_type(_max);
const ResolutionTypeTraits<uint8>::Floating_type    ResolutionTypeTraits<uint8>::_minF = Floating_type(_min);
const ResolutionTypeTraits<uint8>::Floating_type    ResolutionTypeTraits<uint8>::_maxF = Floating_type(_max);

//----------------------------------------------------------------------------
const uint16 ResolutionTypeTraits<uint16>::_min = uint16MIN;
const uint16 ResolutionTypeTraits<uint16>::_max = uint16MAX;
const uint16 ResolutionTypeTraits<uint16>::_norm = uint16MAX;
const double ResolutionTypeTraits<uint16>::_minInDouble = double(uint16MIN);
const double ResolutionTypeTraits<uint16>::_maxInDouble = double(uint16MAX);
const double ResolutionTypeTraits<uint16>::_maxNormInDouble = double(uint16MAX);
const float  ResolutionTypeTraits<uint16>::_minInFloat = float(uint16MIN);
const float  ResolutionTypeTraits<uint16>::_maxInFloat = float(uint16MAX);
const double ResolutionTypeTraits<uint16>::_normScale = 1.0/_maxInDouble;
const ResolutionTypeTraits<uint16>::SumOverflow_type ResolutionTypeTraits<uint16>::_minS = SumOverflow_type(_min);
const ResolutionTypeTraits<uint16>::SumOverflow_type ResolutionTypeTraits<uint16>::_maxS = SumOverflow_type(_max);
const ResolutionTypeTraits<uint16>::MulOverflow_type ResolutionTypeTraits<uint16>::_minM = MulOverflow_type(_min);
const ResolutionTypeTraits<uint16>::MulOverflow_type ResolutionTypeTraits<uint16>::_maxM = MulOverflow_type(_max);
const ResolutionTypeTraits<uint16>::BigOverflow_type ResolutionTypeTraits<uint16>::_minB = BigOverflow_type(_min);
const ResolutionTypeTraits<uint16>::BigOverflow_type ResolutionTypeTraits<uint16>::_maxB = BigOverflow_type(_max);
const ResolutionTypeTraits<uint16>::Floating_type    ResolutionTypeTraits<uint16>::_minF = Floating_type(_min);
const ResolutionTypeTraits<uint16>::Floating_type    ResolutionTypeTraits<uint16>::_maxF = Floating_type(_max);

//----------------------------------------------------------------------------
const int32  ResolutionTypeTraits<int32>::_min = int32MIN;
const int32  ResolutionTypeTraits<int32>::_max = int32MAX;
const int32  ResolutionTypeTraits<int32>::_norm = int32MAX;
const double ResolutionTypeTraits<int32>::_minInDouble = double(int32MIN);
const double ResolutionTypeTraits<int32>::_maxInDouble = double(int32MAX);
const double ResolutionTypeTraits<int32>::_maxNormInDouble = double(int32MAX);
const double ResolutionTypeTraits<int32>::_normScale = 1.0/double(0x80000000);
const ResolutionTypeTraits<int32>::SumOverflow_type ResolutionTypeTraits<int32>::_minS = SumOverflow_type(_min);
const ResolutionTypeTraits<int32>::SumOverflow_type ResolutionTypeTraits<int32>::_maxS = SumOverflow_type(_max);
const ResolutionTypeTraits<int32>::MulOverflow_type ResolutionTypeTraits<int32>::_minM = MulOverflow_type(_min);
const ResolutionTypeTraits<int32>::MulOverflow_type ResolutionTypeTraits<int32>::_maxM = MulOverflow_type(_max);
const ResolutionTypeTraits<int32>::BigOverflow_type ResolutionTypeTraits<int32>::_minB = BigOverflow_type(_min);
const ResolutionTypeTraits<int32>::BigOverflow_type ResolutionTypeTraits<int32>::_maxB = BigOverflow_type(_max);
const ResolutionTypeTraits<int32>::Floating_type    ResolutionTypeTraits<int32>::_minF = Floating_type(_min);
const ResolutionTypeTraits<int32>::Floating_type    ResolutionTypeTraits<int32>::_maxF = Floating_type(_max);

//----------------------------------------------------------------------------
const uint32 ResolutionTypeTraits<uint32>::_min = uint32MIN;
const uint32 ResolutionTypeTraits<uint32>::_max = uint32MAX;
const uint32 ResolutionTypeTraits<uint32>::_norm = uint32MAX;
const double ResolutionTypeTraits<uint32>::_minInDouble = double(uint32MIN);
const double ResolutionTypeTraits<uint32>::_maxInDouble = double(uint32MAX);
const double ResolutionTypeTraits<uint32>::_maxNormInDouble = double(uint32MAX);
const double ResolutionTypeTraits<uint32>::_normScale = 1.0/double(0x80000000);
const ResolutionTypeTraits<uint32>::SumOverflow_type ResolutionTypeTraits<uint32>::_minS = SumOverflow_type(_min);
const ResolutionTypeTraits<uint32>::SumOverflow_type ResolutionTypeTraits<uint32>::_maxS = SumOverflow_type(_max);
const ResolutionTypeTraits<uint32>::MulOverflow_type ResolutionTypeTraits<uint32>::_minM = MulOverflow_type(_min);
const ResolutionTypeTraits<uint32>::MulOverflow_type ResolutionTypeTraits<uint32>::_maxM = MulOverflow_type(_max);
const ResolutionTypeTraits<uint32>::BigOverflow_type ResolutionTypeTraits<uint32>::_minB = BigOverflow_type(_min);
const ResolutionTypeTraits<uint32>::BigOverflow_type ResolutionTypeTraits<uint32>::_maxB = BigOverflow_type(_max);
const ResolutionTypeTraits<uint32>::Floating_type    ResolutionTypeTraits<uint32>::_minF = Floating_type(_min);
const ResolutionTypeTraits<uint32>::Floating_type    ResolutionTypeTraits<uint32>::_maxF = Floating_type(_max);

//----------------------------------------------------------------------------
const float  ResolutionTypeTraits<float>::_min = floatMIN;
const float  ResolutionTypeTraits<float>::_max = floatMAX;
const float  ResolutionTypeTraits<float>::_norm = 1.0f;
const double ResolutionTypeTraits<float>::_minInDouble = double(floatMIN);
const double ResolutionTypeTraits<float>::_maxInDouble = double(floatMAX);
const double ResolutionTypeTraits<float>::_maxNormInDouble = double(1.0);
const double ResolutionTypeTraits<float>::_normScale = 1.0;
const ResolutionTypeTraits<float>::SumOverflow_type ResolutionTypeTraits<float>::_minS = SumOverflow_type(_min);
const ResolutionTypeTraits<float>::SumOverflow_type ResolutionTypeTraits<float>::_maxS = SumOverflow_type(_max);
const ResolutionTypeTraits<float>::MulOverflow_type ResolutionTypeTraits<float>::_minM = MulOverflow_type(_min);
const ResolutionTypeTraits<float>::MulOverflow_type ResolutionTypeTraits<float>::_maxM = MulOverflow_type(_max);
const ResolutionTypeTraits<float>::BigOverflow_type ResolutionTypeTraits<float>::_minB = BigOverflow_type(_min);
const ResolutionTypeTraits<float>::BigOverflow_type ResolutionTypeTraits<float>::_maxB = BigOverflow_type(_max);
const ResolutionTypeTraits<float>::Floating_type    ResolutionTypeTraits<float>::_minF = Floating_type(_min);
const ResolutionTypeTraits<float>::Floating_type    ResolutionTypeTraits<float>::_maxF = Floating_type(_max);

//----------------------------------------------------------------------------
const int64  ResolutionTypeTraits<int64>::_min = int64MIN;
const int64  ResolutionTypeTraits<int64>::_max = int64MAX;
const int64  ResolutionTypeTraits<int64>::_norm = int64MAX;
const double ResolutionTypeTraits<int64>::_minInDouble = double(int64MIN);
const double ResolutionTypeTraits<int64>::_maxInDouble = double(int64MAX);
const double ResolutionTypeTraits<int64>::_maxNormInDouble = double(int64MAX);
const double ResolutionTypeTraits<int64>::_normScale = 1.0/double(int64MAX);
const ResolutionTypeTraits<int64>::SumOverflow_type ResolutionTypeTraits<int64>::_minS = SumOverflow_type(_min);
const ResolutionTypeTraits<int64>::SumOverflow_type ResolutionTypeTraits<int64>::_maxS = SumOverflow_type(_max);
const ResolutionTypeTraits<int64>::MulOverflow_type ResolutionTypeTraits<int64>::_minM = MulOverflow_type(_min);
const ResolutionTypeTraits<int64>::MulOverflow_type ResolutionTypeTraits<int64>::_maxM = MulOverflow_type(_max);
const ResolutionTypeTraits<int64>::BigOverflow_type ResolutionTypeTraits<int64>::_minB = BigOverflow_type(_min);
const ResolutionTypeTraits<int64>::BigOverflow_type ResolutionTypeTraits<int64>::_maxB = BigOverflow_type(_max);
const ResolutionTypeTraits<int64>::Floating_type    ResolutionTypeTraits<int64>::_minF = Floating_type(_min);
const ResolutionTypeTraits<int64>::Floating_type    ResolutionTypeTraits<int64>::_maxF = Floating_type(_max);

//----------------------------------------------------------------------------
const double ResolutionTypeTraits<double>::_min = doubleMIN;
const double ResolutionTypeTraits<double>::_max = doubleMAX;
const double ResolutionTypeTraits<double>::_norm = 1.0;
const double ResolutionTypeTraits<double>::_minInDouble = doubleMIN;
const double ResolutionTypeTraits<double>::_maxInDouble = doubleMIN;
const double ResolutionTypeTraits<double>::_maxNormInDouble = 1.0;
const double ResolutionTypeTraits<double>::_normScale = 1.0;
const ResolutionTypeTraits<double>::SumOverflow_type ResolutionTypeTraits<double>::_minS = SumOverflow_type(_min);
const ResolutionTypeTraits<double>::SumOverflow_type ResolutionTypeTraits<double>::_maxS = SumOverflow_type(_max);
const ResolutionTypeTraits<double>::MulOverflow_type ResolutionTypeTraits<double>::_minM = MulOverflow_type(_min);
const ResolutionTypeTraits<double>::MulOverflow_type ResolutionTypeTraits<double>::_maxM = MulOverflow_type(_max);
const ResolutionTypeTraits<double>::BigOverflow_type ResolutionTypeTraits<double>::_minB = BigOverflow_type(_min);
const ResolutionTypeTraits<double>::BigOverflow_type ResolutionTypeTraits<double>::_maxB = BigOverflow_type(_max);
const ResolutionTypeTraits<double>::Floating_type    ResolutionTypeTraits<double>::_minF = Floating_type(_min);
const ResolutionTypeTraits<double>::Floating_type    ResolutionTypeTraits<double>::_maxF = Floating_type(_max);


//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EResolution iResolution)
{
  static const char * ms_lut[RT_Undefined+1] =
  {
    "int8",    "uint8",
    "int16",   "uint16",
    "int32",   "uint32",
    "int64",   "uint64",
    "float32", "float64",
    "undefined"
  };
  return ms_lut[iResolution];

} // elxToString


//----------------------------------------------------------------------------
//  elxToEResolution
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EResolution elxToEResolution(const char * iprType)
{
  static std::map<std::string, EResolution> ms_lut;
  if (ms_lut.empty())
  {
    ms_lut.insert(make_pair(std::string("RT_INT8"),RT_INT8));
    ms_lut.insert(make_pair(std::string("RT_UINT8"),RT_UINT8));
    ms_lut.insert(make_pair(std::string("RT_INT16"),RT_INT16));
    ms_lut.insert(make_pair(std::string("RT_UINT16"),RT_UINT16));
    ms_lut.insert(make_pair(std::string("RT_INT32"),RT_INT32));
    ms_lut.insert(make_pair(std::string("RT_UINT32"),RT_UINT32));
    ms_lut.insert(make_pair(std::string("RT_INT64"),RT_INT64));
    ms_lut.insert(make_pair(std::string("RT_UINT64"),RT_UINT64));
    ms_lut.insert(make_pair(std::string("RT_Float"),RT_Float));
    ms_lut.insert(make_pair(std::string("RT_Double"),RT_Double));
    ms_lut.insert(make_pair(std::string("RT_Undefined"),RT_Undefined));
  }
  std::map<std::string, EResolution>::iterator it = 
    ms_lut.find(std::string(iprType));
  return it == ms_lut.end() ? RT_Undefined: it->second;

} // elxToEResolution


//----------------------------------------------------------------------------
//  elxToEResolution
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EResolution elxGetFloatingType(EResolution iResolution)
{
  static EResolution ms_lut[RT_Undefined+1] =
  {
    RT_Float,  RT_Float,  // int8, uint8
    RT_Float,  RT_Float,  // int16, uint16
    RT_Double, RT_Double, // int32, uint32
    RT_Double, RT_Double, // int64, uint64
    RT_Double, RT_Double, // float, double
    RT_Undefined
  };
  return ms_lut[iResolution];

} // elxGetFloatingType


//----------------------------------------------------------------------------
//  elxGetBits
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
uint32 elxGetBits(EResolution iResolution)
{
  static uint32 ms_lut[RT_Undefined+1] = { 8,8, 16,16, 32,32, 64,64, 32,64, 0 };
  return ms_lut[iResolution];
}

static char ms_toLower[256] =
{
  0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
  0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f,
  0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f,
  0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f,
  0x40, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f,
  0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x5b, 0x5c, 0x5d, 0x5e, 0x5f,
  0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f,
  0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x7b, 0x7c, 0x7d, 0x7e, 0x7f,

  0x80U, 0x81U, 0x82U, 0x83U, 0x84U, 0x85U, 0x86U, 0x87U, 0x88U, 0x89U, 0x8aU, 0x8bU, 0x8cU, 0x8dU, 0x8eU, 0x8fU,
  0x90U, 0x91U, 0x92U, 0x93U, 0x94U, 0x95U, 0x96U, 0x97U, 0x98U, 0x99U, 0x9aU, 0x9bU, 0x9cU, 0x9dU, 0x9eU, 0x9fU,
  0xa0U, 0xa1U, 0xa2U, 0xa3U, 0xa4U, 0xa5U, 0xa6U, 0xa7U, 0xa8U, 0xa9U, 0xaaU, 0xabU, 0xacU, 0xadU, 0xaeU, 0xafU,
  0xb0U, 0xb1U, 0xb2U, 0xb3U, 0xb4U, 0xb5U, 0xb6U, 0xb7U, 0xb8U, 0xb9U, 0xbaU, 0xbbU, 0xbcU, 0xbdU, 0xbeU, 0xbfU,
  0xc0U, 0xc1U, 0xc2U, 0xc3U, 0xc4U, 0xc5U, 0xc6U, 0xc7U, 0xc8U, 0xc9U, 0xcaU, 0xcbU, 0xccU, 0xcdU, 0xceU, 0xcfU,
  0xd0U, 0xd1U, 0xd2U, 0xd3U, 0xd4U, 0xd5U, 0xd6U, 0xd7U, 0xd8U, 0xd9U, 0xdaU, 0xdbU, 0xdcU, 0xddU, 0xdeU, 0xdfU,
  0xe0U, 0xe1U, 0xe2U, 0xe3U, 0xe4U, 0xe5U, 0xe6U, 0xe7U, 0xe8U, 0xe9U, 0xeaU, 0xebU, 0xecU, 0xedU, 0xeeU, 0xefU,
  0xf0U, 0xf1U, 0xf2U, 0xf3U, 0xf4U, 0xf5U, 0xf6U, 0xf7U, 0xf8U, 0xf9U, 0xfaU, 0xfbU, 0xfcU, 0xfdU, 0xfeU, 0xffU
};

static char ms_toUpper[256] =
{
  0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
  0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f,
  0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f,
  0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f,
  0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f,
  0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x5e, 0x5f,
  0x60, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f,
  0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x7b, 0x7c, 0x7d, 0x7e, 0x7f,
  0x80U, 0x81U, 0x82U, 0x83U, 0x84U, 0x85U, 0x86U, 0x87U, 0x88U, 0x89U, 0x8aU, 0x8bU, 0x8cU, 0x8dU, 0x8eU, 0x8fU,
  0x90U, 0x91U, 0x92U, 0x93U, 0x94U, 0x95U, 0x96U, 0x97U, 0x98U, 0x99U, 0x9aU, 0x9bU, 0x9cU, 0x9dU, 0x9eU, 0x9fU,
  0xa0U, 0xa1U, 0xa2U, 0xa3U, 0xa4U, 0xa5U, 0xa6U, 0xa7U, 0xa8U, 0xa9U, 0xaaU, 0xabU, 0xacU, 0xadU, 0xaeU, 0xafU,
  0xb0U, 0xb1U, 0xb2U, 0xb3U, 0xb4U, 0xb5U, 0xb6U, 0xb7U, 0xb8U, 0xb9U, 0xbaU, 0xbbU, 0xbcU, 0xbdU, 0xbeU, 0xbfU,
  0xc0U, 0xc1U, 0xc2U, 0xc3U, 0xc4U, 0xc5U, 0xc6U, 0xc7U, 0xc8U, 0xc9U, 0xcaU, 0xcbU, 0xccU, 0xcdU, 0xceU, 0xcfU,
  0xd0U, 0xd1U, 0xd2U, 0xd3U, 0xd4U, 0xd5U, 0xd6U, 0xd7U, 0xd8U, 0xd9U, 0xdaU, 0xdbU, 0xdcU, 0xddU, 0xdeU, 0xdfU,
  0xe0U, 0xe1U, 0xe2U, 0xe3U, 0xe4U, 0xe5U, 0xe6U, 0xe7U, 0xe8U, 0xe9U, 0xeaU, 0xebU, 0xecU, 0xedU, 0xeeU, 0xefU,
  0xf0U, 0xf1U, 0xf2U, 0xf3U, 0xf4U, 0xf5U, 0xf6U, 0xf7U, 0xf8U, 0xf9U, 0xfaU, 0xfbU, 0xfcU, 0xfdU, 0xfeU, 0xffU
};

//----------------------------------------------------------------------------
char elxToLower(char iChar)
{
  return ms_toLower[(int32)iChar];

} // elxToLower

//----------------------------------------------------------------------------
char elxToUpper(char iChar)
{
  return ms_toUpper[(int32)iChar];

} // elxToUpper

//----------------------------------------------------------------------------
void elxToLower(char * ioprString)
{
  if (NULL == ioprString) return;
  do { *ioprString = ms_toLower[(int32)(*ioprString)]; } while (0 != *ioprString++);

} // elxToLower

//----------------------------------------------------------------------------
void elxToUpper(char * ioprString)
{
  if (NULL == ioprString) return;
  do { *ioprString = ms_toUpper[(int32)(*ioprString)]; } while (0 != *ioprString++);

} // elxToUpper


//----------------------------------------------------------------------------
void elxZeroMemory(void * iprBuffer, uint32 iSize)
{
  elxASSERT(NULL != iprBuffer);
  ::memset(iprBuffer, 0x00, iSize);
}

} // namespace eLynx


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//  what is missing in window <sdtlib> # NOT in eLynx namespace!
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

#ifdef elxWINDOWS

  //----------------------------------------------------------------------------
  float strtof(const char * p, char ** pend)
  //----------------------------------------------------------------------------
  { 
    return float(::strtod(p, pend)); 

  } // strtof

  //----------------------------------------------------------------------------
  int64 strtoll(const char * p, char ** pend, int base) 
  //----------------------------------------------------------------------------
  { 
    int64 number = 0; 
    int positive,c; 
    int error; 
    const char *pstart; 
    int anytrans = 0; 

    pstart = p; 

    while (isspace(*p))  // skip leading white space 
      p++; 

    switch (*p) 
    {   
    case '-': 
      positive = 0; 
      p++; 
      break; 
    case '+': 
      p++; 
      // FALL-THROUGH 
    default: 
      positive = 1; 
      break; 
    } 
    switch (base) 
    {   
    case 0: 
      base = 10;  // assume decimal base 
      if (*p == '0') 
      {   
        base = 8; // could be octal 
        p++; 
        anytrans++; // count 0 as a translated char 
        switch (*p) 
        {   
        case 'x': 
        case 'X': 
          base = 16; // hex 
          p++; 
          anytrans--; // oops, the previous 0 was part of a 0x, now look for valid chars 
          break; 
  #if BINARY 
        case 'b': 
        case 'B': 
          base = 2; // binary 
          p++; 
          anytrans--; 
      break; 
  #endif 
      } 
    } 
    break; 
    case 16:   // skip over '0x' and '0X' 
      if (*p == '0' && (p[1] == 'x' || p[1] == 'X')) 
        p += 2; 
      break; 
  #if BINARY 
    case 2:   // skip over '0b' and '0B' 
      if (*p == '0' && (p[1] == 'b' || p[1] == 'B')) 
        p += 2; 
      break; 
  #endif 
    } 
    error = 0; 
    while (1) 
    {  
      c = *p; 
      if (c >= '0' && c <= '9')       c -= '0'; 
      else if (c >= 'a' && c <= 'z')  c = c - ('a' - 10); 
      else if (c >= 'A' && c <= 'Z')  c = c - ('A' - 10); 
      else 
      {   
        // unrecognized character 
        // Go back to beginning of string if nothing 
        // was dealt with properly 
        if (anytrans == 0) 
          p = pstart; 
        break; 
      } 
      if (c >= base)  // not in number base 
      { 
        // Go back to beginning of string if no characters 
        // were successfully dealt with 
        if (anytrans == 0) 
          p = pstart; 
        break; 
      } 
      if ((LLONG_MIN + c) / base > number) 
        error = 1; 
      number = number * base - c; 
      p++; 
      anytrans++; 
    } 
    if (pend) 
      *pend = (char *) p; 
    if (positive && number == LLONG_MIN || error) 
    { 
      /*  a range error has occurred, set errno and return 
      LLONG_MAX or LLONG_MIN dependant upon positive. 
      I.e. errange on a negative, means it was under 
      LLONG_MIN, on a positive, was above LLONG_MAX 
      */ 
      number = (positive) ? LLONG_MAX : LLONG_MIN; 
      //__set_errno (ERANGE); 
      return number; 
    } 
    return (positive) ? -number : number; 

  } // strtoll


  //----------------------------------------------------------------------------
  int strcasecmp(const char * s1, const char * s2)
  //----------------------------------------------------------------------------
  {
    if (!s1 && !s2) return 0;
    if (!s1) return 1;
    if (!s2) return -1;
    while (
      *s1 && 
      *s2 &&
      tolower((unsigned char)*s1) == tolower((unsigned char)*s2))
    {
      s1++;
      s2++;
    }
    return tolower((unsigned char)*s1) - tolower((unsigned char)*s2);

  } // strcasecmp

  //----------------------------------------------------------------------------
  int strncasecmp(const char * s1, const char * s2, size_t n)
  //----------------------------------------------------------------------------
  {
    if (!s1 && !s2) return 0;
    if (!s1) return 1;
    if (!s2) return -1;
    if (n < 0) return 0;
    while (n &&
      *s1 && 
      *s2 &&
      tolower((unsigned char)*s1) == tolower((unsigned char)*s2))
    {
      s1++;
      s2++;
      n--;
    }
   
    return n == 0 ? 0 : tolower((unsigned char)*s1) - tolower((unsigned char)*s2);

  } // strncasecmp

#endif //elxWINDOWS
