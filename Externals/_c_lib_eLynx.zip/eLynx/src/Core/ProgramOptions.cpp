//============================================================================
//  ProgramOptions.cpp                                  Core.Component package
//============================================================================
//  Copyright (C) 2009 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <iostream>
#include <boost/program_options.hpp>

#include <elx/core/ProgramOptions.h>
#include <elx/core/CoreErrorIds.h>

namespace eLynx {
	
//----------------------------------------------------------------------------
//  elxGetOptions: Parse input arguments
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : int32 iArgc           : number of the input arguments
//        char** iArgv        : array of input arguments
//        Option* ioOptions   : array of the allowed options
//        uint32 iSize          : number of the allowed options
//----------------------------------------------------------------------------	
uint32 elxGetOptions(
    int32 iArgc, 
    char ** iArgv, 
    ProgramOption * ioOptions,
    uint32 iSize)
{
  namespace po = boost::program_options;
  
  po::options_description desc("Allowed options");
  for (uint32 i=0; i<iSize; ++i)
  {
    if (ioOptions[i]._Flag == OA_NO_ARG)
      desc.add_options()(
        ioOptions[i]._Name.c_str(), 
        ioOptions[i]._Desc.c_str());
    else
      desc.add_options()(
        ioOptions[i]._Name.c_str(), 
        po::value<std::string>(), 
        ioOptions[i]._Desc.c_str());
  }

  try
  {
    po::variables_map vm;
    po::store(po::parse_command_line(iArgc, iArgv, desc), vm);
    po::notify(vm);

    for (uint32 i = 0; i < iSize; ++i)
    {
      if (vm.count(ioOptions[i]._Name.c_str()))
      {
        ioOptions[i]._IsSet = true;
        if (ioOptions[i]._Flag != OA_NO_ARG)
          ioOptions[i]._Value = vm[ioOptions[i]._Name.c_str()].as<std::string>();
      }
    }
  }
  catch(...)
  {
    std::cout << "Invalid command option.\n";
    std::cout << desc << '\n';
    return elxErrInvalidParams;  
  }
  return elxOK;

} // elxGetOptions
	
} // eLynx
