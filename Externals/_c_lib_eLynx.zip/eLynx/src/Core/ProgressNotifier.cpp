//============================================================================
//  ProgressNotifier.cpp                                Core.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include "elx/core/ProgressNotifier.h"
#include "elx/core/CoreException.h"

#include <math.h>

namespace eLynx {
	
ProgressNotifier ProgressNotifier_NULL;

//----------------------------------------------------------------------------
// constructor, creates progress notifier
//----------------------------------------------------------------------------
ProgressNotifier::ProgressNotifier(uint32 iPhases, float iSensitivity)
{
  _nPhases = iPhases;
  _currentPhase = 0;
  _currentProgress = 0.0f;
  _lastNotifiedProgress = 1.0f;
  _sensitivity = iSensitivity;
  _bCanceled = false;
}

//----------------------------------------------------------------------------
// destructor
//----------------------------------------------------------------------------
ProgressNotifier::~ProgressNotifier() 
{
}

//----------------------------------------------------------------------------
// returns the number of phases
//----------------------------------------------------------------------------
uint32 ProgressNotifier::GetPhaseCount() const
{
  return _nPhases;
}


//----------------------------------------------------------------------------
// returns progress sensitivity
//----------------------------------------------------------------------------
float ProgressNotifier::GetSensitivity() const
{
  return _sensitivity;
}
	

//----------------------------------------------------------------------------
// SetSensitivity: sets progress sensitivity
//----------------------------------------------------------------------------
void ProgressNotifier::SetSensitivity(float iSensitivity)
{
  _sensitivity = iSensitivity;
}

//----------------------------------------------------------------------------
// GetCurrentProgress: returns current progress
//----------------------------------------------------------------------------
float ProgressNotifier::GetCurrentProgress() const
{
  return _currentProgress;
}

//----------------------------------------------------------------------------
// GetCurrentPhase: returns the current phase
//----------------------------------------------------------------------------
uint32 ProgressNotifier::GetCurrentPhase() const
{
  return _currentPhase;
}

//----------------------------------------------------------------------------
// sets current progress and phase

void ProgressNotifier::SetProgress(float iProgress, uint32 iPhase)
{
	bool invoke_notify = false;

	uint32 phase = GetCurrentPhaseOffset()+iPhase;
	
	if (fabs(_lastNotifiedProgress-iProgress) >= _sensitivity) {
		invoke_notify = true;
		_lastNotifiedProgress = iProgress;
	}
	_currentProgress = iProgress;
	
	if (phase != _currentPhase) {
		invoke_notify = true;
		_lastNotifiedProgress = _currentProgress;
	}
	_currentPhase = phase;

	if (invoke_notify) 
    Notify(_currentProgress, _currentPhase);
}


//----------------------------------------------------------------------------
// pushes current phase offset to the stack
//----------------------------------------------------------------------------
void ProgressNotifier::PushCurrentPhase(bool ibIncrement)
{
  if (ibIncrement) _currentPhase++;
  _phaseOffsetStack.push(_currentPhase);
}

//----------------------------------------------------------------------------
// pops current phase offset from the stack
//----------------------------------------------------------------------------
void ProgressNotifier::PopCurrentPhase()
{
  if (_phaseOffsetStack.empty()) 
    elxThrow(elxErrInvalidContext, "Phase offset stack is empty.");
	
  _phaseOffsetStack.pop();
  _currentPhase++;
}

//----------------------------------------------------------------------------
// requests operation cancel
//----------------------------------------------------------------------------
void ProgressNotifier::RequestCancel()
{
  _bCanceled = true;
}

//----------------------------------------------------------------------------
// returns actual phase offset
//----------------------------------------------------------------------------
uint32 ProgressNotifier::GetCurrentPhaseOffset() const
{
  if (_phaseOffsetStack.empty()) return 0;
  return _phaseOffsetStack.top();
}

//----------------------------------------------------------------------------
void ProgressNotifier::Log(const char * iprString, uint32 iPhase)
{
  Notify(iprString, iPhase);
}

//----------------------------------------------------------------------------
void ProgressNotifier::Notify(float /*iProgress*/, uint32 /*iPhase*/)
{
  // default implementation do nothing
}
void ProgressNotifier::Notify(const char * /*iprString*/, uint32 /*iPhase*/)
{
  // default implementation do nothing
}

} // namespace eLynx
