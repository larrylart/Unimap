//============================================================================
//  CoreParameters.cpp                                  Core.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreParameters.h>
#include <string.h>

namespace eLynx {

//----------------------------------------------------------------------------
//
//----------------------------------------------------------------------------
size_t elxGetParameterIndex(const ParameterList& iList, const std::string& iName)
{
  const size_t n = iList.size();
  for (size_t i=0; i<n; i++)
    if (iList[i]->GetName() == iName)
      return i;
  return -1;
}

AbstractParameter::AbstractParameter(EParameterType iType, const std::string& iName) : 
  _type(iType), _name(iName) {}
AbstractParameter::~AbstractParameter() {}
EParameterType AbstractParameter::GetType() const { return _type; }
std::string AbstractParameter::GetName() const { return _name; }
void Reset();


//============================================================================
//                              ParameterEnum
//============================================================================
static ParameterEnumItemList s_EmptyList;

ParameterEnum::ParameterEnum(const std::string& iName, 
    int32 iIndex, const ParameterEnumItemList& iList) :
  AbstractParameter(PT_Enum, iName),
  _index(iIndex),
  _default(iIndex),
  _list(iList)
{}

ParameterEnum::ParameterEnum() :  
  AbstractParameter(PT_Enum, ""),
  _index(-1),
  _default(-1), 
  _list(s_EmptyList)
{
}

ParameterEnum::~ParameterEnum() {}

void ParameterEnum::Reset()
  { _index = _default; }

size_t ParameterEnum::GetSize() const
  { return _list.size(); }

int32 ParameterEnum::GetIndex() const
  { return _index; }

void ParameterEnum::SetIndex(int32 iIndex) 
  { _index = iIndex; }

int32 ParameterEnum::GetValue() const 
  { return _list[_index].GetValue(); }

int32 ParameterEnum::GetValue(int32 iIndex) const 
  { return _list[iIndex].GetValue(); }

std::string ParameterEnum::GetLabel() const
  { return _list[_index].GetLabel(); }

std::string ParameterEnum::GetLabel(int32 iIndex) const
  { return _list[iIndex].GetLabel(); }

//============================================================================
//                              ParameterInteger
//============================================================================
ParameterInteger::ParameterInteger(
    const std::string& iName, 
    int32 iMin, int32 iMax, int32 iValue,
    int32 iTick, int32 iDigits,
    const std::string& iFormat) :
  AbstractParameter(PT_Integer, iName),
  _min(iMin), _max(iMax), _value(iValue),
  _default(iValue),
  _tick(iTick), _digits(iDigits),
  _format(iFormat)
{}

ParameterInteger::~ParameterInteger() {}

void ParameterInteger::Reset() { _value = _default; }
void ParameterInteger::SetValue(int32 iValue) { _value = iValue; }
int32 ParameterInteger::GetMin() const { return _min; }
int32 ParameterInteger::GetMax() const { return _max; }
int32 ParameterInteger::GetValue() const { return _value; }
int32 ParameterInteger::GetTick() const { return _tick; }
int32 ParameterInteger::GetDigits() const { return _digits; }
std::string ParameterInteger::GetFormat() const { return _format; }

//============================================================================
//                              ParameterDouble
//============================================================================
ParameterDouble::ParameterDouble(
    const std::string& iName, 
    double iMin, double iMax, double iValue,
    int32 iTick, int32 iDigits,
    const std::string& iFormat) :
  AbstractParameter(PT_Double, iName),
  _min(iMin), _max(iMax), _value(iValue),
  _default(iValue),
  _tick(iTick), _digits(iDigits),
  _format(iFormat)
{}

ParameterDouble::~ParameterDouble() {}

void ParameterDouble::Reset() { _value = _default; }
void ParameterDouble::SetValue(double iValue) { _value = iValue; }
double ParameterDouble::GetMin() const { return _min; }
double ParameterDouble::GetMax() const { return _max; }
double ParameterDouble::GetValue() const { return _value; }
int32 ParameterDouble::GetTick() const { return _tick; }
int32 ParameterDouble::GetDigits() const { return _digits; }
std::string ParameterDouble::GetFormat() const { return _format; }

} // namespace eLynx

