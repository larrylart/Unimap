//============================================================================
//  Timer.cpp                                           Core.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/Timer.h>

namespace eLynx {

#ifdef elxWINDOWS

Timer::Timer() : _startTime(GetTickCount())
{}

void Timer::Start()
{
  _startTime =  GetTickCount();
}

long Timer::Stop() const
{
  long stopTime = GetTickCount();
  return (stopTime - _startTime);
}

#elif elxLINUX

Timer::Timer() : _startTime()
{
  gettimeofday(&_startTime, 0);
}

void Timer::Start()
{
  gettimeofday(&_startTime, 0);
}

long Timer::Stop() const
{
  elxTimeType stopTime;
  gettimeofday(&stopTime, 0);
  return ((stopTime.tv_sec - _startTime.tv_sec)*1000000 + 
      (stopTime.tv_usec - _startTime.tv_usec)) / 1000;
}

#else

Timer::Timer()
{
  elxFIXME;
}

void Timer::Start()
{
  elxFIXME;
}

long Timer::Stop() const
{
  elxFIXME;
}


#endif

} // namespace eLynx
