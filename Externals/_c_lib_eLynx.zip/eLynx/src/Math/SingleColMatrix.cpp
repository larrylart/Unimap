//============================================================================
//  SingleColMatrix.cpp                                 Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/math/SingleColMatrix.h>

namespace eLynx {
namespace Math {
	

//----------------------------------------------------------------------------
// constructor, creates matrix from specified vector

SingleColMatrix::SingleColMatrix(IVector &iVector)
	: _prVector(iVector)
{
}


//----------------------------------------------------------------------------
// copy constructor

SingleColMatrix::SingleColMatrix(const SingleColMatrix &iC)
	: _prVector(iC._prVector)
{
}


//----------------------------------------------------------------------------
// an assignement operator

SingleColMatrix& SingleColMatrix::operator = (SingleColMatrix &iC)
{
	if (&iC != this) CopyData(iC);
	return *this;
}


//----------------------------------------------------------------------------
// copies object data

void SingleColMatrix::CopyData(const SingleColMatrix &iC)
{
	_prVector = iC._prVector;
}


//----------------------------------------------------------------------------

} // namespace Math
} // namespace eLynx
