//============================================================================
//  Delaunay.cpp                                        Math.Component package
//============================================================================
//  Delaunay triangulation algorithm
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreTypes.h>
#include <elx/core/CoreMacros.h>
#include <elx/math/Geometry.h>

#include "Delaunay/Delaunay.hpp"

namespace eLynx {
namespace Math {

//----------------------------------------------------------------------------
//  constructor
//----------------------------------------------------------------------------
Delaunay::Delaunay(const Point2iList& iList)
{
  // Point storage
  _pointCount = iList.size();
  size_t i, n = _pointCount;
  _plPointList = new Point [n];
  elxASSERT(NULL != _plPointList);

  Point * p = _plPointList;
  for (i= 0; i<n; i++, p++)
  {
    p->_x = (float)iList[i]._x;
    p->_y = (float)iList[i]._y;
    p->_prEntry = NULL;
  }

  // Edges
  _freeEdgeCount = 3 * n;   // Eulers relation
  _plEdgeList = new Edge [_freeEdgeCount];
  elxASSERT(NULL != _plEdgeList);

  _plFreeEdgeList = new Edge* [_freeEdgeCount];
  elxASSERT(NULL != _plFreeEdgeList);

  Edge * prEdge = _plEdgeList;
  for (i=0; i<_freeEdgeCount; i++, prEdge++)
    _plFreeEdgeList[i] = prEdge;

  // Sort
  Point ** plSorted = new Point * [n];
  elxASSERT(NULL != plSorted);
  for (i=0; i<n; i++)
    plSorted[i] = _plPointList + i;

  Point ** plTemp = new Point * [n];
  elxASSERT(NULL != plTemp);

  MergeSort(plSorted, plTemp, 0, n-1);
  elxSAFE_DELETE_LIST(plTemp);

  // Triangulate
  Edge * prLeftCW, * prRightCCW;
  Divide(plSorted, 0, n-1, prLeftCW, prRightCCW);
  elxSAFE_DELETE_LIST(plSorted);

} // constructor


//----------------------------------------------------------------------------
//  destructor
//----------------------------------------------------------------------------
Delaunay::~Delaunay()
{
  elxSAFE_DELETE_LIST(_plPointList);
  elxSAFE_DELETE_LIST(_plEdgeList);
  elxSAFE_DELETE_LIST(_plFreeEdgeList);

} // destructor


//----------------------------------------------------------------------------
//  MakeEdge : Initialise a new edge
//----------------------------------------------------------------------------
Delaunay::Edge * Delaunay::MakeEdge(Point * iprP1, Point * iprP2)
{
  if (_freeEdgeCount == 0) elxFIXME; // Out of memory for edges

  Edge * prEdge = _plFreeEdgeList[--_freeEdgeCount];

  if (NULL == iprP1->_prEntry) iprP1->_prEntry = prEdge;
  if (NULL == iprP2->_prEntry) iprP2->_prEntry = prEdge;

  prEdge->_prOrig = iprP1;
  prEdge->_prDest = iprP2;

  prEdge->_prOrigNext = prEdge->_prOrigPrev = 
  prEdge->_prDestNext = prEdge->_prDestPrev = prEdge;

  return prEdge;

} // MakeEdge

//----------------------------------------------------------------------------
//  FreeEdge
//----------------------------------------------------------------------------
void Delaunay::FreeEdge(Edge * iprEdge)
{
  _plFreeEdgeList[_freeEdgeCount++] = iprEdge;

} // FreeEdge


//----------------------------------------------------------------------------
//  Creates a new edge and adds it to two rings of edges
//----------------------------------------------------------------------------
//  u and v are the two vertices which are being joined.
//  a and b are the two edges associated with u and v res.
//----------------------------------------------------------------------------
Delaunay::Edge * Delaunay::Join(
    Edge * iprEdgeA, Point * iprP1, 
    Edge * iprEdgeB, Point * iprP2, 
    ESide iSide)
{
  Edge * prEdge = MakeEdge(iprP1, iprP2);
  
  if (iSide == left) 
  {
    if (iprEdgeA->_prOrig == iprP1)
      Splice(iprEdgeA->_prOrigPrev, prEdge, iprP1);
    else
      Splice(iprEdgeA->_prDestPrev, prEdge, iprP1);
    Splice(iprEdgeB, prEdge, iprP2);
  } 
  else // right
  {
    Splice(iprEdgeA, prEdge, iprP1);
    if (iprEdgeB->_prOrig == iprP2)
      Splice(iprEdgeB->_prOrigPrev, prEdge, iprP2);
    else
      Splice(iprEdgeB->_prDestPrev, prEdge, iprP2);
  }

  return prEdge;

} // Join


//----------------------------------------------------------------------------
// Remove an edge
//----------------------------------------------------------------------------
void Delaunay::RemoveEdge(Edge * iprEdge)
{
  // Cache origin and destination
  Point * u = iprEdge->_prOrig;
  Point * v = iprEdge->_prDest;

  // Adjust entry Points
  if (u->_prEntry == iprEdge)
    u->_prEntry = iprEdge->_prOrigNext;
  if (v->_prEntry == iprEdge)
    v->_prEntry = iprEdge->_prDestNext;

  // Four edge links to change
  if (iprEdge->_prOrigNext->_prOrig == u)
    iprEdge->_prOrigNext->_prOrigPrev = iprEdge->_prOrigPrev;
  else
    iprEdge->_prOrigNext->_prDestPrev = iprEdge->_prOrigPrev;

  if (iprEdge->_prOrigPrev->_prOrig == u)
    iprEdge->_prOrigPrev->_prOrigNext = iprEdge->_prOrigNext;
  else
    iprEdge->_prOrigPrev->_prDestNext = iprEdge->_prOrigNext;

  if (iprEdge->_prDestNext->_prOrig == v)
    iprEdge->_prDestNext->_prOrigPrev = iprEdge->_prDestPrev;
  else
    iprEdge->_prDestNext->_prDestPrev = iprEdge->_prDestPrev;

  if (iprEdge->_prDestPrev->_prOrig == v)
    iprEdge->_prDestPrev->_prOrigNext = iprEdge->_prDestNext;
  else
    iprEdge->_prDestPrev->_prDestNext = iprEdge->_prDestNext;

  FreeEdge(iprEdge);

} // RemoveEdge


//----------------------------------------------------------------------------
// Add an edge to a ring of edges
// B must be the unnattached edge and A must be the previous ccw edge to B.
//----------------------------------------------------------------------------
void Delaunay::Splice(Edge * iprEdgeA, Edge * iprEdgeB, Point * iprPt)
{
  Edge * prNext;
  if (iprEdgeA->_prOrig == iprPt) 
  { 
    prNext = iprEdgeA->_prOrigNext;
    iprEdgeA->_prOrigNext = iprEdgeB;
  } 
  else 
  {
    prNext = iprEdgeA->_prDestNext;
    iprEdgeA->_prDestNext = iprEdgeB;
  }

  if (prNext->_prOrig == iprPt)
    prNext->_prOrigPrev = iprEdgeB;
  else
    prNext->_prDestPrev = iprEdgeB;

  if (iprEdgeB->_prOrig == iprPt) 
  {
    iprEdgeB->_prOrigNext = prNext;
    iprEdgeB->_prOrigPrev = iprEdgeA;
  } 
  else 
  {
    iprEdgeB->_prDestNext = prNext;
    iprEdgeB->_prDestPrev = iprEdgeA;
  }

} // Splice


//----------------------------------------------------------------------------
//  MergeSort
//----------------------------------------------------------------------------
void Delaunay::MergeSort(Point * iprP1[], Point * iprP2[], size_t iLeft, size_t iRight)
{
  if (iRight - iLeft > 0)
  {
    const size_t middle = (iRight + iLeft) / 2;
    MergeSort(iprP1, iprP2, iLeft, middle);
    MergeSort(iprP1, iprP2, middle+1, iRight);

    size_t i,j,k;
    for (i=middle+1; i>iLeft; i--)
      iprP2[i-1] = iprP1[i-1];

    for (j=middle; j<iRight; j++)
      iprP2[iRight+middle-j] = iprP1[j+1];

    for (k=iLeft; k<=iRight; k++)
    {
      if (iprP2[i]->_x < iprP2[j]->_x) 
        iprP1[k] = iprP2[i++];
      else if ((iprP2[i]->_x == iprP2[j]->_x) && (iprP2[i]->_y < iprP2[j]->_y))
        iprP1[k] = iprP2[i++];
      else 
        iprP1[k] = iprP2[j--];
    }
  }

} // MergeSort


//----------------------------------------------------------------------------
//  Divide
//----------------------------------------------------------------------------
void Delaunay::Divide(
    Point * iprSorted[], 
    size_t iLeft, size_t iRight, 
    Edge *& oprLeftCCW, Edge *& oprRightCW)
{
  const size_t n = iRight - iLeft + 1;
  if (n == 2) 
  {
    // Bottom of the recursion. Make an edge
    oprLeftCCW = oprRightCW = MakeEdge(iprSorted[iLeft], iprSorted[iRight]);
  } 
  else if (n == 3) 
  {
    // Bottom of the recursion. Make a triangle or two edges
    Edge * a = MakeEdge(iprSorted[iLeft], iprSorted[iLeft+1]);
    Edge * b = MakeEdge(iprSorted[iLeft+1], iprSorted[iRight]);
    Splice(a, b, iprSorted[iLeft+1]);
    const float cp = CrossProduct(iprSorted[iLeft], iprSorted[iLeft+1], iprSorted[iRight]);
    if (cp > 0)
    {
      // Make a triangle
      Join(a, iprSorted[iLeft], b, iprSorted[iRight], right);
      oprLeftCCW = a;
      oprRightCW = b;
    } 
    else if (cp < 0) 
    {
      // Make a triangle
      Edge * prEdge = Join(a, iprSorted[iLeft], b, iprSorted[iRight], left);
      oprLeftCCW = prEdge;
      oprRightCW = prEdge;
    } 
    else // cp == 0
    {
      // Points are collinear, no triangle
      oprLeftCCW = a;
      oprRightCW = b;
    }
  } 
  else if (n  > 3) 
  {
    // Calculate the split point
    const size_t split = (iLeft + iRight) / 2;

    // Divide 
    Edge * prLeftCCWLeft, * prRightCWLeft; 
    Divide(iprSorted, iLeft, split, prLeftCCWLeft, prRightCWLeft);

    Edge * prLeftCCWRight, * prRightCWRight;
    Divide(iprSorted, split+1, iRight, prLeftCCWRight, prRightCWRight);

    // Merge
    Edge * prLeftTangent;
    Merge(prRightCWLeft, iprSorted[split], prLeftCCWRight, iprSorted[split+1], prLeftTangent);

    // The lower tangent added by merge may have invalidated 
    // prLeftCCWLeft or prRightCWRight. Update them if necessary.
    if (prLeftTangent->_prOrig == iprSorted[iLeft])  prLeftCCWLeft = prLeftTangent;
    if (prLeftTangent->_prDest == iprSorted[iRight]) prRightCWRight = prLeftTangent;

    // Update edge refs to be passed back
    oprLeftCCW = prLeftCCWLeft;
    oprRightCW = prRightCWRight;
  }

} // Divide


//----------------------------------------------------------------------------
//  Determines the lower tangent of two triangulations
//----------------------------------------------------------------------------
void Delaunay::GetLowerTangent(
    Edge * iprRightCWLeft,   Point * iprP1, 
    Edge * iprLeftCCWRight,  Point * iprP2,
    Edge *& oprLeftLower,    Point *& oprOrigLeftLower,
    Edge *& oprRightLower,   Point *& oprOrigRightLower)
{
  Edge * prLeft  = iprRightCWLeft;
  Edge * prRight = iprLeftCCWRight;
  Point * prOrigLeft  = iprP1;
  Point * prOrigRight = iprP2;
  Point * prDestLeft  = prLeft->GetOther(iprP1);
  Point * prDestRight = prRight->GetOther(iprP2);
  bool bFinished = false;

  while (!bFinished)
  {
    if (CrossProduct(prOrigLeft, prDestLeft, prOrigRight) > 0) 
    {
      prLeft = prLeft->GetPrevious(prDestLeft);
      prOrigLeft = prDestLeft;
      prDestLeft = prLeft->GetOther(prOrigLeft);
    } 
    else if (CrossProduct(prOrigRight, prDestRight, prOrigLeft) < 0) 
    {
      prRight = prRight->GetNext(prDestRight);
      prOrigRight = prDestRight;
      prDestRight = prRight->GetOther(prOrigRight);
    } 
    else
      bFinished = true;
  }

  oprLeftLower  = prLeft;
  oprRightLower = prRight;
  oprOrigLeftLower = prOrigLeft;
  oprOrigRightLower = prOrigRight;

} // GetLowerTangent


//----------------------------------------------------------------------------
//  The Merge function is where most of the work actually gets done
//----------------------------------------------------------------------------
void Delaunay::Merge(
    Edge * iprRightCWLeft,  Point * iprP1, 
    Edge * iprLeftCCWRight, Point * iprP2, 
    Edge *& oprLeftTangent)
{
  Edge * prLcand, * prRcand, * prLlower, * prRlower;
  Point * prDestLcand, * prDestRcand, * prOrigLlower, * prOrigRlower;
  float uLcob, vLcob, uLcdb, vLcdb;
  float uRcob, vRcob, uRcdb, vRcdb;
  float cpLcand, cpRcand, dpLcand, dpRcand, cotLcand, cotRcand;
  bool bAboveLcand, bAboveRcand, bAboveNext, bAbovePrev;

  // Create first cross edge by Joining lower common tangent
  GetLowerTangent(iprRightCWLeft, iprP1, iprLeftCCWRight, iprP2, 
                  prLlower, prOrigLlower, prRlower, prOrigRlower);
  Edge * prBase = Join(prLlower, prOrigLlower, prRlower, prOrigRlower, right);
  Point * prOrigBase = prOrigLlower; 
  Point * prDestBase = prOrigRlower;
  
  // Need to return lower tangent
  oprLeftTangent = prBase;

  // Main Merge loop
  do 
  {
    // Initialise prLcand and prRcand 
    prLcand = prBase->GetNext(prOrigBase);
    prRcand = prBase->GetPrevious(prDestBase);
    prDestLcand = prLcand->GetOther(prOrigBase);
    prDestRcand = prRcand->GetOther(prDestBase);

    // Vectors for above and "in_circle" tests
    Vector(prDestLcand, prOrigBase, uLcob, vLcob);
    Vector(prDestLcand, prDestBase, uLcdb, vLcdb);
    Vector(prDestRcand, prOrigBase, uRcob, vRcob);
    Vector(prDestRcand, prDestBase, uRcdb, vRcdb);

    // Above tests
    cpLcand = CrossProduct(uLcob, vLcob, uLcdb, vLcdb);
    cpRcand = CrossProduct(uRcob, vRcob, uRcdb, vRcdb);
    bAboveLcand = cpLcand > 0;
    bAboveRcand = cpRcand > 0;
    if (!bAboveLcand && !bAboveRcand)
      break; // Finished

    // Advance prLcand ccw,  deleting the old prLcand edge,  
    // until the "in_circle" test fails.
    if (bAboveLcand)
    {
      float unob, vnob, undb, vndb, cpNext, dpNext, cotNext;
      Edge * prNext;
      Point * prDestNext;

      dpLcand = DotProduct(uLcob, vLcob, uLcdb, vLcdb);
      cotLcand = dpLcand / cpLcand;

      do 
      {
        prNext = prLcand->GetNext(prOrigBase);
        prDestNext = prNext->GetOther(prOrigBase);
        Vector(prDestNext, prOrigBase, unob, vnob);
        Vector(prDestNext, prDestBase, undb, vndb);
        cpNext = CrossProduct(unob, vnob, undb, vndb);
        bAboveNext = cpNext > 0.0;

        if (!bAboveNext) 
          break;    // Finished

        dpNext = DotProduct(unob, vnob, undb, vndb);
        cotNext = dpNext / cpNext;

        if (cotNext > cotLcand)
          break;    // Finished

        RemoveEdge(prLcand);
        prLcand = prNext;
        cotLcand = cotNext;
      } 
      while (true);
    }

    // Now do the symmetrical for prRcand
    if (bAboveRcand)
    {
      float upob, vpob, updb, vpdb, cpPrev, dpPrev, cotPrev;
      Edge * prPrev;
      Point * prDestPrev;

      dpRcand = DotProduct(uRcob, vRcob, uRcdb, vRcdb);
      cotRcand = dpRcand / cpRcand;

      do 
      {
        prPrev = prRcand->GetPrevious(prDestBase);
        prDestPrev = prPrev->GetOther(prDestBase);
        Vector(prDestPrev, prOrigBase, upob, vpob);
        Vector(prDestPrev, prDestBase, updb, vpdb);
        cpPrev = CrossProduct(upob, vpob, updb, vpdb);
        bAbovePrev = cpPrev > 0.0;

        if (!bAbovePrev) 
          break;    // Finished

        dpPrev = DotProduct(upob, vpob, updb, vpdb);
        cotPrev = dpPrev / cpPrev;

        if (cotPrev > cotRcand)
          break;    // Finished.

        RemoveEdge(prRcand);
        prRcand = prPrev;
        cotRcand = cotPrev;
      } 
      while (true);
    }

    // Now add a cross edge from base to either prLcand or prRcand. 
    // If both are valid choose on the basis of the in_circle test. 
    // Advance base and whichever candidate was chosen.
    prDestLcand = prLcand->GetOther(prOrigBase);
    prDestRcand = prRcand->GetOther(prDestBase);
    if (!bAboveLcand || (bAboveLcand && bAboveRcand && cotRcand < cotLcand))
    {
      // Connect to the right
      prBase = Join(prBase, prOrigBase, prRcand, prDestRcand, right);
      prDestBase = prDestRcand;
    } 
    else 
    {
      // Connect to the left
      prBase = Join(prLcand, prDestLcand, prBase, prDestBase, right);
      prOrigBase = prDestLcand;
    }
  } 
  while (true);

} // Merge


//----------------------------------------------------------------------------
//  The Merge function is where most of the work actually gets done
//----------------------------------------------------------------------------
bool Delaunay::BuildTriangleList(TriangleIdxList& oTriangles)
{
  oTriangles.clear();
  if (_pointCount < MIN_POINT_COUNT) return false;

  Edge * prEdge, * prNext;
  Point * pr0, * prP1, * prP2;

  size_t i, n = _pointCount - 1;
  for (i=0; i<n; i++) 
  {
    pr0 = &_plPointList[i]; 
    Edge * prEdgeStart = prEdge = pr0->_prEntry;
    Point * prPrevP1 = 0, * prPrevP2 = 0;
    do
    {
      prP1 = prEdge->GetOther(pr0);
      if (pr0 < prP1) 
      {
        prNext = prEdge->GetNext(pr0);
        prP2 = prNext->GetOther(pr0);
        if (pr0 < prP2)
          if (prNext->GetNext(prP2) == prEdge->GetPrevious(prP1) ) 
          {  
            // Triangle
            if (prP1 > prP2) 
            { Point * prTemp = prP1; prP1 = prP2; prP2 = prTemp; }

            if (prPrevP1 != prP1 || prPrevP2 != prP2)
            {
              TriangleIdx t(
                uint32(pr0-_plPointList), 
                uint32(prP1-_plPointList), 
                uint32(prP2-_plPointList)
              );
              oTriangles.push_back(t);
              prPrevP1 = prP1;
              prPrevP2 = prP2;
            }
          }
      }

      // Next edge around P0
      prEdge = prEdge->GetNext(pr0);
    } 
    while (prEdge != prEdgeStart);
  }

  return true;

} // BuildTriangleList


//----------------------------------------------------------------------------
//  elxTriangulate
//----------------------------------------------------------------------------
bool elxTriangulate(const Point2iList& iPoints, TriangleIdxList& oTriangles)
{
  Delaunay helper(iPoints);
  return helper.BuildTriangleList(oTriangles);

} // elxTriangulate

//----------------------------------------------------------------------------
//  elxTriangulate
//----------------------------------------------------------------------------
bool elxTriangulate(const Point2iList& iPoints, 
  TriangulationData& oTriangulationData)
{
  typedef TriangulationData::Vertex Vertex;
  typedef TriangulationData::Edge Edge;
  typedef TriangulationData::Triangle Triangle;
  
  Delaunay helper(iPoints);
  
  if (helper._pointCount < Delaunay::MIN_POINT_COUNT) return false;
  
  Delaunay::Edge * prEdge, * prNext;
  Delaunay::Point * pr[3];
  
  Vertex vertex;
  
  oTriangulationData._vertices.clear();
  oTriangulationData._edges.clear();
  oTriangulationData._triangles.clear();
  
  // It's important to preallocate all memory upfront because in case of 
  // reallocations all pointers will be off
  oTriangulationData._vertices.reserve(helper._pointCount);
  // Max number of edges is max number of triangles *3 /2 ~ 3n
  oTriangulationData._edges.reserve(helper._pointCount*3);
  // Max number of triangles is 2n -2 -b where n is total number of
  // vertices and b is number of vertices on the convex hull
  oTriangulationData._triangles.reserve(helper._pointCount*2);
  
  for (uint32 i=0; i<helper._pointCount; i++) 
  {
    // assumption here is that _plPointList is NOT RESORTED 
    // after the initialization
    vertex._position._x =  helper._plPointList[i]._x;
    vertex._position._y =  helper._plPointList[i]._y;
    oTriangulationData._vertices.push_back(vertex);
  }
  
  const size_t n = helper._pointCount - 1;
  for (size_t i=0; i<n; i++)
  {
    pr[0] = &helper._plPointList[i];    
    Delaunay::Edge * prEdgeStart = prEdge = pr[0]->_prEntry;
    Delaunay::Point * prPrevP1 = 0, * prPrevP2 = 0;
    do
    {
      pr[1] = prEdge->GetOther(pr[0]);
      
      if (pr[0] < pr[1]) 
      {
        prNext = prEdge->GetNext(pr[0]);
        pr[2] = prNext->GetOther(pr[0]);
        if (pr[0] < pr[2])
          if (prNext->GetNext(pr[2]) == prEdge->GetPrevious(pr[1])) 
          {  
            // Triangle
            if (pr[1] > pr[2]) 
            { Delaunay::Point * prTemp = pr[1]; pr[1] = pr[2]; pr[2] = prTemp; }


            if (prPrevP1 != pr[1] || prPrevP2 != pr[2])
            {
              prPrevP1 = pr[1];
              prPrevP2 = pr[2];

              Triangle t;
              t._vertex[0]= &oTriangulationData._vertices[pr[0]-helper._plPointList];
              t._vertex[1]= &oTriangulationData._vertices[pr[1]-helper._plPointList];
              t._vertex[2]= &oTriangulationData._vertices[pr[2]-helper._plPointList];
              t._edge[0] = t._edge[1] = t._edge[2] = 0;

              oTriangulationData._triangles.push_back(t);
              Triangle * pt = &oTriangulationData._triangles.back();

              // Now figure out whether the edges were already built
              for(uint32 j = 0; j < 3; ++j)
              {
                Edge * pedge = elxGetEdge(
                  oTriangulationData._vertices[pr[j]-helper._plPointList]._edges, 
                  oTriangulationData._vertices[pr[(j+1)%3]-helper._plPointList]);
                if (pedge == 0)
                {
                  pedge = elxBuildEdge(
                    pr[j] - helper._plPointList, 
                    pr[(j+1)%3] - helper._plPointList, 
                    pt, oTriangulationData
                  );

                  //Assign edges to corresponding vertices  
                  oTriangulationData._vertices[pr[j]-helper._plPointList]._edges.push_back(
                     pedge);
                  oTriangulationData._vertices[pr[(j+1)%3]-helper._plPointList]._edges.push_back(
                     pedge);
                } 
                else
                  //Assign the triangle
                  pedge->_triangle[1] = pt;

                //Assign edges to the triangle  
                pt->_edge[j] = pedge;
              }
            }        
          }
      }
      
      // Next edge around P0
      prEdge = prEdge->GetNext(pr[0]);
    } 
    while (prEdge != prEdgeStart);
  }
  return true;

} // elxTriangulate

} // namespace Math
} // namespace eLynx

