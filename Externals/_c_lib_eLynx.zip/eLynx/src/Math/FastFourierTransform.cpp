//============================================================================
//  FastFourierTransform.cpp                            Math.Component package
//============================================================================
//  Usefull links :
//
//  http://local.wasp.uwa.edu.au/~pbourke/other/dft/
//  http://local.wasp.uwa.edu.au/~pbourke/other/fft2d/
//  http://www.fftw.org/fftw-paper.pdf
//  http://www.fftw.org/index.html
//  http://www.jjj.de/fft/fftpage.html
//
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/math/FrequencyTransform.h>
#include <elx/math/MathCore.h>

namespace eLynx {
namespace Math {

//----------------------------------------------------------------------------
//  elxFFT: computes an in-place complex-to-complex FFT
//----------------------------------------------------------------------------
//  Forward transform, n=0..N-1
//                  N-1
//                  ---
//              1   \          - j k 2 PI n / N
//      X(n) = ---   >   x(k) e
//              N   /
//                  ---
//                  k=0
//
//  Inverse transform, n=0..N-1
//
//                  N-1
//                  ---
//                  \          j k 2 PI n / N
//      X(n) =       >   x(k) e
//                  /                                
//                  ---
//                  k=0
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : ioprComplexMap
//        uint32 iDimArray[]: size for each dimension, must be a power of 2
//        uint32 iDimension: nunber of dimensions of complex map
//        bool ibForward true for forward transform, false for inverse transform
//  Out : bool
//----------------------------------------------------------------------------
bool elxFFT(double * ioprComplexMap, uint32 iDimArray[], uint32 iDimension, bool ibForward)
{
  uint32 i1,i2,i3,i2Reversed,i3Reversed;
  uint32 p1,p2,p3,ifp1,ifp2;
  uint32 bit,k1,k2,n,nrem;
  double tmpRe,tmpIm, wRe,wIm, wpRe,wpIm;
  double theta,wTmp;

  // Compute total number of complex values.
  uint32 nSample = 1;
  for (int32 d=iDimension-1; d>=0; d--)
  {
    // check that dimensions are power of two
    if (!elxIsPow2(iDimArray[d]))
      return false;
    nSample *= iDimArray[d];
  }

  // WARNING: algorithm use prMap as array[1..N] not [0..N-1]
  double * prMap = ioprComplexMap;
  --prMap;
  
  // scale for FFT of IFFT
  double scale = ibForward ? +2*M_PI : -2*M_PI;
  uint32 nprev = 1;
  
  // loop over dimensions.
  for (int32 d=iDimension-1; d>=0; d--) 
  {
    n = iDimArray[d];
    nrem = nSample / (n*nprev);
    p1 = nprev << 1; // x2.
    p2 = p1*n;
    p3 = p2*nrem;
    i2Reversed = 1;
      
    for (i2=1; i2<=p2; i2+=p1) 
    { 
      // bit reversal
      if (i2 < i2Reversed)
      {
	      for (i1=i2; i1<=i2+p1-2; i1+=2) 
          for (i3=i1; i3<=p3; i3+=p2) 
          {
            i3Reversed = i2Reversed + i3 - i2;
		        elxSwap(prMap[i3],   prMap[i3Reversed]);
		        elxSwap(prMap[i3+1], prMap[i3Reversed+1]);
          }
      }
      bit = p2 >> 1; 
      while (bit >= p1 && i2Reversed > bit) 
      {
        i2Reversed -= bit;
        bit >>= 1;
      }
      i2Reversed += bit;
    }
    ifp1 = p1;
      
    while (ifp1 < p2) 
    {
	    ifp2 = ifp1 << 1;
      theta = scale / (ifp2 / p1); 
	    wTmp = sin(0.5*theta);

	    wpRe = -2.0 * wTmp * wTmp;
	    wpIm = sin(theta);

	    wRe = 1.0;
	    wIm = 0.0;

      for (i3=1; i3<=ifp1; i3+=p1)
      {
        for (i1=i3; i1<=i3+p1-2; i1+=2)
        {
          for (i2=i1; i2<=p3; i2+=ifp2)
          {
		        k1 = i2;
            k2 = k1 + ifp1;
		        tmpRe = wRe*prMap[k2]   - wIm*prMap[k2+1];
		        tmpIm = wRe*prMap[k2+1] + wIm*prMap[k2];

            prMap[k2]   = prMap[k1]   - tmpRe;
            prMap[k2+1] = prMap[k1+1] - tmpIm;

            prMap[k1]   += tmpRe;
            prMap[k1+1] += tmpIm;
          }
        }
        wTmp = wRe;
        wRe = wRe*wpRe - wIm*wpIm + wRe;
        wIm = wIm*wpRe + wTmp*wpIm + wIm;
      }
      ifp1 = ifp2;
    }
    nprev *= n;
  }
   
  return true;

} // elxFFT


//----------------------------------------------------------------------------
//  elxFFT: computes an in-place complex-to-complex FFT, float version
//----------------------------------------------------------------------------
bool elxFFT(float * ioprComplexMap, uint32 iDimArray[], uint32 iDimension, bool ibForward)
{
  uint32 i1,i2,i3,i2Reversed,i3Reversed;
  uint32 p1,p2,p3,ifp1,ifp2;
  uint32 bit,k1,k2,n,nrem;
  float tmpRe,tmpIm, wRe,wIm, wpRe,wpIm;
  float theta,wTmp;

  // Compute total number of complex values.
  uint32 nSample = 1;
  for (int32 d=iDimension-1; d>=0; d--)
  {
    // check that dimensions are power of two
    if (!elxIsPow2(iDimArray[d]))
      return false;
    nSample *= iDimArray[d];
  }

  // WARNING: algorithm use prMap as array[1..N] not [0..N-1]
  float * prMap = ioprComplexMap;
  --prMap;
  
  // scale for FFT of IFFT
  float scale = ibForward ? + float(2*M_PI) : - float(2*M_PI);
  uint32 nprev = 1;
  
  // loop over dimensions.
  for (int32 d=iDimension-1; d>=0; d--) 
  {
    n = iDimArray[d];
    nrem = nSample / (n*nprev);
    p1 = nprev << 1; // x2.
    p2 = p1*n;
    p3 = p2*nrem;
    i2Reversed = 1;
      
    for (i2=1; i2<=p2; i2+=p1) 
    { 
      // bit reversal
      if (i2 < i2Reversed)
      {
	      for (i1=i2; i1<=i2+p1-2; i1+=2) 
          for (i3=i1; i3<=p3; i3+=p2) 
          {
            i3Reversed = i2Reversed + i3 - i2;
		        elxSwap(prMap[i3],   prMap[i3Reversed]);
		        elxSwap(prMap[i3+1], prMap[i3Reversed+1]);
          }
      }
      bit = p2 >> 1; 
      while (bit >= p1 && i2Reversed > bit) 
      {
        i2Reversed -= bit;
        bit >>= 1;
      }
      i2Reversed += bit;
    }
    ifp1 = p1;
      
    while (ifp1 < p2) 
    {
	    ifp2 = ifp1 << 1;
      theta = scale / (ifp2 / p1); 
	    wTmp = sinf(0.5f*theta);

	    wpRe = -2.0f * wTmp * wTmp;
	    wpIm = sinf(theta);

	    wRe = 1.0f;
	    wIm = 0.0f;

      for (i3=1; i3<=ifp1; i3+=p1)
      {
        for (i1=i3; i1<=i3+p1-2; i1+=2)
        {
          for (i2=i1; i2<=p3; i2+=ifp2)
          {
		        k1 = i2;
            k2 = k1 + ifp1;
		        tmpRe = wRe*prMap[k2]   - wIm*prMap[k2+1];
		        tmpIm = wRe*prMap[k2+1] + wIm*prMap[k2];

            prMap[k2]   = prMap[k1]   - tmpRe;
            prMap[k2+1] = prMap[k1+1] - tmpIm;

            prMap[k1]   += tmpRe;
            prMap[k1+1] += tmpIm;
          }
        }
        wTmp = wRe;
        wRe = wRe*wpRe - wIm*wpIm + wRe;
        wIm = wIm*wpRe + wTmp*wpIm + wIm;
      }
      ifp1 = ifp2;
    }
    nprev *= n;
  }
   
  return true;

} // elxFFT

/*
template<typename T>
bool elxFFT(T * ioprComplexMap, uint32 iDimArray[], uint32 iDimension, bool ibForward)
{
  uint32 i1,i2,i3,i2Reversed,i3Reversed;
  uint32 p1,p2,p3,ifp1,ifp2;
  uint32 bit,k1,k2,n,nrem;
  T tmpRe,tmpIm, wRe,wIm, wpRe,wpIm;
  T theta,wTmp;

  // Compute total number of complex values.
  uint32 nSample = 1;
  for (int32 d=iDimension-1; d>=0; d--)
  {
    // check that dimensions are power of two
    if (!elxIsPow2(iDimArray[d]))
      return false;
    nSample *= iDimArray[d];
  }

  // WARNING: algorithm use prMap as array[1..N] not [0..N-1]
  T * prMap = ioprComplexMap;
  --prMap;
  
  // scale for FFT of IFFT
  double scale = ibForward ? +2*M_PI : -2*M_PI;
  uint32 nprev = 1;
  
  // loop over dimensions.
  for (int32 d=iDimension-1; d>=0; d--) 
  {
    n = iDimArray[d];
    nrem = nSample / (n*nprev);
    p1 = nprev << 1; // x2.
    p2 = p1*n;
    p3 = p2*nrem;
    i2Reversed = 1;
      
    for (i2=1; i2<=p2; i2+=p1) 
    { 
      // bit reversal
      if (i2 < i2Reversed)
      {
	      for (i1=i2; i1<=i2+p1-2; i1+=2) 
          for (i3=i1; i3<=p3; i3+=p2) 
          {
            i3Reversed = i2Reversed + i3 - i2;
		        elxSwap(prMap[i3],   prMap[i3Reversed]);
		        elxSwap(prMap[i3+1], prMap[i3Reversed+1]);
          }
      }
      bit = p2 >> 1; 
      while (bit >= p1 && i2Reversed > bit) 
      {
        i2Reversed -= bit;
        bit >>= 1;
      }
      i2Reversed += bit;
    }
    ifp1 = p1;
      
    while (ifp1 < p2) 
    {
	    ifp2 = ifp1 << 1;
      theta = scale / (ifp2 / p1); 
	    wTmp = elxSin(0.5*theta);

	    wpRe = -2.0 * wTmp * wTmp;
	    wpIm = elxSin(theta);

	    wRe = 1.0;
	    wIm = 0.0;

      for (i3=1; i3<=ifp1; i3+=p1)
      {
        for (i1=i3; i1<=i3+p1-2; i1+=2)
        {
          for (i2=i1; i2<=p3; i2+=ifp2)
          {
		        k1 = i2;
            k2 = k1 + ifp1;
		        tmpRe = wRe*prMap[k2]   - wIm*prMap[k2+1];
		        tmpIm = wRe*prMap[k2+1] + wIm*prMap[k2];

            prMap[k2]   = prMap[k1]   - tmpRe;
            prMap[k2+1] = prMap[k1+1] - tmpIm;

            prMap[k1]   += tmpRe;
            prMap[k1+1] += tmpIm;
          }
        }
        wTmp = wRe;
        wRe = wRe*wpRe - wIm*wpIm + wRe;
        wIm = wIm*wpRe + wTmp*wpIm + wIm;
      }
      ifp1 = ifp2;
    }
    nprev *= n;
  }
   
  return true;

} // elxFFT
*/

} // namespace Math
} // namespace eLynx
