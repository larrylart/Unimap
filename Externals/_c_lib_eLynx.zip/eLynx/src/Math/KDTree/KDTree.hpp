//============================================================================
//  KDTree/KDTree.hpp                                   Math.Component package
//============================================================================
//  Copyright (C) 2007 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __KDTree_hpp__
#define __KDTree_hpp__

#include <algorithm>
#include <list>

#include "../Geometry/Intersections.hpp"

namespace eLynx {
namespace Math {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//   KDNode::KDNode           
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T>
KDNode<T>::KDNode() :  _pLeft(), _pRight(), _location()  
{}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//   KDNode::KDNode           
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T>
KDNode<T>::~KDNode()
{
  if (_pLeft) { delete _pLeft; _pLeft = 0;}
  if (_pRight) { delete _pRight; _pRight = 0;}
}

namespace {

template <typename T>
struct Neighbor
{
  Neighbor(const Point2<T>& iP, T iD) : _point(iP), _distance(iD) {}
  Point2<T> _point;
  T _distance;
};

template<typename T> inline 
T elxGetDistanceSqr(const Point2<T>& iP0, const Point2<T>& iP1)
{
  const T dx = iP0._x - iP1._x;
  const T dy = iP0._y - iP1._y;
  return dx*dx + dy*dy;
}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  elxCompPoint2X - sorts points by X coordinate            
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T>
struct elxCompPoint2X
{
  bool operator ()(const Point2<T>& iP1, const Point2<T>& iP2)
  {
    return iP1._x < iP2._x;
  }
}; // elxCompPoint2X


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  elxCompPoint2Y - sorts points by Y coordinate            
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T>
struct elxCompPoint2Y
{
  bool operator ()(const Point2<T>& iP1, const Point2<T>& iP2)
  {
    return iP1._y < iP2._y;
  }
}; // elxCompPoint2Y 


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  elxCompPoint2 - sorts points by distance to a given point            
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T>
struct elxCompPoint2
{
  Point2<T> _point;
  elxCompPoint2(const Point2<T>& iP) : _point(iP) {}
  
  bool operator ()(const Point2<T>& iP1, const Point2<T>& iP2)
  {
    return elxGetDistanceSqr(iP1, _point) < elxGetDistanceSqr(iP2, _point);
  }
}; // elxCompPoint2


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  elxBuildKDTree recursively bulds KD tree            
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T, typename Iterator>
KDNode<T>* elxBuildKDTree(const KDNode<T> * iParent, Iterator iBegin, 
  Iterator iEnd, const Rectangle2<T>& iRectangle, uint32 iDepth) 
{
  if (iBegin == iEnd)
    return 0;
  
  if (iDepth & 1)
    std::sort(iBegin, iEnd, elxCompPoint2Y<T>());
  else
    std::sort(iBegin, iEnd, elxCompPoint2X<T>());
    
  KDNode<T> * node = new KDNode<T>();
  size_t median = (iEnd - iBegin) / 2;
  node->_pParent = iParent;
  node->_location = *(iBegin+median);
  
  if (iDepth & 1) // Y
  {
    node->_rectangles[0]._P0 = iRectangle._P0; 
    node->_rectangles[0]._P1 = Point2<T>(iRectangle._P1._x, node->_location._y);
    node->_rectangles[1]._P0 = Point2<T>(iRectangle._P0._x, node->_location._y);
    node->_rectangles[1]._P1 = iRectangle._P1; 
  }
  else
  {
    node->_rectangles[0]._P0 = iRectangle._P0; 
    node->_rectangles[0]._P1 = Point2<T>(node->_location._x, iRectangle._P1._y);
    node->_rectangles[1]._P0 = Point2<T>(node->_location._x, iRectangle._P0._y);
    node->_rectangles[1]._P1 = iRectangle._P1; 
  }
  
  // Two Hyperrectangeles - we need additional two points to
  // identify them. X direction: Top left of the left and bottom right
  // of the right rectangles.
  // Y direction: Top left of the top and bottom right of the bottom rectangles
  // Y direction runs from top to bottom
  node->_pLeft = elxBuildKDTree(node, iBegin, iBegin + median, 
    node->_rectangles[0], iDepth + 1);
  node->_pRight = elxBuildKDTree(node, iBegin + median + 1, iEnd, 
    node->_rectangles[1], iDepth + 1); 

  return node;

} // elxBuildKDTree


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
// elxGetChildrenNeighbors
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T> 
void elxGetChildrenNeighbors(const KDNode<T>* iNode, const Point2<T>& iPoint, 
  std::list<Neighbor<T> >& oNeighbors, uint32 iNumber, uint32 iDepth)
{
  if (iNode == 0)
    return;
    
  T distance = elxSqrt(elxGetDistanceSqr(iPoint, iNode->_location));
  typename std::list<Neighbor<T> >::iterator it = oNeighbors.begin();
  typename std::list<Neighbor<T> >::iterator end = oNeighbors.end();
  bool inserted = false;
  uint32 number = 0;
  for (; it != end && number < iNumber; ++it, ++number)
  {
    if (distance < it->_distance && !inserted)
    {
      it = oNeighbors.insert(it, Neighbor<T>(iNode->_location, distance));
      ++number;
      inserted = true;
    }
  }
  if (number < iNumber && !inserted)
    it = oNeighbors.insert(it, Neighbor<T>(iNode->_location, distance));
    
  if (it != oNeighbors.begin())
  {
    --it; 
    // Check left
    if (elxIntersectCircleRectangle(iNode->_rectangles[0], iPoint, 
        it->_distance))
      elxGetChildrenNeighbors(iNode->_pLeft, iPoint, oNeighbors, iNumber, iDepth + 1); 
    // Check right 
    if (elxIntersectCircleRectangle(iNode->_rectangles[1], iPoint, it->_distance))
      elxGetChildrenNeighbors(iNode->_pRight, iPoint, oNeighbors, iNumber, iDepth + 1); 
  }

} // elxGetChildrenNeighbors


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
// elxGetNeighbor 
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
// recursive function to find a given number (N) of nearest 
// neighbors of a given target point not in the tree. 
// To perform the NN calculation, the tree is searched in a depth-first fashion, 
// refining the distance between a point and Nth fartherst neighbor. 
// First the root node is examined with an initial assumption that the smallest 
// distance to the next point is infinite. The subdomain (right or left), 
// which is a hyperrectangle, containing the target point is searched. 
// This is done recursively until a final minimum region containing the node 
// is found. The algorithm then (through recursion) examines each parent node, 
// seeing if it is possible for the other domain to contain a point that is 
// closer. This is performed by testing for the possibility of intersection 
// between the hyperrectangle and the hypersphere (formed by target node and 
// current minimum radius). If the rectangle that has not been recursively 
// examined yet does not intersect this sphere, then there is no way that 
// the rectangle can contain a point that is a better nearest neighbor. 
// This is repeated until all domains are either searched or discarded, 
// thus leaving the nearest neighbor as the final result. 
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T> 
void elxGetNeighbors(const KDNode<T>* iNode, const Point2<T>& iPoint, 
  std::list<Neighbor<T> >& oNeighbors, uint32 iNumber, uint32 iDepth)
{
  if (iNode == 0)
    return;
   
  T distance = elxSqrt(elxGetDistanceSqr(iPoint, iNode->_location));
  
  // oNeighbors contains points sorted by distance to a given point ascending
  typename std::list<Neighbor<T> >::iterator it = oNeighbors.begin();
  typename std::list<Neighbor<T> >::iterator end = oNeighbors.end();
  bool inserted = false;
  uint32 number = 0;
  for (; it != end && number < iNumber; ++it, ++number)
  {
    if (distance < it->_distance && !inserted)
    {
      it = oNeighbors.insert(it, Neighbor<T>(iNode->_location, distance));
      ++number;
      inserted = true;
    }
  }
  if (number < iNumber && !inserted)
    it = oNeighbors.insert(it, Neighbor<T>(iNode->_location, distance));
  
  bool goLeft = false;
  if (iDepth & 1) // Y
  {
    if (iPoint._y < iNode->_location._y)
      goLeft = true;
  }
  else  // X
  {
    if (iPoint._x < iNode->_location._x)
      goLeft = true;
  } 
  // Keep going farther to find a smallest hyperrectanle which 
  // contains the point 
  elxGetNeighbors((goLeft)? iNode->_pLeft : iNode->_pRight, 
    iPoint, oNeighbors, iNumber, iDepth + 1);
  
  // Check the other branch for NN
  
  // need to pick left or right rectangle by checking the intersection
  // of the hyperrectangle we didn't traverse yet and a sphere with radius
  // equal to a distance from a given point to the iNumber neighbor 
  // (iterator it points just one after it)
  if ( it != oNeighbors.begin() && elxIntersectCircleRectangle(
      (goLeft)?iNode->_rectangles[1] :iNode->_rectangles[0], iPoint, 
      (--it)->_distance))  
    elxGetChildrenNeighbors((goLeft)? iNode->_pRight : iNode->_pLeft,  
      iPoint, oNeighbors, iNumber, iDepth + 1);
      
  return;

} // elxGetNeighbors

} //namespace 


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//  Class constructor              
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T> 
KDTree<T>::KDTree (const Point2<T>* iPoints, uint32 iSize, T iWidth, T iHeight) :
  _spKDRoot(new KDNode<T>())
{
  if (iSize == 0)
    return;
    
  /// Vector to hold all tree points sorted along the X/Y-coordinate
  std::vector<Point2<T> > points(iPoints, iPoints + iSize);      
  std::sort(points.begin(), points.end(), elxCompPoint2X<T>());
  
  // Starting with X
  uint32 median = iSize/2;
  uint32 depth = 1;
  _spKDRoot->_pParent = 0;
  _spKDRoot->_location = points[median];
  
  // Each tree point has two Hyperrectangeles (left and right for X and
  // top and bottom for Y) associated with it. In order to identify them
  // in addition to the point's location we need two more points. 
  // For X direction: Top left of the left and bottom right of the right rectangles.
  // For Y direction: Top left of the top and bottom right of the bottom rectangles
  _spKDRoot->_rectangles[0]._P0 = Point2<T>(T(), T());
  _spKDRoot->_rectangles[0]._P1 = Point2<T>(_spKDRoot->_location._x, iHeight);
  _spKDRoot->_rectangles[1]._P0 = Point2<T>(_spKDRoot->_location._x, T());
  _spKDRoot->_rectangles[1]._P1 = Point2<T>(iWidth, iHeight);
  
  _spKDRoot->_pLeft = elxBuildKDTree(_spKDRoot.get(), points.begin(), 
   points.begin()+median, _spKDRoot->_rectangles[0], depth);
  _spKDRoot->_pRight = elxBuildKDTree(_spKDRoot.get(), points.begin()+median+1,
    points.end(), _spKDRoot->_rectangles[1], depth);
}

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//   KDTree<T>::GetNeighbors                 
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T> 
void KDTree<T>::GetNeighbors(const Point2<T>& iPoint, uint32 iNumber, 
    std::vector<Point2<T> >& oNeighbors) const
{
  uint32 depth = 0;
  oNeighbors.clear();
  // list to maintain a list of closest points. The first iNumber
  // elements a closest points to a given point.
  std::list<Neighbor<T> > neighbors;
  elxGetNeighbors(_spKDRoot.get(), iPoint, neighbors, iNumber, depth);
  typename std::list<Neighbor<T> >::iterator it = neighbors.begin();
  typename std::list<Neighbor<T> >::iterator end = neighbors.end();
  for (uint32 count = 0; count < iNumber && it != end; ++it, ++count)
    oNeighbors.push_back(it->_point);

} // GetNeighbors


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//   KDTree<T>::GetNeighbor                 
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T> 
bool KDTree<T>::GetNeighbor(
  const Point2<T>& iPoint, Point2<T>& oNeighbor, T& oDistance) const
{
  uint32 depth = 0;
  std::list<Neighbor<T> > neighbors;
  elxGetNeighbors(_spKDRoot.get(), iPoint, neighbors, 1, depth);
  bool result = !neighbors.empty();
  if (result)
  {
    const Neighbor<T>& neighbor = neighbors.front();
    oNeighbor = neighbor._point;
    oDistance = neighbor._distance;
  }
  return result;

} // GetNeighbor

} // namespace Math
} // namespace eLynx

#endif // __KDTree_hpp__
