//============================================================================
//  GaussNewton.cpp                                     Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/math/GaussNewton.h>
#include <elx/math/Vector.h>
#include <elx/math/Matrix.h>
#include <elx/math/TransposedMatrix.h>
#include <elx/math/LeastSquares.h>

#include <stdio.h>

namespace eLynx {
namespace Math {
  
//----------------------------------------------------------------------------
// perform the non-linear curve fitting

void GaussNewton::FitParams(const IFunctionNL &iFunction, 
  const IMatrix &iSamples, const IVector &iInitialGuess, IVector &oParams,
  double iEpsilon, uint32 iMaxIterations)
{
  // check inputs for errors
  CheckInputs(iFunction, iSamples, iInitialGuess, oParams);

  // prepare the parameters for iteration and parameters delta vector
  Vector results(iInitialGuess);
  Vector delta(results.GetSize());
  
  uint32 iter = 0;
  double dl;
    
  do {
    
    // compute delta vector for this iteration step
    ComputeDeltaVector(iFunction, iSamples, results, delta);
    
    // compute delta vector initial length
    dl = delta.GetLength();
    
    // if the delta is big enough, add it to the results
    if (dl >= iEpsilon) {
      for (uint32 i = 0; i < results.GetSize(); i++)
        results(i) += delta(i);
    }
    
    iter++;
    if (iMaxIterations > 0 && iter > iMaxIterations) break;
    
  // continue the iteration until the delta remains stable
  } while (dl >= iEpsilon);
  
  // fill in the results
  for (uint32 i = 0; i < results.GetSize(); i++)
    oParams(i) = results(i);
  
}

//----------------------------------------------------------------------------
// checks the inputs

void GaussNewton::CheckInputs(const IFunctionNL &iFunction, 
  const IMatrix &iSamples, const IVector &iInitialGuess, IVector &oParams)
{
  // check if number of variables match width of matrix of samples 
  if (iFunction.GetVariablesCount()+1 != iSamples.GetWidth()) 
    elxThrow(elxErrInvalidParams, elxMsgFormat("Samples (%i-1) does not match "
      "the number of function variables (%i).", iSamples.GetWidth(),
      iFunction.GetVariablesCount()));
      
  // check if size of initial guess match the number of function params
  if (iFunction.GetParametersCount() != iInitialGuess.GetSize())
    elxThrow(elxErrInvalidParams, elxMsgFormat("Number of parameters in the "
      "initial guess (%i) does not match the number of function parameters (%i).",
      iInitialGuess.GetSize(), iFunction.GetParametersCount()));
  
  /// check if size of result vector match the number of function params
  if (iFunction.GetParametersCount() != oParams.GetSize())
    elxThrow(elxErrInvalidParams, elxMsgFormat("Number of parameters in the "
      "result vector (%i) does not match the number of function parameters (%i).",
      oParams.GetSize(), iFunction.GetParametersCount()));
}

//----------------------------------------------------------------------------
// computes the delta vector for actual iteration

void GaussNewton::ComputeDeltaVector(const IFunctionNL &iFunction, 
    const IMatrix &iSamples, const IVector &iParams, IVector &oDelta)
{
  // prepare linear system matrix and right side vector
  Matrix J(iSamples.GetHeight(), iParams.GetSize());
  Vector F(iSamples.GetHeight());
  
  // compute values
  ComputeJacobianAndDiffs(iFunction, iSamples, iParams, J, F);
  
  // solve by least squares
  LeastSquares::Solve(J, F, oDelta);

}

//----------------------------------------------------------------------------
// compute the coefficients for linear system to compute delta vector

void GaussNewton::ComputeJacobianAndDiffs(const IFunctionNL &iFunction,
    const IMatrix &iSamples, const IVector &iParams, IMatrix &oJacobian,
    IVector &oDiffs)
{
  // prepare vector of variables
  Vector vars(iFunction.GetVariablesCount());
  
  // go through each sample
  for (uint32 sample = 0; sample < iSamples.GetHeight(); sample++) {
    
    // fill in the vector of variables
    for (uint32 var = 0; var < iFunction.GetVariablesCount(); var++)
      vars(var) = iSamples(sample, var);
    
    // evaluate jacobian (derivatives by different params)
    for (uint32 param = 0; param < iParams.GetSize(); param++) 
      oJacobian(sample, param) = 
        iFunction.EvalDerivativeByParam(vars, iParams, param);
      
    // evaluate difference between sample and function
    oDiffs(sample) = -(iFunction.Evaluate(vars, iParams) - 
      iSamples(sample, iSamples.GetWidth()-1));
      
  }
}

//----------------------------------------------------------------------------

} // namespace Math
} // namespace eLynx
