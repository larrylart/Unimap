//============================================================================
//  ResampleFilterImpls.cpp                             Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <map>
#include <string>

#include <elx/core/CoreMacros.h>
#include <elx/math/ResampleFilterImpls.h>
#include <elx/math/MathCore.h>

namespace eLynx {
namespace Math {

IResampleFilter::~IResampleFilter(){}

//----------------------------------------------------------------------------
//  BoxFilter: pulse, Fourier window, 1st order (constant) b-spline
//----------------------------------------------------------------------------
double BoxFilter::GetRadius() const { return 0.5; }
double BoxFilter::GetValue(double iX) const
{
  if (iX < 0) iX = -iX;
  if (iX <= 0.5) return 1.0;
  return 0.0;
}
static BoxFilter s_BoxFilter;


//----------------------------------------------------------------------------
//  TriangleFilter: Bartlett window, 2nd order (linear) b-spline
//----------------------------------------------------------------------------
double TriangleFilter::GetRadius() const { return 1.0; }
double TriangleFilter::GetValue(double iX) const
{
  if (iX < 0.0) iX = -iX;
  if (iX < 1.0) return (1.0 - iX);
  return 0.0;
}
static TriangleFilter s_TriangleFilter;


//----------------------------------------------------------------------------
//  HermiteFilter
//----------------------------------------------------------------------------
double HermiteFilter::GetRadius() const { return 1.0; }
double HermiteFilter::GetValue(double iX) const
{
  if (iX < 0.0) iX = -iX;
  if (iX < 1.0) return ((2.0*iX - 3.0)*iX*iX + 1.0);
  return 0.0;
}
static HermiteFilter s_HermiteFilter;

//----------------------------------------------------------------------------
//  BellFilter
//----------------------------------------------------------------------------
double BellFilter::GetRadius() const { return 1.5; }
double BellFilter::GetValue(double iX) const
{
  if (iX < 0.0) iX = -iX;
  if (iX <= 0.5) return (0.75 - iX*iX);
  if (iX <= 1.5) return (0.5*iX*iX - 1.5*iX + 1.125);
  return 0.0;
}
static BellFilter s_BellFilter;

//----------------------------------------------------------------------------
//  CubicBSplineFilter:  4th order (cubic) b-spline
//----------------------------------------------------------------------------
double CubicBSplineFilter::GetRadius() const { return 2.0; }
double CubicBSplineFilter::GetValue(double iX) const
{
  if (iX < 0.0) iX = -iX;
  if (iX < 1.0) 
  {
    const double x2 = iX*iX;
    return (0.5*x2*iX - x2 + 2.0/3.0);
  }
  if (iX < 2.0) 
  {
    iX = 2.0 - iX;
    return (pow(iX, 3.0)/6.0);
  }
  return 0.0;
}
static CubicBSplineFilter s_CubicBSplineFilter;

//----------------------------------------------------------------------------
static double Sinc(double iX)
{
  if (iX == 0.0) return 1;
  iX *= M_PI;
  return (sin(iX)/iX);
}

//----------------------------------------------------------------------------
//  Lanczos3Filter
//----------------------------------------------------------------------------
double Lanczos3Filter::GetRadius() const { return 3.0; }
double Lanczos3Filter::GetValue(double iX) const
{
  if (iX < 0.0) iX = -iX;
  if (iX < 3.0) return (Sinc(iX)*Sinc(iX/3.0));
  return 0.0;
}
static Lanczos3Filter s_Lanczos3Filter;

//----------------------------------------------------------------------------
//  Lanczos5Filter
//----------------------------------------------------------------------------
double Lanczos5Filter::GetRadius() const { return 5.0; }
double Lanczos5Filter::GetValue(double iX) const
{
  if (iX < 0.0) iX = -iX;
  if (iX < 5.0) return (Sinc(iX)*Sinc(iX/5.0));
  return 0.0;
}
static Lanczos5Filter s_Lanczos5Filter;
//----------------------------------------------------------------------------
//  Lanczos8Filter
//----------------------------------------------------------------------------
double Lanczos8Filter::GetRadius() const { return 8.0; }
double Lanczos8Filter::GetValue(double iX) const
{
  if (iX < 0.0) iX = -iX;
  if (iX < 8.0) return (Sinc(iX)*Sinc(iX/8.0));
  return 0.0;
}
static Lanczos8Filter s_Lanczos8Filter;

//----------------------------------------------------------------------------
//  MitchellFilter
//----------------------------------------------------------------------------
double MitchellFilter::GetRadius() const { return 2.0; }
double MitchellFilter::GetValue(double iX) const
{
  const double C = 1.0/3.0;
  if (iX < 0.0) iX = -iX;
  const double x2 = iX*iX;
  if (iX < 1.0) 
  {
    iX = (((12.0 - 9.0*C - 6.0*C)*(iX*x2)) + ((-18.0 + 12.0*C + 6.0*C)*x2) + (6.0 - 2.0*C));
    return (iX/6.0);
  }
  if (iX < 2.0) 
  {
    iX = (((-C -6.0*C)*(iX*x2)) + ((6.0*C + 30.0*C)*x2) + ((-12.0*C -48.0*C)*iX) + (8.0*C + 24.0*C));
    return (iX/6.0);
  }
  return 0.0;
}
static MitchellFilter s_MitchellFilter;

//----------------------------------------------------------------------------
//  CosineFilter
//----------------------------------------------------------------------------
double CosineFilter::GetRadius() const { return 1.0; }
double CosineFilter::GetValue(double iX) const
{
  if ((iX >= -1.0) && (iX <= 1.0)) 
    return (0.5*(1.0 + cos(iX*M_PI)));
  return 0.0;
}
static CosineFilter s_CosineFilter;

//----------------------------------------------------------------------------
//  CatmullRomFilter
//----------------------------------------------------------------------------
double CatmullRomFilter::GetRadius() const { return 2.0; }
double CatmullRomFilter::GetValue(double iX) const
{
  if (iX < 0.0) iX = -iX;
  const double x2 = iX*iX;
  if (iX <= 1.0) return ( 1.5*x2*iX - 2.5*x2 + 1.0);
  if (iX <= 2.0) return (-0.5*x2*iX + 2.5*x2 - 4.0*iX + 2.0);
  return 0.0;
}
static CatmullRomFilter s_CatmullRomFilter;

/*
//----------------------------------------------------------------------------
//  QuadraticFilter: 3rd order (quadratic) b-spline
//----------------------------------------------------------------------------
double QuadraticFilter::GetRadius() const { return 1.5; }
double QuadraticFilter(double x)::GetValue(double iX) const
{
  double t;
  if (x<-1.5) return 0.;
  if (x<-.5) {t = x+1.5; return .5*t*t;}
  if (x<.5) return .75-x*x;
  if (x<1.5) {t = x-1.5; return .5*t*t;}
  return 0.;
}
static QuadraticFilter s_QuadraticFilter;
*/
//----------------------------------------------------------------------------
//  QuadraticFilter
//----------------------------------------------------------------------------
double QuadraticFilter::GetRadius() const { return 1.5; }
double QuadraticFilter::GetValue(double iX) const
{
  if (iX < 0.0) iX = -iX;
  if (iX <= 0.5) return (-2.0*iX*iX + 1.0);
  if (iX <= 1.5) return (iX*iX - 2.5*iX + 1.5);
  return 0.0;
}
static QuadraticFilter s_QuadraticFilter;


//----------------------------------------------------------------------------
//  CubicConvolutionFilter
//----------------------------------------------------------------------------
double CubicConvolutionFilter::GetRadius() const { return 3.0; }
double CubicConvolutionFilter::GetValue(double iX) const
{
  if (iX < 0.0) iX = -iX;
  const double x2 = iX*iX;
  if (iX <= 1.0) return ((4.0/3.0)*x2*iX - (7.0/3.0)*x2 + 1.0);
  if (iX <= 2.0) return (-(7.0/12.0)*x2*iX + 3.0*x2 - (59.0/12.0)*iX + 2.5);
  if (iX <= 3.0) return ((1.0/12.0)*x2*iX - (2.0/3.0)*x2 + 1.75*iX - 1.5);
  return 0.0;
}
static CubicConvolutionFilter s_CubicConvolutionFilter;


//----------------------------------------------------------------------------
//  BlackmanHarrisFilter
//----------------------------------------------------------------------------
static double BlackmanHarris(double iX)
{
  if (iX < 1e-7) return 1.0;
  iX *= M_PI;
  return ((elxSin(iX) / iX)) * 
          (0.42323 + 
           0.49755 * elxCos(iX / 3.0) + 
           0.07922 * elxCos(2.0 * iX  / 3.0));
}

double BlackmanHarrisFilter::GetRadius() const { return 6.0; }
double BlackmanHarrisFilter::GetValue(double iX) const
{
  double y = 0.0, x = fabs(iX);
  if (x < 2.5)
  {
    y = BlackmanHarris(x + 0.5);
    if (x < 1.5) y += BlackmanHarris(x + 1.5);
    if (x < 0.5) y += BlackmanHarris(x + 2.5);
  }
  return (iX > 0.0 ? 1.0 - y : y);
}
static BlackmanHarrisFilter s_BlackmanHarrisFilter;


//----------------------------------------------------------------------------
//  SincFilter
//----------------------------------------------------------------------------
double SincFilter::GetRadius() const { return 4.0; }
double SincFilter::GetValue(double iX) const
{
  if (iX == 0.0) return 1.0;
  iX *= M_PI;
  return sin(iX) / iX;
}
static SincFilter s_SincFilter;


//----------------------------------------------------------------------------
//  HanningFilter
//----------------------------------------------------------------------------
double HanningFilter::GetRadius() const { return 1.0; }
double HanningFilter::GetValue(double iX) const
{
  return 0.5 + 0.5*cos(M_PI*iX);
}
static HanningFilter s_HanningFilter;


//----------------------------------------------------------------------------
//  HammingFilter
//----------------------------------------------------------------------------
double HammingFilter::GetRadius() const { return 1.0; }
double HammingFilter::GetValue(double iX) const
{
  return 0.54 + 0.46*cos(M_PI*iX);
}
static HammingFilter s_HammingFilter;


//----------------------------------------------------------------------------
//  BlackmanFilter
//----------------------------------------------------------------------------
double BlackmanFilter::GetRadius() const { return 1.0; }
double BlackmanFilter::GetValue(double iX) const
{
  return (0.42 + 0.5*cos(M_PI*iX) + 0.08*cos(M_2PI*iX));
}
static BlackmanFilter s_BlackmanFilter;


//----------------------------------------------------------------------------
//  GaussianFilter
//----------------------------------------------------------------------------
static const double s_sqrt2oPI(sqrt(2.0/M_PI));
double GaussianFilter::GetRadius() const { return 1.25; }
double GaussianFilter::GetValue(double iX) const
{
  return exp(-2.0*iX*iX) * s_sqrt2oPI;
}
static GaussianFilter s_GaussianFilter;

//----------------------------------------------------------------------------
//  elxToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const char * elxToString(EResampleFilter iFilter)
{
  static const char * ms_lut[RF_Undefined+1] =
  {
    "Box", "Triangle", "Hermite", "Bell", "Cubic BSpline", 
    "Lanczos3", "Mitchell", "Cosine", "Catmull-Rom", "Quadratic", 
    "Cubic convolution", "Lanczos5", "Lanczos8", "Blackman-Harris",
    "Sync", "Hanning", "Hamming", "Blackman", "Gaussian",
    "Undefined"
  };
  return ms_lut[iFilter];

} // elxToString

//----------------------------------------------------------------------------
//  
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
EResampleFilter elxToEResampleFilter(const char * iprFilter)
{
  static std::map<std::string, EResampleFilter> ms_lut;
  if (ms_lut.empty())
  {
    ms_lut.insert(make_pair(std::string("RF_Box"), RF_Box));
    ms_lut.insert(make_pair(std::string("RF_Triangle"), RF_Triangle));
    ms_lut.insert(make_pair(std::string("RF_Hermite"), RF_Hermite));
    ms_lut.insert(make_pair(std::string("RF_Bell"), RF_Bell));
    ms_lut.insert(make_pair(std::string("RF_CubicBSpline"), RF_CubicBSpline));
    ms_lut.insert(make_pair(std::string("RF_Lanczos3"), RF_Lanczos3));
    ms_lut.insert(make_pair(std::string("RF_Mitchell"), RF_Mitchell));
    ms_lut.insert(make_pair(std::string("RF_Cosine"), RF_Cosine));
    ms_lut.insert(make_pair(std::string("RF_CatmullRom"), RF_CatmullRom));
    ms_lut.insert(make_pair(std::string("RF_Quadratic"), RF_Quadratic));
    ms_lut.insert(make_pair(std::string("RF_CubicConvolution"), RF_CubicConvolution));
    ms_lut.insert(make_pair(std::string("RF_Lanczos5"), RF_Lanczos5));
    ms_lut.insert(make_pair(std::string("RF_Lanczos8"), RF_Lanczos8));
    ms_lut.insert(make_pair(std::string("RF_BlackmanHarris"), RF_BlackmanHarris));
    ms_lut.insert(make_pair(std::string("RF_Sinc"), RF_Sync));
    ms_lut.insert(make_pair(std::string("RF_Hanning"), RF_Hanning));
    ms_lut.insert(make_pair(std::string("RF_Hamming"), RF_Hamming));
    ms_lut.insert(make_pair(std::string("RF_Blackman"), RF_Blackman));
    ms_lut.insert(make_pair(std::string("RF_Gaussian"), RF_Gaussian));
    ms_lut.insert(make_pair(std::string("RF_Undefined"), RF_Undefined));
  }
  return ms_lut[std::string(iprFilter)];

} // elxToEResampleFilter

//----------------------------------------------------------------------------
// Defined in same order as in EResampleFilter declaration
//----------------------------------------------------------------------------
static const IResampleFilter * s_prResampleFilter_lut[RF_Undefined] =
{
  &s_BoxFilter,
  &s_TriangleFilter,
  &s_HermiteFilter,
  &s_BellFilter,
  &s_CubicBSplineFilter,
  &s_Lanczos3Filter,
  &s_MitchellFilter,
  &s_CosineFilter,
  &s_CatmullRomFilter,
  &s_QuadraticFilter,
  &s_CubicConvolutionFilter,
  &s_Lanczos5Filter,
  &s_Lanczos8Filter,
  &s_BlackmanHarrisFilter,
  &s_SincFilter,
  &s_HanningFilter,
  &s_HammingFilter,
  &s_BlackmanFilter,
  &s_GaussianFilter,
};

//----------------------------------------------------------------------------
//  elxGetResampleFilter
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
const IResampleFilter& elxGetResampleFilter(EResampleFilter iFilter)
{
  elxASSERT(RF_Undefined != iFilter);
  return *s_prResampleFilter_lut[iFilter];
}

// Window functions to add: 
// Kaiser, Kaiser-Bessel, Dolph-Chebyshev, Bohman, Cauchy, 
// HannPoisson, Poisson, Reisz, Riemann, Turkey, VallePoussin
// http://www.dsprelated.com/dspbooks/sasp/Spectrum_Analysis_Windows.html

} // namespace Math
} // namespace eLynx
