//============================================================================
//  Matrix.cpp                                          Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/math/SubMatrix.h>

namespace eLynx {
namespace Math {
	
//----------------------------------------------------------------------------
// constructor, creates submatrix for specified matrix

SubMatrix::SubMatrix(IMatrix &iMatrix, 
	uint32 iRow1, uint32 iNRows, uint32 iCol1, uint32 iNCols)
	: _prMatrix(iMatrix)
{
	_Row1 = iRow1;
	_NRows = iNRows;
	_Col1 = iCol1;
	_NCols = iNCols;
}

		
//----------------------------------------------------------------------------
// copy constructor

SubMatrix::SubMatrix(const SubMatrix &iC)
	: _prMatrix(iC._prMatrix)
{
	CopyData(iC);
}

		
//----------------------------------------------------------------------------
// an assignement operator

SubMatrix& SubMatrix::operator = (const SubMatrix &iC)
{
	if (&iC != this) CopyData(iC);
	return *this;
}

		
//----------------------------------------------------------------------------
// submatrix content access operator (const version)

const double& SubMatrix::operator () (uint32 iRow, uint32 iCol) const
{
	if (iRow >= GetHeight())
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Row index %i is out of range <0, %i>.", 
				iRow, GetHeight()-1));
				
	if (iCol >= GetWidth())
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Col index %i is out of range <0, %i>.", 
				iCol, GetWidth()-1));
				
	return _prMatrix(_Row1+iRow, _Col1+iCol);
}

		
//----------------------------------------------------------------------------
// submatrix content access operator

double& SubMatrix::operator () (uint32 iRow, uint32 iCol)
{
	if (iRow >= GetHeight())
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Row index %i is out of range <0, %i>.", 
				iRow, GetHeight()-1));
				
	if (iCol >= GetWidth())
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Col index %i is out of range <0, %i>.", 
				iCol, GetWidth()-1));
				
	return _prMatrix(_Row1+iRow, _Col1+iCol);
}

		
//----------------------------------------------------------------------------
// swaps submatrix rows

void SubMatrix::SwapRows(uint32 iRow1, uint32 iRow2)
{
	if (iRow1 == iRow2) return;
	for (uint32 c = 0; c < GetWidth(); c++) {
		double tmp = (*this)(iRow1, c);
		(*this)(iRow1, c) = (*this)(iRow2, c);
		(*this)(iRow2, c) = tmp;
	}
}

		
//----------------------------------------------------------------------------
// swaps submatrix columns

void SubMatrix::SwapCols(uint32 iCol1, uint32 iCol2)
{
	if (iCol1 == iCol2) return;
	for (uint32 r = 0; r < GetHeight(); r++) {
		double tmp = (*this)(r, iCol1);
		(*this)(r, iCol1) = (*this)(r, iCol2);
		(*this)(r, iCol2) = tmp;
	}
}

		
//----------------------------------------------------------------------------
// copies object data

void SubMatrix::CopyData(const SubMatrix &iC)
{
	_prMatrix = iC._prMatrix;
	_Row1  = iC._Row1;
	_NRows = iC._NRows;
	_Col1 = iC._Col1;
	_NCols = iC._NCols;
}

		
//----------------------------------------------------------------------------

} // namespace Math
} // namespace eLynx
