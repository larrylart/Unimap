//============================================================================
//  TransfertFunction.cpp                               Math.Component package
//============================================================================
//  Usage : 
//  http://pirate.shu.edu/~wachsmut/Java/IRA/PlotFamily.html
//  http://www.mathcurve.com/
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreConversion.h>
#include <elx/math/TransfertFunction.h>
#include <elx/math/Ramp.h> 
#include "math.h"

namespace eLynx {
namespace Math {

static const int32 n_ushort = 1<<16;
static const double dbMax = 255.0;
static const double dsMax = 65535.0;
static const int32 half_ushort = n_ushort>>1;

class ExportedByMath GreyRamp16To8
{
public:
  GreyRamp16To8() { Reset(); }

  void Reset()
  {
    uint8 * p = GetFirst();
    for (int32 i=0; i<n_ushort; i++)
      *p++ = (uint8)(i>>8);
  }

  void Gamma(double iGamma, double iLow=0.0, double iHigh=1.0)
  {
    // --- check parameters ---
    if (iLow == iHigh)
      return;

    bool bNegative = false;
    if (iHigh < iLow) 
    {
      double temp = iLow;
      iLow = iHigh;
      iHigh = temp;
      bNegative = true;
    }
    if (iLow < 0.0)  iLow = 0.0;
    if (iLow > 1.0)  iLow = 1.0;
    if (iHigh > 1.0) iHigh = 1.0;

    const double c = 1.0 / (iHigh - iLow);
    if (c <= 0.0)
      return;

    double dc;
    int32 ic;
    uint8 * p = GetFirst();

    uint16 lo = elxToINT16Scaled(iLow);
    uint16 hi = elxToINT16Scaled(iHigh);

    for (int32 i=0; i<n_ushort; i++, p++)
    {
      if (i <= lo)
        *p = uint8MIN;
      else if (i >= hi)
        *p = uint8MAX;
      else
      {
        dc = double(i)/dsMax;          // [iLow, iHigh] linear
        dc = c * (dc - iLow);          // [0.0, 1.0] linear
        dc = ::pow(dc, iGamma);        // [0.0, 1.0] power
        ic = int32(dbMax * dc + 0.5) ;

        // --- clamps and saves ---
        if (ic < uint8MIN)      *p = uint8MIN; 
        else if (ic > uint8MAX) *p = uint8MAX;
        else                    *p = uint8(ic);
      }
    }

    if (bNegative)
    {
      uint8 * p = GetFirst();
      for (int32 i=0; i<n_ushort; i++)
      { 
        *p = ~(*p);
        ++p;
      }
    }
  }


  uint8 Pick(uint16 iIntensity) const { return _lut[iIntensity]; }
  const uint8 * GetLookUpTable() const { return &_lut[0]; }

  void Transform(uint8 * iprDst, const uint16 * iprSrc, uint32 iSize) const
  {
    if ((NULL == iprDst) || (NULL == iprSrc) || (0 == iSize)) return;
    uint8 * prEnd = iprDst + iSize;
    do { *iprDst = _lut[*iprSrc++]; } while (++iprDst < prEnd);
  }

private:
  // note that this pointer can't be NULL, no need to check it !
  uint8 * GetFirst() { return &_lut[0]; }
  uint8 _lut[1<<16];
};



//----------------------------------------------------------------------------
IMapTransform::~IMapTransform() {}
ITransfertFunction::~ITransfertFunction() {}
//----------------------------------------------------------------------------
AbstractTransfertFunction::AbstractTransfertFunction(double iLow, double iHigh) :  _low(iLow), _high(iHigh) {}
AbstractTransfertFunction::~AbstractTransfertFunction() {}
void AbstractTransfertFunction::Release() { delete this; }
void AbstractTransfertFunction::SetRange(double iLow, double iHigh) { SetLow(iLow);  SetHigh(iHigh); }
void AbstractTransfertFunction::SetLow(double iLow)
{
  if (iLow < 0.0) iLow = 0.0; else if (iLow > 1.0) iLow = 1.0;
  _low = iLow;
}
void AbstractTransfertFunction::SetHigh(double iHigh)
{
  if (iHigh < 0.0) iHigh = 0.0; else if (iHigh > 1.0) iHigh = 1.0;
  _high = iHigh;
}
double AbstractTransfertFunction::GetLow() const { return _low; }
double AbstractTransfertFunction::GetHigh() const { return _high; }




//----------------------------------------------------------------------------
//  TransfertFunctionCopy
//----------------------------------------------------------------------------
TransfertFunctionCopy::TransfertFunctionCopy() : AbstractTransfertFunction(), _transformation(){}
TransfertFunctionCopy::~TransfertFunctionCopy() {}
void TransfertFunctionCopy::SetRange(double, double){}
bool TransfertFunctionCopy::IsSupported(EResolution iResolution) const
{ return _transformation.IsSupported(RT_UINT8, iResolution); }

bool TransfertFunctionCopy::Transform(
    uint8 * iprDest, const void * iprSrc, uint32 iSize,
    EResolution iResolution) const
{ return _transformation.Transform(iprDest, RT_UINT8, iprSrc, iResolution, iSize); }

//----------------------------------------------------------------------------
//  TransfertFunctionGamma
//----------------------------------------------------------------------------
TransfertFunctionGamma::TransfertFunctionGamma(double iLow, double iHigh, double iGamma) :
    AbstractTransfertFunction(iLow, iHigh), _transformation(iLow, iHigh, iGamma){}
TransfertFunctionGamma::~TransfertFunctionGamma(){}
void TransfertFunctionGamma::SetRange(double iLow, double iHigh)
{
  AbstractTransfertFunction::SetRange(iLow, iHigh);
  _transformation.SetLow(iLow);
  _transformation.SetHigh(iHigh);
}
bool TransfertFunctionGamma::IsSupported(EResolution iResolution) const
{ return _transformation.IsSupported(RT_UINT8, iResolution); }

bool TransfertFunctionGamma::Transform(uint8 * iprDest,const void * iprSrc, uint32 iSize, EResolution iResolution) const
{ return _transformation.Transform(iprDest, RT_UINT8, iprSrc, iResolution, iSize); }
void TransfertFunctionGamma::SetParam(double iGamma) { _transformation.SetParam(iGamma); }
double TransfertFunctionGamma::GetParam() const { return _transformation.GetParam(); }

GammaTransform::GammaTransform(double iLow, double iHigh, double iGamma) : 
    IMapTransform(),  _low(iLow),   _high(iHigh),  _gamma(iGamma){}
GammaTransform::~GammaTransform() {}
void GammaTransform::SetLow(double iLow) { _low = iLow; } 
void GammaTransform::SetHigh(double iHigh) {_high = iHigh; } 

void GammaTransform::SetParam(double iGamma)
{
  if (iGamma < 0.1) iGamma = 0.1; else if (iGamma > 4.0) iGamma = 4.0;
  _gamma = iGamma;
}

bool GammaTransform::IsSupported(EResolution iDestination, EResolution iSource) const
{
  if ((RT_INT32 == iSource) || (RT_INT32 == iDestination))
    return false;
  return true;
}

bool GammaTransform::Transform( void * iprDst, EResolution iDst,
    const void * iprSrc, EResolution iSrc, uint32 iSize ) const
{
  if ((NULL == iprDst) || (NULL == iprSrc) || (0 == iSize))
    return false;

  if (_high == _low)
    return false;

  if (!IsSupported(iDst, iSrc))
    return false;

  switch(iDst)
  {
    case RT_UINT8:
    {
      uint8 * prDst = (uint8*)iprDst;
      switch(iSrc)
      {
        case RT_UINT8:    return Do(prDst, (const uint8*)iprSrc, iSize);
        case RT_UINT16:   return Do(prDst, (const uint16*)iprSrc, iSize);
        case RT_INT32:  return Do(prDst, (const int32*)iprSrc, iSize);
        case RT_Float:    return Do(prDst, (const float*)iprSrc, iSize);
        case RT_Double:   return Do(prDst, (const double*)iprSrc, iSize);
        default: return false;
      }
    }
    case RT_UINT16:
    {
      uint16 * prDst = (uint16*)iprDst;
      switch(iSrc)
      {
        case RT_UINT8:    return Do(prDst, (const uint8*)iprSrc, iSize);
        case RT_UINT16:   return Do(prDst, (const uint16*)iprSrc, iSize);
        case RT_INT32:  return Do(prDst, (const int32*)iprSrc, iSize);
        case RT_Float:    return Do(prDst, (const float*)iprSrc, iSize);
        case RT_Double:   return Do(prDst, (const double*)iprSrc, iSize);
        default:  return false;
      }
    }
    default: return false;
  }

  return false;
}

bool GammaTransform::Do(uint8 * iprDst, const uint8 * iprSrc, uint32 iSize) const
{
  Ramp<uint8> ms_ramp;
  ms_ramp.Gamma( _gamma, _low, _high);
  ms_ramp.Transform(iprDst, iprSrc, iSize);
  return true;
}
bool GammaTransform::Do(uint8 * iprDst, const uint16 * iprSrc, uint32 iSize) const
{
#if 0
  GreyRamp16To8 ms_ramp;
  ms_ramp.Gamma(_gamma, _low, _high);
  ms_ramp.Transform(iprDst, iprSrc, iSize);
#else
  // optimization : if size > 65000 transform from a look-up table
  const float g = float(_gamma);

  if (iSize < 65000)
  {
    uint8 * prEnd = iprDst + iSize;
    uint16 v;
    float f;
    if (_low > _high)
    {
      uint16 lo = elxToINT16(_high); 
      uint16 hi = elxToINT16(_low);
      const float a = 1.0f / float(hi-lo);
      do
      {
        v = *iprSrc++;
        if (v <= lo)          *iprDst = uint8MAX;
        else if (v >= hi)     *iprDst = uint8MIN;
        else
        {
          f = a * (v - lo);     // [0.0, 1.0] linear
          f = ::powf(f, g);     // [0.0, 1.0] power is gamma function
          *iprDst = ~uint8(uint8MAX * f + 0.5f);
        }
      }
      while (++iprDst < prEnd);
    }
    else
    {
      uint16 lo = elxToINT16(_low); 
      uint16 hi = elxToINT16(_high);
      const float a = 1.0f / float(hi-lo);
      do
      {
        v = *iprSrc++;
        if (v <= lo)          *iprDst = uint8MIN;
        else if (v >= hi)     *iprDst = uint8MAX;
        else
        {
          f = a * (v - lo);     // [0.0, 1.0] linear
          f = ::powf(f, g);     // [0.0, 1.0] power is gamma function
          *iprDst = uint8(uint8MAX * f + 0.5f);
        }
      }
      while (++iprDst < prEnd);
    }
  }
  else
  {
    // optimization : compute table only then gamma value changes 
    static double ms_oldGamma = -1.0;
    static double ms_oldLow   = -1.0;
    static double ms_oldHigh  = -1.0;
    static uint8 ms_lookupTable[1<<16];
    if ((ms_oldGamma != _gamma) || (ms_oldLow != _low) || (ms_oldHigh != _high))
    {
      ms_oldGamma = _gamma;
      ms_oldLow = _low;
      ms_oldHigh = _high;

      // build look-up table
      uint16 lo = elxToINT16(_low); 
      uint16 hi = elxToINT16(_high);
      bool bNegative = false;
      if (lo > hi)
      {
        uint16 tmp = lo; lo = hi, hi = tmp;
        bNegative = true;
      }

      uint8 * prDst = ms_lookupTable;
      uint8 * prEnd = prDst + (1<<16);
      uint16 v = 0;
      float f;
      const float a = 1.0f / float(hi-lo);
      do
      {
        if (v <= lo)      *prDst = uint8MIN;
        else if (v >= hi) *prDst = uint8MAX;
        else
        {
          f = a * (v - lo);     // [0.0, 1.0] linear
          f = ::powf(f, g);     // [0.0, 1.0] power is gamma function
          *prDst = uint8(uint8MAX * f + 0.5f);
        }
        v++;
      }
      while (++prDst < prEnd);

      if (bNegative)
      {
        prDst = ms_lookupTable;
        prEnd = prDst + (1<<16);
        do { *prDst = ~*prDst; } while (++prDst < prEnd);
      }

      // transform using look-up table
      const uint8 * prTable = &ms_lookupTable[0];
      prEnd = iprDst + iSize;
      do 
      { 
        *iprDst = prTable[*iprSrc++];
      } 
      while (++iprDst < prEnd);
    }
  }
#endif
  return true;
}

bool GammaTransform::Do(uint8 * iprDst, const int32 * iprSrc, uint32 iSize) const
{
  return true;
}

//----------------------------------------------------------------------------
//  float => uint8
//----------------------------------------------------------------------------
bool GammaTransform::Do(uint8 * iprDst, const float * iprSrc, uint32 iSize) const
{
  uint8 * prEnd = iprDst + iSize;

  bool bNegative = false;
  float high = (float)_high;
  float low = (float)_low;
  const float gamma =  (float)_gamma;
  if (high < low) 
  {
    low = (float)_high;
    high = (float)_low;
    bNegative = true;
  }

  const float a = 1.0f / (high - low);
  float d;
  int32 i;

  if (bNegative)
  {
    do
    {
      d = *iprSrc++;                   
      if (d <= low)        *iprDst = 255;
      else if (d >= high)  *iprDst = 0;
      else                  
      {
        d = a * (d - low);       // [0.0, 1.0] linear
        d = ::powf(d, gamma);    // [0.0, 1.0] power is gamma function
        i = int32(255.0f * d + 0.5f);

        // --- clamps, negates and saves ---
        if (i < 0)         *iprDst = 255; 
        else if (i > 255)  *iprDst = 0;
        else               *iprDst = 255-uint8(i);
      }
    }
    while (++iprDst < prEnd);
  }
  else
  {
    do
    {
      d = *iprSrc++;                   
      if (d <= low)         *iprDst = 0;
      else if (d >= high)   *iprDst = 255;
      else                  
      {
        d = a * (d - low);         // [0.0, 1.0] linear
        d = ::powf(d, gamma);      // [0.0, 1.0] power is gamma function
        i = int32(255.0f * d + 0.5f);

        // --- clamps and saves ---
        if (i < 0)         *iprDst = 0; 
        else if (i > 255)  *iprDst = 255;
        else               *iprDst = uint8(i);
      }
    }
    while (++iprDst < prEnd);
  }

  return true; 
}


//----------------------------------------------------------------------------
//  double => uint8
//----------------------------------------------------------------------------
bool GammaTransform::Do(uint8 * iprDst, const double * iprSrc, uint32 iSize) const
{
  uint8 * prEnd = iprDst + iSize;

  bool bNegative = false;
  double high = _high;
  double low = _low;
  if (high < low) 
  {
    low = _high;
    high = _low;
    bNegative = true;
  }

  const double a = 1.0 / (high - low);
  double d;
  int32 i;

  if (bNegative)
  {
    do
    {
      d = *iprSrc++;                   
      if (d <= low)        *iprDst = 255;
      else if (d >= high)  *iprDst = 0;
      else                  
      {
        d = a * (d - low);         // [0.0, 1.0] linear
        d = ::pow(d, _gamma);      // [0.0, 1.0] power is gamma function
        i = int32(255.0f * d + 0.5f);

        // --- clamps, negates and saves ---
        if (i < 0)         *iprDst = 255; 
        else if (i > 255)  *iprDst = 0;
        else               *iprDst = 255-uint8(i);
      }
    }
    while (++iprDst < prEnd);
  }
  else
  {
    do
    {
      d = *iprSrc++;                   
      if (d <= low)         *iprDst = 0;
      else if (d >= high)   *iprDst = 255;
      else                  
      {
        d = a * (d - low);         // [0.0, 1.0] linear
        d = ::pow(d, _gamma);      // [0.0, 1.0] power is gamma function
        i = int32(255.0f * d + 0.5f);

        // --- clamps and saves ---
        if (i < 0)         *iprDst = 0; 
        else if (i > 255)  *iprDst = 255;
        else               *iprDst = uint8(i);
      }
    }
    while (++iprDst < prEnd);
  }

  return true; 
}

bool GammaTransform::Do(uint16 * iprDst, const uint8 * iprSrc, uint32 iSize) const{  return true;}
bool GammaTransform::Do(uint16 * iprDst, const uint16 * iprSrc, uint32 iSize) const{  return true;}
bool GammaTransform::Do(uint16 * iprDst, const int32 * iprSrc, uint32 iSize) const{  return true;}
bool GammaTransform::Do(uint16 * iprDst, const float * iprSrc, uint32 iSize) const{  return true;}
bool GammaTransform::Do(uint16 * iprDst, const double * iprSrc, uint32 iSize) const{  return true; }
bool GammaTransform::Do(double * iprDst, const uint8 * iprSrc, uint32 iSize) const{ return true;}
bool GammaTransform::Do(double * iprDst, const uint16 * iprSrc, uint32 iSize) const{  return true;}
bool GammaTransform::Do(double * iprDst, const int32 * iprSrc, uint32 iSize) const{  return true;}
bool GammaTransform::Do(double * iprDst, const float * iprSrc, uint32 iSize) const{  return true;}
bool GammaTransform::Do(double * iprDst, const double * iprSrc, uint32 iSize) const {  return true; }


//----------------------------------------------------------------------------
//  TransfertFunctionMidtone
//----------------------------------------------------------------------------
TransfertFunctionMidtone::TransfertFunctionMidtone(double iLow, double iHigh, double iMidtone) :
    AbstractTransfertFunction(iLow, iHigh), _transformation(iLow, iHigh, iMidtone){}
TransfertFunctionMidtone::~TransfertFunctionMidtone(){}
void TransfertFunctionMidtone::SetRange(double iLow, double iHigh)
{
  AbstractTransfertFunction::SetRange(iLow, iHigh);
  _transformation.SetLow(iLow);
  _transformation.SetHigh(iHigh);
}
bool TransfertFunctionMidtone::IsSupported(EResolution iResolution) const
{ return _transformation.IsSupported(RT_UINT8, iResolution); }

bool TransfertFunctionMidtone::Transform(uint8 * iprDest,const void * iprSrc, uint32 iSize, EResolution iResolution) const
{ return _transformation.Transform(iprDest, RT_UINT8, iprSrc, iResolution, iSize); }
void TransfertFunctionMidtone::SetParam(double iMidtone) { _transformation.SetParam(iMidtone); }
double TransfertFunctionMidtone::GetParam() const { return _transformation.GetParam(); }

MidtoneTransform::MidtoneTransform(double iLow, double iHigh, double iMidtone) : 
    IMapTransform(),  _low(iLow),   _high(iHigh),  _midtone(iMidtone){}
MidtoneTransform::~MidtoneTransform() {}
void MidtoneTransform::SetLow(double iLow) { _low = iLow; } 
void MidtoneTransform::SetHigh(double iHigh) {_high = iHigh; } 
void MidtoneTransform::SetParam(double iMidtone) { _midtone = iMidtone; }

bool MidtoneTransform::IsSupported(EResolution iDestination, EResolution iSource) const
{
  if ((RT_INT32 == iSource) || (RT_INT32 == iDestination))
    return false;
  return true;
}

bool MidtoneTransform::Transform( void * iprDst, EResolution iDst,
    const void * iprSrc, EResolution iSrc, uint32 iSize ) const
{
  if ((NULL == iprDst) || (NULL == iprSrc) || (0 == iSize))
    return false;

  if (_high == _low)
    return false;

  if (!IsSupported(iDst, iSrc))
    return false;

  switch(iDst)
  {
    case RT_UINT8:
    {
      uint8 * prDst = (uint8*)iprDst;
      switch(iSrc)
      {
        case RT_UINT8:    return Do(prDst, (const uint8*)iprSrc, iSize);
        case RT_UINT16:   return Do(prDst, (const uint16*)iprSrc, iSize);
        case RT_INT32:  return Do(prDst, (const int32*)iprSrc, iSize);
        case RT_Float:    return Do(prDst, (const float*)iprSrc, iSize);
        case RT_Double:   return Do(prDst, (const double*)iprSrc, iSize);
        default: return false;
      }
    }
    case RT_UINT16:
    {
      uint16 * prDst = (uint16*)iprDst;
      switch(iSrc)
      {
        case RT_UINT8:    return Do(prDst, (const uint8*)iprSrc, iSize);
        case RT_UINT16:   return Do(prDst, (const uint16*)iprSrc, iSize);
        case RT_INT32:  return Do(prDst, (const int32*)iprSrc, iSize);
        case RT_Float:    return Do(prDst, (const float*)iprSrc, iSize);
        case RT_Double:   return Do(prDst, (const double*)iprSrc, iSize);
        default:  return false;
      }
    }
    default: return false;
  }

  return false;
}

bool MidtoneTransform::Do(uint8 * iprDst, const uint8 * iprSrc, uint32 iSize) const
{
  Ramp<uint8> ms_ramp;
  ms_ramp.Midtone(_midtone, _low, _high);
  ms_ramp.Transform(iprDst, iprSrc, iSize);
  return true;
}
bool MidtoneTransform::Do(uint8 * iprDst, const uint16 * iprSrc, uint32 iSize) const
{
#if 0
  GreyRamp16To8 ms_ramp;
  ms_ramp.Midtone(_midtone, _low, _high);
  ms_ramp.Transform(iprDst, iprSrc, iSize);
#else
  // optimization : if size > 65000 transform from a look-up table
  const float m = float(_midtone);

  if (iSize < 65000)
  {
    uint8 * prEnd = iprDst + iSize;
    uint16 v;
    float f;
    if (_low > _high)
    {
      uint16 lo = elxToINT16(_high); 
      uint16 hi = elxToINT16(_low);
      const float a = 1.0f / float(hi-lo);
      do
      {
        v = *iprSrc++;
        if (v <= lo)          *iprDst = uint8MAX;
        else if (v >= hi)     *iprDst = uint8MIN;
        else
        {
          f = a * (v - lo);     // [0.0, 1.0] linear
          f = (float)elxMidtone(f, m);
          *iprDst = ~uint8(uint8MAX * f + 0.5f);
        }
      }
      while (++iprDst < prEnd);
    }
    else
    {
      uint16 lo = elxToINT16(_low); 
      uint16 hi = elxToINT16(_high);
      const float a = 1.0f / float(hi-lo);
      do
      {
        v = *iprSrc++;
        if (v <= lo)          *iprDst = uint8MIN;
        else if (v >= hi)     *iprDst = uint8MAX;
        else
        {
          f = a * (v - lo);     // [0.0, 1.0] linear
          f = (float)elxMidtone(f, m);
          *iprDst = uint8(uint8MAX * f + 0.5f);
        }
      }
      while (++iprDst < prEnd);
    }
  }
  else
  {
    // optimization : compute table only then gamma value changes 
    static double ms_oldMidtone = -1.0;
    static double ms_oldLow   = -1.0;
    static double ms_oldHigh  = -1.0;
    static uint8 ms_lookupTable[1<<16];
    if ((ms_oldMidtone != _midtone) || (ms_oldLow != _low) || (ms_oldHigh != _high))
    {
      ms_oldMidtone = _midtone;
      ms_oldLow = _low;
      ms_oldHigh = _high;

      // build look-up table
      uint16 lo = elxToINT16(_low); 
      uint16 hi = elxToINT16(_high);
      bool bNegative = false;
      if (lo > hi)
      {
        uint16 tmp = lo; lo = hi, hi = tmp;
        bNegative = true;
      }

      uint8 * prDst = ms_lookupTable;
      uint8 * prEnd = prDst + (1<<16);
      uint16 v = 0;
      float f;
      const float a = 1.0f / float(hi-lo);
      do
      {
        if (v <= lo)      *prDst = uint8MIN;
        else if (v >= hi) *prDst = uint8MAX;
        else
        {
          f = a * (v - lo);     // [0.0, 1.0] linear
          f = (float)elxMidtone(f, m);
          *prDst = uint8(uint8MAX * f + 0.5f);
        }
        v++;
      }
      while (++prDst < prEnd);

      if (bNegative)
      {
        prDst = ms_lookupTable;
        prEnd = prDst + (1<<16);
        do { *prDst = ~*prDst; } while (++prDst < prEnd);
      }

      // transform using look-up table
      const uint8 * prTable = &ms_lookupTable[0];
      prEnd = iprDst + iSize;
      do 
      { 
        *iprDst = prTable[*iprSrc++];
      } 
      while (++iprDst < prEnd);
    }
  }
#endif
  return true;
}

bool MidtoneTransform::Do(uint8 * iprDst, const int32 * iprSrc, uint32 iSize) const
{
  return true;
}

//----------------------------------------------------------------------------
//  float => uint8
//----------------------------------------------------------------------------
bool MidtoneTransform::Do(uint8 * iprDst, const float * iprSrc, uint32 iSize) const
{
  uint8 * prEnd = iprDst + iSize;

  bool bNegative = false;
  float high = (float)_high;
  float low = (float)_low;
  const float m =  (float)_midtone;
  if (high < low) 
  {
    low = (float)_high;
    high = (float)_low;
    bNegative = true;
  }

  const float a = 1.0f / (high - low);
  float d;
  int32 i;

  if (bNegative)
  {
    do
    {
      d = *iprSrc++;                   
      if (d <= low)        *iprDst = 255;
      else if (d >= high)  *iprDst = 0;
      else                  
      {
        d = a * (d - low);       // [0.0, 1.0] linear
        d = (float)elxMidtone(d, m);
        i = int32(255.0f * d + 0.5f);

        // --- clamps, negates and saves ---
        if (i < 0)         *iprDst = 255; 
        else if (i > 255)  *iprDst = 0;
        else               *iprDst = 255-uint8(i);
      }
    }
    while (++iprDst < prEnd);
  }
  else
  {
    do
    {
      d = *iprSrc++;                   
      if (d <= low)         *iprDst = 0;
      else if (d >= high)   *iprDst = 255;
      else                  
      {
        d = a * (d - low);         // [0.0, 1.0] linear
        d = (float)elxMidtone(d, m);
        i = int32(255.0f * d + 0.5f);

        // --- clamps and saves ---
        if (i < 0)         *iprDst = 0; 
        else if (i > 255)  *iprDst = 255;
        else               *iprDst = uint8(i);
      }
    }
    while (++iprDst < prEnd);
  }
  return true; 
}


//----------------------------------------------------------------------------
//  double => uint8
//----------------------------------------------------------------------------
bool MidtoneTransform::Do(uint8 * iprDst, const double * iprSrc, uint32 iSize) const
{
  uint8 * prEnd = iprDst + iSize;

  bool bNegative = false;
  double high = _high;
  double low = _low;
  if (high < low) 
  {
    low = _high;
    high = _low;
    bNegative = true;
  }

  const double a = 1.0 / (high - low);
  double d;
  int32 i;

  if (bNegative)
  {
    do
    {
      d = *iprSrc++;                   
      if (d <= low)        *iprDst = 255;
      else if (d >= high)  *iprDst = 0;
      else                  
      {
        d = a * (d - low);         // [0.0, 1.0] linear
        d = elxMidtone(d, _midtone);

        i = int32(255.0f * d + 0.5f);

        // --- clamps, negates and saves ---
        if (i < 0)         *iprDst = 255; 
        else if (i > 255)  *iprDst = 0;
        else               *iprDst = 255-uint8(i);
      }
    }
    while (++iprDst < prEnd);
  }
  else
  {
    do
    {
      d = *iprSrc++;                   
      if (d <= low)         *iprDst = 0;
      else if (d >= high)   *iprDst = 255;
      else                  
      {
        d = a * (d - low);         // [0.0, 1.0] linear
        d = elxMidtone(d, _midtone);

        i = int32(255.0f * d + 0.5f);

        // --- clamps and saves ---
        if (i < 0)         *iprDst = 0; 
        else if (i > 255)  *iprDst = 255;
        else               *iprDst = uint8(i);
      }
    }
    while (++iprDst < prEnd);
  }

  return true; 
}

bool MidtoneTransform::Do(uint16 * iprDst, const uint8 * iprSrc, uint32 iSize) const{  return true;}
bool MidtoneTransform::Do(uint16 * iprDst, const uint16 * iprSrc, uint32 iSize) const{  return true;}
bool MidtoneTransform::Do(uint16 * iprDst, const int32 * iprSrc, uint32 iSize) const{  return true;}
bool MidtoneTransform::Do(uint16 * iprDst, const float * iprSrc, uint32 iSize) const{  return true;}
bool MidtoneTransform::Do(uint16 * iprDst, const double * iprSrc, uint32 iSize) const{  return true; }
bool MidtoneTransform::Do(double * iprDst, const uint8 * iprSrc, uint32 iSize) const{ return true;}
bool MidtoneTransform::Do(double * iprDst, const uint16 * iprSrc, uint32 iSize) const{  return true;}
bool MidtoneTransform::Do(double * iprDst, const int32 * iprSrc, uint32 iSize) const{  return true;}
bool MidtoneTransform::Do(double * iprDst, const float * iprSrc, uint32 iSize) const{  return true;}
bool MidtoneTransform::Do(double * iprDst, const double * iprSrc, uint32 iSize) const {  return true; }

//----------------------------------------------------------------------------
CopyTransform::CopyTransform() : IMapTransform(){}
CopyTransform::~CopyTransform() {}
bool CopyTransform::IsSupported(EResolution iDestination, EResolution iSource) const
{
  if ((RT_INT32 == iSource) || (RT_INT32 == iDestination))
    return false;
  return true;
}

bool CopyTransform::Transform(void * iprDst, EResolution iDst,
    const void * iprSrc, EResolution iSrc, uint32 iSize ) const
{ 
  if ((NULL == iprDst) || (NULL == iprSrc) || (0 == iSize))
    return false;

  if (!IsSupported(iDst, iSrc))
    return false;

  switch(iDst)
  {
    case RT_UINT8:
    {
      uint8 * prDst = (uint8*)iprDst;
      switch(iSrc)
      {
        case RT_UINT8:    elxConvertBuffer(prDst, (const uint8*)iprSrc, iSize);  return true;
        case RT_UINT16:   elxConvertBuffer(prDst, (const uint16*)iprSrc, iSize); return true;
        case RT_INT32:  elxConvertBuffer(prDst, (const int32*)iprSrc, iSize);    return true;
        case RT_Float:    elxConvertBuffer(prDst, (const float*)iprSrc, iSize);  return true;
        case RT_Double:   elxConvertBuffer(prDst, (const double*)iprSrc, iSize); return true;
      	default:				  return false;
			}
    }
    case RT_UINT16:
    {
      uint16 * prDst = (uint16*)iprDst;
      switch(iSrc)
      {
        case RT_UINT8:    elxConvertBuffer(prDst, (const uint8*)iprSrc, iSize);  return true;
        case RT_UINT16:   elxConvertBuffer(prDst, (const uint16*)iprSrc, iSize); return true;
        case RT_INT32:  elxConvertBuffer(prDst, (const int32*)iprSrc, iSize);    return true;
        case RT_Float:    elxConvertBuffer(prDst, (const float*)iprSrc, iSize);  return true;
        case RT_Double:   elxConvertBuffer(prDst, (const double*)iprSrc, iSize); return true;
      	default:					return false;
			}
    }
    case RT_Float:
    {
      float * prDst = (float*)iprDst;
      switch(iSrc)
      {
        case RT_UINT8:    elxConvertBuffer(prDst, (const uint8*)iprSrc, iSize);  return true;
        case RT_UINT16:   elxConvertBuffer(prDst, (const uint16*)iprSrc, iSize); return true;
        case RT_INT32:  elxConvertBuffer(prDst, (const int32*)iprSrc, iSize);    return true;
        case RT_Float:    elxConvertBuffer(prDst, (const float*)iprSrc, iSize);  return true;
        case RT_Double:   elxConvertBuffer(prDst, (const double*)iprSrc, iSize); return true;
        default: return false;
      }
      return false;
    }

    case RT_Double:
    {
      double * prDst = (double*)iprDst;
      switch(iSrc)
      {
        case RT_UINT8:    elxConvertBuffer(prDst, (const uint8*)iprSrc, iSize);  return true;
        case RT_UINT16:   elxConvertBuffer(prDst, (const uint16*)iprSrc, iSize); return true;
        case RT_INT32:  elxConvertBuffer(prDst, (const int32*)iprSrc, iSize);    return true;
        case RT_Float:    elxConvertBuffer(prDst, (const float*)iprSrc, iSize);  return true;
        case RT_Double:   elxConvertBuffer(prDst, (const double*)iprSrc, iSize); return true;
        default: return false;
      }
    }
    default: return false;
  }
  return false;
}

} // namespace Math
} // namespace eLynx
