//============================================================================
//  Matrix.cpp                                          Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/math/Matrix.h>

namespace eLynx {
namespace Math {
	

//----------------------------------------------------------------------------
// constructor, creates matrix of given size

Matrix::Matrix(uint32 iHeight, uint32 iWidth)
{
	Resize(iHeight, iWidth);
}


//----------------------------------------------------------------------------
// constructor, creates copy of the matrix

Matrix::Matrix(const IMatrix &iC)
{
	// resize the matrix
	Resize(iC.GetHeight(), iC.GetWidth());
	
	// copy matrix content (take care about indexing)
	for (uint32 r = 0; r < iC.GetHeight(); r++)
		for (uint32 c = 0; c < iC.GetWidth(); c++)
			(*this)(r, c) = iC(r, c);
}


//----------------------------------------------------------------------------
// copy constructor

Matrix::Matrix(const Matrix &iC)
{
	CopyData(iC);
}


//----------------------------------------------------------------------------
// an assignement operator

Matrix& Matrix::operator = (const Matrix &iC)
{
	if (&iC != this) CopyData(iC);
	return *this;
}


//----------------------------------------------------------------------------
// matrix content access operator (const version)

const double& Matrix::operator () (uint32 iRow, uint32 iCol) const
{
	// check row index
	if (iRow >= GetHeight())
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Row index %i out of range <0, %i>.", iRow, GetHeight()-1));
			
	// check column index
	if (iCol >= GetWidth())
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Column index %i out of range <0, %i>.", iCol, GetWidth()-1));
			
	// return the matrix value
	return _spMatrix[iRow*GetWidth()+iCol];
}


//----------------------------------------------------------------------------
// matrix content access operator

double& Matrix::operator () (uint32 iRow, uint32 iCol)
{
	// check row index
	if (iRow >= GetHeight())
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Row index %i out of range <0, %i>.", iRow, GetHeight()-1));
			
	// check column index
	if (iCol >= GetWidth())
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Column index %i out of range <0, %i>.", iCol, GetWidth()-1));
			
	// return the matrix value
	return _spMatrix[iRow*GetWidth()+iCol];
}


//----------------------------------------------------------------------------
// swaps matrix rows

void Matrix::SwapRows(uint32 iRow1, uint32 iRow2)
{
	if (iRow1 == iRow2) return;
	for (uint32 c = 0; c < GetWidth(); c++) {
		double tmp = (*this)(iRow1, c);
		(*this)(iRow1, c) = (*this)(iRow2, c);
		(*this)(iRow2, c) = tmp;
	}
}


//----------------------------------------------------------------------------
// swaps matrix columns

void Matrix::SwapCols(uint32 iCol1, uint32 iCol2)
{
	if (iCol1 == iCol2) return;
	for (uint32 r = 0; r < GetHeight(); r++) {
		double tmp = (*this)(r, iCol1);
		(*this)(r, iCol1) = (*this)(r, iCol2);
		(*this)(r, iCol2) = tmp;
	}
}


//----------------------------------------------------------------------------
// resizes matrix

void Matrix::Resize(uint32 iHeight, uint32 iWidth)
{
	if (iHeight*iWidth == 0) _spMatrix.reset(NULL);
	else _spMatrix.reset(new double[iHeight*iWidth]);
	
	_Height = iHeight;
	_Width = iWidth;
}


//----------------------------------------------------------------------------
// copies object data

void Matrix::CopyData(const Matrix &iC)
{
	Resize(iC._Height, iC._Width);
	for (uint32 i = 0; i < _Width*_Height; i++) _spMatrix[i] = iC._spMatrix[i];
}


//----------------------------------------------------------------------------

} // namespace Math
} // namespace eLynx
