//============================================================================
//  LeastSquares.cpp                                    Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/math/LeastSquares.h>
#include <elx/math/SingleColMatrix.h>
#include <elx/math/SubMatrix.h>
#include <elx/math/TransposedMatrix.h>
#include <elx/math/MatrixRowVector.h>
#include <elx/math/MatrixColVector.h>

#include <boost/scoped_array.hpp>

#include <math.h>

namespace eLynx {
namespace Math {
	
	
//----------------------------------------------------------------------------
// solves the overdetermined system of linear equations using least
// squares method

void LeastSquares::Solve(const IMatrix &iA, const IVector &iB, IVector &oX, 
	double iTau)
{
	// copy inputs to temporaries - HFTI uses also inputs to store values
	Matrix tmpA(iA);
	Vector tmpB(iB);
	
	// create one-based indexing adapters -HFTI method is defined on one-based
	// indexing
	//OneBasedMatrix A(tmpA);
	//OneBasedVector B(tmpB);
	//OneBasedVector X(oX);
	
	/// solve the system using HFTI
	HFTI(tmpA, tmpB, oX, iTau);
}


//----------------------------------------------------------------------------
// creates and applies Householder transformation

void LeastSquares::H1(uint32 iP, uint32 iL, uint32 iM, IVector &ioV, double &oH,
		IMatrix &ioC, double iTau)
{
	double s = ioV(iP-1)*ioV(iP-1);                           // step 2
	for (uint32 i = iL; i <= iM; i++) s += ioV(i-1)*ioV(i-1);
	s = sqrt(s);
	if (ioV(iP-1) > 0.0) s = -s;                            // step 3
	oH = ioV(iP-1)-s;                                       // step 4
	ioV(iP-1) = s;
	H2(iP, iL, iM, ioV, oH, ioC, iTau);
}


//----------------------------------------------------------------------------
// just applies Householder transformation

void LeastSquares::H2(uint32 iP, uint32 iL, uint32 iM, IVector &iV, double &iH,
		IMatrix &ioC, double iTau)
{
	double b = iV(iP-1)*iH;                                 // step 5
	if (fabs(b) < iTau) return;                           // step 6
	for (uint32 j = 1; j <= ioC.GetWidth(); j++) {          // step 7
		double s = ioC(iP-1, j-1)*iH;                           // step 8
		for (uint32 i = iL; i <= iM; i++) s += ioC(i-1, j-1)*iV(i-1);
		s /= b;
		ioC(iP-1, j-1) += s*iH;                                 // step 9
		for (uint32 i = iL; i <= iM; i++) ioC(i-1, j-1) += s*iV(i-1); // step 10
	}
}


//----------------------------------------------------------------------------
// solves the least squares problem using HFTI method

void LeastSquares::HFTI(IMatrix &iA, IVector &iB, IVector &oX, double iTau)
{
	uint32 m = iA.GetHeight();
	uint32 n = iA.GetWidth();
	if (iB.GetSize() != m) 
		elxThrow(elxErrInvalidParams,
			elxMsgFormat("Matrix A and vector B don't match in sizes (%i != %i).",
				m, iB.GetSize()));
				
	if (oX.GetSize() != n)
		elxThrow(elxErrInvalidParams,
			elxMsgFormat("Matrix A and vector X don't match in sizes (%i != %i).",
				n, oX.GetSize()));
				
	Vector h(n), g(n);
	//OneBasedVector h(hv), g(gv);
	boost::scoped_array<uint32> p(new uint32[n]);
				
	for (uint32 i = 1; i <= n; i++) oX(i-1) = 0.0;
	
	uint32 mu = (n < m ? n : m);                                      // step 1
	
	double hbar;
	for (uint32 j = 1; j <= mu; j++) {                                // step 2
		uint32 lambda;
		
		bool hbar_test = false;
		if (j != 1) {                                                 // step 3
			for (uint32 l = j; l <= n; l++) h(l-1) -= iA(j-2, l-1)*iA(j-2, l-1);// step 4
			lambda = FindMaxPos(h, j, n);                               // step 5
			hbar_test = (hbar+1e-3*h(lambda-1) > hbar);                   // step 6
		}
		if (!hbar_test) {                                             // step 6
			for (uint32 l = j; l <= n; l++) {                             // step 7
				h(l-1) = 0;
				for (uint32 i = j; i <= m; i++) h(l-1) += iA(i-1, j-1)*iA(i-1, j-1);
			}
			lambda = FindMaxPos(h, j, n);                               // step 8
			hbar = h(lambda-1);
		}
		p[j-1] = lambda;                                                // step 9
		if (p[j-1] != j) {
			iA.SwapCols(j-1, lambda-1);                                     // step 10
			h(lambda-1) = h(j-1);
		}
		
		MatrixColVector Aj(iA, j-1);
		SubMatrix Ajn(iA, 0, m, j, n-j);
		SingleColMatrix Bc(iB);
		H1(j, j+1, m, Aj, h(j-1), Ajn, iTau);                           // step 11
		H2(j, j+1, m, Aj, h(j-1), Bc, iTau);                            // step 12
	}
	
	uint32 k = 0;                                                     // step 13
	for (uint32 j = 1; j <= n; j++) if (fabs(iA(j-1, j-1)) > iTau) k = j;
	if (k == 0) return;
	
	if (k < n) {                                                    // step 14
		for (uint32 i = k; i >= 1; i--) {                               // step 16
			MatrixRowVector Ai(iA, i-1);
			SubMatrix Ain(iA, 0, i-1, 0, n);
			TransposedMatrix TAin(Ain);
			H1(i, k+1, n, Ai, g(i-1), TAin, iTau);
		}
	}
	
	oX(k-1) = iB(k-1)/iA(k-1, k-1);                                 // step 17
	if (k > 1) 
		for (uint32 i = k-1; i >= 1; i--) {                             // step 18
			double x = iB(i-1);
			for (uint32 j = i+1; j <= k; j++) x -= iA(i-1, j-1)*oX(j-1);
			oX(i-1) = x/iA(i-1, i-1);
		}

	if (k != n) {                                                   // step 19
		for (uint32 i = k+1; i <= n; i++) oX(i-1) = 0;                  // step 20
		for (uint32 i = 1; i <= k; i++) {                               // step 21
			MatrixRowVector Ai(iA, i-1);
			SingleColMatrix Xc(oX);
			H2(i, k+1, n, Ai, g(i-1), Xc, iTau);
		}
	}
	
	for (uint32 j = mu; j >= 1; j--)                                  // step 22
		if (p[j-1] != j) oX.SwapValues(j-1, p[j-1]-1);
		
}


//----------------------------------------------------------------------------
// find index of the maximal value in vector

uint32 LeastSquares::FindMaxPos(IVector &iV, uint32 from, uint32 to)
{
	uint32 result = 0;
	double max_value = -doubleMAX;
	for (uint32 i = from; i <= to; i++)
		if (iV(i-1) > max_value) {
			max_value = iV(i-1);
			result = i;
		}
	return result;
}


//----------------------------------------------------------------------------

} // namespace Math
} // namespace eLynx
