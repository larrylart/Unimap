//============================================================================
//  BSpline.cpp                                         Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/math/BSpline.h>

namespace eLynx {
namespace Math {

//----------------------------------------------------------------------------
//  explicit instantiation 
//----------------------------------------------------------------------------

//template struct eLynx::Math::KDNode<int>;

// --- BSpline1 ---

template class BSpline1<int>;
template class BSpline1<int64>;
template class BSpline1<float>;
template class BSpline1<double>;

// --- BSpline2 ---
template class BSpline2<int>;
template class BSpline2<int64>;
template class BSpline2<float>;
template class BSpline2<double>;

} // namespace Math
} // namespace eLynx
