//============================================================================
//  Vector.cpp                                          Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/math/Vector.h>

#include <math.h>

namespace eLynx {
namespace Math {
	

//----------------------------------------------------------------------------
// constructor, creates vector of specified size
	
Vector::Vector(uint32 iSize)
{
	Resize(iSize);
}


//----------------------------------------------------------------------------
// constructor, creates copy of specified vector

Vector::Vector(const IVector &iC)
{
	// resize the vector
	Resize(iC.GetSize());
	
	// copy vector content (take care of indexing)
	for (uint32 i = 0; i < iC.GetSize(); i++) (*this)(i) = iC(i);
}


//----------------------------------------------------------------------------
// copy constructor

Vector::Vector(const Vector &iC)
{
	CopyData(iC);
}


//----------------------------------------------------------------------------
// an assignement operator

Vector& Vector::operator = (const Vector &iC)
{
	if (&iC != this) CopyData(iC);
	return *this;
}


//----------------------------------------------------------------------------
// vector content access operator (const version)

const double& Vector::operator () (uint32 iIndex) const
{

	// check index
	if (iIndex >= GetSize())
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Index %i out of range <0, %i>.", iIndex, GetSize()-1));
			
	// return value
	return _spVector[iIndex];
}


//----------------------------------------------------------------------------
// vector content access operator 

double& Vector::operator () (uint32 iIndex)
{
	// check index
	if (iIndex >= GetSize())
		elxThrow(elxErrOutOfRange,
			elxMsgFormat("Index %i out of range <0, %i>.", iIndex, GetSize()-1));
			
	// return value
	return _spVector[iIndex];
}


//----------------------------------------------------------------------------
// swaps vector values

void Vector::SwapValues(uint32 iIndex1, uint32 iIndex2)
{
	if (iIndex1 == iIndex2) return;
	double tmp = (*this)(iIndex1);
	(*this)(iIndex1) = (*this)(iIndex2);
	(*this)(iIndex2) = tmp;
}


//----------------------------------------------------------------------------
// resizes vector

void Vector::Resize(uint32 iSize)
{
	if (iSize == 0) _spVector.reset(NULL);
	else _spVector.reset(new double[iSize]);
	_Size = iSize;
}


//----------------------------------------------------------------------------
// copies object data

void Vector::CopyData(const Vector &iC)
{
	Resize(iC.GetSize());
	for (uint32 i = 0; i < GetSize(); i++) _spVector[i] = iC._spVector[i];
}


//----------------------------------------------------------------------------

double Vector::GetLength() const
{
  double result = 0.0;
  for (uint32 i = 0; i < GetSize(); i++)
    result += _spVector[i]*_spVector[i];
    
  return sqrt(result);
}

//----------------------------------------------------------------------------
	
} // namespace Math
} // namespace eLynx
