//============================================================================
//  Delaunay/Delaunay.hpp                               Math.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Delaunay_hpp__
#define __Delaunay_hpp__

#include <boost/assert.hpp>
#include <boost/scoped_array.hpp>

namespace eLynx {
namespace Math {

class Delaunay
{
public:
  static const uint32 MIN_POINT_COUNT = 3;
  Delaunay(const Point2iList& iList);
  ~Delaunay();

  bool BuildTriangleList(TriangleIdxList& oTriangles);
  size_t GetPointCount() const { return _pointCount; }
  
  friend bool elxTriangulate(
    const Point2iList& iPoints,
    TriangulationData& oTriangles);

private:
  // Geometric and topological entities
  struct Edge;

  struct Point
  {
    float _x,_y;
    Edge * _prEntry;
  };

  void Vector(Point * p1, Point * p2, float& u, float& v)
  { u = p2->_x-p1->_x;  v = p2->_y-p1->_y; }

  float DotProduct(float u1, float v1, float u2, float v2) 
  { return (u1*u2 + v1*v2); }

  float CrossProduct(Point * p1, Point * p2, Point * p3)
  { return (p2->_x - p1->_x)*(p3->_y - p1->_y) - (p2->_y - p1->_y)*(p3->_x - p1->_x); }

  float CrossProduct(float u1, float v1, float u2, float v2) 
  { return (u1*v2 - v1*u2); }

  // Edges
  struct Edge 
  {
    Point * _prOrig;
    Edge  * _prOrigNext;
    Edge  * _prOrigPrev;

    Point * _prDest;
    Edge  * _prDestNext;
    Edge  * _prDestPrev;

    Edge * GetNext(Point * p)     { return (_prOrig == p ? _prOrigNext : _prDestNext); }
    Edge * GetPrevious(Point * p) { return (_prOrig == p ? _prOrigPrev : _prDestPrev); }
    Point * GetOther(Point * p)   { return (_prOrig == p ? _prDest : _prOrig); }
  };

  enum ESide {right, left};
  void FreeEdge(Edge * iprEdge);
  void RemoveEdge(Edge * iprEdge);
  Edge * MakeEdge(Point * iprP1, Point * iprP2);
  Edge * Join(Edge * iprEdgeA, Point * iprP1, Edge * iprEdgeB, Point * iprP2, ESide iSide);
  void Splice(Edge * iprEdgeA, Edge * iprEdgeB, Point * iprPt);

  void Merge(
      Edge * iprRightCWLeft,  Point * iprP1, 
      Edge * iprLeftCCWRight, Point * iprP2, 
      Edge *& oprLeftTangent);

  void MergeSort(Point * iprP1[], Point * iprP2[], size_t iLeft, size_t iRight);
  void Divide(Point * iprSorted[], size_t iLeft, size_t iRight,  
      Edge *& oprLeftCCW, Edge *& oprRightCW);

  void GetLowerTangent(
      Edge * iprRightCWLeft,  Point * iprP1, 
      Edge * iprLeftCCWRight, Point * iprP2,
      Edge *& oprLeftLower,   Point *& oprOrigLeftLower, 
      Edge *& oprRightLower,  Point *& oprOrigRightLower);

private:
  Point * _plPointList;
  Edge  * _plEdgeList;
  Edge ** _plFreeEdgeList;
  size_t _freeEdgeCount, _pointCount;
};

namespace {

inline
TriangulationData::Edge * elxGetEdge(
  const std::vector< TriangulationData::Edge * >& iEdges,
  const TriangulationData::Vertex& iVertex)
{
  const size_t size = iEdges.size();
  for (size_t i=0; i<size; ++i)
  {
    if (iEdges[i]->_vertex[0]->_position == iVertex._position ||
        iEdges[i]->_vertex[1]->_position == iVertex._position)
      return iEdges[i];
  }
  return 0;

} // elxGetEdge

inline
TriangulationData::Edge * elxBuildEdge(
  size_t iV1Idx, size_t iV2Idx, 
  TriangulationData::Triangle * ipTriangle, 
  TriangulationData& ioTriangulationData)
{
  TriangulationData::Edge edge;
  edge._vertex[0] = &ioTriangulationData._vertices[iV1Idx];
  edge._vertex[1] = &ioTriangulationData._vertices[iV2Idx];
  edge._triangle[0] = ipTriangle;
  edge._triangle[1] = 0;
  ioTriangulationData._edges.push_back(edge);
  return &ioTriangulationData._edges.back();

} // elxBuildEdge

} // namespace 

//----------------------------------------------------------------------------
//  elxTriangulate
//----------------------------------------------------------------------------
/*
template <typename T>
bool elxTriangulate(const Point2iList& iPoints, const T* iValues, 
  TriangulationData<T>& oTriangulationData)
{
  typedef typename TriangulationData<T>::Normal Normal;
  typedef typename TriangulationData<T>::Vertex Vertex;
  typedef typename TriangulationData<T>::Edge Edge;
  typedef typename TriangulationData<T>::Triangle Triangle;
  
  Delaunay helper(iPoints);
  
  if (helper._pointCount < Delaunay::MIN_POINT_COUNT) return false;
  
  Delaunay::Edge * prEdge, * prNext;
  Delaunay::Point * pr[3];
  
  Vertex vertex;
  
  oTriangulationData._vertices.clear();
  oTriangulationData._edges.clear();
  oTriangulationData._triangles.clear();
  
  // It's important to preallocate all memory upfront because in case of 
  // reallocations all pointers will be off
  oTriangulationData._vertices.reserve(helper._pointCount);
  // Max number of edges is max number of triangles *3 /2 ~ 3n
  oTriangulationData._edges.reserve(helper._pointCount*3);
  // Max number of triangles is 2n -2 -b where n is total number of
  // vertices and b is number of vertices on the convex hull
  oTriangulationData._triangles.reserve(helper._pointCount*2);
  // Array to keep triangle's count at every vertex
  boost::scoped_array<int32> spCount (new int32[helper._pointCount]);
  
  for (uint32 i=0; i<helper._pointCount; i++) 
  {
    vertex._position._x =  helper._plPointList[i]._x;
    vertex._position._y =  helper._plPointList[i]._y;
    // assumption here is that _plPointList is NOT RESORTED 
    // after the initialization
    vertex._value = iValues[i];
    // this is an overkill but we can't afford reallocation
    //vertex._edges.reserve(helper._pointCount);
    oTriangulationData._vertices.push_back(vertex);
    spCount[i] = 0;
  }
  
  const uint32 n = helper._pointCount - 1;
  for (uint32 i=0; i<n; i++) 
  {
    pr[0] = &helper._plPointList[i];    
    Delaunay::Edge * prEdgeStart = prEdge = pr[0]->_prEntry;
    do
    {
      pr[1] = prEdge->GetOther(pr[0]);
      
      if (pr[0] < pr[1]) 
      {
        prNext = prEdge->GetNext(pr[0]);
        pr[2] = prNext->GetOther(pr[0]);
        if (pr[0] < pr[2])
          if (prNext->GetNext(pr[2]) == prEdge->GetPrevious(pr[1])) 
          {  
            // Triangle
            if (pr[1] > pr[2]) 
            { Delaunay::Point * prTemp = pr[1]; pr[1] = pr[2]; pr[2] = prTemp; }

            Triangle t;
            t._vertex[0]= &oTriangulationData._vertices[pr[0]-helper._plPointList];
            t._vertex[1]= &oTriangulationData._vertices[pr[1]-helper._plPointList];
            t._vertex[2]= &oTriangulationData._vertices[pr[2]-helper._plPointList];
            t._edge[0] = t._edge[1] = t._edge[2] = 0;
            elxTriangleNormal<T>(t);
                        
            oTriangulationData._triangles.push_back(t);
            Triangle* pt = &oTriangulationData._triangles.back();

            // Now figure out whether the edges were already built
            for(uint32 j = 0; j < 3; ++j)
            {
              Edge* pedge = elxGetEdge<T>(
                oTriangulationData._vertices[pr[j]-helper._plPointList]._edges, 
                oTriangulationData._vertices[pr[(j+1)%3]-helper._plPointList]);
              if (pedge == 0)
              {
                pedge =  elxBuildEdge(pr[j]-helper._plPointList, 
                          pr[(j+1)%3]-helper._plPointList, pt, oTriangulationData);

                //Assign edges to corresponding vertices  
                oTriangulationData._vertices[pr[j]-helper._plPointList]._edges.push_back(
                   pedge);
                oTriangulationData._vertices[pr[(j+1)%3]-helper._plPointList]._edges.push_back(
                   pedge);
              } 
              else
                //Assign the triangle
                pedge->_triangle[1] = pt;

              //Assign edges to the triangle  
              pt->_edge[j] = pedge;

              // Accumulate normals
              uint32 idx = pr[j]-helper._plPointList;
              oTriangulationData._vertices[idx]._normal._x += pt->_normal._x;
              oTriangulationData._vertices[idx]._normal._y += pt->_normal._y;
              oTriangulationData._vertices[idx]._normal._z += pt->_normal._z;
              ++spCount[idx];
            }        
          }
      }
      
      // Next edge around P0
      prEdge = prEdge->GetNext(pr[0]);
    } 
    while (prEdge != prEdgeStart);
  }
  
  // Adjust normals  
  for (uint32 i=0; i<helper._pointCount; i++) 
  {
    BOOST_ASSERT(spCount[i] > 0);      
    oTriangulationData._vertices[i]._normal._x /= spCount[i];
    oTriangulationData._vertices[i]._normal._y /= spCount[i];
    oTriangulationData._vertices[i]._normal._z /= spCount[i];
  }

  return true;

} // elxTriangulate
*/

} // namespace Math
} // namespace eLynx

#endif // __Delaunay_hpp__
