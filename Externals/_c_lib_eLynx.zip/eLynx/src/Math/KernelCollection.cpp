//============================================================================
//  KernelCollection.cpp                                Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/math/KernelCollection.h>
#include <vector>

namespace eLynx {
namespace Math {

//----------------------------------------------------------------------------
//  elxGetKernelSize
//----------------------------------------------------------------------------
uint32 elxGetKernelSize(double iRadius)
{
  uint32 r = uint32(iRadius + 0.5);
  r = Math::elxMax(uint32(1), r);
  r = Math::elxMin(r, uint32(100));
  uint32 size = 1 + 2*r;
  return size;

} // elxGetKernelSize

//----------------------------------------------------------------------------
//  elxMakeCircleKernel
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeCircleKernel(double iRadius, bool ibNormalize)
{
  int32 w = int32(2.0*iRadius + 0.5);
  if (0 == (w & 1)) w++;
  
  const int32 r = int32(iRadius*iRadius + 0.5);
  const int32 c = w / 2;

  ConvolutionKerneld kernel(w,w);
  double * prK = kernel._spK.get();
  int32 x,y;
  for (y=0; y<w; y++)
    for (x=0; x<w; x++)
      *prK++ = (x-c)*(x-c) + (y-c)*(y-c) > r ? 0.0 : 1.0;
  
  if (ibNormalize)
    kernel.Normalize();
  return kernel;
 
} // elxMakeCircleKernel


//----------------------------------------------------------------------------
//  elxMakeMeanKernel, square
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeMeanKernel(uint32 iWidth, uint32 iHeight)
{
  ConvolutionKerneld kernel(iWidth, iHeight, 1./(iWidth*iHeight));
  return kernel;
  
} // elxMakeMeanKernel


//----------------------------------------------------------------------------
//  elxMakeMeanRadiusKernel, circular or square
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeMeanRadiusKernel(double iRadius, bool ibCircular)
{
  if (ibCircular)
    return elxMakeCircleKernel(iRadius, true);

  // square
  uint32 d = uint32(2.0*iRadius + 0.5);
  if (0 == (d & 1)) d++;
  return elxMakeMeanKernel(d,d);

} // elxMakeMeanRadiusKernel


//----------------------------------------------------------------------------
//  elxMakeGaussianSeparableKernel
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeGaussianSeparableKernel(
    uint32 iWidth, 
    double iVariance, 
    bool ibHorizontal)
{
  if (0 == (iWidth&1))
    return ConvolutionKerneld(0,0);

  uint32 p1 = iWidth;
  uint32 p2 = 1;
  if (!ibHorizontal) { p1 = 1; p2 = iWidth; }
  
  const int32 w = iWidth/2;
  ConvolutionKerneld kernel(p1,p2);
  double * prK = kernel._spK.get();
  
  prK[w] = elxGaussian(0.0, iVariance);
  for (int32 x=1; x<=w; x++)
    prK[w-x] = prK[w+x] = elxGaussian(double(x), iVariance);
  kernel.Normalize();
  return kernel;

} // elxMakeGaussianSeparableKernel


//----------------------------------------------------------------------------
//  elxMakeGaussianKernel
//  It's better to use separable kernels!
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeGaussianKernel(
    uint32 iWidth, 
    uint32 iHeight, 
    double iVariance)
{
  if ((0 == (iWidth&1)) || (0 == (iHeight&1)))
    return ConvolutionKerneld(0,0);

  const int32 w = iWidth/2;
  const int32 h = iHeight/2;
  ConvolutionKerneld kernel(iWidth,iHeight);
  double * prK = kernel._spK.get();
  int32 x,y;
  prK[h*iWidth+w] = elxGaussian(0.0,0.0, iVariance);
  for (x=1; x<=w; x++)
    prK[h*iWidth+w-x] = prK[h*iWidth+w+x] = elxGaussian(double(x), 0.0, iVariance);

  for (y=1; y<=h; y++)
  {
    prK[(h-y)*iWidth + w] = prK[(h+y)*iWidth + w] = elxGaussian(0.0, double(y), iVariance);
    for (x=1; x<=w; x++)
      prK[(h-y)*iWidth + w-x] = prK[(h-y)*iWidth + w+x] = 
      prK[(h+y)*iWidth + w-x] = prK[(h+y)*iWidth + w+x] = 
        elxGaussian(double(x), double(y), iVariance);
  }
     
  kernel.Normalize();
  return kernel;

} // elxMakeGaussianKernel


//----------------------------------------------------------------------------
//  elxMakeGaussianKernel
//  It's better to use separable kernels!
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeGaussianKernel(uint32 iRadius, double iVariance)
{
  return elxMakeGaussianKernel(iRadius, iRadius, iVariance);

} // elxMakeGaussianKernel

//----------------------------------------------------------------------------
//  elxMakeEmboss3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeEmboss3x3d(double iDegrees)
{
  const double r = elxDeg2Rad(iDegrees);
  double array3x3[9];

  array3x3[0] = 4*elxCos(r + 3.0*M_PIo4);
  array3x3[1] = 4*elxCos(r + 2.0*M_PIo4);
  array3x3[2] = 4*elxCos(r + 1.0*M_PIo4);
  array3x3[3] = 4*elxCos(r + 4.0*M_PIo4);
  array3x3[4] = 1;
  array3x3[5] = 4*elxCos(r + 0.0*M_PIo4);
  array3x3[6] = 4*elxCos(r - 3.0*M_PIo4);
  array3x3[7] = 4*elxCos(r - 2.0*M_PIo4);
  array3x3[8] = 4*elxCos(r - 1.0*M_PIo4);
  
  ConvolutionKerneld kernel(3,3, array3x3);
  kernel.Normalize();
  return kernel;
  
} // elxMakeEmboss3x3d


//----------------------------------------------------------------------------
//  elxMakeRobinson5x5d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeRobinson5x5d()
{
  static double ms_array5x5[] = {
      1.,  2.,  3.,  2.,  1.,
      2., -2.,  0., -2.,  2.,
     -1., -8.,  0., -8., -1.,
     -2.,  2.,  0.,  2., -2.,
      1.,  2.,  3.,  2.,  1.
  };
  static const ConvolutionKerneld ms_kernel(5,5, ms_array5x5);
  return ms_kernel;
  
} // elxMakeRobinson5x5d


//----------------------------------------------------------------------------
//  elxMakeLaplacian3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeLaplacian3x3d()
{
  static double ms_array3x3[] = {
    1.,  1., 1.,
    1., -7., 1.,
    1.,  1., 1.
  };
  static const ConvolutionKerneld ms_kernel(3,3, ms_array3x3);
  return ms_kernel;

} // elxMakeLaplacian3x3d


//----------------------------------------------------------------------------
//  elxMakeLaplacian3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeLaplacian3x3d(double iAlpha)
{
  const double a = 1.0/(1.0 + iAlpha);
  const double a1 = a*iAlpha;
  const double a2 = a*(1.0 - iAlpha);
  
  double array3x3[] = {
    a1,     a2,    a1,
    a2,   -4.0*a,  a2,
    a1,     a2,    a1
  };
  ConvolutionKerneld kernel(3,3, array3x3);
  return kernel;

} // elxMakeLaplacian3x3d


//----------------------------------------------------------------------------
//  elxMakeLaplacian
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeLaplacian(double iRadius)
{
  int32 w = int32(1.0 + 2.0*iRadius + 0.5);
  if (0 == (w & 1)) w++;
  
  const int32 r = int32(iRadius*iRadius + 0.5);
  const int32 c = w / 2;

  ConvolutionKerneld kernel(w,w);
  double * prK = kernel._spK.get();
  int32 x,y, sum=0;
  for (y=0; y<w; y++)
    for (x=0; x<w; x++)
    {
      if ((x-c)*(x-c) + (y-c)*(y-c) > r)
      {
        *prK++ = 0.0;
      }
      else
      {
        *prK++ = -1.0;
        sum++;
      }
    }
 
  // update center
  prK = kernel._spK.get();
  prK[ (w+1)*c ] = double(sum);

  return kernel;

} // elxMakeLaplacian


//----------------------------------------------------------------------------
//  elxMakeLoG
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeLoG(double iRadius, double iVariance)
{
  int32 d = int32(1.0 + 2.0*iRadius + 0.5);
  if (0 == (d & 1)) d++;
  ConvolutionKerneld kernel(d,d);
  
  double * prK = kernel._spK.get();
  const int32 r = d/2;
  for (int32 y=0; y<d; y++)
    for (int32 x=0; x<d; x++)
      prK[d*y+x] = elxLoG(double(x-r), double(y-r), iVariance);
  
  kernel.Normalize();
  return kernel;

} // elxMakeLoG


//----------------------------------------------------------------------------
//  Marr-Hildreth
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeMarrHildreth3x3d()
{
  const double oneOsqrt2 = 1.0/M_SQRT2;
  static double ms_array3x3[] = {
    oneOsqrt2,       1.0,        oneOsqrt2,
    1.0,       -4.0-2.0*M_SQRT2, 1.0,
    oneOsqrt2,       1.0,        oneOsqrt2 
  };
  static const ConvolutionKerneld ms_kernel(3,3, ms_array3x3);
  return ms_kernel;
  
} // elxMakeMarrHildreth3x3d


//----------------------------------------------------------------------------
//  elxMakeSmooth3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeSmooth3x3d()
{
  double ms_array3x3[] = {
    1./12., 1./12., 1./12.,
    1./12., 4./12., 1./12.,
    1./12., 1./12., 1./12.
  };
  static const ConvolutionKerneld ms_kernel(3,3, ms_array3x3);
  return ms_kernel;
  
} // elxMakeSmooth3x3d


//----------------------------------------------------------------------------
//  elxMakeLowpass3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeLowpass3x3d(double iAlpha)
{
  const double a1 = iAlpha;
  const double a2 = iAlpha*iAlpha;
  
  double array3x3[] = {
    1.,    a1,    1.,
    a1,    a2,    a1,
    1.,    a1,    1.
  };
  ConvolutionKerneld kernel(3,3, array3x3);
  kernel.Normalize();
  return kernel;

} // elxMakeLowpass3x3d


//----------------------------------------------------------------------------
//  Cone
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeCone5x5d()
{
  static double ms_array5x5[] = {
     0.,     0.,     1./25., 0.,     0.,
     0.,     2./25., 2./25., 2./25., 0.,
     1./25., 2./25., 5./25., 2./25., 1./25.,
     0.,     2./25., 2./25., 2./25., 0.,
     0.,     0.,     1./25., 0.,     0.
  };
  static const ConvolutionKerneld ms_kernel(5,5, ms_array5x5);
  return ms_kernel;
  
} // elxMakeCone5x5d

//----------------------------------------------------------------------------
//  Pyramidal
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakePyramidal5x5d()
{
  static double ms_array5x5[] = {
     1./81., 2./81., 3./81., 2./81., 1./81.,
     2./81., 4./81., 6./81., 4./81., 2./81.,
     3./81., 6./81., 9./81., 6./81., 3./81.,
     2./81., 4./81., 6./81., 4./81., 2./81.,
     1./81., 2./81., 3./81., 2./81., 1./81.
  };
  static const ConvolutionKerneld ms_kernel(5,5, ms_array5x5);
  return ms_kernel;
  
} // elxMakePyramidal5x5d



//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                              Sharpen kernels
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//----------------------------------------------------------------------------
//  elxMakeSharpen3x3d: 
//  iAmount in range [0.0 .. 10.0] default 5.0
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeSharpen3x3d(double iAmount)
{
  const double ratio = 1. / (1. + (10. - iAmount) * 5.);
  const double max = 1. / (4. * (1. + ratio));
  const double min = max * ratio;
 
  double array3x3[] = {
    -min, -max, -min, 
    -max,    2, -max, 
    -min, -max, -min
  };
  ConvolutionKerneld kernel(3,3, array3x3);
  return kernel;

} // elxMakeSharpen3x3d

//----------------------------------------------------------------------------
//  elxMakeSharpenSoft3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeSharpenSoft3x3d()
{
  static double ms_array3x3[] = {
     0., -1.,  0.,
    -1.,  5., -1.,
     0., -1.,  0.
  };
  static const ConvolutionKerneld ms_kernel(3,3, ms_array3x3);
  return ms_kernel;

} // elxMakeSharpenSoft3x3d

//----------------------------------------------------------------------------
//  elxMakeSharpenSoft5x5d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeSharpenSoft5x5d()
{
  static double ms_array5x5[] = {
      0.,  -1.,  -2.,  -1.,  -1.,
     -1.,  -4.,  -8.,  -4.,  -1.,
     -2.,  -8.,  64.,  -8.,  -2.,
     -1.,  -4.,  -8.,  -4.,  -1.,
      0.,  -1.,  -2.,  -1.,  -1.
  };
  static const ConvolutionKerneld ms_kernel(5,5, ms_array5x5);
  return ms_kernel;
  
} // elxMakeSharpenSoft5x5d

//----------------------------------------------------------------------------
//  elxMakeSharpenSmooth3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeSharpenSmooth3x3d(double iAlpha)
{
  const double a = 1.0/(1.0 + iAlpha);
  const double a1 = -iAlpha*a;
  const double a2 = (iAlpha - 1.0)*a;
  const double a3 = (iAlpha + 5.0)*a;
  
  double array3x3[] = {
    a1,   a2,   a1, 
    a2,   a3,   a2,
    a1,   a2,   a1
  };
  ConvolutionKerneld kernel(3,3, array3x3);
  return kernel;

} // elxMakeSharpenSmooth3x3d

//----------------------------------------------------------------------------
//  elxMakeSharpenMore3x3d: 
//  iAlpha in range [0.0 .. 10.0] default 1.0
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeSharpenMore3x3d(double iAlpha)
{
  const double a = -iAlpha;
  const double c = 1.0 + 8.0*iAlpha;
  
  double array3x3[] = {
    a,   a,   a, 
    a,   c,   a,
    a,   a,   a
  };
  ConvolutionKerneld kernel(3,3, array3x3);
  return kernel;

} // elxMakeSharpenMore3x3d

		
//----------------------------------------------------------------------------
//  elxMakeSharpen: Negative Gaussian bell with center valued with 2.0
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeSharpen(double iRadius)
{
  int32 n = int32(iRadius + 0.5);
  if (0 == (n & 1)) n++;
  double s = 1./double(n*n);

  const int32 d = 2*n+1;
  ConvolutionKerneld kernel(d,d);
  double g, sum = 0.;
  int32 i,j, k = 0;
  
  for (j=-n; j<=n; j++)
    for (i=-n; i<=n; i++)
      if ((i != 0) || (j != 0))
      {
        g = elxExp(-2. * s * double(i*i + j*j));
        kernel._spK[k++] = -g; 
        sum += g;
      }
      else
        k++;

  // normalize
  s = 1.0/sum;
  k = 0;
  for (j=-n; j<=n; j++)
    for (i=-n; i<=n; i++)
      if ((i != 0) || (j != 0))
        kernel._spK[k++] *= s; 
      else
        kernel._spK[k++] = 2.0; 

  return kernel;

} // elxMakeSharpen


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                      gradient edge detectors kernels
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//
// - Prewitt:     1   1    1
// - FreiChen:    1  1.41  1
// - Sobel:       1   2    1
//

//----------------------------------------------------------------------------
//  elxMakePixelDifference3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakePixelDifference3x3d()
{
  static double ms_array3x3[] = {
     0.,  1.,  0.,
     0., -1.,  0.,
     0.,  0.,  0.
   };
   static const ConvolutionKerneld ms_kernel(3,3, ms_array3x3);
   return ms_kernel;

} // elxMakePixelDifference3x3d

//----------------------------------------------------------------------------
//  elxMakeSeparatedPixelDifference3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeSeparatedPixelDifference3x3d()
{
  static double ms_array3x3[] = {
     0.,  1.,  0.,
     0.,  0.,  0.,
     0., -1.,  0.
   };
   static const ConvolutionKerneld ms_kernel(3,3, ms_array3x3);
   return ms_kernel;

} // elxMakeSeparatedPixelDifference3x3d

//----------------------------------------------------------------------------
//  elxMakeRoberts3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeRoberts3x3d()
{
  static double ms_array3x3[] = {
     1.,  0.,  0.,
     0., -1.,  0.,
     0.,  0.,  0.
   };
   static const ConvolutionKerneld ms_kernel(3,3, ms_array3x3);
   return ms_kernel;

} // elxMakeRoberts3x3d


//----------------------------------------------------------------------------
//  elxMakePrewitt3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakePrewitt3x3d()
{
  static double ms_array3x3[] = {
     1.,  1.,  1.,
     0.,  0.,  0.,
    -1., -1., -1.
   };
   static const ConvolutionKerneld ms_kernel(3,3, ms_array3x3);
   return ms_kernel;

} // elxMakePrewitt3x3d

//----------------------------------------------------------------------------
//  elxMakePrewitt5x5d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakePrewitt5x5d()
{
  static double ms_array5x5[] = {
     1.,  2.,  3.,  2.,  1.,
     0.,  0.,  0.,  0.,  0.,
    -2., -4., -6., -4., -2., 
     0.,  0.,  0.,  0.,  0.,
     1.,  2.,  3.,  2.,  1.
  };
  static const ConvolutionKerneld ms_kernel(5,5, ms_array5x5);
  return ms_kernel;
  
} // elxMakePrewitt5x5d


//----------------------------------------------------------------------------
//  elxMakeFreiChen3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeFreiChen3x3d()
{
  static double ms_array3x3[] = {
     1.,  M_SQRT2,  1.,
     0.,       0.,  0.,
    -1., -M_SQRT2, -1.
   };
   static const ConvolutionKerneld ms_kernel(3,3, ms_array3x3);
   return ms_kernel;

} // elxMakeFreiChen3x3d


//----------------------------------------------------------------------------
//  elxMakeSobel3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeSobel3x3d()
{
  static double ms_array3x3[] = {
     1.,  2.,  1.,
     0.,  0.,  0.,
    -1., -2., -1.
  };
  static const ConvolutionKerneld ms_kernel(3,3, ms_array3x3);
  return ms_kernel;
  
} // elxMakeSobel3x3d

//----------------------------------------------------------------------------
//  elxMakeSobel5x5d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeSobel5x5d()
{
  static double ms_array5x5[] = {
     1.,  4.,   8.,  4.,  1.,
     0.,  0.,   0.,  0.,  0.,
    -2., -8., -12., -8., -2.,
     0.,  0.,   0.,  0.,  0.,
     1.,  4.,   8.,  4.,  1.
  };
  static const ConvolutionKerneld ms_kernel(5,5, ms_array5x5);
  return ms_kernel;
  
} // elxMakeSobel5x5d

//----------------------------------------------------------------------------
//  elxMakeSobelXNxNd
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeSobelNxNd(uint32 iSize)
{
  uint32 size = (iSize < 3)? 3: iSize;
  if ((size & 1) == 0) 
    ++size;
  ConvolutionKerneld kernel(size, size);
  for (uint32 i = 0; i < iSize; ++i)
  {
    int32 val = (i <= size /2) ? 1 + i : size - i; 
    for (uint32 j = 0; j < size/2; ++j)
    {
      kernel._spK[i*size+j] = -double(val + j); 
      kernel._spK[i*size+size-j-1] = double(val + j);
    }
    kernel._spK[i*size+size/2] = 0.0;
  }  
  return kernel;

} // elxMakeSobelNxNd


//----------------------------------------------------------------------------
//  elxMakeKirsch3x3d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeKirsch3x3d()
{
  static double ms_array3x3[] = {
     3.,  3.,  3.,
     3.,  0.,  3.,
    -5., -5., -5.
   };
   static const ConvolutionKerneld ms_kernel(3,3, ms_array3x3);
   return ms_kernel;

} // elxMakeKirsch3x3d

//----------------------------------------------------------------------------
//  elxMakeKirsch5x5d
//----------------------------------------------------------------------------
ConvolutionKerneld elxMakeKirsch5x5d()
{
  static double ms_array5x5[] = {
     9.,  18.,  27.,  18.,   9.,
    18.,  18.,  36.,  18.,  18.,
   -21., -51., -72., -51., -21.,
    18.,  18.,  36.,  18.,  18.,
     9.,  18.,  27.,  18.,   9.
  };
  static const ConvolutionKerneld ms_kernel(5,5, ms_array5x5);
  return ms_kernel;
  
} // elxMakeKirsch5x5d


} // namespace Math
} // namespace eLynx
