//============================================================================
//  BellSurface.cpp                                     Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/math/BellSurface.h>

#include <math.h>

namespace eLynx {
namespace Math {
  
//----------------------------------------------------------------------------
// evaluate the curve
  
double BellSurface::Evaluate(const IVector &iVars, const IVector &iParams) const
{
  // check vector sizes
  CheckInputs(iVars, iParams);
  
  // extract vars and params
  const double x = iVars(0);
  const double y = iVars(1);
  const double g = iParams(0);
  const double h = iParams(1);
  const double b = iParams(2);
  
  // evaluate the function
  return g*exp((-y*y-x*x)/(2.0*h*h))+b;
}

    
//----------------------------------------------------------------------------
// evaluate the function derivative by param

double BellSurface::EvalDerivativeByParam(const IVector &iVars, 
    const IVector &iParams, uint32 iByParam) const
{
  // check vector sizes
  CheckInputs(iVars, iParams);
  
  // check param index
  if (iByParam >= GetParametersCount()) 
    elxThrow(elxErrOutOfRange, elxMsgFormat("Parameter to differentiate (%i) "
      "out of range (0, %i).", iByParam, GetParametersCount()-1));
      
  // extract vars and params
  const double x = iVars(0);
  const double y = iVars(0);
  const double g = iParams(0);
  const double h = iParams(1);
      
  // evaluate aprropriate derivative
  switch (iByParam) {
    
    // derivative by g
    case 0: {
      return exp((-y*y-x*x)/(2.0*h*h));
    }
    
    // derivative by h
    case 1: {
      return -(g*(-y*y-x*x)*exp((-y*y-x*x)/(2.0*h*h)))/(h*h*h);
    }
    
    // derivative by b
    case 2: {
      return 1.0;
    }
  }
  
  // we should never get there
  return 0.0;
}
 
  
//----------------------------------------------------------------------------
// checks the sizes of input vectors

void BellSurface::CheckInputs(const IVector &iVars, const IVector &iParams) const
{
  // check number of independent variables
  if (iVars.GetSize() != GetVariablesCount()) 
    elxThrow(elxErrInvalidParams, elxMsgFormat("Number of variable values (%i) "
      "does not match the function (%i).", 
      iVars.GetSize(), GetVariablesCount()));
      
  // check number of independent parameters
  if (iParams.GetSize() != GetParametersCount())
    elxThrow(elxErrInvalidParams, elxMsgFormat("Number of parameter values "
      "(%i) does not match the function (%i).", 
      iParams.GetSize(), GetParametersCount()));
}

//----------------------------------------------------------------------------

} // namespace Math
} // namespace eLynx
