//============================================================================
//  Geometry/Intersections.hpp                          Math.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Intersections_hpp__
#define __Geometry_Intersections_hpp__

namespace eLynx {
namespace Math {

//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                              Line2 / Line2
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T, typename U> 
inline
bool elxIntersectLineLine(
  const T iX11, const T iY11, const T iX12, const T iY12,
  const T iX21, const T iY21, const T iX22, const T iY22, 
  U& X, U& Y)
{
  U d = (iX11 - iX12)*(iY21 - iY22) - (iY11 - iY12)*(iX21 - iX22);
  if (d == 0)
    return false;
  const T a = iX11*iY12 - iY11*iX12;
  const T b = iX21*iY22 - iY21*iX22;
  X = U(a*(iX21 - iX22) - b*(iX11 - iX12))/d;
  Y = U(a*(iY21 - iY22) - b*(iY11 - iY12))/d;
  return true;

} // elxIntersectLineLine

//----------------------------------------------------------------------------
template <typename T> 
inline
bool elxIntersectLineLine(
  const T iX11, const T iY11, const T iX12, const T iY12,
  const T iX21, const T iY21, const T iX22, const T iY22, 
  T& X, T& Y)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  F fx, fy;
  bool result = elxIntersectLineLine<T, F>(
    iX11, iY11, iX12, iY12, iX21, iY21, iX22, iY22, fx, fy);
  if (result)
  {
    X = T(elxRound(fx));
    Y = T(elxRound(fy));
  }
  return result;

} // elxIntersectLineLine


//----------------------------------------------------------------------------
template <typename T> 
inline
bool elxIntersectLineLine(
  const Point2<T>& iPoint11, const Point2<T>& iPoint12,
  const Point2<T>& iPoint21, const Point2<T>& iPoint22, 
  Point2<T>& oPoint)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  F fx, fy;
  const bool bSuccess = elxIntersectLineLine<T, F>(
    iPoint11._x, iPoint11._y, iPoint12._x, iPoint12._y,
    iPoint21._x, iPoint21._y, iPoint22._x, iPoint22._y,
    fx, fy);
  if (bSuccess)
  {
    oPoint._x = T(elxRound(fx));
    oPoint._y = T(elxRound(fy));
  }
  return bSuccess;

} // elxIntersectLineLine 

//----------------------------------------------------------------------------
template <typename T, typename U> 
inline
bool elxIntersectLineLine(
  const Point2<T>& iPoint11, const Point2<T>& iPoint12,
  const Point2<T>& iPoint21, const Point2<T>& iPoint22, 
  Point2<U>& oPoint)
{
  return elxIntersectLineLine<T, U>(
    iPoint11._x, iPoint11._y, iPoint12._x, iPoint12._y,
    iPoint21._x, iPoint21._y, iPoint22._x, iPoint22._y,
    oPoint._x, oPoint._y);

} // elxIntersectLineLine 


//----------------------------------------------------------------------------
template <typename T>
inline
bool elxIntersectLineSegment(
  const Point2<T>& iPoint1, const Point2<T>& iPoint2, 
  const Segment2<T>& iSegment, Point2<T>& oPoint)
{
  typedef typename ResolutionTypeTraits<T>::Floating_type F;
  Point2<F> point;
  if (elxIntersectLineLine(iPoint1, iPoint2, iSegment._P0, iSegment._P1, point))
  {
    bool result = (iSegment._P0._x < iSegment._P1._x) ?
     iSegment._P0._x <= point._x && point._x <= iSegment._P1._x :
     iSegment._P1._x <= point._x && point._x <= iSegment._P0._x;
    oPoint._x = T(point._x);
    oPoint._y = T(point._y);
    return 
      result && ((iSegment._P0._y < iSegment._P1._y) ?
        iSegment._P0._y <= point._y && point._y <= iSegment._P1._y :
        iSegment._P1._y <= point._y && point._y <= iSegment._P0._y);
    
  };
  return false;

} // elxIntersectLineSegment


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                              Rectangle2 / Line2
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T>
//inline
bool elxIntersectLineRectangle(
  const Point2<T>& iPoint1, const Point2<T>& iPoint2,
  const Rectangle2<T>& iRectangle, Segment2<T>& oSegment)
{
  Rectangle2<T> rectangle(iRectangle); // Return copy optimization
  if (rectangle._P0._x > rectangle._P1._x)
    std::swap(rectangle._P0, rectangle._P1);
  int32 dy = (iPoint1._x > iPoint2._x) ? 
    iPoint1._y - iPoint2._y : iPoint2._y - iPoint1._y;
    
  Segment2<T> segment(
    rectangle._P0, Point2<T>(rectangle._P1._x, rectangle._P0._y));
  if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P0))
  {
    if (dy < 0)
    {
      segment._P0 = rectangle._P0; 
      segment._P1._x = rectangle._P0._x;  segment._P1._y =  rectangle._P1._y;
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
      segment._P0 = segment._P1; segment._P1 = rectangle._P1;
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
    }
    else
    {
      segment._P0._x = rectangle._P1._x;  segment._P0._y =  rectangle._P0._y;
      segment._P1 = rectangle._P1; 
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
      segment._P0._x = rectangle._P0._x;  segment._P0._y =  rectangle._P1._y;
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
    }
    //shouldn't get there
    BOOST_ASSERT(false);    
  }
  
  segment._P0._x = rectangle._P0._x;  segment._P0._y =  rectangle._P1._y;
  segment._P1 = rectangle._P1; 
  if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P0))
  {
    if (dy < 0)
    {
      segment._P0._x = rectangle._P1._x;  segment._P0._y =  rectangle._P0._y;
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
    }
    else
    {
      segment._P0 = rectangle._P0;
      segment._P1._x = rectangle._P0._x;  segment._P1._y =  rectangle._P1._y;
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
    }
    //shouldn't get there
    BOOST_ASSERT(false);    
  }
  
  segment._P0._x = rectangle._P1._x;  segment._P0._y =  rectangle._P0._y;
  segment._P1 = rectangle._P1; 
  if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P0))
  {
    segment._P0 = rectangle._P0; 
    segment._P1._x = rectangle._P0._x;  segment._P1._y =  rectangle._P1._y;
    BOOST_ASSERT(
      elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1));
    return true;
  }
  return false;
 
} // elxIntersectLineRectangle


//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
//                              Rectangle2 / Circle2
//<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
template <typename T> 
inline
bool elxIntersectCircleRectangle(
  const Rectangle2<T>& iRectangle, const Point2<T>& iPoint, T iRadius)
{
  const T rad2 = iRadius*iRadius;
  const Point2<T> p1(iRectangle._P0._x - iPoint._x, iRectangle._P0._y - iPoint._y);
  const Point2<T> p2(iRectangle._P1._x - iPoint._x, iRectangle._P1._y - iPoint._y);
  
  if (p2._x < 0)                         //R to the left of the circle center
    if (p2._y < 0)                                // top left corner
      return ((p2._x*p2._x + p2._y*p2._y) < rad2);
    else if (p1._y > 0)                           // bottom left corner
      return ((p2._x*p2._x + p1._y*p1._y) < rad2);
    else
      return elxAbs(p2._x) < iRadius;             // left
  else if (p1._x > 0)                     //R to the right of the circle center 
    if (p2._y < 0)                                // top right corner 
      return ((p1._x*p1._x + p2._y*p2._y) < rad2);
    else if (p1._y > 0)                           // bottom right corner
      return ((p1._x*p1._x + p1._y*p1._y) < rad2);
    else
      return p1._x < iRadius;             // right
  else                                    // R on circle vertical centerline
    if (p1._y > 0)                        // south
      return p1._y < iRadius;
    else if (p2._y < 0)                   // north
      return elxAbs(p2._y) < iRadius;

  return true;

} // elxIntersectCircleRectangle

} // namespace Math
} // namespace eLynx

#endif // __Geometry_Intersections_hpp__
