//============================================================================
//  Line.hpp                                            Math.Component package
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#ifndef __Geometry_Line_hpp__
#define __Geometry_Line_hpp__

namespace eLynx {
namespace Math {

//============================================================================
//               2d Line processing at every integer coordinates
//============================================================================
template <class Operator>
inline
void elxProcessLine2i(
    int32 iX1, int32 iY1, int32 iX2, int32 iY2, // two ending points
    int32 iW, int32 iH, // clipped rectangle area (0,0) (iW-1, iH-1)
    Operator& iOperator) // what's to do at each line's points
{
  int32 xinc1, xinc2;
  if (iX2 >= iX1)                 
  {
    // x-values are increasing
    xinc1 = 1;
    xinc2 = 1;
  }
  else
  {
    // x-values are decreasing
    xinc1 = -1;
    xinc2 = -1;
  }
 
  int32 yinc1, yinc2;
  if (iY2 >= iY1)
  {
    // y-values are increasing
    yinc1 = 1;
    yinc2 = 1;
  }
  else
  {
    // y-values are decreasing
    yinc1 = -1;
    yinc2 = -1;
  }

  int32 dx = Math::elxAbs(iX2 - iX1);
  int32 dy = Math::elxAbs(iY2 - iY1);

  int32 den, num, numadd, nPixel;
  
  if (dx >= dy)
  {
    // There is at least one x-value for every y-value
    nPixel = dx;  // There are more x-values than y-values
    xinc1 = 0;    // Don't change the x when numerator >= denominator
    yinc2 = 0;    // Don't change the y for every iteration
    den = dx;
    num = dx / 2;
    numadd = dy;
  }
  else
  {
    // There is at least one y-value for every x-value
    nPixel = dy;  // There are more y-values than x-values
    xinc2 = 0;    // Don't change the x for every iteration
    yinc1 = 0;    // Don't change the y when numerator >= denominator
    den = dy;
    num = dy / 2;
    numadd = dx;
  }

  int32 x = iX1;
  int32 y = iY1;
  for (int32 i=0; i<=nPixel; i++)
  {
    // fast clipped plot
    if (0<=x && x<iW && 0<=y && y < iH)
      iOperator(x,y);

    // Increase the numerator by the top of the fraction
    num += numadd;

    // Check if numerator >= denominator
    if (num >= den)
    {
      // Calculate the new numerator value
      num -= den;

      // Change the x as appropriate
      x += xinc1;

      // Change the y as appropriate
      y += yinc1;
    }

    // Change the x as appropriate
    x += xinc2;

    // Change the y as appropriate
    y += yinc2;
  }

} // elxProcessLine2i

//----------------------------------------------------------------------------
template <class Operator>
inline
void elxProcessLine2i(
  const Math::Point2i& iP1, const Math::Point2i& iP2, // two ending points
  int32 iW, int32 iH, // clipped rectangle area (0,0) (iW-1, iH-1)
  Operator& iOperator) // what's to do at each line's points
{
  elxProcessLine2i(iP1._x, iP1._y, iP2._x, iP2._y, iW, iH, iOperator);
}

} // namespace Math
} // namespace eLynx

#endif // __Geometry_Line_hpp__
