//============================================================================
//  Geometry.cpp                                        Math.Component package
//============================================================================
//  
//============================================================================
//  Copyright (C) 2008 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/math/Geometry.h>
#include "Geometry/Line.hpp"
#include "Geometry/Intersections.hpp"

namespace eLynx {
namespace Math {

namespace {

struct OperatorAddPoint2i
{
  OperatorAddPoint2i(Point2iList& ioPointList) : _list(ioPointList) {}
  void operator()(int32 iX, int32 iY)
  {
    _list.push_back( Point2i(iX, iY) );
  }

  Point2iList& _list;

};

} // namespace

//----------------------------------------------------------------------------
// elxComputeLinePoints
//----------------------------------------------------------------------------
void elxComputeLinePoints(
    const Point2i& iP1, const Point2i& iP2, 
    int32 iW, int32 iH, 
    Point2iList& oList)
{
  OperatorAddPoint2i addPoint(oList);
  elxProcessLine2i(iP1._x, iP1._y, iP2._x, iP2._y, iW, iH, addPoint);

} // elxComputeLinePoints


//----------------------------------------------------------------------------
// explicit instantiations
//----------------------------------------------------------------------------

// --- Point2 ---
template class Point2<int32>;
template class Point2<int64>;
template class Point2<float>;
template class Point2<double>;

// --- Point3 ---
template class Point3<int32>;
template class Point3<int64>;
template class Point3<float>;
template class Point3<double>;

// --- Segment2 ---
template class Segment2<int32>;
template class Segment2<int64>;
template class Segment2<float>;
template class Segment2<double>;

// --- Segment3 ---
template class Segment3<int32>;
template class Segment3<int64>;
template class Segment3<float>;
template class Segment3<double>;

// --- Triangle2 ---
template class Triangle2<int32>;
template class Triangle2<int64>;
template class Triangle2<float>;
template class Triangle2<double>;

// --- Triangle3 ---
template class Triangle3<int32>;
template class Triangle3<int64>;
template class Triangle3<float>;
template class Triangle3<double>;

// --- AOBBox2 ---
template class AOBBox2<int32>;
template class AOBBox2<int64>;
template class AOBBox2<float>;
template class AOBBox2<double>;

// --- Rectangle2 ---
template class Rectangle2<int32>;
template class Rectangle2<int64>;
template class Rectangle2<float>;
template class Rectangle2<double>;


// --- methods ---
template bool elxIntersectLineLine<int32>(
  const Point2<int32>&, const Point2<int32>&, const Point2<int32>&, const Point2<int32>&,
  Point2<int32>&);

template bool elxIntersectLineSegment<int32>(
  const Point2<int32>&, const Point2<int32>&, const Segment2<int32>&, 
  Point2<int32>&);

#if 0
template 
bool elxIntersectLineRectangle(
  const Point2<int32>&, const Point2<int32>&, const Rectangle2<int32>&, Segment2<int32>&);
#else
bool elxIntersectLineRectangle(
  const Point2<int32>& iPoint1, const Point2<int32>& iPoint2,
  const Rectangle2<int32>& iRectangle, Segment2<int32>& oSegment)
{
  Rectangle2<int32> rectangle(iRectangle); // Return copy optimization
  if (rectangle._P0._x > rectangle._P1._x)
    std::swap(rectangle._P0, rectangle._P1);
  int32 dy = (iPoint1._x > iPoint2._x) ? 
    iPoint1._y - iPoint2._y : iPoint2._y - iPoint1._y;
    
  Segment2<int32> segment(
    rectangle._P0, Point2<int32>(rectangle._P1._x, rectangle._P0._y));
  if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P0))
  {
    if (dy < 0)
    {
      segment._P0 = rectangle._P0; 
      segment._P1._x = rectangle._P0._x;  segment._P1._y =  rectangle._P1._y;
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
      segment._P0 = segment._P1; segment._P1 = rectangle._P1;
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
    }
    else
    {
      segment._P0._x = rectangle._P1._x;  segment._P0._y =  rectangle._P0._y;
      segment._P1 = rectangle._P1; 
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
      segment._P0._x = rectangle._P0._x;  segment._P0._y =  rectangle._P1._y;
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
    }
    //shouldn't get there
    BOOST_ASSERT(false);    
  }
  
  segment._P0._x = rectangle._P0._x;  segment._P0._y =  rectangle._P1._y;
  segment._P1 = rectangle._P1; 
  if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P0))
  {
    if (dy < 0)
    {
      segment._P0._x = rectangle._P1._x;  segment._P0._y =  rectangle._P0._y;
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
    }
    else
    {
      segment._P0 = rectangle._P0;
      segment._P1._x = rectangle._P0._x;  segment._P1._y =  rectangle._P1._y;
      if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1))
        return true;
    }
    //shouldn't get there
    BOOST_ASSERT(false);    
  }
  
  segment._P0._x = rectangle._P1._x;  segment._P0._y =  rectangle._P0._y;
  segment._P1 = rectangle._P1; 
  if (elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P0))
  {
    segment._P0 = rectangle._P0; 
    segment._P1._x = rectangle._P0._x;  segment._P1._y =  rectangle._P1._y;
    BOOST_ASSERT(
      elxIntersectLineSegment(iPoint1, iPoint2, segment, oSegment._P1));
    return true;
  }
  return false;
 
} // elxIntersectLineRectangle

#endif
} // namespace Math
} // namespace eLynx

