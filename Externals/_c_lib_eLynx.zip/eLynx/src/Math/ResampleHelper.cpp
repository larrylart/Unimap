//============================================================================
//  ResampleHelper.cpp                                  Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/math/ResampleHelper.h>
#include <math.h>

namespace eLynx {
namespace Math {

//----------------------------------------------------------------------------
//  constructor
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
ResampleHelper::ResampleHelper(
    uint32 iOldSize, uint32 iNewSize, 
    EResampleFilter iFilter) :
  _newSize(iNewSize)
{
  if ((0 == iOldSize) || (0 == iNewSize))
    elxThrow(elxErrInvalidParams, "Invalid Parameters.");

  // get specified filter
  const IResampleFilter& filter = elxGetResampleFilter(iFilter);
  const double radius = filter.GetRadius();

  double scale = (double)iNewSize/(double)iOldSize;
  double center, weight;
  int32 j, left, right, idx;
  uint32 i;

  _spContributors.reset( new Contributor[iNewSize] );
  
  if (scale < 1.0)
  {
    // downsampling: scales from bigger to smaller width
    const double width = radius/scale;
    const uint32 size = (uint32)floor(2.0*width + 1.0);
    for (i=0; i<iNewSize; i++)
    {
      Contributor& c = _spContributors[i];
      c._n = 0;
      c._plSampleList = new SampleWeight[size];
      c._weightSum = 0.0;

      center = (i + 0.5)/scale;
      left   = (int32)(center - width);
      right  = (int32)(center + width);

      for (j=left; j<=right; j++)
      {
        weight = filter.GetValue((center - j - 0.5)*scale);
        if ((0.0 == weight) || (j < 0) || (j >= (int32)iOldSize)) continue;

        idx = c._n;
        c._plSampleList[idx]._sample = j;
        c._plSampleList[idx]._weight = weight;
        c._weightSum += weight;
        c._n++;
      }
    }
  } 
  else 
  {
    // upsampling: scales from smaller to bigger width
    const uint32 size = (uint32)floor(2.0*radius + 1.0);
    for (i=0; i<iNewSize; i++)
    {
      Contributor& c = _spContributors[i];
      c._n = 0;
      c._plSampleList = new SampleWeight[size];
      c._weightSum = 0.0;

      center = (i + 0.5)/scale;
      left  = (int32)floor(center - radius);
      right = (int32)ceil( center + radius);
      for (j=left; j<=right; j++)
      {
        weight = filter.GetValue(center - j - 0.5);
        if ((0.0 == weight) || (j < 0) || (j >= (int32)iOldSize)) continue;
        idx = c._n;
        c._plSampleList[idx]._sample = j;
        c._plSampleList[idx]._weight = weight;
        c._weightSum += weight;
        c._n++;
      }
    }
  }

  // update weights
  for (i=0; i<iNewSize; i++)
  {
    Contributor& c = _spContributors[i];
    const double ws = c._weightSum;
    if (0.0 == ws) continue;
    const double scale = 1.0 / ws;
    for (j=0; j<c._n; j++)
      c._plSampleList[j]._weight *= scale;
  }

} // constructor


//----------------------------------------------------------------------------
//  GetContributorCount
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
uint32 ResampleHelper::GetContributorCount(uint32 iIndex) const
{
  if (iIndex >= _newSize)
    return 0;

  return _spContributors[iIndex]._n;

} // GetContributorCount


//----------------------------------------------------------------------------
//  GetOldIndex
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
uint32 ResampleHelper::GetOldIndex(uint32 iNewIndex, uint32 iContributor) const
{
  return _spContributors[iNewIndex]._plSampleList[iContributor]._sample;

} // GetOldIndex


//----------------------------------------------------------------------------
//  GetWeight
//----------------------------------------------------------------------------
//  public
//----------------------------------------------------------------------------
double ResampleHelper::GetWeight(uint32 iNewIndex, uint32 iContributor) const
{
  return _spContributors[iNewIndex]._plSampleList[iContributor]._weight;

} // GetWeight

} // namespace Math
} // namespace eLynx
