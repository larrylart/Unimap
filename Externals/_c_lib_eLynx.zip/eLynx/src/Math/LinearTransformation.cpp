//============================================================================
//  LinearTransformation.cpp                            Math.Component package
//============================================================================
//  Usage : linear transformation class implementation
//----------------------------------------------------------------------------
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/core/CoreException.h>
#include <elx/math/LinearTransformation.h>

#include <string.h>
#include <math.h>
#include <algorithm>

namespace eLynx {
namespace Math {
	
//----------------------------------------------------------------------------
// constructor, creates null transformation

LinearTransformation::LinearTransformation() : AbstractTransformation()
{
	Identity();
	_spInverted.reset(NULL);
}


//----------------------------------------------------------------------------
// copy constructor

LinearTransformation::LinearTransformation(const LinearTransformation &c)
	: AbstractTransformation()
{
	CopyData(c);
}


//----------------------------------------------------------------------------
// an assignement operator

LinearTransformation& LinearTransformation::operator = (
	const LinearTransformation &c)
{
	if (&c != this) CopyData(c);
	return *this;
}


//----------------------------------------------------------------------------
// creates copy of this object

boost::shared_ptr<AbstractTransformation> LinearTransformation::Clone() const
{
  return boost::shared_ptr<AbstractTransformation>(
    new LinearTransformation(*this));
}


//----------------------------------------------------------------------------
// returns specified value of the matrix

double LinearTransformation::GetValue(uint32 iRow, uint32 iCol) const
{
	// check indices
	if (iRow >= 3 || iCol >= 3) 
		elxThrow(elxErrOutOfRange, elxMsgFormat(
			"Matrix indices [%i, %i] out of range <0..2>x<0..2>.", iRow, iCol));
			
	return _Matrix[iRow][iCol];
}


//----------------------------------------------------------------------------
// sets specified value of the matrix

void LinearTransformation::SetValue(uint32 iRow, uint32 iCol, double iValue) 
{
	// check indices
	if (iRow >= 3 || iCol >= 3) 
		elxThrow(elxErrOutOfRange, elxMsgFormat(
			"Matrix indices [%i, %i] out of range <0..2>x<0..2>.", iRow, iCol));
			
	_Matrix[iRow][iCol] = iValue;
	_spInverted.reset(NULL);
}


//----------------------------------------------------------------------------
// nulls whole matrix

LinearTransformation& LinearTransformation::NullTransformation()
{
	for (uint32 r = 0; r < 3; r++)
		for (uint32 c = 0; c < 3; c++) 
			_Matrix[r][c] = 0.0;
		
	_spInverted.reset(NULL);
	
	return *this;
}


//----------------------------------------------------------------------------
// sets matrix to identity transformation

LinearTransformation& LinearTransformation::Identity()
{
	for (uint32 r = 0; r < 3; r++)
		for (uint32 c = 0; c < 3; c++) 
			if (r == c) _Matrix[r][c] = 1.0;
			else _Matrix[r][c] = 0.0;
			
	_spInverted.reset(NULL);
			
	return *this;
}


//----------------------------------------------------------------------------
// checks whether transformation is identity

bool LinearTransformation::IsIdentity() const
{
  for (uint32 r = 0; r < 3; r++)
    for (uint32 c = 0; c < 3; c++) {
      if (c == r) {
         if (_Matrix[r][c] != 1.0) return false;
      }
      else {
        if (_Matrix[r][c] != 0.0) return false;
      }      
    }
  return true;
}


//----------------------------------------------------------------------------
// sets matrix to translation

LinearTransformation& LinearTransformation::Translation(double iDX, double iDY)
{
	Identity();
	SetValue(2, 0, iDX);
	SetValue(2, 1, iDY);
	
	return *this;
}


//----------------------------------------------------------------------------
// sets matrix to rotation

LinearTransformation& LinearTransformation::Rotation(double iAngle)
{
	double ca = cos(iAngle);
	double sa = sin(iAngle);
	
	Identity();
	SetValue(0, 0, ca); SetValue(0, 1, -sa);
	SetValue(1, 0, sa); SetValue(1, 1, ca);
	
	return *this;
}


//----------------------------------------------------------------------------
// sets matrix to scaling

LinearTransformation& LinearTransformation::Scale(double iSX, double iSY)
{
	Identity();
	SetValue(0, 0, iSX);
	SetValue(1, 1, iSY);
	
	return *this;
}


//----------------------------------------------------------------------------
// sets matrix to general transformation

LinearTransformation& LinearTransformation::GeneralTransformation(
	double iA, double iB, double iC, double iD, double iE, double iF)
{
	Identity();
	SetValue(0, 0, iA); SetValue(0, 1, iD);
	SetValue(1, 0, iB); SetValue(1, 1, iE);
	SetValue(2, 0, iC); SetValue(2, 1, iF);
	
	return *this;
}


//----------------------------------------------------------------------------
// mutliplies current matrix with given matrix

LinearTransformation& LinearTransformation::Multiply(
	const LinearTransformation &iTrf)
{
	double tmp[3][3];

	for (uint32 r = 0; r < 3; r++) 
		for (uint32 c = 0; c < 3; c++) {
			tmp[r][c] = 0.0;
			for (uint32 i = 0; i < 3; i++) 
				tmp[r][c] += _Matrix[r][i]*iTrf._Matrix[i][c];
		}

	memcpy(_Matrix, tmp, sizeof(double)*3*3);
	
	_spInverted.reset(NULL);
	
	return *this;
}


//----------------------------------------------------------------------------
// sets current matrix to inverse of given matrix

LinearTransformation& LinearTransformation::Inverse(
	const LinearTransformation &iTrf)
{
	double det = iTrf.Determinant();
	if (fabs(det) < 1e-6) 
		elxThrow(elxErrInvalidContext, "Can't invert singular matrix.");
		
	det = 1.0/det;
	
	for (uint32 r = 0; r < 3; r++)
		for (uint32 c = 0; c < 3; c++) {
			_Matrix[r][c] = det*iTrf.SubDeterminant(c, r);
			if ((c+r)%2 == 1) _Matrix[r][c] = -_Matrix[r][c];
		}
			
	_spInverted.reset(NULL);
			
	return *this;
}


//----------------------------------------------------------------------------
// transforms coordinates from first image to second

void LinearTransformation::Transform(double iX, double iY, 
	double& oX, double& oY) const
{
	oX = _Matrix[0][0]*iX + _Matrix[1][0]*iY + _Matrix[2][0];
	oY = _Matrix[0][1]*iX + _Matrix[1][1]*iY + _Matrix[2][1];
}


//----------------------------------------------------------------------------
// computes bounding box of transformed first image

void LinearTransformation::GetTransformedBBox(uint32 iWidth, uint32 iHeight,
	double& oLeft, double& oTop, double& oWidth, double& oHeight) const
{
	// get coordinates of transformed image corners
	double x[4], y[4];
	Transform(0, 0, x[0], y[0]);
	Transform(iWidth, 0, x[1], y[1]);
	Transform(iWidth, iHeight, x[2], y[2]);
	Transform(0, iHeight, x[3], y[3]);
	
	// get bounding box of transformed image corners
	oLeft = *std::min_element(x, x+4);
	oTop = *std::min_element(y, y+4);
	oWidth = *std::max_element(x, x+4)-oLeft;
	oHeight = *std::max_element(y, y+4)-oTop;
}


//----------------------------------------------------------------------------
// transforms coordinates from second image to first

void LinearTransformation::InverseTransform(double iX, double iY, 
	double& oX, double& oY) const
{
	if (_spInverted.get() == NULL) {
		_spInverted.reset(new LinearTransformation());
		_spInverted->Inverse(*this);
	}
	
	const LinearTransformation *imatrix = _spInverted.get();
	
	oX = imatrix->_Matrix[0][0]*iX + imatrix->_Matrix[1][0]*iY + 
		imatrix->_Matrix[2][0];
	oY = imatrix->_Matrix[0][1]*iX + imatrix->_Matrix[1][1]*iY + 
		imatrix->_Matrix[2][1];
}


//----------------------------------------------------------------------------
// computes bounding box of inverse transformed second image

void LinearTransformation::GetInverseBBox(uint32 iWidth, uint32 iHeight,
	double& oLeft, double& oTop, double& oWidth, double& oHeight) const	
{
	// get coordinates of transformed image corners
	double x[4], y[4];
	InverseTransform(0, 0, x[0], y[0]);
	InverseTransform(iWidth, 0, x[1], y[1]);
	InverseTransform(iWidth, iHeight, x[2], y[2]);
	InverseTransform(0, iHeight, x[3], y[3]);
	
	// get bounding box of transformed image corners
	oLeft = *std::min_element(x, x+4);
	oTop = *std::min_element(y, y+4);
	oWidth = *std::max_element(x, x+4)-oLeft;
	oHeight = *std::max_element(y, y+4)-oTop;
}


//----------------------------------------------------------------------------
// copies object data

void LinearTransformation::CopyData(const LinearTransformation &c)
{
	// copy the matrix
	memcpy(_Matrix, c._Matrix, sizeof(double)*3*3);
	// ignore inverted, it will be computed on the fly
	_spInverted.reset(NULL);
}


//----------------------------------------------------------------------------
// returns subdeterminant of matrix for rows and cols except specified

double LinearTransformation::SubDeterminant(uint32 iExceptRow, uint32 iExceptCol) const
{
	uint32 r1 = (iExceptRow == 0 ? 1 : 0);
	uint32 r2 = (iExceptRow == 2 ? 1 : 2);
	uint32 c1 = (iExceptCol == 0 ? 1 : 0);
	uint32 c2 = (iExceptCol == 2 ? 1 : 2);
	
	return _Matrix[r1][c1]*_Matrix[r2][c2]-_Matrix[r1][c2]*_Matrix[r2][c1];
}


//----------------------------------------------------------------------------
// returns the determinant of the matrix
	
double LinearTransformation::Determinant() const
{
	return _Matrix[0][0]*SubDeterminant(0, 0)-
		_Matrix[0][1]*SubDeterminant(0, 1)+
		_Matrix[0][2]*SubDeterminant(0, 2);
}

//----------------------------------------------------------------------------

} // namespace Math
} // namespace eLynx
