//============================================================================
//  MatrixRowVector.cpp                                 Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/math/MatrixRowVector.h>

namespace eLynx {
namespace Math {
	

//----------------------------------------------------------------------------
// constructor, creates matrix row vector adapter for specified matrix
// and row

MatrixRowVector::MatrixRowVector(IMatrix &iMatrix, uint32 iRow) 
	: _prMatrix(iMatrix), _Row(iRow)
{
}


//----------------------------------------------------------------------------
// copy constructor

MatrixRowVector::MatrixRowVector(const MatrixRowVector &iC)
	: _prMatrix(iC._prMatrix), _Row(iC._Row)
{
}


//----------------------------------------------------------------------------
// an assignement operator

MatrixRowVector& MatrixRowVector::operator = (const MatrixRowVector &iC)
{
	if (&iC != this) CopyData(iC);
	return *this;
}


//----------------------------------------------------------------------------
// swaps vector (matrix column) values

void MatrixRowVector::SwapValues(uint32 iIndex1, uint32 iIndex2)
{
	if (iIndex1 == iIndex2) return;
	double tmp = (*this)(iIndex1);
	(*this)(iIndex1) = (*this)(iIndex2);
	(*this)(iIndex2) = tmp;
}


//----------------------------------------------------------------------------
// copies object data

void MatrixRowVector::CopyData(const MatrixRowVector &iC)
{
	_prMatrix = iC._prMatrix;
	_Row = iC._Row;
}


//----------------------------------------------------------------------------

} // namespace Math
} // namespace eLynx
