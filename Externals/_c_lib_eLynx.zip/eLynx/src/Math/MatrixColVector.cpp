//============================================================================
//  MatrixColVector.cpp                                 Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <elx/math/MatrixColVector.h>

namespace eLynx {
namespace Math {
	

//----------------------------------------------------------------------------
// constructor, creates matrix column vector adapter for specified matrix
// and column

MatrixColVector::MatrixColVector(IMatrix &iMatrix, uint32 iCol) 
	: _prMatrix(iMatrix), _Col(iCol)
{
}


//----------------------------------------------------------------------------
// copy constructor

MatrixColVector::MatrixColVector(const MatrixColVector &iC)
	: _prMatrix(iC._prMatrix), _Col(iC._Col)
{
}


//----------------------------------------------------------------------------
// an assignement operator

MatrixColVector& MatrixColVector::operator = (const MatrixColVector &iC)
{
	if (&iC != this) CopyData(iC);
	return *this;
}

//----------------------------------------------------------------------------
// swaps vector (matrix column) values

void MatrixColVector::SwapValues(uint32 iIndex1, uint32 iIndex2)
{
	if (iIndex1 == iIndex2) return;
	double tmp = (*this)(iIndex1);
	(*this)(iIndex1) = (*this)(iIndex2);
	(*this)(iIndex2) = tmp;
}


//----------------------------------------------------------------------------
// copies object data

void MatrixColVector::CopyData(const MatrixColVector &iC)
{
	_prMatrix = iC._prMatrix;
	_Col = iC._Col;
}


//----------------------------------------------------------------------------

} // namespace Math
} // namespace eLynx
