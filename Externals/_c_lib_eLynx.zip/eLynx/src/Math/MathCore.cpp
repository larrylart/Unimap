//============================================================================
//  MathCore.cpp                                        Math.Component package
//============================================================================
//  Copyright (C) 2006 by eLynx project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Library General Public License for more details.
//----------------------------------------------------------------------------
#include <map>
#include <string>

#include <elx/math/MathCore.h>
#include <elx/math/Geometry.h>
#include <elx/math/BSpline.h>

namespace eLynx {
namespace Math {


//----------------------------------------------------------------------------
//  elxChannelMaskToString
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : iChannelMask
//  Out :
//----------------------------------------------------------------------------
const char * elxChannelMaskToString(uint32 iChannelMask)
{
  static std::map<uint32, std::string> ms_mask;
  if (ms_mask.empty())
  {
    ms_mask[CM_None]        = "CM_None";
    ms_mask[CM_Channel0]    = "CM_Channel0";
    ms_mask[CM_Channel1]    = "CM_Channel1";
    ms_mask[CM_Channel2]    = "CM_Channel2";
    ms_mask[CM_Channel3]    = "CM_Channel3";
    ms_mask[CM_Channel01]   = "CM_Channel01";
    ms_mask[CM_Channel02]   = "CM_Channel02";
    ms_mask[CM_Channel03]   = "CM_Channel03";
    ms_mask[CM_Channel12]   = "CM_Channel12";
    ms_mask[CM_Channel13]   = "CM_Channel13";
    ms_mask[CM_Channel23]   = "CM_Channel23";
    ms_mask[CM_Channel012]  = "CM_Channel012";
    ms_mask[CM_Channel013]  = "CM_Channel013";
    ms_mask[CM_Channel023]  = "CM_Channel023";
    ms_mask[CM_Channel123]  = "CM_Channel123";
    ms_mask[CM_All]         = "CM_All";
  };
  std::map<uint32, std::string>::iterator it = ms_mask.find(iChannelMask);
  return (it == ms_mask.end()) ? "CM_None" : it->second.c_str();
} // elxChannelMaskToString 

//----------------------------------------------------------------------------
//  elxToChannelMask
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  : iChannelMask
//  Out :
//----------------------------------------------------------------------------
uint32 elxToChannelMask(const char* iprChannelMask)
{
  static std::map<std::string, uint32> ms_mask;
  if (ms_mask.empty())
  {
    ms_mask[std::string("CM_None")]        = CM_None;
    ms_mask[std::string("CM_Channel0")]    = CM_Channel0;
    ms_mask[std::string("CM_Channel1")]    = CM_Channel1;
    ms_mask[std::string("CM_Channel2")]    = CM_Channel2;
    ms_mask[std::string("CM_Channel3")]    = CM_Channel3;
    ms_mask[std::string("CM_Channel01")]   = CM_Channel01;
    ms_mask[std::string("CM_Channel02")]   = CM_Channel02;
    ms_mask[std::string("CM_Channel03")]   = CM_Channel03;
    ms_mask[std::string("CM_Channel12")]   = CM_Channel12;
    ms_mask[std::string("CM_Channel13")]   = CM_Channel13;
    ms_mask[std::string("CM_Channel23")]   = CM_Channel23;
    ms_mask[std::string("CM_Channel012")]  = CM_Channel012;
    ms_mask[std::string("CM_Channel013")]  = CM_Channel013;
    ms_mask[std::string("CM_Channel023")]  = CM_Channel023;
    ms_mask[std::string("CM_Channel123")]  = CM_Channel123;
    ms_mask[std::string("CM_All")]         = CM_All;
  };
  std::map<std::string, uint32>::iterator it = ms_mask.find(iprChannelMask);
  return (it == ms_mask.end()) ? CM_None : it->second;
} //elxToChannelMask  

/*
template<>
const float& elxNaN()
{ static const float ms_NaN = 0.0f / ::sinf(0.0f); return ms_NaN; }

template<>
const double& exlNaN()
{ static const float ms_NaN = 0.0f / ::sinf(0.0f); return ms_NaN; }

// --- const ---
const float& InfPosf() 
{ static const float ms_Inf = 1.0f / ::sinf(0.0f); return ms_Inf; }

const float& InfNegf() 
{ static const float ms_Inf = -1.0f / ::sinf(0.0f); return ms_Inf; }

const float& NaNf()
{ static const float ms_NaN = 0.0f / ::sinf(0.0f); return ms_NaN; }

const double& InfPosd() 
{  static const double ms_Inf = 1.0 / ::sin(0.0); return ms_Inf; }

const double& InfNegd() 
{ static const double ms_Inf = -1.0 / ::sin(0.0); return ms_Inf; }

const double& NaNd() 
{ static const double ms_NaN = 0.0 / ::sin(0.0); return ms_NaN; }

*/

//----------------------------------------------------------------------------
//  elxHighBit
//----------------------------------------------------------------------------
//  global
//----------------------------------------------------------------------------
//  In  :
//  Out :
//----------------------------------------------------------------------------
int32 elxHighBit(uint32 iVal)
{
  static const int32 ms_highBit[] = { -1,0,1,1,2,2,2,2,3,3,3,3,3,3,3,3 };

  int32 h = 0;
  if (iVal & 0xFFFF0000)	
  {
    h = 16;
    iVal >>= 16;
  }
  if (iVal & 0xFF00) 
  {
    h += 8;
    iVal >>= 8;
  }
  if (iVal & 0xF0)
  {
    h += 4;
    iVal >>= 4;
  }
  return h + ms_highBit[iVal];

} // elxHighBit


//----------------------------------------------------------------------------
//  iX                in range [0.0, 1.0] 
//  iMidtones         in range [0.0, 1.0]
//  Fn(iX, iMidtones) in range [0.0, 1.0]
//----------------------------------------------------------------------------
//  Using Bezier curves with control points:
//  P0(0,0), P1(1-m,m) and P2(1,1)
//
//  Bezier curves with 3 control points is defined as:
//  B(t) = (1-t�)P0 + 2t(1-t)P1 + t�P2, t in [0,1]
//  
//  Bx(t) = (1-t�)P0(x) + 2t(1-t)P1(x) + t�P2(x)
//  By(t) = (1-t�)P0(y) + 2t(1-t)P1(y) + t�P2(y)
//
//  P0 is (0,0), P1 is (1-m,m) and P2 is (1,1) we get
// 
//  Bx(t,m) = (1-t�)0 + 2t(1-t)(1-m) + t�*1
//  By(t,m) = (1-t�)0 + 2t(1-t)m + t�*1
//
//  Bx(t,m) = 2t(1-t)(1-m) + t�    (1)
//  By(t,m) = 2t(1-t)m + t�        (2)
//  
//  We get parametric equation, now let's compute y = Fm(x)
//  from (1) we compute tm as f(x) then replace t with tm in (2)
//         x = 2t(1-t)(1-m) + t�   (3)
// (3) <=> 2t(1-t)(1-m) + t� - x = 0
// (3) <=> (2t-2t�)(1-m) + t� - x = 0
// (3) <=> 2t(1-m) - 2t�(1-m) + t� - x = 0
// (3) <=> (1-2(1-m))t� + 2(1-m)t - x = 0
// (3) <=> (2m-1)t� + 2(1-m)t - x = 0
// (3) <=> at� + bt + c = 0, with a = 2m-1, b = 2(1-m) and c = -x
//
//  This is a 2nd degree polynonial equation in form:  at� + tx + c = 0  (4)
//  There are two solutions:
//  t1 = (-b + sqrt(d))/2a, t2 = (-b - sqrt(d))/2a,  with d =  b� - 4ac
//
//  d = b� - 4ac = 4(1-m)� + 4(2m-1)x
//               = 4((1-m)� + (2m-1)x)
//
//  Tm(x) = (-b + sqrt(d))/2a
//  Tm(x) = (-2(1-m) + sqrt(4((1-m)� + (2m-1)x)))/2(2m-1)
//  Tm(x) = (2(m-1) + 2*sqrt((1-m)� + (2m-1)x))/2(2m-1)
//  Tm(x) = (m - 1 + sqrt((1-m)� + (2m-1)x))/(2m-1)
//
//  y(x,m) = 2t(1-t)m + t� with t = Tm(x)
//         = 2mt-2mt� + t�
//         = (1-2m)t� + 2mt
//----------------------------------------------------------------------------
double elxMidtones1(double iX, double iMidtones)
{
  const double m = iMidtones;
  if (m == 0.5) return iX;

  const double a = (1.0 - m)*(1.0 - m) + (2.0*m - 1.0)*iX;
  const double Tm = (m - 1.0 + elxSqrt(a)) / (2.0*m - 1.0);
  const double y = (1.0 - 2.0*m)*Tm*Tm + 2.0*m*Tm;
  return y;
}


//----------------------------------------------------------------------------
//  iX                in range [0.0, 1.0] 
//  iMidtones         in range ]0.0, 1.0[
//  Fn(iX, iMidtones) in range [0.0, 1.0]
//----------------------------------------------------------------------------
//  NURBS stands for Non Uniform Rational B-Splines
//  Using NURBS curves with control points and weights:
//  P0(0,0)[w0=1] , P1(1,0)[w1=w] and P2(1,1)[w2=1]
//
//  NURBS curves with 3 control points is defined as:
//  
//          (1-t�)w0.P0 + 2t(1-t)w1.P1 + t�w2.P2
//  N(t) = --------------------------------------  with t in [0,1]
//              (1-t�)w0 + 2t(1-t)w1 + t�w2
//
// 
//          (1-t�)w0.P0(x) + 2t(1-t)w1.P1(x) + t�w2.P2(x)
//  Nx(t) = ---------------------------------------------
//                  (1-t�)w0 + 2t(1-t)w1 + t�w2
//
//          (1-t�)w0.P0(y) + 2t(1-t)w1.P1(y) + t�w2.P2(y)
//  Ny(t) = ---------------------------------------------
//                  (1-t�)w0 + 2t(1-t)w1 + t�w2
//
//  We are going to compute the weight w so that 
//  the curve goes through the point [m, 1/2].
//  P0(0,0) [w0=1]
//  P1(1,0) [w1=w] 
//  P2(1,1) [w2=1]
// 
//            (1-t�)0 + 2t(1-t)w + t�1       (2t-2t�)w + t�       2t+(1-2w)t�
//  Nx(t,w) = ------------------------- = --------------------- = -----------
//            (1-t�)1 + 2t(1-t)w + t�1    1-t� + 2wt-2wt� + t�    1+2wt-2wt�
//
//            (1-t�)0 + 2t(1-t)0 + t�1         t�
//  Ny(t,w) = ------------------------- = ----------
//            (1-t�)1 + 2t(1-t)w + t�1    1+2wt-2wt�
//
//  N(t,w) goes through [m, 1/2]:
//
//  Nx(t,w) = m     <=>  m  = 2t+(1-2w)t� / (1+2wt-2wt�)  (1)
//  Ny(t,w) = 1/2   <=> 1/2 = t� / (1+2wt-2wt�)           (2)
//
// (2) <=> 2t� = (1+2wt-2wt�) 
// (2) <=> 0 = 1 + 2wt - 2wt� - 2t�
// (2) <=> (2+2w)t� - 2wt - 1 = 0
// (2) <=> (1+w)t� - wt - 1/2 = 0
// (2) <=> at� + bt + c = 0, with a=1+w, b=-w and c=-1/2
//  t = (-b + sqrt(d))/2a,  with d =  b� - 4ac
//  d = b� - 4ac = (-w)� - 4(1+w)(-1/2)
//  d = w� - 2(1+w)
//  t = (-(-w) + sqrt[w� - 2(1+w)]) / 2(1+w)
//  t = (w + sqrt[w�-2w-2]) / (2+2w)  (3)
//
//  t� = (w + sqrt[w�-2w-2])� / (2+2w)�
//  t� = (w� + 2w*sqrt[w�-2w-2] + w�-2w-2) / 4(w�+2w+1)
//  t� = (2w� + 2w(sqrt[w�-2w-2]-1) -2) / 4(w�+2w+1)
//  t� = (w� + w(sqrt[w�-2w-2]-1) -1) / 2(w�+2w+1)
//
//  replacing (1+2wt-2wt�) = 2t� in (1)
//  m = 2t+(1-2w)t� / 2t�
// ... not so easy Zbynek can you do?
//----------------------------------------------------------------------------
double elxMidtone(double iX, double iMidtones)
{
  // some tolerancing would be useful
  if (iMidtones == 0.5) return iX;

  double m;
  if (iMidtones < 0.5) 
  {
    iX = 1.0 - iX;
    m = 1.0 - iMidtones;
  }
  else 
    m = iMidtones; 

  // evaluate weight for P1, w = f(m)
  const double w = (m-0.5) / sqrt( 2*(1.0-m) );
  const double w2 = w*w;
  const double a = w - 1.0;
  const double b = (w2 - 1.0)*iX*iX + (1.0 - 2.0*w2)*iX + w2;
  const double c = 2.0*a*iX - 2.0*w + 1.0;
  const double t = (elxSqrt(b) + a*iX - w ) / c;
  const double d = 1.0 - t;
  const double t2 = t*t;
  double y = t2 / ( d*d + 2.0*t*d*w + t2 );

  // Are we computing inverse function?
  if (iMidtones < 0.5) y = 1.0 - y;
  return y;

} // elxMidtone


//----------------------------------------------------------------------------
//  random number helpers
//----------------------------------------------------------------------------
// seeds the random-number generator with current time
void elxRandomReset() { ::srand( (uint32)time(NULL) ); }

void elxRandomReset(int32 iSeed) { ::srand(iSeed); }

// Return a pseudorandom int32 sign, +1 or -1.
int32 elxRandomSign() { return ((::rand() & 1) ? 1 : -1); }

// range [0.0, 1.0]
const double sr = 1.0/RAND_MAX;
double elxRandom() { return (sr*rand()); }

} // namespace Math
} // namespace eLynx

