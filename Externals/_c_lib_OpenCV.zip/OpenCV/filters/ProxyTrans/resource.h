//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ProxyTransprop.rc
//
#define VERSION_RES_MINOR_VER           0
#define VERSION_RES_BUILD               0
#define VER_DEBUG                       0
#define VERSION_RES_MAJOR_VER           1
#define IDD_ProxyTransformPROP          101
#define IDC_ProxyTransform              1000
#define IDC_SLIDER1                     1000
#define IDB_DEFAULT                     1001
#define IDS_TITLE                       1003
#define VERSION_RES_LANGUAGE            0x409
#define VERSION_RES_CHARSET             1252
#define IDS_STATIC                      -1
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
